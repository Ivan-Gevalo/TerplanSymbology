<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="1" layerType="Vector" styleCategories="Symbology|Labeling|Fields|Forms|Actions" version="4.0.1-Norrköping">
  <renderer-v2 enableorderby="0" forceraster="0" referencescale="-1" symbollevels="0" type="RuleRenderer">
    <rules key="{84f35168-029a-4725-80e5-b056ba9ec5d1}">
      <rule filter="&quot;Class&quot; = '7F.1'" key="{1863594e-26c3-4bbb-a80c-38909c26fe33}" label="Границы существующих (сохраняемых) земельных участков" symbol="0"/>
      <rule filter="&quot;Class&quot; = '7F.2'" key="{71c600d7-93fd-450f-a6cd-438439ff2ea5}" label="Границы земельных участков, предполагаемых к изъятию для государственных или муниципальных нужд" symbol="1"/>
      <rule filter="&quot;Class&quot; = '7F.3'" key="{4f5f3490-2d6c-4575-aa21-fc2034bb302e}" label="Границы изменяемых земельных участков" symbol="2"/>
      <rule filter="&quot;Class&quot; = '7F.4'" key="{f9b85c01-c5bf-4537-8f2e-8f3ed1f965c2}" label="Границы образуемых земельных участков" symbol="3"/>
      <rule filter="&quot;Class&quot; = '7F.5'" key="{8877a3cc-0af0-426d-a86d-bce3b23a32be}" label="Границы образуемых земельных участков, которые после образования будут относиться к имуществу общего пользования" symbol="4"/>
      <rule filter="&quot;Class&quot; = '7F.6'" key="{61b230da-e221-4f75-9a6a-fced8469afd5}" label="Границы образуемых земельных участков, которые после образования будут относиться к территориям общего пользования" symbol="5"/>
      <rule filter="&quot;Class&quot; = '7F.7'" key="{5393f9a3-b05d-4b6a-b2cf-5dde8335ed5a}" label="Границы образуемых земельных участков, предполагаемых к изъятию для государственных или муниципальных нужд" symbol="6"/>
    </rules>
    <symbols>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="0" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{e491f2ee-3331-4dc1-833d-675b0cf824ef}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="255,230,129,255,rgb:1,0.9019608,0.5058824,1"/>
            <Option name="joinstyle" type="QString" value="miter"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.4"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="1" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{7046bfda-7b23-43a3-a66a-1fd4efe7da83}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="255,129,139,255,rgb:1,0.5058824,0.5450981,1"/>
            <Option name="joinstyle" type="QString" value="miter"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.4"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="2" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{690b56e8-cabb-4cc9-bc87-fcfaa5c0bf74}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="129,255,146,255,rgb:0.5058824,1,0.572549,1"/>
            <Option name="joinstyle" type="QString" value="miter"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.4"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="3" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{c2a02980-6681-42f2-9220-8a52e43dafe7}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="255,163,253,255,rgb:1,0.6392157,0.9921569,1"/>
            <Option name="joinstyle" type="QString" value="miter"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.4"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="4" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{43884b27-a499-4ddf-8fe1-7d1b79511873}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="255,163,253,255,rgb:1,0.6392157,0.9921569,1"/>
            <Option name="joinstyle" type="QString" value="miter"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.4"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="LinePatternFill" enabled="1" id="{f5b70cd0-3317-40e8-9ab7-b13dcefb21b9}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="clip_mode" type="QString" value="during_render"/>
            <Option name="color" type="QString" value="0,0,255,255,rgb:0,0,1,1"/>
            <Option name="coordinate_reference" type="QString" value="feature"/>
            <Option name="distance" type="QString" value="3"/>
            <Option name="distance_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="distance_unit" type="QString" value="MM"/>
            <Option name="line_width" type="QString" value="0.26"/>
            <Option name="line_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
          <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="@4@1" type="line">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleLine" enabled="1" id="{e259d7ca-fa91-435d-a84b-47e92773c644}" locked="0" pass="0">
              <Option type="Map">
                <Option name="align_dash_pattern" type="QString" value="0"/>
                <Option name="capstyle" type="QString" value="flat"/>
                <Option name="customdash" type="QString" value="5;2"/>
                <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="customdash_unit" type="QString" value="MM"/>
                <Option name="dash_pattern_offset" type="QString" value="0"/>
                <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
                <Option name="draw_inside_polygon" type="QString" value="0"/>
                <Option name="joinstyle" type="QString" value="miter"/>
                <Option name="line_color" type="QString" value="3,182,0,255,rgb:0.0117647,0.7137255,0,1"/>
                <Option name="line_style" type="QString" value="solid"/>
                <Option name="line_width" type="QString" value="0.2"/>
                <Option name="line_width_unit" type="QString" value="MM"/>
                <Option name="offset" type="QString" value="0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="ring_filter" type="QString" value="0"/>
                <Option name="trim_distance_end" type="QString" value="0"/>
                <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="trim_distance_end_unit" type="QString" value="MM"/>
                <Option name="trim_distance_start" type="QString" value="0"/>
                <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="trim_distance_start_unit" type="QString" value="MM"/>
                <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
                <Option name="use_custom_dash" type="QString" value="0"/>
                <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="5" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{1f6a597a-6da4-468c-9987-121343a1f52a}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="255,163,253,255,rgb:1,0.6392157,0.9921569,1"/>
            <Option name="joinstyle" type="QString" value="miter"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.4"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="LinePatternFill" enabled="1" id="{3435e0c7-02c9-405e-ad81-41b6499a40d9}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="90"/>
            <Option name="clip_mode" type="QString" value="during_render"/>
            <Option name="color" type="QString" value="0,0,255,255,rgb:0,0,1,1"/>
            <Option name="coordinate_reference" type="QString" value="feature"/>
            <Option name="distance" type="QString" value="3"/>
            <Option name="distance_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="distance_unit" type="QString" value="MM"/>
            <Option name="line_width" type="QString" value="0.26"/>
            <Option name="line_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
          <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="@5@1" type="line">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleLine" enabled="1" id="{6f54f749-3766-4bec-a3a0-cc72291f938e}" locked="0" pass="0">
              <Option type="Map">
                <Option name="align_dash_pattern" type="QString" value="0"/>
                <Option name="capstyle" type="QString" value="flat"/>
                <Option name="customdash" type="QString" value="5;2"/>
                <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="customdash_unit" type="QString" value="MM"/>
                <Option name="dash_pattern_offset" type="QString" value="0"/>
                <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
                <Option name="draw_inside_polygon" type="QString" value="0"/>
                <Option name="joinstyle" type="QString" value="miter"/>
                <Option name="line_color" type="QString" value="3,182,0,255,rgb:0.0117647,0.7137255,0,1"/>
                <Option name="line_style" type="QString" value="solid"/>
                <Option name="line_width" type="QString" value="0.2"/>
                <Option name="line_width_unit" type="QString" value="MM"/>
                <Option name="offset" type="QString" value="0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="ring_filter" type="QString" value="0"/>
                <Option name="trim_distance_end" type="QString" value="0"/>
                <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="trim_distance_end_unit" type="QString" value="MM"/>
                <Option name="trim_distance_start" type="QString" value="0"/>
                <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="trim_distance_start_unit" type="QString" value="MM"/>
                <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
                <Option name="use_custom_dash" type="QString" value="0"/>
                <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="6" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{6a77cbdc-5f5e-4d78-911e-8a883c5ddc0b}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="254,28,58,255,rgb:0.9960784,0.1098039,0.227451,1"/>
            <Option name="joinstyle" type="QString" value="miter"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.4"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{c2d75924-a67e-41a9-8c99-cd82690fdc74}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="0,0,255,255,rgb:0,0,1,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.26"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="&quot;NominalNum&quot; || '\nS=' || round(&quot;Area&quot;, 0) || ' кв. м'" fontFamily="Open Sans" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="11" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="Point" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="Regular" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" stretchFactor="100" tabStopDistance="80" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Point" textColor="194,0,123,255,rgb:0.7607843,0,0.4823529,1" textOpacity="1" textOrientation="horizontal" useSubstitutions="0">
        <families/>
        <text-buffer bufferBlendMode="0" bufferColor="250,250,250,255,rgb:0.9803922,0.9803922,0.9803922,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
        <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
        <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="Point" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="Point" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="Point" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeUnit="Point" shapeSizeX="1" shapeSizeY="0.29999999999999999" shapeType="0">
          <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleMarker" enabled="1" id="" locked="0" pass="0">
              <Option type="Map">
                <Option name="angle" type="QString" value="0"/>
                <Option name="cap_style" type="QString" value="square"/>
                <Option name="color" type="QString" value="125,139,143,255,rgb:0.4901961,0.5450981,0.5607843,1"/>
                <Option name="horizontal_anchor_point" type="QString" value="1"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="name" type="QString" value="circle"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
                <Option name="outline_style" type="QString" value="solid"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="outline_width_unit" type="QString" value="MM"/>
                <Option name="scale_method" type="QString" value="diameter"/>
                <Option name="size" type="QString" value="2"/>
                <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="size_unit" type="QString" value="MM"/>
                <Option name="vertical_anchor_point" type="QString" value="1"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
              <Option type="Map">
                <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                <Option name="outline_style" type="QString" value="no"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_unit" type="QString" value="Point"/>
                <Option name="style" type="QString" value="solid"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
        <dd_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
      <placement allowDegraded="0" centroidInside="0" centroidWhole="0" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="1" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="PolygonGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelEveryPartWithEntireLabel" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="5" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
      <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="3" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
      <dd_properties>
        <Option type="Map">
          <Option name="name" type="QString" value=""/>
          <Option name="properties"/>
          <Option name="type" type="QString" value="collection"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
          <Option name="blendMode" type="int" value="0"/>
          <Option name="ddProperties" type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
          <Option name="drawToAllParts" type="bool" value="false"/>
          <Option name="enabled" type="QString" value="0"/>
          <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
          <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{8a7daa56-ac41-4685-8d48-df7c87f80c7a}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
          <Option name="minLength" type="double" value="0"/>
          <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="minLengthUnit" type="QString" value="MM"/>
          <Option name="offsetFromAnchor" type="double" value="0"/>
          <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
          <Option name="offsetFromLabel" type="double" value="0"/>
          <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Guid">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" type="bool" value="false"/>
            <Option name="UseHtml" type="bool" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Class">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Границы существующих (сохраняемых) земельных участков" type="QString" value="7F.1"/>
              </Option>
              <Option type="Map">
                <Option name="Границы земельных участков, предполагаемых к изъятию для государственных или муниципальных нужд" type="QString" value="7F.2"/>
              </Option>
              <Option type="Map">
                <Option name="Границы изменяемых земельных участков" type="QString" value="7F.3"/>
              </Option>
              <Option type="Map">
                <Option name="Границы образуемых земельных участков" type="QString" value="7F.4"/>
              </Option>
              <Option type="Map">
                <Option name="Границы образуемых земельных участков, которые после образования будут относиться к имуществу общего пользования" type="QString" value="7F.5"/>
              </Option>
              <Option type="Map">
                <Option name="Границы образуемых земельных участков, которые после образования будут относиться к территориям общего пользования" type="QString" value="7F.6"/>
              </Option>
              <Option type="Map">
                <Option name="Границы образуемых земельных участков, предполагаемых к изъятию для государственных или муниципальных нужд" type="QString" value="7F.7"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Status">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий" type="QString" value="7B.1"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый" type="QString" value="7B.2"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="FormingType">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Образование земельных участков из земель или земельных участков, находящихся в государственной или муниципальной собственности" type="QString" value="7G.1"/>
              </Option>
              <Option type="Map">
                <Option name="Раздел земельного участка" type="QString" value="7G.2"/>
              </Option>
              <Option type="Map">
                <Option name="Объединение земельных участков" type="QString" value="7G.3"/>
              </Option>
              <Option type="Map">
                <Option name="Выдел земельного участка" type="QString" value="7G.4"/>
              </Option>
              <Option type="Map">
                <Option name="Перераспределение земельных участков" type="QString" value="7G.5"/>
              </Option>
              <Option type="Map">
                <Option name=" " type="QString" value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NominalNum">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" type="bool" value="false"/>
            <Option name="UseHtml" type="bool" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Location">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" type="bool" value="true"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="PermittedUseType">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" type="bool" value="true"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Area">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" type="bool" value="false"/>
            <Option name="UseHtml" type="bool" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Easement">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" type="bool" value="false"/>
            <Option name="UseHtml" type="bool" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Note">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" type="bool" value="false"/>
            <Option name="UseHtml" type="bool" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" index="0" name=""/>
    <alias field="Guid" index="1" name="Идентификатор объекта"/>
    <alias field="Class" index="2" name="Вид границы образуемого (изменяемого) земельного участка"/>
    <alias field="Status" index="3" name="Статус объекта"/>
    <alias field="FormingType" index="4" name="Способ образования земельного участка"/>
    <alias field="NominalNum" index="5" name="Условный или кадастровый номер образуемого (изменяемого) земельного участка"/>
    <alias field="Location" index="6" name="Местоположение (адрес или при отсутствии адреса иное описание местоположения)"/>
    <alias field="PermittedUseType" index="7" name="Вид разрешенного использования земельного участка и объекта капитального строительства"/>
    <alias field="Area" index="8" name="Площадь общая, кв. м"/>
    <alias field="Easement" index="9" name="Информация о наличии публичного сервитута"/>
    <alias field="Note" index="10" name="Примечание"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" expression="" field="fid"/>
    <default applyOnUpdate="1" expression="uuid('WithoutBraces')" field="Guid"/>
    <default applyOnUpdate="0" expression="'7F.1'" field="Class"/>
    <default applyOnUpdate="0" expression="'7B.1'" field="Status"/>
    <default applyOnUpdate="0" expression="" field="FormingType"/>
    <default applyOnUpdate="0" expression="''" field="NominalNum"/>
    <default applyOnUpdate="0" expression="''" field="Location"/>
    <default applyOnUpdate="0" expression="''" field="PermittedUseType"/>
    <default applyOnUpdate="1" expression="round(area($geometry), 2)" field="Area"/>
    <default applyOnUpdate="0" expression="''" field="Easement"/>
    <default applyOnUpdate="0" expression="''" field="Note"/>
  </defaults>
  <constraints>
    <constraint constraints="3" exp_strength="0" field="fid" notnull_strength="1" unique_strength="1"/>
    <constraint constraints="3" exp_strength="0" field="Guid" notnull_strength="1" unique_strength="1"/>
    <constraint constraints="5" exp_strength="1" field="Class" notnull_strength="1" unique_strength="0"/>
    <constraint constraints="5" exp_strength="1" field="Status" notnull_strength="1" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="FormingType" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="5" exp_strength="1" field="NominalNum" notnull_strength="1" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Location" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="5" exp_strength="1" field="PermittedUseType" notnull_strength="1" unique_strength="0"/>
    <constraint constraints="1" exp_strength="0" field="Area" notnull_strength="1" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Easement" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Note" notnull_strength="0" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="fid"/>
    <constraint desc="" exp="" field="Guid"/>
    <constraint desc="Поле &quot;Вид границы образуемого (изменяемого) земельного участка&quot; должно принимать одно из значений справочника &quot;Виды границы образуемого (изменяемого) земельного участка&quot;" exp="&quot;Class&quot; IN ('7F.1', '7F.2', '7F.3', '7F.4', '7F.5', '7F.6', '7F.7')" field="Class"/>
    <constraint desc="Поле &quot;Статус объекта&quot; должно принимать одно из значений справочника &quot;Статусы объекта&quot;" exp="&quot;Status&quot; IN ('7B.1', '7B.2')" field="Status"/>
    <constraint desc="" exp="" field="FormingType"/>
    <constraint desc="Минимальная длина строки - 1 символ" exp="length(&quot;NominalNum&quot;) > 0" field="NominalNum"/>
    <constraint desc="" exp="" field="Location"/>
    <constraint desc="Минимальная длина строки - 1 символ" exp="length(&quot;PermittedUseType&quot;) > 0" field="PermittedUseType"/>
    <constraint desc="" exp="" field="Area"/>
    <constraint desc="" exp="" field="Easement"/>
    <constraint desc="" exp="" field="Note"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
    <actionsetting action="import re, uuid&#xa;&#xa;from PyQt6 import QtCore, QtWidgets&#xa;from PyQt6.QtWidgets import QDialog, QLabel, QTextEdit, QLineEdit, QDoubleSpinBox, QComboBox, QCheckBox, QPushButton, QFileDialog, QTabWidget, QFrame, QRadioButton&#xa;from PyQt6.QtCore import QSize, QRegularExpression&#xa;from PyQt6.QtGui import QFont, QTextCursor, QCursor, QRegularExpressionValidator&#xa;from PyQt6.QtXml import QDomDocument&#xa;from qgis.core import QgsProject, QgsVectorLayer, QgsMapLayerProxyModel&#xa;from qgis.gui import QgsFileWidget, QgsMapLayerComboBox&#xa;&#xa;POLYGON_GEOMETRY = 2&#xa;&#xa;ALLOWED_USE_CODES = (&quot;214001000000&quot;, &quot;214001001000&quot;, &quot;214001001001&quot;, &quot;214001001002&quot;, &quot;214001001003&quot;, &quot;214001001004&quot;, &quot;214001001005&quot;, &quot;214001001006&quot;, &quot;214001002000&quot;, &quot;214001002001&quot;, &quot;214001002002&quot;, &quot;214001002003&quot;, &quot;214001002004&quot;, &quot;214001003000&quot;, &quot;214001004000&quot;, &quot;214001005000&quot;, &quot;214001006000&quot;, &quot;214001007000&quot;, &quot;214001008000&quot;, &quot;214001009000&quot;, &quot;214001010000&quot;, &quot;214001011000&quot;, &quot;214002000000&quot;, &quot;214002001000&quot;, &quot;214002001001&quot;, &quot;214002002000&quot;, &quot;214002003000&quot;, &quot;214002004000&quot;, &quot;214002005000&quot;, &quot;214002006000&quot;, &quot;214002007000&quot;, &quot;214002007001&quot;, &quot;214002007002&quot;, &quot;214003000000&quot;, &quot;214003001000&quot;, &quot;214003001001&quot;, &quot;214003001002&quot;, &quot;214003002000&quot;, &quot;214003002001&quot;, &quot;214003002002&quot;, &quot;214003002003&quot;, &quot;214003002004&quot;, &quot;214003003000&quot;, &quot;214003004000&quot;, &quot;214003004001&quot;, &quot;214003004002&quot;, &quot;214003004003&quot;, &quot;214003005000&quot;, &quot;214003005001&quot;, &quot;214003005002&quot;, &quot;214003006000&quot;, &quot;214003006001&quot;, &quot;214003006002&quot;, &quot;214003006003&quot;, &quot;214003007000&quot;, &quot;214003007001&quot;, &quot;214003007002&quot;, &quot;214003008000&quot;, &quot;214003008001&quot;, &quot;214003008002&quot;, &quot;214003009000&quot;, &quot;214003009001&quot;, &quot;214003009002&quot;, &quot;214003009003&quot;, &quot;214003010000&quot;, &quot;214003010001&quot;, &quot;214003010002&quot;, &quot;214004000000&quot;, &quot;214004001000&quot;, &quot;214004002000&quot;, &quot;214004003000&quot;, &quot;214004004000&quot;, &quot;214004005000&quot;, &quot;214004006000&quot;, &quot;214004007000&quot;, &quot;214004008000&quot;, &quot;214004008001&quot;, &quot;214004008002&quot;, &quot;214004008003&quot;, &quot;214004009000&quot;, &quot;214004009001&quot;, &quot;214004009111&quot;, &quot;214004009112&quot;, &quot;214004009113&quot;, &quot;214004009114&quot;, &quot;214004009002&quot;, &quot;214004010000&quot;, &quot;214005000000&quot;, &quot;214005001000&quot;, &quot;214005001001&quot;, &quot;214005001002&quot;, &quot;214005001003&quot;, &quot;214005001004&quot;, &quot;214005001005&quot;, &quot;214005001006&quot;, &quot;214005001007&quot;, &quot;214005002000&quot;, &quot;214005002001&quot;, &quot;214005003000&quot;, &quot;214005004000&quot;, &quot;214005005000&quot;, &quot;214006000000&quot;, &quot;214006001000&quot;, &quot;214006002000&quot;, &quot;214006002001&quot;, &quot;214006003000&quot;, &quot;214006003001&quot;, &quot;214006003002&quot;, &quot;214006003003&quot;, &quot;214006003004&quot;, &quot;214006004000&quot;, &quot;214006005000&quot;, &quot;214006006000&quot;, &quot;214006007000&quot;, &quot;214006007001&quot;, &quot;214006008000&quot;, &quot;214006009000&quot;, &quot;214006009001&quot;, &quot;214006011000&quot;, &quot;214006012000&quot;, &quot;214007000000&quot;, &quot;214008000000&quot;, &quot;214008001000&quot;, &quot;214008001001&quot;, &quot;214008001002&quot;, &quot;214008002000&quot;, &quot;214008002001&quot;, &quot;214008002002&quot;, &quot;214008002003&quot;, &quot;214008003000&quot;, &quot;214008004000&quot;, &quot;214008005000&quot;, &quot;214008006000&quot;, &quot;214009000000&quot;, &quot;214010000000&quot;, &quot;214011000000&quot;, &quot;214012000000&quot;, &quot;214013000000&quot;, &quot;214014000000&quot;, &quot;214015000000&quot;, &quot;214015001000&quot;, &quot;214016000000&quot;, &quot;214016001000&quot;, &quot;214017000000&quot;, &quot;214018000000&quot;, &quot;214018001000&quot;, &quot;214018002000&quot;, &quot;214018003000&quot;, &quot;214018004000&quot;, &quot;214019000000&quot;, &quot;214020000000&quot;, &quot;214021000000&quot;, &quot;214022000000&quot;, &quot;214023000000&quot;, &quot;214023001000&quot;, &quot;214023002000&quot;, &quot;214024000000&quot;, &quot;214025000000&quot;, &quot;214026000000&quot;, &quot;214027000000&quot;, &quot;214027001000&quot;, &quot;214027002000&quot;, &quot;214028000000&quot;, &quot;214099000000&quot;)&#xa;&#xa;ALLOWED_USE_TEXT = (&quot;сельскохозяйственное использование&quot;, &quot;растениеводство&quot;, &quot;выращивание зерновых и иных сельскохозяйственных культур&quot;, &quot;овощеводство&quot;, &quot;выращивание тонизирующих, лекарственных, цветочных культур&quot;, &quot;садоводство&quot;, &quot;выращивание льна и конопли&quot;, &quot;виноградарство&quot;, &quot;животноводство&quot;, &quot;скотоводство&quot;, &quot;звероводство&quot;, &quot;птицеводство&quot;, &quot;свиноводство&quot;, &quot;пчеловодство&quot;, &quot;рыбоводство&quot;, &quot;научное обеспечение сельского хозяйства&quot;, &quot;хранение и переработка сельскохозяйственной продукции&quot;, &quot;ведение личного подсобного хозяйства на полевых участках&quot;, &quot;питомники&quot;, &quot;обеспечение сельскохозяйственного производства&quot;, &quot;сенокошение&quot;, &quot;выпас сельскохозяйственных животных&quot;, &quot;жилая застройка&quot;, &quot;для индивидуального жилищного строительства&quot;, &quot;малоэтажная многоквартирная жилая застройка&quot;, &quot;для ведения личного подсобного хозяйства (приусадебный земельный участок)&quot;, &quot;блокированная жилая застройка&quot;, &quot;передвижное жилье&quot;, &quot;среднеэтажная жилая застройка&quot;, &quot;многоэтажная жилая застройка (высотная застройка)&quot;, &quot;обслуживание жилой застройки&quot;, &quot;хранение автотранспорта&quot;, &quot;размещение гаражей для собственных нужд&quot;, &quot;общественное использование объектов капитального строительства&quot;, &quot;коммунальное обслуживание&quot;, &quot;предоставление коммунальных услуг&quot;, &quot;административные здания организаций, обеспечивающих предоставление коммунальных услуг&quot;, &quot;социальное обслуживание&quot;, &quot;дома социального обслуживания&quot;, &quot;оказание социальной помощи населению&quot;, &quot;оказание услуг связи&quot;, &quot;общежития&quot;, &quot;бытовое обслуживание&quot;, &quot;здравоохранение&quot;, &quot;амбулаторно-поликлиническое обслуживание&quot;, &quot;стационарное медицинское обслуживание&quot;, &quot;медицинские организации особого назначения&quot;, &quot;образование и просвещение&quot;, &quot;дошкольное, начальное и среднее общее образование&quot;, &quot;среднее и высшее профессиональное образование&quot;, &quot;культурное развитие&quot;, &quot;объекты культурно-досуговой деятельности&quot;, &quot;парки культуры и отдыха&quot;, &quot;цирки и зверинцы&quot;, &quot;религиозное использование&quot;, &quot;осуществление религиозных обрядов&quot;, &quot;религиозное управление и образование&quot;, &quot;общественное управление&quot;, &quot;государственное управление&quot;, &quot;представительская деятельность&quot;, &quot;обеспечение научной деятельности&quot;, &quot;обеспечение деятельности в области гидрометеорологии и смежных с ней областях&quot;, &quot;проведение научных исследований&quot;, &quot;проведение научных испытаний&quot;, &quot;ветеринарное обслуживание&quot;, &quot;амбулаторное ветеринарное обслуживание&quot;, &quot;приюты для животных&quot;, &quot;предпринимательство&quot;, &quot;деловое управление&quot;, &quot;объекты торговли (торговые центры, торгово-развлекательные центры (комплексы)&quot;, &quot;рынки&quot;, &quot;магазины&quot;, &quot;банковская и страховая деятельность&quot;, &quot;общественное питание&quot;, &quot;гостиничное обслуживание&quot;, &quot;развлечение&quot;, &quot;развлекательные мероприятия&quot;, &quot;проведение азартных игр&quot;, &quot;проведение азартных игр в игорных зонах&quot;, &quot;служебные гаражи&quot;, &quot;объекты дорожного сервиса&quot;, &quot;заправка транспортных средств&quot;, &quot;обеспечение дорожного отдыха&quot;, &quot;автомобильные мойки&quot;, &quot;ремонт автомобилей&quot;, &quot;стоянка транспортных средств&quot;, &quot;выставочно-ярмарочная деятельность&quot;, &quot;отдых (рекреация)&quot;, &quot;спорт&quot;, &quot;обеспечение спортивно-зрелищных мероприятий&quot;, &quot;обеспечение занятий спортом в помещениях&quot;, &quot;площадки для занятий спортом&quot;, &quot;оборудованные площадки для занятий спортом&quot;, &quot;водный спорт&quot;, &quot;авиационный спорт&quot;, &quot;спортивные базы&quot;, &quot;природно-познавательный туризм&quot;, &quot;туристическое обслуживание&quot;, &quot;охота и рыбалка&quot;, &quot;причалы для маломерных судов&quot;, &quot;поля для гольфа или конных прогулок&quot;, &quot;производственная деятельность&quot;, &quot;недропользование&quot;, &quot;тяжелая промышленность&quot;, &quot;автомобилестроительная промышленность&quot;, &quot;легкая промышленность&quot;, &quot;фармацевтическая промышленность&quot;, &quot;фарфоро-фаянсовая промышленность&quot;, &quot;электронная промышленность&quot;, &quot;ювелирная промышленность&quot;, &quot;пищевая промышленность&quot;, &quot;нефтехимическая промышленность&quot;, &quot;строительная промышленность&quot;, &quot;энергетика&quot;, &quot;атомная энергетика&quot;, &quot;связь&quot;, &quot;склад&quot;, &quot;складские площадки&quot;, &quot;целлюлозно-бумажная промышленность&quot;, &quot;научно-производственная деятельность&quot;, &quot;обеспечение космической деятельности&quot;, &quot;транспорт&quot;, &quot;железнодорожный транспорт&quot;, &quot;железнодорожные пути&quot;, &quot;обслуживание железнодорожных перевозок&quot;, &quot;автомобильный транспорт&quot;, &quot;размещение автомобильных дорог&quot;, &quot;обслуживание перевозок пассажиров&quot;, &quot;стоянки транспорта общего пользования&quot;, &quot;водный транспорт&quot;, &quot;воздушный транспорт&quot;, &quot;трубопроводный транспорт&quot;, &quot;внеуличный транспорт&quot;, &quot;обеспечение обороны и безопасности&quot;, &quot;обеспечение вооруженных сил&quot;, &quot;охрана государственной границы российской федерации&quot;, &quot;обеспечение внутреннего правопорядка&quot;, &quot;обеспечение деятельности по исполнению наказаний&quot;, &quot;деятельность по особой охране и изучению природы&quot;, &quot;охрана природных территорий&quot;, &quot;сохранение и репродукция редких и (или) находящихся под угрозой исчезновения видов животных&quot;, &quot;курортная деятельность&quot;, &quot;санаторная деятельность&quot;, &quot;историко-культурная деятельность&quot;, &quot;использование лесов&quot;, &quot;заготовка древесины&quot;, &quot;лесные плантации&quot;, &quot;заготовка лесных ресурсов&quot;, &quot;резервные леса&quot;, &quot;водные объекты&quot;, &quot;общее пользование водными объектами&quot;, &quot;специальное пользование водными объектами&quot;, &quot;гидротехнические сооружения&quot;, &quot;земельные участки (территории) общего пользования&quot;, &quot;улично-дорожная сеть&quot;, &quot;благоустройство территории&quot;, &quot;ритуальная деятельность&quot;, &quot;специальная деятельность&quot;, &quot;запас&quot;, &quot;земельные участки общего назначения&quot;, &quot;ведение огородничества&quot;, &quot;ведение садоводства&quot;, &quot;земельные участки, входящие в состав общего имущества собственников индивидуальных жилых домов в малоэтажном жилом комплексе&quot;, &quot;сведения отсутствуют&quot;)&#xa;&#xa;def isLayerValid():&#xa;    if layer.featureCount() == 0:&#xa;        QtWidgets.QMessageBox.critical(None, &quot;Внимание!&quot;, &quot;Слой не содержит объектов. Операция прервана.&quot;)&#xa;        return False&#xa;        &#xa;    return True&#xa;&#xa;def limitNameObj():&#xa;    maxLimit = 1000&#xa;    textContent = nameObj.toPlainText()&#xa;&#xa;    if len(textContent) > maxLimit:&#xa;        nameObj.blockSignals(True)&#xa;        nameObj.setPlainText(textContent[:maxLimit])&#xa;            &#xa;        cursor = nameObj.textCursor()&#xa;        &#xa;        cursor.movePosition(QTextCursor.MoveOperation.End)&#xa;        nameObj.setTextCursor(cursor)&#xa;        nameObj.blockSignals(False)&#xa;&#xa;def validateAllInputs():&#xa;    cadNumPattern = re.compile(r&quot;^\d{1,2}:\d{1,2}:(\d{1}|\d{6,7})$&quot;)&#xa;    skCodePattern = re.compile(r&quot;^\d{2}\.\d{1,2}$&quot;)&#xa;    projectNumPattern = re.compile(r&quot;^\d{2}\.\d{2}\.\d{7}\.\d{1,5}$&quot;)&#xa;&#xa;    if len(nameObj.toPlainText()) == 0:&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;Поле с наименованием проекта межевания территории не может быть пустым.&quot;)&#xa;        return False&#xa;&#xa;    if not re.match(cadNumPattern, cadNum.text()):&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;Указано некорректное значение кадастрового номера квартала.&quot;)&#xa;        return False&#xa;&#xa;    if not re.match(skCodePattern, skCode.text()):&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;Указан некорректный код системы координат.&quot;)&#xa;        return False&#xa;    &#xa;    if changingProject.isChecked() and not re.match(projectNumPattern, projectNum.text()):&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;Необходимо указать корректный учетный номер проекта межевания территории, ранее внесенного в ЕГРН.&quot;)&#xa;        return False&#xa;    &#xa;    return True&#xa;&#xa;def validateFeatures(features):&#xa;    validFeatures = []&#xa;&#xa;    for feature in features:&#xa;        if feature.attribute(&quot;Class&quot;) in (&quot;7F.4&quot;, &quot;7F.5&quot;, &quot;7F.6&quot;, &quot;7F.7&quot;) and not feature.geometry().isEmpty() and len(feature.attribute(&quot;NominalNum&quot;)) > 0:&#xa;            validFeatures.append(feature)&#xa;&#xa;    return validFeatures&#xa;&#xa;def projectLayerClcked():&#xa;    fileSelector.setEnabled(False)&#xa;    pLayers.setEnabled(True)&#xa;&#xa;def externalFileClicked():&#xa;    pLayers.setEnabled(False)&#xa;    fileSelector.setEnabled(True)&#xa;&#xa;def noBordersClicked():&#xa;    pLayers.setEnabled(False)&#xa;    fileSelector.setEnabled(False)&#xa;&#xa;def changingProjectActivated():&#xa;    if changingProject.isChecked():&#xa;        projectNumLabel.setEnabled(True)&#xa;        projectNum.setEnabled(True)&#xa;        partialBound.show()&#xa;        deleteContoursLabel.show()&#xa;        deleteContours.show()&#xa;        boundsLabel.setText(&quot;Описание местоположения добавляемых контуров границы&quot;)&#xa;        noBorders.setText(&quot;Сведения о новых контурах отсутствуют&quot;)&#xa;    else:&#xa;        projectNumLabel.setEnabled(False)&#xa;        projectNum.setEnabled(False)&#xa;        partialBound.hide()&#xa;        deleteContoursLabel.hide()&#xa;        deleteContours.hide()&#xa;        boundsLabel.setText(&quot;Описание местоположения границы&quot;)&#xa;        noBorders.setText(&quot;Сведения о границе территории отсутствуют&quot;)&#xa;&#xa;def loadMIFLayer(filePath):&#xa;    boundsLayer = QgsVectorLayer(filePath, &quot;layer&quot;, &quot;ogr&quot;)&#xa;&#xa;    if boundsLayer.isValid() and boundsLayer.geometryType() == POLYGON_GEOMETRY:&#xa;        return boundsLayer&#xa;    &#xa;    return None&#xa;&#xa;def buildSpatialElement(coords, ptIdx):&#xa;    doc = QDomDocument()&#xa;&#xa;    spatialElement = doc.createElement(&quot;EnSpa2:spatial_element&quot;)&#xa;    typeUnit = doc.createElement(&quot;EnSpa2:type_unit&quot;)&#xa;    typeUnit.appendChild(doc.createTextNode(&quot;01&quot;))&#xa;    spatialElement.appendChild(typeUnit)&#xa;&#xa;    ordinates = doc.createElement(&quot;EnSpa2:ordinates&quot;)&#xa;    spatialElement.appendChild(ordinates)&#xa;&#xa;    for n, point in enumerate(coords):&#xa;        ordinate = doc.createElement(&quot;EnSpa2:ordinate&quot;)&#xa;        xCoord = doc.createElement(&quot;EnSpa2:x&quot;)&#xa;        xCoord.appendChild(doc.createTextNode(str(round(point[0], 2))))&#xa;        yCoord = doc.createElement(&quot;EnSpa2:y&quot;)&#xa;        yCoord.appendChild(doc.createTextNode(str(round(point[1], 2))))&#xa;                &#xa;        ordinate.appendChild(xCoord)&#xa;        ordinate.appendChild(yCoord)&#xa;&#xa;        ordNmb = doc.createElement(&quot;EnSpa2:ord_nmb&quot;)&#xa;        numGeopoint = doc.createElement(&quot;EnSpa2:num_geopoint&quot;)&#xa;&#xa;        if n == (len(coords) - 1):&#xa;            ordNmb.appendChild(doc.createTextNode(str(ptIdx + 1)))&#xa;            numGeopoint.appendChild(doc.createTextNode(str(ptIdx + 1)))&#xa;        else:&#xa;            ordNmb.appendChild(doc.createTextNode(str(n + 1 + ptIdx)))&#xa;            numGeopoint.appendChild(doc.createTextNode(str(n + 1 + ptIdx)))&#xa;&#xa;        ordinate.appendChild(ordNmb)&#xa;        ordinate.appendChild(numGeopoint)&#xa;                    &#xa;        geopointOpred = doc.createElement(&quot;EnSpa2:geopoint_opred&quot;)&#xa;        geopointOpred.appendChild(doc.createTextNode(geoOpredsCodes[geoOpred.currentIndex()]))&#xa;        ordinate.appendChild(geopointOpred)&#xa;&#xa;        deltaGeopoint = doc.createElement(&quot;EnSpa2:delta_geopoint&quot;)&#xa;        deltaGeopoint.appendChild(doc.createTextNode(str(delta.value())))&#xa;        ordinate.appendChild(deltaGeopoint)&#xa;        ordinates.appendChild(ordinate)&#xa;        &#xa;    return spatialElement&#xa;&#xa;def buildContours(feat, doc, isBoundaryChange):&#xa;    geom = feat.geometry()&#xa;    cntrs = []&#xa;        &#xa;    if geom.isMultipart():&#xa;        polygons = geom.asMultiPolygon()&#xa;    else:&#xa;        polygons = [geom.asPolygon()]&#xa;&#xa;    startPtIdx = 0&#xa;&#xa;    for i, poly in enumerate(polygons):&#xa;        exterior_coords = [(p.x(), p.y()) for p in poly[0]]&#xa;        holes_coords = [[(p.x(), p.y()) for p in ring] for ring in poly[1:]]&#xa;        &#xa;        if isBoundaryChange:&#xa;            contour = doc.createElement(&quot;EnSpa2:new_contour&quot;)&#xa;        else:&#xa;            contour = doc.createElement(&quot;EnSpa2:contour&quot;)&#xa;&#xa;        if len(list(geom.constParts())) > 1:&#xa;            numPP = doc.createElement(&quot;EnSpa2:number_pp&quot;)&#xa;            numPP.appendChild(doc.createTextNode(str(i + 1)))&#xa;            contour.appendChild(numPP)&#xa;&#xa;        if isBoundaryChange:&#xa;            nContour = doc.createElement(&quot;EnSpa2:contour&quot;)&#xa;            nContour.appendChild(contour)&#xa;            cntrs.append(nContour)&#xa;        else:&#xa;            cntrs.append(contour)&#xa;&#xa;        entitySpatial = doc.createElement(&quot;EnSpa2:entity_spatial&quot;)&#xa;        sCode = doc.createElement(&quot;EnSpa2:sk_code&quot;)&#xa;        sCode.appendChild(doc.createTextNode(skCode.text()))&#xa;        entitySpatial.appendChild(sCode)&#xa;        contour.appendChild(entitySpatial)&#xa;&#xa;        spatialsElements = doc.createElement(&quot;EnSpa2:spatials_elements&quot;)&#xa;        spatialsElements.appendChild(buildSpatialElement(exterior_coords, startPtIdx))&#xa;&#xa;        startPtIdx += (len(exterior_coords) - 1)&#xa;&#xa;        if len(holes_coords) > 0:&#xa;            for hole in holes_coords:&#xa;                spatialsElements.appendChild(buildSpatialElement(hole, startPtIdx))&#xa;&#xa;                startPtIdx += (len(hole) - 1)&#xa;&#xa;        entitySpatial.appendChild(spatialsElements)&#xa;&#xa;    return cntrs&#xa;&#xa;def buildDeleteContours(doc):&#xa;    cntrs = []&#xa;&#xa;    for cNum in deleteContours.text().split(&quot;,&quot;):&#xa;        contour = doc.createElement(&quot;EnSpa2:contour&quot;)&#xa;        dContour = doc.createElement(&quot;EnSpa2:delete_contour&quot;)&#xa;        dContourNum = doc.createElement(&quot;EnSpa2:number_pp&quot;)&#xa;        dContourNum.appendChild(doc.createTextNode(cNum))&#xa;        dContour.appendChild(dContourNum)&#xa;        contour.appendChild(dContour)&#xa;        cntrs.append(contour)&#xa;&#xa;    return cntrs&#xa;&#xa;def buildXMLTree(id):&#xa;    if onlySelected.isChecked():&#xa;        features = validateFeatures(layer.selectedFeatures())&#xa;    else:&#xa;        features = validateFeatures(layer.getFeatures())&#xa;&#xa;    if len(features) == 0:&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;В составе слоя отсутствуют земельные участки, подлежащие записи в электронный документ.&quot;)&#xa;        window.reject()&#xa;&#xa;    xmlDocument = QDomDocument()&#xa;&#xa;    docRoot = xmlDocument.createElement(&quot;interact_entry_boundaries&quot;)&#xa;    docRoot.setAttribute(&quot;xmlns&quot;, &quot;urn://x-artefacts-rosreestr-ru/interact/interact-entry-boundaries/2.0.1&quot;)&#xa;    docRoot.setAttribute(&quot;xmlns:iBND2&quot;, &quot;urn://x-artefacts-rosreestr-ru/interact/interact-entry-boundaries/2.0.1&quot;)&#xa;    docRoot.setAttribute(&quot;xmlns:Are1&quot;, &quot;urn://x-artefacts-rosreestr-ru/commons/complex-types/area/1.0.1&quot;)&#xa;    docRoot.setAttribute(&quot;xmlns:EnSpa2&quot;, &quot;urn://x-artefacts-rosreestr-ru/commons/complex-types/entity-spatial/2.0.1&quot;)&#xa;    docRoot.setAttribute(&quot;guid&quot;, id)&#xa;    docRoot.setAttribute(&quot;version&quot;, &quot;02&quot;)&#xa;&#xa;    xmlDocument.appendChild(docRoot)&#xa;&#xa;    boundaries = xmlDocument.createElement(&quot;information_registry_boundaries&quot;)&#xa;    docRoot.appendChild(boundaries)&#xa;&#xa;    boundary = xmlDocument.createElement(&quot;information_registry_boundary&quot;)&#xa;    boundaries.appendChild(boundary)&#xa;&#xa;    typeBoundary = xmlDocument.createElement(&quot;iBND2:type_boundary&quot;)&#xa;    typeBoundary.appendChild(xmlDocument.createTextNode(&quot;17&quot;))&#xa;    boundary.appendChild(typeBoundary)&#xa;&#xa;    nameObject = xmlDocument.createElement(&quot;iBND2:name_object&quot;)&#xa;    nameObject.appendChild(xmlDocument.createTextNode(nameObj.toPlainText()))&#xa;    boundary.appendChild(nameObject)&#xa;&#xa;    allBorder = xmlDocument.createElement(&quot;iBND2:all_border_or_part_border&quot;)&#xa;&#xa;    if changingProject.isChecked() and partialBound.isChecked():&#xa;        allBorder.appendChild(xmlDocument.createTextNode(&quot;0&quot;))&#xa;    else:&#xa;        allBorder.appendChild(xmlDocument.createTextNode(&quot;1&quot;))&#xa;    &#xa;    boundary.appendChild(allBorder)&#xa;&#xa;    infoBoundary = xmlDocument.createElement(&quot;iBND2:information_boundary&quot;)&#xa;    boundary.appendChild(infoBoundary)&#xa;&#xa;    surveyingProject = xmlDocument.createElement(&quot;iBND2:surveying_project&quot;)&#xa;    infoBoundary.appendChild(surveyingProject)&#xa;&#xa;    if not changingProject.isChecked():&#xa;        sProject = xmlDocument.createElement(&quot;iBND2:establishment_surveying_project&quot;)&#xa;    else:&#xa;        sProject = xmlDocument.createElement(&quot;iBND2:changing_surveying_project&quot;)&#xa;    &#xa;    surveyingProject.appendChild(sProject)&#xa;&#xa;    cadNumber = xmlDocument.createElement(&quot;iBND2:quarter_cad_number&quot;)&#xa;    cadNumber.appendChild(xmlDocument.createTextNode(cadNum.text()))&#xa;    sProject.appendChild(cadNumber)&#xa;&#xa;    if changingProject.isChecked():&#xa;        sProjectNum = xmlDocument.createElement(&quot;iBND2:survey_project_num&quot;)&#xa;        sProjectNum.appendChild(xmlDocument.createTextNode(projectNum.text()))&#xa;        sProject.appendChild(sProjectNum)&#xa;&#xa;    formingParcels = xmlDocument.createElement(&quot;iBND2:forming_parcels&quot;)&#xa;        &#xa;    # формирование границ образуемых ЗУ&#xa;    for feature in features:&#xa;        formingParcel = xmlDocument.createElement(&quot;iBND2:forming_parcel&quot;)&#xa;        nominalNumber = xmlDocument.createElement(&quot;iBND2:nominal_number&quot;)&#xa;        nominalNumber.appendChild(xmlDocument.createTextNode(feature.attribute(&quot;NominalNum&quot;)))&#xa;        formingParcel.appendChild(nominalNumber)&#xa;        &#xa;        subtype = xmlDocument.createElement(&quot;iBND2:subtype&quot;)&#xa;        &#xa;        if len(list(feature.geometry().constParts())) > 1:&#xa;            subtype.appendChild(xmlDocument.createTextNode(&quot;05&quot;))&#xa;        else:&#xa;            subtype.appendChild(xmlDocument.createTextNode(&quot;01&quot;))&#xa;            &#xa;        formingParcel.appendChild(subtype)&#xa;            &#xa;        fArea = xmlDocument.createElement(&quot;iBND2:area&quot;)&#xa;        areaValue = xmlDocument.createElement(&quot;Are1:value&quot;)&#xa;        areaValue.appendChild(xmlDocument.createTextNode(str(round(feature.geometry().area(), 2))))&#xa;        fArea.appendChild(areaValue)&#xa;        formingParcel.appendChild(fArea)&#xa;        &#xa;        if len(feature.attribute(&quot;PermittedUseType&quot;)) > 0:&#xa;            permittedUse = xmlDocument.createElement(&quot;iBND2:permitted_use_grad_reg&quot;)&#xa;            permittedUseText = xmlDocument.createElement(&quot;iBND2:permitted_use_text&quot;)&#xa;            permittedUseText.appendChild(xmlDocument.createTextNode(feature.attribute(&quot;PermittedUseType&quot;)))&#xa;            permittedUse.appendChild(permittedUseText)&#xa;            formingParcel.appendChild(permittedUse)&#xa;&#xa;            try:&#xa;                allowedUseIndex = ALLOWED_USE_TEXT.index(feature.attribute(&quot;PermittedUseType&quot;).lower())&#xa;                permittedUseCode = xmlDocument.createElement(&quot;iBND2:land_use&quot;)&#xa;                permittedUseCode.appendChild(xmlDocument.createTextNode(ALLOWED_USE_CODES[allowedUseIndex]))&#xa;                permittedUse.appendChild(permittedUseCode)&#xa;            except (ValueError):&#xa;                pass&#xa;            &#xa;        contoursLocation = xmlDocument.createElement(&quot;iBND2:zu_contours_location&quot;)&#xa;        contours = xmlDocument.createElement(&quot;EnSpa2:contours&quot;)&#xa;        contoursLocation.appendChild(contours)&#xa;        &#xa;        for cnt in buildContours(feature, xmlDocument, False):&#xa;            contours.appendChild(cnt)&#xa;        &#xa;        formingParcel.appendChild(contoursLocation)&#xa;&#xa;        if feature.attribute(&quot;Class&quot;) in (&quot;7F.5&quot;, &quot;7F.6&quot;):&#xa;            commonUse = xmlDocument.createElement(&quot;iBND2:common_use&quot;)&#xa;            formingParcel.appendChild(commonUse)&#xa;&#xa;            if feature.attribute(&quot;Class&quot;) == &quot;7F.5&quot;:&#xa;                propertyCommonUse = xmlDocument.createElement(&quot;iBND2:property_common_use&quot;)&#xa;                propertyCommonUse.appendChild(xmlDocument.createTextNode(&quot;true&quot;))&#xa;                commonUse.appendChild(propertyCommonUse)&#xa;&#xa;            if feature.attribute(&quot;Class&quot;) == &quot;7F.6&quot;:&#xa;                territoryCommonUse = xmlDocument.createElement(&quot;iBND2:territory_common_use&quot;)&#xa;                territoryCommonUse.appendChild(xmlDocument.createTextNode(&quot;true&quot;))&#xa;                commonUse.appendChild(territoryCommonUse)&#xa;        &#xa;        formingParcels.appendChild(formingParcel)&#xa;&#xa;    sProject.appendChild(formingParcels)&#xa;&#xa;    # формирование границы территории&#xa;    bLayer = None&#xa;&#xa;    if projectLayer.isChecked():&#xa;        bLayer = pLayers.currentLayer()&#xa;&#xa;    if externalFile.isChecked():&#xa;        if len(fileSelector.filePath()) > 0:&#xa;            bLayer = loadMIFLayer(fileSelector.filePath())&#xa;&#xa;    if bLayer is not None or (changingProject.isChecked() and len(deleteContours.text()) > 0):&#xa;        bounds = xmlDocument.createElement(&quot;iBND2:contours_location&quot;)&#xa;        contours = xmlDocument.createElement(&quot;EnSpa2:contours&quot;)&#xa;&#xa;        if changingProject.isChecked() and len(deleteContours.text()) > 0:&#xa;            for dCnt in buildDeleteContours(xmlDocument):&#xa;                contours.appendChild(dCnt)&#xa;&#xa;        if bLayer is not None:&#xa;            if changingProject.isChecked():&#xa;                bndFlag = True&#xa;            else:&#xa;                bndFlag = False&#xa;&#xa;            for bFeature in bLayer.getFeatures():&#xa;                for cnt in buildContours(bFeature, xmlDocument, bndFlag):&#xa;                    contours.appendChild(cnt)&#xa;&#xa;        bounds.appendChild(contours)&#xa;        sProject.appendChild(bounds)&#xa;&#xa;    return xmlDocument&#xa;&#xa;def exportToXML():&#xa;    if validateAllInputs():&#xa;        documentId = str(uuid.uuid4())&#xa;        selectedDirectory = QFileDialog.getExistingDirectory(window, &quot;Выбор каталога для сохранения документа&quot;)&#xa;&#xa;        if selectedDirectory:&#xa;            xmlTree = buildXMLTree(documentId)&#xa;&#xa;            with open(selectedDirectory + &quot;/&quot; + &quot;interact_entry_boundaries_&quot; + documentId + &quot;.xml&quot;, &quot;w&quot;) as file:&#xa;                file.write(xmlTree.toString(4))&#xa;&#xa;            QtWidgets.QMessageBox.information(window, &quot;Операция завершена&quot;, f&quot;Электронный документ interact_entry_boundaries_{documentId}.xml сохранен.&quot;)&#xa;&#xa;            window.done(1)&#xa;&#xa;layer = QgsProject.instance().mapLayer('[%@layer_id%]')&#xa;&#xa;if isLayerValid():&#xa;    geoOpredsCodes = [&quot;692001000000&quot;, &quot;692002000000&quot;, &quot;692003000000&quot;, &quot;692004000000&quot;, &quot;692005000000&quot;, &quot;692006000000&quot;]&#xa;    geoOpredsValues = [&quot;Геодезический метод&quot;, &quot;Фотограмметрический метод&quot;, &quot;Картометрический метод&quot;, &quot;Иное описание&quot;, &quot;Метод спутниковых геодезических измерений (определений)&quot;, &quot;Аналитический метод&quot;]&#xa;&#xa;    window = QDialog()&#xa;    window.setFixedSize(QSize(700, 515))&#xa;    window.move(window.frameGeometry().center())&#xa;    window.setModal(True)&#xa;&#xa;    window.setWindowTitle(&quot;Формирование электронного документа&quot;)&#xa;&#xa;    tabs = QTabWidget(window)&#xa;&#xa;    iFrame = QFrame(tabs)&#xa;    bFrame = QFrame(tabs)&#xa;&#xa;    tabs.addTab(iFrame, &quot;Сведения о проекте межевания&quot;)&#xa;    tabs.addTab(bFrame, &quot;Сведения о границе территории&quot;)&#xa;    tabs.setCurrentIndex(0)&#xa;    tabs.resize(690, 455)&#xa;    tabs.move(5, 5)&#xa;&#xa;    # виджеты на вкладке &quot;Сведения о проекте межевания&quot;&#xa;    nameObjLabel = QLabel(&quot;Наименование проекта межевания территории&quot;, iFrame)&#xa;    nameObjLabel.setFont(QFont(None, 10, QFont.Weight.Bold))&#xa;    nameObjLabel.move(10, 10)&#xa;&#xa;    nameObj = QTextEdit(iFrame)&#xa;    nameObj.textChanged.connect(limitNameObj)&#xa;    nameObj.setPlaceholderText(&quot;Максимальная длина 1000 символов&quot;)&#xa;    nameObj.resize(667, 109)&#xa;    nameObj.move(10, 35)&#xa;&#xa;    cadNumLabel = QLabel(&quot;Кадастровый номер квартала&quot;, iFrame)&#xa;    cadNumLabel.setFont(QFont(None, 10, QFont.Weight.Bold))&#xa;    cadNumLabel.move(10, 162)&#xa;&#xa;    cadNum = QLineEdit(iFrame)&#xa;    cadNum.setInputMask(&quot;99:99:9999999&quot;)&#xa;    cadNum.setMaxLength(13)&#xa;    cadNum.resize(150, 25)&#xa;    cadNum.move(250, 158)&#xa;&#xa;    skCodeLabel = QLabel(&quot;Код системы координат&quot;, iFrame)&#xa;    skCodeLabel.setFont(QFont(None, 10, QFont.Weight.Bold))&#xa;    skCodeLabel.move(417, 162)&#xa;&#xa;    skCode = QLineEdit(iFrame)&#xa;    skCode.setInputMask(&quot;99.99&quot;)&#xa;    skCode.setMaxLength(5)&#xa;    skCode.resize(60, 25)&#xa;    skCode.move(617, 158)&#xa;&#xa;    geoOpredLabel = QLabel(&quot;Метод определения координат&quot;, iFrame)&#xa;    geoOpredLabel.setFont(QFont(None, 10, QFont.Weight.Bold))&#xa;    geoOpredLabel.move(10, 200)&#xa;&#xa;    geoOpred = QComboBox(iFrame)&#xa;    geoOpred.addItems(geoOpredsValues)&#xa;    geoOpred.setEditable(False)&#xa;    geoOpred.setCurrentIndex(5)&#xa;    geoOpred.resize(667, 25)&#xa;    geoOpred.move(10, 225)&#xa;&#xa;    deltaLabel = QLabel(&quot;Погрешность определения координат&quot;, iFrame)&#xa;    deltaLabel.setFont(QFont(None, 10, QFont.Weight.Bold))&#xa;    deltaLabel.move(10, 268)&#xa;&#xa;    delta = QDoubleSpinBox(iFrame)&#xa;    delta.setRange(0.10, 5.00)&#xa;    delta.setSingleStep(0.10)&#xa;    delta.resize(80, 25)&#xa;    delta.move(315, 265)&#xa;&#xa;    changingProject = QCheckBox(&quot;Внесение изменений в проект межевания территории&quot;, iFrame)&#xa;    changingProject.stateChanged.connect(changingProjectActivated)&#xa;    changingProject.move(10, 305)&#xa;&#xa;    projectNumLabel = QLabel(&quot;Учетный номер проекта межевания территории&quot;, iFrame)&#xa;    projectNumLabel.setFont(QFont(None, 10, QFont.Weight.Bold))&#xa;    projectNumLabel.move(10, 335)&#xa;    projectNumLabel.setEnabled(False)&#xa;&#xa;    projectNum = QLineEdit(iFrame)&#xa;    projectNum.setInputMask(&quot;99.99.9999999.99999&quot;)&#xa;    projectNum.setToolTip(&quot;Учетный номер границы проекта межевания территории, ранее внесенного в ЕГРН&quot;)&#xa;    projectNum.resize(160, 25)&#xa;    projectNum.move(388, 331)&#xa;    projectNum.setEnabled(False)&#xa;&#xa;    onlySelected = QCheckBox(&quot;Сохранить только выделенные объекты&quot;, iFrame)&#xa;    onlySelected.move(10, 380)&#xa;&#xa;    # виджеты на вкладке &quot;Сведения о границе территории&quot;&#xa;    boundsLabel = QLabel(&quot;Описание местоположения границы&quot;, bFrame)&#xa;    boundsLabel.setFont(QFont(None, 10, QFont.Weight.Bold))&#xa;    boundsLabel.resize(600, 25)&#xa;    boundsLabel.move(10, 10)&#xa;&#xa;    projectLayer = QRadioButton(&quot;Слой из проекта&quot;, bFrame)&#xa;    projectLayer.click()&#xa;    projectLayer.clicked.connect(projectLayerClcked)&#xa;    projectLayer.move(10, 35)&#xa;&#xa;    pLayers = QgsMapLayerComboBox(bFrame)&#xa;    pLayers.setFilters(QgsMapLayerProxyModel.PolygonLayer)&#xa;    pLayers.resize(667, 25)&#xa;    pLayers.move(10, 70)&#xa;&#xa;    externalFile = QRadioButton(&quot;Внешний файл&quot;, bFrame)&#xa;    externalFile.clicked.connect(externalFileClicked)&#xa;    externalFile.move(10, 105)&#xa;&#xa;    fileSelector = QgsFileWidget(bFrame)&#xa;    fileSelector.setFilter(&quot;Файлы MapInfo MIF (*.mif)&quot;)&#xa;    fileSelector.setEnabled(False)&#xa;    fileSelector.resize(667, 27)&#xa;    fileSelector.move(10, 140)&#xa;&#xa;    noBorders = QRadioButton(&quot;Сведения о границе территории отсутствуют&quot;, bFrame)&#xa;    noBorders.clicked.connect(noBordersClicked)&#xa;    noBorders.move(10, 175)&#xa;&#xa;    deleteContoursLabel = QLabel(&quot;Номера удаляемых контуров&quot;, bFrame)&#xa;    deleteContoursLabel.setFont(QFont(None, 10, QFont.Weight.Bold))&#xa;    deleteContoursLabel.move(10, 220)&#xa;    deleteContoursLabel.hide()&#xa;&#xa;    deleteContours = QLineEdit(bFrame)&#xa;    deleteContours.setPlaceholderText(&quot;Укажите через запятую номера удаляемых контуров&quot;)&#xa;    deleteContours.setToolTip(&quot;Номера контуров в соответствии с выпиской из ЕГРН&quot;)&#xa;    deleteContours.setValidator(QRegularExpressionValidator(QRegularExpression(&quot;^(\d{1,10},)*$&quot;)))&#xa;    deleteContours.resize(427, 25)&#xa;    deleteContours.move(250, 216)&#xa;    deleteContours.hide()&#xa;&#xa;    partialBound = QCheckBox(&quot;Вносятся сведения о части границы&quot;, bFrame)&#xa;    partialBound.move(10, 256)&#xa;    partialBound.hide()&#xa;&#xa;&#xa;    button = QPushButton(&quot;Сформировать&quot;, window)&#xa;    button.setCursor(QCursor(QtCore.Qt.CursorShape.PointingHandCursor))&#xa;    button.clicked.connect(exportToXML)&#xa;    button.resize(110, 25)&#xa;    button.move(580, 480)&#xa;&#xa;    if layer.selectedFeatureCount() > 0:&#xa;        onlySelected.setEnabled(True)&#xa;    else:&#xa;        onlySelected.setEnabled(False)&#xa;&#xa;    window.show()&#xa;" capture="0" icon="" id="{ee95666b-8de4-4f34-81e3-77796120b5ad}" isEnabledOnlyWhenEditable="0" name="Сформировать электронный документ" notificationMessage="" shortTitle="Сформировать электронный документ" type="1">
      <actionScope id="Layer"/>
    </actionsetting>
  </attributeactions>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="" overrideLabelColor="0" overrideLabelFont="0">
      <labelFont bold="0" description="Sans Serif,9,-1,5,400,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
    </labelStyle>
    <attributeEditorContainer collapsed="0" collapsedExpression="" collapsedExpressionEnabled="0" columnCount="1" groupBox="0" horizontalStretch="0" name="Обязательные атрибуты" showLabel="1" type="Tab" verticalStretch="0" visibilityExpression="" visibilityExpressionEnabled="0">
      <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont bold="0" description="DejaVu Sans,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
      </labelStyle>
      <attributeEditorField horizontalStretch="0" index="1" name="Guid" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont bold="1" description="DejaVu Sans,10,-1,5,700,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField horizontalStretch="0" index="2" name="Class" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont bold="1" description="DejaVu Sans,10,-1,5,700,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField horizontalStretch="0" index="3" name="Status" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont bold="1" description="DejaVu Sans,10,-1,5,700,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField horizontalStretch="0" index="5" name="NominalNum" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont bold="1" description="DejaVu Sans,10,-1,5,700,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField horizontalStretch="0" index="7" name="PermittedUseType" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont bold="1" description="DejaVu Sans,10,-1,5,700,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField horizontalStretch="0" index="8" name="Area" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont bold="1" description="DejaVu Sans,10,-1,5,700,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer collapsed="0" collapsedExpression="" collapsedExpressionEnabled="0" columnCount="1" groupBox="0" horizontalStretch="0" name="Необязательные атрибуты" showLabel="1" type="Tab" verticalStretch="0" visibilityExpression="" visibilityExpressionEnabled="0">
      <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont bold="0" description="DejaVu Sans,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
      </labelStyle>
      <attributeEditorField horizontalStretch="0" index="4" name="FormingType" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont bold="1" description="DejaVu Sans,10,-1,5,700,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField horizontalStretch="0" index="6" name="Location" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont bold="1" description="DejaVu Sans,10,-1,5,700,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField horizontalStretch="0" index="10" name="Note" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont bold="1" description="DejaVu Sans,10,-1,5,700,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer collapsed="0" collapsedExpression="" collapsedExpressionEnabled="0" columnCount="1" groupBox="0" horizontalStretch="0" name="Условно-обязательные атрибуты" showLabel="1" type="Tab" verticalStretch="0" visibilityExpression="" visibilityExpressionEnabled="0">
      <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont bold="0" description="DejaVu Sans,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
      </labelStyle>
      <attributeEditorField horizontalStretch="0" index="9" name="Easement" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="0,0,0,255,rgb:0,0,0,1" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont bold="1" description="DejaVu Sans,10,-1,5,700,0,0,0,0,0,0,0,0,0,0,1" italic="0" strikethrough="0" style="" underline="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field editable="0" name="Area"/>
    <field editable="1" name="Class"/>
    <field editable="1" name="Easement"/>
    <field editable="1" name="FormingType"/>
    <field editable="0" name="Guid"/>
    <field editable="1" name="Location"/>
    <field editable="1" name="NominalNum"/>
    <field editable="1" name="Note"/>
    <field editable="1" name="PermittedUseType"/>
    <field editable="1" name="Status"/>
    <field editable="1" name="fid"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="Area"/>
    <field labelOnTop="1" name="Class"/>
    <field labelOnTop="1" name="Easement"/>
    <field labelOnTop="1" name="FormingType"/>
    <field labelOnTop="1" name="Guid"/>
    <field labelOnTop="1" name="Location"/>
    <field labelOnTop="1" name="NominalNum"/>
    <field labelOnTop="1" name="Note"/>
    <field labelOnTop="1" name="PermittedUseType"/>
    <field labelOnTop="1" name="Status"/>
    <field labelOnTop="0" name="fid"/>
  </labelOnTop>
  <reuseLastValuePolicy>
    <field name="Area" reuseLastValuePolicy="NotAllowed"/>
    <field name="Class" reuseLastValuePolicy="NotAllowed"/>
    <field name="Easement" reuseLastValuePolicy="NotAllowed"/>
    <field name="FormingType" reuseLastValuePolicy="NotAllowed"/>
    <field name="Guid" reuseLastValuePolicy="NotAllowed"/>
    <field name="Location" reuseLastValuePolicy="NotAllowed"/>
    <field name="NominalNum" reuseLastValuePolicy="NotAllowed"/>
    <field name="Note" reuseLastValuePolicy="NotAllowed"/>
    <field name="PermittedUseType" reuseLastValuePolicy="NotAllowed"/>
    <field name="Status" reuseLastValuePolicy="NotAllowed"/>
    <field name="fid" reuseLastValuePolicy="NotAllowed"/>
  </reuseLastValuePolicy>
  <dataDefinedFieldProperties/>
  <widgets/>
  <layerGeometryType>2</layerGeometryType>
</qgis>
