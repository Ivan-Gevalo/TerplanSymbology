<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis styleCategories="Symbology|Labeling|Fields|Forms|Actions" version="3.28.15-Firenze" labelsEnabled="1">
  <renderer-v2 referencescale="-1" forceraster="0" type="RuleRenderer" symbollevels="0" enableorderby="0">
    <rules key="{84f35168-029a-4725-80e5-b056ba9ec5d1}">
      <rule symbol="0" label="Границы существующих (сохраняемых) земельных участков" key="{1863594e-26c3-4bbb-a80c-38909c26fe33}" filter="&quot;Class&quot; = '7F.1'"/>
      <rule symbol="1" label="Границы земельных участков, предполагаемых к изъятию для государственных или муниципальных нужд" key="{71c600d7-93fd-450f-a6cd-438439ff2ea5}" filter="&quot;Class&quot; = '7F.2'"/>
      <rule symbol="2" label="Границы изменяемых земельных участков" key="{4f5f3490-2d6c-4575-aa21-fc2034bb302e}" filter="&quot;Class&quot; = '7F.3'"/>
      <rule symbol="3" label="Границы образуемых земельных участков" key="{f9b85c01-c5bf-4537-8f2e-8f3ed1f965c2}" filter="&quot;Class&quot; = '7F.4'"/>
      <rule symbol="4" label="Границы образуемых земельных участков, которые после образования будут относиться к имуществу общего пользования" key="{8877a3cc-0af0-426d-a86d-bce3b23a32be}" filter="&quot;Class&quot; = '7F.5'"/>
      <rule symbol="5" label="Границы образуемых земельных участков, которые после образования будут относиться к территориям общего пользования" key="{61b230da-e221-4f75-9a6a-fced8469afd5}" filter="&quot;Class&quot; = '7F.6'"/>
      <rule symbol="6" label="Границы образуемых земельных участков, предполагаемых к изъятию для государственных или муниципальных нужд" key="{5393f9a3-b05d-4b6a-b2cf-5dde8335ed5a}" filter="&quot;Class&quot; = '7F.7'"/>
    </rules>
    <symbols>
      <symbol name="0" alpha="1" frame_rate="10" type="fill" force_rhr="0" is_animated="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="255,230,129,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="1" alpha="1" frame_rate="10" type="fill" force_rhr="0" is_animated="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="255,129,139,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="2" alpha="1" frame_rate="10" type="fill" force_rhr="0" is_animated="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="129,255,146,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="3" alpha="1" frame_rate="10" type="fill" force_rhr="0" is_animated="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="255,163,253,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="4" alpha="1" frame_rate="10" type="fill" force_rhr="0" is_animated="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="255,163,253,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer pass="0" locked="0" enabled="1" class="LinePatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="clip_mode" value="during_render" type="QString"/>
            <Option name="color" value="0,0,255,255" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="distance" value="3" type="QString"/>
            <Option name="distance_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_unit" value="MM" type="QString"/>
            <Option name="line_width" value="0.26" type="QString"/>
            <Option name="line_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol name="@4@1" alpha="1" frame_rate="10" type="line" force_rhr="0" is_animated="0" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" locked="0" enabled="1" class="SimpleLine">
              <Option type="Map">
                <Option name="align_dash_pattern" value="0" type="QString"/>
                <Option name="capstyle" value="flat" type="QString"/>
                <Option name="customdash" value="5;2" type="QString"/>
                <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="customdash_unit" value="MM" type="QString"/>
                <Option name="dash_pattern_offset" value="0" type="QString"/>
                <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
                <Option name="draw_inside_polygon" value="0" type="QString"/>
                <Option name="joinstyle" value="miter" type="QString"/>
                <Option name="line_color" value="3,182,0,255" type="QString"/>
                <Option name="line_style" value="solid" type="QString"/>
                <Option name="line_width" value="0.2" type="QString"/>
                <Option name="line_width_unit" value="MM" type="QString"/>
                <Option name="offset" value="0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="ring_filter" value="0" type="QString"/>
                <Option name="trim_distance_end" value="0" type="QString"/>
                <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="trim_distance_end_unit" value="MM" type="QString"/>
                <Option name="trim_distance_start" value="0" type="QString"/>
                <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="trim_distance_start_unit" value="MM" type="QString"/>
                <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
                <Option name="use_custom_dash" value="0" type="QString"/>
                <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol name="5" alpha="1" frame_rate="10" type="fill" force_rhr="0" is_animated="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="255,163,253,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer pass="0" locked="0" enabled="1" class="LinePatternFill">
          <Option type="Map">
            <Option name="angle" value="90" type="QString"/>
            <Option name="clip_mode" value="during_render" type="QString"/>
            <Option name="color" value="0,0,255,255" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="distance" value="3" type="QString"/>
            <Option name="distance_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_unit" value="MM" type="QString"/>
            <Option name="line_width" value="0.26" type="QString"/>
            <Option name="line_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol name="@5@1" alpha="1" frame_rate="10" type="line" force_rhr="0" is_animated="0" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" locked="0" enabled="1" class="SimpleLine">
              <Option type="Map">
                <Option name="align_dash_pattern" value="0" type="QString"/>
                <Option name="capstyle" value="flat" type="QString"/>
                <Option name="customdash" value="5;2" type="QString"/>
                <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="customdash_unit" value="MM" type="QString"/>
                <Option name="dash_pattern_offset" value="0" type="QString"/>
                <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
                <Option name="draw_inside_polygon" value="0" type="QString"/>
                <Option name="joinstyle" value="miter" type="QString"/>
                <Option name="line_color" value="3,182,0,255" type="QString"/>
                <Option name="line_style" value="solid" type="QString"/>
                <Option name="line_width" value="0.2" type="QString"/>
                <Option name="line_width_unit" value="MM" type="QString"/>
                <Option name="offset" value="0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="ring_filter" value="0" type="QString"/>
                <Option name="trim_distance_end" value="0" type="QString"/>
                <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="trim_distance_end_unit" value="MM" type="QString"/>
                <Option name="trim_distance_start" value="0" type="QString"/>
                <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="trim_distance_start_unit" value="MM" type="QString"/>
                <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
                <Option name="use_custom_dash" value="0" type="QString"/>
                <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol name="6" alpha="1" frame_rate="10" type="fill" force_rhr="0" is_animated="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" locked="0" enabled="1" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="254,28,58,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fieldName="&quot;NominalNum&quot; || '\nS=' || round(&quot;Area&quot;, 0) || ' кв. м'" fontWeight="50" blendMode="0" fontSize="11" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" useSubstitutions="0" forcedBold="0" allowHtml="0" fontWordSpacing="0" multilineHeightUnit="Percentage" fontItalic="0" legendString="Aa" fontSizeUnit="Point" fontKerning="1" fontLetterSpacing="0" textColor="194,0,123,255" namedStyle="Regular" forcedItalic="0" multilineHeight="1" textOrientation="horizontal" isExpression="1" previewBkgrdColor="255,255,255,255" fontFamily="Open Sans" capitalization="0" fontStrikeout="0" textOpacity="1">
        <families/>
        <text-buffer bufferBlendMode="0" bufferDraw="0" bufferNoFill="1" bufferColor="250,250,250,255" bufferSizeUnits="MM" bufferSize="1" bufferJoinStyle="128" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1"/>
        <text-mask maskType="0" maskSize="0" maskSizeUnits="MM" maskEnabled="0" maskOpacity="1" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskJoinStyle="128"/>
        <background shapeDraw="1" shapeRotationType="0" shapeBorderWidthUnit="Point" shapeSVGFile="" shapeOpacity="1" shapeType="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeSizeType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="Point" shapeRadiiY="0" shapeSizeUnit="Point" shapeSizeX="1" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeOffsetX="0" shapeOffsetY="0" shapeBorderWidth="0" shapeSizeY="0.29999999999999999" shapeBorderColor="128,128,128,255" shapeRadiiUnit="Point" shapeRotation="0" shapeFillColor="255,255,255,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0">
          <symbol name="markerSymbol" alpha="1" frame_rate="10" type="marker" force_rhr="0" is_animated="0" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" locked="0" enabled="1" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="125,139,143,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="solid" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol name="fillSymbol" alpha="1" frame_rate="10" type="fill" force_rhr="0" is_animated="0" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" locked="0" enabled="1" class="SimpleFill">
              <Option type="Map">
                <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="255,255,255,255" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="128,128,128,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_unit" value="Point" type="QString"/>
                <Option name="style" value="solid" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowRadius="1.5" shadowRadiusUnit="MM" shadowScale="100" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowBlendMode="6" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowOpacity="0.69999999999999996" shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusAlphaOnly="0" shadowDraw="0" shadowUnder="0" shadowOffsetGlobal="1" shadowColor="0,0,0,255"/>
        <dd_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format autoWrapLength="0" reverseDirectionSymbol="0" formatNumbers="0" rightDirectionSymbol=">" leftDirectionSymbol="&lt;" addDirectionSymbol="0" wrapChar="" placeDirectionSymbol="0" multilineAlign="3" useMaxLineLengthForAutoWrap="1" decimals="3" plussign="0"/>
      <placement geometryGeneratorType="PointGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" preserveRotation="1" rotationAngle="0" offsetType="0" fitInPolygonOnly="1" overlapHandling="PreventOverlap" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistance="0" centroidWhole="0" centroidInside="0" xOffset="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" overrunDistance="0" repeatDistanceUnits="MM" lineAnchorTextPoint="FollowPlacement" placementFlags="10" geometryGenerator="" distUnits="MM" overrunDistanceUnit="MM" allowDegraded="0" polygonPlacementFlags="2" layerType="PolygonGeometry" placement="1" geometryGeneratorEnabled="0" priority="5" rotationUnit="AngleDegrees" offsetUnits="MM" quadOffset="4" yOffset="0" maxCurvedCharAngleOut="-25" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" lineAnchorType="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
      <rendering unplacedVisibility="0" obstacleFactor="1" drawLabels="1" labelPerPart="1" obstacleType="1" obstacle="1" maxNumLabels="2000" mergeLines="0" limitNumLabels="0" scaleMin="0" fontLimitPixelSize="0" scaleVisibility="0" minFeatureSize="0" scaleMax="0" fontMaxPixelSize="10000" upsidedownLabels="0" fontMinPixelSize="3" zIndex="0"/>
      <dd_properties>
        <Option type="Map">
          <Option name="name" value="" type="QString"/>
          <Option name="properties"/>
          <Option name="type" value="collection" type="QString"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
          <Option name="blendMode" value="0" type="int"/>
          <Option name="ddProperties" type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
          <Option name="drawToAllParts" value="false" type="bool"/>
          <Option name="enabled" value="0" type="QString"/>
          <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
          <Option name="lineSymbol" value="&lt;symbol name=&quot;symbol&quot; alpha=&quot;1&quot; frame_rate=&quot;10&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; is_animated=&quot;0&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer pass=&quot;0&quot; locked=&quot;0&quot; enabled=&quot;1&quot; class=&quot;SimpleLine&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
          <Option name="minLength" value="0" type="double"/>
          <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
          <Option name="minLengthUnit" value="MM" type="QString"/>
          <Option name="offsetFromAnchor" value="0" type="double"/>
          <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
          <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
          <Option name="offsetFromLabel" value="0" type="double"/>
          <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
          <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="Guid" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Class" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Границы существующих (сохраняемых) земельных участков" value="7F.1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Границы земельных участков, предполагаемых к изъятию для государственных или муниципальных нужд" value="7F.2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Границы изменяемых земельных участков" value="7F.3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Границы образуемых земельных участков" value="7F.4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Границы образуемых земельных участков, которые после образования будут относиться к имуществу общего пользования" value="7F.5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Границы образуемых земельных участков, которые после образования будут относиться к территориям общего пользования" value="7F.6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Границы образуемых земельных участков, предполагаемых к изъятию для государственных или муниципальных нужд" value="7F.7" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Status" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий" value="7B.1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый" value="7B.2" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FormingType" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Образование земельных участков из земель или земельных участков, находящихся в государственной или муниципальной собственности" value="7G.1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Раздел земельного участка" value="7G.2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объединение земельных участков" value="7G.3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Выдел земельного участка" value="7G.4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Перераспределение земельных участков" value="7G.5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NominalNum" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Location" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="PermittedUseType" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Area" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Easement" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Note" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="Идентификатор объекта" index="0" field="Guid"/>
    <alias name="Вид границы образуемого (изменяемого) земельного участка" index="1" field="Class"/>
    <alias name="Статус объекта" index="2" field="Status"/>
    <alias name="Способ образования земельного участка" index="3" field="FormingType"/>
    <alias name="Условный или кадастровый номер образуемого (изменяемого) земельного участка" index="4" field="NominalNum"/>
    <alias name="Местоположение (адрес или при отсутствии адреса иное описание местоположения)" index="5" field="Location"/>
    <alias name="Вид разрешенного использования земельного участка и объекта капитального строительства" index="6" field="PermittedUseType"/>
    <alias name="Площадь общая, кв. м" index="7" field="Area"/>
    <alias name="Информация о наличии публичного сервитута" index="8" field="Easement"/>
    <alias name="Примечание" index="9" field="Note"/>
  </aliases>
  <defaults>
    <default expression="uuid('WithoutBraces')" applyOnUpdate="1" field="Guid"/>
    <default expression="'7F.1'" applyOnUpdate="0" field="Class"/>
    <default expression="'7B.1'" applyOnUpdate="0" field="Status"/>
    <default expression="" applyOnUpdate="0" field="FormingType"/>
    <default expression="''" applyOnUpdate="0" field="NominalNum"/>
    <default expression="''" applyOnUpdate="0" field="Location"/>
    <default expression="''" applyOnUpdate="0" field="PermittedUseType"/>
    <default expression="round(area($geometry), 2)" applyOnUpdate="1" field="Area"/>
    <default expression="''" applyOnUpdate="0" field="Easement"/>
    <default expression="''" applyOnUpdate="0" field="Note"/>
  </defaults>
  <constraints>
    <constraint unique_strength="1" notnull_strength="1" constraints="3" exp_strength="0" field="Guid"/>
    <constraint unique_strength="0" notnull_strength="1" constraints="5" exp_strength="1" field="Class"/>
    <constraint unique_strength="0" notnull_strength="1" constraints="5" exp_strength="1" field="Status"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="FormingType"/>
    <constraint unique_strength="0" notnull_strength="1" constraints="5" exp_strength="1" field="NominalNum"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="Location"/>
    <constraint unique_strength="0" notnull_strength="1" constraints="5" exp_strength="1" field="PermittedUseType"/>
    <constraint unique_strength="0" notnull_strength="1" constraints="1" exp_strength="0" field="Area"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="Easement"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="Note"/>
  </constraints>
  <constraintExpressions>
    <constraint field="Guid" desc="" exp=""/>
    <constraint field="Class" desc="Поле &quot;Вид границы образуемого (изменяемого) земельного участка&quot; должно принимать одно из значений справочника &quot;Виды границы образуемого (изменяемого) земельного участка&quot;" exp="&quot;Class&quot; IN ('7F.1', '7F.2', '7F.3', '7F.4', '7F.5', '7F.6', '7F.7')"/>
    <constraint field="Status" desc="Поле &quot;Статус объекта&quot; должно принимать одно из значений справочника &quot;Статусы объекта&quot;" exp="&quot;Status&quot; IN ('7B.1', '7B.2')"/>
    <constraint field="FormingType" desc="" exp=""/>
    <constraint field="NominalNum" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NominalNum&quot;) > 0"/>
    <constraint field="Location" desc="" exp=""/>
    <constraint field="PermittedUseType" desc="Минимальная длина строки - 1 символ" exp="length(&quot;PermittedUseType&quot;) > 0"/>
    <constraint field="Area" desc="" exp=""/>
    <constraint field="Easement" desc="" exp=""/>
    <constraint field="Note" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
    <actionsetting shortTitle="Сформировать электронный документ" action="import re, uuid&#xa;&#xa;from PyQt5 import QtCore, QtWidgets&#xa;from PyQt5.QtWidgets import QDialog, QLabel, QTextEdit, QLineEdit, QDoubleSpinBox, QComboBox, QCheckBox, QPushButton, QFileDialog, QTabWidget, QFrame, QRadioButton&#xa;from PyQt5.QtCore import QSize&#xa;from PyQt5.QtGui import QFont, QTextCursor, QCursor&#xa;from PyQt5.QtXml import QDomDocument&#xa;from qgis.core import QgsProject, QgsVectorLayer, QgsMapLayerProxyModel&#xa;from qgis.gui import QgsFileWidget, QgsMapLayerComboBox&#xa;&#xa;POLYGON_GEOMETRY = 2&#xa;&#xa;ALLOWED_USE_CODES = (&quot;214001000000&quot;, &quot;214001001000&quot;, &quot;214001001001&quot;, &quot;214001001002&quot;, &quot;214001001003&quot;, &quot;214001001004&quot;, &quot;214001001005&quot;, &quot;214001001006&quot;, &quot;214001002000&quot;, &quot;214001002001&quot;, &quot;214001002002&quot;, &quot;214001002003&quot;, &quot;214001002004&quot;, &quot;214001003000&quot;, &quot;214001004000&quot;, &quot;214001005000&quot;, &quot;214001006000&quot;, &quot;214001007000&quot;, &quot;214001008000&quot;, &quot;214001009000&quot;, &quot;214001010000&quot;, &quot;214001011000&quot;, &quot;214002000000&quot;, &quot;214002001000&quot;, &quot;214002001001&quot;, &quot;214002002000&quot;, &quot;214002003000&quot;, &quot;214002004000&quot;, &quot;214002005000&quot;, &quot;214002006000&quot;, &quot;214002007000&quot;, &quot;214002007001&quot;, &quot;214002007002&quot;, &quot;214003000000&quot;, &quot;214003001000&quot;, &quot;214003001001&quot;, &quot;214003001002&quot;, &quot;214003002000&quot;, &quot;214003002001&quot;, &quot;214003002002&quot;, &quot;214003002003&quot;, &quot;214003002004&quot;, &quot;214003003000&quot;, &quot;214003004000&quot;, &quot;214003004001&quot;, &quot;214003004002&quot;, &quot;214003004003&quot;, &quot;214003005000&quot;, &quot;214003005001&quot;, &quot;214003005002&quot;, &quot;214003006000&quot;, &quot;214003006001&quot;, &quot;214003006002&quot;, &quot;214003006003&quot;, &quot;214003007000&quot;, &quot;214003007001&quot;, &quot;214003007002&quot;, &quot;214003008000&quot;, &quot;214003008001&quot;, &quot;214003008002&quot;, &quot;214003009000&quot;, &quot;214003009001&quot;, &quot;214003009002&quot;, &quot;214003009003&quot;, &quot;214003010000&quot;, &quot;214003010001&quot;, &quot;214003010002&quot;, &quot;214004000000&quot;, &quot;214004001000&quot;, &quot;214004002000&quot;, &quot;214004003000&quot;, &quot;214004004000&quot;, &quot;214004005000&quot;, &quot;214004006000&quot;, &quot;214004007000&quot;, &quot;214004008000&quot;, &quot;214004008001&quot;, &quot;214004008002&quot;, &quot;214004008003&quot;, &quot;214004009000&quot;, &quot;214004009001&quot;, &quot;214004009111&quot;, &quot;214004009112&quot;, &quot;214004009113&quot;, &quot;214004009114&quot;, &quot;214004009002&quot;, &quot;214004010000&quot;, &quot;214005000000&quot;, &quot;214005001000&quot;, &quot;214005001001&quot;, &quot;214005001002&quot;, &quot;214005001003&quot;, &quot;214005001004&quot;, &quot;214005001005&quot;, &quot;214005001006&quot;, &quot;214005001007&quot;, &quot;214005002000&quot;, &quot;214005002001&quot;, &quot;214005003000&quot;, &quot;214005004000&quot;, &quot;214005005000&quot;, &quot;214006000000&quot;, &quot;214006001000&quot;, &quot;214006002000&quot;, &quot;214006002001&quot;, &quot;214006003000&quot;, &quot;214006003001&quot;, &quot;214006003002&quot;, &quot;214006003003&quot;, &quot;214006003004&quot;, &quot;214006004000&quot;, &quot;214006005000&quot;, &quot;214006006000&quot;, &quot;214006007000&quot;, &quot;214006007001&quot;, &quot;214006008000&quot;, &quot;214006009000&quot;, &quot;214006009001&quot;, &quot;214006011000&quot;, &quot;214006012000&quot;, &quot;214007000000&quot;, &quot;214008000000&quot;, &quot;214008001000&quot;, &quot;214008001001&quot;, &quot;214008001002&quot;, &quot;214008002000&quot;, &quot;214008002001&quot;, &quot;214008002002&quot;, &quot;214008002003&quot;, &quot;214008003000&quot;, &quot;214008004000&quot;, &quot;214008005000&quot;, &quot;214008006000&quot;, &quot;214009000000&quot;, &quot;214010000000&quot;, &quot;214011000000&quot;, &quot;214012000000&quot;, &quot;214013000000&quot;, &quot;214014000000&quot;, &quot;214015000000&quot;, &quot;214015001000&quot;, &quot;214016000000&quot;, &quot;214016001000&quot;, &quot;214017000000&quot;, &quot;214018000000&quot;, &quot;214018001000&quot;, &quot;214018002000&quot;, &quot;214018003000&quot;, &quot;214018004000&quot;, &quot;214019000000&quot;, &quot;214020000000&quot;, &quot;214021000000&quot;, &quot;214022000000&quot;, &quot;214023000000&quot;, &quot;214023001000&quot;, &quot;214023002000&quot;, &quot;214024000000&quot;, &quot;214025000000&quot;, &quot;214026000000&quot;, &quot;214027000000&quot;, &quot;214027001000&quot;, &quot;214027002000&quot;, &quot;214028000000&quot;, &quot;214099000000&quot;)&#xa;&#xa;ALLOWED_USE_TEXT = (&quot;сельскохозяйственное использование&quot;, &quot;растениеводство&quot;, &quot;выращивание зерновых и иных сельскохозяйственных культур&quot;, &quot;овощеводство&quot;, &quot;выращивание тонизирующих, лекарственных, цветочных культур&quot;, &quot;садоводство&quot;, &quot;выращивание льна и конопли&quot;, &quot;виноградарство&quot;, &quot;животноводство&quot;, &quot;скотоводство&quot;, &quot;звероводство&quot;, &quot;птицеводство&quot;, &quot;свиноводство&quot;, &quot;пчеловодство&quot;, &quot;рыбоводство&quot;, &quot;научное обеспечение сельского хозяйства&quot;, &quot;хранение и переработка сельскохозяйственной продукции&quot;, &quot;ведение личного подсобного хозяйства на полевых участках&quot;, &quot;питомники&quot;, &quot;обеспечение сельскохозяйственного производства&quot;, &quot;сенокошение&quot;, &quot;выпас сельскохозяйственных животных&quot;, &quot;жилая застройка&quot;, &quot;для индивидуального жилищного строительства&quot;, &quot;малоэтажная многоквартирная жилая застройка&quot;, &quot;для ведения личного подсобного хозяйства (приусадебный земельный участок)&quot;, &quot;блокированная жилая застройка&quot;, &quot;передвижное жилье&quot;, &quot;среднеэтажная жилая застройка&quot;, &quot;многоэтажная жилая застройка (высотная застройка)&quot;, &quot;обслуживание жилой застройки&quot;, &quot;хранение автотранспорта&quot;, &quot;размещение гаражей для собственных нужд&quot;, &quot;общественное использование объектов капитального строительства&quot;, &quot;коммунальное обслуживание&quot;, &quot;предоставление коммунальных услуг&quot;, &quot;административные здания организаций, обеспечивающих предоставление коммунальных услуг&quot;, &quot;социальное обслуживание&quot;, &quot;дома социального обслуживания&quot;, &quot;оказание социальной помощи населению&quot;, &quot;оказание услуг связи&quot;, &quot;общежития&quot;, &quot;бытовое обслуживание&quot;, &quot;здравоохранение&quot;, &quot;амбулаторно-поликлиническое обслуживание&quot;, &quot;стационарное медицинское обслуживание&quot;, &quot;медицинские организации особого назначения&quot;, &quot;образование и просвещение&quot;, &quot;дошкольное, начальное и среднее общее образование&quot;, &quot;среднее и высшее профессиональное образование&quot;, &quot;культурное развитие&quot;, &quot;объекты культурно-досуговой деятельности&quot;, &quot;парки культуры и отдыха&quot;, &quot;цирки и зверинцы&quot;, &quot;религиозное использование&quot;, &quot;осуществление религиозных обрядов&quot;, &quot;религиозное управление и образование&quot;, &quot;общественное управление&quot;, &quot;государственное управление&quot;, &quot;представительская деятельность&quot;, &quot;обеспечение научной деятельности&quot;, &quot;обеспечение деятельности в области гидрометеорологии и смежных с ней областях&quot;, &quot;проведение научных исследований&quot;, &quot;проведение научных испытаний&quot;, &quot;ветеринарное обслуживание&quot;, &quot;амбулаторное ветеринарное обслуживание&quot;, &quot;приюты для животных&quot;, &quot;предпринимательство&quot;, &quot;деловое управление&quot;, &quot;объекты торговли (торговые центры, торгово-развлекательные центры (комплексы)&quot;, &quot;рынки&quot;, &quot;магазины&quot;, &quot;банковская и страховая деятельность&quot;, &quot;общественное питание&quot;, &quot;гостиничное обслуживание&quot;, &quot;развлечение&quot;, &quot;развлекательные мероприятия&quot;, &quot;проведение азартных игр&quot;, &quot;проведение азартных игр в игорных зонах&quot;, &quot;служебные гаражи&quot;, &quot;объекты дорожного сервиса&quot;, &quot;заправка транспортных средств&quot;, &quot;обеспечение дорожного отдыха&quot;, &quot;автомобильные мойки&quot;, &quot;ремонт автомобилей&quot;, &quot;стоянка транспортных средств&quot;, &quot;выставочно-ярмарочная деятельность&quot;, &quot;отдых (рекреация)&quot;, &quot;спорт&quot;, &quot;обеспечение спортивно-зрелищных мероприятий&quot;, &quot;обеспечение занятий спортом в помещениях&quot;, &quot;площадки для занятий спортом&quot;, &quot;оборудованные площадки для занятий спортом&quot;, &quot;водный спорт&quot;, &quot;авиационный спорт&quot;, &quot;спортивные базы&quot;, &quot;природно-познавательный туризм&quot;, &quot;туристическое обслуживание&quot;, &quot;охота и рыбалка&quot;, &quot;причалы для маломерных судов&quot;, &quot;поля для гольфа или конных прогулок&quot;, &quot;производственная деятельность&quot;, &quot;недропользование&quot;, &quot;тяжелая промышленность&quot;, &quot;автомобилестроительная промышленность&quot;, &quot;легкая промышленность&quot;, &quot;фармацевтическая промышленность&quot;, &quot;фарфоро-фаянсовая промышленность&quot;, &quot;электронная промышленность&quot;, &quot;ювелирная промышленность&quot;, &quot;пищевая промышленность&quot;, &quot;нефтехимическая промышленность&quot;, &quot;строительная промышленность&quot;, &quot;энергетика&quot;, &quot;атомная энергетика&quot;, &quot;связь&quot;, &quot;склад&quot;, &quot;складские площадки&quot;, &quot;целлюлозно-бумажная промышленность&quot;, &quot;научно-производственная деятельность&quot;, &quot;обеспечение космической деятельности&quot;, &quot;транспорт&quot;, &quot;железнодорожный транспорт&quot;, &quot;железнодорожные пути&quot;, &quot;обслуживание железнодорожных перевозок&quot;, &quot;автомобильный транспорт&quot;, &quot;размещение автомобильных дорог&quot;, &quot;обслуживание перевозок пассажиров&quot;, &quot;стоянки транспорта общего пользования&quot;, &quot;водный транспорт&quot;, &quot;воздушный транспорт&quot;, &quot;трубопроводный транспорт&quot;, &quot;внеуличный транспорт&quot;, &quot;обеспечение обороны и безопасности&quot;, &quot;обеспечение вооруженных сил&quot;, &quot;охрана государственной границы российской федерации&quot;, &quot;обеспечение внутреннего правопорядка&quot;, &quot;обеспечение деятельности по исполнению наказаний&quot;, &quot;деятельность по особой охране и изучению природы&quot;, &quot;охрана природных территорий&quot;, &quot;сохранение и репродукция редких и (или) находящихся под угрозой исчезновения видов животных&quot;, &quot;курортная деятельность&quot;, &quot;санаторная деятельность&quot;, &quot;историко-культурная деятельность&quot;, &quot;использование лесов&quot;, &quot;заготовка древесины&quot;, &quot;лесные плантации&quot;, &quot;заготовка лесных ресурсов&quot;, &quot;резервные леса&quot;, &quot;водные объекты&quot;, &quot;общее пользование водными объектами&quot;, &quot;специальное пользование водными объектами&quot;, &quot;гидротехнические сооружения&quot;, &quot;земельные участки (территории) общего пользования&quot;, &quot;улично-дорожная сеть&quot;, &quot;благоустройство территории&quot;, &quot;ритуальная деятельность&quot;, &quot;специальная деятельность&quot;, &quot;запас&quot;, &quot;земельные участки общего назначения&quot;, &quot;ведение огородничества&quot;, &quot;ведение садоводства&quot;, &quot;земельные участки, входящие в состав общего имущества собственников индивидуальных жилых домов в малоэтажном жилом комплексе&quot;, &quot;сведения отсутствуют&quot;)&#xa;&#xa;def isLayerValid():&#xa;    if layer.featureCount() == 0:&#xa;        QtWidgets.QMessageBox.critical(None, &quot;Внимание!&quot;, &quot;Слой не содержит объектов. Операция прервана.&quot;)&#xa;        return False&#xa;        &#xa;    return True&#xa;&#xa;def limitNameObj():&#xa;    maxLimit = 1000&#xa;    textContent = nameObj.toPlainText()&#xa;&#xa;    if len(textContent) > maxLimit:&#xa;        nameObj.blockSignals(True)&#xa;        nameObj.setPlainText(textContent[:maxLimit])&#xa;            &#xa;        cursor = nameObj.textCursor()&#xa;        &#xa;        cursor.movePosition(QTextCursor.MoveOperation.End)&#xa;        nameObj.setTextCursor(cursor)&#xa;        nameObj.blockSignals(False)&#xa;&#xa;def validateAllInputs():&#xa;    cadNumPattern = re.compile(r&quot;^\d{1,2}:\d{1,2}:(\d{1}|\d{6,7})$&quot;)&#xa;    skCodePattern = re.compile(r&quot;^\d{2}\.\d{1,2}$&quot;)&#xa;&#xa;    if len(nameObj.toPlainText()) == 0:&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;Поле с наименованием проекта межевания территории не может быть пустым.&quot;)&#xa;        return False&#xa;&#xa;    if not re.match(cadNumPattern, cadNum.text()):&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;Указано некорректное значение кадастрового номера квартала.&quot;)&#xa;        return False&#xa;&#xa;    if not re.match(skCodePattern, skCode.text()):&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;Указан некорректный код системы координат.&quot;)&#xa;        return False&#xa;    &#xa;    return True&#xa;&#xa;def validateFeatures(features):&#xa;    validFeatures = []&#xa;&#xa;    for feature in features:&#xa;        if feature.attribute(&quot;Class&quot;) in (&quot;7F.4&quot;, &quot;7F.5&quot;, &quot;7F.6&quot;, &quot;7F.7&quot;) and not feature.geometry().isEmpty() and len(feature.attribute(&quot;NominalNum&quot;)) > 0:&#xa;            validFeatures.append(feature)&#xa;&#xa;    return validFeatures&#xa;&#xa;def projectLayerClcked():&#xa;    fileSelector.setEnabled(False)&#xa;    pLayers.setEnabled(True)&#xa;&#xa;def externalFileClicked():&#xa;    pLayers.setEnabled(False)&#xa;    fileSelector.setEnabled(True)&#xa;&#xa;def noBordersClicked():&#xa;    pLayers.setEnabled(False)&#xa;    fileSelector.setEnabled(False)&#xa;&#xa;def loadMIFLayer(filePath):&#xa;    boundsLayer = QgsVectorLayer(filePath, &quot;layer&quot;, &quot;ogr&quot;)&#xa;&#xa;    if boundsLayer.isValid() and boundsLayer.geometryType() == POLYGON_GEOMETRY:&#xa;        return boundsLayer&#xa;    &#xa;    return None&#xa;&#xa;def buildSpatialElement(coords, ptIdx):&#xa;    doc = QDomDocument()&#xa;&#xa;    spatialElement = doc.createElement(&quot;EnSpa2:spatial_element&quot;)&#xa;    typeUnit = doc.createElement(&quot;EnSpa2:type_unit&quot;)&#xa;    typeUnit.appendChild(doc.createTextNode(&quot;01&quot;))&#xa;    spatialElement.appendChild(typeUnit)&#xa;&#xa;    ordinates = doc.createElement(&quot;EnSpa2:ordinates&quot;)&#xa;    spatialElement.appendChild(ordinates)&#xa;&#xa;    for n, point in enumerate(coords):&#xa;        ordinate = doc.createElement(&quot;EnSpa2:ordinate&quot;)&#xa;        xCoord = doc.createElement(&quot;EnSpa2:x&quot;)&#xa;        xCoord.appendChild(doc.createTextNode(str(round(point[0], 2))))&#xa;        yCoord = doc.createElement(&quot;EnSpa2:y&quot;)&#xa;        yCoord.appendChild(doc.createTextNode(str(round(point[1], 2))))&#xa;                &#xa;        ordinate.appendChild(xCoord)&#xa;        ordinate.appendChild(yCoord)&#xa;&#xa;        ordNmb = doc.createElement(&quot;EnSpa2:ord_nmb&quot;)&#xa;        numGeopoint = doc.createElement(&quot;EnSpa2:num_geopoint&quot;)&#xa;&#xa;        if n == (len(coords) - 1):&#xa;            ordNmb.appendChild(doc.createTextNode(str(ptIdx + 1)))&#xa;            numGeopoint.appendChild(doc.createTextNode(str(ptIdx + 1)))&#xa;        else:&#xa;            ordNmb.appendChild(doc.createTextNode(str(n + 1 + ptIdx)))&#xa;            numGeopoint.appendChild(doc.createTextNode(str(n + 1 + ptIdx)))&#xa;&#xa;        ordinate.appendChild(ordNmb)&#xa;        ordinate.appendChild(numGeopoint)&#xa;                    &#xa;        geopointOpred = doc.createElement(&quot;EnSpa2:geopoint_opred&quot;)&#xa;        geopointOpred.appendChild(doc.createTextNode(geoOpredsCodes[geoOpred.currentIndex()]))&#xa;        ordinate.appendChild(geopointOpred)&#xa;&#xa;        deltaGeopoint = doc.createElement(&quot;EnSpa2:delta_geopoint&quot;)&#xa;        deltaGeopoint.appendChild(doc.createTextNode(str(delta.value())))&#xa;        ordinate.appendChild(deltaGeopoint)&#xa;        ordinates.appendChild(ordinate)&#xa;        &#xa;    return spatialElement&#xa;&#xa;def buildContours(feat, doc):&#xa;    contours = doc.createElement(&quot;EnSpa2:contours&quot;)&#xa;    geom = feat.geometry()&#xa;        &#xa;    if geom.isMultipart():&#xa;        polygons = geom.asMultiPolygon()&#xa;    else:&#xa;        polygons = [geom.asPolygon()]&#xa;&#xa;    startPtIdx = 0&#xa;&#xa;    for i, poly in enumerate(polygons):&#xa;        exterior_coords = [(p.x(), p.y()) for p in poly[0]]&#xa;        holes_coords = [[(p.x(), p.y()) for p in ring] for ring in poly[1:]]&#xa;        &#xa;        contour = doc.createElement(&quot;EnSpa2:contour&quot;)&#xa;&#xa;        if len(list(geom.constParts())) > 1:&#xa;            numPP = doc.createElement(&quot;EnSpa2:number_pp&quot;)&#xa;            numPP.appendChild(doc.createTextNode(str(i + 1)))&#xa;            contour.appendChild(numPP)&#xa;&#xa;        contours.appendChild(contour)&#xa;&#xa;        entitySpatial = doc.createElement(&quot;EnSpa2:entity_spatial&quot;)&#xa;        sCode = doc.createElement(&quot;EnSpa2:sk_code&quot;)&#xa;        sCode.appendChild(doc.createTextNode(skCode.text()))&#xa;        entitySpatial.appendChild(sCode)&#xa;        contour.appendChild(entitySpatial)&#xa;&#xa;        spatialsElements = doc.createElement(&quot;EnSpa2:spatials_elements&quot;)&#xa;        spatialsElements.appendChild(buildSpatialElement(exterior_coords, startPtIdx))&#xa;&#xa;        startPtIdx += (len(exterior_coords) - 1)&#xa;&#xa;        if len(holes_coords) > 0:&#xa;            for hole in holes_coords:&#xa;                spatialsElements.appendChild(buildSpatialElement(hole, startPtIdx))&#xa;&#xa;                startPtIdx += (len(hole) - 1)&#xa;&#xa;        entitySpatial.appendChild(spatialsElements)&#xa;&#xa;    return contours&#xa;&#xa;def buildXMLTree(id):&#xa;    if onlySelected.isChecked():&#xa;        features = validateFeatures(layer.selectedFeatures())&#xa;    else:&#xa;        features = validateFeatures(layer.getFeatures())&#xa;&#xa;    if len(features) == 0:&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;В составе слоя отсутствуют земельные участки, подлежащие записи в электронный документ.&quot;)&#xa;        window.reject()&#xa;&#xa;    xmlDocument = QDomDocument()&#xa;&#xa;    docRoot = xmlDocument.createElement(&quot;interact_entry_boundaries&quot;)&#xa;    docRoot.setAttribute(&quot;xmlns&quot;, &quot;urn://x-artefacts-rosreestr-ru/interact/interact-entry-boundaries/2.0.1&quot;)&#xa;    docRoot.setAttribute(&quot;xmlns:iBND2&quot;, &quot;urn://x-artefacts-rosreestr-ru/interact/interact-entry-boundaries/2.0.1&quot;)&#xa;    docRoot.setAttribute(&quot;xmlns:Are1&quot;, &quot;urn://x-artefacts-rosreestr-ru/commons/complex-types/area/1.0.1&quot;)&#xa;    docRoot.setAttribute(&quot;xmlns:EnSpa2&quot;, &quot;urn://x-artefacts-rosreestr-ru/commons/complex-types/entity-spatial/2.0.1&quot;)&#xa;    docRoot.setAttribute(&quot;guid&quot;, id)&#xa;    docRoot.setAttribute(&quot;version&quot;, &quot;02&quot;)&#xa;&#xa;    xmlDocument.appendChild(docRoot)&#xa;&#xa;    boundaries = xmlDocument.createElement(&quot;information_registry_boundaries&quot;)&#xa;    docRoot.appendChild(boundaries)&#xa;&#xa;    boundary = xmlDocument.createElement(&quot;information_registry_boundary&quot;)&#xa;    boundaries.appendChild(boundary)&#xa;&#xa;    typeBoundary = xmlDocument.createElement(&quot;iBND2:type_boundary&quot;)&#xa;    typeBoundary.appendChild(xmlDocument.createTextNode(&quot;17&quot;))&#xa;    boundary.appendChild(typeBoundary)&#xa;&#xa;    nameObject = xmlDocument.createElement(&quot;iBND2:name_object&quot;)&#xa;    nameObject.appendChild(xmlDocument.createTextNode(nameObj.toPlainText()))&#xa;    boundary.appendChild(nameObject)&#xa;&#xa;    allBorder = xmlDocument.createElement(&quot;iBND2:all_border_or_part_border&quot;)&#xa;    allBorder.appendChild(xmlDocument.createTextNode(&quot;1&quot;))&#xa;    boundary.appendChild(allBorder)&#xa;&#xa;    infoBoundary = xmlDocument.createElement(&quot;iBND2:information_boundary&quot;)&#xa;    boundary.appendChild(infoBoundary)&#xa;&#xa;    surveyingProject = xmlDocument.createElement(&quot;iBND2:surveying_project&quot;)&#xa;    infoBoundary.appendChild(surveyingProject)&#xa;&#xa;    sProject = xmlDocument.createElement(&quot;iBND2:establishment_surveying_project&quot;)&#xa;    surveyingProject.appendChild(sProject)&#xa;&#xa;    cadNumber = xmlDocument.createElement(&quot;iBND2:quarter_cad_number&quot;)&#xa;    cadNumber.appendChild(xmlDocument.createTextNode(cadNum.text()))&#xa;    sProject.appendChild(cadNumber)&#xa;&#xa;    formingParcels = xmlDocument.createElement(&quot;iBND2:forming_parcels&quot;)&#xa;        &#xa;    # формирование границ образуемых ЗУ&#xa;    for feature in features:&#xa;        formingParcel = xmlDocument.createElement(&quot;iBND2:forming_parcel&quot;)&#xa;        nominalNumber = xmlDocument.createElement(&quot;iBND2:nominal_number&quot;)&#xa;        nominalNumber.appendChild(xmlDocument.createTextNode(feature.attribute(&quot;NominalNum&quot;)))&#xa;        formingParcel.appendChild(nominalNumber)&#xa;        &#xa;        subtype = xmlDocument.createElement(&quot;iBND2:subtype&quot;)&#xa;        &#xa;        if len(list(feature.geometry().constParts())) > 1:&#xa;            subtype.appendChild(xmlDocument.createTextNode(&quot;05&quot;))&#xa;        else:&#xa;            subtype.appendChild(xmlDocument.createTextNode(&quot;01&quot;))&#xa;            &#xa;        formingParcel.appendChild(subtype)&#xa;            &#xa;        fArea = xmlDocument.createElement(&quot;iBND2:area&quot;)&#xa;        areaValue = xmlDocument.createElement(&quot;Are1:value&quot;)&#xa;        areaValue.appendChild(xmlDocument.createTextNode(str(round(feature.geometry().area(), 2))))&#xa;        fArea.appendChild(areaValue)&#xa;        formingParcel.appendChild(fArea)&#xa;        &#xa;        if len(feature.attribute(&quot;PermittedUseType&quot;)) > 0:&#xa;            permittedUse = xmlDocument.createElement(&quot;iBND2:permitted_use_grad_reg&quot;)&#xa;            permittedUseText = xmlDocument.createElement(&quot;iBND2:permitted_use_text&quot;)&#xa;            permittedUseText.appendChild(xmlDocument.createTextNode(feature.attribute(&quot;PermittedUseType&quot;)))&#xa;            permittedUse.appendChild(permittedUseText)&#xa;            formingParcel.appendChild(permittedUse)&#xa;&#xa;            try:&#xa;                allowedUseIndex = ALLOWED_USE_TEXT.index(feature.attribute(&quot;PermittedUseType&quot;).lower())&#xa;                permittedUseCode = xmlDocument.createElement(&quot;iBND2:land_use&quot;)&#xa;                permittedUseCode.appendChild(xmlDocument.createTextNode(ALLOWED_USE_CODES[allowedUseIndex]))&#xa;                permittedUse.appendChild(permittedUseCode)&#xa;            except (ValueError):&#xa;                pass&#xa;            &#xa;        contoursLocation = xmlDocument.createElement(&quot;iBND2:zu_contours_location&quot;)&#xa;        contoursLocation.appendChild(buildContours(feature, xmlDocument))&#xa;        formingParcel.appendChild(contoursLocation)&#xa;&#xa;        if feature.attribute(&quot;Class&quot;) in (&quot;7F.5&quot;, &quot;7F.6&quot;):&#xa;            commonUse = xmlDocument.createElement(&quot;iBND2:common_use&quot;)&#xa;            formingParcel.appendChild(commonUse)&#xa;&#xa;            if feature.attribute(&quot;Class&quot;) == &quot;7F.5&quot;:&#xa;                propertyCommonUse = xmlDocument.createElement(&quot;iBND2:property_common_use&quot;)&#xa;                propertyCommonUse.appendChild(xmlDocument.createTextNode(&quot;true&quot;))&#xa;                commonUse.appendChild(propertyCommonUse)&#xa;&#xa;            if feature.attribute(&quot;Class&quot;) == &quot;7F.6&quot;:&#xa;                territoryCommonUse = xmlDocument.createElement(&quot;iBND2:territory_common_use&quot;)&#xa;                territoryCommonUse.appendChild(xmlDocument.createTextNode(&quot;true&quot;))&#xa;                commonUse.appendChild(territoryCommonUse)&#xa;        &#xa;        formingParcels.appendChild(formingParcel)&#xa;&#xa;    sProject.appendChild(formingParcels)&#xa;&#xa;    # формирование границы территории&#xa;    bLayer = None&#xa;&#xa;    if projectLayer.isChecked():&#xa;        bLayer = pLayers.currentLayer()&#xa;&#xa;    if externalFile.isChecked():&#xa;        if len(fileSelector.filePath()) > 0:&#xa;            bLayer = loadMIFLayer(fileSelector.filePath())&#xa;&#xa;    if bLayer is not None:&#xa;        bounds = xmlDocument.createElement(&quot;iBND2:contours_location&quot;)&#xa;&#xa;        for bFeature in bLayer.getFeatures():&#xa;            bounds.appendChild(buildContours(bFeature, xmlDocument))&#xa;&#xa;        sProject.appendChild(bounds)&#xa;&#xa;    return xmlDocument&#xa;&#xa;def exportToXML():&#xa;    if validateAllInputs():&#xa;        documentId = str(uuid.uuid4())&#xa;        selectedDirectory = QFileDialog.getExistingDirectory(window, &quot;Выбор каталога для сохранения документа&quot;)&#xa;&#xa;        if selectedDirectory:&#xa;            xmlTree = buildXMLTree(documentId)&#xa;&#xa;            with open(selectedDirectory + &quot;/&quot; + &quot;interact_entry_boundaries_&quot; + documentId + &quot;.xml&quot;, &quot;w&quot;) as file:&#xa;                file.write(xmlTree.toString(4))&#xa;&#xa;            QtWidgets.QMessageBox.information(window, &quot;Операция завершена&quot;, f&quot;Электронный документ interact_entry_boundaries_{documentId}.xml сохранен.&quot;)&#xa;&#xa;            window.done(1)&#xa;&#xa;layer = QgsProject.instance().mapLayer('[%@layer_id%]')&#xa;&#xa;if isLayerValid():&#xa;    geoOpredsCodes = [&quot;692001000000&quot;, &quot;692002000000&quot;, &quot;692003000000&quot;, &quot;692004000000&quot;, &quot;692005000000&quot;, &quot;692006000000&quot;]&#xa;    geoOpredsValues = [&quot;Геодезический метод&quot;, &quot;Фотограмметрический метод&quot;, &quot;Картометрический метод&quot;, &quot;Иное описание&quot;, &quot;Метод спутниковых геодезических измерений (определений)&quot;, &quot;Аналитический метод&quot;]&#xa;&#xa;    window = QDialog()&#xa;    window.setFixedSize(QSize(700, 420))&#xa;    window.move(window.frameGeometry().center())&#xa;    window.setModal(True)&#xa;&#xa;    window.setWindowTitle(&quot;Формирование электронного документа&quot;)&#xa;&#xa;    tabs = QTabWidget(window)&#xa;&#xa;    iFrame = QFrame(tabs)&#xa;    bFrame = QFrame(tabs)&#xa;&#xa;    tabs.addTab(iFrame, &quot;Сведения о проекте межевания&quot;)&#xa;    tabs.addTab(bFrame, &quot;Сведения о границе территории&quot;)&#xa;    tabs.setCurrentIndex(0)&#xa;    tabs.resize(690, 360)&#xa;    tabs.move(5, 5)&#xa;&#xa;    # виджеты на вкладке &quot;Сведения о проекте межевания&quot;&#xa;    nameObjLabel = QLabel(&quot;Наименование проекта межевания территории&quot;, iFrame)&#xa;    nameObjLabel.setFont(QFont(&quot;&quot;, 10, QFont.Bold))&#xa;    nameObjLabel.move(10, 10)&#xa;&#xa;    nameObj = QTextEdit(iFrame)&#xa;    nameObj.textChanged.connect(limitNameObj)&#xa;    nameObj.setPlaceholderText(&quot;Максимальная длина 1000 символов&quot;)&#xa;    nameObj.resize(667, 109)&#xa;    nameObj.move(10, 35)&#xa;&#xa;    cadNumLabel = QLabel(&quot;Кадастровый номер квартала&quot;, iFrame)&#xa;    cadNumLabel.setFont(QFont(&quot;&quot;, 10, QFont.Bold))&#xa;    cadNumLabel.move(10, 162)&#xa;&#xa;    cadNum = QLineEdit(iFrame)&#xa;    cadNum.setInputMask(&quot;99:99:9999999&quot;)&#xa;    cadNum.setMaxLength(13)&#xa;    cadNum.resize(150, 25)&#xa;    cadNum.move(250, 158)&#xa;&#xa;    skCodeLabel = QLabel(&quot;Код системы координат&quot;, iFrame)&#xa;    skCodeLabel.setFont(QFont(&quot;&quot;, 10, QFont.Bold))&#xa;    skCodeLabel.move(417, 162)&#xa;&#xa;    skCode = QLineEdit(iFrame)&#xa;    skCode.setInputMask(&quot;99.99&quot;)&#xa;    skCode.setMaxLength(5)&#xa;    skCode.resize(60, 25)&#xa;    skCode.move(617, 158)&#xa;&#xa;    geoOpred = QComboBox(iFrame)&#xa;    geoOpred.addItems(geoOpredsValues)&#xa;    geoOpred.setEditable(False)&#xa;    geoOpred.setCurrentIndex(5)&#xa;    geoOpred.resize(667, 25)&#xa;    geoOpred.move(10, 200)&#xa;&#xa;    deltaLabel = QLabel(&quot;Погрешность определения координат&quot;, iFrame)&#xa;    deltaLabel.setFont(QFont(&quot;&quot;, 10, QFont.Bold))&#xa;    deltaLabel.move(10, 246)&#xa;&#xa;    delta = QDoubleSpinBox(iFrame)&#xa;    delta.setRange(0.10, 5.00)&#xa;    delta.setSingleStep(0.10)&#xa;    delta.resize(80, 25)&#xa;    delta.move(315, 240)&#xa;&#xa;    onlySelected = QCheckBox(&quot;Сохранить только выделенные объекты&quot;, iFrame)&#xa;    onlySelected.move(10, 280)&#xa;&#xa;    # виджеты на вкладке &quot;Сведения о границе территории&quot;&#xa;    fileLabel = QLabel(&quot;Источник координат&quot;, bFrame)&#xa;    fileLabel.setFont(QFont(&quot;&quot;, 10, QFont.Bold))&#xa;    fileLabel.move(10, 10)&#xa;&#xa;    projectLayer = QRadioButton(&quot;Слой из проекта&quot;, bFrame)&#xa;    projectLayer.click()&#xa;    projectLayer.clicked.connect(projectLayerClcked)&#xa;    projectLayer.move(10, 35)&#xa;&#xa;    pLayers = QgsMapLayerComboBox(bFrame)&#xa;    pLayers.setFilters(QgsMapLayerProxyModel.PolygonLayer)&#xa;    pLayers.resize(667, 25)&#xa;    pLayers.move(10, 70)&#xa;&#xa;    externalFile = QRadioButton(&quot;Внешний файл&quot;, bFrame)&#xa;    externalFile.clicked.connect(externalFileClicked)&#xa;    externalFile.move(10, 105)&#xa;&#xa;    fileSelector = QgsFileWidget(bFrame)&#xa;    fileSelector.setFilter(&quot;Файлы MapInfo MIF (*.mif)&quot;)&#xa;    fileSelector.setEnabled(False)&#xa;    fileSelector.resize(667, 27)&#xa;    fileSelector.move(10, 140)&#xa;&#xa;    noBorders = QRadioButton(&quot;Сведения о границе территории отсутствуют&quot;, bFrame)&#xa;    noBorders.clicked.connect(noBordersClicked)&#xa;    noBorders.move(10, 175)&#xa;&#xa;&#xa;    button = QPushButton(&quot;Сформировать&quot;, window)&#xa;    button.setCursor(QCursor(QtCore.Qt.PointingHandCursor))&#xa;    button.clicked.connect(exportToXML)&#xa;    button.resize(110, 25)&#xa;    button.move(580, 385)&#xa;&#xa;    if layer.selectedFeatureCount() > 0:&#xa;        onlySelected.setEnabled(True)&#xa;    else:&#xa;        onlySelected.setEnabled(False)&#xa;&#xa;    window.show()&#xa;" name="Сформировать электронный документ" type="1" id="{ee95666b-8de4-4f34-81e3-77796120b5ad}" icon="" capture="0" notificationMessage="" isEnabledOnlyWhenEditable="0">
      <actionScope id="Layer"/>
    </actionsetting>
  </attributeactions>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="0,0,0,255">
      <labelFont style="" bold="0" underline="0" italic="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer name="Обязательные атрибуты" showLabel="1" collapsedExpressionEnabled="0" groupBox="0" collapsed="0" visibilityExpressionEnabled="0" visibilityExpression="" collapsedExpression="" columnCount="1">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="0,0,0,255">
        <labelFont style="" bold="0" underline="0" italic="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField name="Guid" showLabel="1" index="0">
        <labelStyle overrideLabelFont="1" overrideLabelColor="0" labelColor="0,0,0,255">
          <labelFont style="" bold="1" underline="0" italic="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Class" showLabel="1" index="1">
        <labelStyle overrideLabelFont="1" overrideLabelColor="0" labelColor="0,0,0,255">
          <labelFont style="" bold="1" underline="0" italic="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Status" showLabel="1" index="2">
        <labelStyle overrideLabelFont="1" overrideLabelColor="0" labelColor="0,0,0,255">
          <labelFont style="" bold="1" underline="0" italic="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="NominalNum" showLabel="1" index="4">
        <labelStyle overrideLabelFont="1" overrideLabelColor="0" labelColor="0,0,0,255">
          <labelFont style="" bold="1" underline="0" italic="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="PermittedUseType" showLabel="1" index="6">
        <labelStyle overrideLabelFont="1" overrideLabelColor="0" labelColor="0,0,0,255">
          <labelFont style="" bold="1" underline="0" italic="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Area" showLabel="1" index="7">
        <labelStyle overrideLabelFont="1" overrideLabelColor="0" labelColor="0,0,0,255">
          <labelFont style="" bold="1" underline="0" italic="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer name="Необязательные атрибуты" showLabel="1" collapsedExpressionEnabled="0" groupBox="0" collapsed="0" visibilityExpressionEnabled="0" visibilityExpression="" collapsedExpression="" columnCount="1">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="0,0,0,255">
        <labelFont style="" bold="0" underline="0" italic="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField name="FormingType" showLabel="1" index="3">
        <labelStyle overrideLabelFont="1" overrideLabelColor="0" labelColor="0,0,0,255">
          <labelFont style="" bold="1" underline="0" italic="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Location" showLabel="1" index="5">
        <labelStyle overrideLabelFont="1" overrideLabelColor="0" labelColor="0,0,0,255">
          <labelFont style="" bold="1" underline="0" italic="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Note" showLabel="1" index="9">
        <labelStyle overrideLabelFont="1" overrideLabelColor="0" labelColor="0,0,0,255">
          <labelFont style="" bold="1" underline="0" italic="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer name="Условно-обязательные атрибуты" showLabel="1" collapsedExpressionEnabled="0" groupBox="0" collapsed="0" visibilityExpressionEnabled="0" visibilityExpression="" collapsedExpression="" columnCount="1">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="0,0,0,255">
        <labelFont style="" bold="0" underline="0" italic="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField name="Easement" showLabel="1" index="8">
        <labelStyle overrideLabelFont="1" overrideLabelColor="0" labelColor="0,0,0,255">
          <labelFont style="" bold="1" underline="0" italic="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="Area" editable="0"/>
    <field name="Class" editable="1"/>
    <field name="Easement" editable="1"/>
    <field name="FormingType" editable="1"/>
    <field name="Guid" editable="0"/>
    <field name="Location" editable="1"/>
    <field name="NominalNum" editable="1"/>
    <field name="Note" editable="1"/>
    <field name="PermittedUseType" editable="1"/>
    <field name="Status" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="Area" labelOnTop="1"/>
    <field name="Class" labelOnTop="1"/>
    <field name="Easement" labelOnTop="1"/>
    <field name="FormingType" labelOnTop="1"/>
    <field name="Guid" labelOnTop="1"/>
    <field name="Location" labelOnTop="1"/>
    <field name="NominalNum" labelOnTop="1"/>
    <field name="Note" labelOnTop="1"/>
    <field name="PermittedUseType" labelOnTop="1"/>
    <field name="Status" labelOnTop="1"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="Area" reuseLastValue="0"/>
    <field name="Class" reuseLastValue="0"/>
    <field name="Easement" reuseLastValue="0"/>
    <field name="FormingType" reuseLastValue="0"/>
    <field name="Guid" reuseLastValue="0"/>
    <field name="Location" reuseLastValue="0"/>
    <field name="NominalNum" reuseLastValue="0"/>
    <field name="Note" reuseLastValue="0"/>
    <field name="PermittedUseType" reuseLastValue="0"/>
    <field name="Status" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <layerGeometryType>2</layerGeometryType>
</qgis>
