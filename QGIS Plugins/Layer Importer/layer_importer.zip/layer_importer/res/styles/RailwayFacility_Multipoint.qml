<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{e724fd21-0564-4e24-950e-93a6e2f3528a}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{04e51bb7-c56d-4fe3-9f5e-cba82db2c97a}">
        <rule label="Железнодорожная станция" filter="&quot;CLASSID&quot; = '602030201'" symbol="1" key="{cc3be187-e226-475c-8845-ca34b85978ba}"/>
        <rule label="Железнодорожный вокзал" filter="&quot;CLASSID&quot; = '602030202'" symbol="2" key="{0dfeead3-4ac6-472f-be38-b776a5ea4454}"/>
        <rule label="Железнодорожное депо" filter="&quot;CLASSID&quot; = '602030203'" symbol="3" key="{b7d4783e-5feb-4af8-83c7-64bae23d25b0}"/>
        <rule label="Остановочный пассажирский железнодорожный пункт" filter="&quot;CLASSID&quot; = '602030204'" symbol="4" key="{1c952bdb-5314-40de-b3a5-eca904ea7fac}"/>
        <rule label="Иные объекты железнодорожного транспорта" filter="&quot;CLASSID&quot; = '602030205'" symbol="5" key="{f447074c-9aa4-402a-b923-5383cd40fc3c}"/>
        <rule label="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" filter="&quot;CLASSID&quot; = '602030206'" symbol="6" key="{b649b613-a6dd-4b2c-8901-ac4bf4544821}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="7" key="{1fc26565-5503-483d-91ca-db6c825f6d9c}">
        <rule label="Железнодорожная станция" filter="&quot;CLASSID&quot; = '602030201'" symbol="8" key="{60d7c797-9bae-46f4-909b-84558f314044}"/>
        <rule label="Железнодорожный вокзал" filter="&quot;CLASSID&quot; = '602030202'" symbol="9" key="{beb9e5e6-5bc4-44df-8927-4b550a786fdd}"/>
        <rule label="Железнодорожное депо" filter="&quot;CLASSID&quot; = '602030203'" symbol="10" key="{8a0a0dcb-f512-4c6c-aa26-cc36193abdfa}"/>
        <rule label="Остановочный пассажирский железнодорожный пункт" filter="&quot;CLASSID&quot; = '602030204'" symbol="11" key="{50b808c2-5686-4413-ac7d-232b9b6bcb2d}"/>
        <rule label="Иные объекты железнодорожного транспорта" filter="&quot;CLASSID&quot; = '602030205'" symbol="12" key="{f6e3e56d-7549-4b00-8a15-a45694cbbf99}"/>
        <rule label="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" filter="&quot;CLASSID&quot; = '602030206'" symbol="13" key="{1f87400e-8699-4b0e-b2db-836ea5d6d61b}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="14" key="{4616b4ee-59e0-436a-b4aa-013e49828c70}">
        <rule label="Железнодорожная станция" filter="&quot;CLASSID&quot; = '602030201'" symbol="15" key="{7550679a-8c83-4505-9e2e-6e1e19823252}"/>
        <rule label="Железнодорожный вокзал" filter="&quot;CLASSID&quot; = '602030202'" symbol="16" key="{511697e9-7e9d-4041-bfb4-7e6f3af60d02}"/>
        <rule label="Железнодорожное депо" filter="&quot;CLASSID&quot; = '602030203'" symbol="17" key="{07d3dc8e-6cd5-4a72-86c2-78c5ed407eac}"/>
        <rule label="Остановочный пассажирский железнодорожный пункт" filter="&quot;CLASSID&quot; = '602030204'" symbol="18" key="{5c6c9199-b08e-4441-bc57-64a7b7160a60}"/>
        <rule label="Иные объекты железнодорожного транспорта" filter="&quot;CLASSID&quot; = '602030205'" symbol="19" key="{4dbbcd4c-ca1d-46af-ae1f-22e65ad71ebd}"/>
        <rule label="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" filter="&quot;CLASSID&quot; = '602030206'" symbol="20" key="{2507e62b-f54f-46ea-83c0-de8bad8fb01b}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="21" key="{65a85e88-c04d-44b2-82b7-77eee13e0282}">
        <rule label="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" filter="&quot;CLASSID&quot; = '602030206'" symbol="22" key="{e51a2782-72a1-4a52-a27f-3f767878f1b7}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="23" key="{c4afcc05-76ac-408b-9425-0f09aec14226}">
        <rule label="Железнодорожная станция" filter="&quot;CLASSID&quot; = '602030201'" symbol="24" key="{6b0e6944-8360-4b31-8830-5699ad9233fc}"/>
        <rule label="Железнодорожный вокзал" filter="&quot;CLASSID&quot; = '602030202'" symbol="25" key="{79e15eaa-88f6-42d0-9d4d-702c68e01111}"/>
        <rule label="Железнодорожное депо" filter="&quot;CLASSID&quot; = '602030203'" symbol="26" key="{b374cf56-95ae-4d58-b16a-f5b7f9efc051}"/>
        <rule label="Остановочный пассажирский железнодорожный пункт" filter="&quot;CLASSID&quot; = '602030204'" symbol="27" key="{9a4c677c-d0de-4fd5-881d-5a1f3b1661e2}"/>
        <rule label="Иные объекты железнодорожного транспорта" filter="&quot;CLASSID&quot; = '602030205'" symbol="28" key="{4047fa8a-a11f-4489-8cc7-eb72a2ba194b}"/>
        <rule label="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" filter="&quot;CLASSID&quot; = '602030206'" symbol="29" key="{0cc5f5e7-0ba4-462f-870b-046b8e358211}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="30" key="{bed37723-f444-4f92-bd78-f6436cc168b9}">
        <rule label="Железнодорожная станция" filter="&quot;CLASSID&quot; = '602030201'" symbol="31" key="{d690181b-5747-4104-94fa-3f788c6d0296}"/>
        <rule label="Железнодорожный вокзал" filter="&quot;CLASSID&quot; = '602030202'" symbol="32" key="{219ae698-bc42-47f1-b025-922262c301ee}"/>
        <rule label="Железнодорожное депо" filter="&quot;CLASSID&quot; = '602030203'" symbol="33" key="{e6b26f5c-dd77-444d-9a3a-5cd40c01a0dc}"/>
        <rule label="Остановочный пассажирский железнодорожный пункт" filter="&quot;CLASSID&quot; = '602030204'" symbol="34" key="{fe158e95-ff1f-4b26-8fa9-623e4dffbda2}"/>
        <rule label="Иные объекты железнодорожного транспорта" filter="&quot;CLASSID&quot; = '602030205'" symbol="35" key="{91f51754-18bf-4d33-99ae-b1d20d2a03b2}"/>
        <rule label="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" filter="&quot;CLASSID&quot; = '602030206'" symbol="36" key="{3051b55f-41ad-4403-910a-3e431d777e63}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="37" key="{e7730587-1821-49d0-9bc5-e009a5d993e4}">
        <rule label="Железнодорожная станция" filter="&quot;CLASSID&quot; = '602030201'" symbol="38" key="{303e3bd8-0db5-4e73-bda9-b6504131dba8}"/>
        <rule label="Железнодорожный вокзал" filter="&quot;CLASSID&quot; = '602030202'" symbol="39" key="{ece2c7c1-c95f-46cd-b106-60f92b7f3040}"/>
        <rule label="Железнодорожное депо" filter="&quot;CLASSID&quot; = '602030203'" symbol="40" key="{a310e0eb-8891-4ca9-81ad-3d870e01c1c8}"/>
        <rule label="Остановочный пассажирский железнодорожный пункт" filter="&quot;CLASSID&quot; = '602030204'" symbol="41" key="{4c863599-a196-4a18-8940-bfae7dd74696}"/>
        <rule label="Иные объекты железнодорожного транспорта" filter="&quot;CLASSID&quot; = '602030205'" symbol="42" key="{dd0d633a-aa29-43d2-b7a7-478bffa9d821}"/>
        <rule label="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" filter="&quot;CLASSID&quot; = '602030206'" symbol="43" key="{1c582051-9657-41c9-99f9-27756e2ecfe9}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты регионального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 2" symbol="44" key="{3762e17c-b6ca-4122-8b03-d783b16b15cd}">
        <rule label="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" filter="&quot;CLASSID&quot; = '602030206'" symbol="45" key="{025e10b6-481d-436d-8a04-775e7b8ef6f3}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="46" key="{05ff975e-6f2a-4585-b2ce-1ef2b8ae3f27}">
        <rule label="Железнодорожная станция" filter="&quot;CLASSID&quot; = '602030201'" symbol="47" key="{8ed6a978-c081-45ff-8472-6af76be1f6da}"/>
        <rule label="Железнодорожный вокзал" filter="&quot;CLASSID&quot; = '602030202'" symbol="48" key="{da17afcc-ac8f-4da8-b93e-94285e5dcafb}"/>
        <rule label="Железнодорожное депо" filter="&quot;CLASSID&quot; = '602030203'" symbol="49" key="{a1cb49f9-0334-424e-9d13-306ee361342a}"/>
        <rule label="Остановочный пассажирский железнодорожный пункт" filter="&quot;CLASSID&quot; = '602030204'" symbol="50" key="{4eb422d4-c366-4dca-9048-0cd153f24d68}"/>
        <rule label="Иные объекты железнодорожного транспорта" filter="&quot;CLASSID&quot; = '602030205'" symbol="51" key="{16d3d926-2c32-40f2-ac0e-2a89b495bcaa}"/>
        <rule label="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" filter="&quot;CLASSID&quot; = '602030206'" symbol="52" key="{73ca00e4-93dc-40cd-867b-608f195a64f9}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="53" key="{3a66eba3-97a3-487c-b0a3-541b41dbe35a}">
        <rule label="Железнодорожная станция" filter="&quot;CLASSID&quot; = '602030201'" symbol="54" key="{31c90394-d4c6-46bf-9ec0-9db5e9a43e2d}"/>
        <rule label="Железнодорожный вокзал" filter="&quot;CLASSID&quot; = '602030202'" symbol="55" key="{ab11ec15-4c5d-4cff-81d4-c59843574995}"/>
        <rule label="Железнодорожное депо" filter="&quot;CLASSID&quot; = '602030203'" symbol="56" key="{cea6ab9a-b3b9-4eb5-8cce-16708f4afc16}"/>
        <rule label="Остановочный пассажирский железнодорожный пункт" filter="&quot;CLASSID&quot; = '602030204'" symbol="57" key="{e33abc64-4cd4-4dd6-9a0e-47fd73cbdb5d}"/>
        <rule label="Иные объекты железнодорожного транспорта" filter="&quot;CLASSID&quot; = '602030205'" symbol="58" key="{06ab44d4-4b7e-409c-aeeb-6fad28bbaf33}"/>
        <rule label="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" filter="&quot;CLASSID&quot; = '602030206'" symbol="59" key="{d67c9497-e71c-4182-b988-a63e81e62971}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="60" key="{1d672ea3-1e42-4fd3-b985-9f7486d47140}">
        <rule label="Железнодорожная станция" filter="&quot;CLASSID&quot; = '602030201'" symbol="61" key="{4f44b2f1-d127-41ae-93c8-be60086a3d81}"/>
        <rule label="Железнодорожный вокзал" filter="&quot;CLASSID&quot; = '602030202'" symbol="62" key="{62e85954-0f37-456d-a354-efff3efb6e5c}"/>
        <rule label="Железнодорожное депо" filter="&quot;CLASSID&quot; = '602030203'" symbol="63" key="{cb65488a-a1d1-4c5a-a007-bf799984a588}"/>
        <rule label="Остановочный пассажирский железнодорожный пункт" filter="&quot;CLASSID&quot; = '602030204'" symbol="64" key="{8a6a34a2-7372-4ca2-afb1-bbb0f8161fa3}"/>
        <rule label="Иные объекты железнодорожного транспорта" filter="&quot;CLASSID&quot; = '602030205'" symbol="65" key="{6532615a-cf50-4868-bffa-622622223fc7}"/>
        <rule label="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" filter="&quot;CLASSID&quot; = '602030206'" symbol="66" key="{ec782aaf-f5bb-4521-be5a-23104e9569f5}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты федерального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 1" symbol="67" key="{d6946899-97ea-4429-be0e-f9035da5d50d}">
        <rule label="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" filter="&quot;CLASSID&quot; = '602030206'" symbol="68" key="{ddf3f08c-57f1-4b11-8242-1b58f0b72b7b}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="152,125,183,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS4wMW1tIiBoZWlnaHQ9IjE5OS42OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuMDEgMTk5LjY5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMi45MDMgLTQ1LjEyNSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDc4LjIxNSkiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iNi45MDE0IiBzdHJva2Utd2lkdGg9IjQuOTg0OSIvPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iMTQuNjU0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNy4xMDQiLz48L2c+PGcgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iNDAuMjc0IiB5PSIxNTguNzQiIHdpZHRoPSI5Mi4xNSIgaGVpZ2h0PSI0MC4zMjYiIHN0cm9rZS13aWR0aD0iOC43Mjg3Ii8+PHJlY3QgeD0iMzcuNzkzIiB5PSIxNTUuODQiIHdpZHRoPSIxMi42MjUiIGhlaWdodD0iNDMuMjI3IiByeT0iNS45OTA3IiBzdHJva2Utd2lkdGg9IjguMjM3OCIvPjxyZWN0IHg9IjM0LjU4OCIgeT0iMTY2LjgyIiB3aWR0aD0iNy4wNDgiIGhlaWdodD0iMjQuMTMzIiByeT0iMy4zNDQ1IiBzdHJva2Utd2lkdGg9IjQuNTk5Ii8+PHJlY3QgeD0iNDQuMzUzIiB5PSIxNDMuNzUiIHdpZHRoPSIyMi45OTUiIGhlaWdodD0iMjQuMTMxIiByeT0iMCIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxjaXJjbGUgY3g9IjEwOC4xMSIgY3k9IjU3LjQ1OSIgcj0iMTIuMzM0IiBzdHJva2Utd2lkdGg9IjguNDU2Ii8+PGNpcmNsZSBjeD0iMTA4LjgiIGN5PSI4Ni4yMzUiIHI9IjE4Ljg2MiIgc3Ryb2tlLXdpZHRoPSIxMi45MzEiLz48Y2lyY2xlIGN4PSI5My4zMzciIGN5PSIxMDYuODgiIHI9IjE3LjYxOCIgc3Ryb2tlLXdpZHRoPSIxMi4wNzkiLz48cGF0aCBkPSJtNTAuMjI4IDEzNS45NmgxMy4yMzJzMy4wNDk5LTcuNDkyOSA2LjA5MzMtOS44ODQxYzIuODc4My0yLjI2MTUgNy4wNzQ2LTMuOTQ4NCAxMC40NDYtMy4zODc1IDMuMTYyOSAwLjUyNjE1IDYuMzE0MS0wLjg1OTYyIDcuNTA0MyAxLjQ2OTcgMC4xNjY3OSAwLjMyNjQyLTAuMjE2NTEgMC44MzE1MyAxLjM1MjggMC45NTIzOSAwLjc5NDU2IDAuMDYxMi0wLjA4NTQxLTAuODMzOTUgMy4xNTI0LTAuNjYzMTMgMi41MTU0IDAuMTMyNyAxLjQ2Ni00LjAyNzMgMS40NjYtNC4wMjczcy0zLjAxNzktMTEuODQ4LTcuNTUxNi0xNS4yNjNjLTIuMzUwOS0xLjc3MTEtMi41MTYyLTIuNDExMi0yLjY2MTMtNS4zNTEtMy44MzQ5LTMuNzM5Ny0xMy4wMjYgMS4wNTA0LTE0LjQ5NSAzLjI2NTItMS40MTU4IDIuMTg3MS0yLjI3MTQgNC4wMzUyLTMuODMxOSA1LjcxNjktMC45NDE3OCAxLjAxNDktMi40ODkxIDEuNDE5MS0zLjI2OCAyLjU2MzgtMC45NjA1MyAxLjQxMTUtMC42MDk5NyAzLjQyOTQtMS40NjIgNC45MDg5LTAuODE4MDkgMS40MjA2LTIuMzIgMi4zMjI2LTMuMzcyMSAzLjU3OTctMS42OTc5IDIuMDI4OC0zLjY2MzIgMy45NTMtNC43MjggNi4zNzQ4LTEuMzMxNCAzLjAyODItMS44NzcyIDkuNzQ0OC0xLjg3NzIgOS43NDQ4eiIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxwYXRoIGQ9Im0xMzkuNDggMTUxLjQ3djQ3LjM3NGgzNy4wMzlsMS40MDI1LTEuNDAyNXYtNDUuOTcyem0xMC4yNzIgNS4zNTg4aDEzLjE4OHYxNi40MDdoLTEzLjE4OHoiIHN0cm9rZS13aWR0aD0iOC41NjYzIi8+PHJlY3QgeD0iMTM0LjQ3IiB5PSIxMzkuMjIiIHdpZHRoPSI0OS40NCIgaGVpZ2h0PSIxNi43MDciIHJ5PSI0LjgwNDIiIHN0cm9rZS13aWR0aD0iNy4zMTYiLz48cGF0aCBkPSJtMTcxLjk3IDE5NC4zdjkuMDg2OGg1LjFlLTRsNS45NDU5LTUuOTQ1OXYtMy4xNDA5eiIgc3Ryb2tlLXdpZHRoPSI4LjQ3ODIiLz48cGF0aCBkPSJtMzguNDggMjAzLjM5djE5Ljc1OGgxMS4zMzlhMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2Mi0xMS4xOTcgMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2NyAxMS4xOTdoMTEuNTYyYTE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjItMTEuMTk3IDE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjggMTEuMTk3aDkuNTk3N2ExNC41OCAxNC42NTQgMCAwIDEgMTQuMTYyLTExLjE5NyAxNC41OCAxNC42NTQgMCAwIDEgMTQuMTY4IDExLjE5N2gxNy42OTZ2LTE5Ljc1OHoiIHN0cm9rZS13aWR0aD0iOC40MTA1Ii8+PHJlY3QgeD0iMjIuOTAzIiB5PSIyMTIuMTgiIHdpZHRoPSIyNS4yNDMiIGhlaWdodD0iMTkuMjU1IiBzdHJva2Utd2lkdGg9IjcuODUwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjE0LjY1NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjcuMTA0Ii8+PC9nPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIuOTQxODEiPjxwYXRoIGQ9Im0xMjUuMTkgMjI2LjYxaDMyLjkwNCIvPjxwYXRoIGQ9Im0xNDEuNjQgMjEwLjE2djMyLjkwNCIvPjxwYXRoIGQ9Im0xNTMuMjcgMjM4LjI0LTIzLjI2Ny0yMy4yNjciLz48cGF0aCBkPSJtMTQ4LjE3IDI0MS43MS0xMy4wNjQtMzAuMTk5Ii8+PHBhdGggZD0ibTEzNS4xMSAyNDEuNzEgMTMuMDY0LTMwLjE5OSIvPjxwYXRoIGQ9Im0xMjYuMiAyMzIuMjkgMzAuODc2LTExLjM3MiIvPjxwYXRoIGQ9Im0xMjYuMiAyMjAuOTIgMzAuODc2IDExLjM3MiIvPjwvZz48Zz48cmVjdCB4PSIzOC40OCIgeT0iMTkwLjg2IiB3aWR0aD0iNi4zMTIzIiBoZWlnaHQ9IjIxLjc2Ii8+PHBhdGggZD0ibTUzLjQ1IDE1MC4xcy04LjgxNTYtMi42NTY2LTkuMDk3OC02LjM0MjZjLTAuMTU4NDUtMi4wNyAyLjQ1OTctMy45NTY4IDQuNTA3Ni00LjI5ODEgMi44MTc1LTAuNDY5NTUgNC45Mjc5IDMuNTk1NyA3Ljc4NDMgMy41ODI3IDIuNjUzNC0wLjAxMjEgNC42MDY3LTMuOTUyNyA3LjIwMDYtMy4zOTM3IDEuNzU5MyAwLjM3OTE1IDMuNTAyMyAyLjM4NzYgMy41MDIzIDQuMTA5MSAwIDUuMDkyLTEzLjg5NyA2LjM0MjYtMTMuODk3IDYuMzQyNnoiLz48Y2lyY2xlIGN4PSIxMDMuNTIiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48L2c+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNDAuMDk1KSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSI2LjkwMTQiIHN0cm9rZS13aWR0aD0iNC45ODQ5Ii8+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSIxNC42NTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI3LjEwNCIvPjwvZz48cGF0aCBkPSJtMTUzLjI3IDIxNC45Ny0yMy4yNjcgMjMuMjY3IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iLjk0MTgxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.35402" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjczLjYwM21tIiBoZWlnaHQ9IjkzLjA4MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3My42MDMgOTMuMDgxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02OC4wMTUgLTk4LjMwMSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIxOC40MSAtMjAuODgpIj48cmVjdCB4PSItMTQ3Ljk5IiB5PSIxMzUuNDQiIHdpZHRoPSI2OC43OTIiIGhlaWdodD0iNzQuNDE4IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MTA5Ii8+PGc+PHJlY3QgeD0iLTE0Ny4yNiIgeT0iMjA0LjY3IiB3aWR0aD0iNjYuMzg2IiBoZWlnaHQ9IjMuNzUwNiIvPjxwYXRoIGQ9Im0tMTEzLjYgMTE5LjE4YTM2LjgwMSAxNi4zNjYgMCAwIDAtMzYuNTUyIDE0LjU2NGg3My4xMDRhMzYuODAxIDE2LjM2NiAwIDAgMC0zNi41NTItMTQuNTY0eiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLW9wYWNpdHk9Ii41IiBzdHJva2Utd2lkdGg9IjQuOTQ2MyIvPjxyZWN0IHg9Ii0xNTAuNCIgeT0iMTMwLjU0IiB3aWR0aD0iNzMuNjAzIiBoZWlnaHQ9IjUuMDA2OCIgcnk9IjIuMDE4MiIvPjwvZz48ZyB0cmFuc2Zvcm09Im1hdHJpeCguNjIzMTQgMCAwIC42MjMxNCAtMTU2LjQ0IDkxLjg3OCkiPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.27" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjkwLjcyNG1tIiBoZWlnaHQ9IjE1MS4xM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5MC43MjQgMTUxLjEzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02NS44NzggLTY3LjgzMikiPjxjaXJjbGUgY3g9IjEzMi4xOCIgY3k9IjkyLjI1OCIgcj0iMjIuMDE0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MjYiLz48Zz48cmVjdCB4PSI2NS44NzgiIHk9IjIxMi42NSIgd2lkdGg9IjcxLjUwNCIgaGVpZ2h0PSI2LjMwODkiLz48cGF0aCB0cmFuc2Zvcm09Im1hdHJpeCgxIDAgMCAzLjEwMjYgNjcuNzMgLTIwOC44OSkiIGQ9Im01Ny40NTEgMTM2Ljc0aC00Ny4xMDJsMjMuNTUxLTQwLjc5MXoiLz48cmVjdCB4PSI5OC4xNTUiIHk9Ijg4Ljc5MiIgd2lkdGg9IjEyLjg5MSIgaGVpZ2h0PSI2LjkzMzQiIHJ5PSIwIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.3617" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi41bW0iIGhlaWdodD0iMTIyLjg1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi41IDEyMi44NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzYuMTE3IC04Ni42NjIpIj48ZyBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im0xMTguNTQgMTYxLjQ0Yy0yLjI4OTYgMC00LjEzMzEgMS44NDM0LTQuMTMzMSA0LjEzMzF2MjYuNzQ1aC00LjgwMjN2LTkuMDg4M2gtMzAuODgydjEyLjIyNWMwIDMuMTA0OCAyLjUgNS42MDQ4IDUuNjA0OCA1LjYwNDhoMy40MDE5YTguODE3OCA4LjgxNzggMCAwIDAgOC43OTIyIDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkxNy04LjQ1NDNoMjYuMzMzYTguODE3OCA4LjgxNzggMCAwIDAgOC43OTE3IDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkyMi04LjQ1NDNoNC4wMTczYzIuMjg5NiAwIDQuMTMzMS0xLjg0MzQgNC4xMzMxLTQuMTMzMXYtMzEuMzUzYzAtMi4yODk2LTEuODQzNS00LjEzMzEtNC4xMzMxLTQuMTMzMXptLTIyLjAxOCAzNC43MTJhNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjczODkgMC4zNDU3MiA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0MyAwLjk4NTQ3IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0NyAxLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjM0NTcyIDEuNzM4OSA0LjU0NDUgNC41NDQ1IDAgMCAxLTQuNTQ0NCA0LjU0NDQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDktNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMy0xLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjk4NDk1LTEuNDc0MyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0My0wLjk4NDk1IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0LTAuMzQ1NzJ6bTQzLjkxNyAwYTQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0IDAuMzQ1NzIgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMgMC45ODQ5NSA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuOTg0OTUgMS40NzQzIDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMyAxLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDkgNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEtNC41NDQ0LTQuNTQ0NCA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuMzQ1NzEtMS43Mzg5IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0Ny0xLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMtMC45ODU0NyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNzM4OS0wLjM0NTcyeiIgc3Ryb2tlLXdpZHRoPSIuNTU2NzEiLz48cGF0aCBkPSJtOTAuMjcgMTY1LjQ3LTkuNDAxNSAxMy41MDVoMjguNzM1di0xMy41MDV6IiBzdHJva2Utd2lkdGg9Ii40OTY2OCIvPjxwYXRoIGQ9Im0zNi4xMTcgMTM5LjI4IDE5LjMwNCAxMC4xNjh2MjMuOTcybC0xOS4zMDQtMTAuNjE2eiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjxwYXRoIGQ9Im03OS43MjkgMTM5LjI4LTE5LjMwNCAxMC4xNjh2MjMuOTcybDE5LjMwNC0xMC42MTZ6IiBzdHJva2Utd2lkdGg9Ii41Ii8+PHJlY3QgdHJhbnNmb3JtPSJtYXRyaXgoLjg4NDYxIC0uNDY2MzMgLjg4NDYxIC40NjYzMyAwIDApIiB4PSItMTIzLjg0IiB5PSIxNjcuNjUiIHdpZHRoPSIyMS42NjUiIGhlaWdodD0iMjEuNjY1IiBzdHJva2Utd2lkdGg9Ii43NTgxNiIvPjwvZz48cGF0aCBkPSJtNjguMzgxIDg2LjY2OWMtMy41MzkxIDAuMTQ5MTEtNC44MzI1IDMuNDQxMy00LjYxNTcgNS4wNzQ2IDEuODQ2MiAxMy45MTIgMi45NjI5IDI0LjExNCA0Ljg5NjMgMjQuOTA2IDguNzM3OCAzLjU4MzggMTguNTQ0IDcuNDgyMSAyOC44MSAxMS40NTMtMi4xMDEyIDMuNjEyMi01LjA4MzIgOC43NDM0LTcuNzYyMyAxMy4zODQtMi44Njk1IDQuOTcwMSAwLjk4MzU1IDYuNDg3NiAzLjU2NjIgNy4yMjkgOC43NjUxIDIuNTE2NCAxMC4wMDYtMS40MDQ2IDIyLjcyNC0xMy41NjUgMTEuMjIgNC4yMDI4IDIyLjU1MiA4LjMyOTYgMzMuMjk4IDEyLjA4OSAyLjU4MiAwLjkwMzIzIDUuOTYyOS0xLjA5MzMgNy40ODMzLTMuMzY3MiAxLjg2MTUtMi43ODQyIDQuNzA4My0xMi4yNjgtNS40ODk2LTIyLjIwOS0yLjEwMTQtMi4wNDg1LTQuNTkxNS00LjA3OS03LjMyNTYtNS4xNTI3LTE5LjcyNC03Ljc0NS02MS42NDYtMTUuODU2LTYxLjY0Ni0xNS44NTYtNC40MDktNS40MzQtNy40MTE0LTE0LjI2LTEzLjkzOC0xMy45ODV6Ii8+PHBhdGggZD0ibTEwNS43NCA5MS43NjZjLTUuMzU4OCAwLTkuNTY5LTEuMDkxOC03LjUwNTcgNi4zODgyIDAuMTI5MDkgMC40NjggMC40MDYyNyAwLjk5NTMgMC41OTg5MyAxLjQ2OTdsMjQuMjM5IDYuNDk0Ny04LjUxNy0xMi4yNDNjLTEuNDA2OC0yLjAyMjMtNC42MDg4LTIuMTA5Mi04LjgxNTUtMi4xMDkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS4wMW1tIiBoZWlnaHQ9IjE5OS42OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuMDEgMTk5LjY5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMi45MDMgLTQ1LjEyNSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDc4LjIxNSkiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iNi45MDE0IiBzdHJva2Utd2lkdGg9IjQuOTg0OSIvPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iMTQuNjU0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNy4xMDQiLz48L2c+PGcgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iNDAuMjc0IiB5PSIxNTguNzQiIHdpZHRoPSI5Mi4xNSIgaGVpZ2h0PSI0MC4zMjYiIHN0cm9rZS13aWR0aD0iOC43Mjg3Ii8+PHJlY3QgeD0iMzcuNzkzIiB5PSIxNTUuODQiIHdpZHRoPSIxMi42MjUiIGhlaWdodD0iNDMuMjI3IiByeT0iNS45OTA3IiBzdHJva2Utd2lkdGg9IjguMjM3OCIvPjxyZWN0IHg9IjM0LjU4OCIgeT0iMTY2LjgyIiB3aWR0aD0iNy4wNDgiIGhlaWdodD0iMjQuMTMzIiByeT0iMy4zNDQ1IiBzdHJva2Utd2lkdGg9IjQuNTk5Ii8+PHJlY3QgeD0iNDQuMzUzIiB5PSIxNDMuNzUiIHdpZHRoPSIyMi45OTUiIGhlaWdodD0iMjQuMTMxIiByeT0iMCIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxjaXJjbGUgY3g9IjEwOC4xMSIgY3k9IjU3LjQ1OSIgcj0iMTIuMzM0IiBzdHJva2Utd2lkdGg9IjguNDU2Ii8+PGNpcmNsZSBjeD0iMTA4LjgiIGN5PSI4Ni4yMzUiIHI9IjE4Ljg2MiIgc3Ryb2tlLXdpZHRoPSIxMi45MzEiLz48Y2lyY2xlIGN4PSI5My4zMzciIGN5PSIxMDYuODgiIHI9IjE3LjYxOCIgc3Ryb2tlLXdpZHRoPSIxMi4wNzkiLz48cGF0aCBkPSJtNTAuMjI4IDEzNS45NmgxMy4yMzJzMy4wNDk5LTcuNDkyOSA2LjA5MzMtOS44ODQxYzIuODc4My0yLjI2MTUgNy4wNzQ2LTMuOTQ4NCAxMC40NDYtMy4zODc1IDMuMTYyOSAwLjUyNjE1IDYuMzE0MS0wLjg1OTYyIDcuNTA0MyAxLjQ2OTcgMC4xNjY3OSAwLjMyNjQyLTAuMjE2NTEgMC44MzE1MyAxLjM1MjggMC45NTIzOSAwLjc5NDU2IDAuMDYxMi0wLjA4NTQxLTAuODMzOTUgMy4xNTI0LTAuNjYzMTMgMi41MTU0IDAuMTMyNyAxLjQ2Ni00LjAyNzMgMS40NjYtNC4wMjczcy0zLjAxNzktMTEuODQ4LTcuNTUxNi0xNS4yNjNjLTIuMzUwOS0xLjc3MTEtMi41MTYyLTIuNDExMi0yLjY2MTMtNS4zNTEtMy44MzQ5LTMuNzM5Ny0xMy4wMjYgMS4wNTA0LTE0LjQ5NSAzLjI2NTItMS40MTU4IDIuMTg3MS0yLjI3MTQgNC4wMzUyLTMuODMxOSA1LjcxNjktMC45NDE3OCAxLjAxNDktMi40ODkxIDEuNDE5MS0zLjI2OCAyLjU2MzgtMC45NjA1MyAxLjQxMTUtMC42MDk5NyAzLjQyOTQtMS40NjIgNC45MDg5LTAuODE4MDkgMS40MjA2LTIuMzIgMi4zMjI2LTMuMzcyMSAzLjU3OTctMS42OTc5IDIuMDI4OC0zLjY2MzIgMy45NTMtNC43MjggNi4zNzQ4LTEuMzMxNCAzLjAyODItMS44NzcyIDkuNzQ0OC0xLjg3NzIgOS43NDQ4eiIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxwYXRoIGQ9Im0xMzkuNDggMTUxLjQ3djQ3LjM3NGgzNy4wMzlsMS40MDI1LTEuNDAyNXYtNDUuOTcyem0xMC4yNzIgNS4zNTg4aDEzLjE4OHYxNi40MDdoLTEzLjE4OHoiIHN0cm9rZS13aWR0aD0iOC41NjYzIi8+PHJlY3QgeD0iMTM0LjQ3IiB5PSIxMzkuMjIiIHdpZHRoPSI0OS40NCIgaGVpZ2h0PSIxNi43MDciIHJ5PSI0LjgwNDIiIHN0cm9rZS13aWR0aD0iNy4zMTYiLz48cGF0aCBkPSJtMTcxLjk3IDE5NC4zdjkuMDg2OGg1LjFlLTRsNS45NDU5LTUuOTQ1OXYtMy4xNDA5eiIgc3Ryb2tlLXdpZHRoPSI4LjQ3ODIiLz48cGF0aCBkPSJtMzguNDggMjAzLjM5djE5Ljc1OGgxMS4zMzlhMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2Mi0xMS4xOTcgMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2NyAxMS4xOTdoMTEuNTYyYTE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjItMTEuMTk3IDE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjggMTEuMTk3aDkuNTk3N2ExNC41OCAxNC42NTQgMCAwIDEgMTQuMTYyLTExLjE5NyAxNC41OCAxNC42NTQgMCAwIDEgMTQuMTY4IDExLjE5N2gxNy42OTZ2LTE5Ljc1OHoiIHN0cm9rZS13aWR0aD0iOC40MTA1Ii8+PHJlY3QgeD0iMjIuOTAzIiB5PSIyMTIuMTgiIHdpZHRoPSIyNS4yNDMiIGhlaWdodD0iMTkuMjU1IiBzdHJva2Utd2lkdGg9IjcuODUwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjE0LjY1NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjcuMTA0Ii8+PC9nPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIuOTQxODEiPjxwYXRoIGQ9Im0xMjUuMTkgMjI2LjYxaDMyLjkwNCIvPjxwYXRoIGQ9Im0xNDEuNjQgMjEwLjE2djMyLjkwNCIvPjxwYXRoIGQ9Im0xNTMuMjcgMjM4LjI0LTIzLjI2Ny0yMy4yNjciLz48cGF0aCBkPSJtMTQ4LjE3IDI0MS43MS0xMy4wNjQtMzAuMTk5Ii8+PHBhdGggZD0ibTEzNS4xMSAyNDEuNzEgMTMuMDY0LTMwLjE5OSIvPjxwYXRoIGQ9Im0xMjYuMiAyMzIuMjkgMzAuODc2LTExLjM3MiIvPjxwYXRoIGQ9Im0xMjYuMiAyMjAuOTIgMzAuODc2IDExLjM3MiIvPjwvZz48Zz48cmVjdCB4PSIzOC40OCIgeT0iMTkwLjg2IiB3aWR0aD0iNi4zMTIzIiBoZWlnaHQ9IjIxLjc2Ii8+PHBhdGggZD0ibTUzLjQ1IDE1MC4xcy04LjgxNTYtMi42NTY2LTkuMDk3OC02LjM0MjZjLTAuMTU4NDUtMi4wNyAyLjQ1OTctMy45NTY4IDQuNTA3Ni00LjI5ODEgMi44MTc1LTAuNDY5NTUgNC45Mjc5IDMuNTk1NyA3Ljc4NDMgMy41ODI3IDIuNjUzNC0wLjAxMjEgNC42MDY3LTMuOTUyNyA3LjIwMDYtMy4zOTM3IDEuNzU5MyAwLjM3OTE1IDMuNTAyMyAyLjM4NzYgMy41MDIzIDQuMTA5MSAwIDUuMDkyLTEzLjg5NyA2LjM0MjYtMTMuODk3IDYuMzQyNnoiLz48Y2lyY2xlIGN4PSIxMDMuNTIiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48L2c+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNDAuMDk1KSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSI2LjkwMTQiIHN0cm9rZS13aWR0aD0iNC45ODQ5Ii8+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSIxNC42NTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI3LjEwNCIvPjwvZz48cGF0aCBkPSJtMTUzLjI3IDIxNC45Ny0yMy4yNjcgMjMuMjY3IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iLjk0MTgxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.35402" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxyZWN0IHg9IjE1NS4xMSIgeT0iODUuMTY0IiB3aWR0aD0iOC41NjA5IiBoZWlnaHQ9Ijc4Ljc5Ii8+PHJlY3QgdHJhbnNmb3JtPSJyb3RhdGUoLTkwKSIgeD0iLTkzLjg1OSIgeT0iMTExLjI5IiB3aWR0aD0iOC42OTUzIiBoZWlnaHQ9IjY2LjQ3Ii8+PHBhdGggZD0ibTQwLjI4MyA4My41NDFjLTQuNDczNCAwLTguMDc1IDMuNjAxNi04LjA3NSA4LjA3NXY1Mi4yMTNjMCA0LjQ3MzQgMy42MDE2IDguMDc1IDguMDc1IDguMDc1aDQuOTI5NHYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE3IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2Nmg0LjkyOTRjNC40NzM0IDAgOC4wNzUtMy42MDE1IDguMDc1LTguMDc1di01Mi4yMTNjMC00LjQ3MzQtMy42MDE1LTguMDc1LTguMDc1LTguMDc1em03LjgzMSA1LjgwOTVoNDEuMjg5YzAuODQxMTIgMCAxLjUxODMgMC42NzcxMyAxLjUxODMgMS41MTgzdjIuMzQ4MmMwIDAuODQxMTItMC42NzcxMyAxLjUxODgtMS41MTgzIDEuNTE4OGgtNDEuMjg5Yy0wLjg0MTEyIDAtMS41MTgzLTAuNjc3NjUtMS41MTgzLTEuNTE4OHYtMi4zNDgyYzAtMC44NDExMiAwLjY3NzEzLTEuNTE4MyAxLjUxODMtMS41MTgzem0tOC4wOTU2IDEzLjI2M2g1Ny40ODF2MTkuNzYxaC01Ny40ODF6bTQuMjAxOCAzMS4zNjhhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMgMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczIDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc2OC0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjgtMy4yNzczem00OS4wNzcgMGEzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc2OCAzLjI3NzMgMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjggMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczLTMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc3My0zLjI3NzN6Ii8+PHBhdGggZD0ibTQzLjMwMiAxNDcuNzNjLTEuNjY2MyAwLTMuMDA4MSAxLjM0MTMtMy4wMDgxIDMuMDA3NnYxNC43OTVjMCAxLjY2NjMgMS4zNDE4IDMuMDA3NiAzLjAwODEgMy4wMDc2aDUwLjkxNGMxLjY2NjMgMCAzLjAwODEtMS4zNDEzIDMuMDA4MS0zLjAwNzZ2LTE0Ljc5NWMwLTEuNjY2My0xLjM0MTgtMy4wMDc2LTMuMDA4MS0zLjAwNzZ6bTMuMjkzOSAwLjcyNzA5aDAuNzA5YzAuNzY2MTggMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE4IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE3IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTcgMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjkgMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIxIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyMS0xLjM4MzQgMS4zODM0LTEuMzgzNHoiLz48cmVjdCB4PSI0NC40NjUiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48cmVjdCB4PSI0MC4xMzEiIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjkxLjYwNyIgeT0iMTc1LjMiIHdpZHRoPSI1Ljc3MzEiIGhlaWdodD0iMTAuNTQ4Ii8+PHJlY3QgeD0iNDQuMTkyIiB5PSIxODAuMDciIHdpZHRoPSI0Ny45OSIgaGVpZ2h0PSI2LjM4NzgiLz48cmVjdCB4PSI4Ny43NDgiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjczLjYwM21tIiBoZWlnaHQ9IjkzLjA4MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3My42MDMgOTMuMDgxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02OC4wMTUgLTk4LjMwMSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIxOC40MSAtMjAuODgpIj48cmVjdCB4PSItMTQ3Ljk5IiB5PSIxMzUuNDQiIHdpZHRoPSI2OC43OTIiIGhlaWdodD0iNzQuNDE4IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MTA5Ii8+PGc+PHJlY3QgeD0iLTE0Ny4yNiIgeT0iMjA0LjY3IiB3aWR0aD0iNjYuMzg2IiBoZWlnaHQ9IjMuNzUwNiIvPjxwYXRoIGQ9Im0tMTEzLjYgMTE5LjE4YTM2LjgwMSAxNi4zNjYgMCAwIDAtMzYuNTUyIDE0LjU2NGg3My4xMDRhMzYuODAxIDE2LjM2NiAwIDAgMC0zNi41NTItMTQuNTY0eiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLW9wYWNpdHk9Ii41IiBzdHJva2Utd2lkdGg9IjQuOTQ2MyIvPjxyZWN0IHg9Ii0xNTAuNCIgeT0iMTMwLjU0IiB3aWR0aD0iNzMuNjAzIiBoZWlnaHQ9IjUuMDA2OCIgcnk9IjIuMDE4MiIvPjwvZz48ZyB0cmFuc2Zvcm09Im1hdHJpeCguNjIzMTQgMCAwIC42MjMxNCAtMTU2LjQ0IDkxLjg3OCkiPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.27" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjkwLjcyNG1tIiBoZWlnaHQ9IjE1MS4xM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5MC43MjQgMTUxLjEzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02NS44NzggLTY3LjgzMikiPjxjaXJjbGUgY3g9IjEzMi4xOCIgY3k9IjkyLjI1OCIgcj0iMjIuMDE0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MjYiLz48Zz48cmVjdCB4PSI2NS44NzgiIHk9IjIxMi42NSIgd2lkdGg9IjcxLjUwNCIgaGVpZ2h0PSI2LjMwODkiLz48cGF0aCB0cmFuc2Zvcm09Im1hdHJpeCgxIDAgMCAzLjEwMjYgNjcuNzMgLTIwOC44OSkiIGQ9Im01Ny40NTEgMTM2Ljc0aC00Ny4xMDJsMjMuNTUxLTQwLjc5MXoiLz48cmVjdCB4PSI5OC4xNTUiIHk9Ijg4Ljc5MiIgd2lkdGg9IjEyLjg5MSIgaGVpZ2h0PSI2LjkzMzQiIHJ5PSIwIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.3617" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxyZWN0IHg9IjE1NS4xMSIgeT0iODUuMTY0IiB3aWR0aD0iOC41NjA5IiBoZWlnaHQ9Ijc4Ljc5Ii8+PHJlY3QgdHJhbnNmb3JtPSJyb3RhdGUoLTkwKSIgeD0iLTkzLjg1OSIgeT0iMTExLjI5IiB3aWR0aD0iOC42OTUzIiBoZWlnaHQ9IjY2LjQ3Ii8+PHBhdGggZD0ibTQwLjI4MyA4My41NDFjLTQuNDczNCAwLTguMDc1IDMuNjAxNi04LjA3NSA4LjA3NXY1Mi4yMTNjMCA0LjQ3MzQgMy42MDE2IDguMDc1IDguMDc1IDguMDc1aDQuOTI5NHYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE3IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2Nmg0LjkyOTRjNC40NzM0IDAgOC4wNzUtMy42MDE1IDguMDc1LTguMDc1di01Mi4yMTNjMC00LjQ3MzQtMy42MDE1LTguMDc1LTguMDc1LTguMDc1em03LjgzMSA1LjgwOTVoNDEuMjg5YzAuODQxMTIgMCAxLjUxODMgMC42NzcxMyAxLjUxODMgMS41MTgzdjIuMzQ4MmMwIDAuODQxMTItMC42NzcxMyAxLjUxODgtMS41MTgzIDEuNTE4OGgtNDEuMjg5Yy0wLjg0MTEyIDAtMS41MTgzLTAuNjc3NjUtMS41MTgzLTEuNTE4OHYtMi4zNDgyYzAtMC44NDExMiAwLjY3NzEzLTEuNTE4MyAxLjUxODMtMS41MTgzem0tOC4wOTU2IDEzLjI2M2g1Ny40ODF2MTkuNzYxaC01Ny40ODF6bTQuMjAxOCAzMS4zNjhhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMgMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczIDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc2OC0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjgtMy4yNzczem00OS4wNzcgMGEzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc2OCAzLjI3NzMgMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjggMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczLTMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc3My0zLjI3NzN6Ii8+PHBhdGggZD0ibTQzLjMwMiAxNDcuNzNjLTEuNjY2MyAwLTMuMDA4MSAxLjM0MTMtMy4wMDgxIDMuMDA3NnYxNC43OTVjMCAxLjY2NjMgMS4zNDE4IDMuMDA3NiAzLjAwODEgMy4wMDc2aDUwLjkxNGMxLjY2NjMgMCAzLjAwODEtMS4zNDEzIDMuMDA4MS0zLjAwNzZ2LTE0Ljc5NWMwLTEuNjY2My0xLjM0MTgtMy4wMDc2LTMuMDA4MS0zLjAwNzZ6bTMuMjkzOSAwLjcyNzA5aDAuNzA5YzAuNzY2MTggMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE4IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE3IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTcgMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjkgMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIxIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyMS0xLjM4MzQgMS4zODM0LTEuMzgzNHoiLz48cmVjdCB4PSI0NC40NjUiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48cmVjdCB4PSI0MC4xMzEiIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjkxLjYwNyIgeT0iMTc1LjMiIHdpZHRoPSI1Ljc3MzEiIGhlaWdodD0iMTAuNTQ4Ii8+PHJlY3QgeD0iNDQuMTkyIiB5PSIxODAuMDciIHdpZHRoPSI0Ny45OSIgaGVpZ2h0PSI2LjM4NzgiLz48cmVjdCB4PSI4Ny43NDgiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi41bW0iIGhlaWdodD0iMTIyLjg1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi41IDEyMi44NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzYuMTE3IC04Ni42NjIpIj48ZyBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im0xMTguNTQgMTYxLjQ0Yy0yLjI4OTYgMC00LjEzMzEgMS44NDM0LTQuMTMzMSA0LjEzMzF2MjYuNzQ1aC00LjgwMjN2LTkuMDg4M2gtMzAuODgydjEyLjIyNWMwIDMuMTA0OCAyLjUgNS42MDQ4IDUuNjA0OCA1LjYwNDhoMy40MDE5YTguODE3OCA4LjgxNzggMCAwIDAgOC43OTIyIDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkxNy04LjQ1NDNoMjYuMzMzYTguODE3OCA4LjgxNzggMCAwIDAgOC43OTE3IDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkyMi04LjQ1NDNoNC4wMTczYzIuMjg5NiAwIDQuMTMzMS0xLjg0MzQgNC4xMzMxLTQuMTMzMXYtMzEuMzUzYzAtMi4yODk2LTEuODQzNS00LjEzMzEtNC4xMzMxLTQuMTMzMXptLTIyLjAxOCAzNC43MTJhNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjczODkgMC4zNDU3MiA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0MyAwLjk4NTQ3IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0NyAxLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjM0NTcyIDEuNzM4OSA0LjU0NDUgNC41NDQ1IDAgMCAxLTQuNTQ0NCA0LjU0NDQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDktNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMy0xLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjk4NDk1LTEuNDc0MyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0My0wLjk4NDk1IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0LTAuMzQ1NzJ6bTQzLjkxNyAwYTQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0IDAuMzQ1NzIgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMgMC45ODQ5NSA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuOTg0OTUgMS40NzQzIDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMyAxLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDkgNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEtNC41NDQ0LTQuNTQ0NCA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuMzQ1NzEtMS43Mzg5IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0Ny0xLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMtMC45ODU0NyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNzM4OS0wLjM0NTcyeiIgc3Ryb2tlLXdpZHRoPSIuNTU2NzEiLz48cGF0aCBkPSJtOTAuMjcgMTY1LjQ3LTkuNDAxNSAxMy41MDVoMjguNzM1di0xMy41MDV6IiBzdHJva2Utd2lkdGg9Ii40OTY2OCIvPjxwYXRoIGQ9Im0zNi4xMTcgMTM5LjI4IDE5LjMwNCAxMC4xNjh2MjMuOTcybC0xOS4zMDQtMTAuNjE2eiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjxwYXRoIGQ9Im03OS43MjkgMTM5LjI4LTE5LjMwNCAxMC4xNjh2MjMuOTcybDE5LjMwNC0xMC42MTZ6IiBzdHJva2Utd2lkdGg9Ii41Ii8+PHJlY3QgdHJhbnNmb3JtPSJtYXRyaXgoLjg4NDYxIC0uNDY2MzMgLjg4NDYxIC40NjYzMyAwIDApIiB4PSItMTIzLjg0IiB5PSIxNjcuNjUiIHdpZHRoPSIyMS42NjUiIGhlaWdodD0iMjEuNjY1IiBzdHJva2Utd2lkdGg9Ii43NTgxNiIvPjwvZz48cGF0aCBkPSJtNjguMzgxIDg2LjY2OWMtMy41MzkxIDAuMTQ5MTEtNC44MzI1IDMuNDQxMy00LjYxNTcgNS4wNzQ2IDEuODQ2MiAxMy45MTIgMi45NjI5IDI0LjExNCA0Ljg5NjMgMjQuOTA2IDguNzM3OCAzLjU4MzggMTguNTQ0IDcuNDgyMSAyOC44MSAxMS40NTMtMi4xMDEyIDMuNjEyMi01LjA4MzIgOC43NDM0LTcuNzYyMyAxMy4zODQtMi44Njk1IDQuOTcwMSAwLjk4MzU1IDYuNDg3NiAzLjU2NjIgNy4yMjkgOC43NjUxIDIuNTE2NCAxMC4wMDYtMS40MDQ2IDIyLjcyNC0xMy41NjUgMTEuMjIgNC4yMDI4IDIyLjU1MiA4LjMyOTYgMzMuMjk4IDEyLjA4OSAyLjU4MiAwLjkwMzIzIDUuOTYyOS0xLjA5MzMgNy40ODMzLTMuMzY3MiAxLjg2MTUtMi43ODQyIDQuNzA4My0xMi4yNjgtNS40ODk2LTIyLjIwOS0yLjEwMTQtMi4wNDg1LTQuNTkxNS00LjA3OS03LjMyNTYtNS4xNTI3LTE5LjcyNC03Ljc0NS02MS42NDYtMTUuODU2LTYxLjY0Ni0xNS44NTYtNC40MDktNS40MzQtNy40MTE0LTE0LjI2LTEzLjkzOC0xMy45ODV6Ii8+PHBhdGggZD0ibTEwNS43NCA5MS43NjZjLTUuMzU4OCAwLTkuNTY5LTEuMDkxOC03LjUwNTcgNi4zODgyIDAuMTI5MDkgMC40NjggMC40MDYyNyAwLjk5NTMgMC41OTg5MyAxLjQ2OTdsMjQuMjM5IDYuNDk0Ny04LjUxNy0xMi4yNDNjLTEuNDA2OC0yLjAyMjMtNC42MDg4LTIuMTA5Mi04LjgxNTUtMi4xMDkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="145,82,45,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi41bW0iIGhlaWdodD0iMTIyLjg1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi41IDEyMi44NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzYuMTE3IC04Ni42NjIpIj48ZyBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im0xMTguNTQgMTYxLjQ0Yy0yLjI4OTYgMC00LjEzMzEgMS44NDM0LTQuMTMzMSA0LjEzMzF2MjYuNzQ1aC00LjgwMjN2LTkuMDg4M2gtMzAuODgydjEyLjIyNWMwIDMuMTA0OCAyLjUgNS42MDQ4IDUuNjA0OCA1LjYwNDhoMy40MDE5YTguODE3OCA4LjgxNzggMCAwIDAgOC43OTIyIDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkxNy04LjQ1NDNoMjYuMzMzYTguODE3OCA4LjgxNzggMCAwIDAgOC43OTE3IDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkyMi04LjQ1NDNoNC4wMTczYzIuMjg5NiAwIDQuMTMzMS0xLjg0MzQgNC4xMzMxLTQuMTMzMXYtMzEuMzUzYzAtMi4yODk2LTEuODQzNS00LjEzMzEtNC4xMzMxLTQuMTMzMXptLTIyLjAxOCAzNC43MTJhNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjczODkgMC4zNDU3MiA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0MyAwLjk4NTQ3IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0NyAxLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjM0NTcyIDEuNzM4OSA0LjU0NDUgNC41NDQ1IDAgMCAxLTQuNTQ0NCA0LjU0NDQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDktNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMy0xLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjk4NDk1LTEuNDc0MyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0My0wLjk4NDk1IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0LTAuMzQ1NzJ6bTQzLjkxNyAwYTQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0IDAuMzQ1NzIgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMgMC45ODQ5NSA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuOTg0OTUgMS40NzQzIDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMyAxLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDkgNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEtNC41NDQ0LTQuNTQ0NCA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuMzQ1NzEtMS43Mzg5IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0Ny0xLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMtMC45ODU0NyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNzM4OS0wLjM0NTcyeiIgc3Ryb2tlLXdpZHRoPSIuNTU2NzEiLz48cGF0aCBkPSJtOTAuMjcgMTY1LjQ3LTkuNDAxNSAxMy41MDVoMjguNzM1di0xMy41MDV6IiBzdHJva2Utd2lkdGg9Ii40OTY2OCIvPjxwYXRoIGQ9Im0zNi4xMTcgMTM5LjI4IDE5LjMwNCAxMC4xNjh2MjMuOTcybC0xOS4zMDQtMTAuNjE2eiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjxwYXRoIGQ9Im03OS43MjkgMTM5LjI4LTE5LjMwNCAxMC4xNjh2MjMuOTcybDE5LjMwNC0xMC42MTZ6IiBzdHJva2Utd2lkdGg9Ii41Ii8+PHJlY3QgdHJhbnNmb3JtPSJtYXRyaXgoLjg4NDYxIC0uNDY2MzMgLjg4NDYxIC40NjYzMyAwIDApIiB4PSItMTIzLjg0IiB5PSIxNjcuNjUiIHdpZHRoPSIyMS42NjUiIGhlaWdodD0iMjEuNjY1IiBzdHJva2Utd2lkdGg9Ii43NTgxNiIvPjwvZz48cGF0aCBkPSJtNjguMzgxIDg2LjY2OWMtMy41MzkxIDAuMTQ5MTEtNC44MzI1IDMuNDQxMy00LjYxNTcgNS4wNzQ2IDEuODQ2MiAxMy45MTIgMi45NjI5IDI0LjExNCA0Ljg5NjMgMjQuOTA2IDguNzM3OCAzLjU4MzggMTguNTQ0IDcuNDgyMSAyOC44MSAxMS40NTMtMi4xMDEyIDMuNjEyMi01LjA4MzIgOC43NDM0LTcuNzYyMyAxMy4zODQtMi44Njk1IDQuOTcwMSAwLjk4MzU1IDYuNDg3NiAzLjU2NjIgNy4yMjkgOC43NjUxIDIuNTE2NCAxMC4wMDYtMS40MDQ2IDIyLjcyNC0xMy41NjUgMTEuMjIgNC4yMDI4IDIyLjU1MiA4LjMyOTYgMzMuMjk4IDEyLjA4OSAyLjU4MiAwLjkwMzIzIDUuOTYyOS0xLjA5MzMgNy40ODMzLTMuMzY3MiAxLjg2MTUtMi43ODQyIDQuNzA4My0xMi4yNjgtNS40ODk2LTIyLjIwOS0yLjEwMTQtMi4wNDg1LTQuNTkxNS00LjA3OS03LjMyNTYtNS4xNTI3LTE5LjcyNC03Ljc0NS02MS42NDYtMTUuODU2LTYxLjY0Ni0xNS44NTYtNC40MDktNS40MzQtNy40MTE0LTE0LjI2LTEzLjkzOC0xMy45ODV6Ii8+PHBhdGggZD0ibTEwNS43NCA5MS43NjZjLTUuMzU4OCAwLTkuNTY5LTEuMDkxOC03LjUwNTcgNi4zODgyIDAuMTI5MDkgMC40NjggMC40MDYyNyAwLjk5NTMgMC41OTg5MyAxLjQ2OTdsMjQuMjM5IDYuNDk0Ny04LjUxNy0xMi4yNDNjLTEuNDA2OC0yLjAyMjMtNC42MDg4LTIuMTA5Mi04LjgxNTUtMi4xMDkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="152,125,183,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS4wMW1tIiBoZWlnaHQ9IjE5OS42OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuMDEgMTk5LjY5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMi45MDMgLTQ1LjEyNSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDc4LjIxNSkiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iNi45MDE0IiBzdHJva2Utd2lkdGg9IjQuOTg0OSIvPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iMTQuNjU0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNy4xMDQiLz48L2c+PGcgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iNDAuMjc0IiB5PSIxNTguNzQiIHdpZHRoPSI5Mi4xNSIgaGVpZ2h0PSI0MC4zMjYiIHN0cm9rZS13aWR0aD0iOC43Mjg3Ii8+PHJlY3QgeD0iMzcuNzkzIiB5PSIxNTUuODQiIHdpZHRoPSIxMi42MjUiIGhlaWdodD0iNDMuMjI3IiByeT0iNS45OTA3IiBzdHJva2Utd2lkdGg9IjguMjM3OCIvPjxyZWN0IHg9IjM0LjU4OCIgeT0iMTY2LjgyIiB3aWR0aD0iNy4wNDgiIGhlaWdodD0iMjQuMTMzIiByeT0iMy4zNDQ1IiBzdHJva2Utd2lkdGg9IjQuNTk5Ii8+PHJlY3QgeD0iNDQuMzUzIiB5PSIxNDMuNzUiIHdpZHRoPSIyMi45OTUiIGhlaWdodD0iMjQuMTMxIiByeT0iMCIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxjaXJjbGUgY3g9IjEwOC4xMSIgY3k9IjU3LjQ1OSIgcj0iMTIuMzM0IiBzdHJva2Utd2lkdGg9IjguNDU2Ii8+PGNpcmNsZSBjeD0iMTA4LjgiIGN5PSI4Ni4yMzUiIHI9IjE4Ljg2MiIgc3Ryb2tlLXdpZHRoPSIxMi45MzEiLz48Y2lyY2xlIGN4PSI5My4zMzciIGN5PSIxMDYuODgiIHI9IjE3LjYxOCIgc3Ryb2tlLXdpZHRoPSIxMi4wNzkiLz48cGF0aCBkPSJtNTAuMjI4IDEzNS45NmgxMy4yMzJzMy4wNDk5LTcuNDkyOSA2LjA5MzMtOS44ODQxYzIuODc4My0yLjI2MTUgNy4wNzQ2LTMuOTQ4NCAxMC40NDYtMy4zODc1IDMuMTYyOSAwLjUyNjE1IDYuMzE0MS0wLjg1OTYyIDcuNTA0MyAxLjQ2OTcgMC4xNjY3OSAwLjMyNjQyLTAuMjE2NTEgMC44MzE1MyAxLjM1MjggMC45NTIzOSAwLjc5NDU2IDAuMDYxMi0wLjA4NTQxLTAuODMzOTUgMy4xNTI0LTAuNjYzMTMgMi41MTU0IDAuMTMyNyAxLjQ2Ni00LjAyNzMgMS40NjYtNC4wMjczcy0zLjAxNzktMTEuODQ4LTcuNTUxNi0xNS4yNjNjLTIuMzUwOS0xLjc3MTEtMi41MTYyLTIuNDExMi0yLjY2MTMtNS4zNTEtMy44MzQ5LTMuNzM5Ny0xMy4wMjYgMS4wNTA0LTE0LjQ5NSAzLjI2NTItMS40MTU4IDIuMTg3MS0yLjI3MTQgNC4wMzUyLTMuODMxOSA1LjcxNjktMC45NDE3OCAxLjAxNDktMi40ODkxIDEuNDE5MS0zLjI2OCAyLjU2MzgtMC45NjA1MyAxLjQxMTUtMC42MDk5NyAzLjQyOTQtMS40NjIgNC45MDg5LTAuODE4MDkgMS40MjA2LTIuMzIgMi4zMjI2LTMuMzcyMSAzLjU3OTctMS42OTc5IDIuMDI4OC0zLjY2MzIgMy45NTMtNC43MjggNi4zNzQ4LTEuMzMxNCAzLjAyODItMS44NzcyIDkuNzQ0OC0xLjg3NzIgOS43NDQ4eiIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxwYXRoIGQ9Im0xMzkuNDggMTUxLjQ3djQ3LjM3NGgzNy4wMzlsMS40MDI1LTEuNDAyNXYtNDUuOTcyem0xMC4yNzIgNS4zNTg4aDEzLjE4OHYxNi40MDdoLTEzLjE4OHoiIHN0cm9rZS13aWR0aD0iOC41NjYzIi8+PHJlY3QgeD0iMTM0LjQ3IiB5PSIxMzkuMjIiIHdpZHRoPSI0OS40NCIgaGVpZ2h0PSIxNi43MDciIHJ5PSI0LjgwNDIiIHN0cm9rZS13aWR0aD0iNy4zMTYiLz48cGF0aCBkPSJtMTcxLjk3IDE5NC4zdjkuMDg2OGg1LjFlLTRsNS45NDU5LTUuOTQ1OXYtMy4xNDA5eiIgc3Ryb2tlLXdpZHRoPSI4LjQ3ODIiLz48cGF0aCBkPSJtMzguNDggMjAzLjM5djE5Ljc1OGgxMS4zMzlhMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2Mi0xMS4xOTcgMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2NyAxMS4xOTdoMTEuNTYyYTE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjItMTEuMTk3IDE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjggMTEuMTk3aDkuNTk3N2ExNC41OCAxNC42NTQgMCAwIDEgMTQuMTYyLTExLjE5NyAxNC41OCAxNC42NTQgMCAwIDEgMTQuMTY4IDExLjE5N2gxNy42OTZ2LTE5Ljc1OHoiIHN0cm9rZS13aWR0aD0iOC40MTA1Ii8+PHJlY3QgeD0iMjIuOTAzIiB5PSIyMTIuMTgiIHdpZHRoPSIyNS4yNDMiIGhlaWdodD0iMTkuMjU1IiBzdHJva2Utd2lkdGg9IjcuODUwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjE0LjY1NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjcuMTA0Ii8+PC9nPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIuOTQxODEiPjxwYXRoIGQ9Im0xMjUuMTkgMjI2LjYxaDMyLjkwNCIvPjxwYXRoIGQ9Im0xNDEuNjQgMjEwLjE2djMyLjkwNCIvPjxwYXRoIGQ9Im0xNTMuMjcgMjM4LjI0LTIzLjI2Ny0yMy4yNjciLz48cGF0aCBkPSJtMTQ4LjE3IDI0MS43MS0xMy4wNjQtMzAuMTk5Ii8+PHBhdGggZD0ibTEzNS4xMSAyNDEuNzEgMTMuMDY0LTMwLjE5OSIvPjxwYXRoIGQ9Im0xMjYuMiAyMzIuMjkgMzAuODc2LTExLjM3MiIvPjxwYXRoIGQ9Im0xMjYuMiAyMjAuOTIgMzAuODc2IDExLjM3MiIvPjwvZz48Zz48cmVjdCB4PSIzOC40OCIgeT0iMTkwLjg2IiB3aWR0aD0iNi4zMTIzIiBoZWlnaHQ9IjIxLjc2Ii8+PHBhdGggZD0ibTUzLjQ1IDE1MC4xcy04LjgxNTYtMi42NTY2LTkuMDk3OC02LjM0MjZjLTAuMTU4NDUtMi4wNyAyLjQ1OTctMy45NTY4IDQuNTA3Ni00LjI5ODEgMi44MTc1LTAuNDY5NTUgNC45Mjc5IDMuNTk1NyA3Ljc4NDMgMy41ODI3IDIuNjUzNC0wLjAxMjEgNC42MDY3LTMuOTUyNyA3LjIwMDYtMy4zOTM3IDEuNzU5MyAwLjM3OTE1IDMuNTAyMyAyLjM4NzYgMy41MDIzIDQuMTA5MSAwIDUuMDkyLTEzLjg5NyA2LjM0MjYtMTMuODk3IDYuMzQyNnoiLz48Y2lyY2xlIGN4PSIxMDMuNTIiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48L2c+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNDAuMDk1KSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSI2LjkwMTQiIHN0cm9rZS13aWR0aD0iNC45ODQ5Ii8+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSIxNC42NTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI3LjEwNCIvPjwvZz48cGF0aCBkPSJtMTUzLjI3IDIxNC45Ny0yMy4yNjcgMjMuMjY3IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iLjk0MTgxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.35402" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxyZWN0IHg9IjE1NS4xMSIgeT0iODUuMTY0IiB3aWR0aD0iOC41NjA5IiBoZWlnaHQ9Ijc4Ljc5Ii8+PHJlY3QgdHJhbnNmb3JtPSJyb3RhdGUoLTkwKSIgeD0iLTkzLjg1OSIgeT0iMTExLjI5IiB3aWR0aD0iOC42OTUzIiBoZWlnaHQ9IjY2LjQ3Ii8+PHBhdGggZD0ibTQwLjI4MyA4My41NDFjLTQuNDczNCAwLTguMDc1IDMuNjAxNi04LjA3NSA4LjA3NXY1Mi4yMTNjMCA0LjQ3MzQgMy42MDE2IDguMDc1IDguMDc1IDguMDc1aDQuOTI5NHYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE3IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2Nmg0LjkyOTRjNC40NzM0IDAgOC4wNzUtMy42MDE1IDguMDc1LTguMDc1di01Mi4yMTNjMC00LjQ3MzQtMy42MDE1LTguMDc1LTguMDc1LTguMDc1em03LjgzMSA1LjgwOTVoNDEuMjg5YzAuODQxMTIgMCAxLjUxODMgMC42NzcxMyAxLjUxODMgMS41MTgzdjIuMzQ4MmMwIDAuODQxMTItMC42NzcxMyAxLjUxODgtMS41MTgzIDEuNTE4OGgtNDEuMjg5Yy0wLjg0MTEyIDAtMS41MTgzLTAuNjc3NjUtMS41MTgzLTEuNTE4OHYtMi4zNDgyYzAtMC44NDExMiAwLjY3NzEzLTEuNTE4MyAxLjUxODMtMS41MTgzem0tOC4wOTU2IDEzLjI2M2g1Ny40ODF2MTkuNzYxaC01Ny40ODF6bTQuMjAxOCAzMS4zNjhhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMgMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczIDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc2OC0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjgtMy4yNzczem00OS4wNzcgMGEzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc2OCAzLjI3NzMgMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjggMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczLTMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc3My0zLjI3NzN6Ii8+PHBhdGggZD0ibTQzLjMwMiAxNDcuNzNjLTEuNjY2MyAwLTMuMDA4MSAxLjM0MTMtMy4wMDgxIDMuMDA3NnYxNC43OTVjMCAxLjY2NjMgMS4zNDE4IDMuMDA3NiAzLjAwODEgMy4wMDc2aDUwLjkxNGMxLjY2NjMgMCAzLjAwODEtMS4zNDEzIDMuMDA4MS0zLjAwNzZ2LTE0Ljc5NWMwLTEuNjY2My0xLjM0MTgtMy4wMDc2LTMuMDA4MS0zLjAwNzZ6bTMuMjkzOSAwLjcyNzA5aDAuNzA5YzAuNzY2MTggMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE4IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE3IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTcgMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjkgMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIxIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyMS0xLjM4MzQgMS4zODM0LTEuMzgzNHoiLz48cmVjdCB4PSI0NC40NjUiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48cmVjdCB4PSI0MC4xMzEiIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjkxLjYwNyIgeT0iMTc1LjMiIHdpZHRoPSI1Ljc3MzEiIGhlaWdodD0iMTAuNTQ4Ii8+PHJlY3QgeD0iNDQuMTkyIiB5PSIxODAuMDciIHdpZHRoPSI0Ny45OSIgaGVpZ2h0PSI2LjM4NzgiLz48cmVjdCB4PSI4Ny43NDgiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjczLjYwM21tIiBoZWlnaHQ9IjkzLjA4MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3My42MDMgOTMuMDgxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02OC4wMTUgLTk4LjMwMSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIxOC40MSAtMjAuODgpIj48cmVjdCB4PSItMTQ3Ljk5IiB5PSIxMzUuNDQiIHdpZHRoPSI2OC43OTIiIGhlaWdodD0iNzQuNDE4IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MTA5Ii8+PGc+PHJlY3QgeD0iLTE0Ny4yNiIgeT0iMjA0LjY3IiB3aWR0aD0iNjYuMzg2IiBoZWlnaHQ9IjMuNzUwNiIvPjxwYXRoIGQ9Im0tMTEzLjYgMTE5LjE4YTM2LjgwMSAxNi4zNjYgMCAwIDAtMzYuNTUyIDE0LjU2NGg3My4xMDRhMzYuODAxIDE2LjM2NiAwIDAgMC0zNi41NTItMTQuNTY0eiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLW9wYWNpdHk9Ii41IiBzdHJva2Utd2lkdGg9IjQuOTQ2MyIvPjxyZWN0IHg9Ii0xNTAuNCIgeT0iMTMwLjU0IiB3aWR0aD0iNzMuNjAzIiBoZWlnaHQ9IjUuMDA2OCIgcnk9IjIuMDE4MiIvPjwvZz48ZyB0cmFuc2Zvcm09Im1hdHJpeCguNjIzMTQgMCAwIC42MjMxNCAtMTU2LjQ0IDkxLjg3OCkiPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.27" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjkwLjcyNG1tIiBoZWlnaHQ9IjE1MS4xM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5MC43MjQgMTUxLjEzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02NS44NzggLTY3LjgzMikiPjxjaXJjbGUgY3g9IjEzMi4xOCIgY3k9IjkyLjI1OCIgcj0iMjIuMDE0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MjYiLz48Zz48cmVjdCB4PSI2NS44NzgiIHk9IjIxMi42NSIgd2lkdGg9IjcxLjUwNCIgaGVpZ2h0PSI2LjMwODkiLz48cGF0aCB0cmFuc2Zvcm09Im1hdHJpeCgxIDAgMCAzLjEwMjYgNjcuNzMgLTIwOC44OSkiIGQ9Im01Ny40NTEgMTM2Ljc0aC00Ny4xMDJsMjMuNTUxLTQwLjc5MXoiLz48cmVjdCB4PSI5OC4xNTUiIHk9Ijg4Ljc5MiIgd2lkdGg9IjEyLjg5MSIgaGVpZ2h0PSI2LjkzMzQiIHJ5PSIwIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.3617" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi41bW0iIGhlaWdodD0iMTIyLjg1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi41IDEyMi44NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzYuMTE3IC04Ni42NjIpIj48ZyBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im0xMTguNTQgMTYxLjQ0Yy0yLjI4OTYgMC00LjEzMzEgMS44NDM0LTQuMTMzMSA0LjEzMzF2MjYuNzQ1aC00LjgwMjN2LTkuMDg4M2gtMzAuODgydjEyLjIyNWMwIDMuMTA0OCAyLjUgNS42MDQ4IDUuNjA0OCA1LjYwNDhoMy40MDE5YTguODE3OCA4LjgxNzggMCAwIDAgOC43OTIyIDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkxNy04LjQ1NDNoMjYuMzMzYTguODE3OCA4LjgxNzggMCAwIDAgOC43OTE3IDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkyMi04LjQ1NDNoNC4wMTczYzIuMjg5NiAwIDQuMTMzMS0xLjg0MzQgNC4xMzMxLTQuMTMzMXYtMzEuMzUzYzAtMi4yODk2LTEuODQzNS00LjEzMzEtNC4xMzMxLTQuMTMzMXptLTIyLjAxOCAzNC43MTJhNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjczODkgMC4zNDU3MiA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0MyAwLjk4NTQ3IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0NyAxLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjM0NTcyIDEuNzM4OSA0LjU0NDUgNC41NDQ1IDAgMCAxLTQuNTQ0NCA0LjU0NDQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDktNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMy0xLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjk4NDk1LTEuNDc0MyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0My0wLjk4NDk1IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0LTAuMzQ1NzJ6bTQzLjkxNyAwYTQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0IDAuMzQ1NzIgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMgMC45ODQ5NSA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuOTg0OTUgMS40NzQzIDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMyAxLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDkgNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEtNC41NDQ0LTQuNTQ0NCA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuMzQ1NzEtMS43Mzg5IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0Ny0xLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMtMC45ODU0NyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNzM4OS0wLjM0NTcyeiIgc3Ryb2tlLXdpZHRoPSIuNTU2NzEiLz48cGF0aCBkPSJtOTAuMjcgMTY1LjQ3LTkuNDAxNSAxMy41MDVoMjguNzM1di0xMy41MDV6IiBzdHJva2Utd2lkdGg9Ii40OTY2OCIvPjxwYXRoIGQ9Im0zNi4xMTcgMTM5LjI4IDE5LjMwNCAxMC4xNjh2MjMuOTcybC0xOS4zMDQtMTAuNjE2eiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjxwYXRoIGQ9Im03OS43MjkgMTM5LjI4LTE5LjMwNCAxMC4xNjh2MjMuOTcybDE5LjMwNC0xMC42MTZ6IiBzdHJva2Utd2lkdGg9Ii41Ii8+PHJlY3QgdHJhbnNmb3JtPSJtYXRyaXgoLjg4NDYxIC0uNDY2MzMgLjg4NDYxIC40NjYzMyAwIDApIiB4PSItMTIzLjg0IiB5PSIxNjcuNjUiIHdpZHRoPSIyMS42NjUiIGhlaWdodD0iMjEuNjY1IiBzdHJva2Utd2lkdGg9Ii43NTgxNiIvPjwvZz48cGF0aCBkPSJtNjguMzgxIDg2LjY2OWMtMy41MzkxIDAuMTQ5MTEtNC44MzI1IDMuNDQxMy00LjYxNTcgNS4wNzQ2IDEuODQ2MiAxMy45MTIgMi45NjI5IDI0LjExNCA0Ljg5NjMgMjQuOTA2IDguNzM3OCAzLjU4MzggMTguNTQ0IDcuNDgyMSAyOC44MSAxMS40NTMtMi4xMDEyIDMuNjEyMi01LjA4MzIgOC43NDM0LTcuNzYyMyAxMy4zODQtMi44Njk1IDQuOTcwMSAwLjk4MzU1IDYuNDg3NiAzLjU2NjIgNy4yMjkgOC43NjUxIDIuNTE2NCAxMC4wMDYtMS40MDQ2IDIyLjcyNC0xMy41NjUgMTEuMjIgNC4yMDI4IDIyLjU1MiA4LjMyOTYgMzMuMjk4IDEyLjA4OSAyLjU4MiAwLjkwMzIzIDUuOTYyOS0xLjA5MzMgNy40ODMzLTMuMzY3MiAxLjg2MTUtMi43ODQyIDQuNzA4My0xMi4yNjgtNS40ODk2LTIyLjIwOS0yLjEwMTQtMi4wNDg1LTQuNTkxNS00LjA3OS03LjMyNTYtNS4xNTI3LTE5LjcyNC03Ljc0NS02MS42NDYtMTUuODU2LTYxLjY0Ni0xNS44NTYtNC40MDktNS40MzQtNy40MTE0LTE0LjI2LTEzLjkzOC0xMy45ODV6Ii8+PHBhdGggZD0ibTEwNS43NCA5MS43NjZjLTUuMzU4OCAwLTkuNTY5LTEuMDkxOC03LjUwNTcgNi4zODgyIDAuMTI5MDkgMC40NjggMC40MDYyNyAwLjk5NTMgMC41OTg5MyAxLjQ2OTdsMjQuMjM5IDYuNDk0Ny04LjUxNy0xMi4yNDNjLTEuNDA2OC0yLjAyMjMtNC42MDg4LTIuMTA5Mi04LjgxNTUtMi4xMDkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjczLjYwM21tIiBoZWlnaHQ9IjkzLjA4MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3My42MDMgOTMuMDgxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02OC4wMTUgLTk4LjMwMSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIxOC40MSAtMjAuODgpIj48cmVjdCB4PSItMTQ3Ljk5IiB5PSIxMzUuNDQiIHdpZHRoPSI2OC43OTIiIGhlaWdodD0iNzQuNDE4IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MTA5Ii8+PGc+PHJlY3QgeD0iLTE0Ny4yNiIgeT0iMjA0LjY3IiB3aWR0aD0iNjYuMzg2IiBoZWlnaHQ9IjMuNzUwNiIvPjxwYXRoIGQ9Im0tMTEzLjYgMTE5LjE4YTM2LjgwMSAxNi4zNjYgMCAwIDAtMzYuNTUyIDE0LjU2NGg3My4xMDRhMzYuODAxIDE2LjM2NiAwIDAgMC0zNi41NTItMTQuNTY0eiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLW9wYWNpdHk9Ii41IiBzdHJva2Utd2lkdGg9IjQuOTQ2MyIvPjxyZWN0IHg9Ii0xNTAuNCIgeT0iMTMwLjU0IiB3aWR0aD0iNzMuNjAzIiBoZWlnaHQ9IjUuMDA2OCIgcnk9IjIuMDE4MiIvPjwvZz48ZyB0cmFuc2Zvcm09Im1hdHJpeCguNjIzMTQgMCAwIC42MjMxNCAtMTU2LjQ0IDkxLjg3OCkiPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.27" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="231,113,72,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS4wMW1tIiBoZWlnaHQ9IjE5OS42OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuMDEgMTk5LjY5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMi45MDMgLTQ1LjEyNSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDc4LjIxNSkiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iNi45MDE0IiBzdHJva2Utd2lkdGg9IjQuOTg0OSIvPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iMTQuNjU0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNy4xMDQiLz48L2c+PGcgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iNDAuMjc0IiB5PSIxNTguNzQiIHdpZHRoPSI5Mi4xNSIgaGVpZ2h0PSI0MC4zMjYiIHN0cm9rZS13aWR0aD0iOC43Mjg3Ii8+PHJlY3QgeD0iMzcuNzkzIiB5PSIxNTUuODQiIHdpZHRoPSIxMi42MjUiIGhlaWdodD0iNDMuMjI3IiByeT0iNS45OTA3IiBzdHJva2Utd2lkdGg9IjguMjM3OCIvPjxyZWN0IHg9IjM0LjU4OCIgeT0iMTY2LjgyIiB3aWR0aD0iNy4wNDgiIGhlaWdodD0iMjQuMTMzIiByeT0iMy4zNDQ1IiBzdHJva2Utd2lkdGg9IjQuNTk5Ii8+PHJlY3QgeD0iNDQuMzUzIiB5PSIxNDMuNzUiIHdpZHRoPSIyMi45OTUiIGhlaWdodD0iMjQuMTMxIiByeT0iMCIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxjaXJjbGUgY3g9IjEwOC4xMSIgY3k9IjU3LjQ1OSIgcj0iMTIuMzM0IiBzdHJva2Utd2lkdGg9IjguNDU2Ii8+PGNpcmNsZSBjeD0iMTA4LjgiIGN5PSI4Ni4yMzUiIHI9IjE4Ljg2MiIgc3Ryb2tlLXdpZHRoPSIxMi45MzEiLz48Y2lyY2xlIGN4PSI5My4zMzciIGN5PSIxMDYuODgiIHI9IjE3LjYxOCIgc3Ryb2tlLXdpZHRoPSIxMi4wNzkiLz48cGF0aCBkPSJtNTAuMjI4IDEzNS45NmgxMy4yMzJzMy4wNDk5LTcuNDkyOSA2LjA5MzMtOS44ODQxYzIuODc4My0yLjI2MTUgNy4wNzQ2LTMuOTQ4NCAxMC40NDYtMy4zODc1IDMuMTYyOSAwLjUyNjE1IDYuMzE0MS0wLjg1OTYyIDcuNTA0MyAxLjQ2OTcgMC4xNjY3OSAwLjMyNjQyLTAuMjE2NTEgMC44MzE1MyAxLjM1MjggMC45NTIzOSAwLjc5NDU2IDAuMDYxMi0wLjA4NTQxLTAuODMzOTUgMy4xNTI0LTAuNjYzMTMgMi41MTU0IDAuMTMyNyAxLjQ2Ni00LjAyNzMgMS40NjYtNC4wMjczcy0zLjAxNzktMTEuODQ4LTcuNTUxNi0xNS4yNjNjLTIuMzUwOS0xLjc3MTEtMi41MTYyLTIuNDExMi0yLjY2MTMtNS4zNTEtMy44MzQ5LTMuNzM5Ny0xMy4wMjYgMS4wNTA0LTE0LjQ5NSAzLjI2NTItMS40MTU4IDIuMTg3MS0yLjI3MTQgNC4wMzUyLTMuODMxOSA1LjcxNjktMC45NDE3OCAxLjAxNDktMi40ODkxIDEuNDE5MS0zLjI2OCAyLjU2MzgtMC45NjA1MyAxLjQxMTUtMC42MDk5NyAzLjQyOTQtMS40NjIgNC45MDg5LTAuODE4MDkgMS40MjA2LTIuMzIgMi4zMjI2LTMuMzcyMSAzLjU3OTctMS42OTc5IDIuMDI4OC0zLjY2MzIgMy45NTMtNC43MjggNi4zNzQ4LTEuMzMxNCAzLjAyODItMS44NzcyIDkuNzQ0OC0xLjg3NzIgOS43NDQ4eiIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxwYXRoIGQ9Im0xMzkuNDggMTUxLjQ3djQ3LjM3NGgzNy4wMzlsMS40MDI1LTEuNDAyNXYtNDUuOTcyem0xMC4yNzIgNS4zNTg4aDEzLjE4OHYxNi40MDdoLTEzLjE4OHoiIHN0cm9rZS13aWR0aD0iOC41NjYzIi8+PHJlY3QgeD0iMTM0LjQ3IiB5PSIxMzkuMjIiIHdpZHRoPSI0OS40NCIgaGVpZ2h0PSIxNi43MDciIHJ5PSI0LjgwNDIiIHN0cm9rZS13aWR0aD0iNy4zMTYiLz48cGF0aCBkPSJtMTcxLjk3IDE5NC4zdjkuMDg2OGg1LjFlLTRsNS45NDU5LTUuOTQ1OXYtMy4xNDA5eiIgc3Ryb2tlLXdpZHRoPSI4LjQ3ODIiLz48cGF0aCBkPSJtMzguNDggMjAzLjM5djE5Ljc1OGgxMS4zMzlhMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2Mi0xMS4xOTcgMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2NyAxMS4xOTdoMTEuNTYyYTE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjItMTEuMTk3IDE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjggMTEuMTk3aDkuNTk3N2ExNC41OCAxNC42NTQgMCAwIDEgMTQuMTYyLTExLjE5NyAxNC41OCAxNC42NTQgMCAwIDEgMTQuMTY4IDExLjE5N2gxNy42OTZ2LTE5Ljc1OHoiIHN0cm9rZS13aWR0aD0iOC40MTA1Ii8+PHJlY3QgeD0iMjIuOTAzIiB5PSIyMTIuMTgiIHdpZHRoPSIyNS4yNDMiIGhlaWdodD0iMTkuMjU1IiBzdHJva2Utd2lkdGg9IjcuODUwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjE0LjY1NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjcuMTA0Ii8+PC9nPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIuOTQxODEiPjxwYXRoIGQ9Im0xMjUuMTkgMjI2LjYxaDMyLjkwNCIvPjxwYXRoIGQ9Im0xNDEuNjQgMjEwLjE2djMyLjkwNCIvPjxwYXRoIGQ9Im0xNTMuMjcgMjM4LjI0LTIzLjI2Ny0yMy4yNjciLz48cGF0aCBkPSJtMTQ4LjE3IDI0MS43MS0xMy4wNjQtMzAuMTk5Ii8+PHBhdGggZD0ibTEzNS4xMSAyNDEuNzEgMTMuMDY0LTMwLjE5OSIvPjxwYXRoIGQ9Im0xMjYuMiAyMzIuMjkgMzAuODc2LTExLjM3MiIvPjxwYXRoIGQ9Im0xMjYuMiAyMjAuOTIgMzAuODc2IDExLjM3MiIvPjwvZz48Zz48cmVjdCB4PSIzOC40OCIgeT0iMTkwLjg2IiB3aWR0aD0iNi4zMTIzIiBoZWlnaHQ9IjIxLjc2Ii8+PHBhdGggZD0ibTUzLjQ1IDE1MC4xcy04LjgxNTYtMi42NTY2LTkuMDk3OC02LjM0MjZjLTAuMTU4NDUtMi4wNyAyLjQ1OTctMy45NTY4IDQuNTA3Ni00LjI5ODEgMi44MTc1LTAuNDY5NTUgNC45Mjc5IDMuNTk1NyA3Ljc4NDMgMy41ODI3IDIuNjUzNC0wLjAxMjEgNC42MDY3LTMuOTUyNyA3LjIwMDYtMy4zOTM3IDEuNzU5MyAwLjM3OTE1IDMuNTAyMyAyLjM4NzYgMy41MDIzIDQuMTA5MSAwIDUuMDkyLTEzLjg5NyA2LjM0MjYtMTMuODk3IDYuMzQyNnoiLz48Y2lyY2xlIGN4PSIxMDMuNTIiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48L2c+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNDAuMDk1KSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSI2LjkwMTQiIHN0cm9rZS13aWR0aD0iNC45ODQ5Ii8+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSIxNC42NTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI3LjEwNCIvPjwvZz48cGF0aCBkPSJtMTUzLjI3IDIxNC45Ny0yMy4yNjcgMjMuMjY3IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iLjk0MTgxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.35402" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxyZWN0IHg9IjE1NS4xMSIgeT0iODUuMTY0IiB3aWR0aD0iOC41NjA5IiBoZWlnaHQ9Ijc4Ljc5Ii8+PHJlY3QgdHJhbnNmb3JtPSJyb3RhdGUoLTkwKSIgeD0iLTkzLjg1OSIgeT0iMTExLjI5IiB3aWR0aD0iOC42OTUzIiBoZWlnaHQ9IjY2LjQ3Ii8+PHBhdGggZD0ibTQwLjI4MyA4My41NDFjLTQuNDczNCAwLTguMDc1IDMuNjAxNi04LjA3NSA4LjA3NXY1Mi4yMTNjMCA0LjQ3MzQgMy42MDE2IDguMDc1IDguMDc1IDguMDc1aDQuOTI5NHYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE3IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2Nmg0LjkyOTRjNC40NzM0IDAgOC4wNzUtMy42MDE1IDguMDc1LTguMDc1di01Mi4yMTNjMC00LjQ3MzQtMy42MDE1LTguMDc1LTguMDc1LTguMDc1em03LjgzMSA1LjgwOTVoNDEuMjg5YzAuODQxMTIgMCAxLjUxODMgMC42NzcxMyAxLjUxODMgMS41MTgzdjIuMzQ4MmMwIDAuODQxMTItMC42NzcxMyAxLjUxODgtMS41MTgzIDEuNTE4OGgtNDEuMjg5Yy0wLjg0MTEyIDAtMS41MTgzLTAuNjc3NjUtMS41MTgzLTEuNTE4OHYtMi4zNDgyYzAtMC44NDExMiAwLjY3NzEzLTEuNTE4MyAxLjUxODMtMS41MTgzem0tOC4wOTU2IDEzLjI2M2g1Ny40ODF2MTkuNzYxaC01Ny40ODF6bTQuMjAxOCAzMS4zNjhhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMgMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczIDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc2OC0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjgtMy4yNzczem00OS4wNzcgMGEzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc2OCAzLjI3NzMgMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjggMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczLTMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc3My0zLjI3NzN6Ii8+PHBhdGggZD0ibTQzLjMwMiAxNDcuNzNjLTEuNjY2MyAwLTMuMDA4MSAxLjM0MTMtMy4wMDgxIDMuMDA3NnYxNC43OTVjMCAxLjY2NjMgMS4zNDE4IDMuMDA3NiAzLjAwODEgMy4wMDc2aDUwLjkxNGMxLjY2NjMgMCAzLjAwODEtMS4zNDEzIDMuMDA4MS0zLjAwNzZ2LTE0Ljc5NWMwLTEuNjY2My0xLjM0MTgtMy4wMDc2LTMuMDA4MS0zLjAwNzZ6bTMuMjkzOSAwLjcyNzA5aDAuNzA5YzAuNzY2MTggMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE4IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE3IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTcgMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjkgMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIxIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyMS0xLjM4MzQgMS4zODM0LTEuMzgzNHoiLz48cmVjdCB4PSI0NC40NjUiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48cmVjdCB4PSI0MC4xMzEiIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjkxLjYwNyIgeT0iMTc1LjMiIHdpZHRoPSI1Ljc3MzEiIGhlaWdodD0iMTAuNTQ4Ii8+PHJlY3QgeD0iNDQuMTkyIiB5PSIxODAuMDciIHdpZHRoPSI0Ny45OSIgaGVpZ2h0PSI2LjM4NzgiLz48cmVjdCB4PSI4Ny43NDgiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjczLjYwM21tIiBoZWlnaHQ9IjkzLjA4MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3My42MDMgOTMuMDgxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02OC4wMTUgLTk4LjMwMSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIxOC40MSAtMjAuODgpIj48cmVjdCB4PSItMTQ3Ljk5IiB5PSIxMzUuNDQiIHdpZHRoPSI2OC43OTIiIGhlaWdodD0iNzQuNDE4IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MTA5Ii8+PGc+PHJlY3QgeD0iLTE0Ny4yNiIgeT0iMjA0LjY3IiB3aWR0aD0iNjYuMzg2IiBoZWlnaHQ9IjMuNzUwNiIvPjxwYXRoIGQ9Im0tMTEzLjYgMTE5LjE4YTM2LjgwMSAxNi4zNjYgMCAwIDAtMzYuNTUyIDE0LjU2NGg3My4xMDRhMzYuODAxIDE2LjM2NiAwIDAgMC0zNi41NTItMTQuNTY0eiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLW9wYWNpdHk9Ii41IiBzdHJva2Utd2lkdGg9IjQuOTQ2MyIvPjxyZWN0IHg9Ii0xNTAuNCIgeT0iMTMwLjU0IiB3aWR0aD0iNzMuNjAzIiBoZWlnaHQ9IjUuMDA2OCIgcnk9IjIuMDE4MiIvPjwvZz48ZyB0cmFuc2Zvcm09Im1hdHJpeCguNjIzMTQgMCAwIC42MjMxNCAtMTU2LjQ0IDkxLjg3OCkiPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.27" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjkwLjcyNG1tIiBoZWlnaHQ9IjE1MS4xM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5MC43MjQgMTUxLjEzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02NS44NzggLTY3LjgzMikiPjxjaXJjbGUgY3g9IjEzMi4xOCIgY3k9IjkyLjI1OCIgcj0iMjIuMDE0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MjYiLz48Zz48cmVjdCB4PSI2NS44NzgiIHk9IjIxMi42NSIgd2lkdGg9IjcxLjUwNCIgaGVpZ2h0PSI2LjMwODkiLz48cGF0aCB0cmFuc2Zvcm09Im1hdHJpeCgxIDAgMCAzLjEwMjYgNjcuNzMgLTIwOC44OSkiIGQ9Im01Ny40NTEgMTM2Ljc0aC00Ny4xMDJsMjMuNTUxLTQwLjc5MXoiLz48cmVjdCB4PSI5OC4xNTUiIHk9Ijg4Ljc5MiIgd2lkdGg9IjEyLjg5MSIgaGVpZ2h0PSI2LjkzMzQiIHJ5PSIwIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.3617" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="36" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi41bW0iIGhlaWdodD0iMTIyLjg1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi41IDEyMi44NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzYuMTE3IC04Ni42NjIpIj48ZyBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im0xMTguNTQgMTYxLjQ0Yy0yLjI4OTYgMC00LjEzMzEgMS44NDM0LTQuMTMzMSA0LjEzMzF2MjYuNzQ1aC00LjgwMjN2LTkuMDg4M2gtMzAuODgydjEyLjIyNWMwIDMuMTA0OCAyLjUgNS42MDQ4IDUuNjA0OCA1LjYwNDhoMy40MDE5YTguODE3OCA4LjgxNzggMCAwIDAgOC43OTIyIDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkxNy04LjQ1NDNoMjYuMzMzYTguODE3OCA4LjgxNzggMCAwIDAgOC43OTE3IDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkyMi04LjQ1NDNoNC4wMTczYzIuMjg5NiAwIDQuMTMzMS0xLjg0MzQgNC4xMzMxLTQuMTMzMXYtMzEuMzUzYzAtMi4yODk2LTEuODQzNS00LjEzMzEtNC4xMzMxLTQuMTMzMXptLTIyLjAxOCAzNC43MTJhNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjczODkgMC4zNDU3MiA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0MyAwLjk4NTQ3IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0NyAxLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjM0NTcyIDEuNzM4OSA0LjU0NDUgNC41NDQ1IDAgMCAxLTQuNTQ0NCA0LjU0NDQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDktNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMy0xLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjk4NDk1LTEuNDc0MyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0My0wLjk4NDk1IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0LTAuMzQ1NzJ6bTQzLjkxNyAwYTQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0IDAuMzQ1NzIgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMgMC45ODQ5NSA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuOTg0OTUgMS40NzQzIDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMyAxLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDkgNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEtNC41NDQ0LTQuNTQ0NCA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuMzQ1NzEtMS43Mzg5IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0Ny0xLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMtMC45ODU0NyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNzM4OS0wLjM0NTcyeiIgc3Ryb2tlLXdpZHRoPSIuNTU2NzEiLz48cGF0aCBkPSJtOTAuMjcgMTY1LjQ3LTkuNDAxNSAxMy41MDVoMjguNzM1di0xMy41MDV6IiBzdHJva2Utd2lkdGg9Ii40OTY2OCIvPjxwYXRoIGQ9Im0zNi4xMTcgMTM5LjI4IDE5LjMwNCAxMC4xNjh2MjMuOTcybC0xOS4zMDQtMTAuNjE2eiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjxwYXRoIGQ9Im03OS43MjkgMTM5LjI4LTE5LjMwNCAxMC4xNjh2MjMuOTcybDE5LjMwNC0xMC42MTZ6IiBzdHJva2Utd2lkdGg9Ii41Ii8+PHJlY3QgdHJhbnNmb3JtPSJtYXRyaXgoLjg4NDYxIC0uNDY2MzMgLjg4NDYxIC40NjYzMyAwIDApIiB4PSItMTIzLjg0IiB5PSIxNjcuNjUiIHdpZHRoPSIyMS42NjUiIGhlaWdodD0iMjEuNjY1IiBzdHJva2Utd2lkdGg9Ii43NTgxNiIvPjwvZz48cGF0aCBkPSJtNjguMzgxIDg2LjY2OWMtMy41MzkxIDAuMTQ5MTEtNC44MzI1IDMuNDQxMy00LjYxNTcgNS4wNzQ2IDEuODQ2MiAxMy45MTIgMi45NjI5IDI0LjExNCA0Ljg5NjMgMjQuOTA2IDguNzM3OCAzLjU4MzggMTguNTQ0IDcuNDgyMSAyOC44MSAxMS40NTMtMi4xMDEyIDMuNjEyMi01LjA4MzIgOC43NDM0LTcuNzYyMyAxMy4zODQtMi44Njk1IDQuOTcwMSAwLjk4MzU1IDYuNDg3NiAzLjU2NjIgNy4yMjkgOC43NjUxIDIuNTE2NCAxMC4wMDYtMS40MDQ2IDIyLjcyNC0xMy41NjUgMTEuMjIgNC4yMDI4IDIyLjU1MiA4LjMyOTYgMzMuMjk4IDEyLjA4OSAyLjU4MiAwLjkwMzIzIDUuOTYyOS0xLjA5MzMgNy40ODMzLTMuMzY3MiAxLjg2MTUtMi43ODQyIDQuNzA4My0xMi4yNjgtNS40ODk2LTIyLjIwOS0yLjEwMTQtMi4wNDg1LTQuNTkxNS00LjA3OS03LjMyNTYtNS4xNTI3LTE5LjcyNC03Ljc0NS02MS42NDYtMTUuODU2LTYxLjY0Ni0xNS44NTYtNC40MDktNS40MzQtNy40MTE0LTE0LjI2LTEzLjkzOC0xMy45ODV6Ii8+PHBhdGggZD0ibTEwNS43NCA5MS43NjZjLTUuMzU4OCAwLTkuNTY5LTEuMDkxOC03LjUwNTcgNi4zODgyIDAuMTI5MDkgMC40NjggMC40MDYyNyAwLjk5NTMgMC41OTg5MyAxLjQ2OTdsMjQuMjM5IDYuNDk0Ny04LjUxNy0xMi4yNDNjLTEuNDA2OC0yLjAyMjMtNC42MDg4LTIuMTA5Mi04LjgxNTUtMi4xMDkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="37" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="38" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS4wMW1tIiBoZWlnaHQ9IjE5OS42OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuMDEgMTk5LjY5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMi45MDMgLTQ1LjEyNSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDc4LjIxNSkiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iNi45MDE0IiBzdHJva2Utd2lkdGg9IjQuOTg0OSIvPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iMTQuNjU0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNy4xMDQiLz48L2c+PGcgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iNDAuMjc0IiB5PSIxNTguNzQiIHdpZHRoPSI5Mi4xNSIgaGVpZ2h0PSI0MC4zMjYiIHN0cm9rZS13aWR0aD0iOC43Mjg3Ii8+PHJlY3QgeD0iMzcuNzkzIiB5PSIxNTUuODQiIHdpZHRoPSIxMi42MjUiIGhlaWdodD0iNDMuMjI3IiByeT0iNS45OTA3IiBzdHJva2Utd2lkdGg9IjguMjM3OCIvPjxyZWN0IHg9IjM0LjU4OCIgeT0iMTY2LjgyIiB3aWR0aD0iNy4wNDgiIGhlaWdodD0iMjQuMTMzIiByeT0iMy4zNDQ1IiBzdHJva2Utd2lkdGg9IjQuNTk5Ii8+PHJlY3QgeD0iNDQuMzUzIiB5PSIxNDMuNzUiIHdpZHRoPSIyMi45OTUiIGhlaWdodD0iMjQuMTMxIiByeT0iMCIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxjaXJjbGUgY3g9IjEwOC4xMSIgY3k9IjU3LjQ1OSIgcj0iMTIuMzM0IiBzdHJva2Utd2lkdGg9IjguNDU2Ii8+PGNpcmNsZSBjeD0iMTA4LjgiIGN5PSI4Ni4yMzUiIHI9IjE4Ljg2MiIgc3Ryb2tlLXdpZHRoPSIxMi45MzEiLz48Y2lyY2xlIGN4PSI5My4zMzciIGN5PSIxMDYuODgiIHI9IjE3LjYxOCIgc3Ryb2tlLXdpZHRoPSIxMi4wNzkiLz48cGF0aCBkPSJtNTAuMjI4IDEzNS45NmgxMy4yMzJzMy4wNDk5LTcuNDkyOSA2LjA5MzMtOS44ODQxYzIuODc4My0yLjI2MTUgNy4wNzQ2LTMuOTQ4NCAxMC40NDYtMy4zODc1IDMuMTYyOSAwLjUyNjE1IDYuMzE0MS0wLjg1OTYyIDcuNTA0MyAxLjQ2OTcgMC4xNjY3OSAwLjMyNjQyLTAuMjE2NTEgMC44MzE1MyAxLjM1MjggMC45NTIzOSAwLjc5NDU2IDAuMDYxMi0wLjA4NTQxLTAuODMzOTUgMy4xNTI0LTAuNjYzMTMgMi41MTU0IDAuMTMyNyAxLjQ2Ni00LjAyNzMgMS40NjYtNC4wMjczcy0zLjAxNzktMTEuODQ4LTcuNTUxNi0xNS4yNjNjLTIuMzUwOS0xLjc3MTEtMi41MTYyLTIuNDExMi0yLjY2MTMtNS4zNTEtMy44MzQ5LTMuNzM5Ny0xMy4wMjYgMS4wNTA0LTE0LjQ5NSAzLjI2NTItMS40MTU4IDIuMTg3MS0yLjI3MTQgNC4wMzUyLTMuODMxOSA1LjcxNjktMC45NDE3OCAxLjAxNDktMi40ODkxIDEuNDE5MS0zLjI2OCAyLjU2MzgtMC45NjA1MyAxLjQxMTUtMC42MDk5NyAzLjQyOTQtMS40NjIgNC45MDg5LTAuODE4MDkgMS40MjA2LTIuMzIgMi4zMjI2LTMuMzcyMSAzLjU3OTctMS42OTc5IDIuMDI4OC0zLjY2MzIgMy45NTMtNC43MjggNi4zNzQ4LTEuMzMxNCAzLjAyODItMS44NzcyIDkuNzQ0OC0xLjg3NzIgOS43NDQ4eiIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxwYXRoIGQ9Im0xMzkuNDggMTUxLjQ3djQ3LjM3NGgzNy4wMzlsMS40MDI1LTEuNDAyNXYtNDUuOTcyem0xMC4yNzIgNS4zNTg4aDEzLjE4OHYxNi40MDdoLTEzLjE4OHoiIHN0cm9rZS13aWR0aD0iOC41NjYzIi8+PHJlY3QgeD0iMTM0LjQ3IiB5PSIxMzkuMjIiIHdpZHRoPSI0OS40NCIgaGVpZ2h0PSIxNi43MDciIHJ5PSI0LjgwNDIiIHN0cm9rZS13aWR0aD0iNy4zMTYiLz48cGF0aCBkPSJtMTcxLjk3IDE5NC4zdjkuMDg2OGg1LjFlLTRsNS45NDU5LTUuOTQ1OXYtMy4xNDA5eiIgc3Ryb2tlLXdpZHRoPSI4LjQ3ODIiLz48cGF0aCBkPSJtMzguNDggMjAzLjM5djE5Ljc1OGgxMS4zMzlhMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2Mi0xMS4xOTcgMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2NyAxMS4xOTdoMTEuNTYyYTE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjItMTEuMTk3IDE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjggMTEuMTk3aDkuNTk3N2ExNC41OCAxNC42NTQgMCAwIDEgMTQuMTYyLTExLjE5NyAxNC41OCAxNC42NTQgMCAwIDEgMTQuMTY4IDExLjE5N2gxNy42OTZ2LTE5Ljc1OHoiIHN0cm9rZS13aWR0aD0iOC40MTA1Ii8+PHJlY3QgeD0iMjIuOTAzIiB5PSIyMTIuMTgiIHdpZHRoPSIyNS4yNDMiIGhlaWdodD0iMTkuMjU1IiBzdHJva2Utd2lkdGg9IjcuODUwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjE0LjY1NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjcuMTA0Ii8+PC9nPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIuOTQxODEiPjxwYXRoIGQ9Im0xMjUuMTkgMjI2LjYxaDMyLjkwNCIvPjxwYXRoIGQ9Im0xNDEuNjQgMjEwLjE2djMyLjkwNCIvPjxwYXRoIGQ9Im0xNTMuMjcgMjM4LjI0LTIzLjI2Ny0yMy4yNjciLz48cGF0aCBkPSJtMTQ4LjE3IDI0MS43MS0xMy4wNjQtMzAuMTk5Ii8+PHBhdGggZD0ibTEzNS4xMSAyNDEuNzEgMTMuMDY0LTMwLjE5OSIvPjxwYXRoIGQ9Im0xMjYuMiAyMzIuMjkgMzAuODc2LTExLjM3MiIvPjxwYXRoIGQ9Im0xMjYuMiAyMjAuOTIgMzAuODc2IDExLjM3MiIvPjwvZz48Zz48cmVjdCB4PSIzOC40OCIgeT0iMTkwLjg2IiB3aWR0aD0iNi4zMTIzIiBoZWlnaHQ9IjIxLjc2Ii8+PHBhdGggZD0ibTUzLjQ1IDE1MC4xcy04LjgxNTYtMi42NTY2LTkuMDk3OC02LjM0MjZjLTAuMTU4NDUtMi4wNyAyLjQ1OTctMy45NTY4IDQuNTA3Ni00LjI5ODEgMi44MTc1LTAuNDY5NTUgNC45Mjc5IDMuNTk1NyA3Ljc4NDMgMy41ODI3IDIuNjUzNC0wLjAxMjEgNC42MDY3LTMuOTUyNyA3LjIwMDYtMy4zOTM3IDEuNzU5MyAwLjM3OTE1IDMuNTAyMyAyLjM4NzYgMy41MDIzIDQuMTA5MSAwIDUuMDkyLTEzLjg5NyA2LjM0MjYtMTMuODk3IDYuMzQyNnoiLz48Y2lyY2xlIGN4PSIxMDMuNTIiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48L2c+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNDAuMDk1KSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSI2LjkwMTQiIHN0cm9rZS13aWR0aD0iNC45ODQ5Ii8+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSIxNC42NTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI3LjEwNCIvPjwvZz48cGF0aCBkPSJtMTUzLjI3IDIxNC45Ny0yMy4yNjcgMjMuMjY3IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iLjk0MTgxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.35402" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="39" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxyZWN0IHg9IjE1NS4xMSIgeT0iODUuMTY0IiB3aWR0aD0iOC41NjA5IiBoZWlnaHQ9Ijc4Ljc5Ii8+PHJlY3QgdHJhbnNmb3JtPSJyb3RhdGUoLTkwKSIgeD0iLTkzLjg1OSIgeT0iMTExLjI5IiB3aWR0aD0iOC42OTUzIiBoZWlnaHQ9IjY2LjQ3Ii8+PHBhdGggZD0ibTQwLjI4MyA4My41NDFjLTQuNDczNCAwLTguMDc1IDMuNjAxNi04LjA3NSA4LjA3NXY1Mi4yMTNjMCA0LjQ3MzQgMy42MDE2IDguMDc1IDguMDc1IDguMDc1aDQuOTI5NHYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE3IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2Nmg0LjkyOTRjNC40NzM0IDAgOC4wNzUtMy42MDE1IDguMDc1LTguMDc1di01Mi4yMTNjMC00LjQ3MzQtMy42MDE1LTguMDc1LTguMDc1LTguMDc1em03LjgzMSA1LjgwOTVoNDEuMjg5YzAuODQxMTIgMCAxLjUxODMgMC42NzcxMyAxLjUxODMgMS41MTgzdjIuMzQ4MmMwIDAuODQxMTItMC42NzcxMyAxLjUxODgtMS41MTgzIDEuNTE4OGgtNDEuMjg5Yy0wLjg0MTEyIDAtMS41MTgzLTAuNjc3NjUtMS41MTgzLTEuNTE4OHYtMi4zNDgyYzAtMC44NDExMiAwLjY3NzEzLTEuNTE4MyAxLjUxODMtMS41MTgzem0tOC4wOTU2IDEzLjI2M2g1Ny40ODF2MTkuNzYxaC01Ny40ODF6bTQuMjAxOCAzMS4zNjhhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMgMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczIDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc2OC0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjgtMy4yNzczem00OS4wNzcgMGEzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc2OCAzLjI3NzMgMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjggMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczLTMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc3My0zLjI3NzN6Ii8+PHBhdGggZD0ibTQzLjMwMiAxNDcuNzNjLTEuNjY2MyAwLTMuMDA4MSAxLjM0MTMtMy4wMDgxIDMuMDA3NnYxNC43OTVjMCAxLjY2NjMgMS4zNDE4IDMuMDA3NiAzLjAwODEgMy4wMDc2aDUwLjkxNGMxLjY2NjMgMCAzLjAwODEtMS4zNDEzIDMuMDA4MS0zLjAwNzZ2LTE0Ljc5NWMwLTEuNjY2My0xLjM0MTgtMy4wMDc2LTMuMDA4MS0zLjAwNzZ6bTMuMjkzOSAwLjcyNzA5aDAuNzA5YzAuNzY2MTggMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE4IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE3IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTcgMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjkgMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIxIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyMS0xLjM4MzQgMS4zODM0LTEuMzgzNHoiLz48cmVjdCB4PSI0NC40NjUiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48cmVjdCB4PSI0MC4xMzEiIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjkxLjYwNyIgeT0iMTc1LjMiIHdpZHRoPSI1Ljc3MzEiIGhlaWdodD0iMTAuNTQ4Ii8+PHJlY3QgeD0iNDQuMTkyIiB5PSIxODAuMDciIHdpZHRoPSI0Ny45OSIgaGVpZ2h0PSI2LjM4NzgiLz48cmVjdCB4PSI4Ny43NDgiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="40" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjczLjYwM21tIiBoZWlnaHQ9IjkzLjA4MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3My42MDMgOTMuMDgxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02OC4wMTUgLTk4LjMwMSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIxOC40MSAtMjAuODgpIj48cmVjdCB4PSItMTQ3Ljk5IiB5PSIxMzUuNDQiIHdpZHRoPSI2OC43OTIiIGhlaWdodD0iNzQuNDE4IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MTA5Ii8+PGc+PHJlY3QgeD0iLTE0Ny4yNiIgeT0iMjA0LjY3IiB3aWR0aD0iNjYuMzg2IiBoZWlnaHQ9IjMuNzUwNiIvPjxwYXRoIGQ9Im0tMTEzLjYgMTE5LjE4YTM2LjgwMSAxNi4zNjYgMCAwIDAtMzYuNTUyIDE0LjU2NGg3My4xMDRhMzYuODAxIDE2LjM2NiAwIDAgMC0zNi41NTItMTQuNTY0eiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLW9wYWNpdHk9Ii41IiBzdHJva2Utd2lkdGg9IjQuOTQ2MyIvPjxyZWN0IHg9Ii0xNTAuNCIgeT0iMTMwLjU0IiB3aWR0aD0iNzMuNjAzIiBoZWlnaHQ9IjUuMDA2OCIgcnk9IjIuMDE4MiIvPjwvZz48ZyB0cmFuc2Zvcm09Im1hdHJpeCguNjIzMTQgMCAwIC42MjMxNCAtMTU2LjQ0IDkxLjg3OCkiPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.27" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="41" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="42" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjkwLjcyNG1tIiBoZWlnaHQ9IjE1MS4xM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5MC43MjQgMTUxLjEzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02NS44NzggLTY3LjgzMikiPjxjaXJjbGUgY3g9IjEzMi4xOCIgY3k9IjkyLjI1OCIgcj0iMjIuMDE0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MjYiLz48Zz48cmVjdCB4PSI2NS44NzgiIHk9IjIxMi42NSIgd2lkdGg9IjcxLjUwNCIgaGVpZ2h0PSI2LjMwODkiLz48cGF0aCB0cmFuc2Zvcm09Im1hdHJpeCgxIDAgMCAzLjEwMjYgNjcuNzMgLTIwOC44OSkiIGQ9Im01Ny40NTEgMTM2Ljc0aC00Ny4xMDJsMjMuNTUxLTQwLjc5MXoiLz48cmVjdCB4PSI5OC4xNTUiIHk9Ijg4Ljc5MiIgd2lkdGg9IjEyLjg5MSIgaGVpZ2h0PSI2LjkzMzQiIHJ5PSIwIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.3617" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="43" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi41bW0iIGhlaWdodD0iMTIyLjg1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi41IDEyMi44NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzYuMTE3IC04Ni42NjIpIj48ZyBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im0xMTguNTQgMTYxLjQ0Yy0yLjI4OTYgMC00LjEzMzEgMS44NDM0LTQuMTMzMSA0LjEzMzF2MjYuNzQ1aC00LjgwMjN2LTkuMDg4M2gtMzAuODgydjEyLjIyNWMwIDMuMTA0OCAyLjUgNS42MDQ4IDUuNjA0OCA1LjYwNDhoMy40MDE5YTguODE3OCA4LjgxNzggMCAwIDAgOC43OTIyIDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkxNy04LjQ1NDNoMjYuMzMzYTguODE3OCA4LjgxNzggMCAwIDAgOC43OTE3IDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkyMi04LjQ1NDNoNC4wMTczYzIuMjg5NiAwIDQuMTMzMS0xLjg0MzQgNC4xMzMxLTQuMTMzMXYtMzEuMzUzYzAtMi4yODk2LTEuODQzNS00LjEzMzEtNC4xMzMxLTQuMTMzMXptLTIyLjAxOCAzNC43MTJhNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjczODkgMC4zNDU3MiA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0MyAwLjk4NTQ3IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0NyAxLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjM0NTcyIDEuNzM4OSA0LjU0NDUgNC41NDQ1IDAgMCAxLTQuNTQ0NCA0LjU0NDQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDktNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMy0xLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjk4NDk1LTEuNDc0MyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0My0wLjk4NDk1IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0LTAuMzQ1NzJ6bTQzLjkxNyAwYTQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0IDAuMzQ1NzIgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMgMC45ODQ5NSA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuOTg0OTUgMS40NzQzIDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMyAxLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDkgNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEtNC41NDQ0LTQuNTQ0NCA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuMzQ1NzEtMS43Mzg5IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0Ny0xLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMtMC45ODU0NyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNzM4OS0wLjM0NTcyeiIgc3Ryb2tlLXdpZHRoPSIuNTU2NzEiLz48cGF0aCBkPSJtOTAuMjcgMTY1LjQ3LTkuNDAxNSAxMy41MDVoMjguNzM1di0xMy41MDV6IiBzdHJva2Utd2lkdGg9Ii40OTY2OCIvPjxwYXRoIGQ9Im0zNi4xMTcgMTM5LjI4IDE5LjMwNCAxMC4xNjh2MjMuOTcybC0xOS4zMDQtMTAuNjE2eiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjxwYXRoIGQ9Im03OS43MjkgMTM5LjI4LTE5LjMwNCAxMC4xNjh2MjMuOTcybDE5LjMwNC0xMC42MTZ6IiBzdHJva2Utd2lkdGg9Ii41Ii8+PHJlY3QgdHJhbnNmb3JtPSJtYXRyaXgoLjg4NDYxIC0uNDY2MzMgLjg4NDYxIC40NjYzMyAwIDApIiB4PSItMTIzLjg0IiB5PSIxNjcuNjUiIHdpZHRoPSIyMS42NjUiIGhlaWdodD0iMjEuNjY1IiBzdHJva2Utd2lkdGg9Ii43NTgxNiIvPjwvZz48cGF0aCBkPSJtNjguMzgxIDg2LjY2OWMtMy41MzkxIDAuMTQ5MTEtNC44MzI1IDMuNDQxMy00LjYxNTcgNS4wNzQ2IDEuODQ2MiAxMy45MTIgMi45NjI5IDI0LjExNCA0Ljg5NjMgMjQuOTA2IDguNzM3OCAzLjU4MzggMTguNTQ0IDcuNDgyMSAyOC44MSAxMS40NTMtMi4xMDEyIDMuNjEyMi01LjA4MzIgOC43NDM0LTcuNzYyMyAxMy4zODQtMi44Njk1IDQuOTcwMSAwLjk4MzU1IDYuNDg3NiAzLjU2NjIgNy4yMjkgOC43NjUxIDIuNTE2NCAxMC4wMDYtMS40MDQ2IDIyLjcyNC0xMy41NjUgMTEuMjIgNC4yMDI4IDIyLjU1MiA4LjMyOTYgMzMuMjk4IDEyLjA4OSAyLjU4MiAwLjkwMzIzIDUuOTYyOS0xLjA5MzMgNy40ODMzLTMuMzY3MiAxLjg2MTUtMi43ODQyIDQuNzA4My0xMi4yNjgtNS40ODk2LTIyLjIwOS0yLjEwMTQtMi4wNDg1LTQuNTkxNS00LjA3OS03LjMyNTYtNS4xNTI3LTE5LjcyNC03Ljc0NS02MS42NDYtMTUuODU2LTYxLjY0Ni0xNS44NTYtNC40MDktNS40MzQtNy40MTE0LTE0LjI2LTEzLjkzOC0xMy45ODV6Ii8+PHBhdGggZD0ibTEwNS43NCA5MS43NjZjLTUuMzU4OCAwLTkuNTY5LTEuMDkxOC03LjUwNTcgNi4zODgyIDAuMTI5MDkgMC40NjggMC40MDYyNyAwLjk5NTMgMC41OTg5MyAxLjQ2OTdsMjQuMjM5IDYuNDk0Ny04LjUxNy0xMi4yNDNjLTEuNDA2OC0yLjAyMjMtNC42MDg4LTIuMTA5Mi04LjgxNTUtMi4xMDkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="44" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="125,139,143,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="45" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi41bW0iIGhlaWdodD0iMTIyLjg1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi41IDEyMi44NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzYuMTE3IC04Ni42NjIpIj48ZyBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im0xMTguNTQgMTYxLjQ0Yy0yLjI4OTYgMC00LjEzMzEgMS44NDM0LTQuMTMzMSA0LjEzMzF2MjYuNzQ1aC00LjgwMjN2LTkuMDg4M2gtMzAuODgydjEyLjIyNWMwIDMuMTA0OCAyLjUgNS42MDQ4IDUuNjA0OCA1LjYwNDhoMy40MDE5YTguODE3OCA4LjgxNzggMCAwIDAgOC43OTIyIDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkxNy04LjQ1NDNoMjYuMzMzYTguODE3OCA4LjgxNzggMCAwIDAgOC43OTE3IDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkyMi04LjQ1NDNoNC4wMTczYzIuMjg5NiAwIDQuMTMzMS0xLjg0MzQgNC4xMzMxLTQuMTMzMXYtMzEuMzUzYzAtMi4yODk2LTEuODQzNS00LjEzMzEtNC4xMzMxLTQuMTMzMXptLTIyLjAxOCAzNC43MTJhNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjczODkgMC4zNDU3MiA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0MyAwLjk4NTQ3IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0NyAxLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjM0NTcyIDEuNzM4OSA0LjU0NDUgNC41NDQ1IDAgMCAxLTQuNTQ0NCA0LjU0NDQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDktNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMy0xLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjk4NDk1LTEuNDc0MyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0My0wLjk4NDk1IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0LTAuMzQ1NzJ6bTQzLjkxNyAwYTQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0IDAuMzQ1NzIgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMgMC45ODQ5NSA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuOTg0OTUgMS40NzQzIDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMyAxLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDkgNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEtNC41NDQ0LTQuNTQ0NCA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuMzQ1NzEtMS43Mzg5IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0Ny0xLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMtMC45ODU0NyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNzM4OS0wLjM0NTcyeiIgc3Ryb2tlLXdpZHRoPSIuNTU2NzEiLz48cGF0aCBkPSJtOTAuMjcgMTY1LjQ3LTkuNDAxNSAxMy41MDVoMjguNzM1di0xMy41MDV6IiBzdHJva2Utd2lkdGg9Ii40OTY2OCIvPjxwYXRoIGQ9Im0zNi4xMTcgMTM5LjI4IDE5LjMwNCAxMC4xNjh2MjMuOTcybC0xOS4zMDQtMTAuNjE2eiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjxwYXRoIGQ9Im03OS43MjkgMTM5LjI4LTE5LjMwNCAxMC4xNjh2MjMuOTcybDE5LjMwNC0xMC42MTZ6IiBzdHJva2Utd2lkdGg9Ii41Ii8+PHJlY3QgdHJhbnNmb3JtPSJtYXRyaXgoLjg4NDYxIC0uNDY2MzMgLjg4NDYxIC40NjYzMyAwIDApIiB4PSItMTIzLjg0IiB5PSIxNjcuNjUiIHdpZHRoPSIyMS42NjUiIGhlaWdodD0iMjEuNjY1IiBzdHJva2Utd2lkdGg9Ii43NTgxNiIvPjwvZz48cGF0aCBkPSJtNjguMzgxIDg2LjY2OWMtMy41MzkxIDAuMTQ5MTEtNC44MzI1IDMuNDQxMy00LjYxNTcgNS4wNzQ2IDEuODQ2MiAxMy45MTIgMi45NjI5IDI0LjExNCA0Ljg5NjMgMjQuOTA2IDguNzM3OCAzLjU4MzggMTguNTQ0IDcuNDgyMSAyOC44MSAxMS40NTMtMi4xMDEyIDMuNjEyMi01LjA4MzIgOC43NDM0LTcuNzYyMyAxMy4zODQtMi44Njk1IDQuOTcwMSAwLjk4MzU1IDYuNDg3NiAzLjU2NjIgNy4yMjkgOC43NjUxIDIuNTE2NCAxMC4wMDYtMS40MDQ2IDIyLjcyNC0xMy41NjUgMTEuMjIgNC4yMDI4IDIyLjU1MiA4LjMyOTYgMzMuMjk4IDEyLjA4OSAyLjU4MiAwLjkwMzIzIDUuOTYyOS0xLjA5MzMgNy40ODMzLTMuMzY3MiAxLjg2MTUtMi43ODQyIDQuNzA4My0xMi4yNjgtNS40ODk2LTIyLjIwOS0yLjEwMTQtMi4wNDg1LTQuNTkxNS00LjA3OS03LjMyNTYtNS4xNTI3LTE5LjcyNC03Ljc0NS02MS42NDYtMTUuODU2LTYxLjY0Ni0xNS44NTYtNC40MDktNS40MzQtNy40MTE0LTE0LjI2LTEzLjkzOC0xMy45ODV6Ii8+PHBhdGggZD0ibTEwNS43NCA5MS43NjZjLTUuMzU4OCAwLTkuNTY5LTEuMDkxOC03LjUwNTcgNi4zODgyIDAuMTI5MDkgMC40NjggMC40MDYyNyAwLjk5NTMgMC41OTg5MyAxLjQ2OTdsMjQuMjM5IDYuNDk0Ny04LjUxNy0xMi4yNDNjLTEuNDA2OC0yLjAyMjMtNC42MDg4LTIuMTA5Mi04LjgxNTUtMi4xMDkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="46" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="152,125,183,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="47" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS4wMW1tIiBoZWlnaHQ9IjE5OS42OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuMDEgMTk5LjY5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMi45MDMgLTQ1LjEyNSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDc4LjIxNSkiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iNi45MDE0IiBzdHJva2Utd2lkdGg9IjQuOTg0OSIvPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iMTQuNjU0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNy4xMDQiLz48L2c+PGcgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iNDAuMjc0IiB5PSIxNTguNzQiIHdpZHRoPSI5Mi4xNSIgaGVpZ2h0PSI0MC4zMjYiIHN0cm9rZS13aWR0aD0iOC43Mjg3Ii8+PHJlY3QgeD0iMzcuNzkzIiB5PSIxNTUuODQiIHdpZHRoPSIxMi42MjUiIGhlaWdodD0iNDMuMjI3IiByeT0iNS45OTA3IiBzdHJva2Utd2lkdGg9IjguMjM3OCIvPjxyZWN0IHg9IjM0LjU4OCIgeT0iMTY2LjgyIiB3aWR0aD0iNy4wNDgiIGhlaWdodD0iMjQuMTMzIiByeT0iMy4zNDQ1IiBzdHJva2Utd2lkdGg9IjQuNTk5Ii8+PHJlY3QgeD0iNDQuMzUzIiB5PSIxNDMuNzUiIHdpZHRoPSIyMi45OTUiIGhlaWdodD0iMjQuMTMxIiByeT0iMCIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxjaXJjbGUgY3g9IjEwOC4xMSIgY3k9IjU3LjQ1OSIgcj0iMTIuMzM0IiBzdHJva2Utd2lkdGg9IjguNDU2Ii8+PGNpcmNsZSBjeD0iMTA4LjgiIGN5PSI4Ni4yMzUiIHI9IjE4Ljg2MiIgc3Ryb2tlLXdpZHRoPSIxMi45MzEiLz48Y2lyY2xlIGN4PSI5My4zMzciIGN5PSIxMDYuODgiIHI9IjE3LjYxOCIgc3Ryb2tlLXdpZHRoPSIxMi4wNzkiLz48cGF0aCBkPSJtNTAuMjI4IDEzNS45NmgxMy4yMzJzMy4wNDk5LTcuNDkyOSA2LjA5MzMtOS44ODQxYzIuODc4My0yLjI2MTUgNy4wNzQ2LTMuOTQ4NCAxMC40NDYtMy4zODc1IDMuMTYyOSAwLjUyNjE1IDYuMzE0MS0wLjg1OTYyIDcuNTA0MyAxLjQ2OTcgMC4xNjY3OSAwLjMyNjQyLTAuMjE2NTEgMC44MzE1MyAxLjM1MjggMC45NTIzOSAwLjc5NDU2IDAuMDYxMi0wLjA4NTQxLTAuODMzOTUgMy4xNTI0LTAuNjYzMTMgMi41MTU0IDAuMTMyNyAxLjQ2Ni00LjAyNzMgMS40NjYtNC4wMjczcy0zLjAxNzktMTEuODQ4LTcuNTUxNi0xNS4yNjNjLTIuMzUwOS0xLjc3MTEtMi41MTYyLTIuNDExMi0yLjY2MTMtNS4zNTEtMy44MzQ5LTMuNzM5Ny0xMy4wMjYgMS4wNTA0LTE0LjQ5NSAzLjI2NTItMS40MTU4IDIuMTg3MS0yLjI3MTQgNC4wMzUyLTMuODMxOSA1LjcxNjktMC45NDE3OCAxLjAxNDktMi40ODkxIDEuNDE5MS0zLjI2OCAyLjU2MzgtMC45NjA1MyAxLjQxMTUtMC42MDk5NyAzLjQyOTQtMS40NjIgNC45MDg5LTAuODE4MDkgMS40MjA2LTIuMzIgMi4zMjI2LTMuMzcyMSAzLjU3OTctMS42OTc5IDIuMDI4OC0zLjY2MzIgMy45NTMtNC43MjggNi4zNzQ4LTEuMzMxNCAzLjAyODItMS44NzcyIDkuNzQ0OC0xLjg3NzIgOS43NDQ4eiIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxwYXRoIGQ9Im0xMzkuNDggMTUxLjQ3djQ3LjM3NGgzNy4wMzlsMS40MDI1LTEuNDAyNXYtNDUuOTcyem0xMC4yNzIgNS4zNTg4aDEzLjE4OHYxNi40MDdoLTEzLjE4OHoiIHN0cm9rZS13aWR0aD0iOC41NjYzIi8+PHJlY3QgeD0iMTM0LjQ3IiB5PSIxMzkuMjIiIHdpZHRoPSI0OS40NCIgaGVpZ2h0PSIxNi43MDciIHJ5PSI0LjgwNDIiIHN0cm9rZS13aWR0aD0iNy4zMTYiLz48cGF0aCBkPSJtMTcxLjk3IDE5NC4zdjkuMDg2OGg1LjFlLTRsNS45NDU5LTUuOTQ1OXYtMy4xNDA5eiIgc3Ryb2tlLXdpZHRoPSI4LjQ3ODIiLz48cGF0aCBkPSJtMzguNDggMjAzLjM5djE5Ljc1OGgxMS4zMzlhMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2Mi0xMS4xOTcgMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2NyAxMS4xOTdoMTEuNTYyYTE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjItMTEuMTk3IDE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjggMTEuMTk3aDkuNTk3N2ExNC41OCAxNC42NTQgMCAwIDEgMTQuMTYyLTExLjE5NyAxNC41OCAxNC42NTQgMCAwIDEgMTQuMTY4IDExLjE5N2gxNy42OTZ2LTE5Ljc1OHoiIHN0cm9rZS13aWR0aD0iOC40MTA1Ii8+PHJlY3QgeD0iMjIuOTAzIiB5PSIyMTIuMTgiIHdpZHRoPSIyNS4yNDMiIGhlaWdodD0iMTkuMjU1IiBzdHJva2Utd2lkdGg9IjcuODUwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjE0LjY1NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjcuMTA0Ii8+PC9nPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIuOTQxODEiPjxwYXRoIGQ9Im0xMjUuMTkgMjI2LjYxaDMyLjkwNCIvPjxwYXRoIGQ9Im0xNDEuNjQgMjEwLjE2djMyLjkwNCIvPjxwYXRoIGQ9Im0xNTMuMjcgMjM4LjI0LTIzLjI2Ny0yMy4yNjciLz48cGF0aCBkPSJtMTQ4LjE3IDI0MS43MS0xMy4wNjQtMzAuMTk5Ii8+PHBhdGggZD0ibTEzNS4xMSAyNDEuNzEgMTMuMDY0LTMwLjE5OSIvPjxwYXRoIGQ9Im0xMjYuMiAyMzIuMjkgMzAuODc2LTExLjM3MiIvPjxwYXRoIGQ9Im0xMjYuMiAyMjAuOTIgMzAuODc2IDExLjM3MiIvPjwvZz48Zz48cmVjdCB4PSIzOC40OCIgeT0iMTkwLjg2IiB3aWR0aD0iNi4zMTIzIiBoZWlnaHQ9IjIxLjc2Ii8+PHBhdGggZD0ibTUzLjQ1IDE1MC4xcy04LjgxNTYtMi42NTY2LTkuMDk3OC02LjM0MjZjLTAuMTU4NDUtMi4wNyAyLjQ1OTctMy45NTY4IDQuNTA3Ni00LjI5ODEgMi44MTc1LTAuNDY5NTUgNC45Mjc5IDMuNTk1NyA3Ljc4NDMgMy41ODI3IDIuNjUzNC0wLjAxMjEgNC42MDY3LTMuOTUyNyA3LjIwMDYtMy4zOTM3IDEuNzU5MyAwLjM3OTE1IDMuNTAyMyAyLjM4NzYgMy41MDIzIDQuMTA5MSAwIDUuMDkyLTEzLjg5NyA2LjM0MjYtMTMuODk3IDYuMzQyNnoiLz48Y2lyY2xlIGN4PSIxMDMuNTIiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48L2c+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNDAuMDk1KSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSI2LjkwMTQiIHN0cm9rZS13aWR0aD0iNC45ODQ5Ii8+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSIxNC42NTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI3LjEwNCIvPjwvZz48cGF0aCBkPSJtMTUzLjI3IDIxNC45Ny0yMy4yNjcgMjMuMjY3IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iLjk0MTgxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.35402" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="48" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxyZWN0IHg9IjE1NS4xMSIgeT0iODUuMTY0IiB3aWR0aD0iOC41NjA5IiBoZWlnaHQ9Ijc4Ljc5Ii8+PHJlY3QgdHJhbnNmb3JtPSJyb3RhdGUoLTkwKSIgeD0iLTkzLjg1OSIgeT0iMTExLjI5IiB3aWR0aD0iOC42OTUzIiBoZWlnaHQ9IjY2LjQ3Ii8+PHBhdGggZD0ibTQwLjI4MyA4My41NDFjLTQuNDczNCAwLTguMDc1IDMuNjAxNi04LjA3NSA4LjA3NXY1Mi4yMTNjMCA0LjQ3MzQgMy42MDE2IDguMDc1IDguMDc1IDguMDc1aDQuOTI5NHYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE3IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2Nmg0LjkyOTRjNC40NzM0IDAgOC4wNzUtMy42MDE1IDguMDc1LTguMDc1di01Mi4yMTNjMC00LjQ3MzQtMy42MDE1LTguMDc1LTguMDc1LTguMDc1em03LjgzMSA1LjgwOTVoNDEuMjg5YzAuODQxMTIgMCAxLjUxODMgMC42NzcxMyAxLjUxODMgMS41MTgzdjIuMzQ4MmMwIDAuODQxMTItMC42NzcxMyAxLjUxODgtMS41MTgzIDEuNTE4OGgtNDEuMjg5Yy0wLjg0MTEyIDAtMS41MTgzLTAuNjc3NjUtMS41MTgzLTEuNTE4OHYtMi4zNDgyYzAtMC44NDExMiAwLjY3NzEzLTEuNTE4MyAxLjUxODMtMS41MTgzem0tOC4wOTU2IDEzLjI2M2g1Ny40ODF2MTkuNzYxaC01Ny40ODF6bTQuMjAxOCAzMS4zNjhhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMgMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczIDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc2OC0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjgtMy4yNzczem00OS4wNzcgMGEzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc2OCAzLjI3NzMgMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjggMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczLTMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc3My0zLjI3NzN6Ii8+PHBhdGggZD0ibTQzLjMwMiAxNDcuNzNjLTEuNjY2MyAwLTMuMDA4MSAxLjM0MTMtMy4wMDgxIDMuMDA3NnYxNC43OTVjMCAxLjY2NjMgMS4zNDE4IDMuMDA3NiAzLjAwODEgMy4wMDc2aDUwLjkxNGMxLjY2NjMgMCAzLjAwODEtMS4zNDEzIDMuMDA4MS0zLjAwNzZ2LTE0Ljc5NWMwLTEuNjY2My0xLjM0MTgtMy4wMDc2LTMuMDA4MS0zLjAwNzZ6bTMuMjkzOSAwLjcyNzA5aDAuNzA5YzAuNzY2MTggMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE4IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE3IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTcgMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjkgMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIxIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyMS0xLjM4MzQgMS4zODM0LTEuMzgzNHoiLz48cmVjdCB4PSI0NC40NjUiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48cmVjdCB4PSI0MC4xMzEiIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjkxLjYwNyIgeT0iMTc1LjMiIHdpZHRoPSI1Ljc3MzEiIGhlaWdodD0iMTAuNTQ4Ii8+PHJlY3QgeD0iNDQuMTkyIiB5PSIxODAuMDciIHdpZHRoPSI0Ny45OSIgaGVpZ2h0PSI2LjM4NzgiLz48cmVjdCB4PSI4Ny43NDgiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="49" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjczLjYwM21tIiBoZWlnaHQ9IjkzLjA4MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3My42MDMgOTMuMDgxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02OC4wMTUgLTk4LjMwMSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIxOC40MSAtMjAuODgpIj48cmVjdCB4PSItMTQ3Ljk5IiB5PSIxMzUuNDQiIHdpZHRoPSI2OC43OTIiIGhlaWdodD0iNzQuNDE4IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MTA5Ii8+PGc+PHJlY3QgeD0iLTE0Ny4yNiIgeT0iMjA0LjY3IiB3aWR0aD0iNjYuMzg2IiBoZWlnaHQ9IjMuNzUwNiIvPjxwYXRoIGQ9Im0tMTEzLjYgMTE5LjE4YTM2LjgwMSAxNi4zNjYgMCAwIDAtMzYuNTUyIDE0LjU2NGg3My4xMDRhMzYuODAxIDE2LjM2NiAwIDAgMC0zNi41NTItMTQuNTY0eiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLW9wYWNpdHk9Ii41IiBzdHJva2Utd2lkdGg9IjQuOTQ2MyIvPjxyZWN0IHg9Ii0xNTAuNCIgeT0iMTMwLjU0IiB3aWR0aD0iNzMuNjAzIiBoZWlnaHQ9IjUuMDA2OCIgcnk9IjIuMDE4MiIvPjwvZz48ZyB0cmFuc2Zvcm09Im1hdHJpeCguNjIzMTQgMCAwIC42MjMxNCAtMTU2LjQ0IDkxLjg3OCkiPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.27" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjkwLjcyNG1tIiBoZWlnaHQ9IjE1MS4xM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5MC43MjQgMTUxLjEzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02NS44NzggLTY3LjgzMikiPjxjaXJjbGUgY3g9IjEzMi4xOCIgY3k9IjkyLjI1OCIgcj0iMjIuMDE0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MjYiLz48Zz48cmVjdCB4PSI2NS44NzgiIHk9IjIxMi42NSIgd2lkdGg9IjcxLjUwNCIgaGVpZ2h0PSI2LjMwODkiLz48cGF0aCB0cmFuc2Zvcm09Im1hdHJpeCgxIDAgMCAzLjEwMjYgNjcuNzMgLTIwOC44OSkiIGQ9Im01Ny40NTEgMTM2Ljc0aC00Ny4xMDJsMjMuNTUxLTQwLjc5MXoiLz48cmVjdCB4PSI5OC4xNTUiIHk9Ijg4Ljc5MiIgd2lkdGg9IjEyLjg5MSIgaGVpZ2h0PSI2LjkzMzQiIHJ5PSIwIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.3617" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="50" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="51" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjkwLjcyNG1tIiBoZWlnaHQ9IjE1MS4xM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5MC43MjQgMTUxLjEzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02NS44NzggLTY3LjgzMikiPjxjaXJjbGUgY3g9IjEzMi4xOCIgY3k9IjkyLjI1OCIgcj0iMjIuMDE0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MjYiLz48Zz48cmVjdCB4PSI2NS44NzgiIHk9IjIxMi42NSIgd2lkdGg9IjcxLjUwNCIgaGVpZ2h0PSI2LjMwODkiLz48cGF0aCB0cmFuc2Zvcm09Im1hdHJpeCgxIDAgMCAzLjEwMjYgNjcuNzMgLTIwOC44OSkiIGQ9Im01Ny40NTEgMTM2Ljc0aC00Ny4xMDJsMjMuNTUxLTQwLjc5MXoiLz48cmVjdCB4PSI5OC4xNTUiIHk9Ijg4Ljc5MiIgd2lkdGg9IjEyLjg5MSIgaGVpZ2h0PSI2LjkzMzQiIHJ5PSIwIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.3617" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="52" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi41bW0iIGhlaWdodD0iMTIyLjg1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi41IDEyMi44NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzYuMTE3IC04Ni42NjIpIj48ZyBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im0xMTguNTQgMTYxLjQ0Yy0yLjI4OTYgMC00LjEzMzEgMS44NDM0LTQuMTMzMSA0LjEzMzF2MjYuNzQ1aC00LjgwMjN2LTkuMDg4M2gtMzAuODgydjEyLjIyNWMwIDMuMTA0OCAyLjUgNS42MDQ4IDUuNjA0OCA1LjYwNDhoMy40MDE5YTguODE3OCA4LjgxNzggMCAwIDAgOC43OTIyIDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkxNy04LjQ1NDNoMjYuMzMzYTguODE3OCA4LjgxNzggMCAwIDAgOC43OTE3IDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkyMi04LjQ1NDNoNC4wMTczYzIuMjg5NiAwIDQuMTMzMS0xLjg0MzQgNC4xMzMxLTQuMTMzMXYtMzEuMzUzYzAtMi4yODk2LTEuODQzNS00LjEzMzEtNC4xMzMxLTQuMTMzMXptLTIyLjAxOCAzNC43MTJhNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjczODkgMC4zNDU3MiA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0MyAwLjk4NTQ3IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0NyAxLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjM0NTcyIDEuNzM4OSA0LjU0NDUgNC41NDQ1IDAgMCAxLTQuNTQ0NCA0LjU0NDQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDktNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMy0xLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjk4NDk1LTEuNDc0MyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0My0wLjk4NDk1IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0LTAuMzQ1NzJ6bTQzLjkxNyAwYTQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0IDAuMzQ1NzIgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMgMC45ODQ5NSA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuOTg0OTUgMS40NzQzIDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMyAxLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDkgNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEtNC41NDQ0LTQuNTQ0NCA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuMzQ1NzEtMS43Mzg5IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0Ny0xLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMtMC45ODU0NyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNzM4OS0wLjM0NTcyeiIgc3Ryb2tlLXdpZHRoPSIuNTU2NzEiLz48cGF0aCBkPSJtOTAuMjcgMTY1LjQ3LTkuNDAxNSAxMy41MDVoMjguNzM1di0xMy41MDV6IiBzdHJva2Utd2lkdGg9Ii40OTY2OCIvPjxwYXRoIGQ9Im0zNi4xMTcgMTM5LjI4IDE5LjMwNCAxMC4xNjh2MjMuOTcybC0xOS4zMDQtMTAuNjE2eiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjxwYXRoIGQ9Im03OS43MjkgMTM5LjI4LTE5LjMwNCAxMC4xNjh2MjMuOTcybDE5LjMwNC0xMC42MTZ6IiBzdHJva2Utd2lkdGg9Ii41Ii8+PHJlY3QgdHJhbnNmb3JtPSJtYXRyaXgoLjg4NDYxIC0uNDY2MzMgLjg4NDYxIC40NjYzMyAwIDApIiB4PSItMTIzLjg0IiB5PSIxNjcuNjUiIHdpZHRoPSIyMS42NjUiIGhlaWdodD0iMjEuNjY1IiBzdHJva2Utd2lkdGg9Ii43NTgxNiIvPjwvZz48cGF0aCBkPSJtNjguMzgxIDg2LjY2OWMtMy41MzkxIDAuMTQ5MTEtNC44MzI1IDMuNDQxMy00LjYxNTcgNS4wNzQ2IDEuODQ2MiAxMy45MTIgMi45NjI5IDI0LjExNCA0Ljg5NjMgMjQuOTA2IDguNzM3OCAzLjU4MzggMTguNTQ0IDcuNDgyMSAyOC44MSAxMS40NTMtMi4xMDEyIDMuNjEyMi01LjA4MzIgOC43NDM0LTcuNzYyMyAxMy4zODQtMi44Njk1IDQuOTcwMSAwLjk4MzU1IDYuNDg3NiAzLjU2NjIgNy4yMjkgOC43NjUxIDIuNTE2NCAxMC4wMDYtMS40MDQ2IDIyLjcyNC0xMy41NjUgMTEuMjIgNC4yMDI4IDIyLjU1MiA4LjMyOTYgMzMuMjk4IDEyLjA4OSAyLjU4MiAwLjkwMzIzIDUuOTYyOS0xLjA5MzMgNy40ODMzLTMuMzY3MiAxLjg2MTUtMi43ODQyIDQuNzA4My0xMi4yNjgtNS40ODk2LTIyLjIwOS0yLjEwMTQtMi4wNDg1LTQuNTkxNS00LjA3OS03LjMyNTYtNS4xNTI3LTE5LjcyNC03Ljc0NS02MS42NDYtMTUuODU2LTYxLjY0Ni0xNS44NTYtNC40MDktNS40MzQtNy40MTE0LTE0LjI2LTEzLjkzOC0xMy45ODV6Ii8+PHBhdGggZD0ibTEwNS43NCA5MS43NjZjLTUuMzU4OCAwLTkuNTY5LTEuMDkxOC03LjUwNTcgNi4zODgyIDAuMTI5MDkgMC40NjggMC40MDYyNyAwLjk5NTMgMC41OTg5MyAxLjQ2OTdsMjQuMjM5IDYuNDk0Ny04LjUxNy0xMi4yNDNjLTEuNDA2OC0yLjAyMjMtNC42MDg4LTIuMTA5Mi04LjgxNTUtMi4xMDkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="53" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="231,113,72,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="54" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS4wMW1tIiBoZWlnaHQ9IjE5OS42OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuMDEgMTk5LjY5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMi45MDMgLTQ1LjEyNSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDc4LjIxNSkiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iNi45MDE0IiBzdHJva2Utd2lkdGg9IjQuOTg0OSIvPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iMTQuNjU0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNy4xMDQiLz48L2c+PGcgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iNDAuMjc0IiB5PSIxNTguNzQiIHdpZHRoPSI5Mi4xNSIgaGVpZ2h0PSI0MC4zMjYiIHN0cm9rZS13aWR0aD0iOC43Mjg3Ii8+PHJlY3QgeD0iMzcuNzkzIiB5PSIxNTUuODQiIHdpZHRoPSIxMi42MjUiIGhlaWdodD0iNDMuMjI3IiByeT0iNS45OTA3IiBzdHJva2Utd2lkdGg9IjguMjM3OCIvPjxyZWN0IHg9IjM0LjU4OCIgeT0iMTY2LjgyIiB3aWR0aD0iNy4wNDgiIGhlaWdodD0iMjQuMTMzIiByeT0iMy4zNDQ1IiBzdHJva2Utd2lkdGg9IjQuNTk5Ii8+PHJlY3QgeD0iNDQuMzUzIiB5PSIxNDMuNzUiIHdpZHRoPSIyMi45OTUiIGhlaWdodD0iMjQuMTMxIiByeT0iMCIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxjaXJjbGUgY3g9IjEwOC4xMSIgY3k9IjU3LjQ1OSIgcj0iMTIuMzM0IiBzdHJva2Utd2lkdGg9IjguNDU2Ii8+PGNpcmNsZSBjeD0iMTA4LjgiIGN5PSI4Ni4yMzUiIHI9IjE4Ljg2MiIgc3Ryb2tlLXdpZHRoPSIxMi45MzEiLz48Y2lyY2xlIGN4PSI5My4zMzciIGN5PSIxMDYuODgiIHI9IjE3LjYxOCIgc3Ryb2tlLXdpZHRoPSIxMi4wNzkiLz48cGF0aCBkPSJtNTAuMjI4IDEzNS45NmgxMy4yMzJzMy4wNDk5LTcuNDkyOSA2LjA5MzMtOS44ODQxYzIuODc4My0yLjI2MTUgNy4wNzQ2LTMuOTQ4NCAxMC40NDYtMy4zODc1IDMuMTYyOSAwLjUyNjE1IDYuMzE0MS0wLjg1OTYyIDcuNTA0MyAxLjQ2OTcgMC4xNjY3OSAwLjMyNjQyLTAuMjE2NTEgMC44MzE1MyAxLjM1MjggMC45NTIzOSAwLjc5NDU2IDAuMDYxMi0wLjA4NTQxLTAuODMzOTUgMy4xNTI0LTAuNjYzMTMgMi41MTU0IDAuMTMyNyAxLjQ2Ni00LjAyNzMgMS40NjYtNC4wMjczcy0zLjAxNzktMTEuODQ4LTcuNTUxNi0xNS4yNjNjLTIuMzUwOS0xLjc3MTEtMi41MTYyLTIuNDExMi0yLjY2MTMtNS4zNTEtMy44MzQ5LTMuNzM5Ny0xMy4wMjYgMS4wNTA0LTE0LjQ5NSAzLjI2NTItMS40MTU4IDIuMTg3MS0yLjI3MTQgNC4wMzUyLTMuODMxOSA1LjcxNjktMC45NDE3OCAxLjAxNDktMi40ODkxIDEuNDE5MS0zLjI2OCAyLjU2MzgtMC45NjA1MyAxLjQxMTUtMC42MDk5NyAzLjQyOTQtMS40NjIgNC45MDg5LTAuODE4MDkgMS40MjA2LTIuMzIgMi4zMjI2LTMuMzcyMSAzLjU3OTctMS42OTc5IDIuMDI4OC0zLjY2MzIgMy45NTMtNC43MjggNi4zNzQ4LTEuMzMxNCAzLjAyODItMS44NzcyIDkuNzQ0OC0xLjg3NzIgOS43NDQ4eiIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxwYXRoIGQ9Im0xMzkuNDggMTUxLjQ3djQ3LjM3NGgzNy4wMzlsMS40MDI1LTEuNDAyNXYtNDUuOTcyem0xMC4yNzIgNS4zNTg4aDEzLjE4OHYxNi40MDdoLTEzLjE4OHoiIHN0cm9rZS13aWR0aD0iOC41NjYzIi8+PHJlY3QgeD0iMTM0LjQ3IiB5PSIxMzkuMjIiIHdpZHRoPSI0OS40NCIgaGVpZ2h0PSIxNi43MDciIHJ5PSI0LjgwNDIiIHN0cm9rZS13aWR0aD0iNy4zMTYiLz48cGF0aCBkPSJtMTcxLjk3IDE5NC4zdjkuMDg2OGg1LjFlLTRsNS45NDU5LTUuOTQ1OXYtMy4xNDA5eiIgc3Ryb2tlLXdpZHRoPSI4LjQ3ODIiLz48cGF0aCBkPSJtMzguNDggMjAzLjM5djE5Ljc1OGgxMS4zMzlhMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2Mi0xMS4xOTcgMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2NyAxMS4xOTdoMTEuNTYyYTE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjItMTEuMTk3IDE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjggMTEuMTk3aDkuNTk3N2ExNC41OCAxNC42NTQgMCAwIDEgMTQuMTYyLTExLjE5NyAxNC41OCAxNC42NTQgMCAwIDEgMTQuMTY4IDExLjE5N2gxNy42OTZ2LTE5Ljc1OHoiIHN0cm9rZS13aWR0aD0iOC40MTA1Ii8+PHJlY3QgeD0iMjIuOTAzIiB5PSIyMTIuMTgiIHdpZHRoPSIyNS4yNDMiIGhlaWdodD0iMTkuMjU1IiBzdHJva2Utd2lkdGg9IjcuODUwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjE0LjY1NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjcuMTA0Ii8+PC9nPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIuOTQxODEiPjxwYXRoIGQ9Im0xMjUuMTkgMjI2LjYxaDMyLjkwNCIvPjxwYXRoIGQ9Im0xNDEuNjQgMjEwLjE2djMyLjkwNCIvPjxwYXRoIGQ9Im0xNTMuMjcgMjM4LjI0LTIzLjI2Ny0yMy4yNjciLz48cGF0aCBkPSJtMTQ4LjE3IDI0MS43MS0xMy4wNjQtMzAuMTk5Ii8+PHBhdGggZD0ibTEzNS4xMSAyNDEuNzEgMTMuMDY0LTMwLjE5OSIvPjxwYXRoIGQ9Im0xMjYuMiAyMzIuMjkgMzAuODc2LTExLjM3MiIvPjxwYXRoIGQ9Im0xMjYuMiAyMjAuOTIgMzAuODc2IDExLjM3MiIvPjwvZz48Zz48cmVjdCB4PSIzOC40OCIgeT0iMTkwLjg2IiB3aWR0aD0iNi4zMTIzIiBoZWlnaHQ9IjIxLjc2Ii8+PHBhdGggZD0ibTUzLjQ1IDE1MC4xcy04LjgxNTYtMi42NTY2LTkuMDk3OC02LjM0MjZjLTAuMTU4NDUtMi4wNyAyLjQ1OTctMy45NTY4IDQuNTA3Ni00LjI5ODEgMi44MTc1LTAuNDY5NTUgNC45Mjc5IDMuNTk1NyA3Ljc4NDMgMy41ODI3IDIuNjUzNC0wLjAxMjEgNC42MDY3LTMuOTUyNyA3LjIwMDYtMy4zOTM3IDEuNzU5MyAwLjM3OTE1IDMuNTAyMyAyLjM4NzYgMy41MDIzIDQuMTA5MSAwIDUuMDkyLTEzLjg5NyA2LjM0MjYtMTMuODk3IDYuMzQyNnoiLz48Y2lyY2xlIGN4PSIxMDMuNTIiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48L2c+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNDAuMDk1KSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSI2LjkwMTQiIHN0cm9rZS13aWR0aD0iNC45ODQ5Ii8+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSIxNC42NTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI3LjEwNCIvPjwvZz48cGF0aCBkPSJtMTUzLjI3IDIxNC45Ny0yMy4yNjcgMjMuMjY3IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iLjk0MTgxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.35402" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="55" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxyZWN0IHg9IjE1NS4xMSIgeT0iODUuMTY0IiB3aWR0aD0iOC41NjA5IiBoZWlnaHQ9Ijc4Ljc5Ii8+PHJlY3QgdHJhbnNmb3JtPSJyb3RhdGUoLTkwKSIgeD0iLTkzLjg1OSIgeT0iMTExLjI5IiB3aWR0aD0iOC42OTUzIiBoZWlnaHQ9IjY2LjQ3Ii8+PHBhdGggZD0ibTQwLjI4MyA4My41NDFjLTQuNDczNCAwLTguMDc1IDMuNjAxNi04LjA3NSA4LjA3NXY1Mi4yMTNjMCA0LjQ3MzQgMy42MDE2IDguMDc1IDguMDc1IDguMDc1aDQuOTI5NHYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE3IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2Nmg0LjkyOTRjNC40NzM0IDAgOC4wNzUtMy42MDE1IDguMDc1LTguMDc1di01Mi4yMTNjMC00LjQ3MzQtMy42MDE1LTguMDc1LTguMDc1LTguMDc1em03LjgzMSA1LjgwOTVoNDEuMjg5YzAuODQxMTIgMCAxLjUxODMgMC42NzcxMyAxLjUxODMgMS41MTgzdjIuMzQ4MmMwIDAuODQxMTItMC42NzcxMyAxLjUxODgtMS41MTgzIDEuNTE4OGgtNDEuMjg5Yy0wLjg0MTEyIDAtMS41MTgzLTAuNjc3NjUtMS41MTgzLTEuNTE4OHYtMi4zNDgyYzAtMC44NDExMiAwLjY3NzEzLTEuNTE4MyAxLjUxODMtMS41MTgzem0tOC4wOTU2IDEzLjI2M2g1Ny40ODF2MTkuNzYxaC01Ny40ODF6bTQuMjAxOCAzMS4zNjhhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMgMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczIDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc2OC0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjgtMy4yNzczem00OS4wNzcgMGEzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc2OCAzLjI3NzMgMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjggMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczLTMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc3My0zLjI3NzN6Ii8+PHBhdGggZD0ibTQzLjMwMiAxNDcuNzNjLTEuNjY2MyAwLTMuMDA4MSAxLjM0MTMtMy4wMDgxIDMuMDA3NnYxNC43OTVjMCAxLjY2NjMgMS4zNDE4IDMuMDA3NiAzLjAwODEgMy4wMDc2aDUwLjkxNGMxLjY2NjMgMCAzLjAwODEtMS4zNDEzIDMuMDA4MS0zLjAwNzZ2LTE0Ljc5NWMwLTEuNjY2My0xLjM0MTgtMy4wMDc2LTMuMDA4MS0zLjAwNzZ6bTMuMjkzOSAwLjcyNzA5aDAuNzA5YzAuNzY2MTggMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE4IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE3IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTcgMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjkgMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIxIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyMS0xLjM4MzQgMS4zODM0LTEuMzgzNHoiLz48cmVjdCB4PSI0NC40NjUiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48cmVjdCB4PSI0MC4xMzEiIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjkxLjYwNyIgeT0iMTc1LjMiIHdpZHRoPSI1Ljc3MzEiIGhlaWdodD0iMTAuNTQ4Ii8+PHJlY3QgeD0iNDQuMTkyIiB5PSIxODAuMDciIHdpZHRoPSI0Ny45OSIgaGVpZ2h0PSI2LjM4NzgiLz48cmVjdCB4PSI4Ny43NDgiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="56" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjczLjYwM21tIiBoZWlnaHQ9IjkzLjA4MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3My42MDMgOTMuMDgxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02OC4wMTUgLTk4LjMwMSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIxOC40MSAtMjAuODgpIj48cmVjdCB4PSItMTQ3Ljk5IiB5PSIxMzUuNDQiIHdpZHRoPSI2OC43OTIiIGhlaWdodD0iNzQuNDE4IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MTA5Ii8+PGc+PHJlY3QgeD0iLTE0Ny4yNiIgeT0iMjA0LjY3IiB3aWR0aD0iNjYuMzg2IiBoZWlnaHQ9IjMuNzUwNiIvPjxwYXRoIGQ9Im0tMTEzLjYgMTE5LjE4YTM2LjgwMSAxNi4zNjYgMCAwIDAtMzYuNTUyIDE0LjU2NGg3My4xMDRhMzYuODAxIDE2LjM2NiAwIDAgMC0zNi41NTItMTQuNTY0eiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLW9wYWNpdHk9Ii41IiBzdHJva2Utd2lkdGg9IjQuOTQ2MyIvPjxyZWN0IHg9Ii0xNTAuNCIgeT0iMTMwLjU0IiB3aWR0aD0iNzMuNjAzIiBoZWlnaHQ9IjUuMDA2OCIgcnk9IjIuMDE4MiIvPjwvZz48ZyB0cmFuc2Zvcm09Im1hdHJpeCguNjIzMTQgMCAwIC42MjMxNCAtMTU2LjQ0IDkxLjg3OCkiPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.27" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="57" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="58" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjkwLjcyNG1tIiBoZWlnaHQ9IjE1MS4xM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5MC43MjQgMTUxLjEzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02NS44NzggLTY3LjgzMikiPjxjaXJjbGUgY3g9IjEzMi4xOCIgY3k9IjkyLjI1OCIgcj0iMjIuMDE0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MjYiLz48Zz48cmVjdCB4PSI2NS44NzgiIHk9IjIxMi42NSIgd2lkdGg9IjcxLjUwNCIgaGVpZ2h0PSI2LjMwODkiLz48cGF0aCB0cmFuc2Zvcm09Im1hdHJpeCgxIDAgMCAzLjEwMjYgNjcuNzMgLTIwOC44OSkiIGQ9Im01Ny40NTEgMTM2Ljc0aC00Ny4xMDJsMjMuNTUxLTQwLjc5MXoiLz48cmVjdCB4PSI5OC4xNTUiIHk9Ijg4Ljc5MiIgd2lkdGg9IjEyLjg5MSIgaGVpZ2h0PSI2LjkzMzQiIHJ5PSIwIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.3617" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="59" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi41bW0iIGhlaWdodD0iMTIyLjg1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi41IDEyMi44NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzYuMTE3IC04Ni42NjIpIj48ZyBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im0xMTguNTQgMTYxLjQ0Yy0yLjI4OTYgMC00LjEzMzEgMS44NDM0LTQuMTMzMSA0LjEzMzF2MjYuNzQ1aC00LjgwMjN2LTkuMDg4M2gtMzAuODgydjEyLjIyNWMwIDMuMTA0OCAyLjUgNS42MDQ4IDUuNjA0OCA1LjYwNDhoMy40MDE5YTguODE3OCA4LjgxNzggMCAwIDAgOC43OTIyIDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkxNy04LjQ1NDNoMjYuMzMzYTguODE3OCA4LjgxNzggMCAwIDAgOC43OTE3IDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkyMi04LjQ1NDNoNC4wMTczYzIuMjg5NiAwIDQuMTMzMS0xLjg0MzQgNC4xMzMxLTQuMTMzMXYtMzEuMzUzYzAtMi4yODk2LTEuODQzNS00LjEzMzEtNC4xMzMxLTQuMTMzMXptLTIyLjAxOCAzNC43MTJhNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjczODkgMC4zNDU3MiA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0MyAwLjk4NTQ3IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0NyAxLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjM0NTcyIDEuNzM4OSA0LjU0NDUgNC41NDQ1IDAgMCAxLTQuNTQ0NCA0LjU0NDQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDktNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMy0xLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjk4NDk1LTEuNDc0MyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0My0wLjk4NDk1IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0LTAuMzQ1NzJ6bTQzLjkxNyAwYTQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0IDAuMzQ1NzIgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMgMC45ODQ5NSA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuOTg0OTUgMS40NzQzIDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMyAxLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDkgNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEtNC41NDQ0LTQuNTQ0NCA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuMzQ1NzEtMS43Mzg5IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0Ny0xLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMtMC45ODU0NyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNzM4OS0wLjM0NTcyeiIgc3Ryb2tlLXdpZHRoPSIuNTU2NzEiLz48cGF0aCBkPSJtOTAuMjcgMTY1LjQ3LTkuNDAxNSAxMy41MDVoMjguNzM1di0xMy41MDV6IiBzdHJva2Utd2lkdGg9Ii40OTY2OCIvPjxwYXRoIGQ9Im0zNi4xMTcgMTM5LjI4IDE5LjMwNCAxMC4xNjh2MjMuOTcybC0xOS4zMDQtMTAuNjE2eiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjxwYXRoIGQ9Im03OS43MjkgMTM5LjI4LTE5LjMwNCAxMC4xNjh2MjMuOTcybDE5LjMwNC0xMC42MTZ6IiBzdHJva2Utd2lkdGg9Ii41Ii8+PHJlY3QgdHJhbnNmb3JtPSJtYXRyaXgoLjg4NDYxIC0uNDY2MzMgLjg4NDYxIC40NjYzMyAwIDApIiB4PSItMTIzLjg0IiB5PSIxNjcuNjUiIHdpZHRoPSIyMS42NjUiIGhlaWdodD0iMjEuNjY1IiBzdHJva2Utd2lkdGg9Ii43NTgxNiIvPjwvZz48cGF0aCBkPSJtNjguMzgxIDg2LjY2OWMtMy41MzkxIDAuMTQ5MTEtNC44MzI1IDMuNDQxMy00LjYxNTcgNS4wNzQ2IDEuODQ2MiAxMy45MTIgMi45NjI5IDI0LjExNCA0Ljg5NjMgMjQuOTA2IDguNzM3OCAzLjU4MzggMTguNTQ0IDcuNDgyMSAyOC44MSAxMS40NTMtMi4xMDEyIDMuNjEyMi01LjA4MzIgOC43NDM0LTcuNzYyMyAxMy4zODQtMi44Njk1IDQuOTcwMSAwLjk4MzU1IDYuNDg3NiAzLjU2NjIgNy4yMjkgOC43NjUxIDIuNTE2NCAxMC4wMDYtMS40MDQ2IDIyLjcyNC0xMy41NjUgMTEuMjIgNC4yMDI4IDIyLjU1MiA4LjMyOTYgMzMuMjk4IDEyLjA4OSAyLjU4MiAwLjkwMzIzIDUuOTYyOS0xLjA5MzMgNy40ODMzLTMuMzY3MiAxLjg2MTUtMi43ODQyIDQuNzA4My0xMi4yNjgtNS40ODk2LTIyLjIwOS0yLjEwMTQtMi4wNDg1LTQuNTkxNS00LjA3OS03LjMyNTYtNS4xNTI3LTE5LjcyNC03Ljc0NS02MS42NDYtMTUuODU2LTYxLjY0Ni0xNS44NTYtNC40MDktNS40MzQtNy40MTE0LTE0LjI2LTEzLjkzOC0xMy45ODV6Ii8+PHBhdGggZD0ibTEwNS43NCA5MS43NjZjLTUuMzU4OCAwLTkuNTY5LTEuMDkxOC03LjUwNTcgNi4zODgyIDAuMTI5MDkgMC40NjggMC40MDYyNyAwLjk5NTMgMC41OTg5MyAxLjQ2OTdsMjQuMjM5IDYuNDk0Ny04LjUxNy0xMi4yNDNjLTEuNDA2OC0yLjAyMjMtNC42MDg4LTIuMTA5Mi04LjgxNTUtMi4xMDkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi41bW0iIGhlaWdodD0iMTIyLjg1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi41IDEyMi44NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzYuMTE3IC04Ni42NjIpIj48ZyBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im0xMTguNTQgMTYxLjQ0Yy0yLjI4OTYgMC00LjEzMzEgMS44NDM0LTQuMTMzMSA0LjEzMzF2MjYuNzQ1aC00LjgwMjN2LTkuMDg4M2gtMzAuODgydjEyLjIyNWMwIDMuMTA0OCAyLjUgNS42MDQ4IDUuNjA0OCA1LjYwNDhoMy40MDE5YTguODE3OCA4LjgxNzggMCAwIDAgOC43OTIyIDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkxNy04LjQ1NDNoMjYuMzMzYTguODE3OCA4LjgxNzggMCAwIDAgOC43OTE3IDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkyMi04LjQ1NDNoNC4wMTczYzIuMjg5NiAwIDQuMTMzMS0xLjg0MzQgNC4xMzMxLTQuMTMzMXYtMzEuMzUzYzAtMi4yODk2LTEuODQzNS00LjEzMzEtNC4xMzMxLTQuMTMzMXptLTIyLjAxOCAzNC43MTJhNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjczODkgMC4zNDU3MiA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0MyAwLjk4NTQ3IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0NyAxLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjM0NTcyIDEuNzM4OSA0LjU0NDUgNC41NDQ1IDAgMCAxLTQuNTQ0NCA0LjU0NDQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDktNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMy0xLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjk4NDk1LTEuNDc0MyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0My0wLjk4NDk1IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0LTAuMzQ1NzJ6bTQzLjkxNyAwYTQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0IDAuMzQ1NzIgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMgMC45ODQ5NSA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuOTg0OTUgMS40NzQzIDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMyAxLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDkgNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEtNC41NDQ0LTQuNTQ0NCA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuMzQ1NzEtMS43Mzg5IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0Ny0xLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMtMC45ODU0NyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNzM4OS0wLjM0NTcyeiIgc3Ryb2tlLXdpZHRoPSIuNTU2NzEiLz48cGF0aCBkPSJtOTAuMjcgMTY1LjQ3LTkuNDAxNSAxMy41MDVoMjguNzM1di0xMy41MDV6IiBzdHJva2Utd2lkdGg9Ii40OTY2OCIvPjxwYXRoIGQ9Im0zNi4xMTcgMTM5LjI4IDE5LjMwNCAxMC4xNjh2MjMuOTcybC0xOS4zMDQtMTAuNjE2eiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjxwYXRoIGQ9Im03OS43MjkgMTM5LjI4LTE5LjMwNCAxMC4xNjh2MjMuOTcybDE5LjMwNC0xMC42MTZ6IiBzdHJva2Utd2lkdGg9Ii41Ii8+PHJlY3QgdHJhbnNmb3JtPSJtYXRyaXgoLjg4NDYxIC0uNDY2MzMgLjg4NDYxIC40NjYzMyAwIDApIiB4PSItMTIzLjg0IiB5PSIxNjcuNjUiIHdpZHRoPSIyMS42NjUiIGhlaWdodD0iMjEuNjY1IiBzdHJva2Utd2lkdGg9Ii43NTgxNiIvPjwvZz48cGF0aCBkPSJtNjguMzgxIDg2LjY2OWMtMy41MzkxIDAuMTQ5MTEtNC44MzI1IDMuNDQxMy00LjYxNTcgNS4wNzQ2IDEuODQ2MiAxMy45MTIgMi45NjI5IDI0LjExNCA0Ljg5NjMgMjQuOTA2IDguNzM3OCAzLjU4MzggMTguNTQ0IDcuNDgyMSAyOC44MSAxMS40NTMtMi4xMDEyIDMuNjEyMi01LjA4MzIgOC43NDM0LTcuNzYyMyAxMy4zODQtMi44Njk1IDQuOTcwMSAwLjk4MzU1IDYuNDg3NiAzLjU2NjIgNy4yMjkgOC43NjUxIDIuNTE2NCAxMC4wMDYtMS40MDQ2IDIyLjcyNC0xMy41NjUgMTEuMjIgNC4yMDI4IDIyLjU1MiA4LjMyOTYgMzMuMjk4IDEyLjA4OSAyLjU4MiAwLjkwMzIzIDUuOTYyOS0xLjA5MzMgNy40ODMzLTMuMzY3MiAxLjg2MTUtMi43ODQyIDQuNzA4My0xMi4yNjgtNS40ODk2LTIyLjIwOS0yLjEwMTQtMi4wNDg1LTQuNTkxNS00LjA3OS03LjMyNTYtNS4xNTI3LTE5LjcyNC03Ljc0NS02MS42NDYtMTUuODU2LTYxLjY0Ni0xNS44NTYtNC40MDktNS40MzQtNy40MTE0LTE0LjI2LTEzLjkzOC0xMy45ODV6Ii8+PHBhdGggZD0ibTEwNS43NCA5MS43NjZjLTUuMzU4OCAwLTkuNTY5LTEuMDkxOC03LjUwNTcgNi4zODgyIDAuMTI5MDkgMC40NjggMC40MDYyNyAwLjk5NTMgMC41OTg5MyAxLjQ2OTdsMjQuMjM5IDYuNDk0Ny04LjUxNy0xMi4yNDNjLTEuNDA2OC0yLjAyMjMtNC42MDg4LTIuMTA5Mi04LjgxNTUtMi4xMDkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="60" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="61" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS4wMW1tIiBoZWlnaHQ9IjE5OS42OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuMDEgMTk5LjY5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMi45MDMgLTQ1LjEyNSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDc4LjIxNSkiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iNi45MDE0IiBzdHJva2Utd2lkdGg9IjQuOTg0OSIvPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iMTQuNjU0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNy4xMDQiLz48L2c+PGcgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iNDAuMjc0IiB5PSIxNTguNzQiIHdpZHRoPSI5Mi4xNSIgaGVpZ2h0PSI0MC4zMjYiIHN0cm9rZS13aWR0aD0iOC43Mjg3Ii8+PHJlY3QgeD0iMzcuNzkzIiB5PSIxNTUuODQiIHdpZHRoPSIxMi42MjUiIGhlaWdodD0iNDMuMjI3IiByeT0iNS45OTA3IiBzdHJva2Utd2lkdGg9IjguMjM3OCIvPjxyZWN0IHg9IjM0LjU4OCIgeT0iMTY2LjgyIiB3aWR0aD0iNy4wNDgiIGhlaWdodD0iMjQuMTMzIiByeT0iMy4zNDQ1IiBzdHJva2Utd2lkdGg9IjQuNTk5Ii8+PHJlY3QgeD0iNDQuMzUzIiB5PSIxNDMuNzUiIHdpZHRoPSIyMi45OTUiIGhlaWdodD0iMjQuMTMxIiByeT0iMCIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxjaXJjbGUgY3g9IjEwOC4xMSIgY3k9IjU3LjQ1OSIgcj0iMTIuMzM0IiBzdHJva2Utd2lkdGg9IjguNDU2Ii8+PGNpcmNsZSBjeD0iMTA4LjgiIGN5PSI4Ni4yMzUiIHI9IjE4Ljg2MiIgc3Ryb2tlLXdpZHRoPSIxMi45MzEiLz48Y2lyY2xlIGN4PSI5My4zMzciIGN5PSIxMDYuODgiIHI9IjE3LjYxOCIgc3Ryb2tlLXdpZHRoPSIxMi4wNzkiLz48cGF0aCBkPSJtNTAuMjI4IDEzNS45NmgxMy4yMzJzMy4wNDk5LTcuNDkyOSA2LjA5MzMtOS44ODQxYzIuODc4My0yLjI2MTUgNy4wNzQ2LTMuOTQ4NCAxMC40NDYtMy4zODc1IDMuMTYyOSAwLjUyNjE1IDYuMzE0MS0wLjg1OTYyIDcuNTA0MyAxLjQ2OTcgMC4xNjY3OSAwLjMyNjQyLTAuMjE2NTEgMC44MzE1MyAxLjM1MjggMC45NTIzOSAwLjc5NDU2IDAuMDYxMi0wLjA4NTQxLTAuODMzOTUgMy4xNTI0LTAuNjYzMTMgMi41MTU0IDAuMTMyNyAxLjQ2Ni00LjAyNzMgMS40NjYtNC4wMjczcy0zLjAxNzktMTEuODQ4LTcuNTUxNi0xNS4yNjNjLTIuMzUwOS0xLjc3MTEtMi41MTYyLTIuNDExMi0yLjY2MTMtNS4zNTEtMy44MzQ5LTMuNzM5Ny0xMy4wMjYgMS4wNTA0LTE0LjQ5NSAzLjI2NTItMS40MTU4IDIuMTg3MS0yLjI3MTQgNC4wMzUyLTMuODMxOSA1LjcxNjktMC45NDE3OCAxLjAxNDktMi40ODkxIDEuNDE5MS0zLjI2OCAyLjU2MzgtMC45NjA1MyAxLjQxMTUtMC42MDk5NyAzLjQyOTQtMS40NjIgNC45MDg5LTAuODE4MDkgMS40MjA2LTIuMzIgMi4zMjI2LTMuMzcyMSAzLjU3OTctMS42OTc5IDIuMDI4OC0zLjY2MzIgMy45NTMtNC43MjggNi4zNzQ4LTEuMzMxNCAzLjAyODItMS44NzcyIDkuNzQ0OC0xLjg3NzIgOS43NDQ4eiIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxwYXRoIGQ9Im0xMzkuNDggMTUxLjQ3djQ3LjM3NGgzNy4wMzlsMS40MDI1LTEuNDAyNXYtNDUuOTcyem0xMC4yNzIgNS4zNTg4aDEzLjE4OHYxNi40MDdoLTEzLjE4OHoiIHN0cm9rZS13aWR0aD0iOC41NjYzIi8+PHJlY3QgeD0iMTM0LjQ3IiB5PSIxMzkuMjIiIHdpZHRoPSI0OS40NCIgaGVpZ2h0PSIxNi43MDciIHJ5PSI0LjgwNDIiIHN0cm9rZS13aWR0aD0iNy4zMTYiLz48cGF0aCBkPSJtMTcxLjk3IDE5NC4zdjkuMDg2OGg1LjFlLTRsNS45NDU5LTUuOTQ1OXYtMy4xNDA5eiIgc3Ryb2tlLXdpZHRoPSI4LjQ3ODIiLz48cGF0aCBkPSJtMzguNDggMjAzLjM5djE5Ljc1OGgxMS4zMzlhMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2Mi0xMS4xOTcgMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2NyAxMS4xOTdoMTEuNTYyYTE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjItMTEuMTk3IDE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjggMTEuMTk3aDkuNTk3N2ExNC41OCAxNC42NTQgMCAwIDEgMTQuMTYyLTExLjE5NyAxNC41OCAxNC42NTQgMCAwIDEgMTQuMTY4IDExLjE5N2gxNy42OTZ2LTE5Ljc1OHoiIHN0cm9rZS13aWR0aD0iOC40MTA1Ii8+PHJlY3QgeD0iMjIuOTAzIiB5PSIyMTIuMTgiIHdpZHRoPSIyNS4yNDMiIGhlaWdodD0iMTkuMjU1IiBzdHJva2Utd2lkdGg9IjcuODUwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjE0LjY1NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjcuMTA0Ii8+PC9nPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIuOTQxODEiPjxwYXRoIGQ9Im0xMjUuMTkgMjI2LjYxaDMyLjkwNCIvPjxwYXRoIGQ9Im0xNDEuNjQgMjEwLjE2djMyLjkwNCIvPjxwYXRoIGQ9Im0xNTMuMjcgMjM4LjI0LTIzLjI2Ny0yMy4yNjciLz48cGF0aCBkPSJtMTQ4LjE3IDI0MS43MS0xMy4wNjQtMzAuMTk5Ii8+PHBhdGggZD0ibTEzNS4xMSAyNDEuNzEgMTMuMDY0LTMwLjE5OSIvPjxwYXRoIGQ9Im0xMjYuMiAyMzIuMjkgMzAuODc2LTExLjM3MiIvPjxwYXRoIGQ9Im0xMjYuMiAyMjAuOTIgMzAuODc2IDExLjM3MiIvPjwvZz48Zz48cmVjdCB4PSIzOC40OCIgeT0iMTkwLjg2IiB3aWR0aD0iNi4zMTIzIiBoZWlnaHQ9IjIxLjc2Ii8+PHBhdGggZD0ibTUzLjQ1IDE1MC4xcy04LjgxNTYtMi42NTY2LTkuMDk3OC02LjM0MjZjLTAuMTU4NDUtMi4wNyAyLjQ1OTctMy45NTY4IDQuNTA3Ni00LjI5ODEgMi44MTc1LTAuNDY5NTUgNC45Mjc5IDMuNTk1NyA3Ljc4NDMgMy41ODI3IDIuNjUzNC0wLjAxMjEgNC42MDY3LTMuOTUyNyA3LjIwMDYtMy4zOTM3IDEuNzU5MyAwLjM3OTE1IDMuNTAyMyAyLjM4NzYgMy41MDIzIDQuMTA5MSAwIDUuMDkyLTEzLjg5NyA2LjM0MjYtMTMuODk3IDYuMzQyNnoiLz48Y2lyY2xlIGN4PSIxMDMuNTIiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48L2c+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNDAuMDk1KSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSI2LjkwMTQiIHN0cm9rZS13aWR0aD0iNC45ODQ5Ii8+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSIxNC42NTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI3LjEwNCIvPjwvZz48cGF0aCBkPSJtMTUzLjI3IDIxNC45Ny0yMy4yNjcgMjMuMjY3IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iLjk0MTgxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.35402" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="62" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxyZWN0IHg9IjE1NS4xMSIgeT0iODUuMTY0IiB3aWR0aD0iOC41NjA5IiBoZWlnaHQ9Ijc4Ljc5Ii8+PHJlY3QgdHJhbnNmb3JtPSJyb3RhdGUoLTkwKSIgeD0iLTkzLjg1OSIgeT0iMTExLjI5IiB3aWR0aD0iOC42OTUzIiBoZWlnaHQ9IjY2LjQ3Ii8+PHBhdGggZD0ibTQwLjI4MyA4My41NDFjLTQuNDczNCAwLTguMDc1IDMuNjAxNi04LjA3NSA4LjA3NXY1Mi4yMTNjMCA0LjQ3MzQgMy42MDE2IDguMDc1IDguMDc1IDguMDc1aDQuOTI5NHYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE3IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2Nmg0LjkyOTRjNC40NzM0IDAgOC4wNzUtMy42MDE1IDguMDc1LTguMDc1di01Mi4yMTNjMC00LjQ3MzQtMy42MDE1LTguMDc1LTguMDc1LTguMDc1em03LjgzMSA1LjgwOTVoNDEuMjg5YzAuODQxMTIgMCAxLjUxODMgMC42NzcxMyAxLjUxODMgMS41MTgzdjIuMzQ4MmMwIDAuODQxMTItMC42NzcxMyAxLjUxODgtMS41MTgzIDEuNTE4OGgtNDEuMjg5Yy0wLjg0MTEyIDAtMS41MTgzLTAuNjc3NjUtMS41MTgzLTEuNTE4OHYtMi4zNDgyYzAtMC44NDExMiAwLjY3NzEzLTEuNTE4MyAxLjUxODMtMS41MTgzem0tOC4wOTU2IDEzLjI2M2g1Ny40ODF2MTkuNzYxaC01Ny40ODF6bTQuMjAxOCAzMS4zNjhhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMgMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczIDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc2OC0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjgtMy4yNzczem00OS4wNzcgMGEzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc2OCAzLjI3NzMgMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjggMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczLTMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc3My0zLjI3NzN6Ii8+PHBhdGggZD0ibTQzLjMwMiAxNDcuNzNjLTEuNjY2MyAwLTMuMDA4MSAxLjM0MTMtMy4wMDgxIDMuMDA3NnYxNC43OTVjMCAxLjY2NjMgMS4zNDE4IDMuMDA3NiAzLjAwODEgMy4wMDc2aDUwLjkxNGMxLjY2NjMgMCAzLjAwODEtMS4zNDEzIDMuMDA4MS0zLjAwNzZ2LTE0Ljc5NWMwLTEuNjY2My0xLjM0MTgtMy4wMDc2LTMuMDA4MS0zLjAwNzZ6bTMuMjkzOSAwLjcyNzA5aDAuNzA5YzAuNzY2MTggMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE4IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE3IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTcgMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjkgMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIxIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyMS0xLjM4MzQgMS4zODM0LTEuMzgzNHoiLz48cmVjdCB4PSI0NC40NjUiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48cmVjdCB4PSI0MC4xMzEiIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjkxLjYwNyIgeT0iMTc1LjMiIHdpZHRoPSI1Ljc3MzEiIGhlaWdodD0iMTAuNTQ4Ii8+PHJlY3QgeD0iNDQuMTkyIiB5PSIxODAuMDciIHdpZHRoPSI0Ny45OSIgaGVpZ2h0PSI2LjM4NzgiLz48cmVjdCB4PSI4Ny43NDgiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="63" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjczLjYwM21tIiBoZWlnaHQ9IjkzLjA4MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3My42MDMgOTMuMDgxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02OC4wMTUgLTk4LjMwMSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIxOC40MSAtMjAuODgpIj48cmVjdCB4PSItMTQ3Ljk5IiB5PSIxMzUuNDQiIHdpZHRoPSI2OC43OTIiIGhlaWdodD0iNzQuNDE4IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MTA5Ii8+PGc+PHJlY3QgeD0iLTE0Ny4yNiIgeT0iMjA0LjY3IiB3aWR0aD0iNjYuMzg2IiBoZWlnaHQ9IjMuNzUwNiIvPjxwYXRoIGQ9Im0tMTEzLjYgMTE5LjE4YTM2LjgwMSAxNi4zNjYgMCAwIDAtMzYuNTUyIDE0LjU2NGg3My4xMDRhMzYuODAxIDE2LjM2NiAwIDAgMC0zNi41NTItMTQuNTY0eiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLW9wYWNpdHk9Ii41IiBzdHJva2Utd2lkdGg9IjQuOTQ2MyIvPjxyZWN0IHg9Ii0xNTAuNCIgeT0iMTMwLjU0IiB3aWR0aD0iNzMuNjAzIiBoZWlnaHQ9IjUuMDA2OCIgcnk9IjIuMDE4MiIvPjwvZz48ZyB0cmFuc2Zvcm09Im1hdHJpeCguNjIzMTQgMCAwIC42MjMxNCAtMTU2LjQ0IDkxLjg3OCkiPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.27" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="64" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxwYXRoIGQ9Im00MC4yODMgODMuNTQxYy00LjQ3MzQgMC04LjA3NSAzLjYwMTYtOC4wNzUgOC4wNzV2NTIuMjEzYzAgNC40NzM0IDMuNjAxNiA4LjA3NSA4LjA3NSA4LjA3NWg0LjkyOTR2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxOCAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0aDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYyLjA2NmgzLjc5NDF2LTIuMDY2YzAtMC43NjYxOCAwLjYxNzIxLTEuMzgzNCAxLjM4MzQtMS4zODM0aDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2Mi4wNjZoNC45Mjk0YzQuNDczNCAwIDguMDc1LTMuNjAxNSA4LjA3NS04LjA3NXYtNTIuMjEzYzAtNC40NzM0LTMuNjAxNS04LjA3NS04LjA3NS04LjA3NXptNy44MzEgNS44MDk1aDQxLjI4OWMwLjg0MTEyIDAgMS41MTgzIDAuNjc3MTMgMS41MTgzIDEuNTE4M3YyLjM0ODJjMCAwLjg0MTEyLTAuNjc3MTMgMS41MTg4LTEuNTE4MyAxLjUxODhoLTQxLjI4OWMtMC44NDExMiAwLTEuNTE4My0wLjY3NzY1LTEuNTE4My0xLjUxODh2LTIuMzQ4MmMwLTAuODQxMTIgMC42NzcxMy0xLjUxODMgMS41MTgzLTEuNTE4M3ptLTguMDk1NiAxMy4yNjNoNTcuNDgxdjE5Ljc2MWgtNTcuNDgxem00LjIwMTggMzEuMzY4YTMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzczIDMuMjc3MyAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3MyAzLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjgtMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEgMy4yNzY4LTMuMjc3M3ptNDkuMDc3IDBhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjggMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzY4IDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc3My0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMtMy4yNzczeiIvPjxwYXRoIGQ9Im00My4zMDIgMTQ3LjczYy0xLjY2NjMgMC0zLjAwODEgMS4zNDEzLTMuMDA4MSAzLjAwNzZ2MTQuNzk1YzAgMS42NjYzIDEuMzQxOCAzLjAwNzYgMy4wMDgxIDMuMDA3Nmg1MC45MTRjMS42NjYzIDAgMy4wMDgxLTEuMzQxMyAzLjAwODEtMy4wMDc2di0xNC43OTVjMC0xLjY2NjMtMS4zNDE4LTMuMDA3Ni0zLjAwODEtMy4wMDc2em0zLjI5MzkgMC43MjcwOWgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxOCAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyLTEuMzgzNCAxLjM4MzQtMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTggMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY4IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE3IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY5LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTMgMGgwLjcwOTUyYzAuNzY2MTcgMCAxLjM4MjkgMC42MTcyIDEuMzgyOSAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNjY5IDEuMzgyOS0xLjM4MjkgMS4zODI5aC0wLjcwOTUyYy0wLjc2NjE4IDAtMS4zODI5LTAuNjE2NjktMS4zODI5LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNjY4LTEuMzgzNCAxLjM4MjktMS4zODM0em03LjI2OTggMGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djEzLjU1NWMwIDAuNzY2MTgtMC42MTcyMSAxLjM4MjktMS4zODM0IDEuMzgyOWgtMC43MDljLTAuNzY2MTcgMC0xLjM4MzQtMC42MTY2OS0xLjM4MzQtMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzR6Ii8+PHJlY3QgeD0iNDQuNDY1IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuMTMxIiB5PSIxNzUuMyIgd2lkdGg9IjUuNzczMSIgaGVpZ2h0PSIxMC41NDgiLz48cmVjdCB4PSI5MS42MDciIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjQ0LjE5MiIgeT0iMTgwLjA3IiB3aWR0aD0iNDcuOTkiIGhlaWdodD0iNi4zODc4Ii8+PHJlY3QgeD0iODcuNzQ4IiB5PSIxNjUuNTMiIHdpZHRoPSI1LjMwNTMiIGhlaWdodD0iOS43NjQxIiByeD0iMS43MjA0IiByeT0iMS43MjA0Ii8+PHJlY3QgeD0iNDAuOTU1IiB5PSI4Ni42ODUiIHdpZHRoPSI1NC4yNSIgaGVpZ2h0PSIxMi4xNDQiLz48cmVjdCB4PSIzNy4yMzgiIHk9Ijk5Ljk1MyIgd2lkdGg9IjY0Ljk4MiIgaGVpZ2h0PSIyNy4wNzYiLz48cmVjdCB4PSI0MC44MDQiIHk9IjEzMi4yMyIgd2lkdGg9IjU4LjE3NSIgaGVpZ2h0PSIxMS40ODkiLz48cmVjdCB4PSI0Mi44MjEiIHk9IjE0Ni42IiB3aWR0aD0iNTEuMTM4IiBoZWlnaHQ9IjE4LjcyNyIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="65" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjkwLjcyNG1tIiBoZWlnaHQ9IjE1MS4xM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5MC43MjQgMTUxLjEzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02NS44NzggLTY3LjgzMikiPjxjaXJjbGUgY3g9IjEzMi4xOCIgY3k9IjkyLjI1OCIgcj0iMjIuMDE0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNC44MjYiLz48Zz48cmVjdCB4PSI2NS44NzgiIHk9IjIxMi42NSIgd2lkdGg9IjcxLjUwNCIgaGVpZ2h0PSI2LjMwODkiLz48cGF0aCB0cmFuc2Zvcm09Im1hdHJpeCgxIDAgMCAzLjEwMjYgNjcuNzMgLTIwOC44OSkiIGQ9Im01Ny40NTEgMTM2Ljc0aC00Ny4xMDJsMjMuNTUxLTQwLjc5MXoiLz48cmVjdCB4PSI5OC4xNTUiIHk9Ijg4Ljc5MiIgd2lkdGg9IjEyLjg5MSIgaGVpZ2h0PSI2LjkzMzQiIHJ5PSIwIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.3617" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="66" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi41bW0iIGhlaWdodD0iMTIyLjg1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi41IDEyMi44NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzYuMTE3IC04Ni42NjIpIj48ZyBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im0xMTguNTQgMTYxLjQ0Yy0yLjI4OTYgMC00LjEzMzEgMS44NDM0LTQuMTMzMSA0LjEzMzF2MjYuNzQ1aC00LjgwMjN2LTkuMDg4M2gtMzAuODgydjEyLjIyNWMwIDMuMTA0OCAyLjUgNS42MDQ4IDUuNjA0OCA1LjYwNDhoMy40MDE5YTguODE3OCA4LjgxNzggMCAwIDAgOC43OTIyIDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkxNy04LjQ1NDNoMjYuMzMzYTguODE3OCA4LjgxNzggMCAwIDAgOC43OTE3IDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkyMi04LjQ1NDNoNC4wMTczYzIuMjg5NiAwIDQuMTMzMS0xLjg0MzQgNC4xMzMxLTQuMTMzMXYtMzEuMzUzYzAtMi4yODk2LTEuODQzNS00LjEzMzEtNC4xMzMxLTQuMTMzMXptLTIyLjAxOCAzNC43MTJhNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjczODkgMC4zNDU3MiA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0MyAwLjk4NTQ3IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0NyAxLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjM0NTcyIDEuNzM4OSA0LjU0NDUgNC41NDQ1IDAgMCAxLTQuNTQ0NCA0LjU0NDQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDktNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMy0xLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjk4NDk1LTEuNDc0MyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0My0wLjk4NDk1IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0LTAuMzQ1NzJ6bTQzLjkxNyAwYTQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0IDAuMzQ1NzIgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMgMC45ODQ5NSA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuOTg0OTUgMS40NzQzIDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMyAxLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDkgNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEtNC41NDQ0LTQuNTQ0NCA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuMzQ1NzEtMS43Mzg5IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0Ny0xLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMtMC45ODU0NyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNzM4OS0wLjM0NTcyeiIgc3Ryb2tlLXdpZHRoPSIuNTU2NzEiLz48cGF0aCBkPSJtOTAuMjcgMTY1LjQ3LTkuNDAxNSAxMy41MDVoMjguNzM1di0xMy41MDV6IiBzdHJva2Utd2lkdGg9Ii40OTY2OCIvPjxwYXRoIGQ9Im0zNi4xMTcgMTM5LjI4IDE5LjMwNCAxMC4xNjh2MjMuOTcybC0xOS4zMDQtMTAuNjE2eiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjxwYXRoIGQ9Im03OS43MjkgMTM5LjI4LTE5LjMwNCAxMC4xNjh2MjMuOTcybDE5LjMwNC0xMC42MTZ6IiBzdHJva2Utd2lkdGg9Ii41Ii8+PHJlY3QgdHJhbnNmb3JtPSJtYXRyaXgoLjg4NDYxIC0uNDY2MzMgLjg4NDYxIC40NjYzMyAwIDApIiB4PSItMTIzLjg0IiB5PSIxNjcuNjUiIHdpZHRoPSIyMS42NjUiIGhlaWdodD0iMjEuNjY1IiBzdHJva2Utd2lkdGg9Ii43NTgxNiIvPjwvZz48cGF0aCBkPSJtNjguMzgxIDg2LjY2OWMtMy41MzkxIDAuMTQ5MTEtNC44MzI1IDMuNDQxMy00LjYxNTcgNS4wNzQ2IDEuODQ2MiAxMy45MTIgMi45NjI5IDI0LjExNCA0Ljg5NjMgMjQuOTA2IDguNzM3OCAzLjU4MzggMTguNTQ0IDcuNDgyMSAyOC44MSAxMS40NTMtMi4xMDEyIDMuNjEyMi01LjA4MzIgOC43NDM0LTcuNzYyMyAxMy4zODQtMi44Njk1IDQuOTcwMSAwLjk4MzU1IDYuNDg3NiAzLjU2NjIgNy4yMjkgOC43NjUxIDIuNTE2NCAxMC4wMDYtMS40MDQ2IDIyLjcyNC0xMy41NjUgMTEuMjIgNC4yMDI4IDIyLjU1MiA4LjMyOTYgMzMuMjk4IDEyLjA4OSAyLjU4MiAwLjkwMzIzIDUuOTYyOS0xLjA5MzMgNy40ODMzLTMuMzY3MiAxLjg2MTUtMi43ODQyIDQuNzA4My0xMi4yNjgtNS40ODk2LTIyLjIwOS0yLjEwMTQtMi4wNDg1LTQuNTkxNS00LjA3OS03LjMyNTYtNS4xNTI3LTE5LjcyNC03Ljc0NS02MS42NDYtMTUuODU2LTYxLjY0Ni0xNS44NTYtNC40MDktNS40MzQtNy40MTE0LTE0LjI2LTEzLjkzOC0xMy45ODV6Ii8+PHBhdGggZD0ibTEwNS43NCA5MS43NjZjLTUuMzU4OCAwLTkuNTY5LTEuMDkxOC03LjUwNTcgNi4zODgyIDAuMTI5MDkgMC40NjggMC40MDYyNyAwLjk5NTMgMC41OTg5MyAxLjQ2OTdsMjQuMjM5IDYuNDk0Ny04LjUxNy0xMi4yNDNjLTEuNDA2OC0yLjAyMjMtNC42MDg4LTIuMTA5Mi04LjgxNTUtMi4xMDkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="67" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="133,182,111,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="68" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi41bW0iIGhlaWdodD0iMTIyLjg1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi41IDEyMi44NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzYuMTE3IC04Ni42NjIpIj48ZyBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im0xMTguNTQgMTYxLjQ0Yy0yLjI4OTYgMC00LjEzMzEgMS44NDM0LTQuMTMzMSA0LjEzMzF2MjYuNzQ1aC00LjgwMjN2LTkuMDg4M2gtMzAuODgydjEyLjIyNWMwIDMuMTA0OCAyLjUgNS42MDQ4IDUuNjA0OCA1LjYwNDhoMy40MDE5YTguODE3OCA4LjgxNzggMCAwIDAgOC43OTIyIDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkxNy04LjQ1NDNoMjYuMzMzYTguODE3OCA4LjgxNzggMCAwIDAgOC43OTE3IDguNDU0MyA4LjgxNzggOC44MTc4IDAgMCAwIDguNzkyMi04LjQ1NDNoNC4wMTczYzIuMjg5NiAwIDQuMTMzMS0xLjg0MzQgNC4xMzMxLTQuMTMzMXYtMzEuMzUzYzAtMi4yODk2LTEuODQzNS00LjEzMzEtNC4xMzMxLTQuMTMzMXptLTIyLjAxOCAzNC43MTJhNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjczODkgMC4zNDU3MiA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0MyAwLjk4NTQ3IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0NyAxLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjM0NTcyIDEuNzM4OSA0LjU0NDUgNC41NDQ1IDAgMCAxLTQuNTQ0NCA0LjU0NDQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDktNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMy0xLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMSAwLjk4NDk1LTEuNDc0MyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNDc0My0wLjk4NDk1IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0LTAuMzQ1NzJ6bTQzLjkxNyAwYTQuNTQ0NSA0LjU0NDUgMCAwIDEgMS43Mzk0IDAuMzQ1NzIgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMgMC45ODQ5NSA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuOTg0OTUgMS40NzQzIDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC4zNDYyMyAxLjczOTQgNC41NDQ1IDQuNTQ0NSAwIDAgMS00LjU0NDkgNC41NDQ0IDQuNTQ0NSA0LjU0NDUgMCAwIDEtNC41NDQ0LTQuNTQ0NCA0LjU0NDUgNC41NDQ1IDAgMCAxIDAuMzQ1NzEtMS43Mzg5IDQuNTQ0NSA0LjU0NDUgMCAwIDEgMC45ODU0Ny0xLjQ3NDMgNC41NDQ1IDQuNTQ0NSAwIDAgMSAxLjQ3NDMtMC45ODU0NyA0LjU0NDUgNC41NDQ1IDAgMCAxIDEuNzM4OS0wLjM0NTcyeiIgc3Ryb2tlLXdpZHRoPSIuNTU2NzEiLz48cGF0aCBkPSJtOTAuMjcgMTY1LjQ3LTkuNDAxNSAxMy41MDVoMjguNzM1di0xMy41MDV6IiBzdHJva2Utd2lkdGg9Ii40OTY2OCIvPjxwYXRoIGQ9Im0zNi4xMTcgMTM5LjI4IDE5LjMwNCAxMC4xNjh2MjMuOTcybC0xOS4zMDQtMTAuNjE2eiIgc3Ryb2tlLXdpZHRoPSIuNSIvPjxwYXRoIGQ9Im03OS43MjkgMTM5LjI4LTE5LjMwNCAxMC4xNjh2MjMuOTcybDE5LjMwNC0xMC42MTZ6IiBzdHJva2Utd2lkdGg9Ii41Ii8+PHJlY3QgdHJhbnNmb3JtPSJtYXRyaXgoLjg4NDYxIC0uNDY2MzMgLjg4NDYxIC40NjYzMyAwIDApIiB4PSItMTIzLjg0IiB5PSIxNjcuNjUiIHdpZHRoPSIyMS42NjUiIGhlaWdodD0iMjEuNjY1IiBzdHJva2Utd2lkdGg9Ii43NTgxNiIvPjwvZz48cGF0aCBkPSJtNjguMzgxIDg2LjY2OWMtMy41MzkxIDAuMTQ5MTEtNC44MzI1IDMuNDQxMy00LjYxNTcgNS4wNzQ2IDEuODQ2MiAxMy45MTIgMi45NjI5IDI0LjExNCA0Ljg5NjMgMjQuOTA2IDguNzM3OCAzLjU4MzggMTguNTQ0IDcuNDgyMSAyOC44MSAxMS40NTMtMi4xMDEyIDMuNjEyMi01LjA4MzIgOC43NDM0LTcuNzYyMyAxMy4zODQtMi44Njk1IDQuOTcwMSAwLjk4MzU1IDYuNDg3NiAzLjU2NjIgNy4yMjkgOC43NjUxIDIuNTE2NCAxMC4wMDYtMS40MDQ2IDIyLjcyNC0xMy41NjUgMTEuMjIgNC4yMDI4IDIyLjU1MiA4LjMyOTYgMzMuMjk4IDEyLjA4OSAyLjU4MiAwLjkwMzIzIDUuOTYyOS0xLjA5MzMgNy40ODMzLTMuMzY3MiAxLjg2MTUtMi43ODQyIDQuNzA4My0xMi4yNjgtNS40ODk2LTIyLjIwOS0yLjEwMTQtMi4wNDg1LTQuNTkxNS00LjA3OS03LjMyNTYtNS4xNTI3LTE5LjcyNC03Ljc0NS02MS42NDYtMTUuODU2LTYxLjY0Ni0xNS44NTYtNC40MDktNS40MzQtNy40MTE0LTE0LjI2LTEzLjkzOC0xMy45ODV6Ii8+PHBhdGggZD0ibTEwNS43NCA5MS43NjZjLTUuMzU4OCAwLTkuNTY5LTEuMDkxOC03LjUwNTcgNi4zODgyIDAuMTI5MDkgMC40NjggMC40MDYyNyAwLjk5NTMgMC41OTg5MyAxLjQ2OTdsMjQuMjM5IDYuNDk0Ny04LjUxNy0xMi4yNDNjLTEuNDA2OC0yLjAyMjMtNC42MDg4LTIuMTA5Mi04LjgxNTUtMi4xMDkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="231,113,72,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS4wMW1tIiBoZWlnaHQ9IjE5OS42OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuMDEgMTk5LjY5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMi45MDMgLTQ1LjEyNSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDc4LjIxNSkiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iNi45MDE0IiBzdHJva2Utd2lkdGg9IjQuOTg0OSIvPjxjaXJjbGUgY3g9IjYzLjQyMyIgY3k9IjIyNi42MSIgcj0iMTQuNjU0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNy4xMDQiLz48L2c+PGcgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iNDAuMjc0IiB5PSIxNTguNzQiIHdpZHRoPSI5Mi4xNSIgaGVpZ2h0PSI0MC4zMjYiIHN0cm9rZS13aWR0aD0iOC43Mjg3Ii8+PHJlY3QgeD0iMzcuNzkzIiB5PSIxNTUuODQiIHdpZHRoPSIxMi42MjUiIGhlaWdodD0iNDMuMjI3IiByeT0iNS45OTA3IiBzdHJva2Utd2lkdGg9IjguMjM3OCIvPjxyZWN0IHg9IjM0LjU4OCIgeT0iMTY2LjgyIiB3aWR0aD0iNy4wNDgiIGhlaWdodD0iMjQuMTMzIiByeT0iMy4zNDQ1IiBzdHJva2Utd2lkdGg9IjQuNTk5Ii8+PHJlY3QgeD0iNDQuMzUzIiB5PSIxNDMuNzUiIHdpZHRoPSIyMi45OTUiIGhlaWdodD0iMjQuMTMxIiByeT0iMCIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxjaXJjbGUgY3g9IjEwOC4xMSIgY3k9IjU3LjQ1OSIgcj0iMTIuMzM0IiBzdHJva2Utd2lkdGg9IjguNDU2Ii8+PGNpcmNsZSBjeD0iMTA4LjgiIGN5PSI4Ni4yMzUiIHI9IjE4Ljg2MiIgc3Ryb2tlLXdpZHRoPSIxMi45MzEiLz48Y2lyY2xlIGN4PSI5My4zMzciIGN5PSIxMDYuODgiIHI9IjE3LjYxOCIgc3Ryb2tlLXdpZHRoPSIxMi4wNzkiLz48cGF0aCBkPSJtNTAuMjI4IDEzNS45NmgxMy4yMzJzMy4wNDk5LTcuNDkyOSA2LjA5MzMtOS44ODQxYzIuODc4My0yLjI2MTUgNy4wNzQ2LTMuOTQ4NCAxMC40NDYtMy4zODc1IDMuMTYyOSAwLjUyNjE1IDYuMzE0MS0wLjg1OTYyIDcuNTA0MyAxLjQ2OTcgMC4xNjY3OSAwLjMyNjQyLTAuMjE2NTEgMC44MzE1MyAxLjM1MjggMC45NTIzOSAwLjc5NDU2IDAuMDYxMi0wLjA4NTQxLTAuODMzOTUgMy4xNTI0LTAuNjYzMTMgMi41MTU0IDAuMTMyNyAxLjQ2Ni00LjAyNzMgMS40NjYtNC4wMjczcy0zLjAxNzktMTEuODQ4LTcuNTUxNi0xNS4yNjNjLTIuMzUwOS0xLjc3MTEtMi41MTYyLTIuNDExMi0yLjY2MTMtNS4zNTEtMy44MzQ5LTMuNzM5Ny0xMy4wMjYgMS4wNTA0LTE0LjQ5NSAzLjI2NTItMS40MTU4IDIuMTg3MS0yLjI3MTQgNC4wMzUyLTMuODMxOSA1LjcxNjktMC45NDE3OCAxLjAxNDktMi40ODkxIDEuNDE5MS0zLjI2OCAyLjU2MzgtMC45NjA1MyAxLjQxMTUtMC42MDk5NyAzLjQyOTQtMS40NjIgNC45MDg5LTAuODE4MDkgMS40MjA2LTIuMzIgMi4zMjI2LTMuMzcyMSAzLjU3OTctMS42OTc5IDIuMDI4OC0zLjY2MzIgMy45NTMtNC43MjggNi4zNzQ4LTEuMzMxNCAzLjAyODItMS44NzcyIDkuNzQ0OC0xLjg3NzIgOS43NDQ4eiIgc3Ryb2tlLXdpZHRoPSI4LjQ1NiIvPjxwYXRoIGQ9Im0xMzkuNDggMTUxLjQ3djQ3LjM3NGgzNy4wMzlsMS40MDI1LTEuNDAyNXYtNDUuOTcyem0xMC4yNzIgNS4zNTg4aDEzLjE4OHYxNi40MDdoLTEzLjE4OHoiIHN0cm9rZS13aWR0aD0iOC41NjYzIi8+PHJlY3QgeD0iMTM0LjQ3IiB5PSIxMzkuMjIiIHdpZHRoPSI0OS40NCIgaGVpZ2h0PSIxNi43MDciIHJ5PSI0LjgwNDIiIHN0cm9rZS13aWR0aD0iNy4zMTYiLz48cGF0aCBkPSJtMTcxLjk3IDE5NC4zdjkuMDg2OGg1LjFlLTRsNS45NDU5LTUuOTQ1OXYtMy4xNDA5eiIgc3Ryb2tlLXdpZHRoPSI4LjQ3ODIiLz48cGF0aCBkPSJtMzguNDggMjAzLjM5djE5Ljc1OGgxMS4zMzlhMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2Mi0xMS4xOTcgMTQuNTggMTQuNjU0IDAgMCAxIDE0LjE2NyAxMS4xOTdoMTEuNTYyYTE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjItMTEuMTk3IDE0LjU4IDE0LjY1NCAwIDAgMSAxNC4xNjggMTEuMTk3aDkuNTk3N2ExNC41OCAxNC42NTQgMCAwIDEgMTQuMTYyLTExLjE5NyAxNC41OCAxNC42NTQgMCAwIDEgMTQuMTY4IDExLjE5N2gxNy42OTZ2LTE5Ljc1OHoiIHN0cm9rZS13aWR0aD0iOC40MTA1Ii8+PHJlY3QgeD0iMjIuOTAzIiB5PSIyMTIuMTgiIHdpZHRoPSIyNS4yNDMiIGhlaWdodD0iMTkuMjU1IiBzdHJva2Utd2lkdGg9IjcuODUwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48Y2lyY2xlIGN4PSI2My40MjMiIGN5PSIyMjYuNjEiIHI9IjE0LjY1NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjcuMTA0Ii8+PC9nPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIuOTQxODEiPjxwYXRoIGQ9Im0xMjUuMTkgMjI2LjYxaDMyLjkwNCIvPjxwYXRoIGQ9Im0xNDEuNjQgMjEwLjE2djMyLjkwNCIvPjxwYXRoIGQ9Im0xNTMuMjcgMjM4LjI0LTIzLjI2Ny0yMy4yNjciLz48cGF0aCBkPSJtMTQ4LjE3IDI0MS43MS0xMy4wNjQtMzAuMTk5Ii8+PHBhdGggZD0ibTEzNS4xMSAyNDEuNzEgMTMuMDY0LTMwLjE5OSIvPjxwYXRoIGQ9Im0xMjYuMiAyMzIuMjkgMzAuODc2LTExLjM3MiIvPjxwYXRoIGQ9Im0xMjYuMiAyMjAuOTIgMzAuODc2IDExLjM3MiIvPjwvZz48Zz48cmVjdCB4PSIzOC40OCIgeT0iMTkwLjg2IiB3aWR0aD0iNi4zMTIzIiBoZWlnaHQ9IjIxLjc2Ii8+PHBhdGggZD0ibTUzLjQ1IDE1MC4xcy04LjgxNTYtMi42NTY2LTkuMDk3OC02LjM0MjZjLTAuMTU4NDUtMi4wNyAyLjQ1OTctMy45NTY4IDQuNTA3Ni00LjI5ODEgMi44MTc1LTAuNDY5NTUgNC45Mjc5IDMuNTk1NyA3Ljc4NDMgMy41ODI3IDIuNjUzNC0wLjAxMjEgNC42MDY3LTMuOTUyNyA3LjIwMDYtMy4zOTM3IDEuNzU5MyAwLjM3OTE1IDMuNTAyMyAyLjM4NzYgMy41MDIzIDQuMTA5MSAwIDUuMDkyLTEzLjg5NyA2LjM0MjYtMTMuODk3IDYuMzQyNnoiLz48Y2lyY2xlIGN4PSIxMDMuNTIiIGN5PSIyMjYuNjEiIHI9IjYuOTAxNCIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI0Ljk4NDkiLz48L2c+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNDAuMDk1KSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSI2LjkwMTQiIHN0cm9rZS13aWR0aD0iNC45ODQ5Ii8+PGNpcmNsZSBjeD0iNjMuNDIzIiBjeT0iMjI2LjYxIiByPSIxNC42NTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI3LjEwNCIvPjwvZz48cGF0aCBkPSJtMTUzLjI3IDIxNC45Ny0yMy4yNjcgMjMuMjY3IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iLjk0MTgxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.35402" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny41MW1tIiBoZWlnaHQ9IjExNy40Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuNTEgMTE3LjQ2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMS45NjMgLTgzLjU0MSkiPjxnPjxyZWN0IHg9IjEyNi4yMyIgeT0iMTU4Ljc1IiB3aWR0aD0iNTMuMjQ1IiBoZWlnaHQ9IjQyLjI1MiIvPjxyZWN0IHg9IjExNC42NyIgeT0iMTU4Ljc1IiB3aWR0aD0iMzIuNzM3IiBoZWlnaHQ9IjExLjAwMyIvPjxyZWN0IHg9IjMxLjk2MyIgeT0iMTg1LjA4IiB3aWR0aD0iMTAyLjAzIiBoZWlnaHQ9IjE1LjkxOCIvPjxyZWN0IHg9IjE1NS4xMSIgeT0iODUuMTY0IiB3aWR0aD0iOC41NjA5IiBoZWlnaHQ9Ijc4Ljc5Ii8+PHJlY3QgdHJhbnNmb3JtPSJyb3RhdGUoLTkwKSIgeD0iLTkzLjg1OSIgeT0iMTExLjI5IiB3aWR0aD0iOC42OTUzIiBoZWlnaHQ9IjY2LjQ3Ii8+PHBhdGggZD0ibTQwLjI4MyA4My41NDFjLTQuNDczNCAwLTguMDc1IDMuNjAxNi04LjA3NSA4LjA3NXY1Mi4yMTNjMCA0LjQ3MzQgMy42MDE2IDguMDc1IDguMDc1IDguMDc1aDQuOTI5NHYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE4IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3Mi0xLjM4MzQgMS4zODM0LTEuMzgzNGgwLjcwOWMwLjc2NjE3IDAgMS4zODM0IDAuNjE3MiAxLjM4MzQgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE4IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzRoMC43MDk1MmMwLjc2NjE3IDAgMS4zODI5IDAuNjE3MiAxLjM4MjkgMS4zODM0djIuMDY2aDMuNzk0MXYtMi4wNjZjMC0wLjc2NjE4IDAuNjE3MjEtMS4zODM0IDEuMzgzNC0xLjM4MzRoMC43MDljMC43NjYxNyAwIDEuMzgzNCAwLjYxNzIgMS4zODM0IDEuMzgzNHYyLjA2Nmg0LjkyOTRjNC40NzM0IDAgOC4wNzUtMy42MDE1IDguMDc1LTguMDc1di01Mi4yMTNjMC00LjQ3MzQtMy42MDE1LTguMDc1LTguMDc1LTguMDc1em03LjgzMSA1LjgwOTVoNDEuMjg5YzAuODQxMTIgMCAxLjUxODMgMC42NzcxMyAxLjUxODMgMS41MTgzdjIuMzQ4MmMwIDAuODQxMTItMC42NzcxMyAxLjUxODgtMS41MTgzIDEuNTE4OGgtNDEuMjg5Yy0wLjg0MTEyIDAtMS41MTgzLTAuNjc3NjUtMS41MTgzLTEuNTE4OHYtMi4zNDgyYzAtMC44NDExMiAwLjY3NzEzLTEuNTE4MyAxLjUxODMtMS41MTgzem0tOC4wOTU2IDEzLjI2M2g1Ny40ODF2MTkuNzYxaC01Ny40ODF6bTQuMjAxOCAzMS4zNjhhMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NzMgMy4yNzczIDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczIDMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxLTMuMjc2OC0zLjI3NjggMy4yNzY5IDMuMjc2OSAwIDAgMSAzLjI3NjgtMy4yNzczem00OS4wNzcgMGEzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc2OCAzLjI3NzMgMy4yNzY5IDMuMjc2OSAwIDAgMS0zLjI3NjggMy4yNzY4IDMuMjc2OSAzLjI3NjkgMCAwIDEtMy4yNzczLTMuMjc2OCAzLjI3NjkgMy4yNzY5IDAgMCAxIDMuMjc3My0zLjI3NzN6Ii8+PHBhdGggZD0ibTQzLjMwMiAxNDcuNzNjLTEuNjY2MyAwLTMuMDA4MSAxLjM0MTMtMy4wMDgxIDMuMDA3NnYxNC43OTVjMCAxLjY2NjMgMS4zNDE4IDMuMDA3NiAzLjAwODEgMy4wMDc2aDUwLjkxNGMxLjY2NjMgMCAzLjAwODEtMS4zNDEzIDMuMDA4MS0zLjAwNzZ2LTE0Ljc5NWMwLTEuNjY2My0xLjM0MTgtMy4wMDc2LTMuMDA4MS0zLjAwNzZ6bTMuMjkzOSAwLjcyNzA5aDAuNzA5YzAuNzY2MTggMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE4IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIgMS4zODI5LTEuMzgzNCAxLjM4MjloLTAuNzA5Yy0wLjc2NjE3IDAtMS4zODM0LTAuNjE2NjktMS4zODM0LTEuMzgyOXYtMTMuNTU1YzAtMC43NjYxOCAwLjYxNzItMS4zODM0IDEuMzgzNC0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxOCAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjggMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTcgMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjktMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5MyAwaDAuNzA5NTJjMC43NjYxNyAwIDEuMzgyOSAwLjYxNzIgMS4zODI5IDEuMzgzNHYxMy41NTVjMCAwLjc2NjE4LTAuNjE2NjkgMS4zODI5LTEuMzgyOSAxLjM4MjloLTAuNzA5NTJjLTAuNzY2MTggMC0xLjM4MjktMC42MTY2OS0xLjM4MjktMS4zODI5di0xMy41NTVjMC0wLjc2NjE4IDAuNjE2NjgtMS4zODM0IDEuMzgyOS0xLjM4MzR6bTcuMjY5OCAwaDAuNzA5YzAuNzY2MTcgMCAxLjM4MzQgMC42MTcyIDEuMzgzNCAxLjM4MzR2MTMuNTU1YzAgMC43NjYxOC0wLjYxNzIxIDEuMzgyOS0xLjM4MzQgMS4zODI5aC0wLjcwOWMtMC43NjYxNyAwLTEuMzgzNC0wLjYxNjY5LTEuMzgzNC0xLjM4Mjl2LTEzLjU1NWMwLTAuNzY2MTggMC42MTcyMS0xLjM4MzQgMS4zODM0LTEuMzgzNHoiLz48cmVjdCB4PSI0NC40NjUiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48cmVjdCB4PSI0MC4xMzEiIHk9IjE3NS4zIiB3aWR0aD0iNS43NzMxIiBoZWlnaHQ9IjEwLjU0OCIvPjxyZWN0IHg9IjkxLjYwNyIgeT0iMTc1LjMiIHdpZHRoPSI1Ljc3MzEiIGhlaWdodD0iMTAuNTQ4Ii8+PHJlY3QgeD0iNDQuMTkyIiB5PSIxODAuMDciIHdpZHRoPSI0Ny45OSIgaGVpZ2h0PSI2LjM4NzgiLz48cmVjdCB4PSI4Ny43NDgiIHk9IjE2NS41MyIgd2lkdGg9IjUuMzA1MyIgaGVpZ2h0PSI5Ljc2NDEiIHJ4PSIxLjcyMDQiIHJ5PSIxLjcyMDQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Железнодорожная станция" value="602030201" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожный вокзал" value="602030202" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожное депо" value="602030203" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Остановочный пассажирский железнодорожный пункт" value="602030204" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иные объекты железнодорожного транспорта" value="602030205" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Транспортно-логистический центр, на котором осуществляется перегрузка грузов с одного вида транспорта на другой вид транспорта" value="602030206" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="USING_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Общего пользования" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Необщего пользования" value="2" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="RST_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Пассажирская" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Грузовая" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Техническая (сортировочная, участковая, предпортовая)" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Промежуточная" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Межгосударственная передаточная" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="RST_CLASS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Внеклассная" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="I" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="II" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="III" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="IV" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="V" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="RFO_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Путевой пост" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Диспетчерский пункт" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожный разъезд" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Обгонный железнодорожный пункт" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожный блок-пост" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Здание пункта технического обслуживания локомотивов" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CAPACITY" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SUBURBAN_TR" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Пригородное сообщение отсутствует" value="0" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Пригородное сообщение присутствует" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FREIGHT" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="PASS_TRAIN" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CARGO_TRAIN" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="COMPL_NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="DANGER_OBJ" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Объекты использования атомной энергии (в том числе ядерные установки, пункты хранения ядерных материалов и радиоактивных веществ, пункты хранения радиоактивных отходов)" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Тепловые электростанции мощностью 150 мегаватт и выше" value="10" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Подвесные канатные дороги" value="11" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасные производственные объекты I и II классов опасности, на которых получаются, используются, перерабатываются, образуются, хранятся, транспортируются, уничтожаются опасные вещества" value="12" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасные производственные объекты, на которых получаются, транспортируются, используются расплавы черных и цветных металлов, сплавы на основе этих расплавов с применением оборудования, рассчитанного на максимальное количество расплава 500 килограммов иболее" value="13" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасные производственные объекты, на которых ведутся горные работы (за исключением добычи общераспространенных полезных ископаемых и разработки россыпных месторождений полезных ископаемых, осуществляемых открытым способом без применения взрывных работ), работы по обогащению полезных ископаемых" value="14" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Антенно-мачтовое сооружение (АМС)" value="15" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Гидротехнические сооружения первого и второго классов, устанавливаемые в соответствии с законодательством о безопасности гидротехнических сооружений" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Сооружения связи, являющиеся особо опасными, технически сложными в соответствии с законодательством Российской Федерации в области связи" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Линии электропередачи и иные объекты электросетевого хозяйства напряжением 330 киловольт и более" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты космической инфраструктуры" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты инфраструктуры воздушного транспорта, являющиеся особо опасными, технически сложными объектами в соответствии с воздушным законодательством Российской Федерации" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты капитального строительства инфраструктуры железнодорожного транспорта общего пользования, являющиеся особо опасными, технически сложными объектами в соответствии с законодательством Российской Федерации о железнодорожном транспорте" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты инфраструктуры внеуличного транспорта" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Портовые гидротехнические сооружения, относящиеся к объектам инфраструктуры морского порта, за исключением объектов инфраструктуры морского порта, предназначенных для стоянок и обслуживания маломерных, спортивных парусных и прогулочных судов" value="9" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FUNCTION" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к ликвидации" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTROKS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTRZU" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAMEDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="DATEDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBERDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="PROP_GR" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PRJ_POVS" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PR_TEU" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="USING_TYPE" index="6" name="Вид разрешенного использования"/>
    <alias field="RST_TYPE" index="7" name=""/>
    <alias field="RST_CLASS" index="8" name=""/>
    <alias field="RFO_TYPE" index="9" name=""/>
    <alias field="CAPACITY" index="10" name=""/>
    <alias field="SUBURBAN_TR" index="11" name="Наличие движения пригородных поездов"/>
    <alias field="FREIGHT" index="12" name="Грузовая работа за год, тонн"/>
    <alias field="PASS_TRAIN" index="13" name="Размер движения пассажирских поездов, пар в сутки"/>
    <alias field="CARGO_TRAIN" index="14" name="Размер движения грузовых поездов, пар в сутки"/>
    <alias field="COMPL_NAME" index="15" name="Наименование комплексного объекта"/>
    <alias field="DANGER_OBJ" index="16" name="Критерии отнесения объекта к особо опасным и технически сложным объектам"/>
    <alias field="FUNCTION" index="17" name="Назначение объекта"/>
    <alias field="EVENT_TIME" index="18" name=""/>
    <alias field="SOURCE" index="19" name="Источник данных"/>
    <alias field="NOTE" index="20" name="Примечание"/>
    <alias field="STATUS" index="21" name="Статус объекта"/>
    <alias field="REG_STATUS" index="22" name="Значение объекта"/>
    <alias field="KADASTROKS" index="23" name="Кадастровый номер объекта капитального строительства"/>
    <alias field="KADASTRZU" index="24" name=""/>
    <alias field="NAMEDOCOSN" index="25" name=""/>
    <alias field="DATEDOCOSN" index="26" name=""/>
    <alias field="NUMBERDOCOSN" index="27" name=""/>
    <alias field="PROP_GR" index="28" name=""/>
    <alias field="PRJ_POVS" index="29" name=""/>
    <alias field="PR_TEU" index="30" name=""/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602030201'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="USING_TYPE" expression="1" applyOnUpdate="0"/>
    <default field="RST_TYPE" expression="if(&quot;CLASSID&quot; = '602030201', attribute('RST_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="RST_CLASS" expression="if(&quot;CLASSID&quot; = '602030201' OR &quot;CLASSID&quot; = '602030202', attribute('RST_CLASS'), NULL)" applyOnUpdate="1"/>
    <default field="RFO_TYPE" expression="if(&quot;CLASSID&quot; = '602030205', attribute('RFO_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="CAPACITY" expression="0" applyOnUpdate="0"/>
    <default field="SUBURBAN_TR" expression="" applyOnUpdate="0"/>
    <default field="FREIGHT" expression="0" applyOnUpdate="0"/>
    <default field="PASS_TRAIN" expression="0" applyOnUpdate="0"/>
    <default field="CARGO_TRAIN" expression="0" applyOnUpdate="0"/>
    <default field="COMPL_NAME" expression="''" applyOnUpdate="0"/>
    <default field="DANGER_OBJ" expression="" applyOnUpdate="0"/>
    <default field="FUNCTION" expression="''" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
    <default field="KADASTROKS" expression="''" applyOnUpdate="0"/>
    <default field="KADASTRZU" expression="''" applyOnUpdate="0"/>
    <default field="NAMEDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="DATEDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="NUMBERDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="PROP_GR" expression="" applyOnUpdate="0"/>
    <default field="PRJ_POVS" expression="" applyOnUpdate="0"/>
    <default field="PR_TEU" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="USING_TYPE" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="RST_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="RST_CLASS" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="RFO_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="CAPACITY" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="SUBURBAN_TR" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FREIGHT" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="PASS_TRAIN" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="CARGO_TRAIN" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="COMPL_NAME" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="DANGER_OBJ" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FUNCTION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="2" field="KADASTROKS" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="KADASTRZU" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAMEDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="DATEDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NUMBERDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="PROP_GR" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="PRJ_POVS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="PR_TEU" unique_strength="0" notnull_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="USING_TYPE" desc="" exp=""/>
    <constraint field="RST_TYPE" desc="Заполняется для объекта 602030201" exp="if(&quot;CLASSID&quot; = '602030201', &quot;RST_TYPE&quot; IS NOT NULL, &quot;RST_TYPE&quot; IS NULL)"/>
    <constraint field="RST_CLASS" desc="Заполняется для объектов 602030201, 602030202" exp="if(&quot;CLASSID&quot; = '602030201' OR &quot;CLASSID&quot; = '602030202', &quot;RST_CLASS&quot; IS NOT NULL, &quot;RST_CLASS&quot; IS NULL)"/>
    <constraint field="RFO_TYPE" desc="Заполняется для объекта 602030205" exp="if(&quot;CLASSID&quot; = '602030205', &quot;RFO_TYPE&quot; IS NOT NULL, &quot;RFO_TYPE&quot; IS NULL)"/>
    <constraint field="CAPACITY" desc="Заполняется для объекта 602030202" exp="if (&quot;CLASSID&quot; = '602030202',&#xa;&#x9;&quot;CAPACITY&quot; > 0,&#xa;&#x9;&quot;CAPACITY&quot; >= 0)"/>
    <constraint field="SUBURBAN_TR" desc="" exp=""/>
    <constraint field="FREIGHT" desc="" exp=""/>
    <constraint field="PASS_TRAIN" desc="Значение должно быть представлено положительным целым числом" exp="&quot;PASS_TRAIN&quot; > 0"/>
    <constraint field="CARGO_TRAIN" desc="Значение должно быть представлено положительным целым числом" exp="&quot;CARGO_TRAIN&quot; > 0"/>
    <constraint field="COMPL_NAME" desc="" exp=""/>
    <constraint field="DANGER_OBJ" desc="" exp=""/>
    <constraint field="FUNCTION" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xd;&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
    <constraint field="KADASTROKS" desc="Кадастровый номер объекта должен соответствовать формату, принятому в ЕГРН" exp="regexp_match(&quot;KADASTROKS&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$')"/>
    <constraint field="KADASTRZU" desc="Обязательно для значений атрибута &quot;STATUS&quot; 1, 3, 4" exp="if (&quot;STATUS&quot; = 1 OR &quot;STATUS&quot; = 3 OR &quot;STATUS&quot; = 4,&#xd;&#xa;&#x9;regexp_match(&quot;KADASTRZU&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$|^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1})$'),&#xd;&#xa;&#x9;length(&quot;KADASTRZU&quot;) >= 0)"/>
    <constraint field="NAMEDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NAMEDOCOSN&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NAMEDOCOSN&quot;) >= 0)"/>
    <constraint field="DATEDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3. Формат даты (ДД.ММ.ГГГГ)." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;regexp_match(&quot;DATEDOCOSN&quot;, '^\\d{2}\\.\\d{2}\\.\\d{4}$'),&#xd;&#xa;&#x9;length(&quot;DATEDOCOSN&quot;) >= 0)"/>
    <constraint field="NUMBERDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NUMBERDOCOSN&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NUMBERDOCOSN&quot;) >= 0)"/>
    <constraint field="PROP_GR" desc="" exp=""/>
    <constraint field="PRJ_POVS" desc="" exp=""/>
    <constraint field="PR_TEU" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="6" name="USING_TYPE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="12" name="FREIGHT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="PASS_TRAIN">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="14" name="CARGO_TRAIN">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="21" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="22" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="11" name="SUBURBAN_TR">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="15" name="COMPL_NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="16" name="DANGER_OBJ">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="17" name="FUNCTION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="19" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="20" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="23" name="KADASTROKS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Тип железнодорожной станции" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602030201'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="7" name="RST_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Класс железнодорожной станции/вокзала" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; IN ('602030201', '602030202')">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="8" name="RST_CLASS">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Тип иных объектов железнодорожного транспорта" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602030205'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="9" name="RFO_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Вместимость железнодорожного вокзала, чел." collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602030202'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="10" name="CAPACITY">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="18" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Кадастровый номер земельного участка и (или) номер кадастрового квартала, в границах которого расположен объект" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (1, 3, 4)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="24" name="KADASTRZU">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Наименование документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="25" name="NAMEDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Дата документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="26" name="DATEDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="27" name="NUMBERDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="CAPACITY" editable="1"/>
    <field name="CARGO_TRAIN" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="COMPL_NAME" editable="1"/>
    <field name="DANGER_OBJ" editable="1"/>
    <field name="DATEDOCOSN" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="FREIGHT" editable="1"/>
    <field name="FUNCTION" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="KADASTROKS" editable="1"/>
    <field name="KADASTRZU" editable="1"/>
    <field name="NAME" editable="1"/>
    <field name="NAMEDOCOSN" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="NUMBERDOCOSN" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="PASS_TRAIN" editable="1"/>
    <field name="PRJ_POVS" editable="1"/>
    <field name="PROP_GR" editable="1"/>
    <field name="PR_TEU" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="RFO_TYPE" editable="1"/>
    <field name="RST_CLASS" editable="1"/>
    <field name="RST_TYPE" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="SUBURBAN_TR" editable="1"/>
    <field name="USING_TYPE" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="CAPACITY"/>
    <field labelOnTop="1" name="CARGO_TRAIN"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="COMPL_NAME"/>
    <field labelOnTop="1" name="DANGER_OBJ"/>
    <field labelOnTop="1" name="DATEDOCOSN"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="FREIGHT"/>
    <field labelOnTop="1" name="FUNCTION"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="KADASTROKS"/>
    <field labelOnTop="1" name="KADASTRZU"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NAMEDOCOSN"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="NUMBERDOCOSN"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="PASS_TRAIN"/>
    <field labelOnTop="0" name="PRJ_POVS"/>
    <field labelOnTop="0" name="PROP_GR"/>
    <field labelOnTop="0" name="PR_TEU"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="RFO_TYPE"/>
    <field labelOnTop="1" name="RST_CLASS"/>
    <field labelOnTop="1" name="RST_TYPE"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS"/>
    <field labelOnTop="1" name="SUBURBAN_TR"/>
    <field labelOnTop="1" name="USING_TYPE"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="CAPACITY" reuseLastValue="0"/>
    <field name="CARGO_TRAIN" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="COMPL_NAME" reuseLastValue="0"/>
    <field name="DANGER_OBJ" reuseLastValue="0"/>
    <field name="DATEDOCOSN" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="FREIGHT" reuseLastValue="0"/>
    <field name="FUNCTION" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="KADASTROKS" reuseLastValue="0"/>
    <field name="KADASTRZU" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NAMEDOCOSN" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="NUMBERDOCOSN" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="PASS_TRAIN" reuseLastValue="0"/>
    <field name="PRJ_POVS" reuseLastValue="0"/>
    <field name="PROP_GR" reuseLastValue="0"/>
    <field name="PR_TEU" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="RFO_TYPE" reuseLastValue="0"/>
    <field name="RST_CLASS" reuseLastValue="0"/>
    <field name="RST_TYPE" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="SUBURBAN_TR" reuseLastValue="0"/>
    <field name="USING_TYPE" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
