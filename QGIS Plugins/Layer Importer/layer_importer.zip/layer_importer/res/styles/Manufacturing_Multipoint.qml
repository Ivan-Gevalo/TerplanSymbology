<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{8652c49e-2177-41c4-b386-f6c8e234b342}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{164794ff-28ce-4d7d-a8c4-1de1f3c7a851}">
        <rule label="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" filter="&quot;CLASSID&quot; = '602020101'" symbol="1" key="{19b3684c-e983-4840-ba02-3cd62bc88e47}"/>
        <rule label="Предприятие нефтеперерабатывающей, коксохимической промышленности" filter="&quot;CLASSID&quot; = '602020102'" symbol="2" key="{f0e373c6-ce80-4537-8bce-cde86905779d}"/>
        <rule label="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" filter="&quot;CLASSID&quot; = '602020103'" symbol="3" key="{eed61764-8ea9-4fff-bcc8-96e0cd01c7bc}"/>
        <rule label="Предприятие металлургии (в том числе цветной металлургии), металлообработки" filter="&quot;CLASSID&quot; = '602020104'" symbol="4" key="{da4ea61b-e7fe-406b-a408-c29b17a477b5}"/>
        <rule label="Предприятие машиностроения" filter="&quot;CLASSID&quot; = '602020105'" symbol="5" key="{752232bd-ab19-4abd-b9ae-7cdeda042553}"/>
        <rule label="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" filter="&quot;CLASSID&quot; = '602020106'" symbol="6" key="{176752db-8a58-4447-bef5-1c5267dd3b2a}"/>
        <rule label="Предприятие по обработке древесины, производству изделий из дерева" filter="&quot;CLASSID&quot; = '602020107'" symbol="7" key="{8e522a84-abdc-4a4b-a12c-c83ea6713704}"/>
        <rule label="Предприятие текстильной, легкой промышленности" filter="&quot;CLASSID&quot; = '602020108'" symbol="8" key="{f0f6df96-5b06-4233-8085-c5eb51f93c33}"/>
        <rule label="Предприятие микробиологической, пищевой, пищевкусовой промышленности" filter="&quot;CLASSID&quot; = '602020109'" symbol="9" key="{3d928939-6190-442d-b635-fe0f33f81f7a}"/>
        <rule label="Предприятие обрабатывающей промышленности иной специализации" filter="&quot;CLASSID&quot; = '602020110'" symbol="10" key="{f448bec5-56a2-4bb5-a52d-3bcb75768dc5}"/>
        <rule label="Предприятие угледобывающей промышленности" filter="&quot;CLASSID&quot; = '602020111'" symbol="11" key="{02495829-c127-4c92-ac5b-2ba2434ebab9}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="12" key="{86ba6048-97bb-432d-950e-b2bfa1212069}">
        <rule label="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" filter="&quot;CLASSID&quot; = '602020101'" symbol="13" key="{4e76ab5e-8401-4582-ac9e-fd4ae0519d6d}"/>
        <rule label="Предприятие нефтеперерабатывающей, коксохимической промышленности" filter="&quot;CLASSID&quot; = '602020102'" symbol="14" key="{99a7ac7d-274d-470c-8485-cbbd48c7ce1e}"/>
        <rule label="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" filter="&quot;CLASSID&quot; = '602020103'" symbol="15" key="{7987a19a-634f-4d84-a2b5-b70615a1d991}"/>
        <rule label="Предприятие металлургии (в том числе цветной металлургии), металлообработки" filter="&quot;CLASSID&quot; = '602020104'" symbol="16" key="{75aef04c-2daf-44be-9871-80c920662151}"/>
        <rule label="Предприятие машиностроения" filter="&quot;CLASSID&quot; = '602020105'" symbol="17" key="{72f2f799-3998-4e1f-85a5-cd875cdc8464}"/>
        <rule label="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" filter="&quot;CLASSID&quot; = '602020106'" symbol="18" key="{0bd397ae-44e5-43ed-b900-8a000982251e}"/>
        <rule label="Предприятие по обработке древесины, производству изделий из дерева" filter="&quot;CLASSID&quot; = '602020107'" symbol="19" key="{3327939d-906e-432f-b12c-7ca2fa62840b}"/>
        <rule label="Предприятие текстильной, легкой промышленности" filter="&quot;CLASSID&quot; = '602020108'" symbol="20" key="{e09a228b-2009-4d35-9b35-64504a204a56}"/>
        <rule label="Предприятие микробиологической, пищевой, пищевкусовой промышленности" filter="&quot;CLASSID&quot; = '602020109'" symbol="21" key="{fe330622-2798-48ea-b3a7-fe4633cfcca9}"/>
        <rule label="Предприятие обрабатывающей промышленности иной специализации" filter="&quot;CLASSID&quot; = '602020110'" symbol="22" key="{fcef133f-0bf8-4499-b2ec-ef5989bd0b87}"/>
        <rule label="Предприятие угледобывающей промышленности" filter="&quot;CLASSID&quot; = '602020111'" symbol="23" key="{3a23ad7b-d57f-4db9-9488-bc4111779ecd}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="24" key="{66e8f1c3-4e23-49b3-a6e5-99a1b3976c13}">
        <rule label="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" filter="&quot;CLASSID&quot; = '602020101'" symbol="25" key="{18509098-f22e-4811-be7b-6872df511fae}"/>
        <rule label="Предприятие нефтеперерабатывающей, коксохимической промышленности" filter="&quot;CLASSID&quot; = '602020102'" symbol="26" key="{b0f74aa5-3529-402f-ad3d-d5d8209e6604}"/>
        <rule label="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" filter="&quot;CLASSID&quot; = '602020103'" symbol="27" key="{05c3d3fb-3e34-475d-977b-db90791f3261}"/>
        <rule label="Предприятие металлургии (в том числе цветной металлургии), металлообработки" filter="&quot;CLASSID&quot; = '602020104'" symbol="28" key="{ddc39b29-40d2-424b-a7ee-341558acecc7}"/>
        <rule label="Предприятие машиностроения" filter="&quot;CLASSID&quot; = '602020105'" symbol="29" key="{b890e477-a0f0-40fa-ac0a-1f4a70f82798}"/>
        <rule label="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" filter="&quot;CLASSID&quot; = '602020106'" symbol="30" key="{52d37253-78a6-4dc1-a508-80aa0152f158}"/>
        <rule label="Предприятие по обработке древесины, производству изделий из дерева" filter="&quot;CLASSID&quot; = '602020107'" symbol="31" key="{ef839c8f-1ea8-443e-9c36-7e49e3f7db98}"/>
        <rule label="Предприятие текстильной, легкой промышленности" filter="&quot;CLASSID&quot; = '602020108'" symbol="32" key="{567f3bc7-764d-486b-90e8-de50fd76c220}"/>
        <rule label="Предприятие микробиологической, пищевой, пищевкусовой промышленности" filter="&quot;CLASSID&quot; = '602020109'" symbol="33" key="{06691127-f65c-4c9a-b708-52df550a5fd9}"/>
        <rule label="Предприятие обрабатывающей промышленности иной специализации" filter="&quot;CLASSID&quot; = '602020110'" symbol="34" key="{cbe09cbb-9490-44f5-af1a-84696efeb815}"/>
        <rule label="Предприятие угледобывающей промышленности" filter="&quot;CLASSID&quot; = '602020111'" symbol="35" key="{ceeb60e1-8eee-42e2-af15-4ae5a4ef5d07}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="36" key="{a50e2e95-6b06-4b39-899a-0ba9aebfe961}">
        <rule label="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" filter="&quot;CLASSID&quot; = '602020101'" symbol="37" key="{5074e77f-f0e3-4c9b-88a1-899f8edd9e28}"/>
        <rule label="Предприятие нефтеперерабатывающей, коксохимической промышленности" filter="&quot;CLASSID&quot; = '602020102'" symbol="38" key="{524b7f82-8b42-4efa-80f9-d48aae768fd3}"/>
        <rule label="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" filter="&quot;CLASSID&quot; = '602020103'" symbol="39" key="{1c43fe00-f38c-4d82-ae59-68da458ababb}"/>
        <rule label="Предприятие металлургии (в том числе цветной металлургии), металлообработки" filter="&quot;CLASSID&quot; = '602020104'" symbol="40" key="{c3818344-6005-4a5a-a42a-6738d4c31005}"/>
        <rule label="Предприятие машиностроения" filter="&quot;CLASSID&quot; = '602020105'" symbol="41" key="{c144403a-8341-459c-99b7-fae5ed5727de}"/>
        <rule label="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" filter="&quot;CLASSID&quot; = '602020106'" symbol="42" key="{48632ef5-8137-4b6e-a2f2-9dfb909e60a5}"/>
        <rule label="Предприятие по обработке древесины, производству изделий из дерева" filter="&quot;CLASSID&quot; = '602020107'" symbol="43" key="{2272600d-16ea-43ec-926c-64d8a8d6203c}"/>
        <rule label="Предприятие текстильной, легкой промышленности" filter="&quot;CLASSID&quot; = '602020108'" symbol="44" key="{c8f977a2-c42b-4685-b470-081a1ac56e91}"/>
        <rule label="Предприятие микробиологической, пищевой, пищевкусовой промышленности" filter="&quot;CLASSID&quot; = '602020109'" symbol="45" key="{52a9c919-6aa5-410e-baa3-f995d30d1856}"/>
        <rule label="Предприятие обрабатывающей промышленности иной специализации" filter="&quot;CLASSID&quot; = '602020110'" symbol="46" key="{8d8e69c8-9555-4ef5-b969-4427a312d226}"/>
        <rule label="Предприятие угледобывающей промышленности" filter="&quot;CLASSID&quot; = '602020111'" symbol="47" key="{8a0906cd-2840-411b-b68b-8af6ce48348a}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="48" key="{8d4a610a-cc9a-43ec-87c7-498ce369d335}">
        <rule label="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" filter="&quot;CLASSID&quot; = '602020101'" symbol="49" key="{96cc3ba2-e29d-47f0-8a55-d6932b6f1485}"/>
        <rule label="Предприятие нефтеперерабатывающей, коксохимической промышленности" filter="&quot;CLASSID&quot; = '602020102'" symbol="50" key="{c3b1baf1-5631-46b3-a83f-8ef710ee15e9}"/>
        <rule label="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" filter="&quot;CLASSID&quot; = '602020103'" symbol="51" key="{1ed4df55-6f64-4480-a20e-3d6eba89e2ea}"/>
        <rule label="Предприятие металлургии (в том числе цветной металлургии), металлообработки" filter="&quot;CLASSID&quot; = '602020104'" symbol="52" key="{f98fcc68-f2e6-49c8-9980-5b54cd2c3628}"/>
        <rule label="Предприятие машиностроения" filter="&quot;CLASSID&quot; = '602020105'" symbol="53" key="{0aebd0ae-d681-4415-b412-51701a78a27b}"/>
        <rule label="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" filter="&quot;CLASSID&quot; = '602020106'" symbol="54" key="{cad6be3a-0160-4e73-8951-3354c665588e}"/>
        <rule label="Предприятие по обработке древесины, производству изделий из дерева" filter="&quot;CLASSID&quot; = '602020107'" symbol="55" key="{8356b9fa-3f85-4e5e-b6c2-06f87fe716c7}"/>
        <rule label="Предприятие текстильной, легкой промышленности" filter="&quot;CLASSID&quot; = '602020108'" symbol="56" key="{5f9ad860-dc28-4f5e-8db1-5d0ccc2e4cb3}"/>
        <rule label="Предприятие микробиологической, пищевой, пищевкусовой промышленности" filter="&quot;CLASSID&quot; = '602020109'" symbol="57" key="{e4020a6d-30fa-45f2-9eec-02682f075801}"/>
        <rule label="Предприятие обрабатывающей промышленности иной специализации" filter="&quot;CLASSID&quot; = '602020110'" symbol="58" key="{02c951b6-b072-424d-a4de-6bdf005dde32}"/>
        <rule label="Предприятие угледобывающей промышленности" filter="&quot;CLASSID&quot; = '602020111'" symbol="59" key="{4c92e175-f945-44f8-8bb1-ec1b02b087e0}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="60" key="{32813e13-fddb-4b4f-8f30-99c0ac15400f}">
        <rule label="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" filter="&quot;CLASSID&quot; = '602020101'" symbol="61" key="{6a54b51c-efb2-44a8-8f84-eb029af66bd6}"/>
        <rule label="Предприятие нефтеперерабатывающей, коксохимической промышленности" filter="&quot;CLASSID&quot; = '602020102'" symbol="62" key="{f8852d38-0b31-4f85-ab72-19e9f60c6773}"/>
        <rule label="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" filter="&quot;CLASSID&quot; = '602020103'" symbol="63" key="{e83da981-d6a8-4c90-92c8-0db305b439e5}"/>
        <rule label="Предприятие металлургии (в том числе цветной металлургии), металлообработки" filter="&quot;CLASSID&quot; = '602020104'" symbol="64" key="{73ebeeaa-11f2-48d7-a7dd-9ad6a0237c69}"/>
        <rule label="Предприятие машиностроения" filter="&quot;CLASSID&quot; = '602020105'" symbol="65" key="{4eb874f4-f81b-4994-9940-5102054c59d1}"/>
        <rule label="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" filter="&quot;CLASSID&quot; = '602020106'" symbol="66" key="{05568667-3256-4766-b4fb-73b335c2d86d}"/>
        <rule label="Предприятие по обработке древесины, производству изделий из дерева" filter="&quot;CLASSID&quot; = '602020107'" symbol="67" key="{c6efed93-2e7a-4eaf-8f6d-b0dde7221fb6}"/>
        <rule label="Предприятие текстильной, легкой промышленности" filter="&quot;CLASSID&quot; = '602020108'" symbol="68" key="{9000fa1e-a68b-4339-8e01-b99f39f86e70}"/>
        <rule label="Предприятие микробиологической, пищевой, пищевкусовой промышленности" filter="&quot;CLASSID&quot; = '602020109'" symbol="69" key="{335c60fb-675c-4982-a3dd-0979f8d5d500}"/>
        <rule label="Предприятие обрабатывающей промышленности иной специализации" filter="&quot;CLASSID&quot; = '602020110'" symbol="70" key="{d8ad5999-849d-44b5-b4fd-6825d3da2496}"/>
        <rule label="Предприятие угледобывающей промышленности" filter="&quot;CLASSID&quot; = '602020111'" symbol="71" key="{2041c2d3-d96d-447b-a915-ccaff3354e68}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="72" key="{e8bb4ff3-d144-4a7a-bc38-214e5e594c36}">
        <rule label="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" filter="&quot;CLASSID&quot; = '602020101'" symbol="73" key="{979bb0c9-2f1f-4695-b4a4-734b34d1c663}"/>
        <rule label="Предприятие нефтеперерабатывающей, коксохимической промышленности" filter="&quot;CLASSID&quot; = '602020102'" symbol="74" key="{94d49888-db91-42a6-a5f7-a7d588faa4de}"/>
        <rule label="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" filter="&quot;CLASSID&quot; = '602020103'" symbol="75" key="{f3ece995-658e-411e-850b-cad2d7fb326d}"/>
        <rule label="Предприятие металлургии (в том числе цветной металлургии), металлообработки" filter="&quot;CLASSID&quot; = '602020104'" symbol="76" key="{314d8904-a9dd-410b-829a-9b7b8652a58d}"/>
        <rule label="Предприятие машиностроения" filter="&quot;CLASSID&quot; = '602020105'" symbol="77" key="{8a3735cd-aefc-42f8-94d7-0193a1ec3bdc}"/>
        <rule label="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" filter="&quot;CLASSID&quot; = '602020106'" symbol="78" key="{648b652a-a320-4863-a6e8-f0c61875f36b}"/>
        <rule label="Предприятие по обработке древесины, производству изделий из дерева" filter="&quot;CLASSID&quot; = '602020107'" symbol="79" key="{798a3055-e491-4c59-9cff-c76fe4067fd9}"/>
        <rule label="Предприятие текстильной, легкой промышленности" filter="&quot;CLASSID&quot; = '602020108'" symbol="80" key="{842533a9-afc3-4106-995c-7267e39aaa42}"/>
        <rule label="Предприятие микробиологической, пищевой, пищевкусовой промышленности" filter="&quot;CLASSID&quot; = '602020109'" symbol="81" key="{f781ad39-e751-4a81-a2fc-29196fbe6a28}"/>
        <rule label="Предприятие обрабатывающей промышленности иной специализации" filter="&quot;CLASSID&quot; = '602020110'" symbol="82" key="{36b48dde-603e-4b40-b7a0-a7cd80910a19}"/>
        <rule label="Предприятие угледобывающей промышленности" filter="&quot;CLASSID&quot; = '602020111'" symbol="83" key="{9c9a205d-e836-4813-a933-3410d0ce5d03}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты регионального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 2" symbol="84" key="{9c13ccb7-5391-4f9b-a30f-a414037426e4}">
        <rule label="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" filter="&quot;CLASSID&quot; = '602020101'" symbol="85" key="{36615265-cf92-42cd-8ccd-80c1f8262470}"/>
        <rule label="Предприятие нефтеперерабатывающей, коксохимической промышленности" filter="&quot;CLASSID&quot; = '602020102'" symbol="86" key="{b9731ad0-6a78-4c4c-a035-efbc5307b306}"/>
        <rule label="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" filter="&quot;CLASSID&quot; = '602020103'" symbol="87" key="{482677f0-e3c2-4373-91b8-cdb4b69319e9}"/>
        <rule label="Предприятие металлургии (в том числе цветной металлургии), металлообработки" filter="&quot;CLASSID&quot; = '602020104'" symbol="88" key="{233fd0a3-3836-4d27-9caf-a35eb09a9a4a}"/>
        <rule label="Предприятие машиностроения" filter="&quot;CLASSID&quot; = '602020105'" symbol="89" key="{43e3d1db-34ac-4036-b111-c57475a9b544}"/>
        <rule label="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" filter="&quot;CLASSID&quot; = '602020106'" symbol="90" key="{36c706ac-69f5-4995-b142-38d507064974}"/>
        <rule label="Предприятие по обработке древесины, производству изделий из дерева" filter="&quot;CLASSID&quot; = '602020107'" symbol="91" key="{2d34449d-eae8-4545-b5a9-a498dd19d96a}"/>
        <rule label="Предприятие текстильной, легкой промышленности" filter="&quot;CLASSID&quot; = '602020108'" symbol="92" key="{9eb94df1-a74f-4d70-b497-bc6602948e05}"/>
        <rule label="Предприятие микробиологической, пищевой, пищевкусовой промышленности" filter="&quot;CLASSID&quot; = '602020109'" symbol="93" key="{27eb4ee7-da68-43d7-aaf6-014b0515af1b}"/>
        <rule label="Предприятие обрабатывающей промышленности иной специализации" filter="&quot;CLASSID&quot; = '602020110'" symbol="94" key="{ea0f3acf-6dba-477b-9381-148bab0e76a3}"/>
        <rule label="Предприятие угледобывающей промышленности" filter="&quot;CLASSID&quot; = '602020111'" symbol="95" key="{971c1c52-89fa-46ef-ba0e-100b81a4c47e}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="96" key="{d338a940-b733-45f3-a219-202d6c24e7a5}">
        <rule label="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" filter="&quot;CLASSID&quot; = '602020101'" symbol="97" key="{12fb6147-c347-407c-9974-2594f6b599a1}"/>
        <rule label="Предприятие нефтеперерабатывающей, коксохимической промышленности" filter="&quot;CLASSID&quot; = '602020102'" symbol="98" key="{b78815e6-de12-4070-a94f-19fd93c39517}"/>
        <rule label="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" filter="&quot;CLASSID&quot; = '602020103'" symbol="99" key="{951c0bbb-3e79-4d32-963a-85a965f30998}"/>
        <rule label="Предприятие металлургии (в том числе цветной металлургии), металлообработки" filter="&quot;CLASSID&quot; = '602020104'" symbol="100" key="{cb25620b-1bdc-4521-863c-16c7d6bb9020}"/>
        <rule label="Предприятие машиностроения" filter="&quot;CLASSID&quot; = '602020105'" symbol="101" key="{3ec7dc29-6181-4423-a229-a0a62869c3a2}"/>
        <rule label="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" filter="&quot;CLASSID&quot; = '602020106'" symbol="102" key="{530d1ceb-15bc-4411-8429-71b43d4cc89b}"/>
        <rule label="Предприятие по обработке древесины, производству изделий из дерева" filter="&quot;CLASSID&quot; = '602020107'" symbol="103" key="{d9c88b01-d320-4324-aafa-8fa76b571442}"/>
        <rule label="Предприятие текстильной, легкой промышленности" filter="&quot;CLASSID&quot; = '602020108'" symbol="104" key="{ec44e142-10b6-4b94-941d-d291f2b2d189}"/>
        <rule label="Предприятие микробиологической, пищевой, пищевкусовой промышленности" filter="&quot;CLASSID&quot; = '602020109'" symbol="105" key="{3e69ffdc-9229-4956-8689-5b7d27a2715c}"/>
        <rule label="Предприятие обрабатывающей промышленности иной специализации" filter="&quot;CLASSID&quot; = '602020110'" symbol="106" key="{d71083b9-e1cc-4c67-b85e-7fb56239f020}"/>
        <rule label="Предприятие угледобывающей промышленности" filter="&quot;CLASSID&quot; = '602020111'" symbol="107" key="{703fb741-b69e-4923-a0cd-342eeb6b520a}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="108" key="{5faa1f0d-6e49-4512-add7-d0abab828a9e}">
        <rule label="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" filter="&quot;CLASSID&quot; = '602020101'" symbol="109" key="{74c13bdf-4450-496b-85cc-e73d0fd236b9}"/>
        <rule label="Предприятие нефтеперерабатывающей, коксохимической промышленности" filter="&quot;CLASSID&quot; = '602020102'" symbol="110" key="{8787b538-902a-4d6b-9c79-89522d0203e8}"/>
        <rule label="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" filter="&quot;CLASSID&quot; = '602020103'" symbol="111" key="{3c927b7d-b15b-473a-a2f8-4e1d0f7881b9}"/>
        <rule label="Предприятие металлургии (в том числе цветной металлургии), металлообработки" filter="&quot;CLASSID&quot; = '602020104'" symbol="112" key="{282f2f73-07e8-4d6c-96bc-39b9485bfdd5}"/>
        <rule label="Предприятие машиностроения" filter="&quot;CLASSID&quot; = '602020105'" symbol="113" key="{5f77f05e-44b7-4672-a1af-3fca6b8f9b18}"/>
        <rule label="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" filter="&quot;CLASSID&quot; = '602020106'" symbol="114" key="{4c662e1a-d20f-4a4f-af26-c2e51d9dbd2f}"/>
        <rule label="Предприятие по обработке древесины, производству изделий из дерева" filter="&quot;CLASSID&quot; = '602020107'" symbol="115" key="{cc2a5299-239a-45c5-bb16-f46abd03b595}"/>
        <rule label="Предприятие текстильной, легкой промышленности" filter="&quot;CLASSID&quot; = '602020108'" symbol="116" key="{ca8f6fdd-87cd-4b59-bceb-6a385bc99ab7}"/>
        <rule label="Предприятие микробиологической, пищевой, пищевкусовой промышленности" filter="&quot;CLASSID&quot; = '602020109'" symbol="117" key="{13cd486e-f1ad-4b18-bee6-216b019464ba}"/>
        <rule label="Предприятие обрабатывающей промышленности иной специализации" filter="&quot;CLASSID&quot; = '602020110'" symbol="118" key="{10ddc25c-fa23-4745-b1b2-f831673267cb}"/>
        <rule label="Предприятие угледобывающей промышленности" filter="&quot;CLASSID&quot; = '602020111'" symbol="119" key="{7d80fb2f-d999-4786-9d31-6cee39385af6}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="120" key="{9fe732bf-a162-4a17-81e1-41b3db887fae}">
        <rule label="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" filter="&quot;CLASSID&quot; = '602020101'" symbol="121" key="{f9ca53b7-1d7e-4cfa-8222-c7ecaf4bfc89}"/>
        <rule label="Предприятие нефтеперерабатывающей, коксохимической промышленности" filter="&quot;CLASSID&quot; = '602020102'" symbol="122" key="{b01e9f1f-62cd-478f-bdf8-4f7d2fff3cc2}"/>
        <rule label="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" filter="&quot;CLASSID&quot; = '602020103'" symbol="123" key="{c4915deb-ded2-492a-b5e7-61c025c5c94e}"/>
        <rule label="Предприятие металлургии (в том числе цветной металлургии), металлообработки" filter="&quot;CLASSID&quot; = '602020104'" symbol="124" key="{293bf9e7-b6f8-441e-8fbb-a62f3b6f22c0}"/>
        <rule label="Предприятие машиностроения" filter="&quot;CLASSID&quot; = '602020105'" symbol="125" key="{e88aefe4-ebb8-42a4-83f0-0fa2e3b2ac19}"/>
        <rule label="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" filter="&quot;CLASSID&quot; = '602020106'" symbol="126" key="{6d619d3d-7377-40d1-a265-492dc73ddc53}"/>
        <rule label="Предприятие по обработке древесины, производству изделий из дерева" filter="&quot;CLASSID&quot; = '602020107'" symbol="127" key="{5bf64ef0-9385-4145-9fda-a4d5679491c8}"/>
        <rule label="Предприятие текстильной, легкой промышленности" filter="&quot;CLASSID&quot; = '602020108'" symbol="128" key="{bfea434f-c696-48b5-9da6-ed6f2da86e75}"/>
        <rule label="Предприятие микробиологической, пищевой, пищевкусовой промышленности" filter="&quot;CLASSID&quot; = '602020109'" symbol="129" key="{c492319b-8e86-445e-a95c-736dc4a6f136}"/>
        <rule label="Предприятие обрабатывающей промышленности иной специализации" filter="&quot;CLASSID&quot; = '602020110'" symbol="130" key="{fd910838-efad-4230-88c5-328cb4d218ba}"/>
        <rule label="Предприятие угледобывающей промышленности" filter="&quot;CLASSID&quot; = '602020111'" symbol="131" key="{969c36f2-d0f9-4001-af4c-99bb3f12b65e}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты федерального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 1" symbol="132" key="{6361d1ae-7609-4d2d-a8d9-f6ea6f5ea5d5}">
        <rule label="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" filter="&quot;CLASSID&quot; = '602020101'" symbol="133" key="{18c68bbf-a60d-4a3f-b27c-6a5b1f47ee44}"/>
        <rule label="Предприятие нефтеперерабатывающей, коксохимической промышленности" filter="&quot;CLASSID&quot; = '602020102'" symbol="134" key="{879270f7-f9a5-4c3b-84cd-a132e487a452}"/>
        <rule label="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" filter="&quot;CLASSID&quot; = '602020103'" symbol="135" key="{ea3bc859-2b5d-4480-8d37-d4f36c7e7f64}"/>
        <rule label="Предприятие металлургии (в том числе цветной металлургии), металлообработки" filter="&quot;CLASSID&quot; = '602020104'" symbol="136" key="{f1300989-250d-4fa5-ad52-29ff68665fc3}"/>
        <rule label="Предприятие машиностроения" filter="&quot;CLASSID&quot; = '602020105'" symbol="137" key="{1d134841-8cc4-40ee-a27c-a0d01a81c525}"/>
        <rule label="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" filter="&quot;CLASSID&quot; = '602020106'" symbol="138" key="{4cee18f1-371a-400b-bd23-677aba820b26}"/>
        <rule label="Предприятие по обработке древесины, производству изделий из дерева" filter="&quot;CLASSID&quot; = '602020107'" symbol="139" key="{8ed1b25c-3454-44cd-a1e9-22e3d969632a}"/>
        <rule label="Предприятие текстильной, легкой промышленности" filter="&quot;CLASSID&quot; = '602020108'" symbol="140" key="{9b1f3964-1454-4c44-ac74-8f3332ae8be7}"/>
        <rule label="Предприятие микробиологической, пищевой, пищевкусовой промышленности" filter="&quot;CLASSID&quot; = '602020109'" symbol="141" key="{e518e8a6-2312-4149-80ed-285e36f89b88}"/>
        <rule label="Предприятие обрабатывающей промышленности иной специализации" filter="&quot;CLASSID&quot; = '602020110'" symbol="142" key="{de6d887a-0938-4feb-9eed-23d84987f66e}"/>
        <rule label="Предприятие угледобывающей промышленности" filter="&quot;CLASSID&quot; = '602020111'" symbol="143" key="{29777752-1b67-43fa-bb60-752846049743}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="231,113,72,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5OS42NW1tIiBoZWlnaHQ9IjEzMS4yN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTkuNjUgMTMxLjI3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02LjY4NDcgLTk0LjExNykiPjxyZWN0IHg9IjE4NS4xNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjEuMTc2IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjEwMi4yNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjIuNTU3IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjExNC4zIiB5PSIyMTEuNDQiIHdpZHRoPSI3Ny4zMjUiIGhlaWdodD0iOS42MjExIi8+PHJlY3QgeD0iMTM4LjU5IiB5PSIxOTUuNjYiIHdpZHRoPSIzMS44ODMiIGhlaWdodD0iMTcuODMyIi8+PHJlY3QgeD0iMTEzLjMxIiB5PSIxNDguNTYiIHdpZHRoPSI5My4wMjEiIGhlaWdodD0iNTEuNjA3Ii8+PHJlY3QgeD0iMTY5LjQ2IiB5PSIxMzkuODQiIHdpZHRoPSIzNi44NzQiIGhlaWdodD0iMTcuNDQyIi8+PHBhdGggZD0ibTExOC4zMyAxMzAuODN2MjQuNTM3aDI0Ljk2MXYtMjQuNTM3em02LjI3MiA2LjI3ODJoOC43OTMzdjExLjQ0OWgtOC43OTMzeiIvPjxwYXRoIGQ9Im0xMjAuMyAxNDQuNzhoLTEwLjg0NmwtMTMuNjAxLTE2LjE5MyAyLjIyODktMy40NDg3aDEwLjAyOGwzLjgwOTctMy42NDM5LTAuMjIyMDctMi40ODQ2IDcuMDQ0Ni01LjcxMTggMi4xMDcyIDIuMzEzMyAyLjIxMjktMC43NTE1OHYtOC4xMTJsLTIuMTM0OC0xLjkzODQtMy4xMTA4IDAuMzI4NDV2LTQuNDQ0M2wtMi4xODc1LTMuMjE3NmgtNi4yNTE1bC0yMi4zNDYgMjQuMzczaC04LjQ2ODJsLTI3LjczNS0yNy43MjloLTkuNDhsLTQuMzY1NCA1Ljg1ODkgMjkuMTA5IDI5LjY1N2g1LjI3MThsMi4xOTYyIDIuMTYydjIuOTcwNGwtMi40MTU1IDIuMTI3OWgtOS4zMzc2bC0yMS4zOTggMjEuMjEyaC0xOS45MzRsLTEzLjc5MSAyMi41Nzl2My45MjA4aDMyLjU3OHYtNC43MTQxaDcuMTM2MnYtMTcuNDgzbDI3LjY0NC0yMC40MjdoMTIuOTAybDI5LjIxNiAyNC4xNDl6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43OW1tIiBoZWlnaHQ9IjEyMy43OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzkgMTIzLjc5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS4zNTggLTkxLjgyNikiPjxnPjxyZWN0IHg9IjE1OC43OCIgeT0iOTEuODI2IiB3aWR0aD0iMTMuMjYyIiBoZWlnaHQ9Ijg2LjE3Ii8+PHJlY3QgeD0iMTM4LjA4IiB5PSI5MS44MjYiIHdpZHRoPSIxMy4yNjIiIGhlaWdodD0iODYuMTciLz48cmVjdCB4PSIxMTMuMTIiIHk9IjkxLjgyNiIgd2lkdGg9IjEzLjI2MiIgaGVpZ2h0PSI4Ni4xNyIvPjxwYXRoIGQ9Im00NS44ODggMTc1LjcxLTAuNTI5MTcgMC41MjkxNnYzOS4zNzRoMTM3Ljc5di0zOS45MDR6bTQuNjUxOSA1LjI1MDhoMjIuNzI5djYuODk3OGgtMjIuNzI5em0yNy45NzkgMGgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bTI3LjkzMiAwaDE5LjExOXY2Ljg5NzhoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3OGgtMjIuNzI5em0tNzYuNzE2IDExLjI1MmgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bS01Mi4zNDcgMC4zNjc5M2gyMi43Mjl2Ni44OTczaC0yMi43Mjl6bTgwLjI3OSAwaDE5LjExOXY2Ljg5NzNoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3M2gtMjIuNzI5eiIvPjxwYXRoIGQ9Im03MC40MTEgMTUxLjE4LTEyLjkxNCAxMi45MTQtMTIuMTM4IDEyLjEzOWgyNS4wNTN6Ii8+PHBhdGggZD0ibTk0LjkzNSAxNTEuMTgtMTIuOTE0IDEyLjkxNC0xMi4xMzggMTIuMTM5aDI1LjA1M3oiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="100" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3OC4xM21tIiBoZWlnaHQ9IjExNy45NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzguMTMgMTE3Ljk0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTIzLjg2NSkiPjxwYXRoIGQ9Im0yMy43NzEgMjMuODY1djYyLjQ3M2gtMC4wMDIxYzEuMDllLTQgMC4wMjc2MSAwLjAwMjEgMC4wNTQ4MSAwLjAwMjEgMC4wODI1djIzLjI1MWMwIDEyLjE2LTEwLjU5IDIxLjk1Ny0yMy43NzEgMjIuMDI2djEwLjEwNGg5NS42OTl2LTEwLjEwNGMtMTMuMTgyLTAuMDY5MS0yMy43NzEtOS44NjYtMjMuNzcxLTIyLjAyNnYtMjMuMjUxYzAtMC4wMjc3IDJlLTMgLTAuMDU0ODkgMC4wMDIxLTAuMDgyNWgtMC4wMDIxdi02Mi40NzN6Ii8+PHBhdGggZD0ibTEyMS43NCA0OS4wM3Y0OS4xNDNoLTJlLTNjOGUtNSAwLjAyMTcgMmUtMyAwLjA0MzA2IDJlLTMgMC4wNjQ5MnYxOC4yODljMCA5LjU2NTctOC4zMDI3IDE3LjI3Mi0xOC42MzggMTcuMzI3djcuOTQ4NGg3NS4wMzJ2LTcuOTQ4NGMtMTAuMzM1LTAuMDU0My0xOC42MzgtNy43NjA5LTE4LjYzOC0xNy4zMjd2LTE4LjI4OWMwLTAuMDIxNzggMmUtMyAtMC4wNDMxNCAyZS0zIC0wLjA2NDkyaC0yZS0zdi00OS4xNDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0.40000000000000002" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="101" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS4zbW0iIGhlaWdodD0iMTM5Ljk0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OS4zIDEzOS45NCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzIuMjYzIC03Ni44ODQpIj48Y2lyY2xlIGN4PSI3OS40OTEiIGN5PSIxOTUuOTgiIHI9IjE2Ljg1IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48Y2lyY2xlIGN4PSIxNTQuOCIgY3k9IjE5NS45OCIgcj0iMTYuODUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3Ljk4MTUiLz48Zz48cmVjdCB4PSIxMDMuMzUiIHk9IjE4Mi42MiIgd2lkdGg9IjI1LjU0OSIgaGVpZ2h0PSIxNi4yMjIiLz48cGF0aCBkPSJtMzIuMjYzIDE0OS4wOHY0Mi43OThoMjEuOTlhMjQuODI3IDI0LjgyNyAwIDAgMSAyMC4wMzMtMjAuNTk2di0yMi4yMDN6bTQuNzY1MSA1LjAwMjhoMTcuNjI3djIwLjEzM2gtMTcuNjI3eiIvPjxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDQwLjE1MykiIGQ9Im0xNDUuMDcgNi43OTExLTMuOWUtNCA0MS4yOSA2NS4wMzktMi42ZS01IDI5LjM2Ny0yNC43NzYgMi45ZS00IC0xNi41MTR6Ii8+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoMzkuODQ5KSIgZD0ibTE3MS4wMSA0My41NTUtMi45ZS00IDUuNDU3MSA0LjQyMDMgMmUtNSAyZS01IDI1LjQ5IDExLjgwNS0yLjI1ZS00IDIuM2UtNCAtMjUuNDI4IDUuMTA3OCAzLjU4ZS00IDVlLTUgLTUuNTE5NXoiLz48cGF0aCBkPSJtMTcxLjEgMTUzLjIzLTEyLjk1MiAxOC45OTloOS44NjI0bDguNTU0NSAxMC45OTIgNS4wMDE4IDAuMzM2OTN2LTE5Ljc5NWwtMi45MDczLTQuMTU2M3oiLz48cGF0aCBkPSJtMTEzLjAyIDEwNC4yNC02LjUyMjctNS41MDI5LTIzLjEzMi0xOS45MDUtOC41MjY2LTEuOTQ2NiAwLjA1MzA4OSA4LjIyMDcgMjUuNjIxIDIwLjcyNSA0LjQ4MzUgNS4xNzQyeiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="102" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzMi4xNm1tIiBoZWlnaHQ9IjEyMy44Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzIuMTYgMTIzLjg2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4yMTkgLTkxLjcyMSkiPjxnPjxyZWN0IHg9IjE2MS45NyIgeT0iOTEuNzIxIiB3aWR0aD0iMTYuNDEiIGhlaWdodD0iMTIzLjg2Ii8+PHJlY3QgeD0iNDYuMjIiIHk9IjE2OC4yNSIgd2lkdGg9IjEzMi4xNiIgaGVpZ2h0PSI0Ny4zMjgiLz48cmVjdCB4PSIxNDAuMDQiIHk9IjkxLjcyMSIgd2lkdGg9IjE2LjQxIiBoZWlnaHQ9IjEyMy44NiIvPjxwYXRoIGQ9Im03NS42NDkgMTM4LjczLTI5LjQyOSAyOS40Mjl2MTMuOTU5aDI5LjQyOXoiLz48cGF0aCBkPSJtMTA1LjA4IDEzOC43My0yOS40MjkgMjkuNDI5djEzLjk1OWgyOS40Mjl6Ii8+PHBhdGggZD0ibTEzNC41MSAxMzguNzMtMjkuNDI5IDI5LjQyOXYxMy45NTloMjkuNDI5eiIvPjxyZWN0IHg9IjQ2LjIxOSIgeT0iMTY4LjI1IiB3aWR0aD0iMTMyLjE2IiBoZWlnaHQ9IjEzLjc2OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="103" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNi4zM21tIiBoZWlnaHQ9IjEzOC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTYuMzMgMTM4LjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NS4wNSAtODEuMjY0KSI+PGc+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iMTQ4LjM2IiB5PSIxMjYuNDUiIHdpZHRoPSIyMy4wMTUiIGhlaWdodD0iOTMuMDgxIiBzdHJva2Utd2lkdGg9IjcuNTQ3NCIvPjxyZWN0IHg9IjU1LjA1IiB5PSIxODUuNDkiIHdpZHRoPSIxMTYuMzMiIGhlaWdodD0iMzQuMDQxIiBzdHJva2Utd2lkdGg9IjcuOTgyIi8+PHBhdGggZD0ibTEwMC42NCAxNDguMjcgMWUtNSAxMy40NzUgNjIuNzI5IDIyLjIyMiA0LjI0MTYtMTEuOTcyeiIgc3Ryb2tlLXdpZHRoPSI3Ljk4MiIvPjxwYXRoIGQ9Im01NS4wNSAxNTEuMzQtNGUtNiAxNS4zNTYgNzguMjY1IDI4LjIyNiAxMC42ODQtMTEuNTAzeiIgc3Ryb2tlLXdpZHRoPSIxMi43OTkiLz48cmVjdCB4PSIxMzguNDIiIHk9IjE4Mi43MSIgd2lkdGg9IjEzLjY5MyIgaGVpZ2h0PSI0LjE5NzMiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48cGF0aCBkPSJtNTUuMDUgMTcxLjM0IDVlLTYgMjEuMjkxIDMzLjk2IDEyLjQ5MSA2Ljg5NzItMTguNzUzeiIgc3Ryb2tlLXdpZHRoPSI4Ljk0NjciLz48L2c+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMS42NjM1IDAgMCAxLjY2MzUgMTUyLjI1IC02MC45MjIpIj48Y2lyY2xlIGN4PSIxLjk1MzMiIGN5PSIxMDIuNDUiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9IjMuNzgxNCIgY3k9IjEwOC41MiIgcj0iMi45MDY3Ii8+PGNpcmNsZSBjeD0iMS45OTk4IiBjeT0iMTA1Ljg4IiByPSIyLjkwNjciLz48Y2lyY2xlIGN4PSIxLjE4NDMiIGN5PSIxMDcuMDEiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9Ii01LjAwNTkiIGN5PSI5NS41NzYiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii00LjQyOTgiIGN5PSIxMDAuOTkiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii0zMS42NDYiIGN5PSI5NC4yMzIiIHI9IjYuODcxOCIvPjxjaXJjbGUgY3g9Ii0zMy45MzYiIGN5PSIxMDYuNDIiIHI9IjQuNjYzNiIvPjxjaXJjbGUgY3g9Ii0zMC4xNzgiIGN5PSIxMDYuMjMiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii0zNi45NDciIGN5PSIxMDQuNTIiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii00Ny44OCIgY3k9IjEwNS4zMSIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUwLjgyOSIgY3k9IjEwNC4zNyIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUxLjI1MSIgY3k9IjEwMC43NiIgcj0iNS41NDA4Ii8+PGNpcmNsZSBjeD0iLTUyLjQ0OCIgY3k9IjkzLjAxNiIgcj0iMS41NTQ2Ii8+PGNpcmNsZSBjeD0iLTQ5LjU5OSIgY3k9IjkyLjA0MSIgcj0iMS45NjkxIi8+PGVsbGlwc2UgY3g9Ii00NS43OTEiIGN5PSI5My4xMjIiIHJ4PSIzLjczNTYiIHJ5PSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItNDIuMzk2IiBjeT0iOTMuOTY3IiByPSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItMzguNzMiIGN5PSI5My42NjUiIHI9IjEuOTY5MSIvPjxjaXJjbGUgY3g9Ii0xMS43NTYiIGN5PSIxMDYuNTkiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xNC43MDUiIGN5PSIxMDUuNDYiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xOS45NTIiIGN5PSIxMDEuMTgiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0yNi44MjIiIGN5PSIxMDEuNSIgcj0iNC42MjMyIi8+PGNpcmNsZSBjeD0iLTEyLjA1IiBjeT0iODcuNzMxIiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNS45NzU4IiBjeT0iOTAuMTQ5IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNi45NjI4IiBjeT0iODguNzI1IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItMTQuODc0IiBjeT0iOTEuMjM3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMTcuMDY1IiBjeT0iOTMuNzc2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItNDMuNTQ0IiBjeT0iMTAzLjE3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjAuOTc4IiBjeT0iOTcuNTI1IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjUuNzQ3IiBjeT0iOTYuMTk2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItOS42MzA0IiBjeT0iODkuMzU2IiByPSIyLjIyMTQiLz48Y2lyY2xlIGN4PSItNTEuMTc1IiBjeT0iOTYuMzEyIiByPSIyLjIyMTQiLz48ZWxsaXBzZSBjeD0iMy42MzY2IiBjeT0iMTEyLjkzIiByeD0iMy4yOTc3IiByeT0iNy4yNjQ5Ii8+PHBhdGggZD0ibS0wLjI0ODI4IDEwNy4wOGMtMS41NWUtNiAyLjU1MzMtMS44MzE4IDAuMjMyMTUtNC4zODUyIDAuMjMyMTVzLTQuODYxMyAyLjMyMTItNC44NjEzLTAuMjMyMTVjLTRlLTYgLTIuNTUzMyAyLjA2OTktNC42MjMyIDQuNjIzMi00LjYyMzIgMi41NTMzIDAgNC42MjMyIDIuMDY5OSA0LjYyMzIgNC42MjMyeiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjQyMzUiLz48cGF0aCBkPSJtLTUwLjQ2IDkyLjcxLTEuNDQyNCAwLjQ0OTcyLTAuMDYxNzggMi42MjM0czAuOTA3NzMgMi44MzE2IDEuMDQyNSAzLjA2MDdjMC4xMzQ3NiAwLjIyOTEgMi42MDk0IDMuNDY4IDIuNjA5NCAzLjQ2OGw1LjIzODEgMC40OTM1NyAzLjcyMDMgMS4yNTE0IDMuNzY4IDAuMjE4NzFzNC44MTEyIDEuMjc1MSA1LjIzNzMgMC44MjI0N2MwLjQyNjA2LTAuNDUyNjYgMS40NDg4LTUuMDU0MiAxLjQxMzYtNS4zNTQ1LTAuMDM1MTYtMC4zMDAzNC0zLjM5NTctMS43NzQ1LTMuMzk1Ny0xLjc3NDVsLTMuODQwNS0yLjU0NzItMS42MjUtMS4yMTM0LTIuOTQ0Ni0wLjEwMDkycy0yLjc2MjctMC4zNTA3MS0zLjAzMTQtMC41MTY0NWMtMC4yNjg3Mi0wLjE2NTc1LTMuMTkxNC0wLjc2NTgtMy4zNDczLTAuNzY1OC0wLjE1NTg4IDAtMy4zNDA1LTAuMTE1My0zLjM0MDUtMC4xMTUzeiIvPjxwYXRoIGQ9Im0tMjAuMTk2IDk2LjUwNyAyLjkwNTQgNy4xMTYxIDQuOTYzNiAyLjIxMzUgNy4yMjgyLTAuMzU5MDkgNS4zOTc1IDAuNDAyODVzMS4xNDY1LTIuNDc2MyAxLjE2NjYtMi42Mzg1YzAuMDIwMTA4LTAuMTYyMjMtMi4yNDgzLTEuODA5OC0yLjI0ODMtMS44MDk4bC0xLjQ3OTgtMi4xNjU2LTAuMjEyNTItMi43NjQ5cy0xLjUxOTQtMi4zOTMzLTEuNTIyOC0yLjU1NTVjLTAuMDAzMzMtMC4xNjIxNy0yLjYyMjktNC4yNzMyLTIuNjIyOS00LjI3MzJsLTUuMjE1OS0wLjA2MjAzLTUuMTcyNCAzLjUyOTV6Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.54348" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="104" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0NC43OG1tIiBoZWlnaHQ9Ijk1LjM2M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDQuNzggOTUuMzYzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNi43MjcgLTEwNi4yNykiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE3MS40NyAxMDYuMjd2OTUuMzYzIiBzdHJva2Utd2lkdGg9IjIwLjA3OSIvPjxwYXRoIGQ9Im0xNzEuNDcgMTk1LjQ5aC0xMjguNjF2LTQzLjcxNGwyMy4xNDQtMTQuMTQ5IDEwLjU5MiAxOS4yMjQgMjguNjg0LTE5LjcyNyAxMi42MTEgMjAuNTczIDMwLjU5OS0yMi41MSAxOC42ODggMzEuNTQiIHN0cm9rZS13aWR0aD0iMTIuMjY5Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="105" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43NG1tIiBoZWlnaHQ9IjEyMy4wN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzQgMTIzLjA3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40MDkgLTk1LjY1NCkiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGcgc3Ryb2tlLXdpZHRoPSI4LjgxMiI+PHBhdGggZD0ibTQ5LjgxNSAxNzAuOTN2NDMuMzg2aDI4LjYzOXYtMzMuNzg1aDIyLjM0NiIvPjxwYXRoIGQ9Im0xNTAuNjMgMTcwLjkzdjQzLjM4NmgtMjguNjM5di0zMy43ODVoLTIyLjM0NiIvPjxwYXRoIGQ9Im00OS44MTUgMTcwLjkzczguOTczOS0xNS41ODIgMTUuODI2LTIyLjQzNGM5LjM0NzQtOS4zNDc0IDIxLjk0LTE4LjMzMyAzNS4xNTktMTguMzQ2IDEzLjI3LTAuMDEzMSAyNS45NDYgOC45NjI4IDM1LjMyOSAxOC4zNDYgNi42MTk2IDYuNjE5NiAxNC40OTggMjIuNDM0IDE0LjQ5OCAyMi40MzQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Im0xNTAuNjMgMjE0LjMyaDI3LjkyMXYtODEuMzUyaC0zOC44NHYxNi4yMDgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz48L2c+PHBhdGggZD0ibTExOC4yMSAxMzQuMTF2LTEyLjU0M2gyMi40MTciIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS13aWR0aD0iNy41MTUiLz48cGF0aCBkPSJtMTc4LjQgMTMxLjQ3YzAtMTAuNjQzLTguNjI4Mi0xOS4yNzItMTkuMjcyLTE5LjI3MnMtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2Utd2lkdGg9IjkuNTA4Ii8+PHBhdGggZD0ibTE1Ni43NiAxMTYuODFjLTEuMDkxNS05LjQ3MTktOC42NDU0LTE2LjU0Ny0xOC40OC0xNi41NDctMTAuNjQzIDAtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuMjA4Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="106" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43OW1tIiBoZWlnaHQ9IjEyMy43OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzkgMTIzLjc5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS4zNTggLTkxLjgyNikiPjxnPjxyZWN0IHg9IjE1OC43OCIgeT0iOTEuODI2IiB3aWR0aD0iMTMuMjYyIiBoZWlnaHQ9Ijg2LjE3Ii8+PHJlY3QgeD0iMTM4LjA4IiB5PSI5MS44MjYiIHdpZHRoPSIxMy4yNjIiIGhlaWdodD0iODYuMTciLz48cmVjdCB4PSIxMTMuMTIiIHk9IjkxLjgyNiIgd2lkdGg9IjEzLjI2MiIgaGVpZ2h0PSI4Ni4xNyIvPjxwYXRoIGQ9Im00NS44ODggMTc1LjcxLTAuNTI5MTcgMC41MjkxNnYzOS4zNzRoMTM3Ljc5di0zOS45MDR6bTQuNjUxOSA1LjI1MDhoMjIuNzI5djYuODk3OGgtMjIuNzI5em0yNy45NzkgMGgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bTI3LjkzMiAwaDE5LjExOXY2Ljg5NzhoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3OGgtMjIuNzI5em0tNzYuNzE2IDExLjI1MmgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bS01Mi4zNDcgMC4zNjc5M2gyMi43Mjl2Ni44OTczaC0yMi43Mjl6bTgwLjI3OSAwaDE5LjExOXY2Ljg5NzNoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3M2gtMjIuNzI5eiIvPjxwYXRoIGQ9Im03MC40MTEgMTUxLjE4LTEyLjkxNCAxMi45MTQtMTIuMTM4IDEyLjEzOWgyNS4wNTN6Ii8+PHBhdGggZD0ibTk0LjkzNSAxNTEuMTgtMTIuOTE0IDEyLjkxNC0xMi4xMzggMTIuMTM5aDI1LjA1M3oiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="107" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzOS43N21tIiBoZWlnaHQ9IjEyNS42NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzkuNzcgMTI1LjY1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41ODcgLTgyLjMxMykiPjxnPjxjaXJjbGUgY3g9IjkzLjM3MiIgY3k9IjE5NS4wOCIgcj0iMTIuODgzIi8+PGNpcmNsZSBjeD0iMTM0Ljg2IiBjeT0iMTk1LjA4IiByPSIxMi44ODMiLz48cGF0aCBkPSJtNDEuNTg3IDEyMy44NWgxMzkuNzdsLTI2LjMzOSA1Ny43OTZoLTg3LjA3NHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOS41MDgiLz48Y2lyY2xlIGN4PSI4MS4wMzYiIGN5PSIxMjAuNTYiIHI9IjIwLjU2OCIvPjxjaXJjbGUgY3g9IjE0Mi41NSIgY3k9IjEyMC41NiIgcj0iMjAuNTY4Ii8+PHBhdGggZD0ibTExMS40NyA4Mi4zMTNhMjAuNTY4IDIwLjU2OCAwIDAgMC0yMC41NjggMjAuNTY4aDQxLjEzN2EyMC41NjggMjAuNTY4IDAgMCAwLTIwLjU2OC0yMC41Njh6Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="108" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="109" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5OS42NW1tIiBoZWlnaHQ9IjEzMS4yN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTkuNjUgMTMxLjI3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02LjY4NDcgLTk0LjExNykiPjxyZWN0IHg9IjE4NS4xNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjEuMTc2IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjEwMi4yNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjIuNTU3IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjExNC4zIiB5PSIyMTEuNDQiIHdpZHRoPSI3Ny4zMjUiIGhlaWdodD0iOS42MjExIi8+PHJlY3QgeD0iMTM4LjU5IiB5PSIxOTUuNjYiIHdpZHRoPSIzMS44ODMiIGhlaWdodD0iMTcuODMyIi8+PHJlY3QgeD0iMTEzLjMxIiB5PSIxNDguNTYiIHdpZHRoPSI5My4wMjEiIGhlaWdodD0iNTEuNjA3Ii8+PHJlY3QgeD0iMTY5LjQ2IiB5PSIxMzkuODQiIHdpZHRoPSIzNi44NzQiIGhlaWdodD0iMTcuNDQyIi8+PHBhdGggZD0ibTExOC4zMyAxMzAuODN2MjQuNTM3aDI0Ljk2MXYtMjQuNTM3em02LjI3MiA2LjI3ODJoOC43OTMzdjExLjQ0OWgtOC43OTMzeiIvPjxwYXRoIGQ9Im0xMjAuMyAxNDQuNzhoLTEwLjg0NmwtMTMuNjAxLTE2LjE5MyAyLjIyODktMy40NDg3aDEwLjAyOGwzLjgwOTctMy42NDM5LTAuMjIyMDctMi40ODQ2IDcuMDQ0Ni01LjcxMTggMi4xMDcyIDIuMzEzMyAyLjIxMjktMC43NTE1OHYtOC4xMTJsLTIuMTM0OC0xLjkzODQtMy4xMTA4IDAuMzI4NDV2LTQuNDQ0M2wtMi4xODc1LTMuMjE3NmgtNi4yNTE1bC0yMi4zNDYgMjQuMzczaC04LjQ2ODJsLTI3LjczNS0yNy43MjloLTkuNDhsLTQuMzY1NCA1Ljg1ODkgMjkuMTA5IDI5LjY1N2g1LjI3MThsMi4xOTYyIDIuMTYydjIuOTcwNGwtMi40MTU1IDIuMTI3OWgtOS4zMzc2bC0yMS4zOTggMjEuMjEyaC0xOS45MzRsLTEzLjc5MSAyMi41Nzl2My45MjA4aDMyLjU3OHYtNC43MTQxaDcuMTM2MnYtMTcuNDgzbDI3LjY0NC0yMC40MjdoMTIuOTAybDI5LjIxNiAyNC4xNDl6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzOS43N21tIiBoZWlnaHQ9IjEyNS42NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzkuNzcgMTI1LjY1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41ODcgLTgyLjMxMykiPjxnPjxjaXJjbGUgY3g9IjkzLjM3MiIgY3k9IjE5NS4wOCIgcj0iMTIuODgzIi8+PGNpcmNsZSBjeD0iMTM0Ljg2IiBjeT0iMTk1LjA4IiByPSIxMi44ODMiLz48cGF0aCBkPSJtNDEuNTg3IDEyMy44NWgxMzkuNzdsLTI2LjMzOSA1Ny43OTZoLTg3LjA3NHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOS41MDgiLz48Y2lyY2xlIGN4PSI4MS4wMzYiIGN5PSIxMjAuNTYiIHI9IjIwLjU2OCIvPjxjaXJjbGUgY3g9IjE0Mi41NSIgY3k9IjEyMC41NiIgcj0iMjAuNTY4Ii8+PHBhdGggZD0ibTExMS40NyA4Mi4zMTNhMjAuNTY4IDIwLjU2OCAwIDAgMC0yMC41NjggMjAuNTY4aDQxLjEzN2EyMC41NjggMjAuNTY4IDAgMCAwLTIwLjU2OC0yMC41Njh6Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="110" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5NC41NW1tIiBoZWlnaHQ9IjE5MS4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTQuNTUgMTkxLjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjk2MTggLTUzLjM3MikiPjxnPjxyZWN0IHg9IjMuOTYxOCIgeT0iMjE2Ljk4IiB3aWR0aD0iMTk0LjU1IiBoZWlnaHQ9IjI3LjcxOCIvPjxyZWN0IHg9IjEzNi4wNSIgeT0iOTAuNDc1IiB3aWR0aD0iNDEuOTcyIiBoZWlnaHQ9IjEzNS43NiIgcnk9IjQuODQwOCIvPjxyZWN0IHg9IjcxLjcxMiIgeT0iOTAuNDc1IiB3aWR0aD0iNDYuNjY5IiBoZWlnaHQ9IjEzNy45MiIgcnk9IjcuNzI5MSIvPjxyZWN0IHg9IjIzLjI4MiIgeT0iOTAuNDc1IiB3aWR0aD0iMjIuODIyIiBoZWlnaHQ9IjEzNS40NCIgcnk9IjUuMTgyOSIvPjwvZz48cGF0aCBkPSJtMTU4LjAyIDk0LjgxNWMxLjRlLTQgLTE3LjI2LTEzLjc5Ni0zMS4yNTMtMzAuODE1LTMxLjI1My0xNy4wMTktMS40MmUtNCAtMzAuODE1IDEzLjk5Mi0zMC44MTUgMzEuMjUzIDAuMDAyNCAwLjcwNzYyIDAuMDI4NDQgMS40MTUgMC4wNzgxNiAyLjEyMDgiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMy4yIiBzdHJva2Utd2lkdGg9IjIwLjM4MSIvPjxwYXRoIGQ9Im05Ni45MzggOTQuNzc2YzEuNGUtNCAtMTcuMjE0LTEzLjk1NS0zMS4xNjktMzEuMTY5LTMxLjE2OS0xNy4yMTQtMS40MWUtNCAtMzEuMTY5IDEzLjk1NS0zMS4xNjkgMzEuMTY5IDAuMDAyNCAwLjcwNTczIDAuMDI4NzcgMS40MTEyIDAuMDc5MDYgMi4xMTUxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuMiIgc3Ryb2tlLXdpZHRoPSIyMC40NyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.28779" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="111" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4MC42OG1tIiBoZWlnaHQ9IjE4Ni40N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODAuNjggMTg2LjQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05Ljg2NjQgLTU1LjgzNikiPjxyZWN0IHg9IjE4LjUzNyIgeT0iMTc1LjExIiB3aWR0aD0iMTM2LjY0IiBoZWlnaHQ9IjY3LjE5MyIgcnk9IjAiLz48cmVjdCB4PSIxNjQuMzUiIHk9IjEyOS4yNCIgd2lkdGg9IjI2LjE4OSIgaGVpZ2h0PSIxMTMuMDYiIHJ5PSIwIi8+PGNpcmNsZSBjeD0iMTcyLjYzIiBjeT0iMTA2LjMzIiByPSIxMi44MDEiLz48Y2lyY2xlIGN4PSIxNjUuNzIiIGN5PSI5Ny4zMzMiIHI9IjEyLjgwMSIvPjxjaXJjbGUgY3g9IjE0OC42NyIgY3k9IjEwNy4xMyIgcj0iOS4xMzM1Ii8+PGNpcmNsZSBjeD0iMTM3LjMzIiBjeT0iMTA0LjY4IiByPSI5LjEzMzUiLz48Y2lyY2xlIGN4PSIxNDkuNjYiIGN5PSI4NC4wODEiIHI9IjE0LjYxNyIvPjxjaXJjbGUgY3g9IjExNC42MSIgY3k9IjEwMi42MiIgcj0iMTMuMzc4Ii8+PGNpcmNsZSBjeD0iMTI5LjQiIGN5PSI4MC43OTciIHI9IjguODg1NSIvPjxjaXJjbGUgY3g9IjExOC4zNiIgY3k9IjY3LjQ5NCIgcj0iMTEuNjU4Ii8+PGNpcmNsZSBjeD0iOTcuODAxIiBjeT0iODYuNTA0IiByPSIxMy4wMDUiLz48Y2lyY2xlIGN4PSI5Mi44MDIiIGN5PSI4MC45NzEiIHI9IjEzLjAwNSIvPjxjaXJjbGUgY3g9IjkzLjY5OSIgY3k9IjYzLjc4NSIgcj0iNy4yNjI0Ii8+PGNpcmNsZSBjeD0iMTAwLjU5IiBjeT0iNjcuNjY2IiByPSI3LjI2MjQiLz48Y2lyY2xlIGN4PSIxMjguOTYiIGN5PSI5OS45NDYiIHI9IjcuMjYyNCIvPjxyZWN0IHg9IjEwMC43NCIgeT0iNjguNDg3IiB3aWR0aD0iMjEuNjAxIiBoZWlnaHQ9IjI0LjYzNCIvPjxyZWN0IHg9IjExOS45MyIgeT0iODMuMTkiIHdpZHRoPSIzNC41OSIgaGVpZ2h0PSIxNy4yNTUiLz48Y2lyY2xlIGN4PSI2MC40MjQiIGN5PSI4Mi44MTkiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjU3LjExMyIgY3k9Ijk3Ljc2MyIgcj0iMTUuMjE3Ii8+PGNpcmNsZSBjeD0iMzcuODI2IiBjeT0iMTAxLjc2IiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSIyNS4wODMiIGN5PSI4MC44MDgiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjMyLjU4OCIgY3k9Ijk0LjcyIiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSI0Mi45NjciIGN5PSI4OS40MjMiIHI9IjE1LjIxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="112" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3OC4xM21tIiBoZWlnaHQ9IjExNy45NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzguMTMgMTE3Ljk0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTIzLjg2NSkiPjxwYXRoIGQ9Im0yMy43NzEgMjMuODY1djYyLjQ3M2gtMC4wMDIxYzEuMDllLTQgMC4wMjc2MSAwLjAwMjEgMC4wNTQ4MSAwLjAwMjEgMC4wODI1djIzLjI1MWMwIDEyLjE2LTEwLjU5IDIxLjk1Ny0yMy43NzEgMjIuMDI2djEwLjEwNGg5NS42OTl2LTEwLjEwNGMtMTMuMTgyLTAuMDY5MS0yMy43NzEtOS44NjYtMjMuNzcxLTIyLjAyNnYtMjMuMjUxYzAtMC4wMjc3IDJlLTMgLTAuMDU0ODkgMC4wMDIxLTAuMDgyNWgtMC4wMDIxdi02Mi40NzN6Ii8+PHBhdGggZD0ibTEyMS43NCA0OS4wM3Y0OS4xNDNoLTJlLTNjOGUtNSAwLjAyMTcgMmUtMyAwLjA0MzA2IDJlLTMgMC4wNjQ5MnYxOC4yODljMCA5LjU2NTctOC4zMDI3IDE3LjI3Mi0xOC42MzggMTcuMzI3djcuOTQ4NGg3NS4wMzJ2LTcuOTQ4NGMtMTAuMzM1LTAuMDU0My0xOC42MzgtNy43NjA5LTE4LjYzOC0xNy4zMjd2LTE4LjI4OWMwLTAuMDIxNzggMmUtMyAtMC4wNDMxNCAyZS0zIC0wLjA2NDkyaC0yZS0zdi00OS4xNDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0.40000000000000002" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="113" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS4zbW0iIGhlaWdodD0iMTM5Ljk0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OS4zIDEzOS45NCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzIuMjYzIC03Ni44ODQpIj48Y2lyY2xlIGN4PSI3OS40OTEiIGN5PSIxOTUuOTgiIHI9IjE2Ljg1IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48Y2lyY2xlIGN4PSIxNTQuOCIgY3k9IjE5NS45OCIgcj0iMTYuODUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3Ljk4MTUiLz48Zz48cmVjdCB4PSIxMDMuMzUiIHk9IjE4Mi42MiIgd2lkdGg9IjI1LjU0OSIgaGVpZ2h0PSIxNi4yMjIiLz48cGF0aCBkPSJtMzIuMjYzIDE0OS4wOHY0Mi43OThoMjEuOTlhMjQuODI3IDI0LjgyNyAwIDAgMSAyMC4wMzMtMjAuNTk2di0yMi4yMDN6bTQuNzY1MSA1LjAwMjhoMTcuNjI3djIwLjEzM2gtMTcuNjI3eiIvPjxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDQwLjE1MykiIGQ9Im0xNDUuMDcgNi43OTExLTMuOWUtNCA0MS4yOSA2NS4wMzktMi42ZS01IDI5LjM2Ny0yNC43NzYgMi45ZS00IC0xNi41MTR6Ii8+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoMzkuODQ5KSIgZD0ibTE3MS4wMSA0My41NTUtMi45ZS00IDUuNDU3MSA0LjQyMDMgMmUtNSAyZS01IDI1LjQ5IDExLjgwNS0yLjI1ZS00IDIuM2UtNCAtMjUuNDI4IDUuMTA3OCAzLjU4ZS00IDVlLTUgLTUuNTE5NXoiLz48cGF0aCBkPSJtMTcxLjEgMTUzLjIzLTEyLjk1MiAxOC45OTloOS44NjI0bDguNTU0NSAxMC45OTIgNS4wMDE4IDAuMzM2OTN2LTE5Ljc5NWwtMi45MDczLTQuMTU2M3oiLz48cGF0aCBkPSJtMTEzLjAyIDEwNC4yNC02LjUyMjctNS41MDI5LTIzLjEzMi0xOS45MDUtOC41MjY2LTEuOTQ2NiAwLjA1MzA4OSA4LjIyMDcgMjUuNjIxIDIwLjcyNSA0LjQ4MzUgNS4xNzQyeiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="114" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzMi4xNm1tIiBoZWlnaHQ9IjEyMy44Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzIuMTYgMTIzLjg2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4yMTkgLTkxLjcyMSkiPjxnPjxyZWN0IHg9IjE2MS45NyIgeT0iOTEuNzIxIiB3aWR0aD0iMTYuNDEiIGhlaWdodD0iMTIzLjg2Ii8+PHJlY3QgeD0iNDYuMjIiIHk9IjE2OC4yNSIgd2lkdGg9IjEzMi4xNiIgaGVpZ2h0PSI0Ny4zMjgiLz48cmVjdCB4PSIxNDAuMDQiIHk9IjkxLjcyMSIgd2lkdGg9IjE2LjQxIiBoZWlnaHQ9IjEyMy44NiIvPjxwYXRoIGQ9Im03NS42NDkgMTM4LjczLTI5LjQyOSAyOS40Mjl2MTMuOTU5aDI5LjQyOXoiLz48cGF0aCBkPSJtMTA1LjA4IDEzOC43My0yOS40MjkgMjkuNDI5djEzLjk1OWgyOS40Mjl6Ii8+PHBhdGggZD0ibTEzNC41MSAxMzguNzMtMjkuNDI5IDI5LjQyOXYxMy45NTloMjkuNDI5eiIvPjxyZWN0IHg9IjQ2LjIxOSIgeT0iMTY4LjI1IiB3aWR0aD0iMTMyLjE2IiBoZWlnaHQ9IjEzLjc2OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="115" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNi4zM21tIiBoZWlnaHQ9IjEzOC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTYuMzMgMTM4LjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NS4wNSAtODEuMjY0KSI+PGc+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iMTQ4LjM2IiB5PSIxMjYuNDUiIHdpZHRoPSIyMy4wMTUiIGhlaWdodD0iOTMuMDgxIiBzdHJva2Utd2lkdGg9IjcuNTQ3NCIvPjxyZWN0IHg9IjU1LjA1IiB5PSIxODUuNDkiIHdpZHRoPSIxMTYuMzMiIGhlaWdodD0iMzQuMDQxIiBzdHJva2Utd2lkdGg9IjcuOTgyIi8+PHBhdGggZD0ibTEwMC42NCAxNDguMjcgMWUtNSAxMy40NzUgNjIuNzI5IDIyLjIyMiA0LjI0MTYtMTEuOTcyeiIgc3Ryb2tlLXdpZHRoPSI3Ljk4MiIvPjxwYXRoIGQ9Im01NS4wNSAxNTEuMzQtNGUtNiAxNS4zNTYgNzguMjY1IDI4LjIyNiAxMC42ODQtMTEuNTAzeiIgc3Ryb2tlLXdpZHRoPSIxMi43OTkiLz48cmVjdCB4PSIxMzguNDIiIHk9IjE4Mi43MSIgd2lkdGg9IjEzLjY5MyIgaGVpZ2h0PSI0LjE5NzMiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48cGF0aCBkPSJtNTUuMDUgMTcxLjM0IDVlLTYgMjEuMjkxIDMzLjk2IDEyLjQ5MSA2Ljg5NzItMTguNzUzeiIgc3Ryb2tlLXdpZHRoPSI4Ljk0NjciLz48L2c+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMS42NjM1IDAgMCAxLjY2MzUgMTUyLjI1IC02MC45MjIpIj48Y2lyY2xlIGN4PSIxLjk1MzMiIGN5PSIxMDIuNDUiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9IjMuNzgxNCIgY3k9IjEwOC41MiIgcj0iMi45MDY3Ii8+PGNpcmNsZSBjeD0iMS45OTk4IiBjeT0iMTA1Ljg4IiByPSIyLjkwNjciLz48Y2lyY2xlIGN4PSIxLjE4NDMiIGN5PSIxMDcuMDEiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9Ii01LjAwNTkiIGN5PSI5NS41NzYiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii00LjQyOTgiIGN5PSIxMDAuOTkiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii0zMS42NDYiIGN5PSI5NC4yMzIiIHI9IjYuODcxOCIvPjxjaXJjbGUgY3g9Ii0zMy45MzYiIGN5PSIxMDYuNDIiIHI9IjQuNjYzNiIvPjxjaXJjbGUgY3g9Ii0zMC4xNzgiIGN5PSIxMDYuMjMiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii0zNi45NDciIGN5PSIxMDQuNTIiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii00Ny44OCIgY3k9IjEwNS4zMSIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUwLjgyOSIgY3k9IjEwNC4zNyIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUxLjI1MSIgY3k9IjEwMC43NiIgcj0iNS41NDA4Ii8+PGNpcmNsZSBjeD0iLTUyLjQ0OCIgY3k9IjkzLjAxNiIgcj0iMS41NTQ2Ii8+PGNpcmNsZSBjeD0iLTQ5LjU5OSIgY3k9IjkyLjA0MSIgcj0iMS45NjkxIi8+PGVsbGlwc2UgY3g9Ii00NS43OTEiIGN5PSI5My4xMjIiIHJ4PSIzLjczNTYiIHJ5PSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItNDIuMzk2IiBjeT0iOTMuOTY3IiByPSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItMzguNzMiIGN5PSI5My42NjUiIHI9IjEuOTY5MSIvPjxjaXJjbGUgY3g9Ii0xMS43NTYiIGN5PSIxMDYuNTkiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xNC43MDUiIGN5PSIxMDUuNDYiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xOS45NTIiIGN5PSIxMDEuMTgiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0yNi44MjIiIGN5PSIxMDEuNSIgcj0iNC42MjMyIi8+PGNpcmNsZSBjeD0iLTEyLjA1IiBjeT0iODcuNzMxIiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNS45NzU4IiBjeT0iOTAuMTQ5IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNi45NjI4IiBjeT0iODguNzI1IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItMTQuODc0IiBjeT0iOTEuMjM3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMTcuMDY1IiBjeT0iOTMuNzc2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItNDMuNTQ0IiBjeT0iMTAzLjE3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjAuOTc4IiBjeT0iOTcuNTI1IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjUuNzQ3IiBjeT0iOTYuMTk2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItOS42MzA0IiBjeT0iODkuMzU2IiByPSIyLjIyMTQiLz48Y2lyY2xlIGN4PSItNTEuMTc1IiBjeT0iOTYuMzEyIiByPSIyLjIyMTQiLz48ZWxsaXBzZSBjeD0iMy42MzY2IiBjeT0iMTEyLjkzIiByeD0iMy4yOTc3IiByeT0iNy4yNjQ5Ii8+PHBhdGggZD0ibS0wLjI0ODI4IDEwNy4wOGMtMS41NWUtNiAyLjU1MzMtMS44MzE4IDAuMjMyMTUtNC4zODUyIDAuMjMyMTVzLTQuODYxMyAyLjMyMTItNC44NjEzLTAuMjMyMTVjLTRlLTYgLTIuNTUzMyAyLjA2OTktNC42MjMyIDQuNjIzMi00LjYyMzIgMi41NTMzIDAgNC42MjMyIDIuMDY5OSA0LjYyMzIgNC42MjMyeiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjQyMzUiLz48cGF0aCBkPSJtLTUwLjQ2IDkyLjcxLTEuNDQyNCAwLjQ0OTcyLTAuMDYxNzggMi42MjM0czAuOTA3NzMgMi44MzE2IDEuMDQyNSAzLjA2MDdjMC4xMzQ3NiAwLjIyOTEgMi42MDk0IDMuNDY4IDIuNjA5NCAzLjQ2OGw1LjIzODEgMC40OTM1NyAzLjcyMDMgMS4yNTE0IDMuNzY4IDAuMjE4NzFzNC44MTEyIDEuMjc1MSA1LjIzNzMgMC44MjI0N2MwLjQyNjA2LTAuNDUyNjYgMS40NDg4LTUuMDU0MiAxLjQxMzYtNS4zNTQ1LTAuMDM1MTYtMC4zMDAzNC0zLjM5NTctMS43NzQ1LTMuMzk1Ny0xLjc3NDVsLTMuODQwNS0yLjU0NzItMS42MjUtMS4yMTM0LTIuOTQ0Ni0wLjEwMDkycy0yLjc2MjctMC4zNTA3MS0zLjAzMTQtMC41MTY0NWMtMC4yNjg3Mi0wLjE2NTc1LTMuMTkxNC0wLjc2NTgtMy4zNDczLTAuNzY1OC0wLjE1NTg4IDAtMy4zNDA1LTAuMTE1My0zLjM0MDUtMC4xMTUzeiIvPjxwYXRoIGQ9Im0tMjAuMTk2IDk2LjUwNyAyLjkwNTQgNy4xMTYxIDQuOTYzNiAyLjIxMzUgNy4yMjgyLTAuMzU5MDkgNS4zOTc1IDAuNDAyODVzMS4xNDY1LTIuNDc2MyAxLjE2NjYtMi42Mzg1YzAuMDIwMTA4LTAuMTYyMjMtMi4yNDgzLTEuODA5OC0yLjI0ODMtMS44MDk4bC0xLjQ3OTgtMi4xNjU2LTAuMjEyNTItMi43NjQ5cy0xLjUxOTQtMi4zOTMzLTEuNTIyOC0yLjU1NTVjLTAuMDAzMzMtMC4xNjIxNy0yLjYyMjktNC4yNzMyLTIuNjIyOS00LjI3MzJsLTUuMjE1OS0wLjA2MjAzLTUuMTcyNCAzLjUyOTV6Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.54348" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="116" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0NC43OG1tIiBoZWlnaHQ9Ijk1LjM2M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDQuNzggOTUuMzYzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNi43MjcgLTEwNi4yNykiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE3MS40NyAxMDYuMjd2OTUuMzYzIiBzdHJva2Utd2lkdGg9IjIwLjA3OSIvPjxwYXRoIGQ9Im0xNzEuNDcgMTk1LjQ5aC0xMjguNjF2LTQzLjcxNGwyMy4xNDQtMTQuMTQ5IDEwLjU5MiAxOS4yMjQgMjguNjg0LTE5LjcyNyAxMi42MTEgMjAuNTczIDMwLjU5OS0yMi41MSAxOC42ODggMzEuNTQiIHN0cm9rZS13aWR0aD0iMTIuMjY5Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="117" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43NG1tIiBoZWlnaHQ9IjEyMy4wN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzQgMTIzLjA3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40MDkgLTk1LjY1NCkiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGcgc3Ryb2tlLXdpZHRoPSI4LjgxMiI+PHBhdGggZD0ibTQ5LjgxNSAxNzAuOTN2NDMuMzg2aDI4LjYzOXYtMzMuNzg1aDIyLjM0NiIvPjxwYXRoIGQ9Im0xNTAuNjMgMTcwLjkzdjQzLjM4NmgtMjguNjM5di0zMy43ODVoLTIyLjM0NiIvPjxwYXRoIGQ9Im00OS44MTUgMTcwLjkzczguOTczOS0xNS41ODIgMTUuODI2LTIyLjQzNGM5LjM0NzQtOS4zNDc0IDIxLjk0LTE4LjMzMyAzNS4xNTktMTguMzQ2IDEzLjI3LTAuMDEzMSAyNS45NDYgOC45NjI4IDM1LjMyOSAxOC4zNDYgNi42MTk2IDYuNjE5NiAxNC40OTggMjIuNDM0IDE0LjQ5OCAyMi40MzQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Im0xNTAuNjMgMjE0LjMyaDI3LjkyMXYtODEuMzUyaC0zOC44NHYxNi4yMDgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz48L2c+PHBhdGggZD0ibTExOC4yMSAxMzQuMTF2LTEyLjU0M2gyMi40MTciIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS13aWR0aD0iNy41MTUiLz48cGF0aCBkPSJtMTc4LjQgMTMxLjQ3YzAtMTAuNjQzLTguNjI4Mi0xOS4yNzItMTkuMjcyLTE5LjI3MnMtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2Utd2lkdGg9IjkuNTA4Ii8+PHBhdGggZD0ibTE1Ni43NiAxMTYuODFjLTEuMDkxNS05LjQ3MTktOC42NDU0LTE2LjU0Ny0xOC40OC0xNi41NDctMTAuNjQzIDAtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuMjA4Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="118" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43OW1tIiBoZWlnaHQ9IjEyMy43OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzkgMTIzLjc5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS4zNTggLTkxLjgyNikiPjxnPjxyZWN0IHg9IjE1OC43OCIgeT0iOTEuODI2IiB3aWR0aD0iMTMuMjYyIiBoZWlnaHQ9Ijg2LjE3Ii8+PHJlY3QgeD0iMTM4LjA4IiB5PSI5MS44MjYiIHdpZHRoPSIxMy4yNjIiIGhlaWdodD0iODYuMTciLz48cmVjdCB4PSIxMTMuMTIiIHk9IjkxLjgyNiIgd2lkdGg9IjEzLjI2MiIgaGVpZ2h0PSI4Ni4xNyIvPjxwYXRoIGQ9Im00NS44ODggMTc1LjcxLTAuNTI5MTcgMC41MjkxNnYzOS4zNzRoMTM3Ljc5di0zOS45MDR6bTQuNjUxOSA1LjI1MDhoMjIuNzI5djYuODk3OGgtMjIuNzI5em0yNy45NzkgMGgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bTI3LjkzMiAwaDE5LjExOXY2Ljg5NzhoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3OGgtMjIuNzI5em0tNzYuNzE2IDExLjI1MmgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bS01Mi4zNDcgMC4zNjc5M2gyMi43Mjl2Ni44OTczaC0yMi43Mjl6bTgwLjI3OSAwaDE5LjExOXY2Ljg5NzNoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3M2gtMjIuNzI5eiIvPjxwYXRoIGQ9Im03MC40MTEgMTUxLjE4LTEyLjkxNCAxMi45MTQtMTIuMTM4IDEyLjEzOWgyNS4wNTN6Ii8+PHBhdGggZD0ibTk0LjkzNSAxNTEuMTgtMTIuOTE0IDEyLjkxNC0xMi4xMzggMTIuMTM5aDI1LjA1M3oiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="119" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzOS43N21tIiBoZWlnaHQ9IjEyNS42NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzkuNzcgMTI1LjY1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41ODcgLTgyLjMxMykiPjxnPjxjaXJjbGUgY3g9IjkzLjM3MiIgY3k9IjE5NS4wOCIgcj0iMTIuODgzIi8+PGNpcmNsZSBjeD0iMTM0Ljg2IiBjeT0iMTk1LjA4IiByPSIxMi44ODMiLz48cGF0aCBkPSJtNDEuNTg3IDEyMy44NWgxMzkuNzdsLTI2LjMzOSA1Ny43OTZoLTg3LjA3NHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOS41MDgiLz48Y2lyY2xlIGN4PSI4MS4wMzYiIGN5PSIxMjAuNTYiIHI9IjIwLjU2OCIvPjxjaXJjbGUgY3g9IjE0Mi41NSIgY3k9IjEyMC41NiIgcj0iMjAuNTY4Ii8+PHBhdGggZD0ibTExMS40NyA4Mi4zMTNhMjAuNTY4IDIwLjU2OCAwIDAgMC0yMC41NjggMjAuNTY4aDQxLjEzN2EyMC41NjggMjAuNTY4IDAgMCAwLTIwLjU2OC0yMC41Njh6Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="120" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="121" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5OS42NW1tIiBoZWlnaHQ9IjEzMS4yN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTkuNjUgMTMxLjI3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02LjY4NDcgLTk0LjExNykiPjxyZWN0IHg9IjE4NS4xNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjEuMTc2IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjEwMi4yNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjIuNTU3IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjExNC4zIiB5PSIyMTEuNDQiIHdpZHRoPSI3Ny4zMjUiIGhlaWdodD0iOS42MjExIi8+PHJlY3QgeD0iMTM4LjU5IiB5PSIxOTUuNjYiIHdpZHRoPSIzMS44ODMiIGhlaWdodD0iMTcuODMyIi8+PHJlY3QgeD0iMTEzLjMxIiB5PSIxNDguNTYiIHdpZHRoPSI5My4wMjEiIGhlaWdodD0iNTEuNjA3Ii8+PHJlY3QgeD0iMTY5LjQ2IiB5PSIxMzkuODQiIHdpZHRoPSIzNi44NzQiIGhlaWdodD0iMTcuNDQyIi8+PHBhdGggZD0ibTExOC4zMyAxMzAuODN2MjQuNTM3aDI0Ljk2MXYtMjQuNTM3em02LjI3MiA2LjI3ODJoOC43OTMzdjExLjQ0OWgtOC43OTMzeiIvPjxwYXRoIGQ9Im0xMjAuMyAxNDQuNzhoLTEwLjg0NmwtMTMuNjAxLTE2LjE5MyAyLjIyODktMy40NDg3aDEwLjAyOGwzLjgwOTctMy42NDM5LTAuMjIyMDctMi40ODQ2IDcuMDQ0Ni01LjcxMTggMi4xMDcyIDIuMzEzMyAyLjIxMjktMC43NTE1OHYtOC4xMTJsLTIuMTM0OC0xLjkzODQtMy4xMTA4IDAuMzI4NDV2LTQuNDQ0M2wtMi4xODc1LTMuMjE3NmgtNi4yNTE1bC0yMi4zNDYgMjQuMzczaC04LjQ2ODJsLTI3LjczNS0yNy43MjloLTkuNDhsLTQuMzY1NCA1Ljg1ODkgMjkuMTA5IDI5LjY1N2g1LjI3MThsMi4xOTYyIDIuMTYydjIuOTcwNGwtMi40MTU1IDIuMTI3OWgtOS4zMzc2bC0yMS4zOTggMjEuMjEyaC0xOS45MzRsLTEzLjc5MSAyMi41Nzl2My45MjA4aDMyLjU3OHYtNC43MTQxaDcuMTM2MnYtMTcuNDgzbDI3LjY0NC0yMC40MjdoMTIuOTAybDI5LjIxNiAyNC4xNDl6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="122" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5NC41NW1tIiBoZWlnaHQ9IjE5MS4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTQuNTUgMTkxLjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjk2MTggLTUzLjM3MikiPjxnPjxyZWN0IHg9IjMuOTYxOCIgeT0iMjE2Ljk4IiB3aWR0aD0iMTk0LjU1IiBoZWlnaHQ9IjI3LjcxOCIvPjxyZWN0IHg9IjEzNi4wNSIgeT0iOTAuNDc1IiB3aWR0aD0iNDEuOTcyIiBoZWlnaHQ9IjEzNS43NiIgcnk9IjQuODQwOCIvPjxyZWN0IHg9IjcxLjcxMiIgeT0iOTAuNDc1IiB3aWR0aD0iNDYuNjY5IiBoZWlnaHQ9IjEzNy45MiIgcnk9IjcuNzI5MSIvPjxyZWN0IHg9IjIzLjI4MiIgeT0iOTAuNDc1IiB3aWR0aD0iMjIuODIyIiBoZWlnaHQ9IjEzNS40NCIgcnk9IjUuMTgyOSIvPjwvZz48cGF0aCBkPSJtMTU4LjAyIDk0LjgxNWMxLjRlLTQgLTE3LjI2LTEzLjc5Ni0zMS4yNTMtMzAuODE1LTMxLjI1My0xNy4wMTktMS40MmUtNCAtMzAuODE1IDEzLjk5Mi0zMC44MTUgMzEuMjUzIDAuMDAyNCAwLjcwNzYyIDAuMDI4NDQgMS40MTUgMC4wNzgxNiAyLjEyMDgiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMy4yIiBzdHJva2Utd2lkdGg9IjIwLjM4MSIvPjxwYXRoIGQ9Im05Ni45MzggOTQuNzc2YzEuNGUtNCAtMTcuMjE0LTEzLjk1NS0zMS4xNjktMzEuMTY5LTMxLjE2OS0xNy4yMTQtMS40MWUtNCAtMzEuMTY5IDEzLjk1NS0zMS4xNjkgMzEuMTY5IDAuMDAyNCAwLjcwNTczIDAuMDI4NzcgMS40MTEyIDAuMDc5MDYgMi4xMTUxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuMiIgc3Ryb2tlLXdpZHRoPSIyMC40NyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.28779" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="123" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4MC42OG1tIiBoZWlnaHQ9IjE4Ni40N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODAuNjggMTg2LjQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05Ljg2NjQgLTU1LjgzNikiPjxyZWN0IHg9IjE4LjUzNyIgeT0iMTc1LjExIiB3aWR0aD0iMTM2LjY0IiBoZWlnaHQ9IjY3LjE5MyIgcnk9IjAiLz48cmVjdCB4PSIxNjQuMzUiIHk9IjEyOS4yNCIgd2lkdGg9IjI2LjE4OSIgaGVpZ2h0PSIxMTMuMDYiIHJ5PSIwIi8+PGNpcmNsZSBjeD0iMTcyLjYzIiBjeT0iMTA2LjMzIiByPSIxMi44MDEiLz48Y2lyY2xlIGN4PSIxNjUuNzIiIGN5PSI5Ny4zMzMiIHI9IjEyLjgwMSIvPjxjaXJjbGUgY3g9IjE0OC42NyIgY3k9IjEwNy4xMyIgcj0iOS4xMzM1Ii8+PGNpcmNsZSBjeD0iMTM3LjMzIiBjeT0iMTA0LjY4IiByPSI5LjEzMzUiLz48Y2lyY2xlIGN4PSIxNDkuNjYiIGN5PSI4NC4wODEiIHI9IjE0LjYxNyIvPjxjaXJjbGUgY3g9IjExNC42MSIgY3k9IjEwMi42MiIgcj0iMTMuMzc4Ii8+PGNpcmNsZSBjeD0iMTI5LjQiIGN5PSI4MC43OTciIHI9IjguODg1NSIvPjxjaXJjbGUgY3g9IjExOC4zNiIgY3k9IjY3LjQ5NCIgcj0iMTEuNjU4Ii8+PGNpcmNsZSBjeD0iOTcuODAxIiBjeT0iODYuNTA0IiByPSIxMy4wMDUiLz48Y2lyY2xlIGN4PSI5Mi44MDIiIGN5PSI4MC45NzEiIHI9IjEzLjAwNSIvPjxjaXJjbGUgY3g9IjkzLjY5OSIgY3k9IjYzLjc4NSIgcj0iNy4yNjI0Ii8+PGNpcmNsZSBjeD0iMTAwLjU5IiBjeT0iNjcuNjY2IiByPSI3LjI2MjQiLz48Y2lyY2xlIGN4PSIxMjguOTYiIGN5PSI5OS45NDYiIHI9IjcuMjYyNCIvPjxyZWN0IHg9IjEwMC43NCIgeT0iNjguNDg3IiB3aWR0aD0iMjEuNjAxIiBoZWlnaHQ9IjI0LjYzNCIvPjxyZWN0IHg9IjExOS45MyIgeT0iODMuMTkiIHdpZHRoPSIzNC41OSIgaGVpZ2h0PSIxNy4yNTUiLz48Y2lyY2xlIGN4PSI2MC40MjQiIGN5PSI4Mi44MTkiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjU3LjExMyIgY3k9Ijk3Ljc2MyIgcj0iMTUuMjE3Ii8+PGNpcmNsZSBjeD0iMzcuODI2IiBjeT0iMTAxLjc2IiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSIyNS4wODMiIGN5PSI4MC44MDgiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjMyLjU4OCIgY3k9Ijk0LjcyIiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSI0Mi45NjciIGN5PSI4OS40MjMiIHI9IjE1LjIxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="124" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3OC4xM21tIiBoZWlnaHQ9IjExNy45NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzguMTMgMTE3Ljk0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTIzLjg2NSkiPjxwYXRoIGQ9Im0yMy43NzEgMjMuODY1djYyLjQ3M2gtMC4wMDIxYzEuMDllLTQgMC4wMjc2MSAwLjAwMjEgMC4wNTQ4MSAwLjAwMjEgMC4wODI1djIzLjI1MWMwIDEyLjE2LTEwLjU5IDIxLjk1Ny0yMy43NzEgMjIuMDI2djEwLjEwNGg5NS42OTl2LTEwLjEwNGMtMTMuMTgyLTAuMDY5MS0yMy43NzEtOS44NjYtMjMuNzcxLTIyLjAyNnYtMjMuMjUxYzAtMC4wMjc3IDJlLTMgLTAuMDU0ODkgMC4wMDIxLTAuMDgyNWgtMC4wMDIxdi02Mi40NzN6Ii8+PHBhdGggZD0ibTEyMS43NCA0OS4wM3Y0OS4xNDNoLTJlLTNjOGUtNSAwLjAyMTcgMmUtMyAwLjA0MzA2IDJlLTMgMC4wNjQ5MnYxOC4yODljMCA5LjU2NTctOC4zMDI3IDE3LjI3Mi0xOC42MzggMTcuMzI3djcuOTQ4NGg3NS4wMzJ2LTcuOTQ4NGMtMTAuMzM1LTAuMDU0My0xOC42MzgtNy43NjA5LTE4LjYzOC0xNy4zMjd2LTE4LjI4OWMwLTAuMDIxNzggMmUtMyAtMC4wNDMxNCAyZS0zIC0wLjA2NDkyaC0yZS0zdi00OS4xNDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0.40000000000000002" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="125" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS4zbW0iIGhlaWdodD0iMTM5Ljk0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OS4zIDEzOS45NCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzIuMjYzIC03Ni44ODQpIj48Y2lyY2xlIGN4PSI3OS40OTEiIGN5PSIxOTUuOTgiIHI9IjE2Ljg1IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48Y2lyY2xlIGN4PSIxNTQuOCIgY3k9IjE5NS45OCIgcj0iMTYuODUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3Ljk4MTUiLz48Zz48cmVjdCB4PSIxMDMuMzUiIHk9IjE4Mi42MiIgd2lkdGg9IjI1LjU0OSIgaGVpZ2h0PSIxNi4yMjIiLz48cGF0aCBkPSJtMzIuMjYzIDE0OS4wOHY0Mi43OThoMjEuOTlhMjQuODI3IDI0LjgyNyAwIDAgMSAyMC4wMzMtMjAuNTk2di0yMi4yMDN6bTQuNzY1MSA1LjAwMjhoMTcuNjI3djIwLjEzM2gtMTcuNjI3eiIvPjxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDQwLjE1MykiIGQ9Im0xNDUuMDcgNi43OTExLTMuOWUtNCA0MS4yOSA2NS4wMzktMi42ZS01IDI5LjM2Ny0yNC43NzYgMi45ZS00IC0xNi41MTR6Ii8+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoMzkuODQ5KSIgZD0ibTE3MS4wMSA0My41NTUtMi45ZS00IDUuNDU3MSA0LjQyMDMgMmUtNSAyZS01IDI1LjQ5IDExLjgwNS0yLjI1ZS00IDIuM2UtNCAtMjUuNDI4IDUuMTA3OCAzLjU4ZS00IDVlLTUgLTUuNTE5NXoiLz48cGF0aCBkPSJtMTcxLjEgMTUzLjIzLTEyLjk1MiAxOC45OTloOS44NjI0bDguNTU0NSAxMC45OTIgNS4wMDE4IDAuMzM2OTN2LTE5Ljc5NWwtMi45MDczLTQuMTU2M3oiLz48cGF0aCBkPSJtMTEzLjAyIDEwNC4yNC02LjUyMjctNS41MDI5LTIzLjEzMi0xOS45MDUtOC41MjY2LTEuOTQ2NiAwLjA1MzA4OSA4LjIyMDcgMjUuNjIxIDIwLjcyNSA0LjQ4MzUgNS4xNzQyeiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="126" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzMi4xNm1tIiBoZWlnaHQ9IjEyMy44Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzIuMTYgMTIzLjg2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4yMTkgLTkxLjcyMSkiPjxnPjxyZWN0IHg9IjE2MS45NyIgeT0iOTEuNzIxIiB3aWR0aD0iMTYuNDEiIGhlaWdodD0iMTIzLjg2Ii8+PHJlY3QgeD0iNDYuMjIiIHk9IjE2OC4yNSIgd2lkdGg9IjEzMi4xNiIgaGVpZ2h0PSI0Ny4zMjgiLz48cmVjdCB4PSIxNDAuMDQiIHk9IjkxLjcyMSIgd2lkdGg9IjE2LjQxIiBoZWlnaHQ9IjEyMy44NiIvPjxwYXRoIGQ9Im03NS42NDkgMTM4LjczLTI5LjQyOSAyOS40Mjl2MTMuOTU5aDI5LjQyOXoiLz48cGF0aCBkPSJtMTA1LjA4IDEzOC43My0yOS40MjkgMjkuNDI5djEzLjk1OWgyOS40Mjl6Ii8+PHBhdGggZD0ibTEzNC41MSAxMzguNzMtMjkuNDI5IDI5LjQyOXYxMy45NTloMjkuNDI5eiIvPjxyZWN0IHg9IjQ2LjIxOSIgeT0iMTY4LjI1IiB3aWR0aD0iMTMyLjE2IiBoZWlnaHQ9IjEzLjc2OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="127" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNi4zM21tIiBoZWlnaHQ9IjEzOC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTYuMzMgMTM4LjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NS4wNSAtODEuMjY0KSI+PGc+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iMTQ4LjM2IiB5PSIxMjYuNDUiIHdpZHRoPSIyMy4wMTUiIGhlaWdodD0iOTMuMDgxIiBzdHJva2Utd2lkdGg9IjcuNTQ3NCIvPjxyZWN0IHg9IjU1LjA1IiB5PSIxODUuNDkiIHdpZHRoPSIxMTYuMzMiIGhlaWdodD0iMzQuMDQxIiBzdHJva2Utd2lkdGg9IjcuOTgyIi8+PHBhdGggZD0ibTEwMC42NCAxNDguMjcgMWUtNSAxMy40NzUgNjIuNzI5IDIyLjIyMiA0LjI0MTYtMTEuOTcyeiIgc3Ryb2tlLXdpZHRoPSI3Ljk4MiIvPjxwYXRoIGQ9Im01NS4wNSAxNTEuMzQtNGUtNiAxNS4zNTYgNzguMjY1IDI4LjIyNiAxMC42ODQtMTEuNTAzeiIgc3Ryb2tlLXdpZHRoPSIxMi43OTkiLz48cmVjdCB4PSIxMzguNDIiIHk9IjE4Mi43MSIgd2lkdGg9IjEzLjY5MyIgaGVpZ2h0PSI0LjE5NzMiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48cGF0aCBkPSJtNTUuMDUgMTcxLjM0IDVlLTYgMjEuMjkxIDMzLjk2IDEyLjQ5MSA2Ljg5NzItMTguNzUzeiIgc3Ryb2tlLXdpZHRoPSI4Ljk0NjciLz48L2c+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMS42NjM1IDAgMCAxLjY2MzUgMTUyLjI1IC02MC45MjIpIj48Y2lyY2xlIGN4PSIxLjk1MzMiIGN5PSIxMDIuNDUiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9IjMuNzgxNCIgY3k9IjEwOC41MiIgcj0iMi45MDY3Ii8+PGNpcmNsZSBjeD0iMS45OTk4IiBjeT0iMTA1Ljg4IiByPSIyLjkwNjciLz48Y2lyY2xlIGN4PSIxLjE4NDMiIGN5PSIxMDcuMDEiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9Ii01LjAwNTkiIGN5PSI5NS41NzYiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii00LjQyOTgiIGN5PSIxMDAuOTkiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii0zMS42NDYiIGN5PSI5NC4yMzIiIHI9IjYuODcxOCIvPjxjaXJjbGUgY3g9Ii0zMy45MzYiIGN5PSIxMDYuNDIiIHI9IjQuNjYzNiIvPjxjaXJjbGUgY3g9Ii0zMC4xNzgiIGN5PSIxMDYuMjMiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii0zNi45NDciIGN5PSIxMDQuNTIiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii00Ny44OCIgY3k9IjEwNS4zMSIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUwLjgyOSIgY3k9IjEwNC4zNyIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUxLjI1MSIgY3k9IjEwMC43NiIgcj0iNS41NDA4Ii8+PGNpcmNsZSBjeD0iLTUyLjQ0OCIgY3k9IjkzLjAxNiIgcj0iMS41NTQ2Ii8+PGNpcmNsZSBjeD0iLTQ5LjU5OSIgY3k9IjkyLjA0MSIgcj0iMS45NjkxIi8+PGVsbGlwc2UgY3g9Ii00NS43OTEiIGN5PSI5My4xMjIiIHJ4PSIzLjczNTYiIHJ5PSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItNDIuMzk2IiBjeT0iOTMuOTY3IiByPSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItMzguNzMiIGN5PSI5My42NjUiIHI9IjEuOTY5MSIvPjxjaXJjbGUgY3g9Ii0xMS43NTYiIGN5PSIxMDYuNTkiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xNC43MDUiIGN5PSIxMDUuNDYiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xOS45NTIiIGN5PSIxMDEuMTgiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0yNi44MjIiIGN5PSIxMDEuNSIgcj0iNC42MjMyIi8+PGNpcmNsZSBjeD0iLTEyLjA1IiBjeT0iODcuNzMxIiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNS45NzU4IiBjeT0iOTAuMTQ5IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNi45NjI4IiBjeT0iODguNzI1IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItMTQuODc0IiBjeT0iOTEuMjM3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMTcuMDY1IiBjeT0iOTMuNzc2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItNDMuNTQ0IiBjeT0iMTAzLjE3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjAuOTc4IiBjeT0iOTcuNTI1IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjUuNzQ3IiBjeT0iOTYuMTk2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItOS42MzA0IiBjeT0iODkuMzU2IiByPSIyLjIyMTQiLz48Y2lyY2xlIGN4PSItNTEuMTc1IiBjeT0iOTYuMzEyIiByPSIyLjIyMTQiLz48ZWxsaXBzZSBjeD0iMy42MzY2IiBjeT0iMTEyLjkzIiByeD0iMy4yOTc3IiByeT0iNy4yNjQ5Ii8+PHBhdGggZD0ibS0wLjI0ODI4IDEwNy4wOGMtMS41NWUtNiAyLjU1MzMtMS44MzE4IDAuMjMyMTUtNC4zODUyIDAuMjMyMTVzLTQuODYxMyAyLjMyMTItNC44NjEzLTAuMjMyMTVjLTRlLTYgLTIuNTUzMyAyLjA2OTktNC42MjMyIDQuNjIzMi00LjYyMzIgMi41NTMzIDAgNC42MjMyIDIuMDY5OSA0LjYyMzIgNC42MjMyeiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjQyMzUiLz48cGF0aCBkPSJtLTUwLjQ2IDkyLjcxLTEuNDQyNCAwLjQ0OTcyLTAuMDYxNzggMi42MjM0czAuOTA3NzMgMi44MzE2IDEuMDQyNSAzLjA2MDdjMC4xMzQ3NiAwLjIyOTEgMi42MDk0IDMuNDY4IDIuNjA5NCAzLjQ2OGw1LjIzODEgMC40OTM1NyAzLjcyMDMgMS4yNTE0IDMuNzY4IDAuMjE4NzFzNC44MTEyIDEuMjc1MSA1LjIzNzMgMC44MjI0N2MwLjQyNjA2LTAuNDUyNjYgMS40NDg4LTUuMDU0MiAxLjQxMzYtNS4zNTQ1LTAuMDM1MTYtMC4zMDAzNC0zLjM5NTctMS43NzQ1LTMuMzk1Ny0xLjc3NDVsLTMuODQwNS0yLjU0NzItMS42MjUtMS4yMTM0LTIuOTQ0Ni0wLjEwMDkycy0yLjc2MjctMC4zNTA3MS0zLjAzMTQtMC41MTY0NWMtMC4yNjg3Mi0wLjE2NTc1LTMuMTkxNC0wLjc2NTgtMy4zNDczLTAuNzY1OC0wLjE1NTg4IDAtMy4zNDA1LTAuMTE1My0zLjM0MDUtMC4xMTUzeiIvPjxwYXRoIGQ9Im0tMjAuMTk2IDk2LjUwNyAyLjkwNTQgNy4xMTYxIDQuOTYzNiAyLjIxMzUgNy4yMjgyLTAuMzU5MDkgNS4zOTc1IDAuNDAyODVzMS4xNDY1LTIuNDc2MyAxLjE2NjYtMi42Mzg1YzAuMDIwMTA4LTAuMTYyMjMtMi4yNDgzLTEuODA5OC0yLjI0ODMtMS44MDk4bC0xLjQ3OTgtMi4xNjU2LTAuMjEyNTItMi43NjQ5cy0xLjUxOTQtMi4zOTMzLTEuNTIyOC0yLjU1NTVjLTAuMDAzMzMtMC4xNjIxNy0yLjYyMjktNC4yNzMyLTIuNjIyOS00LjI3MzJsLTUuMjE1OS0wLjA2MjAzLTUuMTcyNCAzLjUyOTV6Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.54348" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="128" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0NC43OG1tIiBoZWlnaHQ9Ijk1LjM2M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDQuNzggOTUuMzYzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNi43MjcgLTEwNi4yNykiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE3MS40NyAxMDYuMjd2OTUuMzYzIiBzdHJva2Utd2lkdGg9IjIwLjA3OSIvPjxwYXRoIGQ9Im0xNzEuNDcgMTk1LjQ5aC0xMjguNjF2LTQzLjcxNGwyMy4xNDQtMTQuMTQ5IDEwLjU5MiAxOS4yMjQgMjguNjg0LTE5LjcyNyAxMi42MTEgMjAuNTczIDMwLjU5OS0yMi41MSAxOC42ODggMzEuNTQiIHN0cm9rZS13aWR0aD0iMTIuMjY5Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="129" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43NG1tIiBoZWlnaHQ9IjEyMy4wN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzQgMTIzLjA3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40MDkgLTk1LjY1NCkiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGcgc3Ryb2tlLXdpZHRoPSI4LjgxMiI+PHBhdGggZD0ibTQ5LjgxNSAxNzAuOTN2NDMuMzg2aDI4LjYzOXYtMzMuNzg1aDIyLjM0NiIvPjxwYXRoIGQ9Im0xNTAuNjMgMTcwLjkzdjQzLjM4NmgtMjguNjM5di0zMy43ODVoLTIyLjM0NiIvPjxwYXRoIGQ9Im00OS44MTUgMTcwLjkzczguOTczOS0xNS41ODIgMTUuODI2LTIyLjQzNGM5LjM0NzQtOS4zNDc0IDIxLjk0LTE4LjMzMyAzNS4xNTktMTguMzQ2IDEzLjI3LTAuMDEzMSAyNS45NDYgOC45NjI4IDM1LjMyOSAxOC4zNDYgNi42MTk2IDYuNjE5NiAxNC40OTggMjIuNDM0IDE0LjQ5OCAyMi40MzQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Im0xNTAuNjMgMjE0LjMyaDI3LjkyMXYtODEuMzUyaC0zOC44NHYxNi4yMDgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz48L2c+PHBhdGggZD0ibTExOC4yMSAxMzQuMTF2LTEyLjU0M2gyMi40MTciIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS13aWR0aD0iNy41MTUiLz48cGF0aCBkPSJtMTc4LjQgMTMxLjQ3YzAtMTAuNjQzLTguNjI4Mi0xOS4yNzItMTkuMjcyLTE5LjI3MnMtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2Utd2lkdGg9IjkuNTA4Ii8+PHBhdGggZD0ibTE1Ni43NiAxMTYuODFjLTEuMDkxNS05LjQ3MTktOC42NDU0LTE2LjU0Ny0xOC40OC0xNi41NDctMTAuNjQzIDAtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuMjA4Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5OS42NW1tIiBoZWlnaHQ9IjEzMS4yN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTkuNjUgMTMxLjI3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02LjY4NDcgLTk0LjExNykiPjxyZWN0IHg9IjE4NS4xNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjEuMTc2IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjEwMi4yNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjIuNTU3IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjExNC4zIiB5PSIyMTEuNDQiIHdpZHRoPSI3Ny4zMjUiIGhlaWdodD0iOS42MjExIi8+PHJlY3QgeD0iMTM4LjU5IiB5PSIxOTUuNjYiIHdpZHRoPSIzMS44ODMiIGhlaWdodD0iMTcuODMyIi8+PHJlY3QgeD0iMTEzLjMxIiB5PSIxNDguNTYiIHdpZHRoPSI5My4wMjEiIGhlaWdodD0iNTEuNjA3Ii8+PHJlY3QgeD0iMTY5LjQ2IiB5PSIxMzkuODQiIHdpZHRoPSIzNi44NzQiIGhlaWdodD0iMTcuNDQyIi8+PHBhdGggZD0ibTExOC4zMyAxMzAuODN2MjQuNTM3aDI0Ljk2MXYtMjQuNTM3em02LjI3MiA2LjI3ODJoOC43OTMzdjExLjQ0OWgtOC43OTMzeiIvPjxwYXRoIGQ9Im0xMjAuMyAxNDQuNzhoLTEwLjg0NmwtMTMuNjAxLTE2LjE5MyAyLjIyODktMy40NDg3aDEwLjAyOGwzLjgwOTctMy42NDM5LTAuMjIyMDctMi40ODQ2IDcuMDQ0Ni01LjcxMTggMi4xMDcyIDIuMzEzMyAyLjIxMjktMC43NTE1OHYtOC4xMTJsLTIuMTM0OC0xLjkzODQtMy4xMTA4IDAuMzI4NDV2LTQuNDQ0M2wtMi4xODc1LTMuMjE3NmgtNi4yNTE1bC0yMi4zNDYgMjQuMzczaC04LjQ2ODJsLTI3LjczNS0yNy43MjloLTkuNDhsLTQuMzY1NCA1Ljg1ODkgMjkuMTA5IDI5LjY1N2g1LjI3MThsMi4xOTYyIDIuMTYydjIuOTcwNGwtMi40MTU1IDIuMTI3OWgtOS4zMzc2bC0yMS4zOTggMjEuMjEyaC0xOS45MzRsLTEzLjc5MSAyMi41Nzl2My45MjA4aDMyLjU3OHYtNC43MTQxaDcuMTM2MnYtMTcuNDgzbDI3LjY0NC0yMC40MjdoMTIuOTAybDI5LjIxNiAyNC4xNDl6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="130" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43OW1tIiBoZWlnaHQ9IjEyMy43OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzkgMTIzLjc5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS4zNTggLTkxLjgyNikiPjxnPjxyZWN0IHg9IjE1OC43OCIgeT0iOTEuODI2IiB3aWR0aD0iMTMuMjYyIiBoZWlnaHQ9Ijg2LjE3Ii8+PHJlY3QgeD0iMTM4LjA4IiB5PSI5MS44MjYiIHdpZHRoPSIxMy4yNjIiIGhlaWdodD0iODYuMTciLz48cmVjdCB4PSIxMTMuMTIiIHk9IjkxLjgyNiIgd2lkdGg9IjEzLjI2MiIgaGVpZ2h0PSI4Ni4xNyIvPjxwYXRoIGQ9Im00NS44ODggMTc1LjcxLTAuNTI5MTcgMC41MjkxNnYzOS4zNzRoMTM3Ljc5di0zOS45MDR6bTQuNjUxOSA1LjI1MDhoMjIuNzI5djYuODk3OGgtMjIuNzI5em0yNy45NzkgMGgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bTI3LjkzMiAwaDE5LjExOXY2Ljg5NzhoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3OGgtMjIuNzI5em0tNzYuNzE2IDExLjI1MmgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bS01Mi4zNDcgMC4zNjc5M2gyMi43Mjl2Ni44OTczaC0yMi43Mjl6bTgwLjI3OSAwaDE5LjExOXY2Ljg5NzNoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3M2gtMjIuNzI5eiIvPjxwYXRoIGQ9Im03MC40MTEgMTUxLjE4LTEyLjkxNCAxMi45MTQtMTIuMTM4IDEyLjEzOWgyNS4wNTN6Ii8+PHBhdGggZD0ibTk0LjkzNSAxNTEuMTgtMTIuOTE0IDEyLjkxNC0xMi4xMzggMTIuMTM5aDI1LjA1M3oiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="131" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzOS43N21tIiBoZWlnaHQ9IjEyNS42NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzkuNzcgMTI1LjY1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41ODcgLTgyLjMxMykiPjxnPjxjaXJjbGUgY3g9IjkzLjM3MiIgY3k9IjE5NS4wOCIgcj0iMTIuODgzIi8+PGNpcmNsZSBjeD0iMTM0Ljg2IiBjeT0iMTk1LjA4IiByPSIxMi44ODMiLz48cGF0aCBkPSJtNDEuNTg3IDEyMy44NWgxMzkuNzdsLTI2LjMzOSA1Ny43OTZoLTg3LjA3NHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOS41MDgiLz48Y2lyY2xlIGN4PSI4MS4wMzYiIGN5PSIxMjAuNTYiIHI9IjIwLjU2OCIvPjxjaXJjbGUgY3g9IjE0Mi41NSIgY3k9IjEyMC41NiIgcj0iMjAuNTY4Ii8+PHBhdGggZD0ibTExMS40NyA4Mi4zMTNhMjAuNTY4IDIwLjU2OCAwIDAgMC0yMC41NjggMjAuNTY4aDQxLjEzN2EyMC41NjggMjAuNTY4IDAgMCAwLTIwLjU2OC0yMC41Njh6Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="132" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="133" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5OS42NW1tIiBoZWlnaHQ9IjEzMS4yN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTkuNjUgMTMxLjI3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02LjY4NDcgLTk0LjExNykiPjxyZWN0IHg9IjE4NS4xNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjEuMTc2IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjEwMi4yNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjIuNTU3IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjExNC4zIiB5PSIyMTEuNDQiIHdpZHRoPSI3Ny4zMjUiIGhlaWdodD0iOS42MjExIi8+PHJlY3QgeD0iMTM4LjU5IiB5PSIxOTUuNjYiIHdpZHRoPSIzMS44ODMiIGhlaWdodD0iMTcuODMyIi8+PHJlY3QgeD0iMTEzLjMxIiB5PSIxNDguNTYiIHdpZHRoPSI5My4wMjEiIGhlaWdodD0iNTEuNjA3Ii8+PHJlY3QgeD0iMTY5LjQ2IiB5PSIxMzkuODQiIHdpZHRoPSIzNi44NzQiIGhlaWdodD0iMTcuNDQyIi8+PHBhdGggZD0ibTExOC4zMyAxMzAuODN2MjQuNTM3aDI0Ljk2MXYtMjQuNTM3em02LjI3MiA2LjI3ODJoOC43OTMzdjExLjQ0OWgtOC43OTMzeiIvPjxwYXRoIGQ9Im0xMjAuMyAxNDQuNzhoLTEwLjg0NmwtMTMuNjAxLTE2LjE5MyAyLjIyODktMy40NDg3aDEwLjAyOGwzLjgwOTctMy42NDM5LTAuMjIyMDctMi40ODQ2IDcuMDQ0Ni01LjcxMTggMi4xMDcyIDIuMzEzMyAyLjIxMjktMC43NTE1OHYtOC4xMTJsLTIuMTM0OC0xLjkzODQtMy4xMTA4IDAuMzI4NDV2LTQuNDQ0M2wtMi4xODc1LTMuMjE3NmgtNi4yNTE1bC0yMi4zNDYgMjQuMzczaC04LjQ2ODJsLTI3LjczNS0yNy43MjloLTkuNDhsLTQuMzY1NCA1Ljg1ODkgMjkuMTA5IDI5LjY1N2g1LjI3MThsMi4xOTYyIDIuMTYydjIuOTcwNGwtMi40MTU1IDIuMTI3OWgtOS4zMzc2bC0yMS4zOTggMjEuMjEyaC0xOS45MzRsLTEzLjc5MSAyMi41Nzl2My45MjA4aDMyLjU3OHYtNC43MTQxaDcuMTM2MnYtMTcuNDgzbDI3LjY0NC0yMC40MjdoMTIuOTAybDI5LjIxNiAyNC4xNDl6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="134" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5NC41NW1tIiBoZWlnaHQ9IjE5MS4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTQuNTUgMTkxLjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjk2MTggLTUzLjM3MikiPjxnPjxyZWN0IHg9IjMuOTYxOCIgeT0iMjE2Ljk4IiB3aWR0aD0iMTk0LjU1IiBoZWlnaHQ9IjI3LjcxOCIvPjxyZWN0IHg9IjEzNi4wNSIgeT0iOTAuNDc1IiB3aWR0aD0iNDEuOTcyIiBoZWlnaHQ9IjEzNS43NiIgcnk9IjQuODQwOCIvPjxyZWN0IHg9IjcxLjcxMiIgeT0iOTAuNDc1IiB3aWR0aD0iNDYuNjY5IiBoZWlnaHQ9IjEzNy45MiIgcnk9IjcuNzI5MSIvPjxyZWN0IHg9IjIzLjI4MiIgeT0iOTAuNDc1IiB3aWR0aD0iMjIuODIyIiBoZWlnaHQ9IjEzNS40NCIgcnk9IjUuMTgyOSIvPjwvZz48cGF0aCBkPSJtMTU4LjAyIDk0LjgxNWMxLjRlLTQgLTE3LjI2LTEzLjc5Ni0zMS4yNTMtMzAuODE1LTMxLjI1My0xNy4wMTktMS40MmUtNCAtMzAuODE1IDEzLjk5Mi0zMC44MTUgMzEuMjUzIDAuMDAyNCAwLjcwNzYyIDAuMDI4NDQgMS40MTUgMC4wNzgxNiAyLjEyMDgiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMy4yIiBzdHJva2Utd2lkdGg9IjIwLjM4MSIvPjxwYXRoIGQ9Im05Ni45MzggOTQuNzc2YzEuNGUtNCAtMTcuMjE0LTEzLjk1NS0zMS4xNjktMzEuMTY5LTMxLjE2OS0xNy4yMTQtMS40MWUtNCAtMzEuMTY5IDEzLjk1NS0zMS4xNjkgMzEuMTY5IDAuMDAyNCAwLjcwNTczIDAuMDI4NzcgMS40MTEyIDAuMDc5MDYgMi4xMTUxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuMiIgc3Ryb2tlLXdpZHRoPSIyMC40NyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.28779" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="135" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4MC42OG1tIiBoZWlnaHQ9IjE4Ni40N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODAuNjggMTg2LjQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05Ljg2NjQgLTU1LjgzNikiPjxyZWN0IHg9IjE4LjUzNyIgeT0iMTc1LjExIiB3aWR0aD0iMTM2LjY0IiBoZWlnaHQ9IjY3LjE5MyIgcnk9IjAiLz48cmVjdCB4PSIxNjQuMzUiIHk9IjEyOS4yNCIgd2lkdGg9IjI2LjE4OSIgaGVpZ2h0PSIxMTMuMDYiIHJ5PSIwIi8+PGNpcmNsZSBjeD0iMTcyLjYzIiBjeT0iMTA2LjMzIiByPSIxMi44MDEiLz48Y2lyY2xlIGN4PSIxNjUuNzIiIGN5PSI5Ny4zMzMiIHI9IjEyLjgwMSIvPjxjaXJjbGUgY3g9IjE0OC42NyIgY3k9IjEwNy4xMyIgcj0iOS4xMzM1Ii8+PGNpcmNsZSBjeD0iMTM3LjMzIiBjeT0iMTA0LjY4IiByPSI5LjEzMzUiLz48Y2lyY2xlIGN4PSIxNDkuNjYiIGN5PSI4NC4wODEiIHI9IjE0LjYxNyIvPjxjaXJjbGUgY3g9IjExNC42MSIgY3k9IjEwMi42MiIgcj0iMTMuMzc4Ii8+PGNpcmNsZSBjeD0iMTI5LjQiIGN5PSI4MC43OTciIHI9IjguODg1NSIvPjxjaXJjbGUgY3g9IjExOC4zNiIgY3k9IjY3LjQ5NCIgcj0iMTEuNjU4Ii8+PGNpcmNsZSBjeD0iOTcuODAxIiBjeT0iODYuNTA0IiByPSIxMy4wMDUiLz48Y2lyY2xlIGN4PSI5Mi44MDIiIGN5PSI4MC45NzEiIHI9IjEzLjAwNSIvPjxjaXJjbGUgY3g9IjkzLjY5OSIgY3k9IjYzLjc4NSIgcj0iNy4yNjI0Ii8+PGNpcmNsZSBjeD0iMTAwLjU5IiBjeT0iNjcuNjY2IiByPSI3LjI2MjQiLz48Y2lyY2xlIGN4PSIxMjguOTYiIGN5PSI5OS45NDYiIHI9IjcuMjYyNCIvPjxyZWN0IHg9IjEwMC43NCIgeT0iNjguNDg3IiB3aWR0aD0iMjEuNjAxIiBoZWlnaHQ9IjI0LjYzNCIvPjxyZWN0IHg9IjExOS45MyIgeT0iODMuMTkiIHdpZHRoPSIzNC41OSIgaGVpZ2h0PSIxNy4yNTUiLz48Y2lyY2xlIGN4PSI2MC40MjQiIGN5PSI4Mi44MTkiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjU3LjExMyIgY3k9Ijk3Ljc2MyIgcj0iMTUuMjE3Ii8+PGNpcmNsZSBjeD0iMzcuODI2IiBjeT0iMTAxLjc2IiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSIyNS4wODMiIGN5PSI4MC44MDgiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjMyLjU4OCIgY3k9Ijk0LjcyIiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSI0Mi45NjciIGN5PSI4OS40MjMiIHI9IjE1LjIxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="136" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3OC4xM21tIiBoZWlnaHQ9IjExNy45NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzguMTMgMTE3Ljk0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTIzLjg2NSkiPjxwYXRoIGQ9Im0yMy43NzEgMjMuODY1djYyLjQ3M2gtMC4wMDIxYzEuMDllLTQgMC4wMjc2MSAwLjAwMjEgMC4wNTQ4MSAwLjAwMjEgMC4wODI1djIzLjI1MWMwIDEyLjE2LTEwLjU5IDIxLjk1Ny0yMy43NzEgMjIuMDI2djEwLjEwNGg5NS42OTl2LTEwLjEwNGMtMTMuMTgyLTAuMDY5MS0yMy43NzEtOS44NjYtMjMuNzcxLTIyLjAyNnYtMjMuMjUxYzAtMC4wMjc3IDJlLTMgLTAuMDU0ODkgMC4wMDIxLTAuMDgyNWgtMC4wMDIxdi02Mi40NzN6Ii8+PHBhdGggZD0ibTEyMS43NCA0OS4wM3Y0OS4xNDNoLTJlLTNjOGUtNSAwLjAyMTcgMmUtMyAwLjA0MzA2IDJlLTMgMC4wNjQ5MnYxOC4yODljMCA5LjU2NTctOC4zMDI3IDE3LjI3Mi0xOC42MzggMTcuMzI3djcuOTQ4NGg3NS4wMzJ2LTcuOTQ4NGMtMTAuMzM1LTAuMDU0My0xOC42MzgtNy43NjA5LTE4LjYzOC0xNy4zMjd2LTE4LjI4OWMwLTAuMDIxNzggMmUtMyAtMC4wNDMxNCAyZS0zIC0wLjA2NDkyaC0yZS0zdi00OS4xNDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0.40000000000000002" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="137" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS4zbW0iIGhlaWdodD0iMTM5Ljk0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OS4zIDEzOS45NCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzIuMjYzIC03Ni44ODQpIj48Y2lyY2xlIGN4PSI3OS40OTEiIGN5PSIxOTUuOTgiIHI9IjE2Ljg1IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48Y2lyY2xlIGN4PSIxNTQuOCIgY3k9IjE5NS45OCIgcj0iMTYuODUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3Ljk4MTUiLz48Zz48cmVjdCB4PSIxMDMuMzUiIHk9IjE4Mi42MiIgd2lkdGg9IjI1LjU0OSIgaGVpZ2h0PSIxNi4yMjIiLz48cGF0aCBkPSJtMzIuMjYzIDE0OS4wOHY0Mi43OThoMjEuOTlhMjQuODI3IDI0LjgyNyAwIDAgMSAyMC4wMzMtMjAuNTk2di0yMi4yMDN6bTQuNzY1MSA1LjAwMjhoMTcuNjI3djIwLjEzM2gtMTcuNjI3eiIvPjxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDQwLjE1MykiIGQ9Im0xNDUuMDcgNi43OTExLTMuOWUtNCA0MS4yOSA2NS4wMzktMi42ZS01IDI5LjM2Ny0yNC43NzYgMi45ZS00IC0xNi41MTR6Ii8+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoMzkuODQ5KSIgZD0ibTE3MS4wMSA0My41NTUtMi45ZS00IDUuNDU3MSA0LjQyMDMgMmUtNSAyZS01IDI1LjQ5IDExLjgwNS0yLjI1ZS00IDIuM2UtNCAtMjUuNDI4IDUuMTA3OCAzLjU4ZS00IDVlLTUgLTUuNTE5NXoiLz48cGF0aCBkPSJtMTcxLjEgMTUzLjIzLTEyLjk1MiAxOC45OTloOS44NjI0bDguNTU0NSAxMC45OTIgNS4wMDE4IDAuMzM2OTN2LTE5Ljc5NWwtMi45MDczLTQuMTU2M3oiLz48cGF0aCBkPSJtMTEzLjAyIDEwNC4yNC02LjUyMjctNS41MDI5LTIzLjEzMi0xOS45MDUtOC41MjY2LTEuOTQ2NiAwLjA1MzA4OSA4LjIyMDcgMjUuNjIxIDIwLjcyNSA0LjQ4MzUgNS4xNzQyeiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="138" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzMi4xNm1tIiBoZWlnaHQ9IjEyMy44Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzIuMTYgMTIzLjg2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4yMTkgLTkxLjcyMSkiPjxnPjxyZWN0IHg9IjE2MS45NyIgeT0iOTEuNzIxIiB3aWR0aD0iMTYuNDEiIGhlaWdodD0iMTIzLjg2Ii8+PHJlY3QgeD0iNDYuMjIiIHk9IjE2OC4yNSIgd2lkdGg9IjEzMi4xNiIgaGVpZ2h0PSI0Ny4zMjgiLz48cmVjdCB4PSIxNDAuMDQiIHk9IjkxLjcyMSIgd2lkdGg9IjE2LjQxIiBoZWlnaHQ9IjEyMy44NiIvPjxwYXRoIGQ9Im03NS42NDkgMTM4LjczLTI5LjQyOSAyOS40Mjl2MTMuOTU5aDI5LjQyOXoiLz48cGF0aCBkPSJtMTA1LjA4IDEzOC43My0yOS40MjkgMjkuNDI5djEzLjk1OWgyOS40Mjl6Ii8+PHBhdGggZD0ibTEzNC41MSAxMzguNzMtMjkuNDI5IDI5LjQyOXYxMy45NTloMjkuNDI5eiIvPjxyZWN0IHg9IjQ2LjIxOSIgeT0iMTY4LjI1IiB3aWR0aD0iMTMyLjE2IiBoZWlnaHQ9IjEzLjc2OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="139" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNi4zM21tIiBoZWlnaHQ9IjEzOC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTYuMzMgMTM4LjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NS4wNSAtODEuMjY0KSI+PGc+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iMTQ4LjM2IiB5PSIxMjYuNDUiIHdpZHRoPSIyMy4wMTUiIGhlaWdodD0iOTMuMDgxIiBzdHJva2Utd2lkdGg9IjcuNTQ3NCIvPjxyZWN0IHg9IjU1LjA1IiB5PSIxODUuNDkiIHdpZHRoPSIxMTYuMzMiIGhlaWdodD0iMzQuMDQxIiBzdHJva2Utd2lkdGg9IjcuOTgyIi8+PHBhdGggZD0ibTEwMC42NCAxNDguMjcgMWUtNSAxMy40NzUgNjIuNzI5IDIyLjIyMiA0LjI0MTYtMTEuOTcyeiIgc3Ryb2tlLXdpZHRoPSI3Ljk4MiIvPjxwYXRoIGQ9Im01NS4wNSAxNTEuMzQtNGUtNiAxNS4zNTYgNzguMjY1IDI4LjIyNiAxMC42ODQtMTEuNTAzeiIgc3Ryb2tlLXdpZHRoPSIxMi43OTkiLz48cmVjdCB4PSIxMzguNDIiIHk9IjE4Mi43MSIgd2lkdGg9IjEzLjY5MyIgaGVpZ2h0PSI0LjE5NzMiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48cGF0aCBkPSJtNTUuMDUgMTcxLjM0IDVlLTYgMjEuMjkxIDMzLjk2IDEyLjQ5MSA2Ljg5NzItMTguNzUzeiIgc3Ryb2tlLXdpZHRoPSI4Ljk0NjciLz48L2c+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMS42NjM1IDAgMCAxLjY2MzUgMTUyLjI1IC02MC45MjIpIj48Y2lyY2xlIGN4PSIxLjk1MzMiIGN5PSIxMDIuNDUiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9IjMuNzgxNCIgY3k9IjEwOC41MiIgcj0iMi45MDY3Ii8+PGNpcmNsZSBjeD0iMS45OTk4IiBjeT0iMTA1Ljg4IiByPSIyLjkwNjciLz48Y2lyY2xlIGN4PSIxLjE4NDMiIGN5PSIxMDcuMDEiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9Ii01LjAwNTkiIGN5PSI5NS41NzYiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii00LjQyOTgiIGN5PSIxMDAuOTkiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii0zMS42NDYiIGN5PSI5NC4yMzIiIHI9IjYuODcxOCIvPjxjaXJjbGUgY3g9Ii0zMy45MzYiIGN5PSIxMDYuNDIiIHI9IjQuNjYzNiIvPjxjaXJjbGUgY3g9Ii0zMC4xNzgiIGN5PSIxMDYuMjMiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii0zNi45NDciIGN5PSIxMDQuNTIiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii00Ny44OCIgY3k9IjEwNS4zMSIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUwLjgyOSIgY3k9IjEwNC4zNyIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUxLjI1MSIgY3k9IjEwMC43NiIgcj0iNS41NDA4Ii8+PGNpcmNsZSBjeD0iLTUyLjQ0OCIgY3k9IjkzLjAxNiIgcj0iMS41NTQ2Ii8+PGNpcmNsZSBjeD0iLTQ5LjU5OSIgY3k9IjkyLjA0MSIgcj0iMS45NjkxIi8+PGVsbGlwc2UgY3g9Ii00NS43OTEiIGN5PSI5My4xMjIiIHJ4PSIzLjczNTYiIHJ5PSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItNDIuMzk2IiBjeT0iOTMuOTY3IiByPSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItMzguNzMiIGN5PSI5My42NjUiIHI9IjEuOTY5MSIvPjxjaXJjbGUgY3g9Ii0xMS43NTYiIGN5PSIxMDYuNTkiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xNC43MDUiIGN5PSIxMDUuNDYiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xOS45NTIiIGN5PSIxMDEuMTgiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0yNi44MjIiIGN5PSIxMDEuNSIgcj0iNC42MjMyIi8+PGNpcmNsZSBjeD0iLTEyLjA1IiBjeT0iODcuNzMxIiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNS45NzU4IiBjeT0iOTAuMTQ5IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNi45NjI4IiBjeT0iODguNzI1IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItMTQuODc0IiBjeT0iOTEuMjM3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMTcuMDY1IiBjeT0iOTMuNzc2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItNDMuNTQ0IiBjeT0iMTAzLjE3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjAuOTc4IiBjeT0iOTcuNTI1IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjUuNzQ3IiBjeT0iOTYuMTk2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItOS42MzA0IiBjeT0iODkuMzU2IiByPSIyLjIyMTQiLz48Y2lyY2xlIGN4PSItNTEuMTc1IiBjeT0iOTYuMzEyIiByPSIyLjIyMTQiLz48ZWxsaXBzZSBjeD0iMy42MzY2IiBjeT0iMTEyLjkzIiByeD0iMy4yOTc3IiByeT0iNy4yNjQ5Ii8+PHBhdGggZD0ibS0wLjI0ODI4IDEwNy4wOGMtMS41NWUtNiAyLjU1MzMtMS44MzE4IDAuMjMyMTUtNC4zODUyIDAuMjMyMTVzLTQuODYxMyAyLjMyMTItNC44NjEzLTAuMjMyMTVjLTRlLTYgLTIuNTUzMyAyLjA2OTktNC42MjMyIDQuNjIzMi00LjYyMzIgMi41NTMzIDAgNC42MjMyIDIuMDY5OSA0LjYyMzIgNC42MjMyeiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjQyMzUiLz48cGF0aCBkPSJtLTUwLjQ2IDkyLjcxLTEuNDQyNCAwLjQ0OTcyLTAuMDYxNzggMi42MjM0czAuOTA3NzMgMi44MzE2IDEuMDQyNSAzLjA2MDdjMC4xMzQ3NiAwLjIyOTEgMi42MDk0IDMuNDY4IDIuNjA5NCAzLjQ2OGw1LjIzODEgMC40OTM1NyAzLjcyMDMgMS4yNTE0IDMuNzY4IDAuMjE4NzFzNC44MTEyIDEuMjc1MSA1LjIzNzMgMC44MjI0N2MwLjQyNjA2LTAuNDUyNjYgMS40NDg4LTUuMDU0MiAxLjQxMzYtNS4zNTQ1LTAuMDM1MTYtMC4zMDAzNC0zLjM5NTctMS43NzQ1LTMuMzk1Ny0xLjc3NDVsLTMuODQwNS0yLjU0NzItMS42MjUtMS4yMTM0LTIuOTQ0Ni0wLjEwMDkycy0yLjc2MjctMC4zNTA3MS0zLjAzMTQtMC41MTY0NWMtMC4yNjg3Mi0wLjE2NTc1LTMuMTkxNC0wLjc2NTgtMy4zNDczLTAuNzY1OC0wLjE1NTg4IDAtMy4zNDA1LTAuMTE1My0zLjM0MDUtMC4xMTUzeiIvPjxwYXRoIGQ9Im0tMjAuMTk2IDk2LjUwNyAyLjkwNTQgNy4xMTYxIDQuOTYzNiAyLjIxMzUgNy4yMjgyLTAuMzU5MDkgNS4zOTc1IDAuNDAyODVzMS4xNDY1LTIuNDc2MyAxLjE2NjYtMi42Mzg1YzAuMDIwMTA4LTAuMTYyMjMtMi4yNDgzLTEuODA5OC0yLjI0ODMtMS44MDk4bC0xLjQ3OTgtMi4xNjU2LTAuMjEyNTItMi43NjQ5cy0xLjUxOTQtMi4zOTMzLTEuNTIyOC0yLjU1NTVjLTAuMDAzMzMtMC4xNjIxNy0yLjYyMjktNC4yNzMyLTIuNjIyOS00LjI3MzJsLTUuMjE1OS0wLjA2MjAzLTUuMTcyNCAzLjUyOTV6Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.54348" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5NC41NW1tIiBoZWlnaHQ9IjE5MS4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTQuNTUgMTkxLjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjk2MTggLTUzLjM3MikiPjxnPjxyZWN0IHg9IjMuOTYxOCIgeT0iMjE2Ljk4IiB3aWR0aD0iMTk0LjU1IiBoZWlnaHQ9IjI3LjcxOCIvPjxyZWN0IHg9IjEzNi4wNSIgeT0iOTAuNDc1IiB3aWR0aD0iNDEuOTcyIiBoZWlnaHQ9IjEzNS43NiIgcnk9IjQuODQwOCIvPjxyZWN0IHg9IjcxLjcxMiIgeT0iOTAuNDc1IiB3aWR0aD0iNDYuNjY5IiBoZWlnaHQ9IjEzNy45MiIgcnk9IjcuNzI5MSIvPjxyZWN0IHg9IjIzLjI4MiIgeT0iOTAuNDc1IiB3aWR0aD0iMjIuODIyIiBoZWlnaHQ9IjEzNS40NCIgcnk9IjUuMTgyOSIvPjwvZz48cGF0aCBkPSJtMTU4LjAyIDk0LjgxNWMxLjRlLTQgLTE3LjI2LTEzLjc5Ni0zMS4yNTMtMzAuODE1LTMxLjI1My0xNy4wMTktMS40MmUtNCAtMzAuODE1IDEzLjk5Mi0zMC44MTUgMzEuMjUzIDAuMDAyNCAwLjcwNzYyIDAuMDI4NDQgMS40MTUgMC4wNzgxNiAyLjEyMDgiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMy4yIiBzdHJva2Utd2lkdGg9IjIwLjM4MSIvPjxwYXRoIGQ9Im05Ni45MzggOTQuNzc2YzEuNGUtNCAtMTcuMjE0LTEzLjk1NS0zMS4xNjktMzEuMTY5LTMxLjE2OS0xNy4yMTQtMS40MWUtNCAtMzEuMTY5IDEzLjk1NS0zMS4xNjkgMzEuMTY5IDAuMDAyNCAwLjcwNTczIDAuMDI4NzcgMS40MTEyIDAuMDc5MDYgMi4xMTUxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuMiIgc3Ryb2tlLXdpZHRoPSIyMC40NyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.28779" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="140" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0NC43OG1tIiBoZWlnaHQ9Ijk1LjM2M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDQuNzggOTUuMzYzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNi43MjcgLTEwNi4yNykiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE3MS40NyAxMDYuMjd2OTUuMzYzIiBzdHJva2Utd2lkdGg9IjIwLjA3OSIvPjxwYXRoIGQ9Im0xNzEuNDcgMTk1LjQ5aC0xMjguNjF2LTQzLjcxNGwyMy4xNDQtMTQuMTQ5IDEwLjU5MiAxOS4yMjQgMjguNjg0LTE5LjcyNyAxMi42MTEgMjAuNTczIDMwLjU5OS0yMi41MSAxOC42ODggMzEuNTQiIHN0cm9rZS13aWR0aD0iMTIuMjY5Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="141" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43NG1tIiBoZWlnaHQ9IjEyMy4wN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzQgMTIzLjA3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40MDkgLTk1LjY1NCkiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGcgc3Ryb2tlLXdpZHRoPSI4LjgxMiI+PHBhdGggZD0ibTQ5LjgxNSAxNzAuOTN2NDMuMzg2aDI4LjYzOXYtMzMuNzg1aDIyLjM0NiIvPjxwYXRoIGQ9Im0xNTAuNjMgMTcwLjkzdjQzLjM4NmgtMjguNjM5di0zMy43ODVoLTIyLjM0NiIvPjxwYXRoIGQ9Im00OS44MTUgMTcwLjkzczguOTczOS0xNS41ODIgMTUuODI2LTIyLjQzNGM5LjM0NzQtOS4zNDc0IDIxLjk0LTE4LjMzMyAzNS4xNTktMTguMzQ2IDEzLjI3LTAuMDEzMSAyNS45NDYgOC45NjI4IDM1LjMyOSAxOC4zNDYgNi42MTk2IDYuNjE5NiAxNC40OTggMjIuNDM0IDE0LjQ5OCAyMi40MzQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Im0xNTAuNjMgMjE0LjMyaDI3LjkyMXYtODEuMzUyaC0zOC44NHYxNi4yMDgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz48L2c+PHBhdGggZD0ibTExOC4yMSAxMzQuMTF2LTEyLjU0M2gyMi40MTciIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS13aWR0aD0iNy41MTUiLz48cGF0aCBkPSJtMTc4LjQgMTMxLjQ3YzAtMTAuNjQzLTguNjI4Mi0xOS4yNzItMTkuMjcyLTE5LjI3MnMtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2Utd2lkdGg9IjkuNTA4Ii8+PHBhdGggZD0ibTE1Ni43NiAxMTYuODFjLTEuMDkxNS05LjQ3MTktOC42NDU0LTE2LjU0Ny0xOC40OC0xNi41NDctMTAuNjQzIDAtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuMjA4Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="142" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43OW1tIiBoZWlnaHQ9IjEyMy43OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzkgMTIzLjc5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS4zNTggLTkxLjgyNikiPjxnPjxyZWN0IHg9IjE1OC43OCIgeT0iOTEuODI2IiB3aWR0aD0iMTMuMjYyIiBoZWlnaHQ9Ijg2LjE3Ii8+PHJlY3QgeD0iMTM4LjA4IiB5PSI5MS44MjYiIHdpZHRoPSIxMy4yNjIiIGhlaWdodD0iODYuMTciLz48cmVjdCB4PSIxMTMuMTIiIHk9IjkxLjgyNiIgd2lkdGg9IjEzLjI2MiIgaGVpZ2h0PSI4Ni4xNyIvPjxwYXRoIGQ9Im00NS44ODggMTc1LjcxLTAuNTI5MTcgMC41MjkxNnYzOS4zNzRoMTM3Ljc5di0zOS45MDR6bTQuNjUxOSA1LjI1MDhoMjIuNzI5djYuODk3OGgtMjIuNzI5em0yNy45NzkgMGgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bTI3LjkzMiAwaDE5LjExOXY2Ljg5NzhoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3OGgtMjIuNzI5em0tNzYuNzE2IDExLjI1MmgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bS01Mi4zNDcgMC4zNjc5M2gyMi43Mjl2Ni44OTczaC0yMi43Mjl6bTgwLjI3OSAwaDE5LjExOXY2Ljg5NzNoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3M2gtMjIuNzI5eiIvPjxwYXRoIGQ9Im03MC40MTEgMTUxLjE4LTEyLjkxNCAxMi45MTQtMTIuMTM4IDEyLjEzOWgyNS4wNTN6Ii8+PHBhdGggZD0ibTk0LjkzNSAxNTEuMTgtMTIuOTE0IDEyLjkxNC0xMi4xMzggMTIuMTM5aDI1LjA1M3oiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="143" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzOS43N21tIiBoZWlnaHQ9IjEyNS42NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzkuNzcgMTI1LjY1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41ODcgLTgyLjMxMykiPjxnPjxjaXJjbGUgY3g9IjkzLjM3MiIgY3k9IjE5NS4wOCIgcj0iMTIuODgzIi8+PGNpcmNsZSBjeD0iMTM0Ljg2IiBjeT0iMTk1LjA4IiByPSIxMi44ODMiLz48cGF0aCBkPSJtNDEuNTg3IDEyMy44NWgxMzkuNzdsLTI2LjMzOSA1Ny43OTZoLTg3LjA3NHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOS41MDgiLz48Y2lyY2xlIGN4PSI4MS4wMzYiIGN5PSIxMjAuNTYiIHI9IjIwLjU2OCIvPjxjaXJjbGUgY3g9IjE0Mi41NSIgY3k9IjEyMC41NiIgcj0iMjAuNTY4Ii8+PHBhdGggZD0ibTExMS40NyA4Mi4zMTNhMjAuNTY4IDIwLjU2OCAwIDAgMC0yMC41NjggMjAuNTY4aDQxLjEzN2EyMC41NjggMjAuNTY4IDAgMCAwLTIwLjU2OC0yMC41Njh6Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4MC42OG1tIiBoZWlnaHQ9IjE4Ni40N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODAuNjggMTg2LjQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05Ljg2NjQgLTU1LjgzNikiPjxyZWN0IHg9IjE4LjUzNyIgeT0iMTc1LjExIiB3aWR0aD0iMTM2LjY0IiBoZWlnaHQ9IjY3LjE5MyIgcnk9IjAiLz48cmVjdCB4PSIxNjQuMzUiIHk9IjEyOS4yNCIgd2lkdGg9IjI2LjE4OSIgaGVpZ2h0PSIxMTMuMDYiIHJ5PSIwIi8+PGNpcmNsZSBjeD0iMTcyLjYzIiBjeT0iMTA2LjMzIiByPSIxMi44MDEiLz48Y2lyY2xlIGN4PSIxNjUuNzIiIGN5PSI5Ny4zMzMiIHI9IjEyLjgwMSIvPjxjaXJjbGUgY3g9IjE0OC42NyIgY3k9IjEwNy4xMyIgcj0iOS4xMzM1Ii8+PGNpcmNsZSBjeD0iMTM3LjMzIiBjeT0iMTA0LjY4IiByPSI5LjEzMzUiLz48Y2lyY2xlIGN4PSIxNDkuNjYiIGN5PSI4NC4wODEiIHI9IjE0LjYxNyIvPjxjaXJjbGUgY3g9IjExNC42MSIgY3k9IjEwMi42MiIgcj0iMTMuMzc4Ii8+PGNpcmNsZSBjeD0iMTI5LjQiIGN5PSI4MC43OTciIHI9IjguODg1NSIvPjxjaXJjbGUgY3g9IjExOC4zNiIgY3k9IjY3LjQ5NCIgcj0iMTEuNjU4Ii8+PGNpcmNsZSBjeD0iOTcuODAxIiBjeT0iODYuNTA0IiByPSIxMy4wMDUiLz48Y2lyY2xlIGN4PSI5Mi44MDIiIGN5PSI4MC45NzEiIHI9IjEzLjAwNSIvPjxjaXJjbGUgY3g9IjkzLjY5OSIgY3k9IjYzLjc4NSIgcj0iNy4yNjI0Ii8+PGNpcmNsZSBjeD0iMTAwLjU5IiBjeT0iNjcuNjY2IiByPSI3LjI2MjQiLz48Y2lyY2xlIGN4PSIxMjguOTYiIGN5PSI5OS45NDYiIHI9IjcuMjYyNCIvPjxyZWN0IHg9IjEwMC43NCIgeT0iNjguNDg3IiB3aWR0aD0iMjEuNjAxIiBoZWlnaHQ9IjI0LjYzNCIvPjxyZWN0IHg9IjExOS45MyIgeT0iODMuMTkiIHdpZHRoPSIzNC41OSIgaGVpZ2h0PSIxNy4yNTUiLz48Y2lyY2xlIGN4PSI2MC40MjQiIGN5PSI4Mi44MTkiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjU3LjExMyIgY3k9Ijk3Ljc2MyIgcj0iMTUuMjE3Ii8+PGNpcmNsZSBjeD0iMzcuODI2IiBjeT0iMTAxLjc2IiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSIyNS4wODMiIGN5PSI4MC44MDgiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjMyLjU4OCIgY3k9Ijk0LjcyIiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSI0Mi45NjciIGN5PSI4OS40MjMiIHI9IjE1LjIxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3OC4xM21tIiBoZWlnaHQ9IjExNy45NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzguMTMgMTE3Ljk0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTIzLjg2NSkiPjxwYXRoIGQ9Im0yMy43NzEgMjMuODY1djYyLjQ3M2gtMC4wMDIxYzEuMDllLTQgMC4wMjc2MSAwLjAwMjEgMC4wNTQ4MSAwLjAwMjEgMC4wODI1djIzLjI1MWMwIDEyLjE2LTEwLjU5IDIxLjk1Ny0yMy43NzEgMjIuMDI2djEwLjEwNGg5NS42OTl2LTEwLjEwNGMtMTMuMTgyLTAuMDY5MS0yMy43NzEtOS44NjYtMjMuNzcxLTIyLjAyNnYtMjMuMjUxYzAtMC4wMjc3IDJlLTMgLTAuMDU0ODkgMC4wMDIxLTAuMDgyNWgtMC4wMDIxdi02Mi40NzN6Ii8+PHBhdGggZD0ibTEyMS43NCA0OS4wM3Y0OS4xNDNoLTJlLTNjOGUtNSAwLjAyMTcgMmUtMyAwLjA0MzA2IDJlLTMgMC4wNjQ5MnYxOC4yODljMCA5LjU2NTctOC4zMDI3IDE3LjI3Mi0xOC42MzggMTcuMzI3djcuOTQ4NGg3NS4wMzJ2LTcuOTQ4NGMtMTAuMzM1LTAuMDU0My0xOC42MzgtNy43NjA5LTE4LjYzOC0xNy4zMjd2LTE4LjI4OWMwLTAuMDIxNzggMmUtMyAtMC4wNDMxNCAyZS0zIC0wLjA2NDkyaC0yZS0zdi00OS4xNDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0.40000000000000002" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS4zbW0iIGhlaWdodD0iMTM5Ljk0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OS4zIDEzOS45NCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzIuMjYzIC03Ni44ODQpIj48Y2lyY2xlIGN4PSI3OS40OTEiIGN5PSIxOTUuOTgiIHI9IjE2Ljg1IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48Y2lyY2xlIGN4PSIxNTQuOCIgY3k9IjE5NS45OCIgcj0iMTYuODUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3Ljk4MTUiLz48Zz48cmVjdCB4PSIxMDMuMzUiIHk9IjE4Mi42MiIgd2lkdGg9IjI1LjU0OSIgaGVpZ2h0PSIxNi4yMjIiLz48cGF0aCBkPSJtMzIuMjYzIDE0OS4wOHY0Mi43OThoMjEuOTlhMjQuODI3IDI0LjgyNyAwIDAgMSAyMC4wMzMtMjAuNTk2di0yMi4yMDN6bTQuNzY1MSA1LjAwMjhoMTcuNjI3djIwLjEzM2gtMTcuNjI3eiIvPjxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDQwLjE1MykiIGQ9Im0xNDUuMDcgNi43OTExLTMuOWUtNCA0MS4yOSA2NS4wMzktMi42ZS01IDI5LjM2Ny0yNC43NzYgMi45ZS00IC0xNi41MTR6Ii8+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoMzkuODQ5KSIgZD0ibTE3MS4wMSA0My41NTUtMi45ZS00IDUuNDU3MSA0LjQyMDMgMmUtNSAyZS01IDI1LjQ5IDExLjgwNS0yLjI1ZS00IDIuM2UtNCAtMjUuNDI4IDUuMTA3OCAzLjU4ZS00IDVlLTUgLTUuNTE5NXoiLz48cGF0aCBkPSJtMTcxLjEgMTUzLjIzLTEyLjk1MiAxOC45OTloOS44NjI0bDguNTU0NSAxMC45OTIgNS4wMDE4IDAuMzM2OTN2LTE5Ljc5NWwtMi45MDczLTQuMTU2M3oiLz48cGF0aCBkPSJtMTEzLjAyIDEwNC4yNC02LjUyMjctNS41MDI5LTIzLjEzMi0xOS45MDUtOC41MjY2LTEuOTQ2NiAwLjA1MzA4OSA4LjIyMDcgMjUuNjIxIDIwLjcyNSA0LjQ4MzUgNS4xNzQyeiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzMi4xNm1tIiBoZWlnaHQ9IjEyMy44Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzIuMTYgMTIzLjg2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4yMTkgLTkxLjcyMSkiPjxnPjxyZWN0IHg9IjE2MS45NyIgeT0iOTEuNzIxIiB3aWR0aD0iMTYuNDEiIGhlaWdodD0iMTIzLjg2Ii8+PHJlY3QgeD0iNDYuMjIiIHk9IjE2OC4yNSIgd2lkdGg9IjEzMi4xNiIgaGVpZ2h0PSI0Ny4zMjgiLz48cmVjdCB4PSIxNDAuMDQiIHk9IjkxLjcyMSIgd2lkdGg9IjE2LjQxIiBoZWlnaHQ9IjEyMy44NiIvPjxwYXRoIGQ9Im03NS42NDkgMTM4LjczLTI5LjQyOSAyOS40Mjl2MTMuOTU5aDI5LjQyOXoiLz48cGF0aCBkPSJtMTA1LjA4IDEzOC43My0yOS40MjkgMjkuNDI5djEzLjk1OWgyOS40Mjl6Ii8+PHBhdGggZD0ibTEzNC41MSAxMzguNzMtMjkuNDI5IDI5LjQyOXYxMy45NTloMjkuNDI5eiIvPjxyZWN0IHg9IjQ2LjIxOSIgeT0iMTY4LjI1IiB3aWR0aD0iMTMyLjE2IiBoZWlnaHQ9IjEzLjc2OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNi4zM21tIiBoZWlnaHQ9IjEzOC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTYuMzMgMTM4LjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NS4wNSAtODEuMjY0KSI+PGc+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iMTQ4LjM2IiB5PSIxMjYuNDUiIHdpZHRoPSIyMy4wMTUiIGhlaWdodD0iOTMuMDgxIiBzdHJva2Utd2lkdGg9IjcuNTQ3NCIvPjxyZWN0IHg9IjU1LjA1IiB5PSIxODUuNDkiIHdpZHRoPSIxMTYuMzMiIGhlaWdodD0iMzQuMDQxIiBzdHJva2Utd2lkdGg9IjcuOTgyIi8+PHBhdGggZD0ibTEwMC42NCAxNDguMjcgMWUtNSAxMy40NzUgNjIuNzI5IDIyLjIyMiA0LjI0MTYtMTEuOTcyeiIgc3Ryb2tlLXdpZHRoPSI3Ljk4MiIvPjxwYXRoIGQ9Im01NS4wNSAxNTEuMzQtNGUtNiAxNS4zNTYgNzguMjY1IDI4LjIyNiAxMC42ODQtMTEuNTAzeiIgc3Ryb2tlLXdpZHRoPSIxMi43OTkiLz48cmVjdCB4PSIxMzguNDIiIHk9IjE4Mi43MSIgd2lkdGg9IjEzLjY5MyIgaGVpZ2h0PSI0LjE5NzMiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48cGF0aCBkPSJtNTUuMDUgMTcxLjM0IDVlLTYgMjEuMjkxIDMzLjk2IDEyLjQ5MSA2Ljg5NzItMTguNzUzeiIgc3Ryb2tlLXdpZHRoPSI4Ljk0NjciLz48L2c+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMS42NjM1IDAgMCAxLjY2MzUgMTUyLjI1IC02MC45MjIpIj48Y2lyY2xlIGN4PSIxLjk1MzMiIGN5PSIxMDIuNDUiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9IjMuNzgxNCIgY3k9IjEwOC41MiIgcj0iMi45MDY3Ii8+PGNpcmNsZSBjeD0iMS45OTk4IiBjeT0iMTA1Ljg4IiByPSIyLjkwNjciLz48Y2lyY2xlIGN4PSIxLjE4NDMiIGN5PSIxMDcuMDEiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9Ii01LjAwNTkiIGN5PSI5NS41NzYiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii00LjQyOTgiIGN5PSIxMDAuOTkiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii0zMS42NDYiIGN5PSI5NC4yMzIiIHI9IjYuODcxOCIvPjxjaXJjbGUgY3g9Ii0zMy45MzYiIGN5PSIxMDYuNDIiIHI9IjQuNjYzNiIvPjxjaXJjbGUgY3g9Ii0zMC4xNzgiIGN5PSIxMDYuMjMiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii0zNi45NDciIGN5PSIxMDQuNTIiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii00Ny44OCIgY3k9IjEwNS4zMSIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUwLjgyOSIgY3k9IjEwNC4zNyIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUxLjI1MSIgY3k9IjEwMC43NiIgcj0iNS41NDA4Ii8+PGNpcmNsZSBjeD0iLTUyLjQ0OCIgY3k9IjkzLjAxNiIgcj0iMS41NTQ2Ii8+PGNpcmNsZSBjeD0iLTQ5LjU5OSIgY3k9IjkyLjA0MSIgcj0iMS45NjkxIi8+PGVsbGlwc2UgY3g9Ii00NS43OTEiIGN5PSI5My4xMjIiIHJ4PSIzLjczNTYiIHJ5PSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItNDIuMzk2IiBjeT0iOTMuOTY3IiByPSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItMzguNzMiIGN5PSI5My42NjUiIHI9IjEuOTY5MSIvPjxjaXJjbGUgY3g9Ii0xMS43NTYiIGN5PSIxMDYuNTkiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xNC43MDUiIGN5PSIxMDUuNDYiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xOS45NTIiIGN5PSIxMDEuMTgiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0yNi44MjIiIGN5PSIxMDEuNSIgcj0iNC42MjMyIi8+PGNpcmNsZSBjeD0iLTEyLjA1IiBjeT0iODcuNzMxIiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNS45NzU4IiBjeT0iOTAuMTQ5IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNi45NjI4IiBjeT0iODguNzI1IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItMTQuODc0IiBjeT0iOTEuMjM3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMTcuMDY1IiBjeT0iOTMuNzc2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItNDMuNTQ0IiBjeT0iMTAzLjE3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjAuOTc4IiBjeT0iOTcuNTI1IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjUuNzQ3IiBjeT0iOTYuMTk2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItOS42MzA0IiBjeT0iODkuMzU2IiByPSIyLjIyMTQiLz48Y2lyY2xlIGN4PSItNTEuMTc1IiBjeT0iOTYuMzEyIiByPSIyLjIyMTQiLz48ZWxsaXBzZSBjeD0iMy42MzY2IiBjeT0iMTEyLjkzIiByeD0iMy4yOTc3IiByeT0iNy4yNjQ5Ii8+PHBhdGggZD0ibS0wLjI0ODI4IDEwNy4wOGMtMS41NWUtNiAyLjU1MzMtMS44MzE4IDAuMjMyMTUtNC4zODUyIDAuMjMyMTVzLTQuODYxMyAyLjMyMTItNC44NjEzLTAuMjMyMTVjLTRlLTYgLTIuNTUzMyAyLjA2OTktNC42MjMyIDQuNjIzMi00LjYyMzIgMi41NTMzIDAgNC42MjMyIDIuMDY5OSA0LjYyMzIgNC42MjMyeiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjQyMzUiLz48cGF0aCBkPSJtLTUwLjQ2IDkyLjcxLTEuNDQyNCAwLjQ0OTcyLTAuMDYxNzggMi42MjM0czAuOTA3NzMgMi44MzE2IDEuMDQyNSAzLjA2MDdjMC4xMzQ3NiAwLjIyOTEgMi42MDk0IDMuNDY4IDIuNjA5NCAzLjQ2OGw1LjIzODEgMC40OTM1NyAzLjcyMDMgMS4yNTE0IDMuNzY4IDAuMjE4NzFzNC44MTEyIDEuMjc1MSA1LjIzNzMgMC44MjI0N2MwLjQyNjA2LTAuNDUyNjYgMS40NDg4LTUuMDU0MiAxLjQxMzYtNS4zNTQ1LTAuMDM1MTYtMC4zMDAzNC0zLjM5NTctMS43NzQ1LTMuMzk1Ny0xLjc3NDVsLTMuODQwNS0yLjU0NzItMS42MjUtMS4yMTM0LTIuOTQ0Ni0wLjEwMDkycy0yLjc2MjctMC4zNTA3MS0zLjAzMTQtMC41MTY0NWMtMC4yNjg3Mi0wLjE2NTc1LTMuMTkxNC0wLjc2NTgtMy4zNDczLTAuNzY1OC0wLjE1NTg4IDAtMy4zNDA1LTAuMTE1My0zLjM0MDUtMC4xMTUzeiIvPjxwYXRoIGQ9Im0tMjAuMTk2IDk2LjUwNyAyLjkwNTQgNy4xMTYxIDQuOTYzNiAyLjIxMzUgNy4yMjgyLTAuMzU5MDkgNS4zOTc1IDAuNDAyODVzMS4xNDY1LTIuNDc2MyAxLjE2NjYtMi42Mzg1YzAuMDIwMTA4LTAuMTYyMjMtMi4yNDgzLTEuODA5OC0yLjI0ODMtMS44MDk4bC0xLjQ3OTgtMi4xNjU2LTAuMjEyNTItMi43NjQ5cy0xLjUxOTQtMi4zOTMzLTEuNTIyOC0yLjU1NTVjLTAuMDAzMzMtMC4xNjIxNy0yLjYyMjktNC4yNzMyLTIuNjIyOS00LjI3MzJsLTUuMjE1OS0wLjA2MjAzLTUuMTcyNCAzLjUyOTV6Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.54348" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5NC41NW1tIiBoZWlnaHQ9IjE5MS4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTQuNTUgMTkxLjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjk2MTggLTUzLjM3MikiPjxnPjxyZWN0IHg9IjMuOTYxOCIgeT0iMjE2Ljk4IiB3aWR0aD0iMTk0LjU1IiBoZWlnaHQ9IjI3LjcxOCIvPjxyZWN0IHg9IjEzNi4wNSIgeT0iOTAuNDc1IiB3aWR0aD0iNDEuOTcyIiBoZWlnaHQ9IjEzNS43NiIgcnk9IjQuODQwOCIvPjxyZWN0IHg9IjcxLjcxMiIgeT0iOTAuNDc1IiB3aWR0aD0iNDYuNjY5IiBoZWlnaHQ9IjEzNy45MiIgcnk9IjcuNzI5MSIvPjxyZWN0IHg9IjIzLjI4MiIgeT0iOTAuNDc1IiB3aWR0aD0iMjIuODIyIiBoZWlnaHQ9IjEzNS40NCIgcnk9IjUuMTgyOSIvPjwvZz48cGF0aCBkPSJtMTU4LjAyIDk0LjgxNWMxLjRlLTQgLTE3LjI2LTEzLjc5Ni0zMS4yNTMtMzAuODE1LTMxLjI1My0xNy4wMTktMS40MmUtNCAtMzAuODE1IDEzLjk5Mi0zMC44MTUgMzEuMjUzIDAuMDAyNCAwLjcwNzYyIDAuMDI4NDQgMS40MTUgMC4wNzgxNiAyLjEyMDgiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMy4yIiBzdHJva2Utd2lkdGg9IjIwLjM4MSIvPjxwYXRoIGQ9Im05Ni45MzggOTQuNzc2YzEuNGUtNCAtMTcuMjE0LTEzLjk1NS0zMS4xNjktMzEuMTY5LTMxLjE2OS0xNy4yMTQtMS40MWUtNCAtMzEuMTY5IDEzLjk1NS0zMS4xNjkgMzEuMTY5IDAuMDAyNCAwLjcwNTczIDAuMDI4NzcgMS40MTEyIDAuMDc5MDYgMi4xMTUxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuMiIgc3Ryb2tlLXdpZHRoPSIyMC40NyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.28779" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0NC43OG1tIiBoZWlnaHQ9Ijk1LjM2M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDQuNzggOTUuMzYzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNi43MjcgLTEwNi4yNykiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE3MS40NyAxMDYuMjd2OTUuMzYzIiBzdHJva2Utd2lkdGg9IjIwLjA3OSIvPjxwYXRoIGQ9Im0xNzEuNDcgMTk1LjQ5aC0xMjguNjF2LTQzLjcxNGwyMy4xNDQtMTQuMTQ5IDEwLjU5MiAxOS4yMjQgMjguNjg0LTE5LjcyNyAxMi42MTEgMjAuNTczIDMwLjU5OS0yMi41MSAxOC42ODggMzEuNTQiIHN0cm9rZS13aWR0aD0iMTIuMjY5Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43NG1tIiBoZWlnaHQ9IjEyMy4wN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzQgMTIzLjA3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40MDkgLTk1LjY1NCkiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGcgc3Ryb2tlLXdpZHRoPSI4LjgxMiI+PHBhdGggZD0ibTQ5LjgxNSAxNzAuOTN2NDMuMzg2aDI4LjYzOXYtMzMuNzg1aDIyLjM0NiIvPjxwYXRoIGQ9Im0xNTAuNjMgMTcwLjkzdjQzLjM4NmgtMjguNjM5di0zMy43ODVoLTIyLjM0NiIvPjxwYXRoIGQ9Im00OS44MTUgMTcwLjkzczguOTczOS0xNS41ODIgMTUuODI2LTIyLjQzNGM5LjM0NzQtOS4zNDc0IDIxLjk0LTE4LjMzMyAzNS4xNTktMTguMzQ2IDEzLjI3LTAuMDEzMSAyNS45NDYgOC45NjI4IDM1LjMyOSAxOC4zNDYgNi42MTk2IDYuNjE5NiAxNC40OTggMjIuNDM0IDE0LjQ5OCAyMi40MzQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Im0xNTAuNjMgMjE0LjMyaDI3LjkyMXYtODEuMzUyaC0zOC44NHYxNi4yMDgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz48L2c+PHBhdGggZD0ibTExOC4yMSAxMzQuMTF2LTEyLjU0M2gyMi40MTciIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS13aWR0aD0iNy41MTUiLz48cGF0aCBkPSJtMTc4LjQgMTMxLjQ3YzAtMTAuNjQzLTguNjI4Mi0xOS4yNzItMTkuMjcyLTE5LjI3MnMtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2Utd2lkdGg9IjkuNTA4Ii8+PHBhdGggZD0ibTE1Ni43NiAxMTYuODFjLTEuMDkxNS05LjQ3MTktOC42NDU0LTE2LjU0Ny0xOC40OC0xNi41NDctMTAuNjQzIDAtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuMjA4Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43OW1tIiBoZWlnaHQ9IjEyMy43OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzkgMTIzLjc5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS4zNTggLTkxLjgyNikiPjxnPjxyZWN0IHg9IjE1OC43OCIgeT0iOTEuODI2IiB3aWR0aD0iMTMuMjYyIiBoZWlnaHQ9Ijg2LjE3Ii8+PHJlY3QgeD0iMTM4LjA4IiB5PSI5MS44MjYiIHdpZHRoPSIxMy4yNjIiIGhlaWdodD0iODYuMTciLz48cmVjdCB4PSIxMTMuMTIiIHk9IjkxLjgyNiIgd2lkdGg9IjEzLjI2MiIgaGVpZ2h0PSI4Ni4xNyIvPjxwYXRoIGQ9Im00NS44ODggMTc1LjcxLTAuNTI5MTcgMC41MjkxNnYzOS4zNzRoMTM3Ljc5di0zOS45MDR6bTQuNjUxOSA1LjI1MDhoMjIuNzI5djYuODk3OGgtMjIuNzI5em0yNy45NzkgMGgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bTI3LjkzMiAwaDE5LjExOXY2Ljg5NzhoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3OGgtMjIuNzI5em0tNzYuNzE2IDExLjI1MmgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bS01Mi4zNDcgMC4zNjc5M2gyMi43Mjl2Ni44OTczaC0yMi43Mjl6bTgwLjI3OSAwaDE5LjExOXY2Ljg5NzNoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3M2gtMjIuNzI5eiIvPjxwYXRoIGQ9Im03MC40MTEgMTUxLjE4LTEyLjkxNCAxMi45MTQtMTIuMTM4IDEyLjEzOWgyNS4wNTN6Ii8+PHBhdGggZD0ibTk0LjkzNSAxNTEuMTgtMTIuOTE0IDEyLjkxNC0xMi4xMzggMTIuMTM5aDI1LjA1M3oiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzOS43N21tIiBoZWlnaHQ9IjEyNS42NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzkuNzcgMTI1LjY1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41ODcgLTgyLjMxMykiPjxnPjxjaXJjbGUgY3g9IjkzLjM3MiIgY3k9IjE5NS4wOCIgcj0iMTIuODgzIi8+PGNpcmNsZSBjeD0iMTM0Ljg2IiBjeT0iMTk1LjA4IiByPSIxMi44ODMiLz48cGF0aCBkPSJtNDEuNTg3IDEyMy44NWgxMzkuNzdsLTI2LjMzOSA1Ny43OTZoLTg3LjA3NHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOS41MDgiLz48Y2lyY2xlIGN4PSI4MS4wMzYiIGN5PSIxMjAuNTYiIHI9IjIwLjU2OCIvPjxjaXJjbGUgY3g9IjE0Mi41NSIgY3k9IjEyMC41NiIgcj0iMjAuNTY4Ii8+PHBhdGggZD0ibTExMS40NyA4Mi4zMTNhMjAuNTY4IDIwLjU2OCAwIDAgMC0yMC41NjggMjAuNTY4aDQxLjEzN2EyMC41NjggMjAuNTY4IDAgMCAwLTIwLjU2OC0yMC41Njh6Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5OS42NW1tIiBoZWlnaHQ9IjEzMS4yN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTkuNjUgMTMxLjI3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02LjY4NDcgLTk0LjExNykiPjxyZWN0IHg9IjE4NS4xNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjEuMTc2IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjEwMi4yNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjIuNTU3IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjExNC4zIiB5PSIyMTEuNDQiIHdpZHRoPSI3Ny4zMjUiIGhlaWdodD0iOS42MjExIi8+PHJlY3QgeD0iMTM4LjU5IiB5PSIxOTUuNjYiIHdpZHRoPSIzMS44ODMiIGhlaWdodD0iMTcuODMyIi8+PHJlY3QgeD0iMTEzLjMxIiB5PSIxNDguNTYiIHdpZHRoPSI5My4wMjEiIGhlaWdodD0iNTEuNjA3Ii8+PHJlY3QgeD0iMTY5LjQ2IiB5PSIxMzkuODQiIHdpZHRoPSIzNi44NzQiIGhlaWdodD0iMTcuNDQyIi8+PHBhdGggZD0ibTExOC4zMyAxMzAuODN2MjQuNTM3aDI0Ljk2MXYtMjQuNTM3em02LjI3MiA2LjI3ODJoOC43OTMzdjExLjQ0OWgtOC43OTMzeiIvPjxwYXRoIGQ9Im0xMjAuMyAxNDQuNzhoLTEwLjg0NmwtMTMuNjAxLTE2LjE5MyAyLjIyODktMy40NDg3aDEwLjAyOGwzLjgwOTctMy42NDM5LTAuMjIyMDctMi40ODQ2IDcuMDQ0Ni01LjcxMTggMi4xMDcyIDIuMzEzMyAyLjIxMjktMC43NTE1OHYtOC4xMTJsLTIuMTM0OC0xLjkzODQtMy4xMTA4IDAuMzI4NDV2LTQuNDQ0M2wtMi4xODc1LTMuMjE3NmgtNi4yNTE1bC0yMi4zNDYgMjQuMzczaC04LjQ2ODJsLTI3LjczNS0yNy43MjloLTkuNDhsLTQuMzY1NCA1Ljg1ODkgMjkuMTA5IDI5LjY1N2g1LjI3MThsMi4xOTYyIDIuMTYydjIuOTcwNGwtMi40MTU1IDIuMTI3OWgtOS4zMzc2bC0yMS4zOTggMjEuMjEyaC0xOS45MzRsLTEzLjc5MSAyMi41Nzl2My45MjA4aDMyLjU3OHYtNC43MTQxaDcuMTM2MnYtMTcuNDgzbDI3LjY0NC0yMC40MjdoMTIuOTAybDI5LjIxNiAyNC4xNDl6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5NC41NW1tIiBoZWlnaHQ9IjE5MS4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTQuNTUgMTkxLjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjk2MTggLTUzLjM3MikiPjxnPjxyZWN0IHg9IjMuOTYxOCIgeT0iMjE2Ljk4IiB3aWR0aD0iMTk0LjU1IiBoZWlnaHQ9IjI3LjcxOCIvPjxyZWN0IHg9IjEzNi4wNSIgeT0iOTAuNDc1IiB3aWR0aD0iNDEuOTcyIiBoZWlnaHQ9IjEzNS43NiIgcnk9IjQuODQwOCIvPjxyZWN0IHg9IjcxLjcxMiIgeT0iOTAuNDc1IiB3aWR0aD0iNDYuNjY5IiBoZWlnaHQ9IjEzNy45MiIgcnk9IjcuNzI5MSIvPjxyZWN0IHg9IjIzLjI4MiIgeT0iOTAuNDc1IiB3aWR0aD0iMjIuODIyIiBoZWlnaHQ9IjEzNS40NCIgcnk9IjUuMTgyOSIvPjwvZz48cGF0aCBkPSJtMTU4LjAyIDk0LjgxNWMxLjRlLTQgLTE3LjI2LTEzLjc5Ni0zMS4yNTMtMzAuODE1LTMxLjI1My0xNy4wMTktMS40MmUtNCAtMzAuODE1IDEzLjk5Mi0zMC44MTUgMzEuMjUzIDAuMDAyNCAwLjcwNzYyIDAuMDI4NDQgMS40MTUgMC4wNzgxNiAyLjEyMDgiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMy4yIiBzdHJva2Utd2lkdGg9IjIwLjM4MSIvPjxwYXRoIGQ9Im05Ni45MzggOTQuNzc2YzEuNGUtNCAtMTcuMjE0LTEzLjk1NS0zMS4xNjktMzEuMTY5LTMxLjE2OS0xNy4yMTQtMS40MWUtNCAtMzEuMTY5IDEzLjk1NS0zMS4xNjkgMzEuMTY5IDAuMDAyNCAwLjcwNTczIDAuMDI4NzcgMS40MTEyIDAuMDc5MDYgMi4xMTUxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuMiIgc3Ryb2tlLXdpZHRoPSIyMC40NyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.28779" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4MC42OG1tIiBoZWlnaHQ9IjE4Ni40N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODAuNjggMTg2LjQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05Ljg2NjQgLTU1LjgzNikiPjxyZWN0IHg9IjE4LjUzNyIgeT0iMTc1LjExIiB3aWR0aD0iMTM2LjY0IiBoZWlnaHQ9IjY3LjE5MyIgcnk9IjAiLz48cmVjdCB4PSIxNjQuMzUiIHk9IjEyOS4yNCIgd2lkdGg9IjI2LjE4OSIgaGVpZ2h0PSIxMTMuMDYiIHJ5PSIwIi8+PGNpcmNsZSBjeD0iMTcyLjYzIiBjeT0iMTA2LjMzIiByPSIxMi44MDEiLz48Y2lyY2xlIGN4PSIxNjUuNzIiIGN5PSI5Ny4zMzMiIHI9IjEyLjgwMSIvPjxjaXJjbGUgY3g9IjE0OC42NyIgY3k9IjEwNy4xMyIgcj0iOS4xMzM1Ii8+PGNpcmNsZSBjeD0iMTM3LjMzIiBjeT0iMTA0LjY4IiByPSI5LjEzMzUiLz48Y2lyY2xlIGN4PSIxNDkuNjYiIGN5PSI4NC4wODEiIHI9IjE0LjYxNyIvPjxjaXJjbGUgY3g9IjExNC42MSIgY3k9IjEwMi42MiIgcj0iMTMuMzc4Ii8+PGNpcmNsZSBjeD0iMTI5LjQiIGN5PSI4MC43OTciIHI9IjguODg1NSIvPjxjaXJjbGUgY3g9IjExOC4zNiIgY3k9IjY3LjQ5NCIgcj0iMTEuNjU4Ii8+PGNpcmNsZSBjeD0iOTcuODAxIiBjeT0iODYuNTA0IiByPSIxMy4wMDUiLz48Y2lyY2xlIGN4PSI5Mi44MDIiIGN5PSI4MC45NzEiIHI9IjEzLjAwNSIvPjxjaXJjbGUgY3g9IjkzLjY5OSIgY3k9IjYzLjc4NSIgcj0iNy4yNjI0Ii8+PGNpcmNsZSBjeD0iMTAwLjU5IiBjeT0iNjcuNjY2IiByPSI3LjI2MjQiLz48Y2lyY2xlIGN4PSIxMjguOTYiIGN5PSI5OS45NDYiIHI9IjcuMjYyNCIvPjxyZWN0IHg9IjEwMC43NCIgeT0iNjguNDg3IiB3aWR0aD0iMjEuNjAxIiBoZWlnaHQ9IjI0LjYzNCIvPjxyZWN0IHg9IjExOS45MyIgeT0iODMuMTkiIHdpZHRoPSIzNC41OSIgaGVpZ2h0PSIxNy4yNTUiLz48Y2lyY2xlIGN4PSI2MC40MjQiIGN5PSI4Mi44MTkiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjU3LjExMyIgY3k9Ijk3Ljc2MyIgcj0iMTUuMjE3Ii8+PGNpcmNsZSBjeD0iMzcuODI2IiBjeT0iMTAxLjc2IiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSIyNS4wODMiIGN5PSI4MC44MDgiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjMyLjU4OCIgY3k9Ijk0LjcyIiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSI0Mi45NjciIGN5PSI4OS40MjMiIHI9IjE1LjIxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3OC4xM21tIiBoZWlnaHQ9IjExNy45NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzguMTMgMTE3Ljk0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTIzLjg2NSkiPjxwYXRoIGQ9Im0yMy43NzEgMjMuODY1djYyLjQ3M2gtMC4wMDIxYzEuMDllLTQgMC4wMjc2MSAwLjAwMjEgMC4wNTQ4MSAwLjAwMjEgMC4wODI1djIzLjI1MWMwIDEyLjE2LTEwLjU5IDIxLjk1Ny0yMy43NzEgMjIuMDI2djEwLjEwNGg5NS42OTl2LTEwLjEwNGMtMTMuMTgyLTAuMDY5MS0yMy43NzEtOS44NjYtMjMuNzcxLTIyLjAyNnYtMjMuMjUxYzAtMC4wMjc3IDJlLTMgLTAuMDU0ODkgMC4wMDIxLTAuMDgyNWgtMC4wMDIxdi02Mi40NzN6Ii8+PHBhdGggZD0ibTEyMS43NCA0OS4wM3Y0OS4xNDNoLTJlLTNjOGUtNSAwLjAyMTcgMmUtMyAwLjA0MzA2IDJlLTMgMC4wNjQ5MnYxOC4yODljMCA5LjU2NTctOC4zMDI3IDE3LjI3Mi0xOC42MzggMTcuMzI3djcuOTQ4NGg3NS4wMzJ2LTcuOTQ4NGMtMTAuMzM1LTAuMDU0My0xOC42MzgtNy43NjA5LTE4LjYzOC0xNy4zMjd2LTE4LjI4OWMwLTAuMDIxNzggMmUtMyAtMC4wNDMxNCAyZS0zIC0wLjA2NDkyaC0yZS0zdi00OS4xNDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0.40000000000000002" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS4zbW0iIGhlaWdodD0iMTM5Ljk0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OS4zIDEzOS45NCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzIuMjYzIC03Ni44ODQpIj48Y2lyY2xlIGN4PSI3OS40OTEiIGN5PSIxOTUuOTgiIHI9IjE2Ljg1IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48Y2lyY2xlIGN4PSIxNTQuOCIgY3k9IjE5NS45OCIgcj0iMTYuODUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3Ljk4MTUiLz48Zz48cmVjdCB4PSIxMDMuMzUiIHk9IjE4Mi42MiIgd2lkdGg9IjI1LjU0OSIgaGVpZ2h0PSIxNi4yMjIiLz48cGF0aCBkPSJtMzIuMjYzIDE0OS4wOHY0Mi43OThoMjEuOTlhMjQuODI3IDI0LjgyNyAwIDAgMSAyMC4wMzMtMjAuNTk2di0yMi4yMDN6bTQuNzY1MSA1LjAwMjhoMTcuNjI3djIwLjEzM2gtMTcuNjI3eiIvPjxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDQwLjE1MykiIGQ9Im0xNDUuMDcgNi43OTExLTMuOWUtNCA0MS4yOSA2NS4wMzktMi42ZS01IDI5LjM2Ny0yNC43NzYgMi45ZS00IC0xNi41MTR6Ii8+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoMzkuODQ5KSIgZD0ibTE3MS4wMSA0My41NTUtMi45ZS00IDUuNDU3MSA0LjQyMDMgMmUtNSAyZS01IDI1LjQ5IDExLjgwNS0yLjI1ZS00IDIuM2UtNCAtMjUuNDI4IDUuMTA3OCAzLjU4ZS00IDVlLTUgLTUuNTE5NXoiLz48cGF0aCBkPSJtMTcxLjEgMTUzLjIzLTEyLjk1MiAxOC45OTloOS44NjI0bDguNTU0NSAxMC45OTIgNS4wMDE4IDAuMzM2OTN2LTE5Ljc5NWwtMi45MDczLTQuMTU2M3oiLz48cGF0aCBkPSJtMTEzLjAyIDEwNC4yNC02LjUyMjctNS41MDI5LTIzLjEzMi0xOS45MDUtOC41MjY2LTEuOTQ2NiAwLjA1MzA4OSA4LjIyMDcgMjUuNjIxIDIwLjcyNSA0LjQ4MzUgNS4xNzQyeiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4MC42OG1tIiBoZWlnaHQ9IjE4Ni40N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODAuNjggMTg2LjQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05Ljg2NjQgLTU1LjgzNikiPjxyZWN0IHg9IjE4LjUzNyIgeT0iMTc1LjExIiB3aWR0aD0iMTM2LjY0IiBoZWlnaHQ9IjY3LjE5MyIgcnk9IjAiLz48cmVjdCB4PSIxNjQuMzUiIHk9IjEyOS4yNCIgd2lkdGg9IjI2LjE4OSIgaGVpZ2h0PSIxMTMuMDYiIHJ5PSIwIi8+PGNpcmNsZSBjeD0iMTcyLjYzIiBjeT0iMTA2LjMzIiByPSIxMi44MDEiLz48Y2lyY2xlIGN4PSIxNjUuNzIiIGN5PSI5Ny4zMzMiIHI9IjEyLjgwMSIvPjxjaXJjbGUgY3g9IjE0OC42NyIgY3k9IjEwNy4xMyIgcj0iOS4xMzM1Ii8+PGNpcmNsZSBjeD0iMTM3LjMzIiBjeT0iMTA0LjY4IiByPSI5LjEzMzUiLz48Y2lyY2xlIGN4PSIxNDkuNjYiIGN5PSI4NC4wODEiIHI9IjE0LjYxNyIvPjxjaXJjbGUgY3g9IjExNC42MSIgY3k9IjEwMi42MiIgcj0iMTMuMzc4Ii8+PGNpcmNsZSBjeD0iMTI5LjQiIGN5PSI4MC43OTciIHI9IjguODg1NSIvPjxjaXJjbGUgY3g9IjExOC4zNiIgY3k9IjY3LjQ5NCIgcj0iMTEuNjU4Ii8+PGNpcmNsZSBjeD0iOTcuODAxIiBjeT0iODYuNTA0IiByPSIxMy4wMDUiLz48Y2lyY2xlIGN4PSI5Mi44MDIiIGN5PSI4MC45NzEiIHI9IjEzLjAwNSIvPjxjaXJjbGUgY3g9IjkzLjY5OSIgY3k9IjYzLjc4NSIgcj0iNy4yNjI0Ii8+PGNpcmNsZSBjeD0iMTAwLjU5IiBjeT0iNjcuNjY2IiByPSI3LjI2MjQiLz48Y2lyY2xlIGN4PSIxMjguOTYiIGN5PSI5OS45NDYiIHI9IjcuMjYyNCIvPjxyZWN0IHg9IjEwMC43NCIgeT0iNjguNDg3IiB3aWR0aD0iMjEuNjAxIiBoZWlnaHQ9IjI0LjYzNCIvPjxyZWN0IHg9IjExOS45MyIgeT0iODMuMTkiIHdpZHRoPSIzNC41OSIgaGVpZ2h0PSIxNy4yNTUiLz48Y2lyY2xlIGN4PSI2MC40MjQiIGN5PSI4Mi44MTkiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjU3LjExMyIgY3k9Ijk3Ljc2MyIgcj0iMTUuMjE3Ii8+PGNpcmNsZSBjeD0iMzcuODI2IiBjeT0iMTAxLjc2IiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSIyNS4wODMiIGN5PSI4MC44MDgiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjMyLjU4OCIgY3k9Ijk0LjcyIiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSI0Mi45NjciIGN5PSI4OS40MjMiIHI9IjE1LjIxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzMi4xNm1tIiBoZWlnaHQ9IjEyMy44Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzIuMTYgMTIzLjg2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4yMTkgLTkxLjcyMSkiPjxnPjxyZWN0IHg9IjE2MS45NyIgeT0iOTEuNzIxIiB3aWR0aD0iMTYuNDEiIGhlaWdodD0iMTIzLjg2Ii8+PHJlY3QgeD0iNDYuMjIiIHk9IjE2OC4yNSIgd2lkdGg9IjEzMi4xNiIgaGVpZ2h0PSI0Ny4zMjgiLz48cmVjdCB4PSIxNDAuMDQiIHk9IjkxLjcyMSIgd2lkdGg9IjE2LjQxIiBoZWlnaHQ9IjEyMy44NiIvPjxwYXRoIGQ9Im03NS42NDkgMTM4LjczLTI5LjQyOSAyOS40Mjl2MTMuOTU5aDI5LjQyOXoiLz48cGF0aCBkPSJtMTA1LjA4IDEzOC43My0yOS40MjkgMjkuNDI5djEzLjk1OWgyOS40Mjl6Ii8+PHBhdGggZD0ibTEzNC41MSAxMzguNzMtMjkuNDI5IDI5LjQyOXYxMy45NTloMjkuNDI5eiIvPjxyZWN0IHg9IjQ2LjIxOSIgeT0iMTY4LjI1IiB3aWR0aD0iMTMyLjE2IiBoZWlnaHQ9IjEzLjc2OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNi4zM21tIiBoZWlnaHQ9IjEzOC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTYuMzMgMTM4LjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NS4wNSAtODEuMjY0KSI+PGc+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iMTQ4LjM2IiB5PSIxMjYuNDUiIHdpZHRoPSIyMy4wMTUiIGhlaWdodD0iOTMuMDgxIiBzdHJva2Utd2lkdGg9IjcuNTQ3NCIvPjxyZWN0IHg9IjU1LjA1IiB5PSIxODUuNDkiIHdpZHRoPSIxMTYuMzMiIGhlaWdodD0iMzQuMDQxIiBzdHJva2Utd2lkdGg9IjcuOTgyIi8+PHBhdGggZD0ibTEwMC42NCAxNDguMjcgMWUtNSAxMy40NzUgNjIuNzI5IDIyLjIyMiA0LjI0MTYtMTEuOTcyeiIgc3Ryb2tlLXdpZHRoPSI3Ljk4MiIvPjxwYXRoIGQ9Im01NS4wNSAxNTEuMzQtNGUtNiAxNS4zNTYgNzguMjY1IDI4LjIyNiAxMC42ODQtMTEuNTAzeiIgc3Ryb2tlLXdpZHRoPSIxMi43OTkiLz48cmVjdCB4PSIxMzguNDIiIHk9IjE4Mi43MSIgd2lkdGg9IjEzLjY5MyIgaGVpZ2h0PSI0LjE5NzMiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48cGF0aCBkPSJtNTUuMDUgMTcxLjM0IDVlLTYgMjEuMjkxIDMzLjk2IDEyLjQ5MSA2Ljg5NzItMTguNzUzeiIgc3Ryb2tlLXdpZHRoPSI4Ljk0NjciLz48L2c+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMS42NjM1IDAgMCAxLjY2MzUgMTUyLjI1IC02MC45MjIpIj48Y2lyY2xlIGN4PSIxLjk1MzMiIGN5PSIxMDIuNDUiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9IjMuNzgxNCIgY3k9IjEwOC41MiIgcj0iMi45MDY3Ii8+PGNpcmNsZSBjeD0iMS45OTk4IiBjeT0iMTA1Ljg4IiByPSIyLjkwNjciLz48Y2lyY2xlIGN4PSIxLjE4NDMiIGN5PSIxMDcuMDEiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9Ii01LjAwNTkiIGN5PSI5NS41NzYiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii00LjQyOTgiIGN5PSIxMDAuOTkiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii0zMS42NDYiIGN5PSI5NC4yMzIiIHI9IjYuODcxOCIvPjxjaXJjbGUgY3g9Ii0zMy45MzYiIGN5PSIxMDYuNDIiIHI9IjQuNjYzNiIvPjxjaXJjbGUgY3g9Ii0zMC4xNzgiIGN5PSIxMDYuMjMiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii0zNi45NDciIGN5PSIxMDQuNTIiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii00Ny44OCIgY3k9IjEwNS4zMSIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUwLjgyOSIgY3k9IjEwNC4zNyIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUxLjI1MSIgY3k9IjEwMC43NiIgcj0iNS41NDA4Ii8+PGNpcmNsZSBjeD0iLTUyLjQ0OCIgY3k9IjkzLjAxNiIgcj0iMS41NTQ2Ii8+PGNpcmNsZSBjeD0iLTQ5LjU5OSIgY3k9IjkyLjA0MSIgcj0iMS45NjkxIi8+PGVsbGlwc2UgY3g9Ii00NS43OTEiIGN5PSI5My4xMjIiIHJ4PSIzLjczNTYiIHJ5PSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItNDIuMzk2IiBjeT0iOTMuOTY3IiByPSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItMzguNzMiIGN5PSI5My42NjUiIHI9IjEuOTY5MSIvPjxjaXJjbGUgY3g9Ii0xMS43NTYiIGN5PSIxMDYuNTkiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xNC43MDUiIGN5PSIxMDUuNDYiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xOS45NTIiIGN5PSIxMDEuMTgiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0yNi44MjIiIGN5PSIxMDEuNSIgcj0iNC42MjMyIi8+PGNpcmNsZSBjeD0iLTEyLjA1IiBjeT0iODcuNzMxIiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNS45NzU4IiBjeT0iOTAuMTQ5IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNi45NjI4IiBjeT0iODguNzI1IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItMTQuODc0IiBjeT0iOTEuMjM3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMTcuMDY1IiBjeT0iOTMuNzc2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItNDMuNTQ0IiBjeT0iMTAzLjE3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjAuOTc4IiBjeT0iOTcuNTI1IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjUuNzQ3IiBjeT0iOTYuMTk2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItOS42MzA0IiBjeT0iODkuMzU2IiByPSIyLjIyMTQiLz48Y2lyY2xlIGN4PSItNTEuMTc1IiBjeT0iOTYuMzEyIiByPSIyLjIyMTQiLz48ZWxsaXBzZSBjeD0iMy42MzY2IiBjeT0iMTEyLjkzIiByeD0iMy4yOTc3IiByeT0iNy4yNjQ5Ii8+PHBhdGggZD0ibS0wLjI0ODI4IDEwNy4wOGMtMS41NWUtNiAyLjU1MzMtMS44MzE4IDAuMjMyMTUtNC4zODUyIDAuMjMyMTVzLTQuODYxMyAyLjMyMTItNC44NjEzLTAuMjMyMTVjLTRlLTYgLTIuNTUzMyAyLjA2OTktNC42MjMyIDQuNjIzMi00LjYyMzIgMi41NTMzIDAgNC42MjMyIDIuMDY5OSA0LjYyMzIgNC42MjMyeiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjQyMzUiLz48cGF0aCBkPSJtLTUwLjQ2IDkyLjcxLTEuNDQyNCAwLjQ0OTcyLTAuMDYxNzggMi42MjM0czAuOTA3NzMgMi44MzE2IDEuMDQyNSAzLjA2MDdjMC4xMzQ3NiAwLjIyOTEgMi42MDk0IDMuNDY4IDIuNjA5NCAzLjQ2OGw1LjIzODEgMC40OTM1NyAzLjcyMDMgMS4yNTE0IDMuNzY4IDAuMjE4NzFzNC44MTEyIDEuMjc1MSA1LjIzNzMgMC44MjI0N2MwLjQyNjA2LTAuNDUyNjYgMS40NDg4LTUuMDU0MiAxLjQxMzYtNS4zNTQ1LTAuMDM1MTYtMC4zMDAzNC0zLjM5NTctMS43NzQ1LTMuMzk1Ny0xLjc3NDVsLTMuODQwNS0yLjU0NzItMS42MjUtMS4yMTM0LTIuOTQ0Ni0wLjEwMDkycy0yLjc2MjctMC4zNTA3MS0zLjAzMTQtMC41MTY0NWMtMC4yNjg3Mi0wLjE2NTc1LTMuMTkxNC0wLjc2NTgtMy4zNDczLTAuNzY1OC0wLjE1NTg4IDAtMy4zNDA1LTAuMTE1My0zLjM0MDUtMC4xMTUzeiIvPjxwYXRoIGQ9Im0tMjAuMTk2IDk2LjUwNyAyLjkwNTQgNy4xMTYxIDQuOTYzNiAyLjIxMzUgNy4yMjgyLTAuMzU5MDkgNS4zOTc1IDAuNDAyODVzMS4xNDY1LTIuNDc2MyAxLjE2NjYtMi42Mzg1YzAuMDIwMTA4LTAuMTYyMjMtMi4yNDgzLTEuODA5OC0yLjI0ODMtMS44MDk4bC0xLjQ3OTgtMi4xNjU2LTAuMjEyNTItMi43NjQ5cy0xLjUxOTQtMi4zOTMzLTEuNTIyOC0yLjU1NTVjLTAuMDAzMzMtMC4xNjIxNy0yLjYyMjktNC4yNzMyLTIuNjIyOS00LjI3MzJsLTUuMjE1OS0wLjA2MjAzLTUuMTcyNCAzLjUyOTV6Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.54348" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0NC43OG1tIiBoZWlnaHQ9Ijk1LjM2M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDQuNzggOTUuMzYzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNi43MjcgLTEwNi4yNykiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE3MS40NyAxMDYuMjd2OTUuMzYzIiBzdHJva2Utd2lkdGg9IjIwLjA3OSIvPjxwYXRoIGQ9Im0xNzEuNDcgMTk1LjQ5aC0xMjguNjF2LTQzLjcxNGwyMy4xNDQtMTQuMTQ5IDEwLjU5MiAxOS4yMjQgMjguNjg0LTE5LjcyNyAxMi42MTEgMjAuNTczIDMwLjU5OS0yMi41MSAxOC42ODggMzEuNTQiIHN0cm9rZS13aWR0aD0iMTIuMjY5Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43NG1tIiBoZWlnaHQ9IjEyMy4wN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzQgMTIzLjA3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40MDkgLTk1LjY1NCkiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGcgc3Ryb2tlLXdpZHRoPSI4LjgxMiI+PHBhdGggZD0ibTQ5LjgxNSAxNzAuOTN2NDMuMzg2aDI4LjYzOXYtMzMuNzg1aDIyLjM0NiIvPjxwYXRoIGQ9Im0xNTAuNjMgMTcwLjkzdjQzLjM4NmgtMjguNjM5di0zMy43ODVoLTIyLjM0NiIvPjxwYXRoIGQ9Im00OS44MTUgMTcwLjkzczguOTczOS0xNS41ODIgMTUuODI2LTIyLjQzNGM5LjM0NzQtOS4zNDc0IDIxLjk0LTE4LjMzMyAzNS4xNTktMTguMzQ2IDEzLjI3LTAuMDEzMSAyNS45NDYgOC45NjI4IDM1LjMyOSAxOC4zNDYgNi42MTk2IDYuNjE5NiAxNC40OTggMjIuNDM0IDE0LjQ5OCAyMi40MzQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Im0xNTAuNjMgMjE0LjMyaDI3LjkyMXYtODEuMzUyaC0zOC44NHYxNi4yMDgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz48L2c+PHBhdGggZD0ibTExOC4yMSAxMzQuMTF2LTEyLjU0M2gyMi40MTciIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS13aWR0aD0iNy41MTUiLz48cGF0aCBkPSJtMTc4LjQgMTMxLjQ3YzAtMTAuNjQzLTguNjI4Mi0xOS4yNzItMTkuMjcyLTE5LjI3MnMtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2Utd2lkdGg9IjkuNTA4Ii8+PHBhdGggZD0ibTE1Ni43NiAxMTYuODFjLTEuMDkxNS05LjQ3MTktOC42NDU0LTE2LjU0Ny0xOC40OC0xNi41NDctMTAuNjQzIDAtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuMjA4Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43OW1tIiBoZWlnaHQ9IjEyMy43OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzkgMTIzLjc5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS4zNTggLTkxLjgyNikiPjxnPjxyZWN0IHg9IjE1OC43OCIgeT0iOTEuODI2IiB3aWR0aD0iMTMuMjYyIiBoZWlnaHQ9Ijg2LjE3Ii8+PHJlY3QgeD0iMTM4LjA4IiB5PSI5MS44MjYiIHdpZHRoPSIxMy4yNjIiIGhlaWdodD0iODYuMTciLz48cmVjdCB4PSIxMTMuMTIiIHk9IjkxLjgyNiIgd2lkdGg9IjEzLjI2MiIgaGVpZ2h0PSI4Ni4xNyIvPjxwYXRoIGQ9Im00NS44ODggMTc1LjcxLTAuNTI5MTcgMC41MjkxNnYzOS4zNzRoMTM3Ljc5di0zOS45MDR6bTQuNjUxOSA1LjI1MDhoMjIuNzI5djYuODk3OGgtMjIuNzI5em0yNy45NzkgMGgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bTI3LjkzMiAwaDE5LjExOXY2Ljg5NzhoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3OGgtMjIuNzI5em0tNzYuNzE2IDExLjI1MmgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bS01Mi4zNDcgMC4zNjc5M2gyMi43Mjl2Ni44OTczaC0yMi43Mjl6bTgwLjI3OSAwaDE5LjExOXY2Ljg5NzNoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3M2gtMjIuNzI5eiIvPjxwYXRoIGQ9Im03MC40MTEgMTUxLjE4LTEyLjkxNCAxMi45MTQtMTIuMTM4IDEyLjEzOWgyNS4wNTN6Ii8+PHBhdGggZD0ibTk0LjkzNSAxNTEuMTgtMTIuOTE0IDEyLjkxNC0xMi4xMzggMTIuMTM5aDI1LjA1M3oiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzOS43N21tIiBoZWlnaHQ9IjEyNS42NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzkuNzcgMTI1LjY1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41ODcgLTgyLjMxMykiPjxnPjxjaXJjbGUgY3g9IjkzLjM3MiIgY3k9IjE5NS4wOCIgcj0iMTIuODgzIi8+PGNpcmNsZSBjeD0iMTM0Ljg2IiBjeT0iMTk1LjA4IiByPSIxMi44ODMiLz48cGF0aCBkPSJtNDEuNTg3IDEyMy44NWgxMzkuNzdsLTI2LjMzOSA1Ny43OTZoLTg3LjA3NHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOS41MDgiLz48Y2lyY2xlIGN4PSI4MS4wMzYiIGN5PSIxMjAuNTYiIHI9IjIwLjU2OCIvPjxjaXJjbGUgY3g9IjE0Mi41NSIgY3k9IjEyMC41NiIgcj0iMjAuNTY4Ii8+PHBhdGggZD0ibTExMS40NyA4Mi4zMTNhMjAuNTY4IDIwLjU2OCAwIDAgMC0yMC41NjggMjAuNTY4aDQxLjEzN2EyMC41NjggMjAuNTY4IDAgMCAwLTIwLjU2OC0yMC41Njh6Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="36" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="37" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5OS42NW1tIiBoZWlnaHQ9IjEzMS4yN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTkuNjUgMTMxLjI3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02LjY4NDcgLTk0LjExNykiPjxyZWN0IHg9IjE4NS4xNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjEuMTc2IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjEwMi4yNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjIuNTU3IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjExNC4zIiB5PSIyMTEuNDQiIHdpZHRoPSI3Ny4zMjUiIGhlaWdodD0iOS42MjExIi8+PHJlY3QgeD0iMTM4LjU5IiB5PSIxOTUuNjYiIHdpZHRoPSIzMS44ODMiIGhlaWdodD0iMTcuODMyIi8+PHJlY3QgeD0iMTEzLjMxIiB5PSIxNDguNTYiIHdpZHRoPSI5My4wMjEiIGhlaWdodD0iNTEuNjA3Ii8+PHJlY3QgeD0iMTY5LjQ2IiB5PSIxMzkuODQiIHdpZHRoPSIzNi44NzQiIGhlaWdodD0iMTcuNDQyIi8+PHBhdGggZD0ibTExOC4zMyAxMzAuODN2MjQuNTM3aDI0Ljk2MXYtMjQuNTM3em02LjI3MiA2LjI3ODJoOC43OTMzdjExLjQ0OWgtOC43OTMzeiIvPjxwYXRoIGQ9Im0xMjAuMyAxNDQuNzhoLTEwLjg0NmwtMTMuNjAxLTE2LjE5MyAyLjIyODktMy40NDg3aDEwLjAyOGwzLjgwOTctMy42NDM5LTAuMjIyMDctMi40ODQ2IDcuMDQ0Ni01LjcxMTggMi4xMDcyIDIuMzEzMyAyLjIxMjktMC43NTE1OHYtOC4xMTJsLTIuMTM0OC0xLjkzODQtMy4xMTA4IDAuMzI4NDV2LTQuNDQ0M2wtMi4xODc1LTMuMjE3NmgtNi4yNTE1bC0yMi4zNDYgMjQuMzczaC04LjQ2ODJsLTI3LjczNS0yNy43MjloLTkuNDhsLTQuMzY1NCA1Ljg1ODkgMjkuMTA5IDI5LjY1N2g1LjI3MThsMi4xOTYyIDIuMTYydjIuOTcwNGwtMi40MTU1IDIuMTI3OWgtOS4zMzc2bC0yMS4zOTggMjEuMjEyaC0xOS45MzRsLTEzLjc5MSAyMi41Nzl2My45MjA4aDMyLjU3OHYtNC43MTQxaDcuMTM2MnYtMTcuNDgzbDI3LjY0NC0yMC40MjdoMTIuOTAybDI5LjIxNiAyNC4xNDl6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="38" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5NC41NW1tIiBoZWlnaHQ9IjE5MS4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTQuNTUgMTkxLjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjk2MTggLTUzLjM3MikiPjxnPjxyZWN0IHg9IjMuOTYxOCIgeT0iMjE2Ljk4IiB3aWR0aD0iMTk0LjU1IiBoZWlnaHQ9IjI3LjcxOCIvPjxyZWN0IHg9IjEzNi4wNSIgeT0iOTAuNDc1IiB3aWR0aD0iNDEuOTcyIiBoZWlnaHQ9IjEzNS43NiIgcnk9IjQuODQwOCIvPjxyZWN0IHg9IjcxLjcxMiIgeT0iOTAuNDc1IiB3aWR0aD0iNDYuNjY5IiBoZWlnaHQ9IjEzNy45MiIgcnk9IjcuNzI5MSIvPjxyZWN0IHg9IjIzLjI4MiIgeT0iOTAuNDc1IiB3aWR0aD0iMjIuODIyIiBoZWlnaHQ9IjEzNS40NCIgcnk9IjUuMTgyOSIvPjwvZz48cGF0aCBkPSJtMTU4LjAyIDk0LjgxNWMxLjRlLTQgLTE3LjI2LTEzLjc5Ni0zMS4yNTMtMzAuODE1LTMxLjI1My0xNy4wMTktMS40MmUtNCAtMzAuODE1IDEzLjk5Mi0zMC44MTUgMzEuMjUzIDAuMDAyNCAwLjcwNzYyIDAuMDI4NDQgMS40MTUgMC4wNzgxNiAyLjEyMDgiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMy4yIiBzdHJva2Utd2lkdGg9IjIwLjM4MSIvPjxwYXRoIGQ9Im05Ni45MzggOTQuNzc2YzEuNGUtNCAtMTcuMjE0LTEzLjk1NS0zMS4xNjktMzEuMTY5LTMxLjE2OS0xNy4yMTQtMS40MWUtNCAtMzEuMTY5IDEzLjk1NS0zMS4xNjkgMzEuMTY5IDAuMDAyNCAwLjcwNTczIDAuMDI4NzcgMS40MTEyIDAuMDc5MDYgMi4xMTUxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuMiIgc3Ryb2tlLXdpZHRoPSIyMC40NyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.28779" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="39" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4MC42OG1tIiBoZWlnaHQ9IjE4Ni40N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODAuNjggMTg2LjQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05Ljg2NjQgLTU1LjgzNikiPjxyZWN0IHg9IjE4LjUzNyIgeT0iMTc1LjExIiB3aWR0aD0iMTM2LjY0IiBoZWlnaHQ9IjY3LjE5MyIgcnk9IjAiLz48cmVjdCB4PSIxNjQuMzUiIHk9IjEyOS4yNCIgd2lkdGg9IjI2LjE4OSIgaGVpZ2h0PSIxMTMuMDYiIHJ5PSIwIi8+PGNpcmNsZSBjeD0iMTcyLjYzIiBjeT0iMTA2LjMzIiByPSIxMi44MDEiLz48Y2lyY2xlIGN4PSIxNjUuNzIiIGN5PSI5Ny4zMzMiIHI9IjEyLjgwMSIvPjxjaXJjbGUgY3g9IjE0OC42NyIgY3k9IjEwNy4xMyIgcj0iOS4xMzM1Ii8+PGNpcmNsZSBjeD0iMTM3LjMzIiBjeT0iMTA0LjY4IiByPSI5LjEzMzUiLz48Y2lyY2xlIGN4PSIxNDkuNjYiIGN5PSI4NC4wODEiIHI9IjE0LjYxNyIvPjxjaXJjbGUgY3g9IjExNC42MSIgY3k9IjEwMi42MiIgcj0iMTMuMzc4Ii8+PGNpcmNsZSBjeD0iMTI5LjQiIGN5PSI4MC43OTciIHI9IjguODg1NSIvPjxjaXJjbGUgY3g9IjExOC4zNiIgY3k9IjY3LjQ5NCIgcj0iMTEuNjU4Ii8+PGNpcmNsZSBjeD0iOTcuODAxIiBjeT0iODYuNTA0IiByPSIxMy4wMDUiLz48Y2lyY2xlIGN4PSI5Mi44MDIiIGN5PSI4MC45NzEiIHI9IjEzLjAwNSIvPjxjaXJjbGUgY3g9IjkzLjY5OSIgY3k9IjYzLjc4NSIgcj0iNy4yNjI0Ii8+PGNpcmNsZSBjeD0iMTAwLjU5IiBjeT0iNjcuNjY2IiByPSI3LjI2MjQiLz48Y2lyY2xlIGN4PSIxMjguOTYiIGN5PSI5OS45NDYiIHI9IjcuMjYyNCIvPjxyZWN0IHg9IjEwMC43NCIgeT0iNjguNDg3IiB3aWR0aD0iMjEuNjAxIiBoZWlnaHQ9IjI0LjYzNCIvPjxyZWN0IHg9IjExOS45MyIgeT0iODMuMTkiIHdpZHRoPSIzNC41OSIgaGVpZ2h0PSIxNy4yNTUiLz48Y2lyY2xlIGN4PSI2MC40MjQiIGN5PSI4Mi44MTkiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjU3LjExMyIgY3k9Ijk3Ljc2MyIgcj0iMTUuMjE3Ii8+PGNpcmNsZSBjeD0iMzcuODI2IiBjeT0iMTAxLjc2IiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSIyNS4wODMiIGN5PSI4MC44MDgiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjMyLjU4OCIgY3k9Ijk0LjcyIiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSI0Mi45NjciIGN5PSI4OS40MjMiIHI9IjE1LjIxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3OC4xM21tIiBoZWlnaHQ9IjExNy45NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzguMTMgMTE3Ljk0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTIzLjg2NSkiPjxwYXRoIGQ9Im0yMy43NzEgMjMuODY1djYyLjQ3M2gtMC4wMDIxYzEuMDllLTQgMC4wMjc2MSAwLjAwMjEgMC4wNTQ4MSAwLjAwMjEgMC4wODI1djIzLjI1MWMwIDEyLjE2LTEwLjU5IDIxLjk1Ny0yMy43NzEgMjIuMDI2djEwLjEwNGg5NS42OTl2LTEwLjEwNGMtMTMuMTgyLTAuMDY5MS0yMy43NzEtOS44NjYtMjMuNzcxLTIyLjAyNnYtMjMuMjUxYzAtMC4wMjc3IDJlLTMgLTAuMDU0ODkgMC4wMDIxLTAuMDgyNWgtMC4wMDIxdi02Mi40NzN6Ii8+PHBhdGggZD0ibTEyMS43NCA0OS4wM3Y0OS4xNDNoLTJlLTNjOGUtNSAwLjAyMTcgMmUtMyAwLjA0MzA2IDJlLTMgMC4wNjQ5MnYxOC4yODljMCA5LjU2NTctOC4zMDI3IDE3LjI3Mi0xOC42MzggMTcuMzI3djcuOTQ4NGg3NS4wMzJ2LTcuOTQ4NGMtMTAuMzM1LTAuMDU0My0xOC42MzgtNy43NjA5LTE4LjYzOC0xNy4zMjd2LTE4LjI4OWMwLTAuMDIxNzggMmUtMyAtMC4wNDMxNCAyZS0zIC0wLjA2NDkyaC0yZS0zdi00OS4xNDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0.40000000000000002" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="40" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3OC4xM21tIiBoZWlnaHQ9IjExNy45NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzguMTMgMTE3Ljk0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTIzLjg2NSkiPjxwYXRoIGQ9Im0yMy43NzEgMjMuODY1djYyLjQ3M2gtMC4wMDIxYzEuMDllLTQgMC4wMjc2MSAwLjAwMjEgMC4wNTQ4MSAwLjAwMjEgMC4wODI1djIzLjI1MWMwIDEyLjE2LTEwLjU5IDIxLjk1Ny0yMy43NzEgMjIuMDI2djEwLjEwNGg5NS42OTl2LTEwLjEwNGMtMTMuMTgyLTAuMDY5MS0yMy43NzEtOS44NjYtMjMuNzcxLTIyLjAyNnYtMjMuMjUxYzAtMC4wMjc3IDJlLTMgLTAuMDU0ODkgMC4wMDIxLTAuMDgyNWgtMC4wMDIxdi02Mi40NzN6Ii8+PHBhdGggZD0ibTEyMS43NCA0OS4wM3Y0OS4xNDNoLTJlLTNjOGUtNSAwLjAyMTcgMmUtMyAwLjA0MzA2IDJlLTMgMC4wNjQ5MnYxOC4yODljMCA5LjU2NTctOC4zMDI3IDE3LjI3Mi0xOC42MzggMTcuMzI3djcuOTQ4NGg3NS4wMzJ2LTcuOTQ4NGMtMTAuMzM1LTAuMDU0My0xOC42MzgtNy43NjA5LTE4LjYzOC0xNy4zMjd2LTE4LjI4OWMwLTAuMDIxNzggMmUtMyAtMC4wNDMxNCAyZS0zIC0wLjA2NDkyaC0yZS0zdi00OS4xNDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0.40000000000000002" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="41" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS4zbW0iIGhlaWdodD0iMTM5Ljk0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OS4zIDEzOS45NCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzIuMjYzIC03Ni44ODQpIj48Y2lyY2xlIGN4PSI3OS40OTEiIGN5PSIxOTUuOTgiIHI9IjE2Ljg1IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48Y2lyY2xlIGN4PSIxNTQuOCIgY3k9IjE5NS45OCIgcj0iMTYuODUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3Ljk4MTUiLz48Zz48cmVjdCB4PSIxMDMuMzUiIHk9IjE4Mi42MiIgd2lkdGg9IjI1LjU0OSIgaGVpZ2h0PSIxNi4yMjIiLz48cGF0aCBkPSJtMzIuMjYzIDE0OS4wOHY0Mi43OThoMjEuOTlhMjQuODI3IDI0LjgyNyAwIDAgMSAyMC4wMzMtMjAuNTk2di0yMi4yMDN6bTQuNzY1MSA1LjAwMjhoMTcuNjI3djIwLjEzM2gtMTcuNjI3eiIvPjxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDQwLjE1MykiIGQ9Im0xNDUuMDcgNi43OTExLTMuOWUtNCA0MS4yOSA2NS4wMzktMi42ZS01IDI5LjM2Ny0yNC43NzYgMi45ZS00IC0xNi41MTR6Ii8+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoMzkuODQ5KSIgZD0ibTE3MS4wMSA0My41NTUtMi45ZS00IDUuNDU3MSA0LjQyMDMgMmUtNSAyZS01IDI1LjQ5IDExLjgwNS0yLjI1ZS00IDIuM2UtNCAtMjUuNDI4IDUuMTA3OCAzLjU4ZS00IDVlLTUgLTUuNTE5NXoiLz48cGF0aCBkPSJtMTcxLjEgMTUzLjIzLTEyLjk1MiAxOC45OTloOS44NjI0bDguNTU0NSAxMC45OTIgNS4wMDE4IDAuMzM2OTN2LTE5Ljc5NWwtMi45MDczLTQuMTU2M3oiLz48cGF0aCBkPSJtMTEzLjAyIDEwNC4yNC02LjUyMjctNS41MDI5LTIzLjEzMi0xOS45MDUtOC41MjY2LTEuOTQ2NiAwLjA1MzA4OSA4LjIyMDcgMjUuNjIxIDIwLjcyNSA0LjQ4MzUgNS4xNzQyeiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="42" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzMi4xNm1tIiBoZWlnaHQ9IjEyMy44Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzIuMTYgMTIzLjg2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4yMTkgLTkxLjcyMSkiPjxnPjxyZWN0IHg9IjE2MS45NyIgeT0iOTEuNzIxIiB3aWR0aD0iMTYuNDEiIGhlaWdodD0iMTIzLjg2Ii8+PHJlY3QgeD0iNDYuMjIiIHk9IjE2OC4yNSIgd2lkdGg9IjEzMi4xNiIgaGVpZ2h0PSI0Ny4zMjgiLz48cmVjdCB4PSIxNDAuMDQiIHk9IjkxLjcyMSIgd2lkdGg9IjE2LjQxIiBoZWlnaHQ9IjEyMy44NiIvPjxwYXRoIGQ9Im03NS42NDkgMTM4LjczLTI5LjQyOSAyOS40Mjl2MTMuOTU5aDI5LjQyOXoiLz48cGF0aCBkPSJtMTA1LjA4IDEzOC43My0yOS40MjkgMjkuNDI5djEzLjk1OWgyOS40Mjl6Ii8+PHBhdGggZD0ibTEzNC41MSAxMzguNzMtMjkuNDI5IDI5LjQyOXYxMy45NTloMjkuNDI5eiIvPjxyZWN0IHg9IjQ2LjIxOSIgeT0iMTY4LjI1IiB3aWR0aD0iMTMyLjE2IiBoZWlnaHQ9IjEzLjc2OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="43" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNi4zM21tIiBoZWlnaHQ9IjEzOC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTYuMzMgMTM4LjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NS4wNSAtODEuMjY0KSI+PGc+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iMTQ4LjM2IiB5PSIxMjYuNDUiIHdpZHRoPSIyMy4wMTUiIGhlaWdodD0iOTMuMDgxIiBzdHJva2Utd2lkdGg9IjcuNTQ3NCIvPjxyZWN0IHg9IjU1LjA1IiB5PSIxODUuNDkiIHdpZHRoPSIxMTYuMzMiIGhlaWdodD0iMzQuMDQxIiBzdHJva2Utd2lkdGg9IjcuOTgyIi8+PHBhdGggZD0ibTEwMC42NCAxNDguMjcgMWUtNSAxMy40NzUgNjIuNzI5IDIyLjIyMiA0LjI0MTYtMTEuOTcyeiIgc3Ryb2tlLXdpZHRoPSI3Ljk4MiIvPjxwYXRoIGQ9Im01NS4wNSAxNTEuMzQtNGUtNiAxNS4zNTYgNzguMjY1IDI4LjIyNiAxMC42ODQtMTEuNTAzeiIgc3Ryb2tlLXdpZHRoPSIxMi43OTkiLz48cmVjdCB4PSIxMzguNDIiIHk9IjE4Mi43MSIgd2lkdGg9IjEzLjY5MyIgaGVpZ2h0PSI0LjE5NzMiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48cGF0aCBkPSJtNTUuMDUgMTcxLjM0IDVlLTYgMjEuMjkxIDMzLjk2IDEyLjQ5MSA2Ljg5NzItMTguNzUzeiIgc3Ryb2tlLXdpZHRoPSI4Ljk0NjciLz48L2c+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMS42NjM1IDAgMCAxLjY2MzUgMTUyLjI1IC02MC45MjIpIj48Y2lyY2xlIGN4PSIxLjk1MzMiIGN5PSIxMDIuNDUiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9IjMuNzgxNCIgY3k9IjEwOC41MiIgcj0iMi45MDY3Ii8+PGNpcmNsZSBjeD0iMS45OTk4IiBjeT0iMTA1Ljg4IiByPSIyLjkwNjciLz48Y2lyY2xlIGN4PSIxLjE4NDMiIGN5PSIxMDcuMDEiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9Ii01LjAwNTkiIGN5PSI5NS41NzYiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii00LjQyOTgiIGN5PSIxMDAuOTkiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii0zMS42NDYiIGN5PSI5NC4yMzIiIHI9IjYuODcxOCIvPjxjaXJjbGUgY3g9Ii0zMy45MzYiIGN5PSIxMDYuNDIiIHI9IjQuNjYzNiIvPjxjaXJjbGUgY3g9Ii0zMC4xNzgiIGN5PSIxMDYuMjMiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii0zNi45NDciIGN5PSIxMDQuNTIiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii00Ny44OCIgY3k9IjEwNS4zMSIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUwLjgyOSIgY3k9IjEwNC4zNyIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUxLjI1MSIgY3k9IjEwMC43NiIgcj0iNS41NDA4Ii8+PGNpcmNsZSBjeD0iLTUyLjQ0OCIgY3k9IjkzLjAxNiIgcj0iMS41NTQ2Ii8+PGNpcmNsZSBjeD0iLTQ5LjU5OSIgY3k9IjkyLjA0MSIgcj0iMS45NjkxIi8+PGVsbGlwc2UgY3g9Ii00NS43OTEiIGN5PSI5My4xMjIiIHJ4PSIzLjczNTYiIHJ5PSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItNDIuMzk2IiBjeT0iOTMuOTY3IiByPSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItMzguNzMiIGN5PSI5My42NjUiIHI9IjEuOTY5MSIvPjxjaXJjbGUgY3g9Ii0xMS43NTYiIGN5PSIxMDYuNTkiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xNC43MDUiIGN5PSIxMDUuNDYiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xOS45NTIiIGN5PSIxMDEuMTgiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0yNi44MjIiIGN5PSIxMDEuNSIgcj0iNC42MjMyIi8+PGNpcmNsZSBjeD0iLTEyLjA1IiBjeT0iODcuNzMxIiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNS45NzU4IiBjeT0iOTAuMTQ5IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNi45NjI4IiBjeT0iODguNzI1IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItMTQuODc0IiBjeT0iOTEuMjM3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMTcuMDY1IiBjeT0iOTMuNzc2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItNDMuNTQ0IiBjeT0iMTAzLjE3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjAuOTc4IiBjeT0iOTcuNTI1IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjUuNzQ3IiBjeT0iOTYuMTk2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItOS42MzA0IiBjeT0iODkuMzU2IiByPSIyLjIyMTQiLz48Y2lyY2xlIGN4PSItNTEuMTc1IiBjeT0iOTYuMzEyIiByPSIyLjIyMTQiLz48ZWxsaXBzZSBjeD0iMy42MzY2IiBjeT0iMTEyLjkzIiByeD0iMy4yOTc3IiByeT0iNy4yNjQ5Ii8+PHBhdGggZD0ibS0wLjI0ODI4IDEwNy4wOGMtMS41NWUtNiAyLjU1MzMtMS44MzE4IDAuMjMyMTUtNC4zODUyIDAuMjMyMTVzLTQuODYxMyAyLjMyMTItNC44NjEzLTAuMjMyMTVjLTRlLTYgLTIuNTUzMyAyLjA2OTktNC42MjMyIDQuNjIzMi00LjYyMzIgMi41NTMzIDAgNC42MjMyIDIuMDY5OSA0LjYyMzIgNC42MjMyeiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjQyMzUiLz48cGF0aCBkPSJtLTUwLjQ2IDkyLjcxLTEuNDQyNCAwLjQ0OTcyLTAuMDYxNzggMi42MjM0czAuOTA3NzMgMi44MzE2IDEuMDQyNSAzLjA2MDdjMC4xMzQ3NiAwLjIyOTEgMi42MDk0IDMuNDY4IDIuNjA5NCAzLjQ2OGw1LjIzODEgMC40OTM1NyAzLjcyMDMgMS4yNTE0IDMuNzY4IDAuMjE4NzFzNC44MTEyIDEuMjc1MSA1LjIzNzMgMC44MjI0N2MwLjQyNjA2LTAuNDUyNjYgMS40NDg4LTUuMDU0MiAxLjQxMzYtNS4zNTQ1LTAuMDM1MTYtMC4zMDAzNC0zLjM5NTctMS43NzQ1LTMuMzk1Ny0xLjc3NDVsLTMuODQwNS0yLjU0NzItMS42MjUtMS4yMTM0LTIuOTQ0Ni0wLjEwMDkycy0yLjc2MjctMC4zNTA3MS0zLjAzMTQtMC41MTY0NWMtMC4yNjg3Mi0wLjE2NTc1LTMuMTkxNC0wLjc2NTgtMy4zNDczLTAuNzY1OC0wLjE1NTg4IDAtMy4zNDA1LTAuMTE1My0zLjM0MDUtMC4xMTUzeiIvPjxwYXRoIGQ9Im0tMjAuMTk2IDk2LjUwNyAyLjkwNTQgNy4xMTYxIDQuOTYzNiAyLjIxMzUgNy4yMjgyLTAuMzU5MDkgNS4zOTc1IDAuNDAyODVzMS4xNDY1LTIuNDc2MyAxLjE2NjYtMi42Mzg1YzAuMDIwMTA4LTAuMTYyMjMtMi4yNDgzLTEuODA5OC0yLjI0ODMtMS44MDk4bC0xLjQ3OTgtMi4xNjU2LTAuMjEyNTItMi43NjQ5cy0xLjUxOTQtMi4zOTMzLTEuNTIyOC0yLjU1NTVjLTAuMDAzMzMtMC4xNjIxNy0yLjYyMjktNC4yNzMyLTIuNjIyOS00LjI3MzJsLTUuMjE1OS0wLjA2MjAzLTUuMTcyNCAzLjUyOTV6Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.54348" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="44" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0NC43OG1tIiBoZWlnaHQ9Ijk1LjM2M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDQuNzggOTUuMzYzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNi43MjcgLTEwNi4yNykiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE3MS40NyAxMDYuMjd2OTUuMzYzIiBzdHJva2Utd2lkdGg9IjIwLjA3OSIvPjxwYXRoIGQ9Im0xNzEuNDcgMTk1LjQ5aC0xMjguNjF2LTQzLjcxNGwyMy4xNDQtMTQuMTQ5IDEwLjU5MiAxOS4yMjQgMjguNjg0LTE5LjcyNyAxMi42MTEgMjAuNTczIDMwLjU5OS0yMi41MSAxOC42ODggMzEuNTQiIHN0cm9rZS13aWR0aD0iMTIuMjY5Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="45" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43NG1tIiBoZWlnaHQ9IjEyMy4wN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzQgMTIzLjA3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40MDkgLTk1LjY1NCkiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGcgc3Ryb2tlLXdpZHRoPSI4LjgxMiI+PHBhdGggZD0ibTQ5LjgxNSAxNzAuOTN2NDMuMzg2aDI4LjYzOXYtMzMuNzg1aDIyLjM0NiIvPjxwYXRoIGQ9Im0xNTAuNjMgMTcwLjkzdjQzLjM4NmgtMjguNjM5di0zMy43ODVoLTIyLjM0NiIvPjxwYXRoIGQ9Im00OS44MTUgMTcwLjkzczguOTczOS0xNS41ODIgMTUuODI2LTIyLjQzNGM5LjM0NzQtOS4zNDc0IDIxLjk0LTE4LjMzMyAzNS4xNTktMTguMzQ2IDEzLjI3LTAuMDEzMSAyNS45NDYgOC45NjI4IDM1LjMyOSAxOC4zNDYgNi42MTk2IDYuNjE5NiAxNC40OTggMjIuNDM0IDE0LjQ5OCAyMi40MzQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Im0xNTAuNjMgMjE0LjMyaDI3LjkyMXYtODEuMzUyaC0zOC44NHYxNi4yMDgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz48L2c+PHBhdGggZD0ibTExOC4yMSAxMzQuMTF2LTEyLjU0M2gyMi40MTciIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS13aWR0aD0iNy41MTUiLz48cGF0aCBkPSJtMTc4LjQgMTMxLjQ3YzAtMTAuNjQzLTguNjI4Mi0xOS4yNzItMTkuMjcyLTE5LjI3MnMtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2Utd2lkdGg9IjkuNTA4Ii8+PHBhdGggZD0ibTE1Ni43NiAxMTYuODFjLTEuMDkxNS05LjQ3MTktOC42NDU0LTE2LjU0Ny0xOC40OC0xNi41NDctMTAuNjQzIDAtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuMjA4Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="46" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43OW1tIiBoZWlnaHQ9IjEyMy43OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzkgMTIzLjc5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS4zNTggLTkxLjgyNikiPjxnPjxyZWN0IHg9IjE1OC43OCIgeT0iOTEuODI2IiB3aWR0aD0iMTMuMjYyIiBoZWlnaHQ9Ijg2LjE3Ii8+PHJlY3QgeD0iMTM4LjA4IiB5PSI5MS44MjYiIHdpZHRoPSIxMy4yNjIiIGhlaWdodD0iODYuMTciLz48cmVjdCB4PSIxMTMuMTIiIHk9IjkxLjgyNiIgd2lkdGg9IjEzLjI2MiIgaGVpZ2h0PSI4Ni4xNyIvPjxwYXRoIGQ9Im00NS44ODggMTc1LjcxLTAuNTI5MTcgMC41MjkxNnYzOS4zNzRoMTM3Ljc5di0zOS45MDR6bTQuNjUxOSA1LjI1MDhoMjIuNzI5djYuODk3OGgtMjIuNzI5em0yNy45NzkgMGgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bTI3LjkzMiAwaDE5LjExOXY2Ljg5NzhoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3OGgtMjIuNzI5em0tNzYuNzE2IDExLjI1MmgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bS01Mi4zNDcgMC4zNjc5M2gyMi43Mjl2Ni44OTczaC0yMi43Mjl6bTgwLjI3OSAwaDE5LjExOXY2Ljg5NzNoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3M2gtMjIuNzI5eiIvPjxwYXRoIGQ9Im03MC40MTEgMTUxLjE4LTEyLjkxNCAxMi45MTQtMTIuMTM4IDEyLjEzOWgyNS4wNTN6Ii8+PHBhdGggZD0ibTk0LjkzNSAxNTEuMTgtMTIuOTE0IDEyLjkxNC0xMi4xMzggMTIuMTM5aDI1LjA1M3oiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="47" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzOS43N21tIiBoZWlnaHQ9IjEyNS42NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzkuNzcgMTI1LjY1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41ODcgLTgyLjMxMykiPjxnPjxjaXJjbGUgY3g9IjkzLjM3MiIgY3k9IjE5NS4wOCIgcj0iMTIuODgzIi8+PGNpcmNsZSBjeD0iMTM0Ljg2IiBjeT0iMTk1LjA4IiByPSIxMi44ODMiLz48cGF0aCBkPSJtNDEuNTg3IDEyMy44NWgxMzkuNzdsLTI2LjMzOSA1Ny43OTZoLTg3LjA3NHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOS41MDgiLz48Y2lyY2xlIGN4PSI4MS4wMzYiIGN5PSIxMjAuNTYiIHI9IjIwLjU2OCIvPjxjaXJjbGUgY3g9IjE0Mi41NSIgY3k9IjEyMC41NiIgcj0iMjAuNTY4Ii8+PHBhdGggZD0ibTExMS40NyA4Mi4zMTNhMjAuNTY4IDIwLjU2OCAwIDAgMC0yMC41NjggMjAuNTY4aDQxLjEzN2EyMC41NjggMjAuNTY4IDAgMCAwLTIwLjU2OC0yMC41Njh6Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="48" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="231,113,72,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="49" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5OS42NW1tIiBoZWlnaHQ9IjEzMS4yN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTkuNjUgMTMxLjI3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02LjY4NDcgLTk0LjExNykiPjxyZWN0IHg9IjE4NS4xNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjEuMTc2IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjEwMi4yNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjIuNTU3IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjExNC4zIiB5PSIyMTEuNDQiIHdpZHRoPSI3Ny4zMjUiIGhlaWdodD0iOS42MjExIi8+PHJlY3QgeD0iMTM4LjU5IiB5PSIxOTUuNjYiIHdpZHRoPSIzMS44ODMiIGhlaWdodD0iMTcuODMyIi8+PHJlY3QgeD0iMTEzLjMxIiB5PSIxNDguNTYiIHdpZHRoPSI5My4wMjEiIGhlaWdodD0iNTEuNjA3Ii8+PHJlY3QgeD0iMTY5LjQ2IiB5PSIxMzkuODQiIHdpZHRoPSIzNi44NzQiIGhlaWdodD0iMTcuNDQyIi8+PHBhdGggZD0ibTExOC4zMyAxMzAuODN2MjQuNTM3aDI0Ljk2MXYtMjQuNTM3em02LjI3MiA2LjI3ODJoOC43OTMzdjExLjQ0OWgtOC43OTMzeiIvPjxwYXRoIGQ9Im0xMjAuMyAxNDQuNzhoLTEwLjg0NmwtMTMuNjAxLTE2LjE5MyAyLjIyODktMy40NDg3aDEwLjAyOGwzLjgwOTctMy42NDM5LTAuMjIyMDctMi40ODQ2IDcuMDQ0Ni01LjcxMTggMi4xMDcyIDIuMzEzMyAyLjIxMjktMC43NTE1OHYtOC4xMTJsLTIuMTM0OC0xLjkzODQtMy4xMTA4IDAuMzI4NDV2LTQuNDQ0M2wtMi4xODc1LTMuMjE3NmgtNi4yNTE1bC0yMi4zNDYgMjQuMzczaC04LjQ2ODJsLTI3LjczNS0yNy43MjloLTkuNDhsLTQuMzY1NCA1Ljg1ODkgMjkuMTA5IDI5LjY1N2g1LjI3MThsMi4xOTYyIDIuMTYydjIuOTcwNGwtMi40MTU1IDIuMTI3OWgtOS4zMzc2bC0yMS4zOTggMjEuMjEyaC0xOS45MzRsLTEzLjc5MSAyMi41Nzl2My45MjA4aDMyLjU3OHYtNC43MTQxaDcuMTM2MnYtMTcuNDgzbDI3LjY0NC0yMC40MjdoMTIuOTAybDI5LjIxNiAyNC4xNDl6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS4zbW0iIGhlaWdodD0iMTM5Ljk0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OS4zIDEzOS45NCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzIuMjYzIC03Ni44ODQpIj48Y2lyY2xlIGN4PSI3OS40OTEiIGN5PSIxOTUuOTgiIHI9IjE2Ljg1IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48Y2lyY2xlIGN4PSIxNTQuOCIgY3k9IjE5NS45OCIgcj0iMTYuODUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3Ljk4MTUiLz48Zz48cmVjdCB4PSIxMDMuMzUiIHk9IjE4Mi42MiIgd2lkdGg9IjI1LjU0OSIgaGVpZ2h0PSIxNi4yMjIiLz48cGF0aCBkPSJtMzIuMjYzIDE0OS4wOHY0Mi43OThoMjEuOTlhMjQuODI3IDI0LjgyNyAwIDAgMSAyMC4wMzMtMjAuNTk2di0yMi4yMDN6bTQuNzY1MSA1LjAwMjhoMTcuNjI3djIwLjEzM2gtMTcuNjI3eiIvPjxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDQwLjE1MykiIGQ9Im0xNDUuMDcgNi43OTExLTMuOWUtNCA0MS4yOSA2NS4wMzktMi42ZS01IDI5LjM2Ny0yNC43NzYgMi45ZS00IC0xNi41MTR6Ii8+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoMzkuODQ5KSIgZD0ibTE3MS4wMSA0My41NTUtMi45ZS00IDUuNDU3MSA0LjQyMDMgMmUtNSAyZS01IDI1LjQ5IDExLjgwNS0yLjI1ZS00IDIuM2UtNCAtMjUuNDI4IDUuMTA3OCAzLjU4ZS00IDVlLTUgLTUuNTE5NXoiLz48cGF0aCBkPSJtMTcxLjEgMTUzLjIzLTEyLjk1MiAxOC45OTloOS44NjI0bDguNTU0NSAxMC45OTIgNS4wMDE4IDAuMzM2OTN2LTE5Ljc5NWwtMi45MDczLTQuMTU2M3oiLz48cGF0aCBkPSJtMTEzLjAyIDEwNC4yNC02LjUyMjctNS41MDI5LTIzLjEzMi0xOS45MDUtOC41MjY2LTEuOTQ2NiAwLjA1MzA4OSA4LjIyMDcgMjUuNjIxIDIwLjcyNSA0LjQ4MzUgNS4xNzQyeiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="50" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5NC41NW1tIiBoZWlnaHQ9IjE5MS4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTQuNTUgMTkxLjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjk2MTggLTUzLjM3MikiPjxnPjxyZWN0IHg9IjMuOTYxOCIgeT0iMjE2Ljk4IiB3aWR0aD0iMTk0LjU1IiBoZWlnaHQ9IjI3LjcxOCIvPjxyZWN0IHg9IjEzNi4wNSIgeT0iOTAuNDc1IiB3aWR0aD0iNDEuOTcyIiBoZWlnaHQ9IjEzNS43NiIgcnk9IjQuODQwOCIvPjxyZWN0IHg9IjcxLjcxMiIgeT0iOTAuNDc1IiB3aWR0aD0iNDYuNjY5IiBoZWlnaHQ9IjEzNy45MiIgcnk9IjcuNzI5MSIvPjxyZWN0IHg9IjIzLjI4MiIgeT0iOTAuNDc1IiB3aWR0aD0iMjIuODIyIiBoZWlnaHQ9IjEzNS40NCIgcnk9IjUuMTgyOSIvPjwvZz48cGF0aCBkPSJtMTU4LjAyIDk0LjgxNWMxLjRlLTQgLTE3LjI2LTEzLjc5Ni0zMS4yNTMtMzAuODE1LTMxLjI1My0xNy4wMTktMS40MmUtNCAtMzAuODE1IDEzLjk5Mi0zMC44MTUgMzEuMjUzIDAuMDAyNCAwLjcwNzYyIDAuMDI4NDQgMS40MTUgMC4wNzgxNiAyLjEyMDgiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMy4yIiBzdHJva2Utd2lkdGg9IjIwLjM4MSIvPjxwYXRoIGQ9Im05Ni45MzggOTQuNzc2YzEuNGUtNCAtMTcuMjE0LTEzLjk1NS0zMS4xNjktMzEuMTY5LTMxLjE2OS0xNy4yMTQtMS40MWUtNCAtMzEuMTY5IDEzLjk1NS0zMS4xNjkgMzEuMTY5IDAuMDAyNCAwLjcwNTczIDAuMDI4NzcgMS40MTEyIDAuMDc5MDYgMi4xMTUxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuMiIgc3Ryb2tlLXdpZHRoPSIyMC40NyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.28779" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="51" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4MC42OG1tIiBoZWlnaHQ9IjE4Ni40N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODAuNjggMTg2LjQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05Ljg2NjQgLTU1LjgzNikiPjxyZWN0IHg9IjE4LjUzNyIgeT0iMTc1LjExIiB3aWR0aD0iMTM2LjY0IiBoZWlnaHQ9IjY3LjE5MyIgcnk9IjAiLz48cmVjdCB4PSIxNjQuMzUiIHk9IjEyOS4yNCIgd2lkdGg9IjI2LjE4OSIgaGVpZ2h0PSIxMTMuMDYiIHJ5PSIwIi8+PGNpcmNsZSBjeD0iMTcyLjYzIiBjeT0iMTA2LjMzIiByPSIxMi44MDEiLz48Y2lyY2xlIGN4PSIxNjUuNzIiIGN5PSI5Ny4zMzMiIHI9IjEyLjgwMSIvPjxjaXJjbGUgY3g9IjE0OC42NyIgY3k9IjEwNy4xMyIgcj0iOS4xMzM1Ii8+PGNpcmNsZSBjeD0iMTM3LjMzIiBjeT0iMTA0LjY4IiByPSI5LjEzMzUiLz48Y2lyY2xlIGN4PSIxNDkuNjYiIGN5PSI4NC4wODEiIHI9IjE0LjYxNyIvPjxjaXJjbGUgY3g9IjExNC42MSIgY3k9IjEwMi42MiIgcj0iMTMuMzc4Ii8+PGNpcmNsZSBjeD0iMTI5LjQiIGN5PSI4MC43OTciIHI9IjguODg1NSIvPjxjaXJjbGUgY3g9IjExOC4zNiIgY3k9IjY3LjQ5NCIgcj0iMTEuNjU4Ii8+PGNpcmNsZSBjeD0iOTcuODAxIiBjeT0iODYuNTA0IiByPSIxMy4wMDUiLz48Y2lyY2xlIGN4PSI5Mi44MDIiIGN5PSI4MC45NzEiIHI9IjEzLjAwNSIvPjxjaXJjbGUgY3g9IjkzLjY5OSIgY3k9IjYzLjc4NSIgcj0iNy4yNjI0Ii8+PGNpcmNsZSBjeD0iMTAwLjU5IiBjeT0iNjcuNjY2IiByPSI3LjI2MjQiLz48Y2lyY2xlIGN4PSIxMjguOTYiIGN5PSI5OS45NDYiIHI9IjcuMjYyNCIvPjxyZWN0IHg9IjEwMC43NCIgeT0iNjguNDg3IiB3aWR0aD0iMjEuNjAxIiBoZWlnaHQ9IjI0LjYzNCIvPjxyZWN0IHg9IjExOS45MyIgeT0iODMuMTkiIHdpZHRoPSIzNC41OSIgaGVpZ2h0PSIxNy4yNTUiLz48Y2lyY2xlIGN4PSI2MC40MjQiIGN5PSI4Mi44MTkiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjU3LjExMyIgY3k9Ijk3Ljc2MyIgcj0iMTUuMjE3Ii8+PGNpcmNsZSBjeD0iMzcuODI2IiBjeT0iMTAxLjc2IiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSIyNS4wODMiIGN5PSI4MC44MDgiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjMyLjU4OCIgY3k9Ijk0LjcyIiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSI0Mi45NjciIGN5PSI4OS40MjMiIHI9IjE1LjIxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="52" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3OC4xM21tIiBoZWlnaHQ9IjExNy45NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzguMTMgMTE3Ljk0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTIzLjg2NSkiPjxwYXRoIGQ9Im0yMy43NzEgMjMuODY1djYyLjQ3M2gtMC4wMDIxYzEuMDllLTQgMC4wMjc2MSAwLjAwMjEgMC4wNTQ4MSAwLjAwMjEgMC4wODI1djIzLjI1MWMwIDEyLjE2LTEwLjU5IDIxLjk1Ny0yMy43NzEgMjIuMDI2djEwLjEwNGg5NS42OTl2LTEwLjEwNGMtMTMuMTgyLTAuMDY5MS0yMy43NzEtOS44NjYtMjMuNzcxLTIyLjAyNnYtMjMuMjUxYzAtMC4wMjc3IDJlLTMgLTAuMDU0ODkgMC4wMDIxLTAuMDgyNWgtMC4wMDIxdi02Mi40NzN6Ii8+PHBhdGggZD0ibTEyMS43NCA0OS4wM3Y0OS4xNDNoLTJlLTNjOGUtNSAwLjAyMTcgMmUtMyAwLjA0MzA2IDJlLTMgMC4wNjQ5MnYxOC4yODljMCA5LjU2NTctOC4zMDI3IDE3LjI3Mi0xOC42MzggMTcuMzI3djcuOTQ4NGg3NS4wMzJ2LTcuOTQ4NGMtMTAuMzM1LTAuMDU0My0xOC42MzgtNy43NjA5LTE4LjYzOC0xNy4zMjd2LTE4LjI4OWMwLTAuMDIxNzggMmUtMyAtMC4wNDMxNCAyZS0zIC0wLjA2NDkyaC0yZS0zdi00OS4xNDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0.40000000000000002" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="53" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS4zbW0iIGhlaWdodD0iMTM5Ljk0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OS4zIDEzOS45NCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzIuMjYzIC03Ni44ODQpIj48Y2lyY2xlIGN4PSI3OS40OTEiIGN5PSIxOTUuOTgiIHI9IjE2Ljg1IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48Y2lyY2xlIGN4PSIxNTQuOCIgY3k9IjE5NS45OCIgcj0iMTYuODUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3Ljk4MTUiLz48Zz48cmVjdCB4PSIxMDMuMzUiIHk9IjE4Mi42MiIgd2lkdGg9IjI1LjU0OSIgaGVpZ2h0PSIxNi4yMjIiLz48cGF0aCBkPSJtMzIuMjYzIDE0OS4wOHY0Mi43OThoMjEuOTlhMjQuODI3IDI0LjgyNyAwIDAgMSAyMC4wMzMtMjAuNTk2di0yMi4yMDN6bTQuNzY1MSA1LjAwMjhoMTcuNjI3djIwLjEzM2gtMTcuNjI3eiIvPjxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDQwLjE1MykiIGQ9Im0xNDUuMDcgNi43OTExLTMuOWUtNCA0MS4yOSA2NS4wMzktMi42ZS01IDI5LjM2Ny0yNC43NzYgMi45ZS00IC0xNi41MTR6Ii8+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoMzkuODQ5KSIgZD0ibTE3MS4wMSA0My41NTUtMi45ZS00IDUuNDU3MSA0LjQyMDMgMmUtNSAyZS01IDI1LjQ5IDExLjgwNS0yLjI1ZS00IDIuM2UtNCAtMjUuNDI4IDUuMTA3OCAzLjU4ZS00IDVlLTUgLTUuNTE5NXoiLz48cGF0aCBkPSJtMTcxLjEgMTUzLjIzLTEyLjk1MiAxOC45OTloOS44NjI0bDguNTU0NSAxMC45OTIgNS4wMDE4IDAuMzM2OTN2LTE5Ljc5NWwtMi45MDczLTQuMTU2M3oiLz48cGF0aCBkPSJtMTEzLjAyIDEwNC4yNC02LjUyMjctNS41MDI5LTIzLjEzMi0xOS45MDUtOC41MjY2LTEuOTQ2NiAwLjA1MzA4OSA4LjIyMDcgMjUuNjIxIDIwLjcyNSA0LjQ4MzUgNS4xNzQyeiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="54" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzMi4xNm1tIiBoZWlnaHQ9IjEyMy44Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzIuMTYgMTIzLjg2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4yMTkgLTkxLjcyMSkiPjxnPjxyZWN0IHg9IjE2MS45NyIgeT0iOTEuNzIxIiB3aWR0aD0iMTYuNDEiIGhlaWdodD0iMTIzLjg2Ii8+PHJlY3QgeD0iNDYuMjIiIHk9IjE2OC4yNSIgd2lkdGg9IjEzMi4xNiIgaGVpZ2h0PSI0Ny4zMjgiLz48cmVjdCB4PSIxNDAuMDQiIHk9IjkxLjcyMSIgd2lkdGg9IjE2LjQxIiBoZWlnaHQ9IjEyMy44NiIvPjxwYXRoIGQ9Im03NS42NDkgMTM4LjczLTI5LjQyOSAyOS40Mjl2MTMuOTU5aDI5LjQyOXoiLz48cGF0aCBkPSJtMTA1LjA4IDEzOC43My0yOS40MjkgMjkuNDI5djEzLjk1OWgyOS40Mjl6Ii8+PHBhdGggZD0ibTEzNC41MSAxMzguNzMtMjkuNDI5IDI5LjQyOXYxMy45NTloMjkuNDI5eiIvPjxyZWN0IHg9IjQ2LjIxOSIgeT0iMTY4LjI1IiB3aWR0aD0iMTMyLjE2IiBoZWlnaHQ9IjEzLjc2OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="55" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNi4zM21tIiBoZWlnaHQ9IjEzOC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTYuMzMgMTM4LjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NS4wNSAtODEuMjY0KSI+PGc+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iMTQ4LjM2IiB5PSIxMjYuNDUiIHdpZHRoPSIyMy4wMTUiIGhlaWdodD0iOTMuMDgxIiBzdHJva2Utd2lkdGg9IjcuNTQ3NCIvPjxyZWN0IHg9IjU1LjA1IiB5PSIxODUuNDkiIHdpZHRoPSIxMTYuMzMiIGhlaWdodD0iMzQuMDQxIiBzdHJva2Utd2lkdGg9IjcuOTgyIi8+PHBhdGggZD0ibTEwMC42NCAxNDguMjcgMWUtNSAxMy40NzUgNjIuNzI5IDIyLjIyMiA0LjI0MTYtMTEuOTcyeiIgc3Ryb2tlLXdpZHRoPSI3Ljk4MiIvPjxwYXRoIGQ9Im01NS4wNSAxNTEuMzQtNGUtNiAxNS4zNTYgNzguMjY1IDI4LjIyNiAxMC42ODQtMTEuNTAzeiIgc3Ryb2tlLXdpZHRoPSIxMi43OTkiLz48cmVjdCB4PSIxMzguNDIiIHk9IjE4Mi43MSIgd2lkdGg9IjEzLjY5MyIgaGVpZ2h0PSI0LjE5NzMiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48cGF0aCBkPSJtNTUuMDUgMTcxLjM0IDVlLTYgMjEuMjkxIDMzLjk2IDEyLjQ5MSA2Ljg5NzItMTguNzUzeiIgc3Ryb2tlLXdpZHRoPSI4Ljk0NjciLz48L2c+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMS42NjM1IDAgMCAxLjY2MzUgMTUyLjI1IC02MC45MjIpIj48Y2lyY2xlIGN4PSIxLjk1MzMiIGN5PSIxMDIuNDUiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9IjMuNzgxNCIgY3k9IjEwOC41MiIgcj0iMi45MDY3Ii8+PGNpcmNsZSBjeD0iMS45OTk4IiBjeT0iMTA1Ljg4IiByPSIyLjkwNjciLz48Y2lyY2xlIGN4PSIxLjE4NDMiIGN5PSIxMDcuMDEiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9Ii01LjAwNTkiIGN5PSI5NS41NzYiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii00LjQyOTgiIGN5PSIxMDAuOTkiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii0zMS42NDYiIGN5PSI5NC4yMzIiIHI9IjYuODcxOCIvPjxjaXJjbGUgY3g9Ii0zMy45MzYiIGN5PSIxMDYuNDIiIHI9IjQuNjYzNiIvPjxjaXJjbGUgY3g9Ii0zMC4xNzgiIGN5PSIxMDYuMjMiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii0zNi45NDciIGN5PSIxMDQuNTIiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii00Ny44OCIgY3k9IjEwNS4zMSIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUwLjgyOSIgY3k9IjEwNC4zNyIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUxLjI1MSIgY3k9IjEwMC43NiIgcj0iNS41NDA4Ii8+PGNpcmNsZSBjeD0iLTUyLjQ0OCIgY3k9IjkzLjAxNiIgcj0iMS41NTQ2Ii8+PGNpcmNsZSBjeD0iLTQ5LjU5OSIgY3k9IjkyLjA0MSIgcj0iMS45NjkxIi8+PGVsbGlwc2UgY3g9Ii00NS43OTEiIGN5PSI5My4xMjIiIHJ4PSIzLjczNTYiIHJ5PSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItNDIuMzk2IiBjeT0iOTMuOTY3IiByPSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItMzguNzMiIGN5PSI5My42NjUiIHI9IjEuOTY5MSIvPjxjaXJjbGUgY3g9Ii0xMS43NTYiIGN5PSIxMDYuNTkiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xNC43MDUiIGN5PSIxMDUuNDYiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xOS45NTIiIGN5PSIxMDEuMTgiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0yNi44MjIiIGN5PSIxMDEuNSIgcj0iNC42MjMyIi8+PGNpcmNsZSBjeD0iLTEyLjA1IiBjeT0iODcuNzMxIiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNS45NzU4IiBjeT0iOTAuMTQ5IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNi45NjI4IiBjeT0iODguNzI1IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItMTQuODc0IiBjeT0iOTEuMjM3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMTcuMDY1IiBjeT0iOTMuNzc2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItNDMuNTQ0IiBjeT0iMTAzLjE3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjAuOTc4IiBjeT0iOTcuNTI1IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjUuNzQ3IiBjeT0iOTYuMTk2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItOS42MzA0IiBjeT0iODkuMzU2IiByPSIyLjIyMTQiLz48Y2lyY2xlIGN4PSItNTEuMTc1IiBjeT0iOTYuMzEyIiByPSIyLjIyMTQiLz48ZWxsaXBzZSBjeD0iMy42MzY2IiBjeT0iMTEyLjkzIiByeD0iMy4yOTc3IiByeT0iNy4yNjQ5Ii8+PHBhdGggZD0ibS0wLjI0ODI4IDEwNy4wOGMtMS41NWUtNiAyLjU1MzMtMS44MzE4IDAuMjMyMTUtNC4zODUyIDAuMjMyMTVzLTQuODYxMyAyLjMyMTItNC44NjEzLTAuMjMyMTVjLTRlLTYgLTIuNTUzMyAyLjA2OTktNC42MjMyIDQuNjIzMi00LjYyMzIgMi41NTMzIDAgNC42MjMyIDIuMDY5OSA0LjYyMzIgNC42MjMyeiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjQyMzUiLz48cGF0aCBkPSJtLTUwLjQ2IDkyLjcxLTEuNDQyNCAwLjQ0OTcyLTAuMDYxNzggMi42MjM0czAuOTA3NzMgMi44MzE2IDEuMDQyNSAzLjA2MDdjMC4xMzQ3NiAwLjIyOTEgMi42MDk0IDMuNDY4IDIuNjA5NCAzLjQ2OGw1LjIzODEgMC40OTM1NyAzLjcyMDMgMS4yNTE0IDMuNzY4IDAuMjE4NzFzNC44MTEyIDEuMjc1MSA1LjIzNzMgMC44MjI0N2MwLjQyNjA2LTAuNDUyNjYgMS40NDg4LTUuMDU0MiAxLjQxMzYtNS4zNTQ1LTAuMDM1MTYtMC4zMDAzNC0zLjM5NTctMS43NzQ1LTMuMzk1Ny0xLjc3NDVsLTMuODQwNS0yLjU0NzItMS42MjUtMS4yMTM0LTIuOTQ0Ni0wLjEwMDkycy0yLjc2MjctMC4zNTA3MS0zLjAzMTQtMC41MTY0NWMtMC4yNjg3Mi0wLjE2NTc1LTMuMTkxNC0wLjc2NTgtMy4zNDczLTAuNzY1OC0wLjE1NTg4IDAtMy4zNDA1LTAuMTE1My0zLjM0MDUtMC4xMTUzeiIvPjxwYXRoIGQ9Im0tMjAuMTk2IDk2LjUwNyAyLjkwNTQgNy4xMTYxIDQuOTYzNiAyLjIxMzUgNy4yMjgyLTAuMzU5MDkgNS4zOTc1IDAuNDAyODVzMS4xNDY1LTIuNDc2MyAxLjE2NjYtMi42Mzg1YzAuMDIwMTA4LTAuMTYyMjMtMi4yNDgzLTEuODA5OC0yLjI0ODMtMS44MDk4bC0xLjQ3OTgtMi4xNjU2LTAuMjEyNTItMi43NjQ5cy0xLjUxOTQtMi4zOTMzLTEuNTIyOC0yLjU1NTVjLTAuMDAzMzMtMC4xNjIxNy0yLjYyMjktNC4yNzMyLTIuNjIyOS00LjI3MzJsLTUuMjE1OS0wLjA2MjAzLTUuMTcyNCAzLjUyOTV6Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.54348" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="56" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0NC43OG1tIiBoZWlnaHQ9Ijk1LjM2M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDQuNzggOTUuMzYzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNi43MjcgLTEwNi4yNykiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE3MS40NyAxMDYuMjd2OTUuMzYzIiBzdHJva2Utd2lkdGg9IjIwLjA3OSIvPjxwYXRoIGQ9Im0xNzEuNDcgMTk1LjQ5aC0xMjguNjF2LTQzLjcxNGwyMy4xNDQtMTQuMTQ5IDEwLjU5MiAxOS4yMjQgMjguNjg0LTE5LjcyNyAxMi42MTEgMjAuNTczIDMwLjU5OS0yMi41MSAxOC42ODggMzEuNTQiIHN0cm9rZS13aWR0aD0iMTIuMjY5Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="57" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43NG1tIiBoZWlnaHQ9IjEyMy4wN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzQgMTIzLjA3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40MDkgLTk1LjY1NCkiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGcgc3Ryb2tlLXdpZHRoPSI4LjgxMiI+PHBhdGggZD0ibTQ5LjgxNSAxNzAuOTN2NDMuMzg2aDI4LjYzOXYtMzMuNzg1aDIyLjM0NiIvPjxwYXRoIGQ9Im0xNTAuNjMgMTcwLjkzdjQzLjM4NmgtMjguNjM5di0zMy43ODVoLTIyLjM0NiIvPjxwYXRoIGQ9Im00OS44MTUgMTcwLjkzczguOTczOS0xNS41ODIgMTUuODI2LTIyLjQzNGM5LjM0NzQtOS4zNDc0IDIxLjk0LTE4LjMzMyAzNS4xNTktMTguMzQ2IDEzLjI3LTAuMDEzMSAyNS45NDYgOC45NjI4IDM1LjMyOSAxOC4zNDYgNi42MTk2IDYuNjE5NiAxNC40OTggMjIuNDM0IDE0LjQ5OCAyMi40MzQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Im0xNTAuNjMgMjE0LjMyaDI3LjkyMXYtODEuMzUyaC0zOC44NHYxNi4yMDgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz48L2c+PHBhdGggZD0ibTExOC4yMSAxMzQuMTF2LTEyLjU0M2gyMi40MTciIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS13aWR0aD0iNy41MTUiLz48cGF0aCBkPSJtMTc4LjQgMTMxLjQ3YzAtMTAuNjQzLTguNjI4Mi0xOS4yNzItMTkuMjcyLTE5LjI3MnMtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2Utd2lkdGg9IjkuNTA4Ii8+PHBhdGggZD0ibTE1Ni43NiAxMTYuODFjLTEuMDkxNS05LjQ3MTktOC42NDU0LTE2LjU0Ny0xOC40OC0xNi41NDctMTAuNjQzIDAtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuMjA4Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="58" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43OW1tIiBoZWlnaHQ9IjEyMy43OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzkgMTIzLjc5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS4zNTggLTkxLjgyNikiPjxnPjxyZWN0IHg9IjE1OC43OCIgeT0iOTEuODI2IiB3aWR0aD0iMTMuMjYyIiBoZWlnaHQ9Ijg2LjE3Ii8+PHJlY3QgeD0iMTM4LjA4IiB5PSI5MS44MjYiIHdpZHRoPSIxMy4yNjIiIGhlaWdodD0iODYuMTciLz48cmVjdCB4PSIxMTMuMTIiIHk9IjkxLjgyNiIgd2lkdGg9IjEzLjI2MiIgaGVpZ2h0PSI4Ni4xNyIvPjxwYXRoIGQ9Im00NS44ODggMTc1LjcxLTAuNTI5MTcgMC41MjkxNnYzOS4zNzRoMTM3Ljc5di0zOS45MDR6bTQuNjUxOSA1LjI1MDhoMjIuNzI5djYuODk3OGgtMjIuNzI5em0yNy45NzkgMGgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bTI3LjkzMiAwaDE5LjExOXY2Ljg5NzhoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3OGgtMjIuNzI5em0tNzYuNzE2IDExLjI1MmgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bS01Mi4zNDcgMC4zNjc5M2gyMi43Mjl2Ni44OTczaC0yMi43Mjl6bTgwLjI3OSAwaDE5LjExOXY2Ljg5NzNoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3M2gtMjIuNzI5eiIvPjxwYXRoIGQ9Im03MC40MTEgMTUxLjE4LTEyLjkxNCAxMi45MTQtMTIuMTM4IDEyLjEzOWgyNS4wNTN6Ii8+PHBhdGggZD0ibTk0LjkzNSAxNTEuMTgtMTIuOTE0IDEyLjkxNC0xMi4xMzggMTIuMTM5aDI1LjA1M3oiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="59" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzOS43N21tIiBoZWlnaHQ9IjEyNS42NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzkuNzcgMTI1LjY1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41ODcgLTgyLjMxMykiPjxnPjxjaXJjbGUgY3g9IjkzLjM3MiIgY3k9IjE5NS4wOCIgcj0iMTIuODgzIi8+PGNpcmNsZSBjeD0iMTM0Ljg2IiBjeT0iMTk1LjA4IiByPSIxMi44ODMiLz48cGF0aCBkPSJtNDEuNTg3IDEyMy44NWgxMzkuNzdsLTI2LjMzOSA1Ny43OTZoLTg3LjA3NHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOS41MDgiLz48Y2lyY2xlIGN4PSI4MS4wMzYiIGN5PSIxMjAuNTYiIHI9IjIwLjU2OCIvPjxjaXJjbGUgY3g9IjE0Mi41NSIgY3k9IjEyMC41NiIgcj0iMjAuNTY4Ii8+PHBhdGggZD0ibTExMS40NyA4Mi4zMTNhMjAuNTY4IDIwLjU2OCAwIDAgMC0yMC41NjggMjAuNTY4aDQxLjEzN2EyMC41NjggMjAuNTY4IDAgMCAwLTIwLjU2OC0yMC41Njh6Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzMi4xNm1tIiBoZWlnaHQ9IjEyMy44Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzIuMTYgMTIzLjg2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4yMTkgLTkxLjcyMSkiPjxnPjxyZWN0IHg9IjE2MS45NyIgeT0iOTEuNzIxIiB3aWR0aD0iMTYuNDEiIGhlaWdodD0iMTIzLjg2Ii8+PHJlY3QgeD0iNDYuMjIiIHk9IjE2OC4yNSIgd2lkdGg9IjEzMi4xNiIgaGVpZ2h0PSI0Ny4zMjgiLz48cmVjdCB4PSIxNDAuMDQiIHk9IjkxLjcyMSIgd2lkdGg9IjE2LjQxIiBoZWlnaHQ9IjEyMy44NiIvPjxwYXRoIGQ9Im03NS42NDkgMTM4LjczLTI5LjQyOSAyOS40Mjl2MTMuOTU5aDI5LjQyOXoiLz48cGF0aCBkPSJtMTA1LjA4IDEzOC43My0yOS40MjkgMjkuNDI5djEzLjk1OWgyOS40Mjl6Ii8+PHBhdGggZD0ibTEzNC41MSAxMzguNzMtMjkuNDI5IDI5LjQyOXYxMy45NTloMjkuNDI5eiIvPjxyZWN0IHg9IjQ2LjIxOSIgeT0iMTY4LjI1IiB3aWR0aD0iMTMyLjE2IiBoZWlnaHQ9IjEzLjc2OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="60" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="61" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5OS42NW1tIiBoZWlnaHQ9IjEzMS4yN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTkuNjUgMTMxLjI3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02LjY4NDcgLTk0LjExNykiPjxyZWN0IHg9IjE4NS4xNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjEuMTc2IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjEwMi4yNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjIuNTU3IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjExNC4zIiB5PSIyMTEuNDQiIHdpZHRoPSI3Ny4zMjUiIGhlaWdodD0iOS42MjExIi8+PHJlY3QgeD0iMTM4LjU5IiB5PSIxOTUuNjYiIHdpZHRoPSIzMS44ODMiIGhlaWdodD0iMTcuODMyIi8+PHJlY3QgeD0iMTEzLjMxIiB5PSIxNDguNTYiIHdpZHRoPSI5My4wMjEiIGhlaWdodD0iNTEuNjA3Ii8+PHJlY3QgeD0iMTY5LjQ2IiB5PSIxMzkuODQiIHdpZHRoPSIzNi44NzQiIGhlaWdodD0iMTcuNDQyIi8+PHBhdGggZD0ibTExOC4zMyAxMzAuODN2MjQuNTM3aDI0Ljk2MXYtMjQuNTM3em02LjI3MiA2LjI3ODJoOC43OTMzdjExLjQ0OWgtOC43OTMzeiIvPjxwYXRoIGQ9Im0xMjAuMyAxNDQuNzhoLTEwLjg0NmwtMTMuNjAxLTE2LjE5MyAyLjIyODktMy40NDg3aDEwLjAyOGwzLjgwOTctMy42NDM5LTAuMjIyMDctMi40ODQ2IDcuMDQ0Ni01LjcxMTggMi4xMDcyIDIuMzEzMyAyLjIxMjktMC43NTE1OHYtOC4xMTJsLTIuMTM0OC0xLjkzODQtMy4xMTA4IDAuMzI4NDV2LTQuNDQ0M2wtMi4xODc1LTMuMjE3NmgtNi4yNTE1bC0yMi4zNDYgMjQuMzczaC04LjQ2ODJsLTI3LjczNS0yNy43MjloLTkuNDhsLTQuMzY1NCA1Ljg1ODkgMjkuMTA5IDI5LjY1N2g1LjI3MThsMi4xOTYyIDIuMTYydjIuOTcwNGwtMi40MTU1IDIuMTI3OWgtOS4zMzc2bC0yMS4zOTggMjEuMjEyaC0xOS45MzRsLTEzLjc5MSAyMi41Nzl2My45MjA4aDMyLjU3OHYtNC43MTQxaDcuMTM2MnYtMTcuNDgzbDI3LjY0NC0yMC40MjdoMTIuOTAybDI5LjIxNiAyNC4xNDl6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="62" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5NC41NW1tIiBoZWlnaHQ9IjE5MS4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTQuNTUgMTkxLjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjk2MTggLTUzLjM3MikiPjxnPjxyZWN0IHg9IjMuOTYxOCIgeT0iMjE2Ljk4IiB3aWR0aD0iMTk0LjU1IiBoZWlnaHQ9IjI3LjcxOCIvPjxyZWN0IHg9IjEzNi4wNSIgeT0iOTAuNDc1IiB3aWR0aD0iNDEuOTcyIiBoZWlnaHQ9IjEzNS43NiIgcnk9IjQuODQwOCIvPjxyZWN0IHg9IjcxLjcxMiIgeT0iOTAuNDc1IiB3aWR0aD0iNDYuNjY5IiBoZWlnaHQ9IjEzNy45MiIgcnk9IjcuNzI5MSIvPjxyZWN0IHg9IjIzLjI4MiIgeT0iOTAuNDc1IiB3aWR0aD0iMjIuODIyIiBoZWlnaHQ9IjEzNS40NCIgcnk9IjUuMTgyOSIvPjwvZz48cGF0aCBkPSJtMTU4LjAyIDk0LjgxNWMxLjRlLTQgLTE3LjI2LTEzLjc5Ni0zMS4yNTMtMzAuODE1LTMxLjI1My0xNy4wMTktMS40MmUtNCAtMzAuODE1IDEzLjk5Mi0zMC44MTUgMzEuMjUzIDAuMDAyNCAwLjcwNzYyIDAuMDI4NDQgMS40MTUgMC4wNzgxNiAyLjEyMDgiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMy4yIiBzdHJva2Utd2lkdGg9IjIwLjM4MSIvPjxwYXRoIGQ9Im05Ni45MzggOTQuNzc2YzEuNGUtNCAtMTcuMjE0LTEzLjk1NS0zMS4xNjktMzEuMTY5LTMxLjE2OS0xNy4yMTQtMS40MWUtNCAtMzEuMTY5IDEzLjk1NS0zMS4xNjkgMzEuMTY5IDAuMDAyNCAwLjcwNTczIDAuMDI4NzcgMS40MTEyIDAuMDc5MDYgMi4xMTUxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuMiIgc3Ryb2tlLXdpZHRoPSIyMC40NyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.28779" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="63" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4MC42OG1tIiBoZWlnaHQ9IjE4Ni40N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODAuNjggMTg2LjQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05Ljg2NjQgLTU1LjgzNikiPjxyZWN0IHg9IjE4LjUzNyIgeT0iMTc1LjExIiB3aWR0aD0iMTM2LjY0IiBoZWlnaHQ9IjY3LjE5MyIgcnk9IjAiLz48cmVjdCB4PSIxNjQuMzUiIHk9IjEyOS4yNCIgd2lkdGg9IjI2LjE4OSIgaGVpZ2h0PSIxMTMuMDYiIHJ5PSIwIi8+PGNpcmNsZSBjeD0iMTcyLjYzIiBjeT0iMTA2LjMzIiByPSIxMi44MDEiLz48Y2lyY2xlIGN4PSIxNjUuNzIiIGN5PSI5Ny4zMzMiIHI9IjEyLjgwMSIvPjxjaXJjbGUgY3g9IjE0OC42NyIgY3k9IjEwNy4xMyIgcj0iOS4xMzM1Ii8+PGNpcmNsZSBjeD0iMTM3LjMzIiBjeT0iMTA0LjY4IiByPSI5LjEzMzUiLz48Y2lyY2xlIGN4PSIxNDkuNjYiIGN5PSI4NC4wODEiIHI9IjE0LjYxNyIvPjxjaXJjbGUgY3g9IjExNC42MSIgY3k9IjEwMi42MiIgcj0iMTMuMzc4Ii8+PGNpcmNsZSBjeD0iMTI5LjQiIGN5PSI4MC43OTciIHI9IjguODg1NSIvPjxjaXJjbGUgY3g9IjExOC4zNiIgY3k9IjY3LjQ5NCIgcj0iMTEuNjU4Ii8+PGNpcmNsZSBjeD0iOTcuODAxIiBjeT0iODYuNTA0IiByPSIxMy4wMDUiLz48Y2lyY2xlIGN4PSI5Mi44MDIiIGN5PSI4MC45NzEiIHI9IjEzLjAwNSIvPjxjaXJjbGUgY3g9IjkzLjY5OSIgY3k9IjYzLjc4NSIgcj0iNy4yNjI0Ii8+PGNpcmNsZSBjeD0iMTAwLjU5IiBjeT0iNjcuNjY2IiByPSI3LjI2MjQiLz48Y2lyY2xlIGN4PSIxMjguOTYiIGN5PSI5OS45NDYiIHI9IjcuMjYyNCIvPjxyZWN0IHg9IjEwMC43NCIgeT0iNjguNDg3IiB3aWR0aD0iMjEuNjAxIiBoZWlnaHQ9IjI0LjYzNCIvPjxyZWN0IHg9IjExOS45MyIgeT0iODMuMTkiIHdpZHRoPSIzNC41OSIgaGVpZ2h0PSIxNy4yNTUiLz48Y2lyY2xlIGN4PSI2MC40MjQiIGN5PSI4Mi44MTkiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjU3LjExMyIgY3k9Ijk3Ljc2MyIgcj0iMTUuMjE3Ii8+PGNpcmNsZSBjeD0iMzcuODI2IiBjeT0iMTAxLjc2IiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSIyNS4wODMiIGN5PSI4MC44MDgiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjMyLjU4OCIgY3k9Ijk0LjcyIiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSI0Mi45NjciIGN5PSI4OS40MjMiIHI9IjE1LjIxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="64" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3OC4xM21tIiBoZWlnaHQ9IjExNy45NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzguMTMgMTE3Ljk0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTIzLjg2NSkiPjxwYXRoIGQ9Im0yMy43NzEgMjMuODY1djYyLjQ3M2gtMC4wMDIxYzEuMDllLTQgMC4wMjc2MSAwLjAwMjEgMC4wNTQ4MSAwLjAwMjEgMC4wODI1djIzLjI1MWMwIDEyLjE2LTEwLjU5IDIxLjk1Ny0yMy43NzEgMjIuMDI2djEwLjEwNGg5NS42OTl2LTEwLjEwNGMtMTMuMTgyLTAuMDY5MS0yMy43NzEtOS44NjYtMjMuNzcxLTIyLjAyNnYtMjMuMjUxYzAtMC4wMjc3IDJlLTMgLTAuMDU0ODkgMC4wMDIxLTAuMDgyNWgtMC4wMDIxdi02Mi40NzN6Ii8+PHBhdGggZD0ibTEyMS43NCA0OS4wM3Y0OS4xNDNoLTJlLTNjOGUtNSAwLjAyMTcgMmUtMyAwLjA0MzA2IDJlLTMgMC4wNjQ5MnYxOC4yODljMCA5LjU2NTctOC4zMDI3IDE3LjI3Mi0xOC42MzggMTcuMzI3djcuOTQ4NGg3NS4wMzJ2LTcuOTQ4NGMtMTAuMzM1LTAuMDU0My0xOC42MzgtNy43NjA5LTE4LjYzOC0xNy4zMjd2LTE4LjI4OWMwLTAuMDIxNzggMmUtMyAtMC4wNDMxNCAyZS0zIC0wLjA2NDkyaC0yZS0zdi00OS4xNDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0.40000000000000002" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="65" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS4zbW0iIGhlaWdodD0iMTM5Ljk0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OS4zIDEzOS45NCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzIuMjYzIC03Ni44ODQpIj48Y2lyY2xlIGN4PSI3OS40OTEiIGN5PSIxOTUuOTgiIHI9IjE2Ljg1IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48Y2lyY2xlIGN4PSIxNTQuOCIgY3k9IjE5NS45OCIgcj0iMTYuODUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3Ljk4MTUiLz48Zz48cmVjdCB4PSIxMDMuMzUiIHk9IjE4Mi42MiIgd2lkdGg9IjI1LjU0OSIgaGVpZ2h0PSIxNi4yMjIiLz48cGF0aCBkPSJtMzIuMjYzIDE0OS4wOHY0Mi43OThoMjEuOTlhMjQuODI3IDI0LjgyNyAwIDAgMSAyMC4wMzMtMjAuNTk2di0yMi4yMDN6bTQuNzY1MSA1LjAwMjhoMTcuNjI3djIwLjEzM2gtMTcuNjI3eiIvPjxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDQwLjE1MykiIGQ9Im0xNDUuMDcgNi43OTExLTMuOWUtNCA0MS4yOSA2NS4wMzktMi42ZS01IDI5LjM2Ny0yNC43NzYgMi45ZS00IC0xNi41MTR6Ii8+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoMzkuODQ5KSIgZD0ibTE3MS4wMSA0My41NTUtMi45ZS00IDUuNDU3MSA0LjQyMDMgMmUtNSAyZS01IDI1LjQ5IDExLjgwNS0yLjI1ZS00IDIuM2UtNCAtMjUuNDI4IDUuMTA3OCAzLjU4ZS00IDVlLTUgLTUuNTE5NXoiLz48cGF0aCBkPSJtMTcxLjEgMTUzLjIzLTEyLjk1MiAxOC45OTloOS44NjI0bDguNTU0NSAxMC45OTIgNS4wMDE4IDAuMzM2OTN2LTE5Ljc5NWwtMi45MDczLTQuMTU2M3oiLz48cGF0aCBkPSJtMTEzLjAyIDEwNC4yNC02LjUyMjctNS41MDI5LTIzLjEzMi0xOS45MDUtOC41MjY2LTEuOTQ2NiAwLjA1MzA4OSA4LjIyMDcgMjUuNjIxIDIwLjcyNSA0LjQ4MzUgNS4xNzQyeiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="66" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzMi4xNm1tIiBoZWlnaHQ9IjEyMy44Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzIuMTYgMTIzLjg2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4yMTkgLTkxLjcyMSkiPjxnPjxyZWN0IHg9IjE2MS45NyIgeT0iOTEuNzIxIiB3aWR0aD0iMTYuNDEiIGhlaWdodD0iMTIzLjg2Ii8+PHJlY3QgeD0iNDYuMjIiIHk9IjE2OC4yNSIgd2lkdGg9IjEzMi4xNiIgaGVpZ2h0PSI0Ny4zMjgiLz48cmVjdCB4PSIxNDAuMDQiIHk9IjkxLjcyMSIgd2lkdGg9IjE2LjQxIiBoZWlnaHQ9IjEyMy44NiIvPjxwYXRoIGQ9Im03NS42NDkgMTM4LjczLTI5LjQyOSAyOS40Mjl2MTMuOTU5aDI5LjQyOXoiLz48cGF0aCBkPSJtMTA1LjA4IDEzOC43My0yOS40MjkgMjkuNDI5djEzLjk1OWgyOS40Mjl6Ii8+PHBhdGggZD0ibTEzNC41MSAxMzguNzMtMjkuNDI5IDI5LjQyOXYxMy45NTloMjkuNDI5eiIvPjxyZWN0IHg9IjQ2LjIxOSIgeT0iMTY4LjI1IiB3aWR0aD0iMTMyLjE2IiBoZWlnaHQ9IjEzLjc2OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="67" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNi4zM21tIiBoZWlnaHQ9IjEzOC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTYuMzMgMTM4LjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NS4wNSAtODEuMjY0KSI+PGc+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iMTQ4LjM2IiB5PSIxMjYuNDUiIHdpZHRoPSIyMy4wMTUiIGhlaWdodD0iOTMuMDgxIiBzdHJva2Utd2lkdGg9IjcuNTQ3NCIvPjxyZWN0IHg9IjU1LjA1IiB5PSIxODUuNDkiIHdpZHRoPSIxMTYuMzMiIGhlaWdodD0iMzQuMDQxIiBzdHJva2Utd2lkdGg9IjcuOTgyIi8+PHBhdGggZD0ibTEwMC42NCAxNDguMjcgMWUtNSAxMy40NzUgNjIuNzI5IDIyLjIyMiA0LjI0MTYtMTEuOTcyeiIgc3Ryb2tlLXdpZHRoPSI3Ljk4MiIvPjxwYXRoIGQ9Im01NS4wNSAxNTEuMzQtNGUtNiAxNS4zNTYgNzguMjY1IDI4LjIyNiAxMC42ODQtMTEuNTAzeiIgc3Ryb2tlLXdpZHRoPSIxMi43OTkiLz48cmVjdCB4PSIxMzguNDIiIHk9IjE4Mi43MSIgd2lkdGg9IjEzLjY5MyIgaGVpZ2h0PSI0LjE5NzMiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48cGF0aCBkPSJtNTUuMDUgMTcxLjM0IDVlLTYgMjEuMjkxIDMzLjk2IDEyLjQ5MSA2Ljg5NzItMTguNzUzeiIgc3Ryb2tlLXdpZHRoPSI4Ljk0NjciLz48L2c+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMS42NjM1IDAgMCAxLjY2MzUgMTUyLjI1IC02MC45MjIpIj48Y2lyY2xlIGN4PSIxLjk1MzMiIGN5PSIxMDIuNDUiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9IjMuNzgxNCIgY3k9IjEwOC41MiIgcj0iMi45MDY3Ii8+PGNpcmNsZSBjeD0iMS45OTk4IiBjeT0iMTA1Ljg4IiByPSIyLjkwNjciLz48Y2lyY2xlIGN4PSIxLjE4NDMiIGN5PSIxMDcuMDEiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9Ii01LjAwNTkiIGN5PSI5NS41NzYiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii00LjQyOTgiIGN5PSIxMDAuOTkiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii0zMS42NDYiIGN5PSI5NC4yMzIiIHI9IjYuODcxOCIvPjxjaXJjbGUgY3g9Ii0zMy45MzYiIGN5PSIxMDYuNDIiIHI9IjQuNjYzNiIvPjxjaXJjbGUgY3g9Ii0zMC4xNzgiIGN5PSIxMDYuMjMiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii0zNi45NDciIGN5PSIxMDQuNTIiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii00Ny44OCIgY3k9IjEwNS4zMSIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUwLjgyOSIgY3k9IjEwNC4zNyIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUxLjI1MSIgY3k9IjEwMC43NiIgcj0iNS41NDA4Ii8+PGNpcmNsZSBjeD0iLTUyLjQ0OCIgY3k9IjkzLjAxNiIgcj0iMS41NTQ2Ii8+PGNpcmNsZSBjeD0iLTQ5LjU5OSIgY3k9IjkyLjA0MSIgcj0iMS45NjkxIi8+PGVsbGlwc2UgY3g9Ii00NS43OTEiIGN5PSI5My4xMjIiIHJ4PSIzLjczNTYiIHJ5PSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItNDIuMzk2IiBjeT0iOTMuOTY3IiByPSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItMzguNzMiIGN5PSI5My42NjUiIHI9IjEuOTY5MSIvPjxjaXJjbGUgY3g9Ii0xMS43NTYiIGN5PSIxMDYuNTkiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xNC43MDUiIGN5PSIxMDUuNDYiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xOS45NTIiIGN5PSIxMDEuMTgiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0yNi44MjIiIGN5PSIxMDEuNSIgcj0iNC42MjMyIi8+PGNpcmNsZSBjeD0iLTEyLjA1IiBjeT0iODcuNzMxIiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNS45NzU4IiBjeT0iOTAuMTQ5IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNi45NjI4IiBjeT0iODguNzI1IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItMTQuODc0IiBjeT0iOTEuMjM3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMTcuMDY1IiBjeT0iOTMuNzc2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItNDMuNTQ0IiBjeT0iMTAzLjE3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjAuOTc4IiBjeT0iOTcuNTI1IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjUuNzQ3IiBjeT0iOTYuMTk2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItOS42MzA0IiBjeT0iODkuMzU2IiByPSIyLjIyMTQiLz48Y2lyY2xlIGN4PSItNTEuMTc1IiBjeT0iOTYuMzEyIiByPSIyLjIyMTQiLz48ZWxsaXBzZSBjeD0iMy42MzY2IiBjeT0iMTEyLjkzIiByeD0iMy4yOTc3IiByeT0iNy4yNjQ5Ii8+PHBhdGggZD0ibS0wLjI0ODI4IDEwNy4wOGMtMS41NWUtNiAyLjU1MzMtMS44MzE4IDAuMjMyMTUtNC4zODUyIDAuMjMyMTVzLTQuODYxMyAyLjMyMTItNC44NjEzLTAuMjMyMTVjLTRlLTYgLTIuNTUzMyAyLjA2OTktNC42MjMyIDQuNjIzMi00LjYyMzIgMi41NTMzIDAgNC42MjMyIDIuMDY5OSA0LjYyMzIgNC42MjMyeiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjQyMzUiLz48cGF0aCBkPSJtLTUwLjQ2IDkyLjcxLTEuNDQyNCAwLjQ0OTcyLTAuMDYxNzggMi42MjM0czAuOTA3NzMgMi44MzE2IDEuMDQyNSAzLjA2MDdjMC4xMzQ3NiAwLjIyOTEgMi42MDk0IDMuNDY4IDIuNjA5NCAzLjQ2OGw1LjIzODEgMC40OTM1NyAzLjcyMDMgMS4yNTE0IDMuNzY4IDAuMjE4NzFzNC44MTEyIDEuMjc1MSA1LjIzNzMgMC44MjI0N2MwLjQyNjA2LTAuNDUyNjYgMS40NDg4LTUuMDU0MiAxLjQxMzYtNS4zNTQ1LTAuMDM1MTYtMC4zMDAzNC0zLjM5NTctMS43NzQ1LTMuMzk1Ny0xLjc3NDVsLTMuODQwNS0yLjU0NzItMS42MjUtMS4yMTM0LTIuOTQ0Ni0wLjEwMDkycy0yLjc2MjctMC4zNTA3MS0zLjAzMTQtMC41MTY0NWMtMC4yNjg3Mi0wLjE2NTc1LTMuMTkxNC0wLjc2NTgtMy4zNDczLTAuNzY1OC0wLjE1NTg4IDAtMy4zNDA1LTAuMTE1My0zLjM0MDUtMC4xMTUzeiIvPjxwYXRoIGQ9Im0tMjAuMTk2IDk2LjUwNyAyLjkwNTQgNy4xMTYxIDQuOTYzNiAyLjIxMzUgNy4yMjgyLTAuMzU5MDkgNS4zOTc1IDAuNDAyODVzMS4xNDY1LTIuNDc2MyAxLjE2NjYtMi42Mzg1YzAuMDIwMTA4LTAuMTYyMjMtMi4yNDgzLTEuODA5OC0yLjI0ODMtMS44MDk4bC0xLjQ3OTgtMi4xNjU2LTAuMjEyNTItMi43NjQ5cy0xLjUxOTQtMi4zOTMzLTEuNTIyOC0yLjU1NTVjLTAuMDAzMzMtMC4xNjIxNy0yLjYyMjktNC4yNzMyLTIuNjIyOS00LjI3MzJsLTUuMjE1OS0wLjA2MjAzLTUuMTcyNCAzLjUyOTV6Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.54348" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="68" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0NC43OG1tIiBoZWlnaHQ9Ijk1LjM2M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDQuNzggOTUuMzYzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNi43MjcgLTEwNi4yNykiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE3MS40NyAxMDYuMjd2OTUuMzYzIiBzdHJva2Utd2lkdGg9IjIwLjA3OSIvPjxwYXRoIGQ9Im0xNzEuNDcgMTk1LjQ5aC0xMjguNjF2LTQzLjcxNGwyMy4xNDQtMTQuMTQ5IDEwLjU5MiAxOS4yMjQgMjguNjg0LTE5LjcyNyAxMi42MTEgMjAuNTczIDMwLjU5OS0yMi41MSAxOC42ODggMzEuNTQiIHN0cm9rZS13aWR0aD0iMTIuMjY5Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="69" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43NG1tIiBoZWlnaHQ9IjEyMy4wN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzQgMTIzLjA3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40MDkgLTk1LjY1NCkiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGcgc3Ryb2tlLXdpZHRoPSI4LjgxMiI+PHBhdGggZD0ibTQ5LjgxNSAxNzAuOTN2NDMuMzg2aDI4LjYzOXYtMzMuNzg1aDIyLjM0NiIvPjxwYXRoIGQ9Im0xNTAuNjMgMTcwLjkzdjQzLjM4NmgtMjguNjM5di0zMy43ODVoLTIyLjM0NiIvPjxwYXRoIGQ9Im00OS44MTUgMTcwLjkzczguOTczOS0xNS41ODIgMTUuODI2LTIyLjQzNGM5LjM0NzQtOS4zNDc0IDIxLjk0LTE4LjMzMyAzNS4xNTktMTguMzQ2IDEzLjI3LTAuMDEzMSAyNS45NDYgOC45NjI4IDM1LjMyOSAxOC4zNDYgNi42MTk2IDYuNjE5NiAxNC40OTggMjIuNDM0IDE0LjQ5OCAyMi40MzQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Im0xNTAuNjMgMjE0LjMyaDI3LjkyMXYtODEuMzUyaC0zOC44NHYxNi4yMDgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz48L2c+PHBhdGggZD0ibTExOC4yMSAxMzQuMTF2LTEyLjU0M2gyMi40MTciIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS13aWR0aD0iNy41MTUiLz48cGF0aCBkPSJtMTc4LjQgMTMxLjQ3YzAtMTAuNjQzLTguNjI4Mi0xOS4yNzItMTkuMjcyLTE5LjI3MnMtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2Utd2lkdGg9IjkuNTA4Ii8+PHBhdGggZD0ibTE1Ni43NiAxMTYuODFjLTEuMDkxNS05LjQ3MTktOC42NDU0LTE2LjU0Ny0xOC40OC0xNi41NDctMTAuNjQzIDAtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuMjA4Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNi4zM21tIiBoZWlnaHQ9IjEzOC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTYuMzMgMTM4LjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NS4wNSAtODEuMjY0KSI+PGc+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iMTQ4LjM2IiB5PSIxMjYuNDUiIHdpZHRoPSIyMy4wMTUiIGhlaWdodD0iOTMuMDgxIiBzdHJva2Utd2lkdGg9IjcuNTQ3NCIvPjxyZWN0IHg9IjU1LjA1IiB5PSIxODUuNDkiIHdpZHRoPSIxMTYuMzMiIGhlaWdodD0iMzQuMDQxIiBzdHJva2Utd2lkdGg9IjcuOTgyIi8+PHBhdGggZD0ibTEwMC42NCAxNDguMjcgMWUtNSAxMy40NzUgNjIuNzI5IDIyLjIyMiA0LjI0MTYtMTEuOTcyeiIgc3Ryb2tlLXdpZHRoPSI3Ljk4MiIvPjxwYXRoIGQ9Im01NS4wNSAxNTEuMzQtNGUtNiAxNS4zNTYgNzguMjY1IDI4LjIyNiAxMC42ODQtMTEuNTAzeiIgc3Ryb2tlLXdpZHRoPSIxMi43OTkiLz48cmVjdCB4PSIxMzguNDIiIHk9IjE4Mi43MSIgd2lkdGg9IjEzLjY5MyIgaGVpZ2h0PSI0LjE5NzMiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48cGF0aCBkPSJtNTUuMDUgMTcxLjM0IDVlLTYgMjEuMjkxIDMzLjk2IDEyLjQ5MSA2Ljg5NzItMTguNzUzeiIgc3Ryb2tlLXdpZHRoPSI4Ljk0NjciLz48L2c+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMS42NjM1IDAgMCAxLjY2MzUgMTUyLjI1IC02MC45MjIpIj48Y2lyY2xlIGN4PSIxLjk1MzMiIGN5PSIxMDIuNDUiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9IjMuNzgxNCIgY3k9IjEwOC41MiIgcj0iMi45MDY3Ii8+PGNpcmNsZSBjeD0iMS45OTk4IiBjeT0iMTA1Ljg4IiByPSIyLjkwNjciLz48Y2lyY2xlIGN4PSIxLjE4NDMiIGN5PSIxMDcuMDEiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9Ii01LjAwNTkiIGN5PSI5NS41NzYiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii00LjQyOTgiIGN5PSIxMDAuOTkiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii0zMS42NDYiIGN5PSI5NC4yMzIiIHI9IjYuODcxOCIvPjxjaXJjbGUgY3g9Ii0zMy45MzYiIGN5PSIxMDYuNDIiIHI9IjQuNjYzNiIvPjxjaXJjbGUgY3g9Ii0zMC4xNzgiIGN5PSIxMDYuMjMiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii0zNi45NDciIGN5PSIxMDQuNTIiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii00Ny44OCIgY3k9IjEwNS4zMSIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUwLjgyOSIgY3k9IjEwNC4zNyIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUxLjI1MSIgY3k9IjEwMC43NiIgcj0iNS41NDA4Ii8+PGNpcmNsZSBjeD0iLTUyLjQ0OCIgY3k9IjkzLjAxNiIgcj0iMS41NTQ2Ii8+PGNpcmNsZSBjeD0iLTQ5LjU5OSIgY3k9IjkyLjA0MSIgcj0iMS45NjkxIi8+PGVsbGlwc2UgY3g9Ii00NS43OTEiIGN5PSI5My4xMjIiIHJ4PSIzLjczNTYiIHJ5PSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItNDIuMzk2IiBjeT0iOTMuOTY3IiByPSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItMzguNzMiIGN5PSI5My42NjUiIHI9IjEuOTY5MSIvPjxjaXJjbGUgY3g9Ii0xMS43NTYiIGN5PSIxMDYuNTkiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xNC43MDUiIGN5PSIxMDUuNDYiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xOS45NTIiIGN5PSIxMDEuMTgiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0yNi44MjIiIGN5PSIxMDEuNSIgcj0iNC42MjMyIi8+PGNpcmNsZSBjeD0iLTEyLjA1IiBjeT0iODcuNzMxIiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNS45NzU4IiBjeT0iOTAuMTQ5IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNi45NjI4IiBjeT0iODguNzI1IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItMTQuODc0IiBjeT0iOTEuMjM3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMTcuMDY1IiBjeT0iOTMuNzc2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItNDMuNTQ0IiBjeT0iMTAzLjE3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjAuOTc4IiBjeT0iOTcuNTI1IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjUuNzQ3IiBjeT0iOTYuMTk2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItOS42MzA0IiBjeT0iODkuMzU2IiByPSIyLjIyMTQiLz48Y2lyY2xlIGN4PSItNTEuMTc1IiBjeT0iOTYuMzEyIiByPSIyLjIyMTQiLz48ZWxsaXBzZSBjeD0iMy42MzY2IiBjeT0iMTEyLjkzIiByeD0iMy4yOTc3IiByeT0iNy4yNjQ5Ii8+PHBhdGggZD0ibS0wLjI0ODI4IDEwNy4wOGMtMS41NWUtNiAyLjU1MzMtMS44MzE4IDAuMjMyMTUtNC4zODUyIDAuMjMyMTVzLTQuODYxMyAyLjMyMTItNC44NjEzLTAuMjMyMTVjLTRlLTYgLTIuNTUzMyAyLjA2OTktNC42MjMyIDQuNjIzMi00LjYyMzIgMi41NTMzIDAgNC42MjMyIDIuMDY5OSA0LjYyMzIgNC42MjMyeiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjQyMzUiLz48cGF0aCBkPSJtLTUwLjQ2IDkyLjcxLTEuNDQyNCAwLjQ0OTcyLTAuMDYxNzggMi42MjM0czAuOTA3NzMgMi44MzE2IDEuMDQyNSAzLjA2MDdjMC4xMzQ3NiAwLjIyOTEgMi42MDk0IDMuNDY4IDIuNjA5NCAzLjQ2OGw1LjIzODEgMC40OTM1NyAzLjcyMDMgMS4yNTE0IDMuNzY4IDAuMjE4NzFzNC44MTEyIDEuMjc1MSA1LjIzNzMgMC44MjI0N2MwLjQyNjA2LTAuNDUyNjYgMS40NDg4LTUuMDU0MiAxLjQxMzYtNS4zNTQ1LTAuMDM1MTYtMC4zMDAzNC0zLjM5NTctMS43NzQ1LTMuMzk1Ny0xLjc3NDVsLTMuODQwNS0yLjU0NzItMS42MjUtMS4yMTM0LTIuOTQ0Ni0wLjEwMDkycy0yLjc2MjctMC4zNTA3MS0zLjAzMTQtMC41MTY0NWMtMC4yNjg3Mi0wLjE2NTc1LTMuMTkxNC0wLjc2NTgtMy4zNDczLTAuNzY1OC0wLjE1NTg4IDAtMy4zNDA1LTAuMTE1My0zLjM0MDUtMC4xMTUzeiIvPjxwYXRoIGQ9Im0tMjAuMTk2IDk2LjUwNyAyLjkwNTQgNy4xMTYxIDQuOTYzNiAyLjIxMzUgNy4yMjgyLTAuMzU5MDkgNS4zOTc1IDAuNDAyODVzMS4xNDY1LTIuNDc2MyAxLjE2NjYtMi42Mzg1YzAuMDIwMTA4LTAuMTYyMjMtMi4yNDgzLTEuODA5OC0yLjI0ODMtMS44MDk4bC0xLjQ3OTgtMi4xNjU2LTAuMjEyNTItMi43NjQ5cy0xLjUxOTQtMi4zOTMzLTEuNTIyOC0yLjU1NTVjLTAuMDAzMzMtMC4xNjIxNy0yLjYyMjktNC4yNzMyLTIuNjIyOS00LjI3MzJsLTUuMjE1OS0wLjA2MjAzLTUuMTcyNCAzLjUyOTV6Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.54348" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="70" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43OW1tIiBoZWlnaHQ9IjEyMy43OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzkgMTIzLjc5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS4zNTggLTkxLjgyNikiPjxnPjxyZWN0IHg9IjE1OC43OCIgeT0iOTEuODI2IiB3aWR0aD0iMTMuMjYyIiBoZWlnaHQ9Ijg2LjE3Ii8+PHJlY3QgeD0iMTM4LjA4IiB5PSI5MS44MjYiIHdpZHRoPSIxMy4yNjIiIGhlaWdodD0iODYuMTciLz48cmVjdCB4PSIxMTMuMTIiIHk9IjkxLjgyNiIgd2lkdGg9IjEzLjI2MiIgaGVpZ2h0PSI4Ni4xNyIvPjxwYXRoIGQ9Im00NS44ODggMTc1LjcxLTAuNTI5MTcgMC41MjkxNnYzOS4zNzRoMTM3Ljc5di0zOS45MDR6bTQuNjUxOSA1LjI1MDhoMjIuNzI5djYuODk3OGgtMjIuNzI5em0yNy45NzkgMGgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bTI3LjkzMiAwaDE5LjExOXY2Ljg5NzhoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3OGgtMjIuNzI5em0tNzYuNzE2IDExLjI1MmgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bS01Mi4zNDcgMC4zNjc5M2gyMi43Mjl2Ni44OTczaC0yMi43Mjl6bTgwLjI3OSAwaDE5LjExOXY2Ljg5NzNoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3M2gtMjIuNzI5eiIvPjxwYXRoIGQ9Im03MC40MTEgMTUxLjE4LTEyLjkxNCAxMi45MTQtMTIuMTM4IDEyLjEzOWgyNS4wNTN6Ii8+PHBhdGggZD0ibTk0LjkzNSAxNTEuMTgtMTIuOTE0IDEyLjkxNC0xMi4xMzggMTIuMTM5aDI1LjA1M3oiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="71" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzOS43N21tIiBoZWlnaHQ9IjEyNS42NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzkuNzcgMTI1LjY1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41ODcgLTgyLjMxMykiPjxnPjxjaXJjbGUgY3g9IjkzLjM3MiIgY3k9IjE5NS4wOCIgcj0iMTIuODgzIi8+PGNpcmNsZSBjeD0iMTM0Ljg2IiBjeT0iMTk1LjA4IiByPSIxMi44ODMiLz48cGF0aCBkPSJtNDEuNTg3IDEyMy44NWgxMzkuNzdsLTI2LjMzOSA1Ny43OTZoLTg3LjA3NHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOS41MDgiLz48Y2lyY2xlIGN4PSI4MS4wMzYiIGN5PSIxMjAuNTYiIHI9IjIwLjU2OCIvPjxjaXJjbGUgY3g9IjE0Mi41NSIgY3k9IjEyMC41NiIgcj0iMjAuNTY4Ii8+PHBhdGggZD0ibTExMS40NyA4Mi4zMTNhMjAuNTY4IDIwLjU2OCAwIDAgMC0yMC41NjggMjAuNTY4aDQxLjEzN2EyMC41NjggMjAuNTY4IDAgMCAwLTIwLjU2OC0yMC41Njh6Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="72" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="73" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5OS42NW1tIiBoZWlnaHQ9IjEzMS4yN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTkuNjUgMTMxLjI3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02LjY4NDcgLTk0LjExNykiPjxyZWN0IHg9IjE4NS4xNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjEuMTc2IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjEwMi4yNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjIuNTU3IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjExNC4zIiB5PSIyMTEuNDQiIHdpZHRoPSI3Ny4zMjUiIGhlaWdodD0iOS42MjExIi8+PHJlY3QgeD0iMTM4LjU5IiB5PSIxOTUuNjYiIHdpZHRoPSIzMS44ODMiIGhlaWdodD0iMTcuODMyIi8+PHJlY3QgeD0iMTEzLjMxIiB5PSIxNDguNTYiIHdpZHRoPSI5My4wMjEiIGhlaWdodD0iNTEuNjA3Ii8+PHJlY3QgeD0iMTY5LjQ2IiB5PSIxMzkuODQiIHdpZHRoPSIzNi44NzQiIGhlaWdodD0iMTcuNDQyIi8+PHBhdGggZD0ibTExOC4zMyAxMzAuODN2MjQuNTM3aDI0Ljk2MXYtMjQuNTM3em02LjI3MiA2LjI3ODJoOC43OTMzdjExLjQ0OWgtOC43OTMzeiIvPjxwYXRoIGQ9Im0xMjAuMyAxNDQuNzhoLTEwLjg0NmwtMTMuNjAxLTE2LjE5MyAyLjIyODktMy40NDg3aDEwLjAyOGwzLjgwOTctMy42NDM5LTAuMjIyMDctMi40ODQ2IDcuMDQ0Ni01LjcxMTggMi4xMDcyIDIuMzEzMyAyLjIxMjktMC43NTE1OHYtOC4xMTJsLTIuMTM0OC0xLjkzODQtMy4xMTA4IDAuMzI4NDV2LTQuNDQ0M2wtMi4xODc1LTMuMjE3NmgtNi4yNTE1bC0yMi4zNDYgMjQuMzczaC04LjQ2ODJsLTI3LjczNS0yNy43MjloLTkuNDhsLTQuMzY1NCA1Ljg1ODkgMjkuMTA5IDI5LjY1N2g1LjI3MThsMi4xOTYyIDIuMTYydjIuOTcwNGwtMi40MTU1IDIuMTI3OWgtOS4zMzc2bC0yMS4zOTggMjEuMjEyaC0xOS45MzRsLTEzLjc5MSAyMi41Nzl2My45MjA4aDMyLjU3OHYtNC43MTQxaDcuMTM2MnYtMTcuNDgzbDI3LjY0NC0yMC40MjdoMTIuOTAybDI5LjIxNiAyNC4xNDl6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="74" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5NC41NW1tIiBoZWlnaHQ9IjE5MS4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTQuNTUgMTkxLjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjk2MTggLTUzLjM3MikiPjxnPjxyZWN0IHg9IjMuOTYxOCIgeT0iMjE2Ljk4IiB3aWR0aD0iMTk0LjU1IiBoZWlnaHQ9IjI3LjcxOCIvPjxyZWN0IHg9IjEzNi4wNSIgeT0iOTAuNDc1IiB3aWR0aD0iNDEuOTcyIiBoZWlnaHQ9IjEzNS43NiIgcnk9IjQuODQwOCIvPjxyZWN0IHg9IjcxLjcxMiIgeT0iOTAuNDc1IiB3aWR0aD0iNDYuNjY5IiBoZWlnaHQ9IjEzNy45MiIgcnk9IjcuNzI5MSIvPjxyZWN0IHg9IjIzLjI4MiIgeT0iOTAuNDc1IiB3aWR0aD0iMjIuODIyIiBoZWlnaHQ9IjEzNS40NCIgcnk9IjUuMTgyOSIvPjwvZz48cGF0aCBkPSJtMTU4LjAyIDk0LjgxNWMxLjRlLTQgLTE3LjI2LTEzLjc5Ni0zMS4yNTMtMzAuODE1LTMxLjI1My0xNy4wMTktMS40MmUtNCAtMzAuODE1IDEzLjk5Mi0zMC44MTUgMzEuMjUzIDAuMDAyNCAwLjcwNzYyIDAuMDI4NDQgMS40MTUgMC4wNzgxNiAyLjEyMDgiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMy4yIiBzdHJva2Utd2lkdGg9IjIwLjM4MSIvPjxwYXRoIGQ9Im05Ni45MzggOTQuNzc2YzEuNGUtNCAtMTcuMjE0LTEzLjk1NS0zMS4xNjktMzEuMTY5LTMxLjE2OS0xNy4yMTQtMS40MWUtNCAtMzEuMTY5IDEzLjk1NS0zMS4xNjkgMzEuMTY5IDAuMDAyNCAwLjcwNTczIDAuMDI4NzcgMS40MTEyIDAuMDc5MDYgMi4xMTUxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuMiIgc3Ryb2tlLXdpZHRoPSIyMC40NyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.28779" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="75" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4MC42OG1tIiBoZWlnaHQ9IjE4Ni40N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODAuNjggMTg2LjQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05Ljg2NjQgLTU1LjgzNikiPjxyZWN0IHg9IjE4LjUzNyIgeT0iMTc1LjExIiB3aWR0aD0iMTM2LjY0IiBoZWlnaHQ9IjY3LjE5MyIgcnk9IjAiLz48cmVjdCB4PSIxNjQuMzUiIHk9IjEyOS4yNCIgd2lkdGg9IjI2LjE4OSIgaGVpZ2h0PSIxMTMuMDYiIHJ5PSIwIi8+PGNpcmNsZSBjeD0iMTcyLjYzIiBjeT0iMTA2LjMzIiByPSIxMi44MDEiLz48Y2lyY2xlIGN4PSIxNjUuNzIiIGN5PSI5Ny4zMzMiIHI9IjEyLjgwMSIvPjxjaXJjbGUgY3g9IjE0OC42NyIgY3k9IjEwNy4xMyIgcj0iOS4xMzM1Ii8+PGNpcmNsZSBjeD0iMTM3LjMzIiBjeT0iMTA0LjY4IiByPSI5LjEzMzUiLz48Y2lyY2xlIGN4PSIxNDkuNjYiIGN5PSI4NC4wODEiIHI9IjE0LjYxNyIvPjxjaXJjbGUgY3g9IjExNC42MSIgY3k9IjEwMi42MiIgcj0iMTMuMzc4Ii8+PGNpcmNsZSBjeD0iMTI5LjQiIGN5PSI4MC43OTciIHI9IjguODg1NSIvPjxjaXJjbGUgY3g9IjExOC4zNiIgY3k9IjY3LjQ5NCIgcj0iMTEuNjU4Ii8+PGNpcmNsZSBjeD0iOTcuODAxIiBjeT0iODYuNTA0IiByPSIxMy4wMDUiLz48Y2lyY2xlIGN4PSI5Mi44MDIiIGN5PSI4MC45NzEiIHI9IjEzLjAwNSIvPjxjaXJjbGUgY3g9IjkzLjY5OSIgY3k9IjYzLjc4NSIgcj0iNy4yNjI0Ii8+PGNpcmNsZSBjeD0iMTAwLjU5IiBjeT0iNjcuNjY2IiByPSI3LjI2MjQiLz48Y2lyY2xlIGN4PSIxMjguOTYiIGN5PSI5OS45NDYiIHI9IjcuMjYyNCIvPjxyZWN0IHg9IjEwMC43NCIgeT0iNjguNDg3IiB3aWR0aD0iMjEuNjAxIiBoZWlnaHQ9IjI0LjYzNCIvPjxyZWN0IHg9IjExOS45MyIgeT0iODMuMTkiIHdpZHRoPSIzNC41OSIgaGVpZ2h0PSIxNy4yNTUiLz48Y2lyY2xlIGN4PSI2MC40MjQiIGN5PSI4Mi44MTkiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjU3LjExMyIgY3k9Ijk3Ljc2MyIgcj0iMTUuMjE3Ii8+PGNpcmNsZSBjeD0iMzcuODI2IiBjeT0iMTAxLjc2IiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSIyNS4wODMiIGN5PSI4MC44MDgiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjMyLjU4OCIgY3k9Ijk0LjcyIiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSI0Mi45NjciIGN5PSI4OS40MjMiIHI9IjE1LjIxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="76" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3OC4xM21tIiBoZWlnaHQ9IjExNy45NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzguMTMgMTE3Ljk0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTIzLjg2NSkiPjxwYXRoIGQ9Im0yMy43NzEgMjMuODY1djYyLjQ3M2gtMC4wMDIxYzEuMDllLTQgMC4wMjc2MSAwLjAwMjEgMC4wNTQ4MSAwLjAwMjEgMC4wODI1djIzLjI1MWMwIDEyLjE2LTEwLjU5IDIxLjk1Ny0yMy43NzEgMjIuMDI2djEwLjEwNGg5NS42OTl2LTEwLjEwNGMtMTMuMTgyLTAuMDY5MS0yMy43NzEtOS44NjYtMjMuNzcxLTIyLjAyNnYtMjMuMjUxYzAtMC4wMjc3IDJlLTMgLTAuMDU0ODkgMC4wMDIxLTAuMDgyNWgtMC4wMDIxdi02Mi40NzN6Ii8+PHBhdGggZD0ibTEyMS43NCA0OS4wM3Y0OS4xNDNoLTJlLTNjOGUtNSAwLjAyMTcgMmUtMyAwLjA0MzA2IDJlLTMgMC4wNjQ5MnYxOC4yODljMCA5LjU2NTctOC4zMDI3IDE3LjI3Mi0xOC42MzggMTcuMzI3djcuOTQ4NGg3NS4wMzJ2LTcuOTQ4NGMtMTAuMzM1LTAuMDU0My0xOC42MzgtNy43NjA5LTE4LjYzOC0xNy4zMjd2LTE4LjI4OWMwLTAuMDIxNzggMmUtMyAtMC4wNDMxNCAyZS0zIC0wLjA2NDkyaC0yZS0zdi00OS4xNDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0.40000000000000002" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="77" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS4zbW0iIGhlaWdodD0iMTM5Ljk0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OS4zIDEzOS45NCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzIuMjYzIC03Ni44ODQpIj48Y2lyY2xlIGN4PSI3OS40OTEiIGN5PSIxOTUuOTgiIHI9IjE2Ljg1IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48Y2lyY2xlIGN4PSIxNTQuOCIgY3k9IjE5NS45OCIgcj0iMTYuODUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3Ljk4MTUiLz48Zz48cmVjdCB4PSIxMDMuMzUiIHk9IjE4Mi42MiIgd2lkdGg9IjI1LjU0OSIgaGVpZ2h0PSIxNi4yMjIiLz48cGF0aCBkPSJtMzIuMjYzIDE0OS4wOHY0Mi43OThoMjEuOTlhMjQuODI3IDI0LjgyNyAwIDAgMSAyMC4wMzMtMjAuNTk2di0yMi4yMDN6bTQuNzY1MSA1LjAwMjhoMTcuNjI3djIwLjEzM2gtMTcuNjI3eiIvPjxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDQwLjE1MykiIGQ9Im0xNDUuMDcgNi43OTExLTMuOWUtNCA0MS4yOSA2NS4wMzktMi42ZS01IDI5LjM2Ny0yNC43NzYgMi45ZS00IC0xNi41MTR6Ii8+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoMzkuODQ5KSIgZD0ibTE3MS4wMSA0My41NTUtMi45ZS00IDUuNDU3MSA0LjQyMDMgMmUtNSAyZS01IDI1LjQ5IDExLjgwNS0yLjI1ZS00IDIuM2UtNCAtMjUuNDI4IDUuMTA3OCAzLjU4ZS00IDVlLTUgLTUuNTE5NXoiLz48cGF0aCBkPSJtMTcxLjEgMTUzLjIzLTEyLjk1MiAxOC45OTloOS44NjI0bDguNTU0NSAxMC45OTIgNS4wMDE4IDAuMzM2OTN2LTE5Ljc5NWwtMi45MDczLTQuMTU2M3oiLz48cGF0aCBkPSJtMTEzLjAyIDEwNC4yNC02LjUyMjctNS41MDI5LTIzLjEzMi0xOS45MDUtOC41MjY2LTEuOTQ2NiAwLjA1MzA4OSA4LjIyMDcgMjUuNjIxIDIwLjcyNSA0LjQ4MzUgNS4xNzQyeiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="78" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzMi4xNm1tIiBoZWlnaHQ9IjEyMy44Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzIuMTYgMTIzLjg2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4yMTkgLTkxLjcyMSkiPjxnPjxyZWN0IHg9IjE2MS45NyIgeT0iOTEuNzIxIiB3aWR0aD0iMTYuNDEiIGhlaWdodD0iMTIzLjg2Ii8+PHJlY3QgeD0iNDYuMjIiIHk9IjE2OC4yNSIgd2lkdGg9IjEzMi4xNiIgaGVpZ2h0PSI0Ny4zMjgiLz48cmVjdCB4PSIxNDAuMDQiIHk9IjkxLjcyMSIgd2lkdGg9IjE2LjQxIiBoZWlnaHQ9IjEyMy44NiIvPjxwYXRoIGQ9Im03NS42NDkgMTM4LjczLTI5LjQyOSAyOS40Mjl2MTMuOTU5aDI5LjQyOXoiLz48cGF0aCBkPSJtMTA1LjA4IDEzOC43My0yOS40MjkgMjkuNDI5djEzLjk1OWgyOS40Mjl6Ii8+PHBhdGggZD0ibTEzNC41MSAxMzguNzMtMjkuNDI5IDI5LjQyOXYxMy45NTloMjkuNDI5eiIvPjxyZWN0IHg9IjQ2LjIxOSIgeT0iMTY4LjI1IiB3aWR0aD0iMTMyLjE2IiBoZWlnaHQ9IjEzLjc2OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="79" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNi4zM21tIiBoZWlnaHQ9IjEzOC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTYuMzMgMTM4LjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NS4wNSAtODEuMjY0KSI+PGc+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iMTQ4LjM2IiB5PSIxMjYuNDUiIHdpZHRoPSIyMy4wMTUiIGhlaWdodD0iOTMuMDgxIiBzdHJva2Utd2lkdGg9IjcuNTQ3NCIvPjxyZWN0IHg9IjU1LjA1IiB5PSIxODUuNDkiIHdpZHRoPSIxMTYuMzMiIGhlaWdodD0iMzQuMDQxIiBzdHJva2Utd2lkdGg9IjcuOTgyIi8+PHBhdGggZD0ibTEwMC42NCAxNDguMjcgMWUtNSAxMy40NzUgNjIuNzI5IDIyLjIyMiA0LjI0MTYtMTEuOTcyeiIgc3Ryb2tlLXdpZHRoPSI3Ljk4MiIvPjxwYXRoIGQ9Im01NS4wNSAxNTEuMzQtNGUtNiAxNS4zNTYgNzguMjY1IDI4LjIyNiAxMC42ODQtMTEuNTAzeiIgc3Ryb2tlLXdpZHRoPSIxMi43OTkiLz48cmVjdCB4PSIxMzguNDIiIHk9IjE4Mi43MSIgd2lkdGg9IjEzLjY5MyIgaGVpZ2h0PSI0LjE5NzMiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48cGF0aCBkPSJtNTUuMDUgMTcxLjM0IDVlLTYgMjEuMjkxIDMzLjk2IDEyLjQ5MSA2Ljg5NzItMTguNzUzeiIgc3Ryb2tlLXdpZHRoPSI4Ljk0NjciLz48L2c+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMS42NjM1IDAgMCAxLjY2MzUgMTUyLjI1IC02MC45MjIpIj48Y2lyY2xlIGN4PSIxLjk1MzMiIGN5PSIxMDIuNDUiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9IjMuNzgxNCIgY3k9IjEwOC41MiIgcj0iMi45MDY3Ii8+PGNpcmNsZSBjeD0iMS45OTk4IiBjeT0iMTA1Ljg4IiByPSIyLjkwNjciLz48Y2lyY2xlIGN4PSIxLjE4NDMiIGN5PSIxMDcuMDEiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9Ii01LjAwNTkiIGN5PSI5NS41NzYiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii00LjQyOTgiIGN5PSIxMDAuOTkiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii0zMS42NDYiIGN5PSI5NC4yMzIiIHI9IjYuODcxOCIvPjxjaXJjbGUgY3g9Ii0zMy45MzYiIGN5PSIxMDYuNDIiIHI9IjQuNjYzNiIvPjxjaXJjbGUgY3g9Ii0zMC4xNzgiIGN5PSIxMDYuMjMiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii0zNi45NDciIGN5PSIxMDQuNTIiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii00Ny44OCIgY3k9IjEwNS4zMSIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUwLjgyOSIgY3k9IjEwNC4zNyIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUxLjI1MSIgY3k9IjEwMC43NiIgcj0iNS41NDA4Ii8+PGNpcmNsZSBjeD0iLTUyLjQ0OCIgY3k9IjkzLjAxNiIgcj0iMS41NTQ2Ii8+PGNpcmNsZSBjeD0iLTQ5LjU5OSIgY3k9IjkyLjA0MSIgcj0iMS45NjkxIi8+PGVsbGlwc2UgY3g9Ii00NS43OTEiIGN5PSI5My4xMjIiIHJ4PSIzLjczNTYiIHJ5PSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItNDIuMzk2IiBjeT0iOTMuOTY3IiByPSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItMzguNzMiIGN5PSI5My42NjUiIHI9IjEuOTY5MSIvPjxjaXJjbGUgY3g9Ii0xMS43NTYiIGN5PSIxMDYuNTkiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xNC43MDUiIGN5PSIxMDUuNDYiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xOS45NTIiIGN5PSIxMDEuMTgiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0yNi44MjIiIGN5PSIxMDEuNSIgcj0iNC42MjMyIi8+PGNpcmNsZSBjeD0iLTEyLjA1IiBjeT0iODcuNzMxIiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNS45NzU4IiBjeT0iOTAuMTQ5IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNi45NjI4IiBjeT0iODguNzI1IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItMTQuODc0IiBjeT0iOTEuMjM3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMTcuMDY1IiBjeT0iOTMuNzc2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItNDMuNTQ0IiBjeT0iMTAzLjE3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjAuOTc4IiBjeT0iOTcuNTI1IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjUuNzQ3IiBjeT0iOTYuMTk2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItOS42MzA0IiBjeT0iODkuMzU2IiByPSIyLjIyMTQiLz48Y2lyY2xlIGN4PSItNTEuMTc1IiBjeT0iOTYuMzEyIiByPSIyLjIyMTQiLz48ZWxsaXBzZSBjeD0iMy42MzY2IiBjeT0iMTEyLjkzIiByeD0iMy4yOTc3IiByeT0iNy4yNjQ5Ii8+PHBhdGggZD0ibS0wLjI0ODI4IDEwNy4wOGMtMS41NWUtNiAyLjU1MzMtMS44MzE4IDAuMjMyMTUtNC4zODUyIDAuMjMyMTVzLTQuODYxMyAyLjMyMTItNC44NjEzLTAuMjMyMTVjLTRlLTYgLTIuNTUzMyAyLjA2OTktNC42MjMyIDQuNjIzMi00LjYyMzIgMi41NTMzIDAgNC42MjMyIDIuMDY5OSA0LjYyMzIgNC42MjMyeiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjQyMzUiLz48cGF0aCBkPSJtLTUwLjQ2IDkyLjcxLTEuNDQyNCAwLjQ0OTcyLTAuMDYxNzggMi42MjM0czAuOTA3NzMgMi44MzE2IDEuMDQyNSAzLjA2MDdjMC4xMzQ3NiAwLjIyOTEgMi42MDk0IDMuNDY4IDIuNjA5NCAzLjQ2OGw1LjIzODEgMC40OTM1NyAzLjcyMDMgMS4yNTE0IDMuNzY4IDAuMjE4NzFzNC44MTEyIDEuMjc1MSA1LjIzNzMgMC44MjI0N2MwLjQyNjA2LTAuNDUyNjYgMS40NDg4LTUuMDU0MiAxLjQxMzYtNS4zNTQ1LTAuMDM1MTYtMC4zMDAzNC0zLjM5NTctMS43NzQ1LTMuMzk1Ny0xLjc3NDVsLTMuODQwNS0yLjU0NzItMS42MjUtMS4yMTM0LTIuOTQ0Ni0wLjEwMDkycy0yLjc2MjctMC4zNTA3MS0zLjAzMTQtMC41MTY0NWMtMC4yNjg3Mi0wLjE2NTc1LTMuMTkxNC0wLjc2NTgtMy4zNDczLTAuNzY1OC0wLjE1NTg4IDAtMy4zNDA1LTAuMTE1My0zLjM0MDUtMC4xMTUzeiIvPjxwYXRoIGQ9Im0tMjAuMTk2IDk2LjUwNyAyLjkwNTQgNy4xMTYxIDQuOTYzNiAyLjIxMzUgNy4yMjgyLTAuMzU5MDkgNS4zOTc1IDAuNDAyODVzMS4xNDY1LTIuNDc2MyAxLjE2NjYtMi42Mzg1YzAuMDIwMTA4LTAuMTYyMjMtMi4yNDgzLTEuODA5OC0yLjI0ODMtMS44MDk4bC0xLjQ3OTgtMi4xNjU2LTAuMjEyNTItMi43NjQ5cy0xLjUxOTQtMi4zOTMzLTEuNTIyOC0yLjU1NTVjLTAuMDAzMzMtMC4xNjIxNy0yLjYyMjktNC4yNzMyLTIuNjIyOS00LjI3MzJsLTUuMjE1OS0wLjA2MjAzLTUuMTcyNCAzLjUyOTV6Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.54348" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0NC43OG1tIiBoZWlnaHQ9Ijk1LjM2M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDQuNzggOTUuMzYzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNi43MjcgLTEwNi4yNykiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE3MS40NyAxMDYuMjd2OTUuMzYzIiBzdHJva2Utd2lkdGg9IjIwLjA3OSIvPjxwYXRoIGQ9Im0xNzEuNDcgMTk1LjQ5aC0xMjguNjF2LTQzLjcxNGwyMy4xNDQtMTQuMTQ5IDEwLjU5MiAxOS4yMjQgMjguNjg0LTE5LjcyNyAxMi42MTEgMjAuNTczIDMwLjU5OS0yMi41MSAxOC42ODggMzEuNTQiIHN0cm9rZS13aWR0aD0iMTIuMjY5Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="80" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0NC43OG1tIiBoZWlnaHQ9Ijk1LjM2M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDQuNzggOTUuMzYzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNi43MjcgLTEwNi4yNykiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE3MS40NyAxMDYuMjd2OTUuMzYzIiBzdHJva2Utd2lkdGg9IjIwLjA3OSIvPjxwYXRoIGQ9Im0xNzEuNDcgMTk1LjQ5aC0xMjguNjF2LTQzLjcxNGwyMy4xNDQtMTQuMTQ5IDEwLjU5MiAxOS4yMjQgMjguNjg0LTE5LjcyNyAxMi42MTEgMjAuNTczIDMwLjU5OS0yMi41MSAxOC42ODggMzEuNTQiIHN0cm9rZS13aWR0aD0iMTIuMjY5Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="81" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43NG1tIiBoZWlnaHQ9IjEyMy4wN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzQgMTIzLjA3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40MDkgLTk1LjY1NCkiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGcgc3Ryb2tlLXdpZHRoPSI4LjgxMiI+PHBhdGggZD0ibTQ5LjgxNSAxNzAuOTN2NDMuMzg2aDI4LjYzOXYtMzMuNzg1aDIyLjM0NiIvPjxwYXRoIGQ9Im0xNTAuNjMgMTcwLjkzdjQzLjM4NmgtMjguNjM5di0zMy43ODVoLTIyLjM0NiIvPjxwYXRoIGQ9Im00OS44MTUgMTcwLjkzczguOTczOS0xNS41ODIgMTUuODI2LTIyLjQzNGM5LjM0NzQtOS4zNDc0IDIxLjk0LTE4LjMzMyAzNS4xNTktMTguMzQ2IDEzLjI3LTAuMDEzMSAyNS45NDYgOC45NjI4IDM1LjMyOSAxOC4zNDYgNi42MTk2IDYuNjE5NiAxNC40OTggMjIuNDM0IDE0LjQ5OCAyMi40MzQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Im0xNTAuNjMgMjE0LjMyaDI3LjkyMXYtODEuMzUyaC0zOC44NHYxNi4yMDgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz48L2c+PHBhdGggZD0ibTExOC4yMSAxMzQuMTF2LTEyLjU0M2gyMi40MTciIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS13aWR0aD0iNy41MTUiLz48cGF0aCBkPSJtMTc4LjQgMTMxLjQ3YzAtMTAuNjQzLTguNjI4Mi0xOS4yNzItMTkuMjcyLTE5LjI3MnMtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2Utd2lkdGg9IjkuNTA4Ii8+PHBhdGggZD0ibTE1Ni43NiAxMTYuODFjLTEuMDkxNS05LjQ3MTktOC42NDU0LTE2LjU0Ny0xOC40OC0xNi41NDctMTAuNjQzIDAtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuMjA4Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="82" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43OW1tIiBoZWlnaHQ9IjEyMy43OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzkgMTIzLjc5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS4zNTggLTkxLjgyNikiPjxnPjxyZWN0IHg9IjE1OC43OCIgeT0iOTEuODI2IiB3aWR0aD0iMTMuMjYyIiBoZWlnaHQ9Ijg2LjE3Ii8+PHJlY3QgeD0iMTM4LjA4IiB5PSI5MS44MjYiIHdpZHRoPSIxMy4yNjIiIGhlaWdodD0iODYuMTciLz48cmVjdCB4PSIxMTMuMTIiIHk9IjkxLjgyNiIgd2lkdGg9IjEzLjI2MiIgaGVpZ2h0PSI4Ni4xNyIvPjxwYXRoIGQ9Im00NS44ODggMTc1LjcxLTAuNTI5MTcgMC41MjkxNnYzOS4zNzRoMTM3Ljc5di0zOS45MDR6bTQuNjUxOSA1LjI1MDhoMjIuNzI5djYuODk3OGgtMjIuNzI5em0yNy45NzkgMGgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bTI3LjkzMiAwaDE5LjExOXY2Ljg5NzhoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3OGgtMjIuNzI5em0tNzYuNzE2IDExLjI1MmgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bS01Mi4zNDcgMC4zNjc5M2gyMi43Mjl2Ni44OTczaC0yMi43Mjl6bTgwLjI3OSAwaDE5LjExOXY2Ljg5NzNoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3M2gtMjIuNzI5eiIvPjxwYXRoIGQ9Im03MC40MTEgMTUxLjE4LTEyLjkxNCAxMi45MTQtMTIuMTM4IDEyLjEzOWgyNS4wNTN6Ii8+PHBhdGggZD0ibTk0LjkzNSAxNTEuMTgtMTIuOTE0IDEyLjkxNC0xMi4xMzggMTIuMTM5aDI1LjA1M3oiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="83" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzOS43N21tIiBoZWlnaHQ9IjEyNS42NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzkuNzcgMTI1LjY1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41ODcgLTgyLjMxMykiPjxnPjxjaXJjbGUgY3g9IjkzLjM3MiIgY3k9IjE5NS4wOCIgcj0iMTIuODgzIi8+PGNpcmNsZSBjeD0iMTM0Ljg2IiBjeT0iMTk1LjA4IiByPSIxMi44ODMiLz48cGF0aCBkPSJtNDEuNTg3IDEyMy44NWgxMzkuNzdsLTI2LjMzOSA1Ny43OTZoLTg3LjA3NHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOS41MDgiLz48Y2lyY2xlIGN4PSI4MS4wMzYiIGN5PSIxMjAuNTYiIHI9IjIwLjU2OCIvPjxjaXJjbGUgY3g9IjE0Mi41NSIgY3k9IjEyMC41NiIgcj0iMjAuNTY4Ii8+PHBhdGggZD0ibTExMS40NyA4Mi4zMTNhMjAuNTY4IDIwLjU2OCAwIDAgMC0yMC41NjggMjAuNTY4aDQxLjEzN2EyMC41NjggMjAuNTY4IDAgMCAwLTIwLjU2OC0yMC41Njh6Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="84" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="85" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5OS42NW1tIiBoZWlnaHQ9IjEzMS4yN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTkuNjUgMTMxLjI3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02LjY4NDcgLTk0LjExNykiPjxyZWN0IHg9IjE4NS4xNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjEuMTc2IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjEwMi4yNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjIuNTU3IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjExNC4zIiB5PSIyMTEuNDQiIHdpZHRoPSI3Ny4zMjUiIGhlaWdodD0iOS42MjExIi8+PHJlY3QgeD0iMTM4LjU5IiB5PSIxOTUuNjYiIHdpZHRoPSIzMS44ODMiIGhlaWdodD0iMTcuODMyIi8+PHJlY3QgeD0iMTEzLjMxIiB5PSIxNDguNTYiIHdpZHRoPSI5My4wMjEiIGhlaWdodD0iNTEuNjA3Ii8+PHJlY3QgeD0iMTY5LjQ2IiB5PSIxMzkuODQiIHdpZHRoPSIzNi44NzQiIGhlaWdodD0iMTcuNDQyIi8+PHBhdGggZD0ibTExOC4zMyAxMzAuODN2MjQuNTM3aDI0Ljk2MXYtMjQuNTM3em02LjI3MiA2LjI3ODJoOC43OTMzdjExLjQ0OWgtOC43OTMzeiIvPjxwYXRoIGQ9Im0xMjAuMyAxNDQuNzhoLTEwLjg0NmwtMTMuNjAxLTE2LjE5MyAyLjIyODktMy40NDg3aDEwLjAyOGwzLjgwOTctMy42NDM5LTAuMjIyMDctMi40ODQ2IDcuMDQ0Ni01LjcxMTggMi4xMDcyIDIuMzEzMyAyLjIxMjktMC43NTE1OHYtOC4xMTJsLTIuMTM0OC0xLjkzODQtMy4xMTA4IDAuMzI4NDV2LTQuNDQ0M2wtMi4xODc1LTMuMjE3NmgtNi4yNTE1bC0yMi4zNDYgMjQuMzczaC04LjQ2ODJsLTI3LjczNS0yNy43MjloLTkuNDhsLTQuMzY1NCA1Ljg1ODkgMjkuMTA5IDI5LjY1N2g1LjI3MThsMi4xOTYyIDIuMTYydjIuOTcwNGwtMi40MTU1IDIuMTI3OWgtOS4zMzc2bC0yMS4zOTggMjEuMjEyaC0xOS45MzRsLTEzLjc5MSAyMi41Nzl2My45MjA4aDMyLjU3OHYtNC43MTQxaDcuMTM2MnYtMTcuNDgzbDI3LjY0NC0yMC40MjdoMTIuOTAybDI5LjIxNiAyNC4xNDl6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="86" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5NC41NW1tIiBoZWlnaHQ9IjE5MS4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTQuNTUgMTkxLjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjk2MTggLTUzLjM3MikiPjxnPjxyZWN0IHg9IjMuOTYxOCIgeT0iMjE2Ljk4IiB3aWR0aD0iMTk0LjU1IiBoZWlnaHQ9IjI3LjcxOCIvPjxyZWN0IHg9IjEzNi4wNSIgeT0iOTAuNDc1IiB3aWR0aD0iNDEuOTcyIiBoZWlnaHQ9IjEzNS43NiIgcnk9IjQuODQwOCIvPjxyZWN0IHg9IjcxLjcxMiIgeT0iOTAuNDc1IiB3aWR0aD0iNDYuNjY5IiBoZWlnaHQ9IjEzNy45MiIgcnk9IjcuNzI5MSIvPjxyZWN0IHg9IjIzLjI4MiIgeT0iOTAuNDc1IiB3aWR0aD0iMjIuODIyIiBoZWlnaHQ9IjEzNS40NCIgcnk9IjUuMTgyOSIvPjwvZz48cGF0aCBkPSJtMTU4LjAyIDk0LjgxNWMxLjRlLTQgLTE3LjI2LTEzLjc5Ni0zMS4yNTMtMzAuODE1LTMxLjI1My0xNy4wMTktMS40MmUtNCAtMzAuODE1IDEzLjk5Mi0zMC44MTUgMzEuMjUzIDAuMDAyNCAwLjcwNzYyIDAuMDI4NDQgMS40MTUgMC4wNzgxNiAyLjEyMDgiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMy4yIiBzdHJva2Utd2lkdGg9IjIwLjM4MSIvPjxwYXRoIGQ9Im05Ni45MzggOTQuNzc2YzEuNGUtNCAtMTcuMjE0LTEzLjk1NS0zMS4xNjktMzEuMTY5LTMxLjE2OS0xNy4yMTQtMS40MWUtNCAtMzEuMTY5IDEzLjk1NS0zMS4xNjkgMzEuMTY5IDAuMDAyNCAwLjcwNTczIDAuMDI4NzcgMS40MTEyIDAuMDc5MDYgMi4xMTUxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuMiIgc3Ryb2tlLXdpZHRoPSIyMC40NyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.28779" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="87" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4MC42OG1tIiBoZWlnaHQ9IjE4Ni40N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODAuNjggMTg2LjQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05Ljg2NjQgLTU1LjgzNikiPjxyZWN0IHg9IjE4LjUzNyIgeT0iMTc1LjExIiB3aWR0aD0iMTM2LjY0IiBoZWlnaHQ9IjY3LjE5MyIgcnk9IjAiLz48cmVjdCB4PSIxNjQuMzUiIHk9IjEyOS4yNCIgd2lkdGg9IjI2LjE4OSIgaGVpZ2h0PSIxMTMuMDYiIHJ5PSIwIi8+PGNpcmNsZSBjeD0iMTcyLjYzIiBjeT0iMTA2LjMzIiByPSIxMi44MDEiLz48Y2lyY2xlIGN4PSIxNjUuNzIiIGN5PSI5Ny4zMzMiIHI9IjEyLjgwMSIvPjxjaXJjbGUgY3g9IjE0OC42NyIgY3k9IjEwNy4xMyIgcj0iOS4xMzM1Ii8+PGNpcmNsZSBjeD0iMTM3LjMzIiBjeT0iMTA0LjY4IiByPSI5LjEzMzUiLz48Y2lyY2xlIGN4PSIxNDkuNjYiIGN5PSI4NC4wODEiIHI9IjE0LjYxNyIvPjxjaXJjbGUgY3g9IjExNC42MSIgY3k9IjEwMi42MiIgcj0iMTMuMzc4Ii8+PGNpcmNsZSBjeD0iMTI5LjQiIGN5PSI4MC43OTciIHI9IjguODg1NSIvPjxjaXJjbGUgY3g9IjExOC4zNiIgY3k9IjY3LjQ5NCIgcj0iMTEuNjU4Ii8+PGNpcmNsZSBjeD0iOTcuODAxIiBjeT0iODYuNTA0IiByPSIxMy4wMDUiLz48Y2lyY2xlIGN4PSI5Mi44MDIiIGN5PSI4MC45NzEiIHI9IjEzLjAwNSIvPjxjaXJjbGUgY3g9IjkzLjY5OSIgY3k9IjYzLjc4NSIgcj0iNy4yNjI0Ii8+PGNpcmNsZSBjeD0iMTAwLjU5IiBjeT0iNjcuNjY2IiByPSI3LjI2MjQiLz48Y2lyY2xlIGN4PSIxMjguOTYiIGN5PSI5OS45NDYiIHI9IjcuMjYyNCIvPjxyZWN0IHg9IjEwMC43NCIgeT0iNjguNDg3IiB3aWR0aD0iMjEuNjAxIiBoZWlnaHQ9IjI0LjYzNCIvPjxyZWN0IHg9IjExOS45MyIgeT0iODMuMTkiIHdpZHRoPSIzNC41OSIgaGVpZ2h0PSIxNy4yNTUiLz48Y2lyY2xlIGN4PSI2MC40MjQiIGN5PSI4Mi44MTkiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjU3LjExMyIgY3k9Ijk3Ljc2MyIgcj0iMTUuMjE3Ii8+PGNpcmNsZSBjeD0iMzcuODI2IiBjeT0iMTAxLjc2IiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSIyNS4wODMiIGN5PSI4MC44MDgiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjMyLjU4OCIgY3k9Ijk0LjcyIiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSI0Mi45NjciIGN5PSI4OS40MjMiIHI9IjE1LjIxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="88" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3OC4xM21tIiBoZWlnaHQ9IjExNy45NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzguMTMgMTE3Ljk0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTIzLjg2NSkiPjxwYXRoIGQ9Im0yMy43NzEgMjMuODY1djYyLjQ3M2gtMC4wMDIxYzEuMDllLTQgMC4wMjc2MSAwLjAwMjEgMC4wNTQ4MSAwLjAwMjEgMC4wODI1djIzLjI1MWMwIDEyLjE2LTEwLjU5IDIxLjk1Ny0yMy43NzEgMjIuMDI2djEwLjEwNGg5NS42OTl2LTEwLjEwNGMtMTMuMTgyLTAuMDY5MS0yMy43NzEtOS44NjYtMjMuNzcxLTIyLjAyNnYtMjMuMjUxYzAtMC4wMjc3IDJlLTMgLTAuMDU0ODkgMC4wMDIxLTAuMDgyNWgtMC4wMDIxdi02Mi40NzN6Ii8+PHBhdGggZD0ibTEyMS43NCA0OS4wM3Y0OS4xNDNoLTJlLTNjOGUtNSAwLjAyMTcgMmUtMyAwLjA0MzA2IDJlLTMgMC4wNjQ5MnYxOC4yODljMCA5LjU2NTctOC4zMDI3IDE3LjI3Mi0xOC42MzggMTcuMzI3djcuOTQ4NGg3NS4wMzJ2LTcuOTQ4NGMtMTAuMzM1LTAuMDU0My0xOC42MzgtNy43NjA5LTE4LjYzOC0xNy4zMjd2LTE4LjI4OWMwLTAuMDIxNzggMmUtMyAtMC4wNDMxNCAyZS0zIC0wLjA2NDkyaC0yZS0zdi00OS4xNDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0.40000000000000002" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="89" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS4zbW0iIGhlaWdodD0iMTM5Ljk0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OS4zIDEzOS45NCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMzIuMjYzIC03Ni44ODQpIj48Y2lyY2xlIGN4PSI3OS40OTEiIGN5PSIxOTUuOTgiIHI9IjE2Ljg1IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48Y2lyY2xlIGN4PSIxNTQuOCIgY3k9IjE5NS45OCIgcj0iMTYuODUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3Ljk4MTUiLz48Zz48cmVjdCB4PSIxMDMuMzUiIHk9IjE4Mi42MiIgd2lkdGg9IjI1LjU0OSIgaGVpZ2h0PSIxNi4yMjIiLz48cGF0aCBkPSJtMzIuMjYzIDE0OS4wOHY0Mi43OThoMjEuOTlhMjQuODI3IDI0LjgyNyAwIDAgMSAyMC4wMzMtMjAuNTk2di0yMi4yMDN6bTQuNzY1MSA1LjAwMjhoMTcuNjI3djIwLjEzM2gtMTcuNjI3eiIvPjxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDQwLjE1MykiIGQ9Im0xNDUuMDcgNi43OTExLTMuOWUtNCA0MS4yOSA2NS4wMzktMi42ZS01IDI5LjM2Ny0yNC43NzYgMi45ZS00IC0xNi41MTR6Ii8+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoMzkuODQ5KSIgZD0ibTE3MS4wMSA0My41NTUtMi45ZS00IDUuNDU3MSA0LjQyMDMgMmUtNSAyZS01IDI1LjQ5IDExLjgwNS0yLjI1ZS00IDIuM2UtNCAtMjUuNDI4IDUuMTA3OCAzLjU4ZS00IDVlLTUgLTUuNTE5NXoiLz48cGF0aCBkPSJtMTcxLjEgMTUzLjIzLTEyLjk1MiAxOC45OTloOS44NjI0bDguNTU0NSAxMC45OTIgNS4wMDE4IDAuMzM2OTN2LTE5Ljc5NWwtMi45MDczLTQuMTU2M3oiLz48cGF0aCBkPSJtMTEzLjAyIDEwNC4yNC02LjUyMjctNS41MDI5LTIzLjEzMi0xOS45MDUtOC41MjY2LTEuOTQ2NiAwLjA1MzA4OSA4LjIyMDcgMjUuNjIxIDIwLjcyNSA0LjQ4MzUgNS4xNzQyeiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43NG1tIiBoZWlnaHQ9IjEyMy4wN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzQgMTIzLjA3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40MDkgLTk1LjY1NCkiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGcgc3Ryb2tlLXdpZHRoPSI4LjgxMiI+PHBhdGggZD0ibTQ5LjgxNSAxNzAuOTN2NDMuMzg2aDI4LjYzOXYtMzMuNzg1aDIyLjM0NiIvPjxwYXRoIGQ9Im0xNTAuNjMgMTcwLjkzdjQzLjM4NmgtMjguNjM5di0zMy43ODVoLTIyLjM0NiIvPjxwYXRoIGQ9Im00OS44MTUgMTcwLjkzczguOTczOS0xNS41ODIgMTUuODI2LTIyLjQzNGM5LjM0NzQtOS4zNDc0IDIxLjk0LTE4LjMzMyAzNS4xNTktMTguMzQ2IDEzLjI3LTAuMDEzMSAyNS45NDYgOC45NjI4IDM1LjMyOSAxOC4zNDYgNi42MTk2IDYuNjE5NiAxNC40OTggMjIuNDM0IDE0LjQ5OCAyMi40MzQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Im0xNTAuNjMgMjE0LjMyaDI3LjkyMXYtODEuMzUyaC0zOC44NHYxNi4yMDgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz48L2c+PHBhdGggZD0ibTExOC4yMSAxMzQuMTF2LTEyLjU0M2gyMi40MTciIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS13aWR0aD0iNy41MTUiLz48cGF0aCBkPSJtMTc4LjQgMTMxLjQ3YzAtMTAuNjQzLTguNjI4Mi0xOS4yNzItMTkuMjcyLTE5LjI3MnMtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2Utd2lkdGg9IjkuNTA4Ii8+PHBhdGggZD0ibTE1Ni43NiAxMTYuODFjLTEuMDkxNS05LjQ3MTktOC42NDU0LTE2LjU0Ny0xOC40OC0xNi41NDctMTAuNjQzIDAtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuMjA4Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="90" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzMi4xNm1tIiBoZWlnaHQ9IjEyMy44Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzIuMTYgMTIzLjg2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4yMTkgLTkxLjcyMSkiPjxnPjxyZWN0IHg9IjE2MS45NyIgeT0iOTEuNzIxIiB3aWR0aD0iMTYuNDEiIGhlaWdodD0iMTIzLjg2Ii8+PHJlY3QgeD0iNDYuMjIiIHk9IjE2OC4yNSIgd2lkdGg9IjEzMi4xNiIgaGVpZ2h0PSI0Ny4zMjgiLz48cmVjdCB4PSIxNDAuMDQiIHk9IjkxLjcyMSIgd2lkdGg9IjE2LjQxIiBoZWlnaHQ9IjEyMy44NiIvPjxwYXRoIGQ9Im03NS42NDkgMTM4LjczLTI5LjQyOSAyOS40Mjl2MTMuOTU5aDI5LjQyOXoiLz48cGF0aCBkPSJtMTA1LjA4IDEzOC43My0yOS40MjkgMjkuNDI5djEzLjk1OWgyOS40Mjl6Ii8+PHBhdGggZD0ibTEzNC41MSAxMzguNzMtMjkuNDI5IDI5LjQyOXYxMy45NTloMjkuNDI5eiIvPjxyZWN0IHg9IjQ2LjIxOSIgeT0iMTY4LjI1IiB3aWR0aD0iMTMyLjE2IiBoZWlnaHQ9IjEzLjc2OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="91" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNi4zM21tIiBoZWlnaHQ9IjEzOC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTYuMzMgMTM4LjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NS4wNSAtODEuMjY0KSI+PGc+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHJlY3QgeD0iMTQ4LjM2IiB5PSIxMjYuNDUiIHdpZHRoPSIyMy4wMTUiIGhlaWdodD0iOTMuMDgxIiBzdHJva2Utd2lkdGg9IjcuNTQ3NCIvPjxyZWN0IHg9IjU1LjA1IiB5PSIxODUuNDkiIHdpZHRoPSIxMTYuMzMiIGhlaWdodD0iMzQuMDQxIiBzdHJva2Utd2lkdGg9IjcuOTgyIi8+PHBhdGggZD0ibTEwMC42NCAxNDguMjcgMWUtNSAxMy40NzUgNjIuNzI5IDIyLjIyMiA0LjI0MTYtMTEuOTcyeiIgc3Ryb2tlLXdpZHRoPSI3Ljk4MiIvPjxwYXRoIGQ9Im01NS4wNSAxNTEuMzQtNGUtNiAxNS4zNTYgNzguMjY1IDI4LjIyNiAxMC42ODQtMTEuNTAzeiIgc3Ryb2tlLXdpZHRoPSIxMi43OTkiLz48cmVjdCB4PSIxMzguNDIiIHk9IjE4Mi43MSIgd2lkdGg9IjEzLjY5MyIgaGVpZ2h0PSI0LjE5NzMiIHN0cm9rZS13aWR0aD0iNy45ODIiLz48cGF0aCBkPSJtNTUuMDUgMTcxLjM0IDVlLTYgMjEuMjkxIDMzLjk2IDEyLjQ5MSA2Ljg5NzItMTguNzUzeiIgc3Ryb2tlLXdpZHRoPSI4Ljk0NjciLz48L2c+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMS42NjM1IDAgMCAxLjY2MzUgMTUyLjI1IC02MC45MjIpIj48Y2lyY2xlIGN4PSIxLjk1MzMiIGN5PSIxMDIuNDUiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9IjMuNzgxNCIgY3k9IjEwOC41MiIgcj0iMi45MDY3Ii8+PGNpcmNsZSBjeD0iMS45OTk4IiBjeT0iMTA1Ljg4IiByPSIyLjkwNjciLz48Y2lyY2xlIGN4PSIxLjE4NDMiIGN5PSIxMDcuMDEiIHI9IjIuOTA2NyIvPjxjaXJjbGUgY3g9Ii01LjAwNTkiIGN5PSI5NS41NzYiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii00LjQyOTgiIGN5PSIxMDAuOTkiIHI9IjQuODg0NiIvPjxjaXJjbGUgY3g9Ii0zMS42NDYiIGN5PSI5NC4yMzIiIHI9IjYuODcxOCIvPjxjaXJjbGUgY3g9Ii0zMy45MzYiIGN5PSIxMDYuNDIiIHI9IjQuNjYzNiIvPjxjaXJjbGUgY3g9Ii0zMC4xNzgiIGN5PSIxMDYuMjMiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii0zNi45NDciIGN5PSIxMDQuNTIiIHI9IjMuNzk1MiIvPjxjaXJjbGUgY3g9Ii00Ny44OCIgY3k9IjEwNS4zMSIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUwLjgyOSIgY3k9IjEwNC4zNyIgcj0iNC41NDQ2Ii8+PGNpcmNsZSBjeD0iLTUxLjI1MSIgY3k9IjEwMC43NiIgcj0iNS41NDA4Ii8+PGNpcmNsZSBjeD0iLTUyLjQ0OCIgY3k9IjkzLjAxNiIgcj0iMS41NTQ2Ii8+PGNpcmNsZSBjeD0iLTQ5LjU5OSIgY3k9IjkyLjA0MSIgcj0iMS45NjkxIi8+PGVsbGlwc2UgY3g9Ii00NS43OTEiIGN5PSI5My4xMjIiIHJ4PSIzLjczNTYiIHJ5PSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItNDIuMzk2IiBjeT0iOTMuOTY3IiByPSIxLjk2OTEiLz48Y2lyY2xlIGN4PSItMzguNzMiIGN5PSI5My42NjUiIHI9IjEuOTY5MSIvPjxjaXJjbGUgY3g9Ii0xMS43NTYiIGN5PSIxMDYuNTkiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xNC43MDUiIGN5PSIxMDUuNDYiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0xOS45NTIiIGN5PSIxMDEuMTgiIHI9IjQuNjIzMiIvPjxjaXJjbGUgY3g9Ii0yNi44MjIiIGN5PSIxMDEuNSIgcj0iNC42MjMyIi8+PGNpcmNsZSBjeD0iLTEyLjA1IiBjeT0iODcuNzMxIiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNS45NzU4IiBjeT0iOTAuMTQ5IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItNi45NjI4IiBjeT0iODguNzI1IiByPSIyLjI1MzkiLz48Y2lyY2xlIGN4PSItMTQuODc0IiBjeT0iOTEuMjM3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMTcuMDY1IiBjeT0iOTMuNzc2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItNDMuNTQ0IiBjeT0iMTAzLjE3IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjAuOTc4IiBjeT0iOTcuNTI1IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItMjUuNzQ3IiBjeT0iOTYuMTk2IiByPSIzLjYwNzMiLz48Y2lyY2xlIGN4PSItOS42MzA0IiBjeT0iODkuMzU2IiByPSIyLjIyMTQiLz48Y2lyY2xlIGN4PSItNTEuMTc1IiBjeT0iOTYuMzEyIiByPSIyLjIyMTQiLz48ZWxsaXBzZSBjeD0iMy42MzY2IiBjeT0iMTEyLjkzIiByeD0iMy4yOTc3IiByeT0iNy4yNjQ5Ii8+PHBhdGggZD0ibS0wLjI0ODI4IDEwNy4wOGMtMS41NWUtNiAyLjU1MzMtMS44MzE4IDAuMjMyMTUtNC4zODUyIDAuMjMyMTVzLTQuODYxMyAyLjMyMTItNC44NjEzLTAuMjMyMTVjLTRlLTYgLTIuNTUzMyAyLjA2OTktNC42MjMyIDQuNjIzMi00LjYyMzIgMi41NTMzIDAgNC42MjMyIDIuMDY5OSA0LjYyMzIgNC42MjMyeiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjQyMzUiLz48cGF0aCBkPSJtLTUwLjQ2IDkyLjcxLTEuNDQyNCAwLjQ0OTcyLTAuMDYxNzggMi42MjM0czAuOTA3NzMgMi44MzE2IDEuMDQyNSAzLjA2MDdjMC4xMzQ3NiAwLjIyOTEgMi42MDk0IDMuNDY4IDIuNjA5NCAzLjQ2OGw1LjIzODEgMC40OTM1NyAzLjcyMDMgMS4yNTE0IDMuNzY4IDAuMjE4NzFzNC44MTEyIDEuMjc1MSA1LjIzNzMgMC44MjI0N2MwLjQyNjA2LTAuNDUyNjYgMS40NDg4LTUuMDU0MiAxLjQxMzYtNS4zNTQ1LTAuMDM1MTYtMC4zMDAzNC0zLjM5NTctMS43NzQ1LTMuMzk1Ny0xLjc3NDVsLTMuODQwNS0yLjU0NzItMS42MjUtMS4yMTM0LTIuOTQ0Ni0wLjEwMDkycy0yLjc2MjctMC4zNTA3MS0zLjAzMTQtMC41MTY0NWMtMC4yNjg3Mi0wLjE2NTc1LTMuMTkxNC0wLjc2NTgtMy4zNDczLTAuNzY1OC0wLjE1NTg4IDAtMy4zNDA1LTAuMTE1My0zLjM0MDUtMC4xMTUzeiIvPjxwYXRoIGQ9Im0tMjAuMTk2IDk2LjUwNyAyLjkwNTQgNy4xMTYxIDQuOTYzNiAyLjIxMzUgNy4yMjgyLTAuMzU5MDkgNS4zOTc1IDAuNDAyODVzMS4xNDY1LTIuNDc2MyAxLjE2NjYtMi42Mzg1YzAuMDIwMTA4LTAuMTYyMjMtMi4yNDgzLTEuODA5OC0yLjI0ODMtMS44MDk4bC0xLjQ3OTgtMi4xNjU2LTAuMjEyNTItMi43NjQ5cy0xLjUxOTQtMi4zOTMzLTEuNTIyOC0yLjU1NTVjLTAuMDAzMzMtMC4xNjIxNy0yLjYyMjktNC4yNzMyLTIuNjIyOS00LjI3MzJsLTUuMjE1OS0wLjA2MjAzLTUuMTcyNCAzLjUyOTV6Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.54348" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="92" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0NC43OG1tIiBoZWlnaHQ9Ijk1LjM2M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDQuNzggOTUuMzYzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNi43MjcgLTEwNi4yNykiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE3MS40NyAxMDYuMjd2OTUuMzYzIiBzdHJva2Utd2lkdGg9IjIwLjA3OSIvPjxwYXRoIGQ9Im0xNzEuNDcgMTk1LjQ5aC0xMjguNjF2LTQzLjcxNGwyMy4xNDQtMTQuMTQ5IDEwLjU5MiAxOS4yMjQgMjguNjg0LTE5LjcyNyAxMi42MTEgMjAuNTczIDMwLjU5OS0yMi41MSAxOC42ODggMzEuNTQiIHN0cm9rZS13aWR0aD0iMTIuMjY5Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="93" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43NG1tIiBoZWlnaHQ9IjEyMy4wN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzQgMTIzLjA3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40MDkgLTk1LjY1NCkiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PGcgc3Ryb2tlLXdpZHRoPSI4LjgxMiI+PHBhdGggZD0ibTQ5LjgxNSAxNzAuOTN2NDMuMzg2aDI4LjYzOXYtMzMuNzg1aDIyLjM0NiIvPjxwYXRoIGQ9Im0xNTAuNjMgMTcwLjkzdjQzLjM4NmgtMjguNjM5di0zMy43ODVoLTIyLjM0NiIvPjxwYXRoIGQ9Im00OS44MTUgMTcwLjkzczguOTczOS0xNS41ODIgMTUuODI2LTIyLjQzNGM5LjM0NzQtOS4zNDc0IDIxLjk0LTE4LjMzMyAzNS4xNTktMTguMzQ2IDEzLjI3LTAuMDEzMSAyNS45NDYgOC45NjI4IDM1LjMyOSAxOC4zNDYgNi42MTk2IDYuNjE5NiAxNC40OTggMjIuNDM0IDE0LjQ5OCAyMi40MzQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Im0xNTAuNjMgMjE0LjMyaDI3LjkyMXYtODEuMzUyaC0zOC44NHYxNi4yMDgiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz48L2c+PHBhdGggZD0ibTExOC4yMSAxMzQuMTF2LTEyLjU0M2gyMi40MTciIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS13aWR0aD0iNy41MTUiLz48cGF0aCBkPSJtMTc4LjQgMTMxLjQ3YzAtMTAuNjQzLTguNjI4Mi0xOS4yNzItMTkuMjcyLTE5LjI3MnMtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2Utd2lkdGg9IjkuNTA4Ii8+PHBhdGggZD0ibTE1Ni43NiAxMTYuODFjLTEuMDkxNS05LjQ3MTktOC42NDU0LTE2LjU0Ny0xOC40OC0xNi41NDctMTAuNjQzIDAtMTkuMjcyIDguNjI4Mi0xOS4yNzIgMTkuMjcyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuMjA4Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="94" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzNy43OW1tIiBoZWlnaHQ9IjEyMy43OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzcuNzkgMTIzLjc5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS4zNTggLTkxLjgyNikiPjxnPjxyZWN0IHg9IjE1OC43OCIgeT0iOTEuODI2IiB3aWR0aD0iMTMuMjYyIiBoZWlnaHQ9Ijg2LjE3Ii8+PHJlY3QgeD0iMTM4LjA4IiB5PSI5MS44MjYiIHdpZHRoPSIxMy4yNjIiIGhlaWdodD0iODYuMTciLz48cmVjdCB4PSIxMTMuMTIiIHk9IjkxLjgyNiIgd2lkdGg9IjEzLjI2MiIgaGVpZ2h0PSI4Ni4xNyIvPjxwYXRoIGQ9Im00NS44ODggMTc1LjcxLTAuNTI5MTcgMC41MjkxNnYzOS4zNzRoMTM3Ljc5di0zOS45MDR6bTQuNjUxOSA1LjI1MDhoMjIuNzI5djYuODk3OGgtMjIuNzI5em0yNy45NzkgMGgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bTI3LjkzMiAwaDE5LjExOXY2Ljg5NzhoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3OGgtMjIuNzI5em0tNzYuNzE2IDExLjI1MmgxOS4xMTl2Ni44OTc4aC0xOS4xMTl6bTI0LjM2OCAwaDIyLjczdjYuODk3OGgtMjIuNzN6bS01Mi4zNDcgMC4zNjc5M2gyMi43Mjl2Ni44OTczaC0yMi43Mjl6bTgwLjI3OSAwaDE5LjExOXY2Ljg5NzNoLTE5LjExOXptMjQuNDE2IDBoMjIuNzI5djYuODk3M2gtMjIuNzI5eiIvPjxwYXRoIGQ9Im03MC40MTEgMTUxLjE4LTEyLjkxNCAxMi45MTQtMTIuMTM4IDEyLjEzOWgyNS4wNTN6Ii8+PHBhdGggZD0ibTk0LjkzNSAxNTEuMTgtMTIuOTE0IDEyLjkxNC0xMi4xMzggMTIuMTM5aDI1LjA1M3oiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="95" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEzOS43N21tIiBoZWlnaHQ9IjEyNS42NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMzkuNzcgMTI1LjY1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41ODcgLTgyLjMxMykiPjxnPjxjaXJjbGUgY3g9IjkzLjM3MiIgY3k9IjE5NS4wOCIgcj0iMTIuODgzIi8+PGNpcmNsZSBjeD0iMTM0Ljg2IiBjeT0iMTk1LjA4IiByPSIxMi44ODMiLz48cGF0aCBkPSJtNDEuNTg3IDEyMy44NWgxMzkuNzdsLTI2LjMzOSA1Ny43OTZoLTg3LjA3NHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOS41MDgiLz48Y2lyY2xlIGN4PSI4MS4wMzYiIGN5PSIxMjAuNTYiIHI9IjIwLjU2OCIvPjxjaXJjbGUgY3g9IjE0Mi41NSIgY3k9IjEyMC41NiIgcj0iMjAuNTY4Ii8+PHBhdGggZD0ibTExMS40NyA4Mi4zMTNhMjAuNTY4IDIwLjU2OCAwIDAgMC0yMC41NjggMjAuNTY4aDQxLjEzN2EyMC41NjggMjAuNTY4IDAgMCAwLTIwLjU2OC0yMC41Njh6Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="96" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="231,113,72,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="97" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5OS42NW1tIiBoZWlnaHQ9IjEzMS4yN21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTkuNjUgMTMxLjI3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02LjY4NDcgLTk0LjExNykiPjxyZWN0IHg9IjE4NS4xNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjEuMTc2IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjEwMi4yNSIgeT0iMjA3LjE4IiB3aWR0aD0iMjIuNTU3IiBoZWlnaHQ9IjE4LjIwOSIvPjxyZWN0IHg9IjExNC4zIiB5PSIyMTEuNDQiIHdpZHRoPSI3Ny4zMjUiIGhlaWdodD0iOS42MjExIi8+PHJlY3QgeD0iMTM4LjU5IiB5PSIxOTUuNjYiIHdpZHRoPSIzMS44ODMiIGhlaWdodD0iMTcuODMyIi8+PHJlY3QgeD0iMTEzLjMxIiB5PSIxNDguNTYiIHdpZHRoPSI5My4wMjEiIGhlaWdodD0iNTEuNjA3Ii8+PHJlY3QgeD0iMTY5LjQ2IiB5PSIxMzkuODQiIHdpZHRoPSIzNi44NzQiIGhlaWdodD0iMTcuNDQyIi8+PHBhdGggZD0ibTExOC4zMyAxMzAuODN2MjQuNTM3aDI0Ljk2MXYtMjQuNTM3em02LjI3MiA2LjI3ODJoOC43OTMzdjExLjQ0OWgtOC43OTMzeiIvPjxwYXRoIGQ9Im0xMjAuMyAxNDQuNzhoLTEwLjg0NmwtMTMuNjAxLTE2LjE5MyAyLjIyODktMy40NDg3aDEwLjAyOGwzLjgwOTctMy42NDM5LTAuMjIyMDctMi40ODQ2IDcuMDQ0Ni01LjcxMTggMi4xMDcyIDIuMzEzMyAyLjIxMjktMC43NTE1OHYtOC4xMTJsLTIuMTM0OC0xLjkzODQtMy4xMTA4IDAuMzI4NDV2LTQuNDQ0M2wtMi4xODc1LTMuMjE3NmgtNi4yNTE1bC0yMi4zNDYgMjQuMzczaC04LjQ2ODJsLTI3LjczNS0yNy43MjloLTkuNDhsLTQuMzY1NCA1Ljg1ODkgMjkuMTA5IDI5LjY1N2g1LjI3MThsMi4xOTYyIDIuMTYydjIuOTcwNGwtMi40MTU1IDIuMTI3OWgtOS4zMzc2bC0yMS4zOTggMjEuMjEyaC0xOS45MzRsLTEzLjc5MSAyMi41Nzl2My45MjA4aDMyLjU3OHYtNC43MTQxaDcuMTM2MnYtMTcuNDgzbDI3LjY0NC0yMC40MjdoMTIuOTAybDI5LjIxNiAyNC4xNDl6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="98" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5NC41NW1tIiBoZWlnaHQ9IjE5MS4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxOTQuNTUgMTkxLjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjk2MTggLTUzLjM3MikiPjxnPjxyZWN0IHg9IjMuOTYxOCIgeT0iMjE2Ljk4IiB3aWR0aD0iMTk0LjU1IiBoZWlnaHQ9IjI3LjcxOCIvPjxyZWN0IHg9IjEzNi4wNSIgeT0iOTAuNDc1IiB3aWR0aD0iNDEuOTcyIiBoZWlnaHQ9IjEzNS43NiIgcnk9IjQuODQwOCIvPjxyZWN0IHg9IjcxLjcxMiIgeT0iOTAuNDc1IiB3aWR0aD0iNDYuNjY5IiBoZWlnaHQ9IjEzNy45MiIgcnk9IjcuNzI5MSIvPjxyZWN0IHg9IjIzLjI4MiIgeT0iOTAuNDc1IiB3aWR0aD0iMjIuODIyIiBoZWlnaHQ9IjEzNS40NCIgcnk9IjUuMTgyOSIvPjwvZz48cGF0aCBkPSJtMTU4LjAyIDk0LjgxNWMxLjRlLTQgLTE3LjI2LTEzLjc5Ni0zMS4yNTMtMzAuODE1LTMxLjI1My0xNy4wMTktMS40MmUtNCAtMzAuODE1IDEzLjk5Mi0zMC44MTUgMzEuMjUzIDAuMDAyNCAwLjcwNzYyIDAuMDI4NDQgMS40MTUgMC4wNzgxNiAyLjEyMDgiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMy4yIiBzdHJva2Utd2lkdGg9IjIwLjM4MSIvPjxwYXRoIGQ9Im05Ni45MzggOTQuNzc2YzEuNGUtNCAtMTcuMjE0LTEzLjk1NS0zMS4xNjktMzEuMTY5LTMxLjE2OS0xNy4yMTQtMS40MWUtNCAtMzEuMTY5IDEzLjk1NS0zMS4xNjkgMzEuMTY5IDAuMDAyNCAwLjcwNTczIDAuMDI4NzcgMS40MTEyIDAuMDc5MDYgMi4xMTUxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuMiIgc3Ryb2tlLXdpZHRoPSIyMC40NyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.28779" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="99" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="114,155,111,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4MC42OG1tIiBoZWlnaHQ9IjE4Ni40N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODAuNjggMTg2LjQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05Ljg2NjQgLTU1LjgzNikiPjxyZWN0IHg9IjE4LjUzNyIgeT0iMTc1LjExIiB3aWR0aD0iMTM2LjY0IiBoZWlnaHQ9IjY3LjE5MyIgcnk9IjAiLz48cmVjdCB4PSIxNjQuMzUiIHk9IjEyOS4yNCIgd2lkdGg9IjI2LjE4OSIgaGVpZ2h0PSIxMTMuMDYiIHJ5PSIwIi8+PGNpcmNsZSBjeD0iMTcyLjYzIiBjeT0iMTA2LjMzIiByPSIxMi44MDEiLz48Y2lyY2xlIGN4PSIxNjUuNzIiIGN5PSI5Ny4zMzMiIHI9IjEyLjgwMSIvPjxjaXJjbGUgY3g9IjE0OC42NyIgY3k9IjEwNy4xMyIgcj0iOS4xMzM1Ii8+PGNpcmNsZSBjeD0iMTM3LjMzIiBjeT0iMTA0LjY4IiByPSI5LjEzMzUiLz48Y2lyY2xlIGN4PSIxNDkuNjYiIGN5PSI4NC4wODEiIHI9IjE0LjYxNyIvPjxjaXJjbGUgY3g9IjExNC42MSIgY3k9IjEwMi42MiIgcj0iMTMuMzc4Ii8+PGNpcmNsZSBjeD0iMTI5LjQiIGN5PSI4MC43OTciIHI9IjguODg1NSIvPjxjaXJjbGUgY3g9IjExOC4zNiIgY3k9IjY3LjQ5NCIgcj0iMTEuNjU4Ii8+PGNpcmNsZSBjeD0iOTcuODAxIiBjeT0iODYuNTA0IiByPSIxMy4wMDUiLz48Y2lyY2xlIGN4PSI5Mi44MDIiIGN5PSI4MC45NzEiIHI9IjEzLjAwNSIvPjxjaXJjbGUgY3g9IjkzLjY5OSIgY3k9IjYzLjc4NSIgcj0iNy4yNjI0Ii8+PGNpcmNsZSBjeD0iMTAwLjU5IiBjeT0iNjcuNjY2IiByPSI3LjI2MjQiLz48Y2lyY2xlIGN4PSIxMjguOTYiIGN5PSI5OS45NDYiIHI9IjcuMjYyNCIvPjxyZWN0IHg9IjEwMC43NCIgeT0iNjguNDg3IiB3aWR0aD0iMjEuNjAxIiBoZWlnaHQ9IjI0LjYzNCIvPjxyZWN0IHg9IjExOS45MyIgeT0iODMuMTkiIHdpZHRoPSIzNC41OSIgaGVpZ2h0PSIxNy4yNTUiLz48Y2lyY2xlIGN4PSI2MC40MjQiIGN5PSI4Mi44MTkiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjU3LjExMyIgY3k9Ijk3Ljc2MyIgcj0iMTUuMjE3Ii8+PGNpcmNsZSBjeD0iMzcuODI2IiBjeT0iMTAxLjc2IiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSIyNS4wODMiIGN5PSI4MC44MDgiIHI9IjE1LjIxNyIvPjxjaXJjbGUgY3g9IjMyLjU4OCIgY3k9Ijk0LjcyIiByPSIxNS4yMTciLz48Y2lyY2xlIGN4PSI0Mi45NjciIGN5PSI4OS40MjMiIHI9IjE1LjIxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Предприятие добывающей промышленности (кроме угледобывающей промышленности)" value="602020101" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Предприятие нефтеперерабатывающей, коксохимической промышленности" value="602020102" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Предприятие химической, целлюлозно-бумажной, фармацевтической промышленности, полиграфическое предприятие" value="602020103" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Предприятие металлургии (в том числе цветной металлургии), металлообработки" value="602020104" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Предприятие машиностроения" value="602020105" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Предприятие строительной промышленности, по выпуску неметаллической минеральной продукции" value="602020106" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Предприятие по обработке древесины, производству изделий из дерева" value="602020107" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Предприятие текстильной, легкой промышленности" value="602020108" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Предприятие микробиологической, пищевой, пищевкусовой промышленности" value="602020109" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Предприятие обрабатывающей промышленности иной специализации" value="602020110" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Предприятие угледобывающей промышленности" value="602020111" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="MAIN_ACTIV" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADD_ACTIV" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="MP_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Угольная шахта" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной объект по добыче полезных ископаемых закрытым способом" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Угольный разрез" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной объект по добыче полезных ископаемых открытым способом" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Угольная обогатительная фабрика" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной объект по обогащению и первичной обработке извлеченных полезных ископаемых" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Коксовая батарея" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное производственное подразделение" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="WRK_COUNT" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="HZRD_CLASS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="I класс опасности объекта" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="II класс опасности объекта" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="III класс опасности объекта" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="IV класс опасности объекта" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="V класс опасности объекта" value="5" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="HZRD_CAT" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Объекты, оказывающие значительное негативное воздействие на окружающую среду и относящиеся к областям применения наилучших доступных технологий, - объекты I категории" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты, оказывающие умеренное негативное воздействие на окружающую среду, - объекты II категории" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты, оказывающие незначительное негативное воздействие на окружающую среду, - объекты III категории" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты, оказывающие минимальное негативное воздействие на окружающую среду, - объекты IV категории" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="BENT_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Коммерческое предприятие (организация), не относящееся к субъектам малого и среднего предпринимательства" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Среднее предприятие" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Малое предприятие (кроме микропредприятий)" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Микропредприятие" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Данные о типе предприятия (организации) отсутствуют" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="DANGER_OBJ" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Объекты использования атомной энергии (в том числе ядерные установки, пункты хранения ядерных материалов и радиоактивных веществ, пункты хранения радиоактивных отходов)" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Тепловые электростанции мощностью 150 мегаватт и выше" value="10" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Подвесные канатные дороги" value="11" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасные производственные объекты I и II классов опасности, на которых получаются, используются, перерабатываются, образуются, хранятся, транспортируются, уничтожаются опасные вещества" value="12" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасные производственные объекты, на которых получаются, транспортируются, используются расплавы черных и цветных металлов, сплавы на основе этих расплавов с применением оборудования, рассчитанного на максимальное количество расплава 500 килограммов иболее" value="13" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасные производственные объекты, на которых ведутся горные работы (за исключением добычи общераспространенных полезных ископаемых и разработки россыпных месторождений полезных ископаемых, осуществляемых открытым способом без применения взрывных работ), работы по обогащению полезных ископаемых" value="14" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Антенно-мачтовое сооружение (АМС)" value="15" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Гидротехнические сооружения первого и второго классов, устанавливаемые в соответствии с законодательством о безопасности гидротехнических сооружений" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Сооружения связи, являющиеся особо опасными, технически сложными в соответствии с законодательством Российской Федерации в области связи" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Линии электропередачи и иные объекты электросетевого хозяйства напряжением 330 киловольт и более" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты космической инфраструктуры" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты инфраструктуры воздушного транспорта, являющиеся особо опасными, технически сложными объектами в соответствии с воздушным законодательством Российской Федерации" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты капитального строительства инфраструктуры железнодорожного транспорта общего пользования, являющиеся особо опасными, технически сложными объектами в соответствии с законодательством Российской Федерации о железнодорожном транспорте" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты инфраструктуры внеуличного транспорта" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Портовые гидротехнические сооружения, относящиеся к объектам инфраструктуры морского порта, за исключением объектов инфраструктуры морского порта, предназначенных для стоянок и обслуживания маломерных, спортивных парусных и прогулочных судов" value="9" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FUNCTION" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к ликвидации" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTROKS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTRZU" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKVED" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="MAIN_ACTIV" index="6" name="Подтип предприятия - основная специализация, вид деятельности"/>
    <alias field="ADD_ACTIV" index="7" name="Дополнительные виды деятельности"/>
    <alias field="MP_TYPE" index="8" name=""/>
    <alias field="WRK_COUNT" index="9" name="Количество рабочих мест, единиц"/>
    <alias field="HZRD_CLASS" index="10" name="Класс опасности объекта в соответствии с санитарной классификацией"/>
    <alias field="HZRD_CAT" index="11" name="Категория объекта, оказывающего негативное воздействие на окружающую среду"/>
    <alias field="BENT_TYPE" index="12" name="Тип хозяйствующего субъекта"/>
    <alias field="DANGER_OBJ" index="13" name="Критерии отнесения объекта к особо опасным и технически сложным объектам"/>
    <alias field="FUNCTION" index="14" name="Назначение объекта"/>
    <alias field="EVENT_TIME" index="15" name=""/>
    <alias field="SOURCE" index="16" name="Источник данных"/>
    <alias field="NOTE" index="17" name="Примечание"/>
    <alias field="STATUS" index="18" name="Статус объекта"/>
    <alias field="REG_STATUS" index="19" name="Значение объекта"/>
    <alias field="KADASTROKS" index="20" name="Кадастровый номер объекта капитального строительства"/>
    <alias field="KADASTRZU" index="21" name=""/>
    <alias field="OKVED" index="22" name="Вид деятельности по общероссийскому классификатору видов экономической деятельности (ОКВЭД)"/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602020101'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="MAIN_ACTIV" expression="''" applyOnUpdate="0"/>
    <default field="ADD_ACTIV" expression="''" applyOnUpdate="0"/>
    <default field="MP_TYPE" expression="if(&quot;CLASSID&quot; = '602020101' OR &quot;CLASSID&quot; = '602020111', attribute('MP_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="WRK_COUNT" expression="0" applyOnUpdate="0"/>
    <default field="HZRD_CLASS" expression="1" applyOnUpdate="0"/>
    <default field="HZRD_CAT" expression="" applyOnUpdate="0"/>
    <default field="BENT_TYPE" expression="" applyOnUpdate="0"/>
    <default field="DANGER_OBJ" expression="" applyOnUpdate="0"/>
    <default field="FUNCTION" expression="''" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
    <default field="KADASTROKS" expression="''" applyOnUpdate="0"/>
    <default field="KADASTRZU" expression="''" applyOnUpdate="0"/>
    <default field="OKVED" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="MAIN_ACTIV" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="ADD_ACTIV" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="2" field="MP_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="WRK_COUNT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="HZRD_CLASS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="HZRD_CAT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="BENT_TYPE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="DANGER_OBJ" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FUNCTION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="2" field="KADASTROKS" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="KADASTRZU" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="OKVED" unique_strength="0" notnull_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="MAIN_ACTIV" desc="" exp=""/>
    <constraint field="ADD_ACTIV" desc="" exp=""/>
    <constraint field="MP_TYPE" desc="Заполняется для объектов 602020101, 602020111" exp="if(&quot;CLASSID&quot; = '602020101' OR &quot;CLASSID&quot; = '602020111', &quot;MP_TYPE&quot; IS NOT NULL, &quot;MP_TYPE&quot; IS NULL)"/>
    <constraint field="WRK_COUNT" desc="" exp=""/>
    <constraint field="HZRD_CLASS" desc="" exp=""/>
    <constraint field="HZRD_CAT" desc="" exp=""/>
    <constraint field="BENT_TYPE" desc="" exp=""/>
    <constraint field="DANGER_OBJ" desc="" exp=""/>
    <constraint field="FUNCTION" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xd;&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
    <constraint field="KADASTROKS" desc="Кадастровый номе объекта должен соответствовать формату, принятому в ЕГРН" exp="regexp_match(&quot;KADASTROKS&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$')"/>
    <constraint field="KADASTRZU" desc="Обязательно для значений атрибута &quot;STATUS&quot; 1, 3, 4" exp="if (&quot;STATUS&quot; = 1 OR &quot;STATUS&quot; = 3 OR &quot;STATUS&quot; = 4,&#xa;&#x9;regexp_match(&quot;KADASTRZU&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$|^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1})$'),&#xa;&#x9;length(&quot;KADASTRZU&quot;) >= 0)"/>
    <constraint field="OKVED" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="10" name="HZRD_CLASS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="18" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="19" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="6" name="MAIN_ACTIV">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="7" name="ADD_ACTIV">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Основные производственные подразделения" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; IN ('602020101', '602020111')">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="8" name="MP_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorField showLabel="1" index="9" name="WRK_COUNT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="11" name="HZRD_CAT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="12" name="BENT_TYPE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="DANGER_OBJ">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="14" name="FUNCTION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="16" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="17" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="20" name="KADASTROKS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="22" name="OKVED">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="15" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Кадастровый номер земельного участка и (или) номер кадастрового квартала, в границах которого расположен объект" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (1, 3, 4)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="21" name="KADASTRZU">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="ADD_ACTIV" editable="1"/>
    <field name="BENT_TYPE" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="DANGER_OBJ" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="FUNCTION" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="HZRD_CAT" editable="1"/>
    <field name="HZRD_CLASS" editable="1"/>
    <field name="KADASTROKS" editable="1"/>
    <field name="KADASTRZU" editable="1"/>
    <field name="MAIN_ACTIV" editable="1"/>
    <field name="MP_TYPE" editable="1"/>
    <field name="NAME" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="OKVED" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="WRK_COUNT" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="ADD_ACTIV"/>
    <field labelOnTop="1" name="BENT_TYPE"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="DANGER_OBJ"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="FUNCTION"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="HZRD_CAT"/>
    <field labelOnTop="1" name="HZRD_CLASS"/>
    <field labelOnTop="1" name="KADASTROKS"/>
    <field labelOnTop="1" name="KADASTRZU"/>
    <field labelOnTop="1" name="MAIN_ACTIV"/>
    <field labelOnTop="1" name="MP_TYPE"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="OKVED"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS"/>
    <field labelOnTop="1" name="WRK_COUNT"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="ADD_ACTIV" reuseLastValue="0"/>
    <field name="BENT_TYPE" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="DANGER_OBJ" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="FUNCTION" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="HZRD_CAT" reuseLastValue="0"/>
    <field name="HZRD_CLASS" reuseLastValue="0"/>
    <field name="KADASTROKS" reuseLastValue="0"/>
    <field name="KADASTRZU" reuseLastValue="0"/>
    <field name="MAIN_ACTIV" reuseLastValue="0"/>
    <field name="MP_TYPE" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="OKVED" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="WRK_COUNT" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
