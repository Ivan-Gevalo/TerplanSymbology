<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis styleCategories="Symbology|Fields|Forms" version="3.28.15-Firenze">
  <renderer-v2 type="singleSymbol" enableorderby="0" referencescale="-1" symbollevels="0" forceraster="0">
    <symbols>
      <symbol name="0" type="fill" is_animated="0" force_rhr="0" clip_to_extent="1" frame_rate="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" class="SimpleFill" enabled="1" locked="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="114,155,111,0"/>
            <Option name="joinstyle" type="QString" value="miter"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="170,102,205,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.7"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer pass="0" class="SimpleLine" enabled="1" locked="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="miter"/>
            <Option name="line_color" type="QString" value="170,102,205,255"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.2"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="1"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer pass="0" class="MarkerLine" enabled="1" locked="0">
          <Option type="Map">
            <Option name="average_angle_length" type="QString" value="0"/>
            <Option name="average_angle_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="average_angle_unit" type="QString" value="MM"/>
            <Option name="interval" type="QString" value="1.5"/>
            <Option name="interval_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="interval_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_along_line" type="QString" value="0"/>
            <Option name="offset_along_line_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_along_line_unit" type="QString" value="MM"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="place_on_every_part" type="bool" value="true"/>
            <Option name="placements" type="QString" value="Interval"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="rotate" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
          <symbol name="@0@2" type="marker" is_animated="0" force_rhr="0" clip_to_extent="1" frame_rate="10" alpha="1">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" class="SimpleMarker" enabled="1" locked="0">
              <Option type="Map">
                <Option name="angle" type="QString" value="0"/>
                <Option name="cap_style" type="QString" value="square"/>
                <Option name="color" type="QString" value="255,0,0,255"/>
                <Option name="horizontal_anchor_point" type="QString" value="1"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="name" type="QString" value="line"/>
                <Option name="offset" type="QString" value="0,-0.75"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="170,102,205,255"/>
                <Option name="outline_style" type="QString" value="solid"/>
                <Option name="outline_width" type="QString" value="0.3"/>
                <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="outline_width_unit" type="QString" value="MM"/>
                <Option name="scale_method" type="QString" value="diameter"/>
                <Option name="size" type="QString" value="0.6"/>
                <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="size_unit" type="QString" value="MM"/>
                <Option name="vertical_anchor_point" type="QString" value="1"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" type="bool" value="false"/>
            <Option name="UseHtml" type="bool" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Граница территории исторического поселения" type="QString" value="604020100"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" type="bool" value="false"/>
            <Option name="UseHtml" type="bool" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SETTL_CAT" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" type="QString" value="1"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" type="QString" value="2"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" type="bool" value="true"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" type="bool" value="false"/>
            <Option name="UseHtml" type="bool" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" name="Идентификатор объекта" index="0"/>
    <alias field="CLASSID" name="" index="1"/>
    <alias field="NAME" name="Наименование объекта" index="2"/>
    <alias field="SETTL_CAT" name="Категория историко-культурного значения исторического поселения" index="3"/>
    <alias field="SOURCE" name="Источник данных (вносятся реквизиты правовых актов об утверждении границ территории и предмета охраны исторического поселения)" index="4"/>
    <alias field="NOTE" name="Примечание" index="5"/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'604020100'" applyOnUpdate="1"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="SETTL_CAT" expression="1" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="GLOBALID" constraints="3" notnull_strength="1" exp_strength="0" unique_strength="1"/>
    <constraint field="CLASSID" constraints="1" notnull_strength="1" exp_strength="0" unique_strength="0"/>
    <constraint field="NAME" constraints="5" notnull_strength="1" exp_strength="1" unique_strength="0"/>
    <constraint field="SETTL_CAT" constraints="1" notnull_strength="1" exp_strength="0" unique_strength="0"/>
    <constraint field="SOURCE" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
    <constraint field="NOTE" constraints="0" notnull_strength="0" exp_strength="0" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="SETTL_CAT" desc="" exp=""/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" strikethrough="0" bold="0" underline="0" style="" italic="0"/>
    </labelStyle>
    <attributeEditorContainer name="Обязательные атрибуты" collapsed="0" visibilityExpression="" collapsedExpressionEnabled="0" showLabel="1" visibilityExpressionEnabled="0" groupBox="0" columnCount="1" collapsedExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" strikethrough="0" bold="0" underline="0" style="" italic="0"/>
      </labelStyle>
      <attributeEditorField name="GLOBALID" index="0" showLabel="1">
        <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0" bold="1" underline="0" style="" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="CLASSID" index="1" showLabel="1">
        <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0" bold="1" underline="0" style="" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="NAME" index="2" showLabel="1">
        <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0" bold="1" underline="0" style="" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="SETTL_CAT" index="3" showLabel="1">
        <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0" bold="1" underline="0" style="" italic="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer name="Необязательные атрибуты" collapsed="0" visibilityExpression="" collapsedExpressionEnabled="0" showLabel="1" visibilityExpressionEnabled="0" groupBox="0" columnCount="1" collapsedExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" strikethrough="0" bold="0" underline="0" style="" italic="0"/>
      </labelStyle>
      <attributeEditorField name="SOURCE" index="4" showLabel="1">
        <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0" bold="1" underline="0" style="" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="NOTE" index="5" showLabel="1">
        <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="1">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" strikethrough="0" bold="1" underline="0" style="" italic="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="CLASSID" editable="0"/>
    <field name="GLOBALID" editable="0"/>
    <field name="NAME" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="SETTL_CAT" editable="1"/>
    <field name="SOURCE" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="CLASSID" labelOnTop="1"/>
    <field name="GLOBALID" labelOnTop="1"/>
    <field name="NAME" labelOnTop="1"/>
    <field name="NOTE" labelOnTop="1"/>
    <field name="SETTL_CAT" labelOnTop="1"/>
    <field name="SOURCE" labelOnTop="1"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="SETTL_CAT" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" type="bool" value="true"/>
            <Option name="expression" type="QString" value="'Код объекта: ' || attribute(@feature, 'CLASSID')"/>
            <Option name="type" type="int" value="3"/>
          </Option>
        </Option>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>2</layerGeometryType>
</qgis>
