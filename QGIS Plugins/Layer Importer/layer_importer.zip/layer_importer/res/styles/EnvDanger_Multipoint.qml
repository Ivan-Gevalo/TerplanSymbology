<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{a841c9b9-6bc9-43c9-a9f2-d1556d82c79f}">
      <rule label="Объекты накопленного вреда окружающей среде" filter="&quot;CLASSID&quot; = '705030100'" symbol="0" key="{f57f5d7e-f8b3-45f5-95b1-06bf2370f286}"/>
      <rule label="Водные объекты, подлежащие реабилитации" filter="&quot;CLASSID&quot; = '705030200'" symbol="1" key="{77053248-96a0-407c-91b8-5a2d2d0e7bc2}"/>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5Ny44bW0iIGhlaWdodD0iMTk3LjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgMTk3LjggMTk3LjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYuMDk4IC02My4yMjYpIj48cmVjdCB4PSIxMC42OTUiIHk9IjY3LjgyMyIgd2lkdGg9IjE4OC42MSIgaGVpZ2h0PSIxODguNjEiIHJ5PSIyNy4wNjEiIGZpbGw9IiNmZmYiLz48ZyBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCI+PHJlY3QgeD0iMTAuNjk1IiB5PSI2Ny44MjMiIHdpZHRoPSIxODguNjEiIGhlaWdodD0iMTg4LjYxIiByeT0iMjcuMDYxIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI5LjE5NSIvPjxyZWN0IHg9IjQ2LjYzMSIgeT0iMTAzLjc2IiB3aWR0aD0iMTE2Ljc0IiBoZWlnaHQ9IjExNi43NCIgcnk9IjAiIHN0cm9rZS13aWR0aD0iMTEuNjg3Ii8+PHJlY3QgeD0iNjkuNDc0IiB5PSIxMjYuNiIgd2lkdGg9IjcxLjA1MyIgaGVpZ2h0PSI3MS4wNTMiIHJ5PSIwIiBzdHJva2Utd2lkdGg9IjE0Ljc0NSIvPjwvZz48cmVjdCB4PSI4My44NTYiIHk9IjE0MC45OCIgd2lkdGg9IjQyLjI4OCIgaGVpZ2h0PSI0Mi4yODgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE5Ny44bW0iIGhlaWdodD0iMTk3LjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgMTk3LjggMTk3LjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYuMDk4IC02My4yMjYpIj48cmVjdCB4PSIxMC42OTUiIHk9IjY3LjgyMyIgd2lkdGg9IjE4OC42MSIgaGVpZ2h0PSIxODguNjEiIHJ5PSIyNy4wNjEiIGZpbGw9IiNmZmYiLz48cmVjdCB4PSIxMC42OTUiIHk9IjY3LjgyMyIgd2lkdGg9IjE4OC42MSIgaGVpZ2h0PSIxODguNjEiIHJ5PSIyNy4wNjEiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI5LjE5NSIvPjxyZWN0IHg9IjQ2LjYzMSIgeT0iMTAzLjc2IiB3aWR0aD0iMTE2Ljc0IiBoZWlnaHQ9IjExNi43NCIgcnk9IjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjExLjY4NyIvPjxyZWN0IHg9IjgzLjg1NiIgeT0iMTQwLjk4IiB3aWR0aD0iNDIuMjg4IiBoZWlnaHQ9IjQyLjI4OCIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Объекты накопленного вреда окружающей среде" value="705030100" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Водные объекты, подлежащие реабилитации" value="705030200" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OBJ_DESC" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="AREA" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name="Номер согласно положению о территориальном планировании"/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="OBJ_DESC" index="6" name="Описание объекта"/>
    <alias field="AREA" index="7" name="Площадь, га"/>
    <alias field="SOURCE" index="8" name="Источник данных (вносятся реквизиты правовых актов о решении создания объектов или другие источники данных)"/>
    <alias field="NOTE" index="9" name="Примечание"/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'705030100'" applyOnUpdate="1"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="OBJ_DESC" expression="''" applyOnUpdate="0"/>
    <default field="AREA" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="OBJ_DESC" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="AREA" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="" exp=""/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="OBJ_DESC" desc="" exp=""/>
    <constraint field="AREA" desc="" exp=""/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="6" name="OBJ_DESC">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="7" name="AREA">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="8" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="9" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="2" name="NUMBER">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="AREA" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="NAME" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="OBJ_DESC" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="SOURCE" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="AREA"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="OBJ_DESC"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="SOURCE"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="AREA" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="OBJ_DESC" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
