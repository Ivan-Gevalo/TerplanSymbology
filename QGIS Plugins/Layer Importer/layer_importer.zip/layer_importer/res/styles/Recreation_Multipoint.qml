<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{b0759647-6a60-4800-979f-e5aa47baa768}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{7590c9fa-151a-4c45-b279-f796e4591fe7}">
        <rule label="Гостиницы и аналогичные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010601'" symbol="1" key="{94ff3558-4713-457b-914e-5f147326144c}"/>
        <rule label="Специализированные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010602'" symbol="2" key="{4aad40c1-2fe6-40b2-b34a-fc6d700f54a4}"/>
        <rule label="Детский оздоровительный лагерь" filter="&quot;CLASSID&quot; = '602010603'" symbol="3" key="{50e824e8-ec10-4c4a-8cce-6eebb8608325}"/>
        <rule label="Оздоровительно-спортивный лагерь" filter="&quot;CLASSID&quot; = '602010604'" symbol="4" key="{8c27136a-884b-4bd7-8fdd-1364752464a5}"/>
        <rule label="Объекты физкультурно-досугового назначения и активного отдыха" filter="&quot;CLASSID&quot; = '602010605'" symbol="5" key="{a5dc7f74-ad41-4b67-986a-312f9aad8eb9}"/>
        <rule label="Места и объекты массового посещения, в том числе тематический туризм" filter="&quot;CLASSID&quot; = '602010607'" symbol="6" key="{4a8a6876-3020-4c50-bc2c-eb3546e37775}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="7" key="{c70411cc-6a6a-4295-b197-a993cc85c8ae}">
        <rule label="Гостиницы и аналогичные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010601'" symbol="8" key="{5e74ec5b-927d-468d-a300-573dfb522701}"/>
        <rule label="Специализированные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010602'" symbol="9" key="{5ba0615e-a15e-4ebf-b154-d43cc6c4bd4c}"/>
        <rule label="Детский оздоровительный лагерь" filter="&quot;CLASSID&quot; = '602010603'" symbol="10" key="{fd82152b-c889-4b2b-a01f-76cd31929559}"/>
        <rule label="Оздоровительно-спортивный лагерь" filter="&quot;CLASSID&quot; = '602010604'" symbol="11" key="{d009d6a5-9c40-4ab4-92a0-f5b667100687}"/>
        <rule label="Объекты физкультурно-досугового назначения и активного отдыха" filter="&quot;CLASSID&quot; = '602010605'" symbol="12" key="{e7efd677-b81e-497e-8c3a-a6f716cce47f}"/>
        <rule label="Места и объекты массового посещения, в том числе тематический туризм" filter="&quot;CLASSID&quot; = '602010607'" symbol="13" key="{28d7df1e-029e-4e71-b5f9-dbb49b620548}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="14" key="{de2346b8-8b43-4fe7-9a76-2d317a45e11e}">
        <rule label="Гостиницы и аналогичные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010601'" symbol="15" key="{03df3141-106c-4369-9863-3347c328cb1d}"/>
        <rule label="Специализированные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010602'" symbol="16" key="{93d68d92-794f-4148-a589-00c95a565a24}"/>
        <rule label="Детский оздоровительный лагерь" filter="&quot;CLASSID&quot; = '602010603'" symbol="17" key="{2cff9ee9-4089-4ea7-afdd-ff038e13426a}"/>
        <rule label="Оздоровительно-спортивный лагерь" filter="&quot;CLASSID&quot; = '602010604'" symbol="18" key="{1d370912-0ac8-4e8a-8d2f-64a22c0ccdce}"/>
        <rule label="Объекты физкультурно-досугового назначения и активного отдыха" filter="&quot;CLASSID&quot; = '602010605'" symbol="19" key="{4af4790e-4c60-4705-8373-590a5ac47365}"/>
        <rule label="Места и объекты массового посещения, в том числе тематический туризм" filter="&quot;CLASSID&quot; = '602010607'" symbol="20" key="{d702fa65-bd76-4352-aa3a-de83ae0d60b9}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="21" key="{03721fcb-d4f9-440c-8281-d25e640fa0d9}">
        <rule label="Гостиницы и аналогичные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010601'" symbol="22" key="{54231170-8c66-4f97-a1ec-6ec99c9c97c1}"/>
        <rule label="Специализированные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010602'" symbol="23" key="{c650f72c-7408-4e23-9618-9542ff368aaf}"/>
        <rule label="Детский оздоровительный лагерь" filter="&quot;CLASSID&quot; = '602010603'" symbol="24" key="{581cc5b7-2210-4625-a425-2aff10758f7d}"/>
        <rule label="Оздоровительно-спортивный лагерь" filter="&quot;CLASSID&quot; = '602010604'" symbol="25" key="{fbb325ac-d92b-4277-8e3f-fd89a5ab1f6b}"/>
        <rule label="Объекты физкультурно-досугового назначения и активного отдыха" filter="&quot;CLASSID&quot; = '602010605'" symbol="26" key="{177e90f1-6af0-40a7-bc96-23e61fa53918}"/>
        <rule label="Места и объекты массового посещения, в том числе тематический туризм" filter="&quot;CLASSID&quot; = '602010607'" symbol="27" key="{090b2ae3-d266-4933-92bf-e8ae62f3935c}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="28" key="{93caa1e3-736e-4258-b785-63532bac903d}">
        <rule label="Гостиницы и аналогичные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010601'" symbol="29" key="{54c9855e-00a3-4f88-a3ca-fc19db4699ed}"/>
        <rule label="Специализированные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010602'" symbol="30" key="{7f91c13c-91c8-4c8b-a934-1a923d1b8a03}"/>
        <rule label="Детский оздоровительный лагерь" filter="&quot;CLASSID&quot; = '602010603'" symbol="31" key="{c084477c-c9e8-4644-ab8f-57eb8a802f5a}"/>
        <rule label="Оздоровительно-спортивный лагерь" filter="&quot;CLASSID&quot; = '602010604'" symbol="32" key="{d9055d3d-5eb0-40c8-b40e-48d8a25c37ee}"/>
        <rule label="Объекты физкультурно-досугового назначения и активного отдыха" filter="&quot;CLASSID&quot; = '602010605'" symbol="33" key="{8fd7511a-fce1-4aa0-9220-43d8d005e34f}"/>
        <rule label="Места и объекты массового посещения, в том числе тематический туризм" filter="&quot;CLASSID&quot; = '602010607'" symbol="34" key="{c416a470-83fc-4b26-a601-62b0eeb6314e}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="35" key="{82bcba68-458a-48c5-bcec-835e4bd080e9}">
        <rule label="Гостиницы и аналогичные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010601'" symbol="36" key="{0d2fb85b-d249-4d41-8b8e-a27a52b890e0}"/>
        <rule label="Специализированные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010602'" symbol="37" key="{7d0501bc-4c60-4c14-93d5-949f556be6ee}"/>
        <rule label="Детский оздоровительный лагерь" filter="&quot;CLASSID&quot; = '602010603'" symbol="38" key="{bc6908ef-8380-4acb-b5a0-def78c73e638}"/>
        <rule label="Оздоровительно-спортивный лагерь" filter="&quot;CLASSID&quot; = '602010604'" symbol="39" key="{152db0b8-38f1-4adc-a084-fcdc740d56f2}"/>
        <rule label="Объекты физкультурно-досугового назначения и активного отдыха" filter="&quot;CLASSID&quot; = '602010605'" symbol="40" key="{723d036e-661b-4269-8fa7-fc50df519934}"/>
        <rule label="Места и объекты массового посещения, в том числе тематический туризм" filter="&quot;CLASSID&quot; = '602010607'" symbol="41" key="{b4fb27c1-b739-4393-b614-97e4b1656f3a}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="42" key="{e39b146c-7b63-408a-b184-20bca216adc7}">
        <rule label="Гостиницы и аналогичные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010601'" symbol="43" key="{6ad7fec6-002d-4dc0-9b69-b362d62b371e}"/>
        <rule label="Специализированные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010602'" symbol="44" key="{984f7daf-984b-4a9a-b7a3-2d222b4e6920}"/>
        <rule label="Детский оздоровительный лагерь" filter="&quot;CLASSID&quot; = '602010603'" symbol="45" key="{0d3f79cc-04d5-4b3b-af24-8dc29a6de99f}"/>
        <rule label="Оздоровительно-спортивный лагерь" filter="&quot;CLASSID&quot; = '602010604'" symbol="46" key="{646eed0a-c29a-4fc4-be35-809db716f370}"/>
        <rule label="Объекты физкультурно-досугового назначения и активного отдыха" filter="&quot;CLASSID&quot; = '602010605'" symbol="47" key="{e85a4a44-c807-42d3-9962-d99f169b432f}"/>
        <rule label="Места и объекты массового посещения, в том числе тематический туризм" filter="&quot;CLASSID&quot; = '602010607'" symbol="48" key="{b180e0a2-13f8-4438-950b-5c8792ecb9fc}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты регионального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 2" symbol="49" key="{aa89bdd5-21ba-4731-8a65-f5f4b5272aaf}">
        <rule label="Гостиницы и аналогичные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010601'" symbol="50" key="{2d76f98d-1b5a-4c25-bcfc-a7c53fb04689}"/>
        <rule label="Специализированные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010602'" symbol="51" key="{16418fa0-6589-46bc-99c7-7f3565be272f}"/>
        <rule label="Детский оздоровительный лагерь" filter="&quot;CLASSID&quot; = '602010603'" symbol="52" key="{ca43677a-d96f-4131-8452-d5c5a8bd3548}"/>
        <rule label="Оздоровительно-спортивный лагерь" filter="&quot;CLASSID&quot; = '602010604'" symbol="53" key="{f0a46da5-82bc-43d7-b7ac-c1fdcabb519b}"/>
        <rule label="Объекты физкультурно-досугового назначения и активного отдыха" filter="&quot;CLASSID&quot; = '602010605'" symbol="54" key="{e54b8a29-5058-4520-97b6-aed4a11c81e7}"/>
        <rule label="Места и объекты массового посещения, в том числе тематический туризм" filter="&quot;CLASSID&quot; = '602010607'" symbol="55" key="{d376119e-b087-4fe9-98ad-057d3eb8f5a0}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="56" key="{c5febb43-e4c3-43b5-8aa2-e0974a6dc258}">
        <rule label="Гостиницы и аналогичные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010601'" symbol="57" key="{84dc0a63-a148-4cb1-9fa5-1d330af84f26}"/>
        <rule label="Специализированные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010602'" symbol="58" key="{177cca1e-b924-4675-b1bc-57f1ffdb584c}"/>
        <rule label="Детский оздоровительный лагерь" filter="&quot;CLASSID&quot; = '602010603'" symbol="59" key="{f6cf4ac3-a0b5-4775-bc2f-2f24105c16db}"/>
        <rule label="Оздоровительно-спортивный лагерь" filter="&quot;CLASSID&quot; = '602010604'" symbol="60" key="{8079f734-6bfc-406a-8d42-fceed340e54c}"/>
        <rule label="Объекты физкультурно-досугового назначения и активного отдыха" filter="&quot;CLASSID&quot; = '602010605'" symbol="61" key="{235bf6b9-f0e2-40f4-b4da-7df29ad8d8b9}"/>
        <rule label="Места и объекты массового посещения, в том числе тематический туризм" filter="&quot;CLASSID&quot; = '602010607'" symbol="62" key="{b049f363-5cc9-48a6-a67f-0706ff4f6b8b}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="63" key="{3da0d451-a2d5-4fe1-b851-92d510f2078e}">
        <rule label="Гостиницы и аналогичные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010601'" symbol="64" key="{e6e1e615-02e3-4c78-88b1-b0cd03cc81c3}"/>
        <rule label="Специализированные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010602'" symbol="65" key="{25106e41-ecf4-409d-8a12-b8022bcc5691}"/>
        <rule label="Детский оздоровительный лагерь" filter="&quot;CLASSID&quot; = '602010603'" symbol="66" key="{653d7fc7-a3f5-47b8-b80e-2855b555e032}"/>
        <rule label="Оздоровительно-спортивный лагерь" filter="&quot;CLASSID&quot; = '602010604'" symbol="67" key="{a80481d3-dad8-4d38-bbd6-0784938050c5}"/>
        <rule label="Объекты физкультурно-досугового назначения и активного отдыха" filter="&quot;CLASSID&quot; = '602010605'" symbol="68" key="{215aa976-7ad2-4a74-96fe-6826306f4483}"/>
        <rule label="Места и объекты массового посещения, в том числе тематический туризм" filter="&quot;CLASSID&quot; = '602010607'" symbol="69" key="{34472dec-6c0b-4a86-ba14-81a9458fb6ca}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="70" key="{2043e66e-02db-4fae-b903-6e5770c70a21}">
        <rule label="Гостиницы и аналогичные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010601'" symbol="71" key="{ac9b185b-5b5f-47a0-9b01-8c018a9d79d9}"/>
        <rule label="Специализированные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010602'" symbol="72" key="{7db8d66b-6606-4ce9-a797-b9d395f0820a}"/>
        <rule label="Детский оздоровительный лагерь" filter="&quot;CLASSID&quot; = '602010603'" symbol="73" key="{1ec04269-e269-4ded-8324-8a7fec622d03}"/>
        <rule label="Оздоровительно-спортивный лагерь" filter="&quot;CLASSID&quot; = '602010604'" symbol="74" key="{038aae2f-bc56-4fb5-a726-7eeaf24f2cda}"/>
        <rule label="Объекты физкультурно-досугового назначения и активного отдыха" filter="&quot;CLASSID&quot; = '602010605'" symbol="75" key="{be022cd2-9a2e-4436-96b6-da6a574f8dab}"/>
        <rule label="Места и объекты массового посещения, в том числе тематический туризм" filter="&quot;CLASSID&quot; = '602010607'" symbol="76" key="{690bc9f2-0630-4f35-bb90-64ca0bfd59c8}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты федерального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 1" symbol="77" key="{6ca6a35f-2643-4a37-81e9-2e1a9710357d}">
        <rule label="Гостиницы и аналогичные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010601'" symbol="78" key="{315565da-a66c-4926-9d25-bf3180df03ca}"/>
        <rule label="Специализированные коллективные средства размещения" filter="&quot;CLASSID&quot; = '602010602'" symbol="79" key="{8279d812-9285-4ef4-b715-0bcebb31f701}"/>
        <rule label="Детский оздоровительный лагерь" filter="&quot;CLASSID&quot; = '602010603'" symbol="80" key="{74f0bede-e949-4317-8a7e-9595e0164abc}"/>
        <rule label="Оздоровительно-спортивный лагерь" filter="&quot;CLASSID&quot; = '602010604'" symbol="81" key="{c3b8b126-4987-4075-ab14-6b017a77c37f}"/>
        <rule label="Объекты физкультурно-досугового назначения и активного отдыха" filter="&quot;CLASSID&quot; = '602010605'" symbol="82" key="{240fc292-f68c-4204-9f50-d88e4c8e3d34}"/>
        <rule label="Места и объекты массового посещения, в том числе тематический туризм" filter="&quot;CLASSID&quot; = '602010607'" symbol="83" key="{a8158d61-8df6-4e47-b8de-1def88e97796}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="152,125,183,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNy45Nm1tIiBoZWlnaHQ9IjE0Ny4xOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTcuOTYgMTQ3LjE5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40OTIgLTczLjA0NikiPjxyZWN0IHg9IjQ1LjQ5MiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjEzNC4zMiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjY0Ljk5NiIgeT0iMTM0Ljc4IiB3aWR0aD0iODQuMDY2IiBoZWlnaHQ9IjIzLjcyMSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.00707" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNS4xN21tIiBoZWlnaHQ9IjE1Ni42Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjUuMTcgMTU2LjY2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MC42MzcgLTc2LjA2OCkiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY0NThweCI+PHBhdGggZD0ibTEwNC4zNSA3Ni4xNjNzNS41MzM0IDkuNTA5OSA1LjU4NjcgMTQuNDg1YzAuMDUxMyA0Ljc4MzgtNC40MTYyIDguMjU5MS03LjkwMTYgMTEuMjIzLTEwLjMyNyA4Ljc4MTktMTkuNDY4IDE4LjQzNC0yMi4wMTkgMzAuNzkxLTEuOTI0OCA5LjMyNTYgMS42Mjk2IDE5LjQ4NyA2LjA1ODEgMjcuOTE3IDMuMzc0OSA2LjQyNCAxNC44OTkgMTUuODczIDE0Ljg5OSAxNS44NzNzMTIuNzQ2LTkuODI3OCAxNy4xMjgtMTYuNDFjNS4xNjkzLTcuNzY1MyA5LjI3MjUtMTYuODE5IDEwLjA2NC0yNi4xMTQgMS4xMzQ5LTEzLjMzLTEuMTM2Ni0yNy44MDUtNy44OTQyLTM5LjM1MS00LjEwNzctNy4wMTg1LTE1LjkyMS0xOC40MTUtMTUuOTIxLTE4LjQxNXoiLz48cGF0aCBkPSJtMTMzLjYgMTE1Ljg3czEuNzk5NSAyMS4wNzYtMS4yNzk4IDMwLjkyMmMtMy42MjkgMTEuNjAzLTE5LjUyNCAzMC44MDctMTkuNTI0IDMwLjgwN3MyNC40NDgtMi41ODI3IDMyLjIwNy0xMC44MzVjNi42MTczLTcuMDM4MiA5LjU4MjQtMTguNTQ1IDcuNTMxNi0yNy45ODYtMi4xMDMtOS42ODExLTE4LjkzNS0yMi45MDgtMTguOTM1LTIyLjkwOHoiLz48cGF0aCBkPSJtNzMuNzg4IDEyMS43cy0wLjg4MjU5IDguNzAyNi0zLjY1MDQgMTEuNzE0Yy02LjI2MjIgNi44MTIyLTExLjQ2NiAxNC45MzEtMTAuOTY5IDIzLjU4OSAwLjM3ODMyIDYuNTk2NCA0Ljg3MjYgMTMuMjE3IDEwLjM1OCAxNi45IDQuMTMzNCAyLjc3NTIgOS43NzI0IDIuNzE0OSAxNC43NDEgMi40MDMyIDQuMTEyLTAuMjU3ODggOC40NTAyIDEuMDkyNiA4LjQ1MDIgMS4wOTI2cy0xNC4wMS0xMC45MzUtMTcuMjg4LTE4Ljc4OWMtMy40OC04LjMzNjItMy4xNTg2LTE3LjQwNC0xLjI3NjMtMjcuMDcgMC42MjczLTMuMjIxNC0wLjM2NTM5LTkuODM4OC0wLjM2NTM5LTkuODM4OHoiLz48cGF0aCBkPSJtNDAuODIzIDIxOS42NiAxMDkuNTItNDIuMjE1IDUuNjkwOCA5LjE5MDEtMTA4LjUgNDUuOTJ6Ii8+PHBhdGggZD0ibTE2NS42MiAyMTkuMzgtMTA5LjUyLTQyLjIxNS01LjY5MDggOS4xOTAxIDEwOC41IDQ1LjkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.15476" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMC4wOW1tIiBoZWlnaHQ9IjE1OS41M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjAuMDkgMTU5LjUzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC41MjUgLTY3LjA4NykiPjxyZWN0IHg9IjQ0LjUyNSIgeT0iMjE2LjAzIiB3aWR0aD0iMTIwLjA5IiBoZWlnaHQ9IjEwLjU4Ii8+PHJlY3QgeD0iNzAuMTM3IiB5PSIxNjcuMjIiIHdpZHRoPSI2OC44NjciIGhlaWdodD0iNTAuMjY4Ii8+PHBhdGggdHJhbnNmb3JtPSJtYXRyaXgoLjk0NDMgMCAwIC42MzM2NSAxMC45NTUgNzcuMDM5KSIgZD0ibTE1Mi44MiAxNDcuMDdoLTEwNy4zN2w1My42ODUtOTIuOTg1eiIvPjxwYXRoIGQ9Im0xMDAuNjIgMTE4LjQ4di01MS4xODJsMzUuNjAzIDE2LjM3M3YyNS43NjhsLTI3LjA0My0xNS4xNHYyNy41NzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.76387" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk1Ljc3NG1tIiBoZWlnaHQ9IjE2Ni4zM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5NS43NzQgMTY2LjMzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi42NjQgLTY2LjAwNSkiPjxyZWN0IHRyYW5zZm9ybT0ibWF0cml4KC41MjM1NCAtLjg1MiAuODg1NDggLjQ2NDY4IDAgMCkiIHg9Ii04Ny40ODciIHk9IjEyMi40MyIgd2lkdGg9IjU3Ljk0MiIgaGVpZ2h0PSIxMC4xNCIvPjxjaXJjbGUgY3g9IjExOC45NCIgY3k9IjgwLjQ2IiByPSIxNC40NTUiLz48cGF0aCBkPSJtMTEwLjI4IDg0LjcwNXMtMjQuMjg1IDI5LjM5Mi0zMC45MTcgNDYuOTA1Yy0yLjgxMDMgNy40MjA5LTEuMzUxMyAxNS44ODktMy4zNTEyIDIzLjU2OC0yLjY2MDYgMTAuMjE2LTkuOTQwNiAyNi42NzUtMTQuMTg2IDM1LjE0Ni00LjY5MTkgOS4zNjItNS41NDAyIDEzLjc1MS04LjYyMjkgMjMuOTU1LTAuOTkxNTggMy4yODIyLTAuMjEyNCA4Ljg5NCAzLjA5MTUgOS44MTA2IDguMTAzNiAyLjI0OCAxNy41MTggMy40NTExIDE5LjY4OCAyLjMzODUgMS44MjM4LTAuOTM0ODQgMS43MTk5LTQuMjU2IDAuMjgyNzYtNS43Njg4LTEuNzIyMi0xLjgxMjctNi4wNDYxLTAuNzM3NjEtNy4wMjA4LTMuMTAzNC0xLjYwMjQtMy44ODk1LTAuNTg4Mi03LjUxOTIgMC40OTQ1NC0xMS40NCAyLjE3NDUtNy44NzUyIDcuODQ4OS0xMi4yMDQgMTIuMjM4LTIxLjU3MSAzLjc2ODQtOC4wNDIzIDcuNjA0OC0xNS4yNDQgMTAuNTUtMTUuMjQ0IDIuNDQ5OSAwIDYuODk3NyA4LjI1MjIgOS41OTA2IDEzLjA3MSAzLjY3ODMgNi41ODI3IDcuNzcgMTUuNTExIDguOTEzNyAyMy43ODIgMS40MzU5IDEwLjM4NSAxLjEwNDIgMTcuNzcgNi4wOTkzIDIzLjQxMSAyLjEwOTIgMi4zODE2IDcuNTgzNyAyLjE0NjQgMTIuODkyIDIuMjk2NiA0LjkzMTYgMC4xMzk1NCA4LjU2MjUgMS4wNzE0IDExLjE4Ny0wLjkzMjgxIDIuMzMxMS0xLjc4MDMtMS4xOTg2LTUuNjc3OS00LjA1NTQtNi42NjkyLTMuNDAxNS0xLjE4MDMtMTEuMTI5LTIuNTY3LTExLjg4NS02LjU1Ni0yLjE3MDYtMTEuNDUzLTMuMzAxNC0yMS4zOTEtNi45OTU5LTMxLjQ4OS0yLjgyOS03LjczMjItNy42NjQtMTQuMjQ1LTExLjQ2OS0yMS44NzYtMy4yNjgyLTYuNTU0NC00LjgxNzUtMTQuMjQ1LTIuOTQyMy0yNS40NiAwLjQ3NDU0LTIuODM3OSAxLjc5NTgtNi44NDU4IDUuNjE4My02LjU1MzIgMy43MjYzIDAuMjg1MjUgMTEuODgyIDYuNTI4NSAxNi41NzIgOS42Nzc3IDguNzM0MiA1Ljg2NDUgMTMuNzc1IDEwLjAxMSAxMy43NzUgMTAuMDExczUuMzU3IDIuMDkxOCA3LjEwMzUgMC40ODQ3YzEuMzM1Ni0xLjIyOSAyLjI0ODQtMi44MTk4IDAuMDgxMi01LjQ0NDQtMy44NDg2LTQuNjYwOC0xNy43NTQtMTIuNjYtMjMuMzk4LTE2LjMzMi0yLjgyNTgtMS44Mzc4LTQuNDY4OS0yLjEwNTUtNC42NzE5LTUuNjIyMi0wLjI1NDE1LTQuNDAzMyAwLTExLjIzMSAwLTE1Ljk5OHYtMjEuNTEyeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PHBhdGggZD0ibTEzOS45NyAxNDQuNjRzLTM0Ljk4NCA1Ni4wODgtNDkuMTExIDc5Ljc4M2MtMC44NjgzNyAxLjQ1NjUtMC4wNDEzOSA0LjExODEgMS40Nzk5IDQuODY3MSAxLjU3OCAwLjc3Njk1IDIuODgzMyAwLjQwNzM4IDQuOTM3NC0xLjg2MTggMi44ODkxLTMuMTkxNiA0OC41My03OC4xOTQgNDguNTMtNzguMTk0eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.10936" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3MC40NW1tIiBoZWlnaHQ9IjE3My43OG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzAuNDUgMTczLjc4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMS4zNTUgLTUxLjYxNykiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyOC41IC44OTA1NCkiPjxnIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0ibS0yNzAuOTIgMTExLjYxIDEyLjc1MiAyLjU5NzFjMi4wNDc5IDAuNDE3MDkgMy4zNjA4IDIuNDAxNSAyLjk0MzcgNC40NDk0bC04LjcyMjMgNDIuODI3Yy0wLjQxNzA4IDIuMDQ3OS0yLjM3NjEgMi42ODA3LTQuNDQ5NCAyLjk0MzdsLTEyLjgxMiAxLjYyNTZjLTAuOTk4NzQgMC4xMjY3MiAwLjI3ODA2LTMuMjc3NC0wLjU4NjY3LTUuMDc2LTAuOTMwMzctMS45MzUyLTEuMTIwOC01LjI4MjUtMC45MjU0Mi02LjM0NzlsNy4zNTA5LTQwLjA3NWMwLjM3NzA3LTIuMDU1NiAyLjQwMTUtMy4zNjA4IDQuNDQ5NC0yLjk0Mzd6IiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi42MjI2Ii8+PHBhdGggZD0ibS0yNTcuMjggMjE2LjQ2IDIuNzIwOC0zNS41NzYtMTguMTI0LTI1LjY0Mi03LjEyNzQgMzAuMTM0LTE5LjM3MSAzMS4zNTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMy40NSIvPjxwYXRoIGQ9Im0tMjM0LjkzIDEzOS45cy0xMS4wNCAwLjU0NDU3LTE0Ljg5NC0yLjcxMzJjLTQuNjI1MS0zLjkwOTUtMy44MzItMTUuMjAyLTYuMTg2OS0xNy4wODItNC4wNzI4LTMuMjUyMi0xNS4xMzgtNC41ODcyLTE1LjEzOC00LjU4NzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI4LjY1Ii8+PC9nPjxjaXJjbGUgY3g9Ii0yNTYuODQiIGN5PSI5Ni4yMzQiIHI9IjE0LjEzIi8+PHBhdGggZD0ibS0yMzYuNjUgMTIzLjEzLTMuNzQxNCA5OC41MzkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQuNzUiLz48cGF0aCBkPSJtLTI4My40OCAxMDkuNDUgMy4xNDQ0IDAuNzY4NDNjMy41MDA4IDAuODU1NTMgMy4xOTk1IDIuNzY2IDIuNDMxOCA2LjgxNTZsLTUuODcwNyAzMC45NjljLTAuNzY3NjggNC4wNDk3LTQuMjA0MSA2LjYyMTItNy43MDQ5IDUuNzY1NmwtMTAuMTctMi40ODUzYy0zLjUwMDgtMC44NTU1NC02Ljg1NTgtNS4zNDQtNC45MzM1LTguODU0MmwxNS45NzUtMjkuMTcxYzEuOTIyMy0zLjUxMDMgMy42MjcxLTQuNjY0MyA3LjEyNzktMy44MDg3eiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMy4wMjY1Ii8+PHBhdGggZD0ibS0yNTYuMTIgMTE1LjAycy0yLjU0NzMtMS4wNjcxLTIuOTc5LTIuNTY4M2MtMC40OTM5MS0xLjcxNzgtMC4yMDMyOS00LjUzNzYtMC4yMDMyOS00LjUzNzZsLTUuMTE1NC02LjI1MDNzLTAuNDUyMzYgNC43MDY5LTEuNzA4OCA2LjYwMDljLTEuMjIyNiAxLjg0My02LjE4IDMuMDgwOC02LjE4IDMuMDgwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Im0xNDIuNDUgODcuNzQ3IDE1LjYxMiAzLjE3OTZjMi41MDcyIDAuNTEwNjQgNC4xMTQ2IDIuOTQwMiAzLjYwNCA1LjQ0NzRsLTEwLjY3OSA1Mi40MzJjLTAuNTEwNjMgMi41MDcyLTIuOTA5MSAzLjI4MTktNS40NDc0IDMuNjA0bC0xNS42ODYgMS45OTAxYy0xLjIyMjggMC4xNTUxNCAwLjM0MDQzLTQuMDEyNS0wLjcxODI1LTYuMjE0NS0xLjEzOS0yLjM2OTItMS4zNzIyLTYuNDY3My0xLjEzMy03Ljc3MTdsOC45OTk2LTQ5LjA2M2MwLjQ2MTY1LTIuNTE2NyAyLjk0MDItNC4xMTQ2IDUuNDQ3NC0zLjYwNHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjIxMDkiLz48cGF0aCBkPSJtMTU5LjE1IDIxNi4xIDMuMzMxMS00My41NTUtMjIuMTg5LTMxLjM5NC04LjcyNiAzNi44OTItMjMuNzE2IDM4LjM4OSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjE2LjQ2NyIvPjxwYXRoIGQ9Im0xODYuNTEgMTIyLjM4cy0xMy41MTcgMC42NjY3MS0xOC4yMzUtMy4zMjE4Yy01LjY2MjQtNC43ODYzLTQuNjkxNC0xOC42MTEtNy41NzQ2LTIwLjkxMy00Ljk4NjMtMy45ODE2LTE4LjUzMy01LjYxNi0xOC41MzMtNS42MTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMC41OSIvPjwvZz48Y2lyY2xlIGN4PSIxNTkuNjkiIGN5PSI2OC45MTYiIHI9IjE3LjMiLz48cGF0aCBkPSJtMTgzLjEgMTA2Ljc5LTQuMDExOCAxMDUuNjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUuMDkzNCIvPjxwYXRoIGQ9Im0xMjcuMDggODUuMDk1IDMuODQ5NiAwLjk0MDc4YzQuMjg2IDEuMDQ3NCAzLjkxNzEgMy4zODYzIDIuOTc3MiA4LjM0NDNsLTcuMTg3NCAzNy45MTVjLTAuOTM5ODcgNC45NTgtNS4xNDcgOC4xMDYyLTkuNDMzIDcuMDU4OGwtMTIuNDUxLTMuMDQyN2MtNC4yODYtMS4wNDc0LTguMzkzNS02LjU0MjUtNi4wNC0xMC44NGwxOS41NTgtMzUuNzEzYzIuMzUzNC00LjI5NzYgNC40NDA2LTUuNzEwNCA4LjcyNjYtNC42NjN6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjcwNTMiLz48cGF0aCBkPSJtMTYwLjU4IDkxLjkxOHMtMy4xMTg2LTEuMzA2NS0zLjY0NzEtMy4xNDQzYy0wLjYwNDY5LTIuMTAzLTAuMjQ4ODktNS41NTUzLTAuMjQ4ODktNS41NTUzbC02LjI2MjgtNy42NTIxcy0wLjU1MzgyIDUuNzYyNy0yLjA5MjEgOC4wODE0Yy0xLjQ5NjggMi4yNTYzLTcuNTY2MSAzLjc3MTctNy41NjYxIDMuNzcxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="225,89,137,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNy45Nm1tIiBoZWlnaHQ9IjE0Ny4xOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTcuOTYgMTQ3LjE5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40OTIgLTczLjA0NikiPjxyZWN0IHg9IjQ1LjQ5MiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjEzNC4zMiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjY0Ljk5NiIgeT0iMTM0Ljc4IiB3aWR0aD0iODQuMDY2IiBoZWlnaHQ9IjIzLjcyMSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.00707" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS41OW1tIiBoZWlnaHQ9IjE2MS41OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuNTkgMTYxLjU5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xOS4xNTkgLTYxLjY3NSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC4wOTU0NTIgLS4wODA3MTEpIj48cmVjdCB4PSI2Mi4zNjEiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSIxMTguODQiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSI3NC43NjIiIHk9IjEzNS4wMSIgd2lkdGg9IjUzLjQ0OSIgaGVpZ2h0PSIxNS4wODEiLz48L2c+PGNpcmNsZSBjeD0iOTkuOTU2IiBjeT0iMTQyLjQ3IiByPSI3My4yMDIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMTUuMTkiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNS4xN21tIiBoZWlnaHQ9IjE1Ni42Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjUuMTcgMTU2LjY2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MC42MzcgLTc2LjA2OCkiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY0NThweCI+PHBhdGggZD0ibTEwNC4zNSA3Ni4xNjNzNS41MzM0IDkuNTA5OSA1LjU4NjcgMTQuNDg1YzAuMDUxMyA0Ljc4MzgtNC40MTYyIDguMjU5MS03LjkwMTYgMTEuMjIzLTEwLjMyNyA4Ljc4MTktMTkuNDY4IDE4LjQzNC0yMi4wMTkgMzAuNzkxLTEuOTI0OCA5LjMyNTYgMS42Mjk2IDE5LjQ4NyA2LjA1ODEgMjcuOTE3IDMuMzc0OSA2LjQyNCAxNC44OTkgMTUuODczIDE0Ljg5OSAxNS44NzNzMTIuNzQ2LTkuODI3OCAxNy4xMjgtMTYuNDFjNS4xNjkzLTcuNzY1MyA5LjI3MjUtMTYuODE5IDEwLjA2NC0yNi4xMTQgMS4xMzQ5LTEzLjMzLTEuMTM2Ni0yNy44MDUtNy44OTQyLTM5LjM1MS00LjEwNzctNy4wMTg1LTE1LjkyMS0xOC40MTUtMTUuOTIxLTE4LjQxNXoiLz48cGF0aCBkPSJtMTMzLjYgMTE1Ljg3czEuNzk5NSAyMS4wNzYtMS4yNzk4IDMwLjkyMmMtMy42MjkgMTEuNjAzLTE5LjUyNCAzMC44MDctMTkuNTI0IDMwLjgwN3MyNC40NDgtMi41ODI3IDMyLjIwNy0xMC44MzVjNi42MTczLTcuMDM4MiA5LjU4MjQtMTguNTQ1IDcuNTMxNi0yNy45ODYtMi4xMDMtOS42ODExLTE4LjkzNS0yMi45MDgtMTguOTM1LTIyLjkwOHoiLz48cGF0aCBkPSJtNzMuNzg4IDEyMS43cy0wLjg4MjU5IDguNzAyNi0zLjY1MDQgMTEuNzE0Yy02LjI2MjIgNi44MTIyLTExLjQ2NiAxNC45MzEtMTAuOTY5IDIzLjU4OSAwLjM3ODMyIDYuNTk2NCA0Ljg3MjYgMTMuMjE3IDEwLjM1OCAxNi45IDQuMTMzNCAyLjc3NTIgOS43NzI0IDIuNzE0OSAxNC43NDEgMi40MDMyIDQuMTEyLTAuMjU3ODggOC40NTAyIDEuMDkyNiA4LjQ1MDIgMS4wOTI2cy0xNC4wMS0xMC45MzUtMTcuMjg4LTE4Ljc4OWMtMy40OC04LjMzNjItMy4xNTg2LTE3LjQwNC0xLjI3NjMtMjcuMDcgMC42MjczLTMuMjIxNC0wLjM2NTM5LTkuODM4OC0wLjM2NTM5LTkuODM4OHoiLz48cGF0aCBkPSJtNDAuODIzIDIxOS42NiAxMDkuNTItNDIuMjE1IDUuNjkwOCA5LjE5MDEtMTA4LjUgNDUuOTJ6Ii8+PHBhdGggZD0ibTE2NS42MiAyMTkuMzgtMTA5LjUyLTQyLjIxNS01LjY5MDggOS4xOTAxIDEwOC41IDQ1LjkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.15476" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMC4wOW1tIiBoZWlnaHQ9IjE1OS41M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjAuMDkgMTU5LjUzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC41MjUgLTY3LjA4NykiPjxyZWN0IHg9IjQ0LjUyNSIgeT0iMjE2LjAzIiB3aWR0aD0iMTIwLjA5IiBoZWlnaHQ9IjEwLjU4Ii8+PHJlY3QgeD0iNzAuMTM3IiB5PSIxNjcuMjIiIHdpZHRoPSI2OC44NjciIGhlaWdodD0iNTAuMjY4Ii8+PHBhdGggdHJhbnNmb3JtPSJtYXRyaXgoLjk0NDMgMCAwIC42MzM2NSAxMC45NTUgNzcuMDM5KSIgZD0ibTE1Mi44MiAxNDcuMDdoLTEwNy4zN2w1My42ODUtOTIuOTg1eiIvPjxwYXRoIGQ9Im0xMDAuNjIgMTE4LjQ4di01MS4xODJsMzUuNjAzIDE2LjM3M3YyNS43NjhsLTI3LjA0My0xNS4xNHYyNy41NzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.76387" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk1Ljc3NG1tIiBoZWlnaHQ9IjE2Ni4zM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5NS43NzQgMTY2LjMzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi42NjQgLTY2LjAwNSkiPjxyZWN0IHRyYW5zZm9ybT0ibWF0cml4KC41MjM1NCAtLjg1MiAuODg1NDggLjQ2NDY4IDAgMCkiIHg9Ii04Ny40ODciIHk9IjEyMi40MyIgd2lkdGg9IjU3Ljk0MiIgaGVpZ2h0PSIxMC4xNCIvPjxjaXJjbGUgY3g9IjExOC45NCIgY3k9IjgwLjQ2IiByPSIxNC40NTUiLz48cGF0aCBkPSJtMTEwLjI4IDg0LjcwNXMtMjQuMjg1IDI5LjM5Mi0zMC45MTcgNDYuOTA1Yy0yLjgxMDMgNy40MjA5LTEuMzUxMyAxNS44ODktMy4zNTEyIDIzLjU2OC0yLjY2MDYgMTAuMjE2LTkuOTQwNiAyNi42NzUtMTQuMTg2IDM1LjE0Ni00LjY5MTkgOS4zNjItNS41NDAyIDEzLjc1MS04LjYyMjkgMjMuOTU1LTAuOTkxNTggMy4yODIyLTAuMjEyNCA4Ljg5NCAzLjA5MTUgOS44MTA2IDguMTAzNiAyLjI0OCAxNy41MTggMy40NTExIDE5LjY4OCAyLjMzODUgMS44MjM4LTAuOTM0ODQgMS43MTk5LTQuMjU2IDAuMjgyNzYtNS43Njg4LTEuNzIyMi0xLjgxMjctNi4wNDYxLTAuNzM3NjEtNy4wMjA4LTMuMTAzNC0xLjYwMjQtMy44ODk1LTAuNTg4Mi03LjUxOTIgMC40OTQ1NC0xMS40NCAyLjE3NDUtNy44NzUyIDcuODQ4OS0xMi4yMDQgMTIuMjM4LTIxLjU3MSAzLjc2ODQtOC4wNDIzIDcuNjA0OC0xNS4yNDQgMTAuNTUtMTUuMjQ0IDIuNDQ5OSAwIDYuODk3NyA4LjI1MjIgOS41OTA2IDEzLjA3MSAzLjY3ODMgNi41ODI3IDcuNzcgMTUuNTExIDguOTEzNyAyMy43ODIgMS40MzU5IDEwLjM4NSAxLjEwNDIgMTcuNzcgNi4wOTkzIDIzLjQxMSAyLjEwOTIgMi4zODE2IDcuNTgzNyAyLjE0NjQgMTIuODkyIDIuMjk2NiA0LjkzMTYgMC4xMzk1NCA4LjU2MjUgMS4wNzE0IDExLjE4Ny0wLjkzMjgxIDIuMzMxMS0xLjc4MDMtMS4xOTg2LTUuNjc3OS00LjA1NTQtNi42NjkyLTMuNDAxNS0xLjE4MDMtMTEuMTI5LTIuNTY3LTExLjg4NS02LjU1Ni0yLjE3MDYtMTEuNDUzLTMuMzAxNC0yMS4zOTEtNi45OTU5LTMxLjQ4OS0yLjgyOS03LjczMjItNy42NjQtMTQuMjQ1LTExLjQ2OS0yMS44NzYtMy4yNjgyLTYuNTU0NC00LjgxNzUtMTQuMjQ1LTIuOTQyMy0yNS40NiAwLjQ3NDU0LTIuODM3OSAxLjc5NTgtNi44NDU4IDUuNjE4My02LjU1MzIgMy43MjYzIDAuMjg1MjUgMTEuODgyIDYuNTI4NSAxNi41NzIgOS42Nzc3IDguNzM0MiA1Ljg2NDUgMTMuNzc1IDEwLjAxMSAxMy43NzUgMTAuMDExczUuMzU3IDIuMDkxOCA3LjEwMzUgMC40ODQ3YzEuMzM1Ni0xLjIyOSAyLjI0ODQtMi44MTk4IDAuMDgxMi01LjQ0NDQtMy44NDg2LTQuNjYwOC0xNy43NTQtMTIuNjYtMjMuMzk4LTE2LjMzMi0yLjgyNTgtMS44Mzc4LTQuNDY4OS0yLjEwNTUtNC42NzE5LTUuNjIyMi0wLjI1NDE1LTQuNDAzMyAwLTExLjIzMSAwLTE1Ljk5OHYtMjEuNTEyeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PHBhdGggZD0ibTEzOS45NyAxNDQuNjRzLTM0Ljk4NCA1Ni4wODgtNDkuMTExIDc5Ljc4M2MtMC44NjgzNyAxLjQ1NjUtMC4wNDEzOSA0LjExODEgMS40Nzk5IDQuODY3MSAxLjU3OCAwLjc3Njk1IDIuODgzMyAwLjQwNzM4IDQuOTM3NC0xLjg2MTggMi44ODkxLTMuMTkxNiA0OC41My03OC4xOTQgNDguNTMtNzguMTk0eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.10936" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS41OW1tIiBoZWlnaHQ9IjE2MS41OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuNTkgMTYxLjU5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xOS4xNTkgLTYxLjY3NSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC4wOTU0NTIgLS4wODA3MTEpIj48cmVjdCB4PSI2Mi4zNjEiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSIxMTguODQiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSI3NC43NjIiIHk9IjEzNS4wMSIgd2lkdGg9IjUzLjQ0OSIgaGVpZ2h0PSIxNS4wODEiLz48L2c+PGNpcmNsZSBjeD0iOTkuOTU2IiBjeT0iMTQyLjQ3IiByPSI3My4yMDIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMTUuMTkiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3MC40NW1tIiBoZWlnaHQ9IjE3My43OG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzAuNDUgMTczLjc4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMS4zNTUgLTUxLjYxNykiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyOC41IC44OTA1NCkiPjxnIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0ibS0yNzAuOTIgMTExLjYxIDEyLjc1MiAyLjU5NzFjMi4wNDc5IDAuNDE3MDkgMy4zNjA4IDIuNDAxNSAyLjk0MzcgNC40NDk0bC04LjcyMjMgNDIuODI3Yy0wLjQxNzA4IDIuMDQ3OS0yLjM3NjEgMi42ODA3LTQuNDQ5NCAyLjk0MzdsLTEyLjgxMiAxLjYyNTZjLTAuOTk4NzQgMC4xMjY3MiAwLjI3ODA2LTMuMjc3NC0wLjU4NjY3LTUuMDc2LTAuOTMwMzctMS45MzUyLTEuMTIwOC01LjI4MjUtMC45MjU0Mi02LjM0NzlsNy4zNTA5LTQwLjA3NWMwLjM3NzA3LTIuMDU1NiAyLjQwMTUtMy4zNjA4IDQuNDQ5NC0yLjk0Mzd6IiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi42MjI2Ii8+PHBhdGggZD0ibS0yNTcuMjggMjE2LjQ2IDIuNzIwOC0zNS41NzYtMTguMTI0LTI1LjY0Mi03LjEyNzQgMzAuMTM0LTE5LjM3MSAzMS4zNTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMy40NSIvPjxwYXRoIGQ9Im0tMjM0LjkzIDEzOS45cy0xMS4wNCAwLjU0NDU3LTE0Ljg5NC0yLjcxMzJjLTQuNjI1MS0zLjkwOTUtMy44MzItMTUuMjAyLTYuMTg2OS0xNy4wODItNC4wNzI4LTMuMjUyMi0xNS4xMzgtNC41ODcyLTE1LjEzOC00LjU4NzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI4LjY1Ii8+PC9nPjxjaXJjbGUgY3g9Ii0yNTYuODQiIGN5PSI5Ni4yMzQiIHI9IjE0LjEzIi8+PHBhdGggZD0ibS0yMzYuNjUgMTIzLjEzLTMuNzQxNCA5OC41MzkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQuNzUiLz48cGF0aCBkPSJtLTI4My40OCAxMDkuNDUgMy4xNDQ0IDAuNzY4NDNjMy41MDA4IDAuODU1NTMgMy4xOTk1IDIuNzY2IDIuNDMxOCA2LjgxNTZsLTUuODcwNyAzMC45NjljLTAuNzY3NjggNC4wNDk3LTQuMjA0MSA2LjYyMTItNy43MDQ5IDUuNzY1NmwtMTAuMTctMi40ODUzYy0zLjUwMDgtMC44NTU1NC02Ljg1NTgtNS4zNDQtNC45MzM1LTguODU0MmwxNS45NzUtMjkuMTcxYzEuOTIyMy0zLjUxMDMgMy42MjcxLTQuNjY0MyA3LjEyNzktMy44MDg3eiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMy4wMjY1Ii8+PHBhdGggZD0ibS0yNTYuMTIgMTE1LjAycy0yLjU0NzMtMS4wNjcxLTIuOTc5LTIuNTY4M2MtMC40OTM5MS0xLjcxNzgtMC4yMDMyOS00LjUzNzYtMC4yMDMyOS00LjUzNzZsLTUuMTE1NC02LjI1MDNzLTAuNDUyMzYgNC43MDY5LTEuNzA4OCA2LjYwMDljLTEuMjIyNiAxLjg0My02LjE4IDMuMDgwOC02LjE4IDMuMDgwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Im0xNDIuNDUgODcuNzQ3IDE1LjYxMiAzLjE3OTZjMi41MDcyIDAuNTEwNjQgNC4xMTQ2IDIuOTQwMiAzLjYwNCA1LjQ0NzRsLTEwLjY3OSA1Mi40MzJjLTAuNTEwNjMgMi41MDcyLTIuOTA5MSAzLjI4MTktNS40NDc0IDMuNjA0bC0xNS42ODYgMS45OTAxYy0xLjIyMjggMC4xNTUxNCAwLjM0MDQzLTQuMDEyNS0wLjcxODI1LTYuMjE0NS0xLjEzOS0yLjM2OTItMS4zNzIyLTYuNDY3My0xLjEzMy03Ljc3MTdsOC45OTk2LTQ5LjA2M2MwLjQ2MTY1LTIuNTE2NyAyLjk0MDItNC4xMTQ2IDUuNDQ3NC0zLjYwNHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjIxMDkiLz48cGF0aCBkPSJtMTU5LjE1IDIxNi4xIDMuMzMxMS00My41NTUtMjIuMTg5LTMxLjM5NC04LjcyNiAzNi44OTItMjMuNzE2IDM4LjM4OSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjE2LjQ2NyIvPjxwYXRoIGQ9Im0xODYuNTEgMTIyLjM4cy0xMy41MTcgMC42NjY3MS0xOC4yMzUtMy4zMjE4Yy01LjY2MjQtNC43ODYzLTQuNjkxNC0xOC42MTEtNy41NzQ2LTIwLjkxMy00Ljk4NjMtMy45ODE2LTE4LjUzMy01LjYxNi0xOC41MzMtNS42MTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMC41OSIvPjwvZz48Y2lyY2xlIGN4PSIxNTkuNjkiIGN5PSI2OC45MTYiIHI9IjE3LjMiLz48cGF0aCBkPSJtMTgzLjEgMTA2Ljc5LTQuMDExOCAxMDUuNjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUuMDkzNCIvPjxwYXRoIGQ9Im0xMjcuMDggODUuMDk1IDMuODQ5NiAwLjk0MDc4YzQuMjg2IDEuMDQ3NCAzLjkxNzEgMy4zODYzIDIuOTc3MiA4LjM0NDNsLTcuMTg3NCAzNy45MTVjLTAuOTM5ODcgNC45NTgtNS4xNDcgOC4xMDYyLTkuNDMzIDcuMDU4OGwtMTIuNDUxLTMuMDQyN2MtNC4yODYtMS4wNDc0LTguMzkzNS02LjU0MjUtNi4wNC0xMC44NGwxOS41NTgtMzUuNzEzYzIuMzUzNC00LjI5NzYgNC40NDA2LTUuNzEwNCA4LjcyNjYtNC42NjN6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjcwNTMiLz48cGF0aCBkPSJtMTYwLjU4IDkxLjkxOHMtMy4xMTg2LTEuMzA2NS0zLjY0NzEtMy4xNDQzYy0wLjYwNDY5LTIuMTAzLTAuMjQ4ODktNS41NTUzLTAuMjQ4ODktNS41NTUzbC02LjI2MjgtNy42NTIxcy0wLjU1MzgyIDUuNzYyNy0yLjA5MjEgOC4wODE0Yy0xLjQ5NjggMi4yNTYzLTcuNTY2MSAzLjc3MTctNy41NjYxIDMuNzcxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="229,182,54,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,255,255,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNy45Nm1tIiBoZWlnaHQ9IjE0Ny4xOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTcuOTYgMTQ3LjE5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40OTIgLTczLjA0NikiPjxyZWN0IHg9IjQ1LjQ5MiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjEzNC4zMiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjY0Ljk5NiIgeT0iMTM0Ljc4IiB3aWR0aD0iODQuMDY2IiBoZWlnaHQ9IjIzLjcyMSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.00707" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS41OW1tIiBoZWlnaHQ9IjE2MS41OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuNTkgMTYxLjU5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xOS4xNTkgLTYxLjY3NSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC4wOTU0NTIgLS4wODA3MTEpIj48cmVjdCB4PSI2Mi4zNjEiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSIxMTguODQiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSI3NC43NjIiIHk9IjEzNS4wMSIgd2lkdGg9IjUzLjQ0OSIgaGVpZ2h0PSIxNS4wODEiLz48L2c+PGNpcmNsZSBjeD0iOTkuOTU2IiBjeT0iMTQyLjQ3IiByPSI3My4yMDIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMTUuMTkiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNS4xN21tIiBoZWlnaHQ9IjE1Ni42Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjUuMTcgMTU2LjY2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MC42MzcgLTc2LjA2OCkiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY0NThweCI+PHBhdGggZD0ibTEwNC4zNSA3Ni4xNjNzNS41MzM0IDkuNTA5OSA1LjU4NjcgMTQuNDg1YzAuMDUxMyA0Ljc4MzgtNC40MTYyIDguMjU5MS03LjkwMTYgMTEuMjIzLTEwLjMyNyA4Ljc4MTktMTkuNDY4IDE4LjQzNC0yMi4wMTkgMzAuNzkxLTEuOTI0OCA5LjMyNTYgMS42Mjk2IDE5LjQ4NyA2LjA1ODEgMjcuOTE3IDMuMzc0OSA2LjQyNCAxNC44OTkgMTUuODczIDE0Ljg5OSAxNS44NzNzMTIuNzQ2LTkuODI3OCAxNy4xMjgtMTYuNDFjNS4xNjkzLTcuNzY1MyA5LjI3MjUtMTYuODE5IDEwLjA2NC0yNi4xMTQgMS4xMzQ5LTEzLjMzLTEuMTM2Ni0yNy44MDUtNy44OTQyLTM5LjM1MS00LjEwNzctNy4wMTg1LTE1LjkyMS0xOC40MTUtMTUuOTIxLTE4LjQxNXoiLz48cGF0aCBkPSJtMTMzLjYgMTE1Ljg3czEuNzk5NSAyMS4wNzYtMS4yNzk4IDMwLjkyMmMtMy42MjkgMTEuNjAzLTE5LjUyNCAzMC44MDctMTkuNTI0IDMwLjgwN3MyNC40NDgtMi41ODI3IDMyLjIwNy0xMC44MzVjNi42MTczLTcuMDM4MiA5LjU4MjQtMTguNTQ1IDcuNTMxNi0yNy45ODYtMi4xMDMtOS42ODExLTE4LjkzNS0yMi45MDgtMTguOTM1LTIyLjkwOHoiLz48cGF0aCBkPSJtNzMuNzg4IDEyMS43cy0wLjg4MjU5IDguNzAyNi0zLjY1MDQgMTEuNzE0Yy02LjI2MjIgNi44MTIyLTExLjQ2NiAxNC45MzEtMTAuOTY5IDIzLjU4OSAwLjM3ODMyIDYuNTk2NCA0Ljg3MjYgMTMuMjE3IDEwLjM1OCAxNi45IDQuMTMzNCAyLjc3NTIgOS43NzI0IDIuNzE0OSAxNC43NDEgMi40MDMyIDQuMTEyLTAuMjU3ODggOC40NTAyIDEuMDkyNiA4LjQ1MDIgMS4wOTI2cy0xNC4wMS0xMC45MzUtMTcuMjg4LTE4Ljc4OWMtMy40OC04LjMzNjItMy4xNTg2LTE3LjQwNC0xLjI3NjMtMjcuMDcgMC42MjczLTMuMjIxNC0wLjM2NTM5LTkuODM4OC0wLjM2NTM5LTkuODM4OHoiLz48cGF0aCBkPSJtNDAuODIzIDIxOS42NiAxMDkuNTItNDIuMjE1IDUuNjkwOCA5LjE5MDEtMTA4LjUgNDUuOTJ6Ii8+PHBhdGggZD0ibTE2NS42MiAyMTkuMzgtMTA5LjUyLTQyLjIxNS01LjY5MDggOS4xOTAxIDEwOC41IDQ1LjkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.15476" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMC4wOW1tIiBoZWlnaHQ9IjE1OS41M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjAuMDkgMTU5LjUzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC41MjUgLTY3LjA4NykiPjxyZWN0IHg9IjQ0LjUyNSIgeT0iMjE2LjAzIiB3aWR0aD0iMTIwLjA5IiBoZWlnaHQ9IjEwLjU4Ii8+PHJlY3QgeD0iNzAuMTM3IiB5PSIxNjcuMjIiIHdpZHRoPSI2OC44NjciIGhlaWdodD0iNTAuMjY4Ii8+PHBhdGggdHJhbnNmb3JtPSJtYXRyaXgoLjk0NDMgMCAwIC42MzM2NSAxMC45NTUgNzcuMDM5KSIgZD0ibTE1Mi44MiAxNDcuMDdoLTEwNy4zN2w1My42ODUtOTIuOTg1eiIvPjxwYXRoIGQ9Im0xMDAuNjIgMTE4LjQ4di01MS4xODJsMzUuNjAzIDE2LjM3M3YyNS43NjhsLTI3LjA0My0xNS4xNHYyNy41NzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.76387" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk1Ljc3NG1tIiBoZWlnaHQ9IjE2Ni4zM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5NS43NzQgMTY2LjMzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi42NjQgLTY2LjAwNSkiPjxyZWN0IHRyYW5zZm9ybT0ibWF0cml4KC41MjM1NCAtLjg1MiAuODg1NDggLjQ2NDY4IDAgMCkiIHg9Ii04Ny40ODciIHk9IjEyMi40MyIgd2lkdGg9IjU3Ljk0MiIgaGVpZ2h0PSIxMC4xNCIvPjxjaXJjbGUgY3g9IjExOC45NCIgY3k9IjgwLjQ2IiByPSIxNC40NTUiLz48cGF0aCBkPSJtMTEwLjI4IDg0LjcwNXMtMjQuMjg1IDI5LjM5Mi0zMC45MTcgNDYuOTA1Yy0yLjgxMDMgNy40MjA5LTEuMzUxMyAxNS44ODktMy4zNTEyIDIzLjU2OC0yLjY2MDYgMTAuMjE2LTkuOTQwNiAyNi42NzUtMTQuMTg2IDM1LjE0Ni00LjY5MTkgOS4zNjItNS41NDAyIDEzLjc1MS04LjYyMjkgMjMuOTU1LTAuOTkxNTggMy4yODIyLTAuMjEyNCA4Ljg5NCAzLjA5MTUgOS44MTA2IDguMTAzNiAyLjI0OCAxNy41MTggMy40NTExIDE5LjY4OCAyLjMzODUgMS44MjM4LTAuOTM0ODQgMS43MTk5LTQuMjU2IDAuMjgyNzYtNS43Njg4LTEuNzIyMi0xLjgxMjctNi4wNDYxLTAuNzM3NjEtNy4wMjA4LTMuMTAzNC0xLjYwMjQtMy44ODk1LTAuNTg4Mi03LjUxOTIgMC40OTQ1NC0xMS40NCAyLjE3NDUtNy44NzUyIDcuODQ4OS0xMi4yMDQgMTIuMjM4LTIxLjU3MSAzLjc2ODQtOC4wNDIzIDcuNjA0OC0xNS4yNDQgMTAuNTUtMTUuMjQ0IDIuNDQ5OSAwIDYuODk3NyA4LjI1MjIgOS41OTA2IDEzLjA3MSAzLjY3ODMgNi41ODI3IDcuNzcgMTUuNTExIDguOTEzNyAyMy43ODIgMS40MzU5IDEwLjM4NSAxLjEwNDIgMTcuNzcgNi4wOTkzIDIzLjQxMSAyLjEwOTIgMi4zODE2IDcuNTgzNyAyLjE0NjQgMTIuODkyIDIuMjk2NiA0LjkzMTYgMC4xMzk1NCA4LjU2MjUgMS4wNzE0IDExLjE4Ny0wLjkzMjgxIDIuMzMxMS0xLjc4MDMtMS4xOTg2LTUuNjc3OS00LjA1NTQtNi42NjkyLTMuNDAxNS0xLjE4MDMtMTEuMTI5LTIuNTY3LTExLjg4NS02LjU1Ni0yLjE3MDYtMTEuNDUzLTMuMzAxNC0yMS4zOTEtNi45OTU5LTMxLjQ4OS0yLjgyOS03LjczMjItNy42NjQtMTQuMjQ1LTExLjQ2OS0yMS44NzYtMy4yNjgyLTYuNTU0NC00LjgxNzUtMTQuMjQ1LTIuOTQyMy0yNS40NiAwLjQ3NDU0LTIuODM3OSAxLjc5NTgtNi44NDU4IDUuNjE4My02LjU1MzIgMy43MjYzIDAuMjg1MjUgMTEuODgyIDYuNTI4NSAxNi41NzIgOS42Nzc3IDguNzM0MiA1Ljg2NDUgMTMuNzc1IDEwLjAxMSAxMy43NzUgMTAuMDExczUuMzU3IDIuMDkxOCA3LjEwMzUgMC40ODQ3YzEuMzM1Ni0xLjIyOSAyLjI0ODQtMi44MTk4IDAuMDgxMi01LjQ0NDQtMy44NDg2LTQuNjYwOC0xNy43NTQtMTIuNjYtMjMuMzk4LTE2LjMzMi0yLjgyNTgtMS44Mzc4LTQuNDY4OS0yLjEwNTUtNC42NzE5LTUuNjIyMi0wLjI1NDE1LTQuNDAzMyAwLTExLjIzMSAwLTE1Ljk5OHYtMjEuNTEyeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PHBhdGggZD0ibTEzOS45NyAxNDQuNjRzLTM0Ljk4NCA1Ni4wODgtNDkuMTExIDc5Ljc4M2MtMC44NjgzNyAxLjQ1NjUtMC4wNDEzOSA0LjExODEgMS40Nzk5IDQuODY3MSAxLjU3OCAwLjc3Njk1IDIuODgzMyAwLjQwNzM4IDQuOTM3NC0xLjg2MTggMi44ODkxLTMuMTkxNiA0OC41My03OC4xOTQgNDguNTMtNzguMTk0eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.10936" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3MC40NW1tIiBoZWlnaHQ9IjE3My43OG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzAuNDUgMTczLjc4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMS4zNTUgLTUxLjYxNykiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyOC41IC44OTA1NCkiPjxnIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0ibS0yNzAuOTIgMTExLjYxIDEyLjc1MiAyLjU5NzFjMi4wNDc5IDAuNDE3MDkgMy4zNjA4IDIuNDAxNSAyLjk0MzcgNC40NDk0bC04LjcyMjMgNDIuODI3Yy0wLjQxNzA4IDIuMDQ3OS0yLjM3NjEgMi42ODA3LTQuNDQ5NCAyLjk0MzdsLTEyLjgxMiAxLjYyNTZjLTAuOTk4NzQgMC4xMjY3MiAwLjI3ODA2LTMuMjc3NC0wLjU4NjY3LTUuMDc2LTAuOTMwMzctMS45MzUyLTEuMTIwOC01LjI4MjUtMC45MjU0Mi02LjM0NzlsNy4zNTA5LTQwLjA3NWMwLjM3NzA3LTIuMDU1NiAyLjQwMTUtMy4zNjA4IDQuNDQ5NC0yLjk0Mzd6IiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi42MjI2Ii8+PHBhdGggZD0ibS0yNTcuMjggMjE2LjQ2IDIuNzIwOC0zNS41NzYtMTguMTI0LTI1LjY0Mi03LjEyNzQgMzAuMTM0LTE5LjM3MSAzMS4zNTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMy40NSIvPjxwYXRoIGQ9Im0tMjM0LjkzIDEzOS45cy0xMS4wNCAwLjU0NDU3LTE0Ljg5NC0yLjcxMzJjLTQuNjI1MS0zLjkwOTUtMy44MzItMTUuMjAyLTYuMTg2OS0xNy4wODItNC4wNzI4LTMuMjUyMi0xNS4xMzgtNC41ODcyLTE1LjEzOC00LjU4NzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI4LjY1Ii8+PC9nPjxjaXJjbGUgY3g9Ii0yNTYuODQiIGN5PSI5Ni4yMzQiIHI9IjE0LjEzIi8+PHBhdGggZD0ibS0yMzYuNjUgMTIzLjEzLTMuNzQxNCA5OC41MzkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQuNzUiLz48cGF0aCBkPSJtLTI4My40OCAxMDkuNDUgMy4xNDQ0IDAuNzY4NDNjMy41MDA4IDAuODU1NTMgMy4xOTk1IDIuNzY2IDIuNDMxOCA2LjgxNTZsLTUuODcwNyAzMC45NjljLTAuNzY3NjggNC4wNDk3LTQuMjA0MSA2LjYyMTItNy43MDQ5IDUuNzY1NmwtMTAuMTctMi40ODUzYy0zLjUwMDgtMC44NTU1NC02Ljg1NTgtNS4zNDQtNC45MzM1LTguODU0MmwxNS45NzUtMjkuMTcxYzEuOTIyMy0zLjUxMDMgMy42MjcxLTQuNjY0MyA3LjEyNzktMy44MDg3eiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMy4wMjY1Ii8+PHBhdGggZD0ibS0yNTYuMTIgMTE1LjAycy0yLjU0NzMtMS4wNjcxLTIuOTc5LTIuNTY4M2MtMC40OTM5MS0xLjcxNzgtMC4yMDMyOS00LjUzNzYtMC4yMDMyOS00LjUzNzZsLTUuMTE1NC02LjI1MDNzLTAuNDUyMzYgNC43MDY5LTEuNzA4OCA2LjYwMDljLTEuMjIyNiAxLjg0My02LjE4IDMuMDgwOC02LjE4IDMuMDgwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Im0xNDIuNDUgODcuNzQ3IDE1LjYxMiAzLjE3OTZjMi41MDcyIDAuNTEwNjQgNC4xMTQ2IDIuOTQwMiAzLjYwNCA1LjQ0NzRsLTEwLjY3OSA1Mi40MzJjLTAuNTEwNjMgMi41MDcyLTIuOTA5MSAzLjI4MTktNS40NDc0IDMuNjA0bC0xNS42ODYgMS45OTAxYy0xLjIyMjggMC4xNTUxNCAwLjM0MDQzLTQuMDEyNS0wLjcxODI1LTYuMjE0NS0xLjEzOS0yLjM2OTItMS4zNzIyLTYuNDY3My0xLjEzMy03Ljc3MTdsOC45OTk2LTQ5LjA2M2MwLjQ2MTY1LTIuNTE2NyAyLjk0MDItNC4xMTQ2IDUuNDQ3NC0zLjYwNHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjIxMDkiLz48cGF0aCBkPSJtMTU5LjE1IDIxNi4xIDMuMzMxMS00My41NTUtMjIuMTg5LTMxLjM5NC04LjcyNiAzNi44OTItMjMuNzE2IDM4LjM4OSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjE2LjQ2NyIvPjxwYXRoIGQ9Im0xODYuNTEgMTIyLjM4cy0xMy41MTcgMC42NjY3MS0xOC4yMzUtMy4zMjE4Yy01LjY2MjQtNC43ODYzLTQuNjkxNC0xOC42MTEtNy41NzQ2LTIwLjkxMy00Ljk4NjMtMy45ODE2LTE4LjUzMy01LjYxNi0xOC41MzMtNS42MTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMC41OSIvPjwvZz48Y2lyY2xlIGN4PSIxNTkuNjkiIGN5PSI2OC45MTYiIHI9IjE3LjMiLz48cGF0aCBkPSJtMTgzLjEgMTA2Ljc5LTQuMDExOCAxMDUuNjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUuMDkzNCIvPjxwYXRoIGQ9Im0xMjcuMDggODUuMDk1IDMuODQ5NiAwLjk0MDc4YzQuMjg2IDEuMDQ3NCAzLjkxNzEgMy4zODYzIDIuOTc3MiA4LjM0NDNsLTcuMTg3NCAzNy45MTVjLTAuOTM5ODcgNC45NTgtNS4xNDcgOC4xMDYyLTkuNDMzIDcuMDU4OGwtMTIuNDUxLTMuMDQyN2MtNC4yODYtMS4wNDc0LTguMzkzNS02LjU0MjUtNi4wNC0xMC44NGwxOS41NTgtMzUuNzEzYzIuMzUzNC00LjI5NzYgNC40NDA2LTUuNzEwNCA4LjcyNjYtNC42NjN6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjcwNTMiLz48cGF0aCBkPSJtMTYwLjU4IDkxLjkxOHMtMy4xMTg2LTEuMzA2NS0zLjY0NzEtMy4xNDQzYy0wLjYwNDY5LTIuMTAzLTAuMjQ4ODktNS41NTUzLTAuMjQ4ODktNS41NTUzbC02LjI2MjgtNy42NTIxcy0wLjU1MzgyIDUuNzYyNy0yLjA5MjEgOC4wODE0Yy0xLjQ5NjggMi4yNTYzLTcuNTY2MSAzLjc3MTctNy41NjYxIDMuNzcxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="152,125,183,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNy45Nm1tIiBoZWlnaHQ9IjE0Ny4xOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTcuOTYgMTQ3LjE5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40OTIgLTczLjA0NikiPjxyZWN0IHg9IjQ1LjQ5MiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjEzNC4zMiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjY0Ljk5NiIgeT0iMTM0Ljc4IiB3aWR0aD0iODQuMDY2IiBoZWlnaHQ9IjIzLjcyMSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.00707" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNS4xN21tIiBoZWlnaHQ9IjE1Ni42Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjUuMTcgMTU2LjY2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MC42MzcgLTc2LjA2OCkiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY0NThweCI+PHBhdGggZD0ibTEwNC4zNSA3Ni4xNjNzNS41MzM0IDkuNTA5OSA1LjU4NjcgMTQuNDg1YzAuMDUxMyA0Ljc4MzgtNC40MTYyIDguMjU5MS03LjkwMTYgMTEuMjIzLTEwLjMyNyA4Ljc4MTktMTkuNDY4IDE4LjQzNC0yMi4wMTkgMzAuNzkxLTEuOTI0OCA5LjMyNTYgMS42Mjk2IDE5LjQ4NyA2LjA1ODEgMjcuOTE3IDMuMzc0OSA2LjQyNCAxNC44OTkgMTUuODczIDE0Ljg5OSAxNS44NzNzMTIuNzQ2LTkuODI3OCAxNy4xMjgtMTYuNDFjNS4xNjkzLTcuNzY1MyA5LjI3MjUtMTYuODE5IDEwLjA2NC0yNi4xMTQgMS4xMzQ5LTEzLjMzLTEuMTM2Ni0yNy44MDUtNy44OTQyLTM5LjM1MS00LjEwNzctNy4wMTg1LTE1LjkyMS0xOC40MTUtMTUuOTIxLTE4LjQxNXoiLz48cGF0aCBkPSJtMTMzLjYgMTE1Ljg3czEuNzk5NSAyMS4wNzYtMS4yNzk4IDMwLjkyMmMtMy42MjkgMTEuNjAzLTE5LjUyNCAzMC44MDctMTkuNTI0IDMwLjgwN3MyNC40NDgtMi41ODI3IDMyLjIwNy0xMC44MzVjNi42MTczLTcuMDM4MiA5LjU4MjQtMTguNTQ1IDcuNTMxNi0yNy45ODYtMi4xMDMtOS42ODExLTE4LjkzNS0yMi45MDgtMTguOTM1LTIyLjkwOHoiLz48cGF0aCBkPSJtNzMuNzg4IDEyMS43cy0wLjg4MjU5IDguNzAyNi0zLjY1MDQgMTEuNzE0Yy02LjI2MjIgNi44MTIyLTExLjQ2NiAxNC45MzEtMTAuOTY5IDIzLjU4OSAwLjM3ODMyIDYuNTk2NCA0Ljg3MjYgMTMuMjE3IDEwLjM1OCAxNi45IDQuMTMzNCAyLjc3NTIgOS43NzI0IDIuNzE0OSAxNC43NDEgMi40MDMyIDQuMTEyLTAuMjU3ODggOC40NTAyIDEuMDkyNiA4LjQ1MDIgMS4wOTI2cy0xNC4wMS0xMC45MzUtMTcuMjg4LTE4Ljc4OWMtMy40OC04LjMzNjItMy4xNTg2LTE3LjQwNC0xLjI3NjMtMjcuMDcgMC42MjczLTMuMjIxNC0wLjM2NTM5LTkuODM4OC0wLjM2NTM5LTkuODM4OHoiLz48cGF0aCBkPSJtNDAuODIzIDIxOS42NiAxMDkuNTItNDIuMjE1IDUuNjkwOCA5LjE5MDEtMTA4LjUgNDUuOTJ6Ii8+PHBhdGggZD0ibTE2NS42MiAyMTkuMzgtMTA5LjUyLTQyLjIxNS01LjY5MDggOS4xOTAxIDEwOC41IDQ1LjkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.15476" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS41OW1tIiBoZWlnaHQ9IjE2MS41OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuNTkgMTYxLjU5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xOS4xNTkgLTYxLjY3NSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC4wOTU0NTIgLS4wODA3MTEpIj48cmVjdCB4PSI2Mi4zNjEiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSIxMTguODQiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSI3NC43NjIiIHk9IjEzNS4wMSIgd2lkdGg9IjUzLjQ0OSIgaGVpZ2h0PSIxNS4wODEiLz48L2c+PGNpcmNsZSBjeD0iOTkuOTU2IiBjeT0iMTQyLjQ3IiByPSI3My4yMDIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMTUuMTkiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNS4xN21tIiBoZWlnaHQ9IjE1Ni42Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjUuMTcgMTU2LjY2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MC42MzcgLTc2LjA2OCkiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY0NThweCI+PHBhdGggZD0ibTEwNC4zNSA3Ni4xNjNzNS41MzM0IDkuNTA5OSA1LjU4NjcgMTQuNDg1YzAuMDUxMyA0Ljc4MzgtNC40MTYyIDguMjU5MS03LjkwMTYgMTEuMjIzLTEwLjMyNyA4Ljc4MTktMTkuNDY4IDE4LjQzNC0yMi4wMTkgMzAuNzkxLTEuOTI0OCA5LjMyNTYgMS42Mjk2IDE5LjQ4NyA2LjA1ODEgMjcuOTE3IDMuMzc0OSA2LjQyNCAxNC44OTkgMTUuODczIDE0Ljg5OSAxNS44NzNzMTIuNzQ2LTkuODI3OCAxNy4xMjgtMTYuNDFjNS4xNjkzLTcuNzY1MyA5LjI3MjUtMTYuODE5IDEwLjA2NC0yNi4xMTQgMS4xMzQ5LTEzLjMzLTEuMTM2Ni0yNy44MDUtNy44OTQyLTM5LjM1MS00LjEwNzctNy4wMTg1LTE1LjkyMS0xOC40MTUtMTUuOTIxLTE4LjQxNXoiLz48cGF0aCBkPSJtMTMzLjYgMTE1Ljg3czEuNzk5NSAyMS4wNzYtMS4yNzk4IDMwLjkyMmMtMy42MjkgMTEuNjAzLTE5LjUyNCAzMC44MDctMTkuNTI0IDMwLjgwN3MyNC40NDgtMi41ODI3IDMyLjIwNy0xMC44MzVjNi42MTczLTcuMDM4MiA5LjU4MjQtMTguNTQ1IDcuNTMxNi0yNy45ODYtMi4xMDMtOS42ODExLTE4LjkzNS0yMi45MDgtMTguOTM1LTIyLjkwOHoiLz48cGF0aCBkPSJtNzMuNzg4IDEyMS43cy0wLjg4MjU5IDguNzAyNi0zLjY1MDQgMTEuNzE0Yy02LjI2MjIgNi44MTIyLTExLjQ2NiAxNC45MzEtMTAuOTY5IDIzLjU4OSAwLjM3ODMyIDYuNTk2NCA0Ljg3MjYgMTMuMjE3IDEwLjM1OCAxNi45IDQuMTMzNCAyLjc3NTIgOS43NzI0IDIuNzE0OSAxNC43NDEgMi40MDMyIDQuMTEyLTAuMjU3ODggOC40NTAyIDEuMDkyNiA4LjQ1MDIgMS4wOTI2cy0xNC4wMS0xMC45MzUtMTcuMjg4LTE4Ljc4OWMtMy40OC04LjMzNjItMy4xNTg2LTE3LjQwNC0xLjI3NjMtMjcuMDcgMC42MjczLTMuMjIxNC0wLjM2NTM5LTkuODM4OC0wLjM2NTM5LTkuODM4OHoiLz48cGF0aCBkPSJtNDAuODIzIDIxOS42NiAxMDkuNTItNDIuMjE1IDUuNjkwOCA5LjE5MDEtMTA4LjUgNDUuOTJ6Ii8+PHBhdGggZD0ibTE2NS42MiAyMTkuMzgtMTA5LjUyLTQyLjIxNS01LjY5MDggOS4xOTAxIDEwOC41IDQ1LjkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.15476" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMC4wOW1tIiBoZWlnaHQ9IjE1OS41M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjAuMDkgMTU5LjUzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC41MjUgLTY3LjA4NykiPjxyZWN0IHg9IjQ0LjUyNSIgeT0iMjE2LjAzIiB3aWR0aD0iMTIwLjA5IiBoZWlnaHQ9IjEwLjU4Ii8+PHJlY3QgeD0iNzAuMTM3IiB5PSIxNjcuMjIiIHdpZHRoPSI2OC44NjciIGhlaWdodD0iNTAuMjY4Ii8+PHBhdGggdHJhbnNmb3JtPSJtYXRyaXgoLjk0NDMgMCAwIC42MzM2NSAxMC45NTUgNzcuMDM5KSIgZD0ibTE1Mi44MiAxNDcuMDdoLTEwNy4zN2w1My42ODUtOTIuOTg1eiIvPjxwYXRoIGQ9Im0xMDAuNjIgMTE4LjQ4di01MS4xODJsMzUuNjAzIDE2LjM3M3YyNS43NjhsLTI3LjA0My0xNS4xNHYyNy41NzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.76387" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk1Ljc3NG1tIiBoZWlnaHQ9IjE2Ni4zM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5NS43NzQgMTY2LjMzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi42NjQgLTY2LjAwNSkiPjxyZWN0IHRyYW5zZm9ybT0ibWF0cml4KC41MjM1NCAtLjg1MiAuODg1NDggLjQ2NDY4IDAgMCkiIHg9Ii04Ny40ODciIHk9IjEyMi40MyIgd2lkdGg9IjU3Ljk0MiIgaGVpZ2h0PSIxMC4xNCIvPjxjaXJjbGUgY3g9IjExOC45NCIgY3k9IjgwLjQ2IiByPSIxNC40NTUiLz48cGF0aCBkPSJtMTEwLjI4IDg0LjcwNXMtMjQuMjg1IDI5LjM5Mi0zMC45MTcgNDYuOTA1Yy0yLjgxMDMgNy40MjA5LTEuMzUxMyAxNS44ODktMy4zNTEyIDIzLjU2OC0yLjY2MDYgMTAuMjE2LTkuOTQwNiAyNi42NzUtMTQuMTg2IDM1LjE0Ni00LjY5MTkgOS4zNjItNS41NDAyIDEzLjc1MS04LjYyMjkgMjMuOTU1LTAuOTkxNTggMy4yODIyLTAuMjEyNCA4Ljg5NCAzLjA5MTUgOS44MTA2IDguMTAzNiAyLjI0OCAxNy41MTggMy40NTExIDE5LjY4OCAyLjMzODUgMS44MjM4LTAuOTM0ODQgMS43MTk5LTQuMjU2IDAuMjgyNzYtNS43Njg4LTEuNzIyMi0xLjgxMjctNi4wNDYxLTAuNzM3NjEtNy4wMjA4LTMuMTAzNC0xLjYwMjQtMy44ODk1LTAuNTg4Mi03LjUxOTIgMC40OTQ1NC0xMS40NCAyLjE3NDUtNy44NzUyIDcuODQ4OS0xMi4yMDQgMTIuMjM4LTIxLjU3MSAzLjc2ODQtOC4wNDIzIDcuNjA0OC0xNS4yNDQgMTAuNTUtMTUuMjQ0IDIuNDQ5OSAwIDYuODk3NyA4LjI1MjIgOS41OTA2IDEzLjA3MSAzLjY3ODMgNi41ODI3IDcuNzcgMTUuNTExIDguOTEzNyAyMy43ODIgMS40MzU5IDEwLjM4NSAxLjEwNDIgMTcuNzcgNi4wOTkzIDIzLjQxMSAyLjEwOTIgMi4zODE2IDcuNTgzNyAyLjE0NjQgMTIuODkyIDIuMjk2NiA0LjkzMTYgMC4xMzk1NCA4LjU2MjUgMS4wNzE0IDExLjE4Ny0wLjkzMjgxIDIuMzMxMS0xLjc4MDMtMS4xOTg2LTUuNjc3OS00LjA1NTQtNi42NjkyLTMuNDAxNS0xLjE4MDMtMTEuMTI5LTIuNTY3LTExLjg4NS02LjU1Ni0yLjE3MDYtMTEuNDUzLTMuMzAxNC0yMS4zOTEtNi45OTU5LTMxLjQ4OS0yLjgyOS03LjczMjItNy42NjQtMTQuMjQ1LTExLjQ2OS0yMS44NzYtMy4yNjgyLTYuNTU0NC00LjgxNzUtMTQuMjQ1LTIuOTQyMy0yNS40NiAwLjQ3NDU0LTIuODM3OSAxLjc5NTgtNi44NDU4IDUuNjE4My02LjU1MzIgMy43MjYzIDAuMjg1MjUgMTEuODgyIDYuNTI4NSAxNi41NzIgOS42Nzc3IDguNzM0MiA1Ljg2NDUgMTMuNzc1IDEwLjAxMSAxMy43NzUgMTAuMDExczUuMzU3IDIuMDkxOCA3LjEwMzUgMC40ODQ3YzEuMzM1Ni0xLjIyOSAyLjI0ODQtMi44MTk4IDAuMDgxMi01LjQ0NDQtMy44NDg2LTQuNjYwOC0xNy43NTQtMTIuNjYtMjMuMzk4LTE2LjMzMi0yLjgyNTgtMS44Mzc4LTQuNDY4OS0yLjEwNTUtNC42NzE5LTUuNjIyMi0wLjI1NDE1LTQuNDAzMyAwLTExLjIzMSAwLTE1Ljk5OHYtMjEuNTEyeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PHBhdGggZD0ibTEzOS45NyAxNDQuNjRzLTM0Ljk4NCA1Ni4wODgtNDkuMTExIDc5Ljc4M2MtMC44NjgzNyAxLjQ1NjUtMC4wNDEzOSA0LjExODEgMS40Nzk5IDQuODY3MSAxLjU3OCAwLjc3Njk1IDIuODgzMyAwLjQwNzM4IDQuOTM3NC0xLjg2MTggMi44ODkxLTMuMTkxNiA0OC41My03OC4xOTQgNDguNTMtNzguMTk0eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.10936" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3MC40NW1tIiBoZWlnaHQ9IjE3My43OG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzAuNDUgMTczLjc4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMS4zNTUgLTUxLjYxNykiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyOC41IC44OTA1NCkiPjxnIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0ibS0yNzAuOTIgMTExLjYxIDEyLjc1MiAyLjU5NzFjMi4wNDc5IDAuNDE3MDkgMy4zNjA4IDIuNDAxNSAyLjk0MzcgNC40NDk0bC04LjcyMjMgNDIuODI3Yy0wLjQxNzA4IDIuMDQ3OS0yLjM3NjEgMi42ODA3LTQuNDQ5NCAyLjk0MzdsLTEyLjgxMiAxLjYyNTZjLTAuOTk4NzQgMC4xMjY3MiAwLjI3ODA2LTMuMjc3NC0wLjU4NjY3LTUuMDc2LTAuOTMwMzctMS45MzUyLTEuMTIwOC01LjI4MjUtMC45MjU0Mi02LjM0NzlsNy4zNTA5LTQwLjA3NWMwLjM3NzA3LTIuMDU1NiAyLjQwMTUtMy4zNjA4IDQuNDQ5NC0yLjk0Mzd6IiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi42MjI2Ii8+PHBhdGggZD0ibS0yNTcuMjggMjE2LjQ2IDIuNzIwOC0zNS41NzYtMTguMTI0LTI1LjY0Mi03LjEyNzQgMzAuMTM0LTE5LjM3MSAzMS4zNTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMy40NSIvPjxwYXRoIGQ9Im0tMjM0LjkzIDEzOS45cy0xMS4wNCAwLjU0NDU3LTE0Ljg5NC0yLjcxMzJjLTQuNjI1MS0zLjkwOTUtMy44MzItMTUuMjAyLTYuMTg2OS0xNy4wODItNC4wNzI4LTMuMjUyMi0xNS4xMzgtNC41ODcyLTE1LjEzOC00LjU4NzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI4LjY1Ii8+PC9nPjxjaXJjbGUgY3g9Ii0yNTYuODQiIGN5PSI5Ni4yMzQiIHI9IjE0LjEzIi8+PHBhdGggZD0ibS0yMzYuNjUgMTIzLjEzLTMuNzQxNCA5OC41MzkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQuNzUiLz48cGF0aCBkPSJtLTI4My40OCAxMDkuNDUgMy4xNDQ0IDAuNzY4NDNjMy41MDA4IDAuODU1NTMgMy4xOTk1IDIuNzY2IDIuNDMxOCA2LjgxNTZsLTUuODcwNyAzMC45NjljLTAuNzY3NjggNC4wNDk3LTQuMjA0MSA2LjYyMTItNy43MDQ5IDUuNzY1NmwtMTAuMTctMi40ODUzYy0zLjUwMDgtMC44NTU1NC02Ljg1NTgtNS4zNDQtNC45MzM1LTguODU0MmwxNS45NzUtMjkuMTcxYzEuOTIyMy0zLjUxMDMgMy42MjcxLTQuNjY0MyA3LjEyNzktMy44MDg3eiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMy4wMjY1Ii8+PHBhdGggZD0ibS0yNTYuMTIgMTE1LjAycy0yLjU0NzMtMS4wNjcxLTIuOTc5LTIuNTY4M2MtMC40OTM5MS0xLjcxNzgtMC4yMDMyOS00LjUzNzYtMC4yMDMyOS00LjUzNzZsLTUuMTE1NC02LjI1MDNzLTAuNDUyMzYgNC43MDY5LTEuNzA4OCA2LjYwMDljLTEuMjIyNiAxLjg0My02LjE4IDMuMDgwOC02LjE4IDMuMDgwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Im0xNDIuNDUgODcuNzQ3IDE1LjYxMiAzLjE3OTZjMi41MDcyIDAuNTEwNjQgNC4xMTQ2IDIuOTQwMiAzLjYwNCA1LjQ0NzRsLTEwLjY3OSA1Mi40MzJjLTAuNTEwNjMgMi41MDcyLTIuOTA5MSAzLjI4MTktNS40NDc0IDMuNjA0bC0xNS42ODYgMS45OTAxYy0xLjIyMjggMC4xNTUxNCAwLjM0MDQzLTQuMDEyNS0wLjcxODI1LTYuMjE0NS0xLjEzOS0yLjM2OTItMS4zNzIyLTYuNDY3My0xLjEzMy03Ljc3MTdsOC45OTk2LTQ5LjA2M2MwLjQ2MTY1LTIuNTE2NyAyLjk0MDItNC4xMTQ2IDUuNDQ3NC0zLjYwNHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjIxMDkiLz48cGF0aCBkPSJtMTU5LjE1IDIxNi4xIDMuMzMxMS00My41NTUtMjIuMTg5LTMxLjM5NC04LjcyNiAzNi44OTItMjMuNzE2IDM4LjM4OSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjE2LjQ2NyIvPjxwYXRoIGQ9Im0xODYuNTEgMTIyLjM4cy0xMy41MTcgMC42NjY3MS0xOC4yMzUtMy4zMjE4Yy01LjY2MjQtNC43ODYzLTQuNjkxNC0xOC42MTEtNy41NzQ2LTIwLjkxMy00Ljk4NjMtMy45ODE2LTE4LjUzMy01LjYxNi0xOC41MzMtNS42MTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMC41OSIvPjwvZz48Y2lyY2xlIGN4PSIxNTkuNjkiIGN5PSI2OC45MTYiIHI9IjE3LjMiLz48cGF0aCBkPSJtMTgzLjEgMTA2Ljc5LTQuMDExOCAxMDUuNjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUuMDkzNCIvPjxwYXRoIGQ9Im0xMjcuMDggODUuMDk1IDMuODQ5NiAwLjk0MDc4YzQuMjg2IDEuMDQ3NCAzLjkxNzEgMy4zODYzIDIuOTc3MiA4LjM0NDNsLTcuMTg3NCAzNy45MTVjLTAuOTM5ODcgNC45NTgtNS4xNDcgOC4xMDYyLTkuNDMzIDcuMDU4OGwtMTIuNDUxLTMuMDQyN2MtNC4yODYtMS4wNDc0LTguMzkzNS02LjU0MjUtNi4wNC0xMC44NGwxOS41NTgtMzUuNzEzYzIuMzUzNC00LjI5NzYgNC40NDA2LTUuNzEwNCA4LjcyNjYtNC42NjN6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjcwNTMiLz48cGF0aCBkPSJtMTYwLjU4IDkxLjkxOHMtMy4xMTg2LTEuMzA2NS0zLjY0NzEtMy4xNDQzYy0wLjYwNDY5LTIuMTAzLTAuMjQ4ODktNS41NTUzLTAuMjQ4ODktNS41NTUzbC02LjI2MjgtNy42NTIxcy0wLjU1MzgyIDUuNzYyNy0yLjA5MjEgOC4wODE0Yy0xLjQ5NjggMi4yNTYzLTcuNTY2MSAzLjc3MTctNy41NjYxIDMuNzcxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,207,80,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="36" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNy45Nm1tIiBoZWlnaHQ9IjE0Ny4xOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTcuOTYgMTQ3LjE5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40OTIgLTczLjA0NikiPjxyZWN0IHg9IjQ1LjQ5MiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjEzNC4zMiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjY0Ljk5NiIgeT0iMTM0Ljc4IiB3aWR0aD0iODQuMDY2IiBoZWlnaHQ9IjIzLjcyMSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.00707" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="37" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS41OW1tIiBoZWlnaHQ9IjE2MS41OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuNTkgMTYxLjU5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xOS4xNTkgLTYxLjY3NSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC4wOTU0NTIgLS4wODA3MTEpIj48cmVjdCB4PSI2Mi4zNjEiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSIxMTguODQiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSI3NC43NjIiIHk9IjEzNS4wMSIgd2lkdGg9IjUzLjQ0OSIgaGVpZ2h0PSIxNS4wODEiLz48L2c+PGNpcmNsZSBjeD0iOTkuOTU2IiBjeT0iMTQyLjQ3IiByPSI3My4yMDIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMTUuMTkiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="38" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNS4xN21tIiBoZWlnaHQ9IjE1Ni42Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjUuMTcgMTU2LjY2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MC42MzcgLTc2LjA2OCkiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY0NThweCI+PHBhdGggZD0ibTEwNC4zNSA3Ni4xNjNzNS41MzM0IDkuNTA5OSA1LjU4NjcgMTQuNDg1YzAuMDUxMyA0Ljc4MzgtNC40MTYyIDguMjU5MS03LjkwMTYgMTEuMjIzLTEwLjMyNyA4Ljc4MTktMTkuNDY4IDE4LjQzNC0yMi4wMTkgMzAuNzkxLTEuOTI0OCA5LjMyNTYgMS42Mjk2IDE5LjQ4NyA2LjA1ODEgMjcuOTE3IDMuMzc0OSA2LjQyNCAxNC44OTkgMTUuODczIDE0Ljg5OSAxNS44NzNzMTIuNzQ2LTkuODI3OCAxNy4xMjgtMTYuNDFjNS4xNjkzLTcuNzY1MyA5LjI3MjUtMTYuODE5IDEwLjA2NC0yNi4xMTQgMS4xMzQ5LTEzLjMzLTEuMTM2Ni0yNy44MDUtNy44OTQyLTM5LjM1MS00LjEwNzctNy4wMTg1LTE1LjkyMS0xOC40MTUtMTUuOTIxLTE4LjQxNXoiLz48cGF0aCBkPSJtMTMzLjYgMTE1Ljg3czEuNzk5NSAyMS4wNzYtMS4yNzk4IDMwLjkyMmMtMy42MjkgMTEuNjAzLTE5LjUyNCAzMC44MDctMTkuNTI0IDMwLjgwN3MyNC40NDgtMi41ODI3IDMyLjIwNy0xMC44MzVjNi42MTczLTcuMDM4MiA5LjU4MjQtMTguNTQ1IDcuNTMxNi0yNy45ODYtMi4xMDMtOS42ODExLTE4LjkzNS0yMi45MDgtMTguOTM1LTIyLjkwOHoiLz48cGF0aCBkPSJtNzMuNzg4IDEyMS43cy0wLjg4MjU5IDguNzAyNi0zLjY1MDQgMTEuNzE0Yy02LjI2MjIgNi44MTIyLTExLjQ2NiAxNC45MzEtMTAuOTY5IDIzLjU4OSAwLjM3ODMyIDYuNTk2NCA0Ljg3MjYgMTMuMjE3IDEwLjM1OCAxNi45IDQuMTMzNCAyLjc3NTIgOS43NzI0IDIuNzE0OSAxNC43NDEgMi40MDMyIDQuMTEyLTAuMjU3ODggOC40NTAyIDEuMDkyNiA4LjQ1MDIgMS4wOTI2cy0xNC4wMS0xMC45MzUtMTcuMjg4LTE4Ljc4OWMtMy40OC04LjMzNjItMy4xNTg2LTE3LjQwNC0xLjI3NjMtMjcuMDcgMC42MjczLTMuMjIxNC0wLjM2NTM5LTkuODM4OC0wLjM2NTM5LTkuODM4OHoiLz48cGF0aCBkPSJtNDAuODIzIDIxOS42NiAxMDkuNTItNDIuMjE1IDUuNjkwOCA5LjE5MDEtMTA4LjUgNDUuOTJ6Ii8+PHBhdGggZD0ibTE2NS42MiAyMTkuMzgtMTA5LjUyLTQyLjIxNS01LjY5MDggOS4xOTAxIDEwOC41IDQ1LjkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.15476" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="39" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMC4wOW1tIiBoZWlnaHQ9IjE1OS41M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjAuMDkgMTU5LjUzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC41MjUgLTY3LjA4NykiPjxyZWN0IHg9IjQ0LjUyNSIgeT0iMjE2LjAzIiB3aWR0aD0iMTIwLjA5IiBoZWlnaHQ9IjEwLjU4Ii8+PHJlY3QgeD0iNzAuMTM3IiB5PSIxNjcuMjIiIHdpZHRoPSI2OC44NjciIGhlaWdodD0iNTAuMjY4Ii8+PHBhdGggdHJhbnNmb3JtPSJtYXRyaXgoLjk0NDMgMCAwIC42MzM2NSAxMC45NTUgNzcuMDM5KSIgZD0ibTE1Mi44MiAxNDcuMDdoLTEwNy4zN2w1My42ODUtOTIuOTg1eiIvPjxwYXRoIGQ9Im0xMDAuNjIgMTE4LjQ4di01MS4xODJsMzUuNjAzIDE2LjM3M3YyNS43NjhsLTI3LjA0My0xNS4xNHYyNy41NzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.76387" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMC4wOW1tIiBoZWlnaHQ9IjE1OS41M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjAuMDkgMTU5LjUzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC41MjUgLTY3LjA4NykiPjxyZWN0IHg9IjQ0LjUyNSIgeT0iMjE2LjAzIiB3aWR0aD0iMTIwLjA5IiBoZWlnaHQ9IjEwLjU4Ii8+PHJlY3QgeD0iNzAuMTM3IiB5PSIxNjcuMjIiIHdpZHRoPSI2OC44NjciIGhlaWdodD0iNTAuMjY4Ii8+PHBhdGggdHJhbnNmb3JtPSJtYXRyaXgoLjk0NDMgMCAwIC42MzM2NSAxMC45NTUgNzcuMDM5KSIgZD0ibTE1Mi44MiAxNDcuMDdoLTEwNy4zN2w1My42ODUtOTIuOTg1eiIvPjxwYXRoIGQ9Im0xMDAuNjIgMTE4LjQ4di01MS4xODJsMzUuNjAzIDE2LjM3M3YyNS43NjhsLTI3LjA0My0xNS4xNHYyNy41NzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.76387" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="40" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk1Ljc3NG1tIiBoZWlnaHQ9IjE2Ni4zM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5NS43NzQgMTY2LjMzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi42NjQgLTY2LjAwNSkiPjxyZWN0IHRyYW5zZm9ybT0ibWF0cml4KC41MjM1NCAtLjg1MiAuODg1NDggLjQ2NDY4IDAgMCkiIHg9Ii04Ny40ODciIHk9IjEyMi40MyIgd2lkdGg9IjU3Ljk0MiIgaGVpZ2h0PSIxMC4xNCIvPjxjaXJjbGUgY3g9IjExOC45NCIgY3k9IjgwLjQ2IiByPSIxNC40NTUiLz48cGF0aCBkPSJtMTEwLjI4IDg0LjcwNXMtMjQuMjg1IDI5LjM5Mi0zMC45MTcgNDYuOTA1Yy0yLjgxMDMgNy40MjA5LTEuMzUxMyAxNS44ODktMy4zNTEyIDIzLjU2OC0yLjY2MDYgMTAuMjE2LTkuOTQwNiAyNi42NzUtMTQuMTg2IDM1LjE0Ni00LjY5MTkgOS4zNjItNS41NDAyIDEzLjc1MS04LjYyMjkgMjMuOTU1LTAuOTkxNTggMy4yODIyLTAuMjEyNCA4Ljg5NCAzLjA5MTUgOS44MTA2IDguMTAzNiAyLjI0OCAxNy41MTggMy40NTExIDE5LjY4OCAyLjMzODUgMS44MjM4LTAuOTM0ODQgMS43MTk5LTQuMjU2IDAuMjgyNzYtNS43Njg4LTEuNzIyMi0xLjgxMjctNi4wNDYxLTAuNzM3NjEtNy4wMjA4LTMuMTAzNC0xLjYwMjQtMy44ODk1LTAuNTg4Mi03LjUxOTIgMC40OTQ1NC0xMS40NCAyLjE3NDUtNy44NzUyIDcuODQ4OS0xMi4yMDQgMTIuMjM4LTIxLjU3MSAzLjc2ODQtOC4wNDIzIDcuNjA0OC0xNS4yNDQgMTAuNTUtMTUuMjQ0IDIuNDQ5OSAwIDYuODk3NyA4LjI1MjIgOS41OTA2IDEzLjA3MSAzLjY3ODMgNi41ODI3IDcuNzcgMTUuNTExIDguOTEzNyAyMy43ODIgMS40MzU5IDEwLjM4NSAxLjEwNDIgMTcuNzcgNi4wOTkzIDIzLjQxMSAyLjEwOTIgMi4zODE2IDcuNTgzNyAyLjE0NjQgMTIuODkyIDIuMjk2NiA0LjkzMTYgMC4xMzk1NCA4LjU2MjUgMS4wNzE0IDExLjE4Ny0wLjkzMjgxIDIuMzMxMS0xLjc4MDMtMS4xOTg2LTUuNjc3OS00LjA1NTQtNi42NjkyLTMuNDAxNS0xLjE4MDMtMTEuMTI5LTIuNTY3LTExLjg4NS02LjU1Ni0yLjE3MDYtMTEuNDUzLTMuMzAxNC0yMS4zOTEtNi45OTU5LTMxLjQ4OS0yLjgyOS03LjczMjItNy42NjQtMTQuMjQ1LTExLjQ2OS0yMS44NzYtMy4yNjgyLTYuNTU0NC00LjgxNzUtMTQuMjQ1LTIuOTQyMy0yNS40NiAwLjQ3NDU0LTIuODM3OSAxLjc5NTgtNi44NDU4IDUuNjE4My02LjU1MzIgMy43MjYzIDAuMjg1MjUgMTEuODgyIDYuNTI4NSAxNi41NzIgOS42Nzc3IDguNzM0MiA1Ljg2NDUgMTMuNzc1IDEwLjAxMSAxMy43NzUgMTAuMDExczUuMzU3IDIuMDkxOCA3LjEwMzUgMC40ODQ3YzEuMzM1Ni0xLjIyOSAyLjI0ODQtMi44MTk4IDAuMDgxMi01LjQ0NDQtMy44NDg2LTQuNjYwOC0xNy43NTQtMTIuNjYtMjMuMzk4LTE2LjMzMi0yLjgyNTgtMS44Mzc4LTQuNDY4OS0yLjEwNTUtNC42NzE5LTUuNjIyMi0wLjI1NDE1LTQuNDAzMyAwLTExLjIzMSAwLTE1Ljk5OHYtMjEuNTEyeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PHBhdGggZD0ibTEzOS45NyAxNDQuNjRzLTM0Ljk4NCA1Ni4wODgtNDkuMTExIDc5Ljc4M2MtMC44NjgzNyAxLjQ1NjUtMC4wNDEzOSA0LjExODEgMS40Nzk5IDQuODY3MSAxLjU3OCAwLjc3Njk1IDIuODgzMyAwLjQwNzM4IDQuOTM3NC0xLjg2MTggMi44ODkxLTMuMTkxNiA0OC41My03OC4xOTQgNDguNTMtNzguMTk0eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.10936" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="41" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3MC40NW1tIiBoZWlnaHQ9IjE3My43OG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzAuNDUgMTczLjc4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMS4zNTUgLTUxLjYxNykiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyOC41IC44OTA1NCkiPjxnIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0ibS0yNzAuOTIgMTExLjYxIDEyLjc1MiAyLjU5NzFjMi4wNDc5IDAuNDE3MDkgMy4zNjA4IDIuNDAxNSAyLjk0MzcgNC40NDk0bC04LjcyMjMgNDIuODI3Yy0wLjQxNzA4IDIuMDQ3OS0yLjM3NjEgMi42ODA3LTQuNDQ5NCAyLjk0MzdsLTEyLjgxMiAxLjYyNTZjLTAuOTk4NzQgMC4xMjY3MiAwLjI3ODA2LTMuMjc3NC0wLjU4NjY3LTUuMDc2LTAuOTMwMzctMS45MzUyLTEuMTIwOC01LjI4MjUtMC45MjU0Mi02LjM0NzlsNy4zNTA5LTQwLjA3NWMwLjM3NzA3LTIuMDU1NiAyLjQwMTUtMy4zNjA4IDQuNDQ5NC0yLjk0Mzd6IiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi42MjI2Ii8+PHBhdGggZD0ibS0yNTcuMjggMjE2LjQ2IDIuNzIwOC0zNS41NzYtMTguMTI0LTI1LjY0Mi03LjEyNzQgMzAuMTM0LTE5LjM3MSAzMS4zNTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMy40NSIvPjxwYXRoIGQ9Im0tMjM0LjkzIDEzOS45cy0xMS4wNCAwLjU0NDU3LTE0Ljg5NC0yLjcxMzJjLTQuNjI1MS0zLjkwOTUtMy44MzItMTUuMjAyLTYuMTg2OS0xNy4wODItNC4wNzI4LTMuMjUyMi0xNS4xMzgtNC41ODcyLTE1LjEzOC00LjU4NzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI4LjY1Ii8+PC9nPjxjaXJjbGUgY3g9Ii0yNTYuODQiIGN5PSI5Ni4yMzQiIHI9IjE0LjEzIi8+PHBhdGggZD0ibS0yMzYuNjUgMTIzLjEzLTMuNzQxNCA5OC41MzkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQuNzUiLz48cGF0aCBkPSJtLTI4My40OCAxMDkuNDUgMy4xNDQ0IDAuNzY4NDNjMy41MDA4IDAuODU1NTMgMy4xOTk1IDIuNzY2IDIuNDMxOCA2LjgxNTZsLTUuODcwNyAzMC45NjljLTAuNzY3NjggNC4wNDk3LTQuMjA0MSA2LjYyMTItNy43MDQ5IDUuNzY1NmwtMTAuMTctMi40ODUzYy0zLjUwMDgtMC44NTU1NC02Ljg1NTgtNS4zNDQtNC45MzM1LTguODU0MmwxNS45NzUtMjkuMTcxYzEuOTIyMy0zLjUxMDMgMy42MjcxLTQuNjY0MyA3LjEyNzktMy44MDg3eiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMy4wMjY1Ii8+PHBhdGggZD0ibS0yNTYuMTIgMTE1LjAycy0yLjU0NzMtMS4wNjcxLTIuOTc5LTIuNTY4M2MtMC40OTM5MS0xLjcxNzgtMC4yMDMyOS00LjUzNzYtMC4yMDMyOS00LjUzNzZsLTUuMTE1NC02LjI1MDNzLTAuNDUyMzYgNC43MDY5LTEuNzA4OCA2LjYwMDljLTEuMjIyNiAxLjg0My02LjE4IDMuMDgwOC02LjE4IDMuMDgwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Im0xNDIuNDUgODcuNzQ3IDE1LjYxMiAzLjE3OTZjMi41MDcyIDAuNTEwNjQgNC4xMTQ2IDIuOTQwMiAzLjYwNCA1LjQ0NzRsLTEwLjY3OSA1Mi40MzJjLTAuNTEwNjMgMi41MDcyLTIuOTA5MSAzLjI4MTktNS40NDc0IDMuNjA0bC0xNS42ODYgMS45OTAxYy0xLjIyMjggMC4xNTUxNCAwLjM0MDQzLTQuMDEyNS0wLjcxODI1LTYuMjE0NS0xLjEzOS0yLjM2OTItMS4zNzIyLTYuNDY3My0xLjEzMy03Ljc3MTdsOC45OTk2LTQ5LjA2M2MwLjQ2MTY1LTIuNTE2NyAyLjk0MDItNC4xMTQ2IDUuNDQ3NC0zLjYwNHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjIxMDkiLz48cGF0aCBkPSJtMTU5LjE1IDIxNi4xIDMuMzMxMS00My41NTUtMjIuMTg5LTMxLjM5NC04LjcyNiAzNi44OTItMjMuNzE2IDM4LjM4OSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjE2LjQ2NyIvPjxwYXRoIGQ9Im0xODYuNTEgMTIyLjM4cy0xMy41MTcgMC42NjY3MS0xOC4yMzUtMy4zMjE4Yy01LjY2MjQtNC43ODYzLTQuNjkxNC0xOC42MTEtNy41NzQ2LTIwLjkxMy00Ljk4NjMtMy45ODE2LTE4LjUzMy01LjYxNi0xOC41MzMtNS42MTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMC41OSIvPjwvZz48Y2lyY2xlIGN4PSIxNTkuNjkiIGN5PSI2OC45MTYiIHI9IjE3LjMiLz48cGF0aCBkPSJtMTgzLjEgMTA2Ljc5LTQuMDExOCAxMDUuNjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUuMDkzNCIvPjxwYXRoIGQ9Im0xMjcuMDggODUuMDk1IDMuODQ5NiAwLjk0MDc4YzQuMjg2IDEuMDQ3NCAzLjkxNzEgMy4zODYzIDIuOTc3MiA4LjM0NDNsLTcuMTg3NCAzNy45MTVjLTAuOTM5ODcgNC45NTgtNS4xNDcgOC4xMDYyLTkuNDMzIDcuMDU4OGwtMTIuNDUxLTMuMDQyN2MtNC4yODYtMS4wNDc0LTguMzkzNS02LjU0MjUtNi4wNC0xMC44NGwxOS41NTgtMzUuNzEzYzIuMzUzNC00LjI5NzYgNC40NDA2LTUuNzEwNCA4LjcyNjYtNC42NjN6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjcwNTMiLz48cGF0aCBkPSJtMTYwLjU4IDkxLjkxOHMtMy4xMTg2LTEuMzA2NS0zLjY0NzEtMy4xNDQzYy0wLjYwNDY5LTIuMTAzLTAuMjQ4ODktNS41NTUzLTAuMjQ4ODktNS41NTUzbC02LjI2MjgtNy42NTIxcy0wLjU1MzgyIDUuNzYyNy0yLjA5MjEgOC4wODE0Yy0xLjQ5NjggMi4yNTYzLTcuNTY2MSAzLjc3MTctNy41NjYxIDMuNzcxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="42" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="225,89,137,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="43" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNy45Nm1tIiBoZWlnaHQ9IjE0Ny4xOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTcuOTYgMTQ3LjE5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40OTIgLTczLjA0NikiPjxyZWN0IHg9IjQ1LjQ5MiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjEzNC4zMiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjY0Ljk5NiIgeT0iMTM0Ljc4IiB3aWR0aD0iODQuMDY2IiBoZWlnaHQ9IjIzLjcyMSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.00707" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="44" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS41OW1tIiBoZWlnaHQ9IjE2MS41OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuNTkgMTYxLjU5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xOS4xNTkgLTYxLjY3NSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC4wOTU0NTIgLS4wODA3MTEpIj48cmVjdCB4PSI2Mi4zNjEiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSIxMTguODQiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSI3NC43NjIiIHk9IjEzNS4wMSIgd2lkdGg9IjUzLjQ0OSIgaGVpZ2h0PSIxNS4wODEiLz48L2c+PGNpcmNsZSBjeD0iOTkuOTU2IiBjeT0iMTQyLjQ3IiByPSI3My4yMDIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMTUuMTkiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="45" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNS4xN21tIiBoZWlnaHQ9IjE1Ni42Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjUuMTcgMTU2LjY2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MC42MzcgLTc2LjA2OCkiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY0NThweCI+PHBhdGggZD0ibTEwNC4zNSA3Ni4xNjNzNS41MzM0IDkuNTA5OSA1LjU4NjcgMTQuNDg1YzAuMDUxMyA0Ljc4MzgtNC40MTYyIDguMjU5MS03LjkwMTYgMTEuMjIzLTEwLjMyNyA4Ljc4MTktMTkuNDY4IDE4LjQzNC0yMi4wMTkgMzAuNzkxLTEuOTI0OCA5LjMyNTYgMS42Mjk2IDE5LjQ4NyA2LjA1ODEgMjcuOTE3IDMuMzc0OSA2LjQyNCAxNC44OTkgMTUuODczIDE0Ljg5OSAxNS44NzNzMTIuNzQ2LTkuODI3OCAxNy4xMjgtMTYuNDFjNS4xNjkzLTcuNzY1MyA5LjI3MjUtMTYuODE5IDEwLjA2NC0yNi4xMTQgMS4xMzQ5LTEzLjMzLTEuMTM2Ni0yNy44MDUtNy44OTQyLTM5LjM1MS00LjEwNzctNy4wMTg1LTE1LjkyMS0xOC40MTUtMTUuOTIxLTE4LjQxNXoiLz48cGF0aCBkPSJtMTMzLjYgMTE1Ljg3czEuNzk5NSAyMS4wNzYtMS4yNzk4IDMwLjkyMmMtMy42MjkgMTEuNjAzLTE5LjUyNCAzMC44MDctMTkuNTI0IDMwLjgwN3MyNC40NDgtMi41ODI3IDMyLjIwNy0xMC44MzVjNi42MTczLTcuMDM4MiA5LjU4MjQtMTguNTQ1IDcuNTMxNi0yNy45ODYtMi4xMDMtOS42ODExLTE4LjkzNS0yMi45MDgtMTguOTM1LTIyLjkwOHoiLz48cGF0aCBkPSJtNzMuNzg4IDEyMS43cy0wLjg4MjU5IDguNzAyNi0zLjY1MDQgMTEuNzE0Yy02LjI2MjIgNi44MTIyLTExLjQ2NiAxNC45MzEtMTAuOTY5IDIzLjU4OSAwLjM3ODMyIDYuNTk2NCA0Ljg3MjYgMTMuMjE3IDEwLjM1OCAxNi45IDQuMTMzNCAyLjc3NTIgOS43NzI0IDIuNzE0OSAxNC43NDEgMi40MDMyIDQuMTEyLTAuMjU3ODggOC40NTAyIDEuMDkyNiA4LjQ1MDIgMS4wOTI2cy0xNC4wMS0xMC45MzUtMTcuMjg4LTE4Ljc4OWMtMy40OC04LjMzNjItMy4xNTg2LTE3LjQwNC0xLjI3NjMtMjcuMDcgMC42MjczLTMuMjIxNC0wLjM2NTM5LTkuODM4OC0wLjM2NTM5LTkuODM4OHoiLz48cGF0aCBkPSJtNDAuODIzIDIxOS42NiAxMDkuNTItNDIuMjE1IDUuNjkwOCA5LjE5MDEtMTA4LjUgNDUuOTJ6Ii8+PHBhdGggZD0ibTE2NS42MiAyMTkuMzgtMTA5LjUyLTQyLjIxNS01LjY5MDggOS4xOTAxIDEwOC41IDQ1LjkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.15476" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="46" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMC4wOW1tIiBoZWlnaHQ9IjE1OS41M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjAuMDkgMTU5LjUzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC41MjUgLTY3LjA4NykiPjxyZWN0IHg9IjQ0LjUyNSIgeT0iMjE2LjAzIiB3aWR0aD0iMTIwLjA5IiBoZWlnaHQ9IjEwLjU4Ii8+PHJlY3QgeD0iNzAuMTM3IiB5PSIxNjcuMjIiIHdpZHRoPSI2OC44NjciIGhlaWdodD0iNTAuMjY4Ii8+PHBhdGggdHJhbnNmb3JtPSJtYXRyaXgoLjk0NDMgMCAwIC42MzM2NSAxMC45NTUgNzcuMDM5KSIgZD0ibTE1Mi44MiAxNDcuMDdoLTEwNy4zN2w1My42ODUtOTIuOTg1eiIvPjxwYXRoIGQ9Im0xMDAuNjIgMTE4LjQ4di01MS4xODJsMzUuNjAzIDE2LjM3M3YyNS43NjhsLTI3LjA0My0xNS4xNHYyNy41NzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.76387" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="47" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk1Ljc3NG1tIiBoZWlnaHQ9IjE2Ni4zM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5NS43NzQgMTY2LjMzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi42NjQgLTY2LjAwNSkiPjxyZWN0IHRyYW5zZm9ybT0ibWF0cml4KC41MjM1NCAtLjg1MiAuODg1NDggLjQ2NDY4IDAgMCkiIHg9Ii04Ny40ODciIHk9IjEyMi40MyIgd2lkdGg9IjU3Ljk0MiIgaGVpZ2h0PSIxMC4xNCIvPjxjaXJjbGUgY3g9IjExOC45NCIgY3k9IjgwLjQ2IiByPSIxNC40NTUiLz48cGF0aCBkPSJtMTEwLjI4IDg0LjcwNXMtMjQuMjg1IDI5LjM5Mi0zMC45MTcgNDYuOTA1Yy0yLjgxMDMgNy40MjA5LTEuMzUxMyAxNS44ODktMy4zNTEyIDIzLjU2OC0yLjY2MDYgMTAuMjE2LTkuOTQwNiAyNi42NzUtMTQuMTg2IDM1LjE0Ni00LjY5MTkgOS4zNjItNS41NDAyIDEzLjc1MS04LjYyMjkgMjMuOTU1LTAuOTkxNTggMy4yODIyLTAuMjEyNCA4Ljg5NCAzLjA5MTUgOS44MTA2IDguMTAzNiAyLjI0OCAxNy41MTggMy40NTExIDE5LjY4OCAyLjMzODUgMS44MjM4LTAuOTM0ODQgMS43MTk5LTQuMjU2IDAuMjgyNzYtNS43Njg4LTEuNzIyMi0xLjgxMjctNi4wNDYxLTAuNzM3NjEtNy4wMjA4LTMuMTAzNC0xLjYwMjQtMy44ODk1LTAuNTg4Mi03LjUxOTIgMC40OTQ1NC0xMS40NCAyLjE3NDUtNy44NzUyIDcuODQ4OS0xMi4yMDQgMTIuMjM4LTIxLjU3MSAzLjc2ODQtOC4wNDIzIDcuNjA0OC0xNS4yNDQgMTAuNTUtMTUuMjQ0IDIuNDQ5OSAwIDYuODk3NyA4LjI1MjIgOS41OTA2IDEzLjA3MSAzLjY3ODMgNi41ODI3IDcuNzcgMTUuNTExIDguOTEzNyAyMy43ODIgMS40MzU5IDEwLjM4NSAxLjEwNDIgMTcuNzcgNi4wOTkzIDIzLjQxMSAyLjEwOTIgMi4zODE2IDcuNTgzNyAyLjE0NjQgMTIuODkyIDIuMjk2NiA0LjkzMTYgMC4xMzk1NCA4LjU2MjUgMS4wNzE0IDExLjE4Ny0wLjkzMjgxIDIuMzMxMS0xLjc4MDMtMS4xOTg2LTUuNjc3OS00LjA1NTQtNi42NjkyLTMuNDAxNS0xLjE4MDMtMTEuMTI5LTIuNTY3LTExLjg4NS02LjU1Ni0yLjE3MDYtMTEuNDUzLTMuMzAxNC0yMS4zOTEtNi45OTU5LTMxLjQ4OS0yLjgyOS03LjczMjItNy42NjQtMTQuMjQ1LTExLjQ2OS0yMS44NzYtMy4yNjgyLTYuNTU0NC00LjgxNzUtMTQuMjQ1LTIuOTQyMy0yNS40NiAwLjQ3NDU0LTIuODM3OSAxLjc5NTgtNi44NDU4IDUuNjE4My02LjU1MzIgMy43MjYzIDAuMjg1MjUgMTEuODgyIDYuNTI4NSAxNi41NzIgOS42Nzc3IDguNzM0MiA1Ljg2NDUgMTMuNzc1IDEwLjAxMSAxMy43NzUgMTAuMDExczUuMzU3IDIuMDkxOCA3LjEwMzUgMC40ODQ3YzEuMzM1Ni0xLjIyOSAyLjI0ODQtMi44MTk4IDAuMDgxMi01LjQ0NDQtMy44NDg2LTQuNjYwOC0xNy43NTQtMTIuNjYtMjMuMzk4LTE2LjMzMi0yLjgyNTgtMS44Mzc4LTQuNDY4OS0yLjEwNTUtNC42NzE5LTUuNjIyMi0wLjI1NDE1LTQuNDAzMyAwLTExLjIzMSAwLTE1Ljk5OHYtMjEuNTEyeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PHBhdGggZD0ibTEzOS45NyAxNDQuNjRzLTM0Ljk4NCA1Ni4wODgtNDkuMTExIDc5Ljc4M2MtMC44NjgzNyAxLjQ1NjUtMC4wNDEzOSA0LjExODEgMS40Nzk5IDQuODY3MSAxLjU3OCAwLjc3Njk1IDIuODgzMyAwLjQwNzM4IDQuOTM3NC0xLjg2MTggMi44ODkxLTMuMTkxNiA0OC41My03OC4xOTQgNDguNTMtNzguMTk0eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.10936" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="48" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3MC40NW1tIiBoZWlnaHQ9IjE3My43OG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzAuNDUgMTczLjc4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMS4zNTUgLTUxLjYxNykiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyOC41IC44OTA1NCkiPjxnIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0ibS0yNzAuOTIgMTExLjYxIDEyLjc1MiAyLjU5NzFjMi4wNDc5IDAuNDE3MDkgMy4zNjA4IDIuNDAxNSAyLjk0MzcgNC40NDk0bC04LjcyMjMgNDIuODI3Yy0wLjQxNzA4IDIuMDQ3OS0yLjM3NjEgMi42ODA3LTQuNDQ5NCAyLjk0MzdsLTEyLjgxMiAxLjYyNTZjLTAuOTk4NzQgMC4xMjY3MiAwLjI3ODA2LTMuMjc3NC0wLjU4NjY3LTUuMDc2LTAuOTMwMzctMS45MzUyLTEuMTIwOC01LjI4MjUtMC45MjU0Mi02LjM0NzlsNy4zNTA5LTQwLjA3NWMwLjM3NzA3LTIuMDU1NiAyLjQwMTUtMy4zNjA4IDQuNDQ5NC0yLjk0Mzd6IiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi42MjI2Ii8+PHBhdGggZD0ibS0yNTcuMjggMjE2LjQ2IDIuNzIwOC0zNS41NzYtMTguMTI0LTI1LjY0Mi03LjEyNzQgMzAuMTM0LTE5LjM3MSAzMS4zNTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMy40NSIvPjxwYXRoIGQ9Im0tMjM0LjkzIDEzOS45cy0xMS4wNCAwLjU0NDU3LTE0Ljg5NC0yLjcxMzJjLTQuNjI1MS0zLjkwOTUtMy44MzItMTUuMjAyLTYuMTg2OS0xNy4wODItNC4wNzI4LTMuMjUyMi0xNS4xMzgtNC41ODcyLTE1LjEzOC00LjU4NzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI4LjY1Ii8+PC9nPjxjaXJjbGUgY3g9Ii0yNTYuODQiIGN5PSI5Ni4yMzQiIHI9IjE0LjEzIi8+PHBhdGggZD0ibS0yMzYuNjUgMTIzLjEzLTMuNzQxNCA5OC41MzkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQuNzUiLz48cGF0aCBkPSJtLTI4My40OCAxMDkuNDUgMy4xNDQ0IDAuNzY4NDNjMy41MDA4IDAuODU1NTMgMy4xOTk1IDIuNzY2IDIuNDMxOCA2LjgxNTZsLTUuODcwNyAzMC45NjljLTAuNzY3NjggNC4wNDk3LTQuMjA0MSA2LjYyMTItNy43MDQ5IDUuNzY1NmwtMTAuMTctMi40ODUzYy0zLjUwMDgtMC44NTU1NC02Ljg1NTgtNS4zNDQtNC45MzM1LTguODU0MmwxNS45NzUtMjkuMTcxYzEuOTIyMy0zLjUxMDMgMy42MjcxLTQuNjY0MyA3LjEyNzktMy44MDg3eiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMy4wMjY1Ii8+PHBhdGggZD0ibS0yNTYuMTIgMTE1LjAycy0yLjU0NzMtMS4wNjcxLTIuOTc5LTIuNTY4M2MtMC40OTM5MS0xLjcxNzgtMC4yMDMyOS00LjUzNzYtMC4yMDMyOS00LjUzNzZsLTUuMTE1NC02LjI1MDNzLTAuNDUyMzYgNC43MDY5LTEuNzA4OCA2LjYwMDljLTEuMjIyNiAxLjg0My02LjE4IDMuMDgwOC02LjE4IDMuMDgwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Im0xNDIuNDUgODcuNzQ3IDE1LjYxMiAzLjE3OTZjMi41MDcyIDAuNTEwNjQgNC4xMTQ2IDIuOTQwMiAzLjYwNCA1LjQ0NzRsLTEwLjY3OSA1Mi40MzJjLTAuNTEwNjMgMi41MDcyLTIuOTA5MSAzLjI4MTktNS40NDc0IDMuNjA0bC0xNS42ODYgMS45OTAxYy0xLjIyMjggMC4xNTUxNCAwLjM0MDQzLTQuMDEyNS0wLjcxODI1LTYuMjE0NS0xLjEzOS0yLjM2OTItMS4zNzIyLTYuNDY3My0xLjEzMy03Ljc3MTdsOC45OTk2LTQ5LjA2M2MwLjQ2MTY1LTIuNTE2NyAyLjk0MDItNC4xMTQ2IDUuNDQ3NC0zLjYwNHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjIxMDkiLz48cGF0aCBkPSJtMTU5LjE1IDIxNi4xIDMuMzMxMS00My41NTUtMjIuMTg5LTMxLjM5NC04LjcyNiAzNi44OTItMjMuNzE2IDM4LjM4OSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjE2LjQ2NyIvPjxwYXRoIGQ9Im0xODYuNTEgMTIyLjM4cy0xMy41MTcgMC42NjY3MS0xOC4yMzUtMy4zMjE4Yy01LjY2MjQtNC43ODYzLTQuNjkxNC0xOC42MTEtNy41NzQ2LTIwLjkxMy00Ljk4NjMtMy45ODE2LTE4LjUzMy01LjYxNi0xOC41MzMtNS42MTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMC41OSIvPjwvZz48Y2lyY2xlIGN4PSIxNTkuNjkiIGN5PSI2OC45MTYiIHI9IjE3LjMiLz48cGF0aCBkPSJtMTgzLjEgMTA2Ljc5LTQuMDExOCAxMDUuNjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUuMDkzNCIvPjxwYXRoIGQ9Im0xMjcuMDggODUuMDk1IDMuODQ5NiAwLjk0MDc4YzQuMjg2IDEuMDQ3NCAzLjkxNzEgMy4zODYzIDIuOTc3MiA4LjM0NDNsLTcuMTg3NCAzNy45MTVjLTAuOTM5ODcgNC45NTgtNS4xNDcgOC4xMDYyLTkuNDMzIDcuMDU4OGwtMTIuNDUxLTMuMDQyN2MtNC4yODYtMS4wNDc0LTguMzkzNS02LjU0MjUtNi4wNC0xMC44NGwxOS41NTgtMzUuNzEzYzIuMzUzNC00LjI5NzYgNC40NDA2LTUuNzEwNCA4LjcyNjYtNC42NjN6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjcwNTMiLz48cGF0aCBkPSJtMTYwLjU4IDkxLjkxOHMtMy4xMTg2LTEuMzA2NS0zLjY0NzEtMy4xNDQzYy0wLjYwNDY5LTIuMTAzLTAuMjQ4ODktNS41NTUzLTAuMjQ4ODktNS41NTUzbC02LjI2MjgtNy42NTIxcy0wLjU1MzgyIDUuNzYyNy0yLjA5MjEgOC4wODE0Yy0xLjQ5NjggMi4yNTYzLTcuNTY2MSAzLjc3MTctNy41NjYxIDMuNzcxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="49" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="229,182,54,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk1Ljc3NG1tIiBoZWlnaHQ9IjE2Ni4zM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5NS43NzQgMTY2LjMzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi42NjQgLTY2LjAwNSkiPjxyZWN0IHRyYW5zZm9ybT0ibWF0cml4KC41MjM1NCAtLjg1MiAuODg1NDggLjQ2NDY4IDAgMCkiIHg9Ii04Ny40ODciIHk9IjEyMi40MyIgd2lkdGg9IjU3Ljk0MiIgaGVpZ2h0PSIxMC4xNCIvPjxjaXJjbGUgY3g9IjExOC45NCIgY3k9IjgwLjQ2IiByPSIxNC40NTUiLz48cGF0aCBkPSJtMTEwLjI4IDg0LjcwNXMtMjQuMjg1IDI5LjM5Mi0zMC45MTcgNDYuOTA1Yy0yLjgxMDMgNy40MjA5LTEuMzUxMyAxNS44ODktMy4zNTEyIDIzLjU2OC0yLjY2MDYgMTAuMjE2LTkuOTQwNiAyNi42NzUtMTQuMTg2IDM1LjE0Ni00LjY5MTkgOS4zNjItNS41NDAyIDEzLjc1MS04LjYyMjkgMjMuOTU1LTAuOTkxNTggMy4yODIyLTAuMjEyNCA4Ljg5NCAzLjA5MTUgOS44MTA2IDguMTAzNiAyLjI0OCAxNy41MTggMy40NTExIDE5LjY4OCAyLjMzODUgMS44MjM4LTAuOTM0ODQgMS43MTk5LTQuMjU2IDAuMjgyNzYtNS43Njg4LTEuNzIyMi0xLjgxMjctNi4wNDYxLTAuNzM3NjEtNy4wMjA4LTMuMTAzNC0xLjYwMjQtMy44ODk1LTAuNTg4Mi03LjUxOTIgMC40OTQ1NC0xMS40NCAyLjE3NDUtNy44NzUyIDcuODQ4OS0xMi4yMDQgMTIuMjM4LTIxLjU3MSAzLjc2ODQtOC4wNDIzIDcuNjA0OC0xNS4yNDQgMTAuNTUtMTUuMjQ0IDIuNDQ5OSAwIDYuODk3NyA4LjI1MjIgOS41OTA2IDEzLjA3MSAzLjY3ODMgNi41ODI3IDcuNzcgMTUuNTExIDguOTEzNyAyMy43ODIgMS40MzU5IDEwLjM4NSAxLjEwNDIgMTcuNzcgNi4wOTkzIDIzLjQxMSAyLjEwOTIgMi4zODE2IDcuNTgzNyAyLjE0NjQgMTIuODkyIDIuMjk2NiA0LjkzMTYgMC4xMzk1NCA4LjU2MjUgMS4wNzE0IDExLjE4Ny0wLjkzMjgxIDIuMzMxMS0xLjc4MDMtMS4xOTg2LTUuNjc3OS00LjA1NTQtNi42NjkyLTMuNDAxNS0xLjE4MDMtMTEuMTI5LTIuNTY3LTExLjg4NS02LjU1Ni0yLjE3MDYtMTEuNDUzLTMuMzAxNC0yMS4zOTEtNi45OTU5LTMxLjQ4OS0yLjgyOS03LjczMjItNy42NjQtMTQuMjQ1LTExLjQ2OS0yMS44NzYtMy4yNjgyLTYuNTU0NC00LjgxNzUtMTQuMjQ1LTIuOTQyMy0yNS40NiAwLjQ3NDU0LTIuODM3OSAxLjc5NTgtNi44NDU4IDUuNjE4My02LjU1MzIgMy43MjYzIDAuMjg1MjUgMTEuODgyIDYuNTI4NSAxNi41NzIgOS42Nzc3IDguNzM0MiA1Ljg2NDUgMTMuNzc1IDEwLjAxMSAxMy43NzUgMTAuMDExczUuMzU3IDIuMDkxOCA3LjEwMzUgMC40ODQ3YzEuMzM1Ni0xLjIyOSAyLjI0ODQtMi44MTk4IDAuMDgxMi01LjQ0NDQtMy44NDg2LTQuNjYwOC0xNy43NTQtMTIuNjYtMjMuMzk4LTE2LjMzMi0yLjgyNTgtMS44Mzc4LTQuNDY4OS0yLjEwNTUtNC42NzE5LTUuNjIyMi0wLjI1NDE1LTQuNDAzMyAwLTExLjIzMSAwLTE1Ljk5OHYtMjEuNTEyeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PHBhdGggZD0ibTEzOS45NyAxNDQuNjRzLTM0Ljk4NCA1Ni4wODgtNDkuMTExIDc5Ljc4M2MtMC44NjgzNyAxLjQ1NjUtMC4wNDEzOSA0LjExODEgMS40Nzk5IDQuODY3MSAxLjU3OCAwLjc3Njk1IDIuODgzMyAwLjQwNzM4IDQuOTM3NC0xLjg2MTggMi44ODkxLTMuMTkxNiA0OC41My03OC4xOTQgNDguNTMtNzguMTk0eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.10936" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="50" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,255,255,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNy45Nm1tIiBoZWlnaHQ9IjE0Ny4xOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTcuOTYgMTQ3LjE5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40OTIgLTczLjA0NikiPjxyZWN0IHg9IjQ1LjQ5MiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjEzNC4zMiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjY0Ljk5NiIgeT0iMTM0Ljc4IiB3aWR0aD0iODQuMDY2IiBoZWlnaHQ9IjIzLjcyMSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.00707" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="51" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS41OW1tIiBoZWlnaHQ9IjE2MS41OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuNTkgMTYxLjU5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xOS4xNTkgLTYxLjY3NSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC4wOTU0NTIgLS4wODA3MTEpIj48cmVjdCB4PSI2Mi4zNjEiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSIxMTguODQiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSI3NC43NjIiIHk9IjEzNS4wMSIgd2lkdGg9IjUzLjQ0OSIgaGVpZ2h0PSIxNS4wODEiLz48L2c+PGNpcmNsZSBjeD0iOTkuOTU2IiBjeT0iMTQyLjQ3IiByPSI3My4yMDIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMTUuMTkiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="52" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNS4xN21tIiBoZWlnaHQ9IjE1Ni42Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjUuMTcgMTU2LjY2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MC42MzcgLTc2LjA2OCkiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY0NThweCI+PHBhdGggZD0ibTEwNC4zNSA3Ni4xNjNzNS41MzM0IDkuNTA5OSA1LjU4NjcgMTQuNDg1YzAuMDUxMyA0Ljc4MzgtNC40MTYyIDguMjU5MS03LjkwMTYgMTEuMjIzLTEwLjMyNyA4Ljc4MTktMTkuNDY4IDE4LjQzNC0yMi4wMTkgMzAuNzkxLTEuOTI0OCA5LjMyNTYgMS42Mjk2IDE5LjQ4NyA2LjA1ODEgMjcuOTE3IDMuMzc0OSA2LjQyNCAxNC44OTkgMTUuODczIDE0Ljg5OSAxNS44NzNzMTIuNzQ2LTkuODI3OCAxNy4xMjgtMTYuNDFjNS4xNjkzLTcuNzY1MyA5LjI3MjUtMTYuODE5IDEwLjA2NC0yNi4xMTQgMS4xMzQ5LTEzLjMzLTEuMTM2Ni0yNy44MDUtNy44OTQyLTM5LjM1MS00LjEwNzctNy4wMTg1LTE1LjkyMS0xOC40MTUtMTUuOTIxLTE4LjQxNXoiLz48cGF0aCBkPSJtMTMzLjYgMTE1Ljg3czEuNzk5NSAyMS4wNzYtMS4yNzk4IDMwLjkyMmMtMy42MjkgMTEuNjAzLTE5LjUyNCAzMC44MDctMTkuNTI0IDMwLjgwN3MyNC40NDgtMi41ODI3IDMyLjIwNy0xMC44MzVjNi42MTczLTcuMDM4MiA5LjU4MjQtMTguNTQ1IDcuNTMxNi0yNy45ODYtMi4xMDMtOS42ODExLTE4LjkzNS0yMi45MDgtMTguOTM1LTIyLjkwOHoiLz48cGF0aCBkPSJtNzMuNzg4IDEyMS43cy0wLjg4MjU5IDguNzAyNi0zLjY1MDQgMTEuNzE0Yy02LjI2MjIgNi44MTIyLTExLjQ2NiAxNC45MzEtMTAuOTY5IDIzLjU4OSAwLjM3ODMyIDYuNTk2NCA0Ljg3MjYgMTMuMjE3IDEwLjM1OCAxNi45IDQuMTMzNCAyLjc3NTIgOS43NzI0IDIuNzE0OSAxNC43NDEgMi40MDMyIDQuMTEyLTAuMjU3ODggOC40NTAyIDEuMDkyNiA4LjQ1MDIgMS4wOTI2cy0xNC4wMS0xMC45MzUtMTcuMjg4LTE4Ljc4OWMtMy40OC04LjMzNjItMy4xNTg2LTE3LjQwNC0xLjI3NjMtMjcuMDcgMC42MjczLTMuMjIxNC0wLjM2NTM5LTkuODM4OC0wLjM2NTM5LTkuODM4OHoiLz48cGF0aCBkPSJtNDAuODIzIDIxOS42NiAxMDkuNTItNDIuMjE1IDUuNjkwOCA5LjE5MDEtMTA4LjUgNDUuOTJ6Ii8+PHBhdGggZD0ibTE2NS42MiAyMTkuMzgtMTA5LjUyLTQyLjIxNS01LjY5MDggOS4xOTAxIDEwOC41IDQ1LjkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.15476" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="53" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMC4wOW1tIiBoZWlnaHQ9IjE1OS41M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjAuMDkgMTU5LjUzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC41MjUgLTY3LjA4NykiPjxyZWN0IHg9IjQ0LjUyNSIgeT0iMjE2LjAzIiB3aWR0aD0iMTIwLjA5IiBoZWlnaHQ9IjEwLjU4Ii8+PHJlY3QgeD0iNzAuMTM3IiB5PSIxNjcuMjIiIHdpZHRoPSI2OC44NjciIGhlaWdodD0iNTAuMjY4Ii8+PHBhdGggdHJhbnNmb3JtPSJtYXRyaXgoLjk0NDMgMCAwIC42MzM2NSAxMC45NTUgNzcuMDM5KSIgZD0ibTE1Mi44MiAxNDcuMDdoLTEwNy4zN2w1My42ODUtOTIuOTg1eiIvPjxwYXRoIGQ9Im0xMDAuNjIgMTE4LjQ4di01MS4xODJsMzUuNjAzIDE2LjM3M3YyNS43NjhsLTI3LjA0My0xNS4xNHYyNy41NzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.76387" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="54" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk1Ljc3NG1tIiBoZWlnaHQ9IjE2Ni4zM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5NS43NzQgMTY2LjMzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi42NjQgLTY2LjAwNSkiPjxyZWN0IHRyYW5zZm9ybT0ibWF0cml4KC41MjM1NCAtLjg1MiAuODg1NDggLjQ2NDY4IDAgMCkiIHg9Ii04Ny40ODciIHk9IjEyMi40MyIgd2lkdGg9IjU3Ljk0MiIgaGVpZ2h0PSIxMC4xNCIvPjxjaXJjbGUgY3g9IjExOC45NCIgY3k9IjgwLjQ2IiByPSIxNC40NTUiLz48cGF0aCBkPSJtMTEwLjI4IDg0LjcwNXMtMjQuMjg1IDI5LjM5Mi0zMC45MTcgNDYuOTA1Yy0yLjgxMDMgNy40MjA5LTEuMzUxMyAxNS44ODktMy4zNTEyIDIzLjU2OC0yLjY2MDYgMTAuMjE2LTkuOTQwNiAyNi42NzUtMTQuMTg2IDM1LjE0Ni00LjY5MTkgOS4zNjItNS41NDAyIDEzLjc1MS04LjYyMjkgMjMuOTU1LTAuOTkxNTggMy4yODIyLTAuMjEyNCA4Ljg5NCAzLjA5MTUgOS44MTA2IDguMTAzNiAyLjI0OCAxNy41MTggMy40NTExIDE5LjY4OCAyLjMzODUgMS44MjM4LTAuOTM0ODQgMS43MTk5LTQuMjU2IDAuMjgyNzYtNS43Njg4LTEuNzIyMi0xLjgxMjctNi4wNDYxLTAuNzM3NjEtNy4wMjA4LTMuMTAzNC0xLjYwMjQtMy44ODk1LTAuNTg4Mi03LjUxOTIgMC40OTQ1NC0xMS40NCAyLjE3NDUtNy44NzUyIDcuODQ4OS0xMi4yMDQgMTIuMjM4LTIxLjU3MSAzLjc2ODQtOC4wNDIzIDcuNjA0OC0xNS4yNDQgMTAuNTUtMTUuMjQ0IDIuNDQ5OSAwIDYuODk3NyA4LjI1MjIgOS41OTA2IDEzLjA3MSAzLjY3ODMgNi41ODI3IDcuNzcgMTUuNTExIDguOTEzNyAyMy43ODIgMS40MzU5IDEwLjM4NSAxLjEwNDIgMTcuNzcgNi4wOTkzIDIzLjQxMSAyLjEwOTIgMi4zODE2IDcuNTgzNyAyLjE0NjQgMTIuODkyIDIuMjk2NiA0LjkzMTYgMC4xMzk1NCA4LjU2MjUgMS4wNzE0IDExLjE4Ny0wLjkzMjgxIDIuMzMxMS0xLjc4MDMtMS4xOTg2LTUuNjc3OS00LjA1NTQtNi42NjkyLTMuNDAxNS0xLjE4MDMtMTEuMTI5LTIuNTY3LTExLjg4NS02LjU1Ni0yLjE3MDYtMTEuNDUzLTMuMzAxNC0yMS4zOTEtNi45OTU5LTMxLjQ4OS0yLjgyOS03LjczMjItNy42NjQtMTQuMjQ1LTExLjQ2OS0yMS44NzYtMy4yNjgyLTYuNTU0NC00LjgxNzUtMTQuMjQ1LTIuOTQyMy0yNS40NiAwLjQ3NDU0LTIuODM3OSAxLjc5NTgtNi44NDU4IDUuNjE4My02LjU1MzIgMy43MjYzIDAuMjg1MjUgMTEuODgyIDYuNTI4NSAxNi41NzIgOS42Nzc3IDguNzM0MiA1Ljg2NDUgMTMuNzc1IDEwLjAxMSAxMy43NzUgMTAuMDExczUuMzU3IDIuMDkxOCA3LjEwMzUgMC40ODQ3YzEuMzM1Ni0xLjIyOSAyLjI0ODQtMi44MTk4IDAuMDgxMi01LjQ0NDQtMy44NDg2LTQuNjYwOC0xNy43NTQtMTIuNjYtMjMuMzk4LTE2LjMzMi0yLjgyNTgtMS44Mzc4LTQuNDY4OS0yLjEwNTUtNC42NzE5LTUuNjIyMi0wLjI1NDE1LTQuNDAzMyAwLTExLjIzMSAwLTE1Ljk5OHYtMjEuNTEyeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PHBhdGggZD0ibTEzOS45NyAxNDQuNjRzLTM0Ljk4NCA1Ni4wODgtNDkuMTExIDc5Ljc4M2MtMC44NjgzNyAxLjQ1NjUtMC4wNDEzOSA0LjExODEgMS40Nzk5IDQuODY3MSAxLjU3OCAwLjc3Njk1IDIuODgzMyAwLjQwNzM4IDQuOTM3NC0xLjg2MTggMi44ODkxLTMuMTkxNiA0OC41My03OC4xOTQgNDguNTMtNzguMTk0eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.10936" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="55" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3MC40NW1tIiBoZWlnaHQ9IjE3My43OG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzAuNDUgMTczLjc4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMS4zNTUgLTUxLjYxNykiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyOC41IC44OTA1NCkiPjxnIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0ibS0yNzAuOTIgMTExLjYxIDEyLjc1MiAyLjU5NzFjMi4wNDc5IDAuNDE3MDkgMy4zNjA4IDIuNDAxNSAyLjk0MzcgNC40NDk0bC04LjcyMjMgNDIuODI3Yy0wLjQxNzA4IDIuMDQ3OS0yLjM3NjEgMi42ODA3LTQuNDQ5NCAyLjk0MzdsLTEyLjgxMiAxLjYyNTZjLTAuOTk4NzQgMC4xMjY3MiAwLjI3ODA2LTMuMjc3NC0wLjU4NjY3LTUuMDc2LTAuOTMwMzctMS45MzUyLTEuMTIwOC01LjI4MjUtMC45MjU0Mi02LjM0NzlsNy4zNTA5LTQwLjA3NWMwLjM3NzA3LTIuMDU1NiAyLjQwMTUtMy4zNjA4IDQuNDQ5NC0yLjk0Mzd6IiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi42MjI2Ii8+PHBhdGggZD0ibS0yNTcuMjggMjE2LjQ2IDIuNzIwOC0zNS41NzYtMTguMTI0LTI1LjY0Mi03LjEyNzQgMzAuMTM0LTE5LjM3MSAzMS4zNTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMy40NSIvPjxwYXRoIGQ9Im0tMjM0LjkzIDEzOS45cy0xMS4wNCAwLjU0NDU3LTE0Ljg5NC0yLjcxMzJjLTQuNjI1MS0zLjkwOTUtMy44MzItMTUuMjAyLTYuMTg2OS0xNy4wODItNC4wNzI4LTMuMjUyMi0xNS4xMzgtNC41ODcyLTE1LjEzOC00LjU4NzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI4LjY1Ii8+PC9nPjxjaXJjbGUgY3g9Ii0yNTYuODQiIGN5PSI5Ni4yMzQiIHI9IjE0LjEzIi8+PHBhdGggZD0ibS0yMzYuNjUgMTIzLjEzLTMuNzQxNCA5OC41MzkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQuNzUiLz48cGF0aCBkPSJtLTI4My40OCAxMDkuNDUgMy4xNDQ0IDAuNzY4NDNjMy41MDA4IDAuODU1NTMgMy4xOTk1IDIuNzY2IDIuNDMxOCA2LjgxNTZsLTUuODcwNyAzMC45NjljLTAuNzY3NjggNC4wNDk3LTQuMjA0MSA2LjYyMTItNy43MDQ5IDUuNzY1NmwtMTAuMTctMi40ODUzYy0zLjUwMDgtMC44NTU1NC02Ljg1NTgtNS4zNDQtNC45MzM1LTguODU0MmwxNS45NzUtMjkuMTcxYzEuOTIyMy0zLjUxMDMgMy42MjcxLTQuNjY0MyA3LjEyNzktMy44MDg3eiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMy4wMjY1Ii8+PHBhdGggZD0ibS0yNTYuMTIgMTE1LjAycy0yLjU0NzMtMS4wNjcxLTIuOTc5LTIuNTY4M2MtMC40OTM5MS0xLjcxNzgtMC4yMDMyOS00LjUzNzYtMC4yMDMyOS00LjUzNzZsLTUuMTE1NC02LjI1MDNzLTAuNDUyMzYgNC43MDY5LTEuNzA4OCA2LjYwMDljLTEuMjIyNiAxLjg0My02LjE4IDMuMDgwOC02LjE4IDMuMDgwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Im0xNDIuNDUgODcuNzQ3IDE1LjYxMiAzLjE3OTZjMi41MDcyIDAuNTEwNjQgNC4xMTQ2IDIuOTQwMiAzLjYwNCA1LjQ0NzRsLTEwLjY3OSA1Mi40MzJjLTAuNTEwNjMgMi41MDcyLTIuOTA5MSAzLjI4MTktNS40NDc0IDMuNjA0bC0xNS42ODYgMS45OTAxYy0xLjIyMjggMC4xNTUxNCAwLjM0MDQzLTQuMDEyNS0wLjcxODI1LTYuMjE0NS0xLjEzOS0yLjM2OTItMS4zNzIyLTYuNDY3My0xLjEzMy03Ljc3MTdsOC45OTk2LTQ5LjA2M2MwLjQ2MTY1LTIuNTE2NyAyLjk0MDItNC4xMTQ2IDUuNDQ3NC0zLjYwNHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjIxMDkiLz48cGF0aCBkPSJtMTU5LjE1IDIxNi4xIDMuMzMxMS00My41NTUtMjIuMTg5LTMxLjM5NC04LjcyNiAzNi44OTItMjMuNzE2IDM4LjM4OSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjE2LjQ2NyIvPjxwYXRoIGQ9Im0xODYuNTEgMTIyLjM4cy0xMy41MTcgMC42NjY3MS0xOC4yMzUtMy4zMjE4Yy01LjY2MjQtNC43ODYzLTQuNjkxNC0xOC42MTEtNy41NzQ2LTIwLjkxMy00Ljk4NjMtMy45ODE2LTE4LjUzMy01LjYxNi0xOC41MzMtNS42MTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMC41OSIvPjwvZz48Y2lyY2xlIGN4PSIxNTkuNjkiIGN5PSI2OC45MTYiIHI9IjE3LjMiLz48cGF0aCBkPSJtMTgzLjEgMTA2Ljc5LTQuMDExOCAxMDUuNjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUuMDkzNCIvPjxwYXRoIGQ9Im0xMjcuMDggODUuMDk1IDMuODQ5NiAwLjk0MDc4YzQuMjg2IDEuMDQ3NCAzLjkxNzEgMy4zODYzIDIuOTc3MiA4LjM0NDNsLTcuMTg3NCAzNy45MTVjLTAuOTM5ODcgNC45NTgtNS4xNDcgOC4xMDYyLTkuNDMzIDcuMDU4OGwtMTIuNDUxLTMuMDQyN2MtNC4yODYtMS4wNDc0LTguMzkzNS02LjU0MjUtNi4wNC0xMC44NGwxOS41NTgtMzUuNzEzYzIuMzUzNC00LjI5NzYgNC40NDA2LTUuNzEwNCA4LjcyNjYtNC42NjN6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjcwNTMiLz48cGF0aCBkPSJtMTYwLjU4IDkxLjkxOHMtMy4xMTg2LTEuMzA2NS0zLjY0NzEtMy4xNDQzYy0wLjYwNDY5LTIuMTAzLTAuMjQ4ODktNS41NTUzLTAuMjQ4ODktNS41NTUzbC02LjI2MjgtNy42NTIxcy0wLjU1MzgyIDUuNzYyNy0yLjA5MjEgOC4wODE0Yy0xLjQ5NjggMi4yNTYzLTcuNTY2MSAzLjc3MTctNy41NjYxIDMuNzcxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="56" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="152,125,183,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="57" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNy45Nm1tIiBoZWlnaHQ9IjE0Ny4xOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTcuOTYgMTQ3LjE5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40OTIgLTczLjA0NikiPjxyZWN0IHg9IjQ1LjQ5MiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjEzNC4zMiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjY0Ljk5NiIgeT0iMTM0Ljc4IiB3aWR0aD0iODQuMDY2IiBoZWlnaHQ9IjIzLjcyMSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.00707" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="58" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS41OW1tIiBoZWlnaHQ9IjE2MS41OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuNTkgMTYxLjU5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xOS4xNTkgLTYxLjY3NSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC4wOTU0NTIgLS4wODA3MTEpIj48cmVjdCB4PSI2Mi4zNjEiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSIxMTguODQiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSI3NC43NjIiIHk9IjEzNS4wMSIgd2lkdGg9IjUzLjQ0OSIgaGVpZ2h0PSIxNS4wODEiLz48L2c+PGNpcmNsZSBjeD0iOTkuOTU2IiBjeT0iMTQyLjQ3IiByPSI3My4yMDIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMTUuMTkiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="59" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNS4xN21tIiBoZWlnaHQ9IjE1Ni42Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjUuMTcgMTU2LjY2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MC42MzcgLTc2LjA2OCkiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY0NThweCI+PHBhdGggZD0ibTEwNC4zNSA3Ni4xNjNzNS41MzM0IDkuNTA5OSA1LjU4NjcgMTQuNDg1YzAuMDUxMyA0Ljc4MzgtNC40MTYyIDguMjU5MS03LjkwMTYgMTEuMjIzLTEwLjMyNyA4Ljc4MTktMTkuNDY4IDE4LjQzNC0yMi4wMTkgMzAuNzkxLTEuOTI0OCA5LjMyNTYgMS42Mjk2IDE5LjQ4NyA2LjA1ODEgMjcuOTE3IDMuMzc0OSA2LjQyNCAxNC44OTkgMTUuODczIDE0Ljg5OSAxNS44NzNzMTIuNzQ2LTkuODI3OCAxNy4xMjgtMTYuNDFjNS4xNjkzLTcuNzY1MyA5LjI3MjUtMTYuODE5IDEwLjA2NC0yNi4xMTQgMS4xMzQ5LTEzLjMzLTEuMTM2Ni0yNy44MDUtNy44OTQyLTM5LjM1MS00LjEwNzctNy4wMTg1LTE1LjkyMS0xOC40MTUtMTUuOTIxLTE4LjQxNXoiLz48cGF0aCBkPSJtMTMzLjYgMTE1Ljg3czEuNzk5NSAyMS4wNzYtMS4yNzk4IDMwLjkyMmMtMy42MjkgMTEuNjAzLTE5LjUyNCAzMC44MDctMTkuNTI0IDMwLjgwN3MyNC40NDgtMi41ODI3IDMyLjIwNy0xMC44MzVjNi42MTczLTcuMDM4MiA5LjU4MjQtMTguNTQ1IDcuNTMxNi0yNy45ODYtMi4xMDMtOS42ODExLTE4LjkzNS0yMi45MDgtMTguOTM1LTIyLjkwOHoiLz48cGF0aCBkPSJtNzMuNzg4IDEyMS43cy0wLjg4MjU5IDguNzAyNi0zLjY1MDQgMTEuNzE0Yy02LjI2MjIgNi44MTIyLTExLjQ2NiAxNC45MzEtMTAuOTY5IDIzLjU4OSAwLjM3ODMyIDYuNTk2NCA0Ljg3MjYgMTMuMjE3IDEwLjM1OCAxNi45IDQuMTMzNCAyLjc3NTIgOS43NzI0IDIuNzE0OSAxNC43NDEgMi40MDMyIDQuMTEyLTAuMjU3ODggOC40NTAyIDEuMDkyNiA4LjQ1MDIgMS4wOTI2cy0xNC4wMS0xMC45MzUtMTcuMjg4LTE4Ljc4OWMtMy40OC04LjMzNjItMy4xNTg2LTE3LjQwNC0xLjI3NjMtMjcuMDcgMC42MjczLTMuMjIxNC0wLjM2NTM5LTkuODM4OC0wLjM2NTM5LTkuODM4OHoiLz48cGF0aCBkPSJtNDAuODIzIDIxOS42NiAxMDkuNTItNDIuMjE1IDUuNjkwOCA5LjE5MDEtMTA4LjUgNDUuOTJ6Ii8+PHBhdGggZD0ibTE2NS42MiAyMTkuMzgtMTA5LjUyLTQyLjIxNS01LjY5MDggOS4xOTAxIDEwOC41IDQ1LjkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.15476" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3MC40NW1tIiBoZWlnaHQ9IjE3My43OG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzAuNDUgMTczLjc4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMS4zNTUgLTUxLjYxNykiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyOC41IC44OTA1NCkiPjxnIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0ibS0yNzAuOTIgMTExLjYxIDEyLjc1MiAyLjU5NzFjMi4wNDc5IDAuNDE3MDkgMy4zNjA4IDIuNDAxNSAyLjk0MzcgNC40NDk0bC04LjcyMjMgNDIuODI3Yy0wLjQxNzA4IDIuMDQ3OS0yLjM3NjEgMi42ODA3LTQuNDQ5NCAyLjk0MzdsLTEyLjgxMiAxLjYyNTZjLTAuOTk4NzQgMC4xMjY3MiAwLjI3ODA2LTMuMjc3NC0wLjU4NjY3LTUuMDc2LTAuOTMwMzctMS45MzUyLTEuMTIwOC01LjI4MjUtMC45MjU0Mi02LjM0NzlsNy4zNTA5LTQwLjA3NWMwLjM3NzA3LTIuMDU1NiAyLjQwMTUtMy4zNjA4IDQuNDQ5NC0yLjk0Mzd6IiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi42MjI2Ii8+PHBhdGggZD0ibS0yNTcuMjggMjE2LjQ2IDIuNzIwOC0zNS41NzYtMTguMTI0LTI1LjY0Mi03LjEyNzQgMzAuMTM0LTE5LjM3MSAzMS4zNTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMy40NSIvPjxwYXRoIGQ9Im0tMjM0LjkzIDEzOS45cy0xMS4wNCAwLjU0NDU3LTE0Ljg5NC0yLjcxMzJjLTQuNjI1MS0zLjkwOTUtMy44MzItMTUuMjAyLTYuMTg2OS0xNy4wODItNC4wNzI4LTMuMjUyMi0xNS4xMzgtNC41ODcyLTE1LjEzOC00LjU4NzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI4LjY1Ii8+PC9nPjxjaXJjbGUgY3g9Ii0yNTYuODQiIGN5PSI5Ni4yMzQiIHI9IjE0LjEzIi8+PHBhdGggZD0ibS0yMzYuNjUgMTIzLjEzLTMuNzQxNCA5OC41MzkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQuNzUiLz48cGF0aCBkPSJtLTI4My40OCAxMDkuNDUgMy4xNDQ0IDAuNzY4NDNjMy41MDA4IDAuODU1NTMgMy4xOTk1IDIuNzY2IDIuNDMxOCA2LjgxNTZsLTUuODcwNyAzMC45NjljLTAuNzY3NjggNC4wNDk3LTQuMjA0MSA2LjYyMTItNy43MDQ5IDUuNzY1NmwtMTAuMTctMi40ODUzYy0zLjUwMDgtMC44NTU1NC02Ljg1NTgtNS4zNDQtNC45MzM1LTguODU0MmwxNS45NzUtMjkuMTcxYzEuOTIyMy0zLjUxMDMgMy42MjcxLTQuNjY0MyA3LjEyNzktMy44MDg3eiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMy4wMjY1Ii8+PHBhdGggZD0ibS0yNTYuMTIgMTE1LjAycy0yLjU0NzMtMS4wNjcxLTIuOTc5LTIuNTY4M2MtMC40OTM5MS0xLjcxNzgtMC4yMDMyOS00LjUzNzYtMC4yMDMyOS00LjUzNzZsLTUuMTE1NC02LjI1MDNzLTAuNDUyMzYgNC43MDY5LTEuNzA4OCA2LjYwMDljLTEuMjIyNiAxLjg0My02LjE4IDMuMDgwOC02LjE4IDMuMDgwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Im0xNDIuNDUgODcuNzQ3IDE1LjYxMiAzLjE3OTZjMi41MDcyIDAuNTEwNjQgNC4xMTQ2IDIuOTQwMiAzLjYwNCA1LjQ0NzRsLTEwLjY3OSA1Mi40MzJjLTAuNTEwNjMgMi41MDcyLTIuOTA5MSAzLjI4MTktNS40NDc0IDMuNjA0bC0xNS42ODYgMS45OTAxYy0xLjIyMjggMC4xNTUxNCAwLjM0MDQzLTQuMDEyNS0wLjcxODI1LTYuMjE0NS0xLjEzOS0yLjM2OTItMS4zNzIyLTYuNDY3My0xLjEzMy03Ljc3MTdsOC45OTk2LTQ5LjA2M2MwLjQ2MTY1LTIuNTE2NyAyLjk0MDItNC4xMTQ2IDUuNDQ3NC0zLjYwNHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjIxMDkiLz48cGF0aCBkPSJtMTU5LjE1IDIxNi4xIDMuMzMxMS00My41NTUtMjIuMTg5LTMxLjM5NC04LjcyNiAzNi44OTItMjMuNzE2IDM4LjM4OSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjE2LjQ2NyIvPjxwYXRoIGQ9Im0xODYuNTEgMTIyLjM4cy0xMy41MTcgMC42NjY3MS0xOC4yMzUtMy4zMjE4Yy01LjY2MjQtNC43ODYzLTQuNjkxNC0xOC42MTEtNy41NzQ2LTIwLjkxMy00Ljk4NjMtMy45ODE2LTE4LjUzMy01LjYxNi0xOC41MzMtNS42MTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMC41OSIvPjwvZz48Y2lyY2xlIGN4PSIxNTkuNjkiIGN5PSI2OC45MTYiIHI9IjE3LjMiLz48cGF0aCBkPSJtMTgzLjEgMTA2Ljc5LTQuMDExOCAxMDUuNjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUuMDkzNCIvPjxwYXRoIGQ9Im0xMjcuMDggODUuMDk1IDMuODQ5NiAwLjk0MDc4YzQuMjg2IDEuMDQ3NCAzLjkxNzEgMy4zODYzIDIuOTc3MiA4LjM0NDNsLTcuMTg3NCAzNy45MTVjLTAuOTM5ODcgNC45NTgtNS4xNDcgOC4xMDYyLTkuNDMzIDcuMDU4OGwtMTIuNDUxLTMuMDQyN2MtNC4yODYtMS4wNDc0LTguMzkzNS02LjU0MjUtNi4wNC0xMC44NGwxOS41NTgtMzUuNzEzYzIuMzUzNC00LjI5NzYgNC40NDA2LTUuNzEwNCA4LjcyNjYtNC42NjN6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjcwNTMiLz48cGF0aCBkPSJtMTYwLjU4IDkxLjkxOHMtMy4xMTg2LTEuMzA2NS0zLjY0NzEtMy4xNDQzYy0wLjYwNDY5LTIuMTAzLTAuMjQ4ODktNS41NTUzLTAuMjQ4ODktNS41NTUzbC02LjI2MjgtNy42NTIxcy0wLjU1MzgyIDUuNzYyNy0yLjA5MjEgOC4wODE0Yy0xLjQ5NjggMi4yNTYzLTcuNTY2MSAzLjc3MTctNy41NjYxIDMuNzcxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="60" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMC4wOW1tIiBoZWlnaHQ9IjE1OS41M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjAuMDkgMTU5LjUzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC41MjUgLTY3LjA4NykiPjxyZWN0IHg9IjQ0LjUyNSIgeT0iMjE2LjAzIiB3aWR0aD0iMTIwLjA5IiBoZWlnaHQ9IjEwLjU4Ii8+PHJlY3QgeD0iNzAuMTM3IiB5PSIxNjcuMjIiIHdpZHRoPSI2OC44NjciIGhlaWdodD0iNTAuMjY4Ii8+PHBhdGggdHJhbnNmb3JtPSJtYXRyaXgoLjk0NDMgMCAwIC42MzM2NSAxMC45NTUgNzcuMDM5KSIgZD0ibTE1Mi44MiAxNDcuMDdoLTEwNy4zN2w1My42ODUtOTIuOTg1eiIvPjxwYXRoIGQ9Im0xMDAuNjIgMTE4LjQ4di01MS4xODJsMzUuNjAzIDE2LjM3M3YyNS43NjhsLTI3LjA0My0xNS4xNHYyNy41NzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.76387" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="61" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk1Ljc3NG1tIiBoZWlnaHQ9IjE2Ni4zM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5NS43NzQgMTY2LjMzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi42NjQgLTY2LjAwNSkiPjxyZWN0IHRyYW5zZm9ybT0ibWF0cml4KC41MjM1NCAtLjg1MiAuODg1NDggLjQ2NDY4IDAgMCkiIHg9Ii04Ny40ODciIHk9IjEyMi40MyIgd2lkdGg9IjU3Ljk0MiIgaGVpZ2h0PSIxMC4xNCIvPjxjaXJjbGUgY3g9IjExOC45NCIgY3k9IjgwLjQ2IiByPSIxNC40NTUiLz48cGF0aCBkPSJtMTEwLjI4IDg0LjcwNXMtMjQuMjg1IDI5LjM5Mi0zMC45MTcgNDYuOTA1Yy0yLjgxMDMgNy40MjA5LTEuMzUxMyAxNS44ODktMy4zNTEyIDIzLjU2OC0yLjY2MDYgMTAuMjE2LTkuOTQwNiAyNi42NzUtMTQuMTg2IDM1LjE0Ni00LjY5MTkgOS4zNjItNS41NDAyIDEzLjc1MS04LjYyMjkgMjMuOTU1LTAuOTkxNTggMy4yODIyLTAuMjEyNCA4Ljg5NCAzLjA5MTUgOS44MTA2IDguMTAzNiAyLjI0OCAxNy41MTggMy40NTExIDE5LjY4OCAyLjMzODUgMS44MjM4LTAuOTM0ODQgMS43MTk5LTQuMjU2IDAuMjgyNzYtNS43Njg4LTEuNzIyMi0xLjgxMjctNi4wNDYxLTAuNzM3NjEtNy4wMjA4LTMuMTAzNC0xLjYwMjQtMy44ODk1LTAuNTg4Mi03LjUxOTIgMC40OTQ1NC0xMS40NCAyLjE3NDUtNy44NzUyIDcuODQ4OS0xMi4yMDQgMTIuMjM4LTIxLjU3MSAzLjc2ODQtOC4wNDIzIDcuNjA0OC0xNS4yNDQgMTAuNTUtMTUuMjQ0IDIuNDQ5OSAwIDYuODk3NyA4LjI1MjIgOS41OTA2IDEzLjA3MSAzLjY3ODMgNi41ODI3IDcuNzcgMTUuNTExIDguOTEzNyAyMy43ODIgMS40MzU5IDEwLjM4NSAxLjEwNDIgMTcuNzcgNi4wOTkzIDIzLjQxMSAyLjEwOTIgMi4zODE2IDcuNTgzNyAyLjE0NjQgMTIuODkyIDIuMjk2NiA0LjkzMTYgMC4xMzk1NCA4LjU2MjUgMS4wNzE0IDExLjE4Ny0wLjkzMjgxIDIuMzMxMS0xLjc4MDMtMS4xOTg2LTUuNjc3OS00LjA1NTQtNi42NjkyLTMuNDAxNS0xLjE4MDMtMTEuMTI5LTIuNTY3LTExLjg4NS02LjU1Ni0yLjE3MDYtMTEuNDUzLTMuMzAxNC0yMS4zOTEtNi45OTU5LTMxLjQ4OS0yLjgyOS03LjczMjItNy42NjQtMTQuMjQ1LTExLjQ2OS0yMS44NzYtMy4yNjgyLTYuNTU0NC00LjgxNzUtMTQuMjQ1LTIuOTQyMy0yNS40NiAwLjQ3NDU0LTIuODM3OSAxLjc5NTgtNi44NDU4IDUuNjE4My02LjU1MzIgMy43MjYzIDAuMjg1MjUgMTEuODgyIDYuNTI4NSAxNi41NzIgOS42Nzc3IDguNzM0MiA1Ljg2NDUgMTMuNzc1IDEwLjAxMSAxMy43NzUgMTAuMDExczUuMzU3IDIuMDkxOCA3LjEwMzUgMC40ODQ3YzEuMzM1Ni0xLjIyOSAyLjI0ODQtMi44MTk4IDAuMDgxMi01LjQ0NDQtMy44NDg2LTQuNjYwOC0xNy43NTQtMTIuNjYtMjMuMzk4LTE2LjMzMi0yLjgyNTgtMS44Mzc4LTQuNDY4OS0yLjEwNTUtNC42NzE5LTUuNjIyMi0wLjI1NDE1LTQuNDAzMyAwLTExLjIzMSAwLTE1Ljk5OHYtMjEuNTEyeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PHBhdGggZD0ibTEzOS45NyAxNDQuNjRzLTM0Ljk4NCA1Ni4wODgtNDkuMTExIDc5Ljc4M2MtMC44NjgzNyAxLjQ1NjUtMC4wNDEzOSA0LjExODEgMS40Nzk5IDQuODY3MSAxLjU3OCAwLjc3Njk1IDIuODgzMyAwLjQwNzM4IDQuOTM3NC0xLjg2MTggMi44ODkxLTMuMTkxNiA0OC41My03OC4xOTQgNDguNTMtNzguMTk0eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.10936" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="62" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3MC40NW1tIiBoZWlnaHQ9IjE3My43OG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzAuNDUgMTczLjc4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMS4zNTUgLTUxLjYxNykiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyOC41IC44OTA1NCkiPjxnIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0ibS0yNzAuOTIgMTExLjYxIDEyLjc1MiAyLjU5NzFjMi4wNDc5IDAuNDE3MDkgMy4zNjA4IDIuNDAxNSAyLjk0MzcgNC40NDk0bC04LjcyMjMgNDIuODI3Yy0wLjQxNzA4IDIuMDQ3OS0yLjM3NjEgMi42ODA3LTQuNDQ5NCAyLjk0MzdsLTEyLjgxMiAxLjYyNTZjLTAuOTk4NzQgMC4xMjY3MiAwLjI3ODA2LTMuMjc3NC0wLjU4NjY3LTUuMDc2LTAuOTMwMzctMS45MzUyLTEuMTIwOC01LjI4MjUtMC45MjU0Mi02LjM0NzlsNy4zNTA5LTQwLjA3NWMwLjM3NzA3LTIuMDU1NiAyLjQwMTUtMy4zNjA4IDQuNDQ5NC0yLjk0Mzd6IiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi42MjI2Ii8+PHBhdGggZD0ibS0yNTcuMjggMjE2LjQ2IDIuNzIwOC0zNS41NzYtMTguMTI0LTI1LjY0Mi03LjEyNzQgMzAuMTM0LTE5LjM3MSAzMS4zNTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMy40NSIvPjxwYXRoIGQ9Im0tMjM0LjkzIDEzOS45cy0xMS4wNCAwLjU0NDU3LTE0Ljg5NC0yLjcxMzJjLTQuNjI1MS0zLjkwOTUtMy44MzItMTUuMjAyLTYuMTg2OS0xNy4wODItNC4wNzI4LTMuMjUyMi0xNS4xMzgtNC41ODcyLTE1LjEzOC00LjU4NzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI4LjY1Ii8+PC9nPjxjaXJjbGUgY3g9Ii0yNTYuODQiIGN5PSI5Ni4yMzQiIHI9IjE0LjEzIi8+PHBhdGggZD0ibS0yMzYuNjUgMTIzLjEzLTMuNzQxNCA5OC41MzkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQuNzUiLz48cGF0aCBkPSJtLTI4My40OCAxMDkuNDUgMy4xNDQ0IDAuNzY4NDNjMy41MDA4IDAuODU1NTMgMy4xOTk1IDIuNzY2IDIuNDMxOCA2LjgxNTZsLTUuODcwNyAzMC45NjljLTAuNzY3NjggNC4wNDk3LTQuMjA0MSA2LjYyMTItNy43MDQ5IDUuNzY1NmwtMTAuMTctMi40ODUzYy0zLjUwMDgtMC44NTU1NC02Ljg1NTgtNS4zNDQtNC45MzM1LTguODU0MmwxNS45NzUtMjkuMTcxYzEuOTIyMy0zLjUxMDMgMy42MjcxLTQuNjY0MyA3LjEyNzktMy44MDg3eiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMy4wMjY1Ii8+PHBhdGggZD0ibS0yNTYuMTIgMTE1LjAycy0yLjU0NzMtMS4wNjcxLTIuOTc5LTIuNTY4M2MtMC40OTM5MS0xLjcxNzgtMC4yMDMyOS00LjUzNzYtMC4yMDMyOS00LjUzNzZsLTUuMTE1NC02LjI1MDNzLTAuNDUyMzYgNC43MDY5LTEuNzA4OCA2LjYwMDljLTEuMjIyNiAxLjg0My02LjE4IDMuMDgwOC02LjE4IDMuMDgwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Im0xNDIuNDUgODcuNzQ3IDE1LjYxMiAzLjE3OTZjMi41MDcyIDAuNTEwNjQgNC4xMTQ2IDIuOTQwMiAzLjYwNCA1LjQ0NzRsLTEwLjY3OSA1Mi40MzJjLTAuNTEwNjMgMi41MDcyLTIuOTA5MSAzLjI4MTktNS40NDc0IDMuNjA0bC0xNS42ODYgMS45OTAxYy0xLjIyMjggMC4xNTUxNCAwLjM0MDQzLTQuMDEyNS0wLjcxODI1LTYuMjE0NS0xLjEzOS0yLjM2OTItMS4zNzIyLTYuNDY3My0xLjEzMy03Ljc3MTdsOC45OTk2LTQ5LjA2M2MwLjQ2MTY1LTIuNTE2NyAyLjk0MDItNC4xMTQ2IDUuNDQ3NC0zLjYwNHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjIxMDkiLz48cGF0aCBkPSJtMTU5LjE1IDIxNi4xIDMuMzMxMS00My41NTUtMjIuMTg5LTMxLjM5NC04LjcyNiAzNi44OTItMjMuNzE2IDM4LjM4OSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjE2LjQ2NyIvPjxwYXRoIGQ9Im0xODYuNTEgMTIyLjM4cy0xMy41MTcgMC42NjY3MS0xOC4yMzUtMy4zMjE4Yy01LjY2MjQtNC43ODYzLTQuNjkxNC0xOC42MTEtNy41NzQ2LTIwLjkxMy00Ljk4NjMtMy45ODE2LTE4LjUzMy01LjYxNi0xOC41MzMtNS42MTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMC41OSIvPjwvZz48Y2lyY2xlIGN4PSIxNTkuNjkiIGN5PSI2OC45MTYiIHI9IjE3LjMiLz48cGF0aCBkPSJtMTgzLjEgMTA2Ljc5LTQuMDExOCAxMDUuNjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUuMDkzNCIvPjxwYXRoIGQ9Im0xMjcuMDggODUuMDk1IDMuODQ5NiAwLjk0MDc4YzQuMjg2IDEuMDQ3NCAzLjkxNzEgMy4zODYzIDIuOTc3MiA4LjM0NDNsLTcuMTg3NCAzNy45MTVjLTAuOTM5ODcgNC45NTgtNS4xNDcgOC4xMDYyLTkuNDMzIDcuMDU4OGwtMTIuNDUxLTMuMDQyN2MtNC4yODYtMS4wNDc0LTguMzkzNS02LjU0MjUtNi4wNC0xMC44NGwxOS41NTgtMzUuNzEzYzIuMzUzNC00LjI5NzYgNC40NDA2LTUuNzEwNCA4LjcyNjYtNC42NjN6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjcwNTMiLz48cGF0aCBkPSJtMTYwLjU4IDkxLjkxOHMtMy4xMTg2LTEuMzA2NS0zLjY0NzEtMy4xNDQzYy0wLjYwNDY5LTIuMTAzLTAuMjQ4ODktNS41NTUzLTAuMjQ4ODktNS41NTUzbC02LjI2MjgtNy42NTIxcy0wLjU1MzgyIDUuNzYyNy0yLjA5MjEgOC4wODE0Yy0xLjQ5NjggMi4yNTYzLTcuNTY2MSAzLjc3MTctNy41NjYxIDMuNzcxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="63" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,207,80,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="64" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNy45Nm1tIiBoZWlnaHQ9IjE0Ny4xOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTcuOTYgMTQ3LjE5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40OTIgLTczLjA0NikiPjxyZWN0IHg9IjQ1LjQ5MiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjEzNC4zMiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjY0Ljk5NiIgeT0iMTM0Ljc4IiB3aWR0aD0iODQuMDY2IiBoZWlnaHQ9IjIzLjcyMSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.00707" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="65" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS41OW1tIiBoZWlnaHQ9IjE2MS41OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuNTkgMTYxLjU5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xOS4xNTkgLTYxLjY3NSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC4wOTU0NTIgLS4wODA3MTEpIj48cmVjdCB4PSI2Mi4zNjEiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSIxMTguODQiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSI3NC43NjIiIHk9IjEzNS4wMSIgd2lkdGg9IjUzLjQ0OSIgaGVpZ2h0PSIxNS4wODEiLz48L2c+PGNpcmNsZSBjeD0iOTkuOTU2IiBjeT0iMTQyLjQ3IiByPSI3My4yMDIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMTUuMTkiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="66" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNS4xN21tIiBoZWlnaHQ9IjE1Ni42Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjUuMTcgMTU2LjY2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MC42MzcgLTc2LjA2OCkiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY0NThweCI+PHBhdGggZD0ibTEwNC4zNSA3Ni4xNjNzNS41MzM0IDkuNTA5OSA1LjU4NjcgMTQuNDg1YzAuMDUxMyA0Ljc4MzgtNC40MTYyIDguMjU5MS03LjkwMTYgMTEuMjIzLTEwLjMyNyA4Ljc4MTktMTkuNDY4IDE4LjQzNC0yMi4wMTkgMzAuNzkxLTEuOTI0OCA5LjMyNTYgMS42Mjk2IDE5LjQ4NyA2LjA1ODEgMjcuOTE3IDMuMzc0OSA2LjQyNCAxNC44OTkgMTUuODczIDE0Ljg5OSAxNS44NzNzMTIuNzQ2LTkuODI3OCAxNy4xMjgtMTYuNDFjNS4xNjkzLTcuNzY1MyA5LjI3MjUtMTYuODE5IDEwLjA2NC0yNi4xMTQgMS4xMzQ5LTEzLjMzLTEuMTM2Ni0yNy44MDUtNy44OTQyLTM5LjM1MS00LjEwNzctNy4wMTg1LTE1LjkyMS0xOC40MTUtMTUuOTIxLTE4LjQxNXoiLz48cGF0aCBkPSJtMTMzLjYgMTE1Ljg3czEuNzk5NSAyMS4wNzYtMS4yNzk4IDMwLjkyMmMtMy42MjkgMTEuNjAzLTE5LjUyNCAzMC44MDctMTkuNTI0IDMwLjgwN3MyNC40NDgtMi41ODI3IDMyLjIwNy0xMC44MzVjNi42MTczLTcuMDM4MiA5LjU4MjQtMTguNTQ1IDcuNTMxNi0yNy45ODYtMi4xMDMtOS42ODExLTE4LjkzNS0yMi45MDgtMTguOTM1LTIyLjkwOHoiLz48cGF0aCBkPSJtNzMuNzg4IDEyMS43cy0wLjg4MjU5IDguNzAyNi0zLjY1MDQgMTEuNzE0Yy02LjI2MjIgNi44MTIyLTExLjQ2NiAxNC45MzEtMTAuOTY5IDIzLjU4OSAwLjM3ODMyIDYuNTk2NCA0Ljg3MjYgMTMuMjE3IDEwLjM1OCAxNi45IDQuMTMzNCAyLjc3NTIgOS43NzI0IDIuNzE0OSAxNC43NDEgMi40MDMyIDQuMTEyLTAuMjU3ODggOC40NTAyIDEuMDkyNiA4LjQ1MDIgMS4wOTI2cy0xNC4wMS0xMC45MzUtMTcuMjg4LTE4Ljc4OWMtMy40OC04LjMzNjItMy4xNTg2LTE3LjQwNC0xLjI3NjMtMjcuMDcgMC42MjczLTMuMjIxNC0wLjM2NTM5LTkuODM4OC0wLjM2NTM5LTkuODM4OHoiLz48cGF0aCBkPSJtNDAuODIzIDIxOS42NiAxMDkuNTItNDIuMjE1IDUuNjkwOCA5LjE5MDEtMTA4LjUgNDUuOTJ6Ii8+PHBhdGggZD0ibTE2NS42MiAyMTkuMzgtMTA5LjUyLTQyLjIxNS01LjY5MDggOS4xOTAxIDEwOC41IDQ1LjkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.15476" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="67" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMC4wOW1tIiBoZWlnaHQ9IjE1OS41M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjAuMDkgMTU5LjUzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC41MjUgLTY3LjA4NykiPjxyZWN0IHg9IjQ0LjUyNSIgeT0iMjE2LjAzIiB3aWR0aD0iMTIwLjA5IiBoZWlnaHQ9IjEwLjU4Ii8+PHJlY3QgeD0iNzAuMTM3IiB5PSIxNjcuMjIiIHdpZHRoPSI2OC44NjciIGhlaWdodD0iNTAuMjY4Ii8+PHBhdGggdHJhbnNmb3JtPSJtYXRyaXgoLjk0NDMgMCAwIC42MzM2NSAxMC45NTUgNzcuMDM5KSIgZD0ibTE1Mi44MiAxNDcuMDdoLTEwNy4zN2w1My42ODUtOTIuOTg1eiIvPjxwYXRoIGQ9Im0xMDAuNjIgMTE4LjQ4di01MS4xODJsMzUuNjAzIDE2LjM3M3YyNS43NjhsLTI3LjA0My0xNS4xNHYyNy41NzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.76387" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="68" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk1Ljc3NG1tIiBoZWlnaHQ9IjE2Ni4zM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5NS43NzQgMTY2LjMzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi42NjQgLTY2LjAwNSkiPjxyZWN0IHRyYW5zZm9ybT0ibWF0cml4KC41MjM1NCAtLjg1MiAuODg1NDggLjQ2NDY4IDAgMCkiIHg9Ii04Ny40ODciIHk9IjEyMi40MyIgd2lkdGg9IjU3Ljk0MiIgaGVpZ2h0PSIxMC4xNCIvPjxjaXJjbGUgY3g9IjExOC45NCIgY3k9IjgwLjQ2IiByPSIxNC40NTUiLz48cGF0aCBkPSJtMTEwLjI4IDg0LjcwNXMtMjQuMjg1IDI5LjM5Mi0zMC45MTcgNDYuOTA1Yy0yLjgxMDMgNy40MjA5LTEuMzUxMyAxNS44ODktMy4zNTEyIDIzLjU2OC0yLjY2MDYgMTAuMjE2LTkuOTQwNiAyNi42NzUtMTQuMTg2IDM1LjE0Ni00LjY5MTkgOS4zNjItNS41NDAyIDEzLjc1MS04LjYyMjkgMjMuOTU1LTAuOTkxNTggMy4yODIyLTAuMjEyNCA4Ljg5NCAzLjA5MTUgOS44MTA2IDguMTAzNiAyLjI0OCAxNy41MTggMy40NTExIDE5LjY4OCAyLjMzODUgMS44MjM4LTAuOTM0ODQgMS43MTk5LTQuMjU2IDAuMjgyNzYtNS43Njg4LTEuNzIyMi0xLjgxMjctNi4wNDYxLTAuNzM3NjEtNy4wMjA4LTMuMTAzNC0xLjYwMjQtMy44ODk1LTAuNTg4Mi03LjUxOTIgMC40OTQ1NC0xMS40NCAyLjE3NDUtNy44NzUyIDcuODQ4OS0xMi4yMDQgMTIuMjM4LTIxLjU3MSAzLjc2ODQtOC4wNDIzIDcuNjA0OC0xNS4yNDQgMTAuNTUtMTUuMjQ0IDIuNDQ5OSAwIDYuODk3NyA4LjI1MjIgOS41OTA2IDEzLjA3MSAzLjY3ODMgNi41ODI3IDcuNzcgMTUuNTExIDguOTEzNyAyMy43ODIgMS40MzU5IDEwLjM4NSAxLjEwNDIgMTcuNzcgNi4wOTkzIDIzLjQxMSAyLjEwOTIgMi4zODE2IDcuNTgzNyAyLjE0NjQgMTIuODkyIDIuMjk2NiA0LjkzMTYgMC4xMzk1NCA4LjU2MjUgMS4wNzE0IDExLjE4Ny0wLjkzMjgxIDIuMzMxMS0xLjc4MDMtMS4xOTg2LTUuNjc3OS00LjA1NTQtNi42NjkyLTMuNDAxNS0xLjE4MDMtMTEuMTI5LTIuNTY3LTExLjg4NS02LjU1Ni0yLjE3MDYtMTEuNDUzLTMuMzAxNC0yMS4zOTEtNi45OTU5LTMxLjQ4OS0yLjgyOS03LjczMjItNy42NjQtMTQuMjQ1LTExLjQ2OS0yMS44NzYtMy4yNjgyLTYuNTU0NC00LjgxNzUtMTQuMjQ1LTIuOTQyMy0yNS40NiAwLjQ3NDU0LTIuODM3OSAxLjc5NTgtNi44NDU4IDUuNjE4My02LjU1MzIgMy43MjYzIDAuMjg1MjUgMTEuODgyIDYuNTI4NSAxNi41NzIgOS42Nzc3IDguNzM0MiA1Ljg2NDUgMTMuNzc1IDEwLjAxMSAxMy43NzUgMTAuMDExczUuMzU3IDIuMDkxOCA3LjEwMzUgMC40ODQ3YzEuMzM1Ni0xLjIyOSAyLjI0ODQtMi44MTk4IDAuMDgxMi01LjQ0NDQtMy44NDg2LTQuNjYwOC0xNy43NTQtMTIuNjYtMjMuMzk4LTE2LjMzMi0yLjgyNTgtMS44Mzc4LTQuNDY4OS0yLjEwNTUtNC42NzE5LTUuNjIyMi0wLjI1NDE1LTQuNDAzMyAwLTExLjIzMSAwLTE1Ljk5OHYtMjEuNTEyeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PHBhdGggZD0ibTEzOS45NyAxNDQuNjRzLTM0Ljk4NCA1Ni4wODgtNDkuMTExIDc5Ljc4M2MtMC44NjgzNyAxLjQ1NjUtMC4wNDEzOSA0LjExODEgMS40Nzk5IDQuODY3MSAxLjU3OCAwLjc3Njk1IDIuODgzMyAwLjQwNzM4IDQuOTM3NC0xLjg2MTggMi44ODkxLTMuMTkxNiA0OC41My03OC4xOTQgNDguNTMtNzguMTk0eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.10936" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="69" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3MC40NW1tIiBoZWlnaHQ9IjE3My43OG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzAuNDUgMTczLjc4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMS4zNTUgLTUxLjYxNykiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyOC41IC44OTA1NCkiPjxnIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0ibS0yNzAuOTIgMTExLjYxIDEyLjc1MiAyLjU5NzFjMi4wNDc5IDAuNDE3MDkgMy4zNjA4IDIuNDAxNSAyLjk0MzcgNC40NDk0bC04LjcyMjMgNDIuODI3Yy0wLjQxNzA4IDIuMDQ3OS0yLjM3NjEgMi42ODA3LTQuNDQ5NCAyLjk0MzdsLTEyLjgxMiAxLjYyNTZjLTAuOTk4NzQgMC4xMjY3MiAwLjI3ODA2LTMuMjc3NC0wLjU4NjY3LTUuMDc2LTAuOTMwMzctMS45MzUyLTEuMTIwOC01LjI4MjUtMC45MjU0Mi02LjM0NzlsNy4zNTA5LTQwLjA3NWMwLjM3NzA3LTIuMDU1NiAyLjQwMTUtMy4zNjA4IDQuNDQ5NC0yLjk0Mzd6IiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi42MjI2Ii8+PHBhdGggZD0ibS0yNTcuMjggMjE2LjQ2IDIuNzIwOC0zNS41NzYtMTguMTI0LTI1LjY0Mi03LjEyNzQgMzAuMTM0LTE5LjM3MSAzMS4zNTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMy40NSIvPjxwYXRoIGQ9Im0tMjM0LjkzIDEzOS45cy0xMS4wNCAwLjU0NDU3LTE0Ljg5NC0yLjcxMzJjLTQuNjI1MS0zLjkwOTUtMy44MzItMTUuMjAyLTYuMTg2OS0xNy4wODItNC4wNzI4LTMuMjUyMi0xNS4xMzgtNC41ODcyLTE1LjEzOC00LjU4NzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI4LjY1Ii8+PC9nPjxjaXJjbGUgY3g9Ii0yNTYuODQiIGN5PSI5Ni4yMzQiIHI9IjE0LjEzIi8+PHBhdGggZD0ibS0yMzYuNjUgMTIzLjEzLTMuNzQxNCA5OC41MzkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQuNzUiLz48cGF0aCBkPSJtLTI4My40OCAxMDkuNDUgMy4xNDQ0IDAuNzY4NDNjMy41MDA4IDAuODU1NTMgMy4xOTk1IDIuNzY2IDIuNDMxOCA2LjgxNTZsLTUuODcwNyAzMC45NjljLTAuNzY3NjggNC4wNDk3LTQuMjA0MSA2LjYyMTItNy43MDQ5IDUuNzY1NmwtMTAuMTctMi40ODUzYy0zLjUwMDgtMC44NTU1NC02Ljg1NTgtNS4zNDQtNC45MzM1LTguODU0MmwxNS45NzUtMjkuMTcxYzEuOTIyMy0zLjUxMDMgMy42MjcxLTQuNjY0MyA3LjEyNzktMy44MDg3eiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMy4wMjY1Ii8+PHBhdGggZD0ibS0yNTYuMTIgMTE1LjAycy0yLjU0NzMtMS4wNjcxLTIuOTc5LTIuNTY4M2MtMC40OTM5MS0xLjcxNzgtMC4yMDMyOS00LjUzNzYtMC4yMDMyOS00LjUzNzZsLTUuMTE1NC02LjI1MDNzLTAuNDUyMzYgNC43MDY5LTEuNzA4OCA2LjYwMDljLTEuMjIyNiAxLjg0My02LjE4IDMuMDgwOC02LjE4IDMuMDgwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Im0xNDIuNDUgODcuNzQ3IDE1LjYxMiAzLjE3OTZjMi41MDcyIDAuNTEwNjQgNC4xMTQ2IDIuOTQwMiAzLjYwNCA1LjQ0NzRsLTEwLjY3OSA1Mi40MzJjLTAuNTEwNjMgMi41MDcyLTIuOTA5MSAzLjI4MTktNS40NDc0IDMuNjA0bC0xNS42ODYgMS45OTAxYy0xLjIyMjggMC4xNTUxNCAwLjM0MDQzLTQuMDEyNS0wLjcxODI1LTYuMjE0NS0xLjEzOS0yLjM2OTItMS4zNzIyLTYuNDY3My0xLjEzMy03Ljc3MTdsOC45OTk2LTQ5LjA2M2MwLjQ2MTY1LTIuNTE2NyAyLjk0MDItNC4xMTQ2IDUuNDQ3NC0zLjYwNHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjIxMDkiLz48cGF0aCBkPSJtMTU5LjE1IDIxNi4xIDMuMzMxMS00My41NTUtMjIuMTg5LTMxLjM5NC04LjcyNiAzNi44OTItMjMuNzE2IDM4LjM4OSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjE2LjQ2NyIvPjxwYXRoIGQ9Im0xODYuNTEgMTIyLjM4cy0xMy41MTcgMC42NjY3MS0xOC4yMzUtMy4zMjE4Yy01LjY2MjQtNC43ODYzLTQuNjkxNC0xOC42MTEtNy41NzQ2LTIwLjkxMy00Ljk4NjMtMy45ODE2LTE4LjUzMy01LjYxNi0xOC41MzMtNS42MTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMC41OSIvPjwvZz48Y2lyY2xlIGN4PSIxNTkuNjkiIGN5PSI2OC45MTYiIHI9IjE3LjMiLz48cGF0aCBkPSJtMTgzLjEgMTA2Ljc5LTQuMDExOCAxMDUuNjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUuMDkzNCIvPjxwYXRoIGQ9Im0xMjcuMDggODUuMDk1IDMuODQ5NiAwLjk0MDc4YzQuMjg2IDEuMDQ3NCAzLjkxNzEgMy4zODYzIDIuOTc3MiA4LjM0NDNsLTcuMTg3NCAzNy45MTVjLTAuOTM5ODcgNC45NTgtNS4xNDcgOC4xMDYyLTkuNDMzIDcuMDU4OGwtMTIuNDUxLTMuMDQyN2MtNC4yODYtMS4wNDc0LTguMzkzNS02LjU0MjUtNi4wNC0xMC44NGwxOS41NTgtMzUuNzEzYzIuMzUzNC00LjI5NzYgNC40NDA2LTUuNzEwNCA4LjcyNjYtNC42NjN6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjcwNTMiLz48cGF0aCBkPSJtMTYwLjU4IDkxLjkxOHMtMy4xMTg2LTEuMzA2NS0zLjY0NzEtMy4xNDQzYy0wLjYwNDY5LTIuMTAzLTAuMjQ4ODktNS41NTUzLTAuMjQ4ODktNS41NTUzbC02LjI2MjgtNy42NTIxcy0wLjU1MzgyIDUuNzYyNy0yLjA5MjEgOC4wODE0Yy0xLjQ5NjggMi4yNTYzLTcuNTY2MSAzLjc3MTctNy41NjYxIDMuNzcxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,207,80,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="70" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="225,89,137,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="71" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNy45Nm1tIiBoZWlnaHQ9IjE0Ny4xOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTcuOTYgMTQ3LjE5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40OTIgLTczLjA0NikiPjxyZWN0IHg9IjQ1LjQ5MiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjEzNC4zMiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjY0Ljk5NiIgeT0iMTM0Ljc4IiB3aWR0aD0iODQuMDY2IiBoZWlnaHQ9IjIzLjcyMSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.00707" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="72" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS41OW1tIiBoZWlnaHQ9IjE2MS41OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuNTkgMTYxLjU5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xOS4xNTkgLTYxLjY3NSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC4wOTU0NTIgLS4wODA3MTEpIj48cmVjdCB4PSI2Mi4zNjEiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSIxMTguODQiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSI3NC43NjIiIHk9IjEzNS4wMSIgd2lkdGg9IjUzLjQ0OSIgaGVpZ2h0PSIxNS4wODEiLz48L2c+PGNpcmNsZSBjeD0iOTkuOTU2IiBjeT0iMTQyLjQ3IiByPSI3My4yMDIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMTUuMTkiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="73" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNS4xN21tIiBoZWlnaHQ9IjE1Ni42Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjUuMTcgMTU2LjY2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MC42MzcgLTc2LjA2OCkiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY0NThweCI+PHBhdGggZD0ibTEwNC4zNSA3Ni4xNjNzNS41MzM0IDkuNTA5OSA1LjU4NjcgMTQuNDg1YzAuMDUxMyA0Ljc4MzgtNC40MTYyIDguMjU5MS03LjkwMTYgMTEuMjIzLTEwLjMyNyA4Ljc4MTktMTkuNDY4IDE4LjQzNC0yMi4wMTkgMzAuNzkxLTEuOTI0OCA5LjMyNTYgMS42Mjk2IDE5LjQ4NyA2LjA1ODEgMjcuOTE3IDMuMzc0OSA2LjQyNCAxNC44OTkgMTUuODczIDE0Ljg5OSAxNS44NzNzMTIuNzQ2LTkuODI3OCAxNy4xMjgtMTYuNDFjNS4xNjkzLTcuNzY1MyA5LjI3MjUtMTYuODE5IDEwLjA2NC0yNi4xMTQgMS4xMzQ5LTEzLjMzLTEuMTM2Ni0yNy44MDUtNy44OTQyLTM5LjM1MS00LjEwNzctNy4wMTg1LTE1LjkyMS0xOC40MTUtMTUuOTIxLTE4LjQxNXoiLz48cGF0aCBkPSJtMTMzLjYgMTE1Ljg3czEuNzk5NSAyMS4wNzYtMS4yNzk4IDMwLjkyMmMtMy42MjkgMTEuNjAzLTE5LjUyNCAzMC44MDctMTkuNTI0IDMwLjgwN3MyNC40NDgtMi41ODI3IDMyLjIwNy0xMC44MzVjNi42MTczLTcuMDM4MiA5LjU4MjQtMTguNTQ1IDcuNTMxNi0yNy45ODYtMi4xMDMtOS42ODExLTE4LjkzNS0yMi45MDgtMTguOTM1LTIyLjkwOHoiLz48cGF0aCBkPSJtNzMuNzg4IDEyMS43cy0wLjg4MjU5IDguNzAyNi0zLjY1MDQgMTEuNzE0Yy02LjI2MjIgNi44MTIyLTExLjQ2NiAxNC45MzEtMTAuOTY5IDIzLjU4OSAwLjM3ODMyIDYuNTk2NCA0Ljg3MjYgMTMuMjE3IDEwLjM1OCAxNi45IDQuMTMzNCAyLjc3NTIgOS43NzI0IDIuNzE0OSAxNC43NDEgMi40MDMyIDQuMTEyLTAuMjU3ODggOC40NTAyIDEuMDkyNiA4LjQ1MDIgMS4wOTI2cy0xNC4wMS0xMC45MzUtMTcuMjg4LTE4Ljc4OWMtMy40OC04LjMzNjItMy4xNTg2LTE3LjQwNC0xLjI3NjMtMjcuMDcgMC42MjczLTMuMjIxNC0wLjM2NTM5LTkuODM4OC0wLjM2NTM5LTkuODM4OHoiLz48cGF0aCBkPSJtNDAuODIzIDIxOS42NiAxMDkuNTItNDIuMjE1IDUuNjkwOCA5LjE5MDEtMTA4LjUgNDUuOTJ6Ii8+PHBhdGggZD0ibTE2NS42MiAyMTkuMzgtMTA5LjUyLTQyLjIxNS01LjY5MDggOS4xOTAxIDEwOC41IDQ1LjkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.15476" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="74" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMC4wOW1tIiBoZWlnaHQ9IjE1OS41M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjAuMDkgMTU5LjUzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC41MjUgLTY3LjA4NykiPjxyZWN0IHg9IjQ0LjUyNSIgeT0iMjE2LjAzIiB3aWR0aD0iMTIwLjA5IiBoZWlnaHQ9IjEwLjU4Ii8+PHJlY3QgeD0iNzAuMTM3IiB5PSIxNjcuMjIiIHdpZHRoPSI2OC44NjciIGhlaWdodD0iNTAuMjY4Ii8+PHBhdGggdHJhbnNmb3JtPSJtYXRyaXgoLjk0NDMgMCAwIC42MzM2NSAxMC45NTUgNzcuMDM5KSIgZD0ibTE1Mi44MiAxNDcuMDdoLTEwNy4zN2w1My42ODUtOTIuOTg1eiIvPjxwYXRoIGQ9Im0xMDAuNjIgMTE4LjQ4di01MS4xODJsMzUuNjAzIDE2LjM3M3YyNS43NjhsLTI3LjA0My0xNS4xNHYyNy41NzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.76387" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="75" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk1Ljc3NG1tIiBoZWlnaHQ9IjE2Ni4zM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5NS43NzQgMTY2LjMzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi42NjQgLTY2LjAwNSkiPjxyZWN0IHRyYW5zZm9ybT0ibWF0cml4KC41MjM1NCAtLjg1MiAuODg1NDggLjQ2NDY4IDAgMCkiIHg9Ii04Ny40ODciIHk9IjEyMi40MyIgd2lkdGg9IjU3Ljk0MiIgaGVpZ2h0PSIxMC4xNCIvPjxjaXJjbGUgY3g9IjExOC45NCIgY3k9IjgwLjQ2IiByPSIxNC40NTUiLz48cGF0aCBkPSJtMTEwLjI4IDg0LjcwNXMtMjQuMjg1IDI5LjM5Mi0zMC45MTcgNDYuOTA1Yy0yLjgxMDMgNy40MjA5LTEuMzUxMyAxNS44ODktMy4zNTEyIDIzLjU2OC0yLjY2MDYgMTAuMjE2LTkuOTQwNiAyNi42NzUtMTQuMTg2IDM1LjE0Ni00LjY5MTkgOS4zNjItNS41NDAyIDEzLjc1MS04LjYyMjkgMjMuOTU1LTAuOTkxNTggMy4yODIyLTAuMjEyNCA4Ljg5NCAzLjA5MTUgOS44MTA2IDguMTAzNiAyLjI0OCAxNy41MTggMy40NTExIDE5LjY4OCAyLjMzODUgMS44MjM4LTAuOTM0ODQgMS43MTk5LTQuMjU2IDAuMjgyNzYtNS43Njg4LTEuNzIyMi0xLjgxMjctNi4wNDYxLTAuNzM3NjEtNy4wMjA4LTMuMTAzNC0xLjYwMjQtMy44ODk1LTAuNTg4Mi03LjUxOTIgMC40OTQ1NC0xMS40NCAyLjE3NDUtNy44NzUyIDcuODQ4OS0xMi4yMDQgMTIuMjM4LTIxLjU3MSAzLjc2ODQtOC4wNDIzIDcuNjA0OC0xNS4yNDQgMTAuNTUtMTUuMjQ0IDIuNDQ5OSAwIDYuODk3NyA4LjI1MjIgOS41OTA2IDEzLjA3MSAzLjY3ODMgNi41ODI3IDcuNzcgMTUuNTExIDguOTEzNyAyMy43ODIgMS40MzU5IDEwLjM4NSAxLjEwNDIgMTcuNzcgNi4wOTkzIDIzLjQxMSAyLjEwOTIgMi4zODE2IDcuNTgzNyAyLjE0NjQgMTIuODkyIDIuMjk2NiA0LjkzMTYgMC4xMzk1NCA4LjU2MjUgMS4wNzE0IDExLjE4Ny0wLjkzMjgxIDIuMzMxMS0xLjc4MDMtMS4xOTg2LTUuNjc3OS00LjA1NTQtNi42NjkyLTMuNDAxNS0xLjE4MDMtMTEuMTI5LTIuNTY3LTExLjg4NS02LjU1Ni0yLjE3MDYtMTEuNDUzLTMuMzAxNC0yMS4zOTEtNi45OTU5LTMxLjQ4OS0yLjgyOS03LjczMjItNy42NjQtMTQuMjQ1LTExLjQ2OS0yMS44NzYtMy4yNjgyLTYuNTU0NC00LjgxNzUtMTQuMjQ1LTIuOTQyMy0yNS40NiAwLjQ3NDU0LTIuODM3OSAxLjc5NTgtNi44NDU4IDUuNjE4My02LjU1MzIgMy43MjYzIDAuMjg1MjUgMTEuODgyIDYuNTI4NSAxNi41NzIgOS42Nzc3IDguNzM0MiA1Ljg2NDUgMTMuNzc1IDEwLjAxMSAxMy43NzUgMTAuMDExczUuMzU3IDIuMDkxOCA3LjEwMzUgMC40ODQ3YzEuMzM1Ni0xLjIyOSAyLjI0ODQtMi44MTk4IDAuMDgxMi01LjQ0NDQtMy44NDg2LTQuNjYwOC0xNy43NTQtMTIuNjYtMjMuMzk4LTE2LjMzMi0yLjgyNTgtMS44Mzc4LTQuNDY4OS0yLjEwNTUtNC42NzE5LTUuNjIyMi0wLjI1NDE1LTQuNDAzMyAwLTExLjIzMSAwLTE1Ljk5OHYtMjEuNTEyeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PHBhdGggZD0ibTEzOS45NyAxNDQuNjRzLTM0Ljk4NCA1Ni4wODgtNDkuMTExIDc5Ljc4M2MtMC44NjgzNyAxLjQ1NjUtMC4wNDEzOSA0LjExODEgMS40Nzk5IDQuODY3MSAxLjU3OCAwLjc3Njk1IDIuODgzMyAwLjQwNzM4IDQuOTM3NC0xLjg2MTggMi44ODkxLTMuMTkxNiA0OC41My03OC4xOTQgNDguNTMtNzguMTk0eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.10936" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="76" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3MC40NW1tIiBoZWlnaHQ9IjE3My43OG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzAuNDUgMTczLjc4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMS4zNTUgLTUxLjYxNykiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyOC41IC44OTA1NCkiPjxnIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0ibS0yNzAuOTIgMTExLjYxIDEyLjc1MiAyLjU5NzFjMi4wNDc5IDAuNDE3MDkgMy4zNjA4IDIuNDAxNSAyLjk0MzcgNC40NDk0bC04LjcyMjMgNDIuODI3Yy0wLjQxNzA4IDIuMDQ3OS0yLjM3NjEgMi42ODA3LTQuNDQ5NCAyLjk0MzdsLTEyLjgxMiAxLjYyNTZjLTAuOTk4NzQgMC4xMjY3MiAwLjI3ODA2LTMuMjc3NC0wLjU4NjY3LTUuMDc2LTAuOTMwMzctMS45MzUyLTEuMTIwOC01LjI4MjUtMC45MjU0Mi02LjM0NzlsNy4zNTA5LTQwLjA3NWMwLjM3NzA3LTIuMDU1NiAyLjQwMTUtMy4zNjA4IDQuNDQ5NC0yLjk0Mzd6IiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi42MjI2Ii8+PHBhdGggZD0ibS0yNTcuMjggMjE2LjQ2IDIuNzIwOC0zNS41NzYtMTguMTI0LTI1LjY0Mi03LjEyNzQgMzAuMTM0LTE5LjM3MSAzMS4zNTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMy40NSIvPjxwYXRoIGQ9Im0tMjM0LjkzIDEzOS45cy0xMS4wNCAwLjU0NDU3LTE0Ljg5NC0yLjcxMzJjLTQuNjI1MS0zLjkwOTUtMy44MzItMTUuMjAyLTYuMTg2OS0xNy4wODItNC4wNzI4LTMuMjUyMi0xNS4xMzgtNC41ODcyLTE1LjEzOC00LjU4NzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI4LjY1Ii8+PC9nPjxjaXJjbGUgY3g9Ii0yNTYuODQiIGN5PSI5Ni4yMzQiIHI9IjE0LjEzIi8+PHBhdGggZD0ibS0yMzYuNjUgMTIzLjEzLTMuNzQxNCA5OC41MzkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQuNzUiLz48cGF0aCBkPSJtLTI4My40OCAxMDkuNDUgMy4xNDQ0IDAuNzY4NDNjMy41MDA4IDAuODU1NTMgMy4xOTk1IDIuNzY2IDIuNDMxOCA2LjgxNTZsLTUuODcwNyAzMC45NjljLTAuNzY3NjggNC4wNDk3LTQuMjA0MSA2LjYyMTItNy43MDQ5IDUuNzY1NmwtMTAuMTctMi40ODUzYy0zLjUwMDgtMC44NTU1NC02Ljg1NTgtNS4zNDQtNC45MzM1LTguODU0MmwxNS45NzUtMjkuMTcxYzEuOTIyMy0zLjUxMDMgMy42MjcxLTQuNjY0MyA3LjEyNzktMy44MDg3eiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMy4wMjY1Ii8+PHBhdGggZD0ibS0yNTYuMTIgMTE1LjAycy0yLjU0NzMtMS4wNjcxLTIuOTc5LTIuNTY4M2MtMC40OTM5MS0xLjcxNzgtMC4yMDMyOS00LjUzNzYtMC4yMDMyOS00LjUzNzZsLTUuMTE1NC02LjI1MDNzLTAuNDUyMzYgNC43MDY5LTEuNzA4OCA2LjYwMDljLTEuMjIyNiAxLjg0My02LjE4IDMuMDgwOC02LjE4IDMuMDgwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Im0xNDIuNDUgODcuNzQ3IDE1LjYxMiAzLjE3OTZjMi41MDcyIDAuNTEwNjQgNC4xMTQ2IDIuOTQwMiAzLjYwNCA1LjQ0NzRsLTEwLjY3OSA1Mi40MzJjLTAuNTEwNjMgMi41MDcyLTIuOTA5MSAzLjI4MTktNS40NDc0IDMuNjA0bC0xNS42ODYgMS45OTAxYy0xLjIyMjggMC4xNTUxNCAwLjM0MDQzLTQuMDEyNS0wLjcxODI1LTYuMjE0NS0xLjEzOS0yLjM2OTItMS4zNzIyLTYuNDY3My0xLjEzMy03Ljc3MTdsOC45OTk2LTQ5LjA2M2MwLjQ2MTY1LTIuNTE2NyAyLjk0MDItNC4xMTQ2IDUuNDQ3NC0zLjYwNHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjIxMDkiLz48cGF0aCBkPSJtMTU5LjE1IDIxNi4xIDMuMzMxMS00My41NTUtMjIuMTg5LTMxLjM5NC04LjcyNiAzNi44OTItMjMuNzE2IDM4LjM4OSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjE2LjQ2NyIvPjxwYXRoIGQ9Im0xODYuNTEgMTIyLjM4cy0xMy41MTcgMC42NjY3MS0xOC4yMzUtMy4zMjE4Yy01LjY2MjQtNC43ODYzLTQuNjkxNC0xOC42MTEtNy41NzQ2LTIwLjkxMy00Ljk4NjMtMy45ODE2LTE4LjUzMy01LjYxNi0xOC41MzMtNS42MTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMC41OSIvPjwvZz48Y2lyY2xlIGN4PSIxNTkuNjkiIGN5PSI2OC45MTYiIHI9IjE3LjMiLz48cGF0aCBkPSJtMTgzLjEgMTA2Ljc5LTQuMDExOCAxMDUuNjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUuMDkzNCIvPjxwYXRoIGQ9Im0xMjcuMDggODUuMDk1IDMuODQ5NiAwLjk0MDc4YzQuMjg2IDEuMDQ3NCAzLjkxNzEgMy4zODYzIDIuOTc3MiA4LjM0NDNsLTcuMTg3NCAzNy45MTVjLTAuOTM5ODcgNC45NTgtNS4xNDcgOC4xMDYyLTkuNDMzIDcuMDU4OGwtMTIuNDUxLTMuMDQyN2MtNC4yODYtMS4wNDc0LTguMzkzNS02LjU0MjUtNi4wNC0xMC44NGwxOS41NTgtMzUuNzEzYzIuMzUzNC00LjI5NzYgNC40NDA2LTUuNzEwNCA4LjcyNjYtNC42NjN6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjcwNTMiLz48cGF0aCBkPSJtMTYwLjU4IDkxLjkxOHMtMy4xMTg2LTEuMzA2NS0zLjY0NzEtMy4xNDQzYy0wLjYwNDY5LTIuMTAzLTAuMjQ4ODktNS41NTUzLTAuMjQ4ODktNS41NTUzbC02LjI2MjgtNy42NTIxcy0wLjU1MzgyIDUuNzYyNy0yLjA5MjEgOC4wODE0Yy0xLjQ5NjggMi4yNTYzLTcuNTY2MSAzLjc3MTctNy41NjYxIDMuNzcxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="77" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="229,182,54,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="78" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,255,255,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNy45Nm1tIiBoZWlnaHQ9IjE0Ny4xOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTcuOTYgMTQ3LjE5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40OTIgLTczLjA0NikiPjxyZWN0IHg9IjQ1LjQ5MiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjEzNC4zMiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjY0Ljk5NiIgeT0iMTM0Ljc4IiB3aWR0aD0iODQuMDY2IiBoZWlnaHQ9IjIzLjcyMSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.00707" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="79" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS41OW1tIiBoZWlnaHQ9IjE2MS41OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuNTkgMTYxLjU5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xOS4xNTkgLTYxLjY3NSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC4wOTU0NTIgLS4wODA3MTEpIj48cmVjdCB4PSI2Mi4zNjEiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSIxMTguODQiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSI3NC43NjIiIHk9IjEzNS4wMSIgd2lkdGg9IjUzLjQ0OSIgaGVpZ2h0PSIxNS4wODEiLz48L2c+PGNpcmNsZSBjeD0iOTkuOTU2IiBjeT0iMTQyLjQ3IiByPSI3My4yMDIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMTUuMTkiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExNy45Nm1tIiBoZWlnaHQ9IjE0Ny4xOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTcuOTYgMTQ3LjE5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NS40OTIgLTczLjA0NikiPjxyZWN0IHg9IjQ1LjQ5MiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjEzNC4zMiIgeT0iNzMuMDQ2IiB3aWR0aD0iMjkuMTMzIiBoZWlnaHQ9IjE0Ny4xOSIvPjxyZWN0IHg9IjY0Ljk5NiIgeT0iMTM0Ljc4IiB3aWR0aD0iODQuMDY2IiBoZWlnaHQ9IjIzLjcyMSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.00707" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="80" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNS4xN21tIiBoZWlnaHQ9IjE1Ni42Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjUuMTcgMTU2LjY2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MC42MzcgLTc2LjA2OCkiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY0NThweCI+PHBhdGggZD0ibTEwNC4zNSA3Ni4xNjNzNS41MzM0IDkuNTA5OSA1LjU4NjcgMTQuNDg1YzAuMDUxMyA0Ljc4MzgtNC40MTYyIDguMjU5MS03LjkwMTYgMTEuMjIzLTEwLjMyNyA4Ljc4MTktMTkuNDY4IDE4LjQzNC0yMi4wMTkgMzAuNzkxLTEuOTI0OCA5LjMyNTYgMS42Mjk2IDE5LjQ4NyA2LjA1ODEgMjcuOTE3IDMuMzc0OSA2LjQyNCAxNC44OTkgMTUuODczIDE0Ljg5OSAxNS44NzNzMTIuNzQ2LTkuODI3OCAxNy4xMjgtMTYuNDFjNS4xNjkzLTcuNzY1MyA5LjI3MjUtMTYuODE5IDEwLjA2NC0yNi4xMTQgMS4xMzQ5LTEzLjMzLTEuMTM2Ni0yNy44MDUtNy44OTQyLTM5LjM1MS00LjEwNzctNy4wMTg1LTE1LjkyMS0xOC40MTUtMTUuOTIxLTE4LjQxNXoiLz48cGF0aCBkPSJtMTMzLjYgMTE1Ljg3czEuNzk5NSAyMS4wNzYtMS4yNzk4IDMwLjkyMmMtMy42MjkgMTEuNjAzLTE5LjUyNCAzMC44MDctMTkuNTI0IDMwLjgwN3MyNC40NDgtMi41ODI3IDMyLjIwNy0xMC44MzVjNi42MTczLTcuMDM4MiA5LjU4MjQtMTguNTQ1IDcuNTMxNi0yNy45ODYtMi4xMDMtOS42ODExLTE4LjkzNS0yMi45MDgtMTguOTM1LTIyLjkwOHoiLz48cGF0aCBkPSJtNzMuNzg4IDEyMS43cy0wLjg4MjU5IDguNzAyNi0zLjY1MDQgMTEuNzE0Yy02LjI2MjIgNi44MTIyLTExLjQ2NiAxNC45MzEtMTAuOTY5IDIzLjU4OSAwLjM3ODMyIDYuNTk2NCA0Ljg3MjYgMTMuMjE3IDEwLjM1OCAxNi45IDQuMTMzNCAyLjc3NTIgOS43NzI0IDIuNzE0OSAxNC43NDEgMi40MDMyIDQuMTEyLTAuMjU3ODggOC40NTAyIDEuMDkyNiA4LjQ1MDIgMS4wOTI2cy0xNC4wMS0xMC45MzUtMTcuMjg4LTE4Ljc4OWMtMy40OC04LjMzNjItMy4xNTg2LTE3LjQwNC0xLjI3NjMtMjcuMDcgMC42MjczLTMuMjIxNC0wLjM2NTM5LTkuODM4OC0wLjM2NTM5LTkuODM4OHoiLz48cGF0aCBkPSJtNDAuODIzIDIxOS42NiAxMDkuNTItNDIuMjE1IDUuNjkwOCA5LjE5MDEtMTA4LjUgNDUuOTJ6Ii8+PHBhdGggZD0ibTE2NS42MiAyMTkuMzgtMTA5LjUyLTQyLjIxNS01LjY5MDggOS4xOTAxIDEwOC41IDQ1LjkyeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.15476" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="81" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMC4wOW1tIiBoZWlnaHQ9IjE1OS41M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjAuMDkgMTU5LjUzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC41MjUgLTY3LjA4NykiPjxyZWN0IHg9IjQ0LjUyNSIgeT0iMjE2LjAzIiB3aWR0aD0iMTIwLjA5IiBoZWlnaHQ9IjEwLjU4Ii8+PHJlY3QgeD0iNzAuMTM3IiB5PSIxNjcuMjIiIHdpZHRoPSI2OC44NjciIGhlaWdodD0iNTAuMjY4Ii8+PHBhdGggdHJhbnNmb3JtPSJtYXRyaXgoLjk0NDMgMCAwIC42MzM2NSAxMC45NTUgNzcuMDM5KSIgZD0ibTE1Mi44MiAxNDcuMDdoLTEwNy4zN2w1My42ODUtOTIuOTg1eiIvPjxwYXRoIGQ9Im0xMDAuNjIgMTE4LjQ4di01MS4xODJsMzUuNjAzIDE2LjM3M3YyNS43NjhsLTI3LjA0My0xNS4xNHYyNy41NzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.76387" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="82" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk1Ljc3NG1tIiBoZWlnaHQ9IjE2Ni4zM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5NS43NzQgMTY2LjMzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01Mi42NjQgLTY2LjAwNSkiPjxyZWN0IHRyYW5zZm9ybT0ibWF0cml4KC41MjM1NCAtLjg1MiAuODg1NDggLjQ2NDY4IDAgMCkiIHg9Ii04Ny40ODciIHk9IjEyMi40MyIgd2lkdGg9IjU3Ljk0MiIgaGVpZ2h0PSIxMC4xNCIvPjxjaXJjbGUgY3g9IjExOC45NCIgY3k9IjgwLjQ2IiByPSIxNC40NTUiLz48cGF0aCBkPSJtMTEwLjI4IDg0LjcwNXMtMjQuMjg1IDI5LjM5Mi0zMC45MTcgNDYuOTA1Yy0yLjgxMDMgNy40MjA5LTEuMzUxMyAxNS44ODktMy4zNTEyIDIzLjU2OC0yLjY2MDYgMTAuMjE2LTkuOTQwNiAyNi42NzUtMTQuMTg2IDM1LjE0Ni00LjY5MTkgOS4zNjItNS41NDAyIDEzLjc1MS04LjYyMjkgMjMuOTU1LTAuOTkxNTggMy4yODIyLTAuMjEyNCA4Ljg5NCAzLjA5MTUgOS44MTA2IDguMTAzNiAyLjI0OCAxNy41MTggMy40NTExIDE5LjY4OCAyLjMzODUgMS44MjM4LTAuOTM0ODQgMS43MTk5LTQuMjU2IDAuMjgyNzYtNS43Njg4LTEuNzIyMi0xLjgxMjctNi4wNDYxLTAuNzM3NjEtNy4wMjA4LTMuMTAzNC0xLjYwMjQtMy44ODk1LTAuNTg4Mi03LjUxOTIgMC40OTQ1NC0xMS40NCAyLjE3NDUtNy44NzUyIDcuODQ4OS0xMi4yMDQgMTIuMjM4LTIxLjU3MSAzLjc2ODQtOC4wNDIzIDcuNjA0OC0xNS4yNDQgMTAuNTUtMTUuMjQ0IDIuNDQ5OSAwIDYuODk3NyA4LjI1MjIgOS41OTA2IDEzLjA3MSAzLjY3ODMgNi41ODI3IDcuNzcgMTUuNTExIDguOTEzNyAyMy43ODIgMS40MzU5IDEwLjM4NSAxLjEwNDIgMTcuNzcgNi4wOTkzIDIzLjQxMSAyLjEwOTIgMi4zODE2IDcuNTgzNyAyLjE0NjQgMTIuODkyIDIuMjk2NiA0LjkzMTYgMC4xMzk1NCA4LjU2MjUgMS4wNzE0IDExLjE4Ny0wLjkzMjgxIDIuMzMxMS0xLjc4MDMtMS4xOTg2LTUuNjc3OS00LjA1NTQtNi42NjkyLTMuNDAxNS0xLjE4MDMtMTEuMTI5LTIuNTY3LTExLjg4NS02LjU1Ni0yLjE3MDYtMTEuNDUzLTMuMzAxNC0yMS4zOTEtNi45OTU5LTMxLjQ4OS0yLjgyOS03LjczMjItNy42NjQtMTQuMjQ1LTExLjQ2OS0yMS44NzYtMy4yNjgyLTYuNTU0NC00LjgxNzUtMTQuMjQ1LTIuOTQyMy0yNS40NiAwLjQ3NDU0LTIuODM3OSAxLjc5NTgtNi44NDU4IDUuNjE4My02LjU1MzIgMy43MjYzIDAuMjg1MjUgMTEuODgyIDYuNTI4NSAxNi41NzIgOS42Nzc3IDguNzM0MiA1Ljg2NDUgMTMuNzc1IDEwLjAxMSAxMy43NzUgMTAuMDExczUuMzU3IDIuMDkxOCA3LjEwMzUgMC40ODQ3YzEuMzM1Ni0xLjIyOSAyLjI0ODQtMi44MTk4IDAuMDgxMi01LjQ0NDQtMy44NDg2LTQuNjYwOC0xNy43NTQtMTIuNjYtMjMuMzk4LTE2LjMzMi0yLjgyNTgtMS44Mzc4LTQuNDY4OS0yLjEwNTUtNC42NzE5LTUuNjIyMi0wLjI1NDE1LTQuNDAzMyAwLTExLjIzMSAwLTE1Ljk5OHYtMjEuNTEyeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PHBhdGggZD0ibTEzOS45NyAxNDQuNjRzLTM0Ljk4NCA1Ni4wODgtNDkuMTExIDc5Ljc4M2MtMC44NjgzNyAxLjQ1NjUtMC4wNDEzOSA0LjExODEgMS40Nzk5IDQuODY3MSAxLjU3OCAwLjc3Njk1IDIuODgzMyAwLjQwNzM4IDQuOTM3NC0xLjg2MTggMi44ODkxLTMuMTkxNiA0OC41My03OC4xOTQgNDguNTMtNzguMTk0eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii4yNjQ1OHB4Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.10936" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="83" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3MC40NW1tIiBoZWlnaHQ9IjE3My43OG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNzAuNDUgMTczLjc4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMS4zNTUgLTUxLjYxNykiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyOC41IC44OTA1NCkiPjxnIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0ibS0yNzAuOTIgMTExLjYxIDEyLjc1MiAyLjU5NzFjMi4wNDc5IDAuNDE3MDkgMy4zNjA4IDIuNDAxNSAyLjk0MzcgNC40NDk0bC04LjcyMjMgNDIuODI3Yy0wLjQxNzA4IDIuMDQ3OS0yLjM3NjEgMi42ODA3LTQuNDQ5NCAyLjk0MzdsLTEyLjgxMiAxLjYyNTZjLTAuOTk4NzQgMC4xMjY3MiAwLjI3ODA2LTMuMjc3NC0wLjU4NjY3LTUuMDc2LTAuOTMwMzctMS45MzUyLTEuMTIwOC01LjI4MjUtMC45MjU0Mi02LjM0NzlsNy4zNTA5LTQwLjA3NWMwLjM3NzA3LTIuMDU1NiAyLjQwMTUtMy4zNjA4IDQuNDQ5NC0yLjk0Mzd6IiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi42MjI2Ii8+PHBhdGggZD0ibS0yNTcuMjggMjE2LjQ2IDIuNzIwOC0zNS41NzYtMTguMTI0LTI1LjY0Mi03LjEyNzQgMzAuMTM0LTE5LjM3MSAzMS4zNTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMy40NSIvPjxwYXRoIGQ9Im0tMjM0LjkzIDEzOS45cy0xMS4wNCAwLjU0NDU3LTE0Ljg5NC0yLjcxMzJjLTQuNjI1MS0zLjkwOTUtMy44MzItMTUuMjAyLTYuMTg2OS0xNy4wODItNC4wNzI4LTMuMjUyMi0xNS4xMzgtNC41ODcyLTE1LjEzOC00LjU4NzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI4LjY1Ii8+PC9nPjxjaXJjbGUgY3g9Ii0yNTYuODQiIGN5PSI5Ni4yMzQiIHI9IjE0LjEzIi8+PHBhdGggZD0ibS0yMzYuNjUgMTIzLjEzLTMuNzQxNCA5OC41MzkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQuNzUiLz48cGF0aCBkPSJtLTI4My40OCAxMDkuNDUgMy4xNDQ0IDAuNzY4NDNjMy41MDA4IDAuODU1NTMgMy4xOTk1IDIuNzY2IDIuNDMxOCA2LjgxNTZsLTUuODcwNyAzMC45NjljLTAuNzY3NjggNC4wNDk3LTQuMjA0MSA2LjYyMTItNy43MDQ5IDUuNzY1NmwtMTAuMTctMi40ODUzYy0zLjUwMDgtMC44NTU1NC02Ljg1NTgtNS4zNDQtNC45MzM1LTguODU0MmwxNS45NzUtMjkuMTcxYzEuOTIyMy0zLjUxMDMgMy42MjcxLTQuNjY0MyA3LjEyNzktMy44MDg3eiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMy4wMjY1Ii8+PHBhdGggZD0ibS0yNTYuMTIgMTE1LjAycy0yLjU0NzMtMS4wNjcxLTIuOTc5LTIuNTY4M2MtMC40OTM5MS0xLjcxNzgtMC4yMDMyOS00LjUzNzYtMC4yMDMyOS00LjUzNzZsLTUuMTE1NC02LjI1MDNzLTAuNDUyMzYgNC43MDY5LTEuNzA4OCA2LjYwMDljLTEuMjIyNiAxLjg0My02LjE4IDMuMDgwOC02LjE4IDMuMDgwOCIvPjwvZz48ZyBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Im0xNDIuNDUgODcuNzQ3IDE1LjYxMiAzLjE3OTZjMi41MDcyIDAuNTEwNjQgNC4xMTQ2IDIuOTQwMiAzLjYwNCA1LjQ0NzRsLTEwLjY3OSA1Mi40MzJjLTAuNTEwNjMgMi41MDcyLTIuOTA5MSAzLjI4MTktNS40NDc0IDMuNjA0bC0xNS42ODYgMS45OTAxYy0xLjIyMjggMC4xNTUxNCAwLjM0MDQzLTQuMDEyNS0wLjcxODI1LTYuMjE0NS0xLjEzOS0yLjM2OTItMS4zNzIyLTYuNDY3My0xLjEzMy03Ljc3MTdsOC45OTk2LTQ5LjA2M2MwLjQ2MTY1LTIuNTE2NyAyLjk0MDItNC4xMTQ2IDUuNDQ3NC0zLjYwNHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjIxMDkiLz48cGF0aCBkPSJtMTU5LjE1IDIxNi4xIDMuMzMxMS00My41NTUtMjIuMTg5LTMxLjM5NC04LjcyNiAzNi44OTItMjMuNzE2IDM4LjM4OSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjE2LjQ2NyIvPjxwYXRoIGQ9Im0xODYuNTEgMTIyLjM4cy0xMy41MTcgMC42NjY3MS0xOC4yMzUtMy4zMjE4Yy01LjY2MjQtNC43ODYzLTQuNjkxNC0xOC42MTEtNy41NzQ2LTIwLjkxMy00Ljk4NjMtMy45ODE2LTE4LjUzMy01LjYxNi0xOC41MzMtNS42MTYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxMC41OSIvPjwvZz48Y2lyY2xlIGN4PSIxNTkuNjkiIGN5PSI2OC45MTYiIHI9IjE3LjMiLz48cGF0aCBkPSJtMTgzLjEgMTA2Ljc5LTQuMDExOCAxMDUuNjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUuMDkzNCIvPjxwYXRoIGQ9Im0xMjcuMDggODUuMDk1IDMuODQ5NiAwLjk0MDc4YzQuMjg2IDEuMDQ3NCAzLjkxNzEgMy4zODYzIDIuOTc3MiA4LjM0NDNsLTcuMTg3NCAzNy45MTVjLTAuOTM5ODcgNC45NTgtNS4xNDcgOC4xMDYyLTkuNDMzIDcuMDU4OGwtMTIuNDUxLTMuMDQyN2MtNC4yODYtMS4wNDc0LTguMzkzNS02LjU0MjUtNi4wNC0xMC44NGwxOS41NTgtMzUuNzEzYzIuMzUzNC00LjI5NzYgNC40NDA2LTUuNzEwNCA4LjcyNjYtNC42NjN6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIzLjcwNTMiLz48cGF0aCBkPSJtMTYwLjU4IDkxLjkxOHMtMy4xMTg2LTEuMzA2NS0zLjY0NzEtMy4xNDQzYy0wLjYwNDY5LTIuMTAzLTAuMjQ4ODktNS41NTUzLTAuMjQ4ODktNS41NTUzbC02LjI2MjgtNy42NTIxcy0wLjU1MzgyIDUuNzYyNy0yLjA5MjEgOC4wODE0Yy0xLjQ5NjggMi4yNTYzLTcuNTY2MSAzLjc3MTctNy41NjYxIDMuNzcxNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MS41OW1tIiBoZWlnaHQ9IjE2MS41OW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjEuNTkgMTYxLjU5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xOS4xNTkgLTYxLjY3NSkiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC4wOTU0NTIgLS4wODA3MTEpIj48cmVjdCB4PSI2Mi4zNjEiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSIxMTguODQiIHk9Ijk1Ljc2MiIgd2lkdGg9IjE4LjUyMyIgaGVpZ2h0PSI5My41ODIiLz48cmVjdCB4PSI3NC43NjIiIHk9IjEzNS4wMSIgd2lkdGg9IjUzLjQ0OSIgaGVpZ2h0PSIxNS4wODEiLz48L2c+PGNpcmNsZSBjeD0iOTkuOTU2IiBjeT0iMTQyLjQ3IiByPSI3My4yMDIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMTUuMTkiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Гостиницы и аналогичные коллективные средства размещения" value="602010601" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Специализированные коллективные средства размещения" value="602010602" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Детский оздоровительный лагерь" value="602010603" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Оздоровительно-спортивный лагерь" value="602010604" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты физкультурно-досугового назначения и активного отдыха" value="602010605" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Места и объекты массового посещения, в том числе тематический туризм" value="602010607" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="HOT_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Туристская гостиница" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Коммунальная гостиница" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Мотель" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Пансионат" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Общежитие для приезжих, хостел" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иная организация гостиничного типа" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SAF_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Дом отдыха" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="База отдыха" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Кемпинг" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Другая организация отдыха (кроме турбаз)" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Туристская база" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Наземный и водный транспорт, переоборудованный под средства размещения для ночлега, включая дебаркадеры" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Пансионат с лечением" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Курортный отель" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной объект" value="9" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CHI_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Загородный оздоровительный лагерь" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Санаторно-оздоровительный лагерь" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Оздоровительный лагерь с дневным пребыванием" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Лагерь труда и отдыха" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Палаточный лагерь" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Здание спортивного лагеря" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной объект" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="AL_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Центр (комплекс) конного туризма" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Лодочная станция" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Аквапарк" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Дом рыбака и охотника (база, комплекс и другое)" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Визит-центр особо охраняемой природной территории" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Танцевальные залы" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Аттракционы и иные подобные объекты" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной объект" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="TEM_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Культура" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Природа" value="10" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Развлечения" value="11" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Сельский отдых" value="12" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Театры" value="13" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Традиции" value="14" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Места воинской славы" value="15" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Активный отдых" value="16" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Детский отдых" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Гастрономический туризм" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Святыни и храмы" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Музеи" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Необычные места" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Охота и рыбалка" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Оздоровительный туризм" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Пляжный отдых" value="9" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CAPACITY" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="PERSON_PD" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ONE_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="BOAT_COUNT" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SEAT_COUNT" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SEASON" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Круглогодичный" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="более 6 месяцев" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="4 - 6 месяцев" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="до 3 месяцев" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="WRK_COUNT" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FUNCTION" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к ликвидации" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTROKS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTRZU" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAMEDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="DATEDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBERDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="HOT_STYPE" index="6" name=""/>
    <alias field="SAF_STYPE" index="7" name=""/>
    <alias field="CHI_STYPE" index="8" name=""/>
    <alias field="AL_STYPE" index="9" name=""/>
    <alias field="TEM_TYPE" index="10" name=""/>
    <alias field="CAPACITY" index="11" name=""/>
    <alias field="PERSON_PD" index="12" name=""/>
    <alias field="ONE_TIME" index="13" name=""/>
    <alias field="BOAT_COUNT" index="14" name=""/>
    <alias field="SEAT_COUNT" index="15" name=""/>
    <alias field="SEASON" index="16" name="Продолжительность работы"/>
    <alias field="WRK_COUNT" index="17" name="Количество рабочих мест, единиц"/>
    <alias field="FUNCTION" index="18" name="Назначение объекта"/>
    <alias field="EVENT_TIME" index="19" name=""/>
    <alias field="SOURCE" index="20" name="Источник данных"/>
    <alias field="NOTE" index="21" name="Примечание"/>
    <alias field="STATUS" index="22" name="Статус объекта"/>
    <alias field="REG_STATUS" index="23" name="Значение объекта"/>
    <alias field="KADASTROKS" index="24" name="Кадастровый номер объекта капитального строительства"/>
    <alias field="KADASTRZU" index="25" name=""/>
    <alias field="NAMEDOCOSN" index="26" name=""/>
    <alias field="DATEDOCOSN" index="27" name=""/>
    <alias field="NUMBERDOCOSN" index="28" name=""/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602010601'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="HOT_STYPE" expression="if(&quot;CLASSID&quot; = '602010601', attribute('HOT_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="SAF_STYPE" expression="if(&quot;CLASSID&quot; = '602010602', attribute('SAF_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="CHI_STYPE" expression="if(&quot;CLASSID&quot; = '602010603', attribute('CHI_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="AL_STYPE" expression="if(&quot;CLASSID&quot; = '602010605', attribute('AL_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="TEM_TYPE" expression="if(&quot;CLASSID&quot; = '602010607', attribute('TEM_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="CAPACITY" expression="0" applyOnUpdate="0"/>
    <default field="PERSON_PD" expression="0" applyOnUpdate="0"/>
    <default field="ONE_TIME" expression="0" applyOnUpdate="0"/>
    <default field="BOAT_COUNT" expression="0" applyOnUpdate="0"/>
    <default field="SEAT_COUNT" expression="0" applyOnUpdate="0"/>
    <default field="SEASON" expression="" applyOnUpdate="0"/>
    <default field="WRK_COUNT" expression="0" applyOnUpdate="0"/>
    <default field="FUNCTION" expression="''" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
    <default field="KADASTROKS" expression="''" applyOnUpdate="0"/>
    <default field="KADASTRZU" expression="''" applyOnUpdate="0"/>
    <default field="NAMEDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="DATEDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="NUMBERDOCOSN" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="HOT_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="SAF_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="CHI_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="AL_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="TEM_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="CAPACITY" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="PERSON_PD" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="ONE_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="BOAT_COUNT" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="SEAT_COUNT" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SEASON" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="WRK_COUNT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FUNCTION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="2" field="KADASTROKS" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="KADASTRZU" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAMEDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="DATEDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NUMBERDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="HOT_STYPE" desc="Заполняется для объекта 602010601" exp="if(&quot;CLASSID&quot; = '602010601', &quot;HOT_STYPE&quot; IS NOT NULL, &quot;HOT_STYPE&quot; IS NULL)"/>
    <constraint field="SAF_STYPE" desc="Заполняется для объекта 602010602" exp="if(&quot;CLASSID&quot; = '602010602', &quot;SAF_STYPE&quot; IS NOT NULL, &quot;SAF_STYPE&quot; IS NULL)"/>
    <constraint field="CHI_STYPE" desc="Заполняется для объекта 602010603" exp="if(&quot;CLASSID&quot; = '602010603', &quot;CHI_STYPE&quot; IS NOT NULL, &quot;CHI_STYPE&quot; IS NULL)"/>
    <constraint field="AL_STYPE" desc="Заполняется для объекта 602010605" exp="if(&quot;CLASSID&quot; = '602010605', &quot;AL_STYPE&quot; IS NOT NULL, &quot;AL_STYPE&quot; IS NULL)"/>
    <constraint field="TEM_TYPE" desc="Заполняется для кода 602010607" exp="if(&quot;CLASSID&quot; = '602010607', &quot;TEM_TYPE&quot; IS NOT NULL, &quot;TEM_TYPE&quot; IS NULL)"/>
    <constraint field="CAPACITY" desc="Заполняется для объектов 602010601-602010605." exp="if (&quot;CLASSID&quot; = '602010601' OR&#xa;&#x9;&quot;CLASSID&quot; = '602010602' OR&#xa;&#x9;&quot;CLASSID&quot; = '602010603' OR&#xa;&#x9;&quot;CLASSID&quot; = '602010604' OR&#xa;&#x9;&quot;CLASSID&quot; = '602010605',&#xd;&#xa;&#x9;&quot;CAPACITY&quot; > 0,&#xd;&#xa;&#x9;&quot;CAPACITY&quot; >= 0)"/>
    <constraint field="PERSON_PD" desc="Заполняется для объектов 602010605." exp="if (&quot;CLASSID&quot; = '602010605',&#xa;&#x9;&quot;PERSON_PD&quot; > 0,&#xa;&#x9;&quot;PERSON_PD&quot; >= 0)"/>
    <constraint field="ONE_TIME" desc="Заполняется для объектов 602010605." exp="if (&quot;CLASSID&quot; = '602010605',&#xa;&#x9;&quot;ONE_TIME&quot; > 0,&#xa;&#x9;&quot;ONE_TIME&quot; >= 0)"/>
    <constraint field="BOAT_COUNT" desc="Заполняется для объектов 602010605." exp="if (&quot;CLASSID&quot; = '602010605',&#xa;&#x9;&quot;BOAT_COUNT&quot; > 0,&#xa;&#x9;&quot;BOAT_COUNT&quot; >= 0)"/>
    <constraint field="SEAT_COUNT" desc="Заполняется для объектов 602010605." exp="if (&quot;CLASSID&quot; = '602010605',&#xa;&#x9;&quot;SEAT_COUNT&quot; > 0,&#xa;&#x9;&quot;SEAT_COUNT&quot; >= 0)"/>
    <constraint field="SEASON" desc="" exp=""/>
    <constraint field="WRK_COUNT" desc="" exp=""/>
    <constraint field="FUNCTION" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
    <constraint field="KADASTROKS" desc="Кадастровый номер объекта должен соответствовать формату, принятому в ЕГРН." exp="regexp_match(&quot;KADASTROKS&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$')"/>
    <constraint field="KADASTRZU" desc="Обязательно для значений атрибута &quot;STATUS&quot; 1, 3, 4." exp="if (&quot;STATUS&quot; = 1 OR &quot;STATUS&quot; = 3 OR &quot;STATUS&quot; = 4,&#xd;&#xa;&#x9;regexp_match(&quot;KADASTRZU&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$|^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1})$'),&#xd;&#xa;&#x9;length(&quot;KADASTRZU&quot;) >= 0)"/>
    <constraint field="NAMEDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NAMEDOCOSN&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NAMEDOCOSN&quot;) >= 0)"/>
    <constraint field="DATEDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3. Формат даты (ДД.ММ.ГГГГ)." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;regexp_match(&quot;DATEDOCOSN&quot;, '^\\d{2}\\.\\d{2}\\.\\d{4}$'),&#xd;&#xa;&#x9;length(&quot;DATEDOCOSN&quot;) >= 0)"/>
    <constraint field="NUMBERDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NUMBERDOCOSN&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NUMBERDOCOSN&quot;) >= 0)"/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="22" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="23" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="16" name="SEASON">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="17" name="WRK_COUNT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="18" name="FUNCTION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="20" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="21" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="24" name="KADASTROKS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип гостиниц, аналогичных коллективных средств размещения" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010601'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="6" name="HOT_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип специализированного коллективного средства размещения" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010602'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="7" name="SAF_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип детского оздоровительного лагеря" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010603'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="8" name="CHI_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип объекта физкультурно-досугового назначения и активного отдыха" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010605'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="9" name="AL_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип места или объекта массового посещения, в том числе тематического туризма" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010607'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="10" name="TEM_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Вместимость объектов, обеспечивающих пребывание, мест" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; IN ('602010601', '602010602', '602010603', '602010604', '602010605')">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="11" name="CAPACITY">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Мощность объектов, не предусматривающих пребывания, число обслуживаемых лиц в сутки" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010605'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="12" name="PERSON_PD">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Единовременная пропускная способность, чел." collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010605'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="13" name="ONE_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Количество стояночных мест лодочных станций и яхт-клубов, мест" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010605'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="14" name="BOAT_COUNT">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Вместимость объектов зрелищного назначения, зрительских мест" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010605'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="15" name="SEAT_COUNT">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="19" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Кадастровый номер земельного участка и (или) номер кадастрового квартала, в границах которого расположен объект" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (1, 3, 4)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="25" name="KADASTRZU">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Наименование документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="26" name="NAMEDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Дата документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="27" name="DATEDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="28" name="NUMBERDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="AL_STYPE" editable="1"/>
    <field name="BOAT_COUNT" editable="1"/>
    <field name="CAPACITY" editable="1"/>
    <field name="CHI_STYPE" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="DATEDOCOSN" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="FUNCTION" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="HOT_STYPE" editable="1"/>
    <field name="KADASTROKS" editable="1"/>
    <field name="KADASTRZU" editable="1"/>
    <field name="NAME" editable="1"/>
    <field name="NAMEDOCOSN" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="NUMBERDOCOSN" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="ONE_TIME" editable="1"/>
    <field name="PERSON_PD" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="SAF_STYPE" editable="1"/>
    <field name="SEASON" editable="1"/>
    <field name="SEAT_COUNT" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="TEM_TYPE" editable="1"/>
    <field name="WRK_COUNT" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="AL_STYPE"/>
    <field labelOnTop="1" name="BOAT_COUNT"/>
    <field labelOnTop="1" name="CAPACITY"/>
    <field labelOnTop="1" name="CHI_STYPE"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="DATEDOCOSN"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="FUNCTION"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="HOT_STYPE"/>
    <field labelOnTop="1" name="KADASTROKS"/>
    <field labelOnTop="1" name="KADASTRZU"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NAMEDOCOSN"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="NUMBERDOCOSN"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="ONE_TIME"/>
    <field labelOnTop="1" name="PERSON_PD"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="SAF_STYPE"/>
    <field labelOnTop="1" name="SEASON"/>
    <field labelOnTop="1" name="SEAT_COUNT"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS"/>
    <field labelOnTop="1" name="TEM_TYPE"/>
    <field labelOnTop="1" name="WRK_COUNT"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="AL_STYPE" reuseLastValue="0"/>
    <field name="BOAT_COUNT" reuseLastValue="0"/>
    <field name="CAPACITY" reuseLastValue="0"/>
    <field name="CHI_STYPE" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="DATEDOCOSN" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="FUNCTION" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="HOT_STYPE" reuseLastValue="0"/>
    <field name="KADASTROKS" reuseLastValue="0"/>
    <field name="KADASTRZU" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NAMEDOCOSN" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="NUMBERDOCOSN" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="ONE_TIME" reuseLastValue="0"/>
    <field name="PERSON_PD" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="SAF_STYPE" reuseLastValue="0"/>
    <field name="SEASON" reuseLastValue="0"/>
    <field name="SEAT_COUNT" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="TEM_TYPE" reuseLastValue="0"/>
    <field name="WRK_COUNT" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
