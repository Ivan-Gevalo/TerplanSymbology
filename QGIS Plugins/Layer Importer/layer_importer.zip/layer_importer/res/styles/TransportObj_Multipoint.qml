<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{57d27dbd-6c3c-40b7-bbd2-8dece7806463}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{b4c5c594-d552-4474-87fa-7258ab0d7397}">
        <rule label="Мостовое сооружение" filter="&quot;CLASSID&quot; = '602031601'" symbol="1" key="{303b56b8-a8f8-4c91-8f7e-da3a78d4cf1e}"/>
        <rule label="Транспортная развязка в разных уровнях" filter="&quot;CLASSID&quot; = '602031602'" symbol="2" key="{58f97407-ecac-429d-bcb3-a4fe10b666e8}"/>
        <rule label="Тоннель" filter="&quot;CLASSID&quot; = '602031603'" symbol="3" key="{5908b6eb-ce04-4ed8-a61d-a31d6bd05ae5}"/>
        <rule label="Пешеходный переход в разных уровнях" filter="&quot;CLASSID&quot; = '602031604'" symbol="4" key="{dcc3e774-d762-4eb6-8f34-6aed6059c560}"/>
        <rule label="Железнодорожный переезд" filter="&quot;CLASSID&quot; = '602031605'" symbol="5" key="{c4f1a006-52a2-4d84-976f-6b453c2aeac8}"/>
        <rule label="Саморегулируемое пересечение в одном уровне" filter="&quot;CLASSID&quot; = '602031606'" symbol="6" key="{d30be251-c901-4af7-91fa-fe8ca88979d6}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="7" key="{23c7475a-ea08-4962-a1b4-ee2863b033cf}">
        <rule label="Мостовое сооружение" filter="&quot;CLASSID&quot; = '602031601'" symbol="8" key="{3f513400-615b-4a46-ba5e-30bf1e661dc7}"/>
        <rule label="Транспортная развязка в разных уровнях" filter="&quot;CLASSID&quot; = '602031602'" symbol="9" key="{b19f8424-ff16-4838-917a-664e2dfb6213}"/>
        <rule label="Тоннель" filter="&quot;CLASSID&quot; = '602031603'" symbol="10" key="{e4cad17d-0d09-426c-b906-0772cf99fc86}"/>
        <rule label="Пешеходный переход в разных уровнях" filter="&quot;CLASSID&quot; = '602031604'" symbol="11" key="{87bc5520-d568-4bbd-a364-d3c70936b1c2}"/>
        <rule label="Железнодорожный переезд" filter="&quot;CLASSID&quot; = '602031605'" symbol="12" key="{9da34461-79a7-4e0e-af8a-fa764e4fa796}"/>
        <rule label="Саморегулируемое пересечение в одном уровне" filter="&quot;CLASSID&quot; = '602031606'" symbol="13" key="{1e1cb66f-9663-4317-961a-34390e863387}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="14" key="{c22e1788-961f-420e-b06c-eb632baaa7bd}">
        <rule label="Мостовое сооружение" filter="&quot;CLASSID&quot; = '602031601'" symbol="15" key="{fd4a2da5-4610-4d61-84fc-9fbfc85e745c}"/>
        <rule label="Транспортная развязка в разных уровнях" filter="&quot;CLASSID&quot; = '602031602'" symbol="16" key="{3c153e52-4136-4448-a180-fd61fa1cacfe}"/>
        <rule label="Тоннель" filter="&quot;CLASSID&quot; = '602031603'" symbol="17" key="{d16c8e2b-fdcf-46ff-97ce-4a53efd516c1}"/>
        <rule label="Пешеходный переход в разных уровнях" filter="&quot;CLASSID&quot; = '602031604'" symbol="18" key="{3f01fd3b-15a3-4268-af62-28dcf894f513}"/>
        <rule label="Железнодорожный переезд" filter="&quot;CLASSID&quot; = '602031605'" symbol="19" key="{fc7ea725-2b95-4be4-92b1-91944426dfd6}"/>
        <rule label="Саморегулируемое пересечение в одном уровне" filter="&quot;CLASSID&quot; = '602031606'" symbol="20" key="{fe2f7df8-7dc4-43f9-a6de-f124eae76004}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="21" key="{94464dbd-6a5c-4579-9656-92bcfc144fce}">
        <rule label="Мостовое сооружение" filter="&quot;CLASSID&quot; = '602031601'" symbol="22" key="{3fde6fa4-97d0-4d11-aeb0-fde3f2502bfd}"/>
        <rule label="Транспортная развязка в разных уровнях" filter="&quot;CLASSID&quot; = '602031602'" symbol="23" key="{06e0ba46-c064-4d2e-8c06-55c5e2cf2150}"/>
        <rule label="Тоннель" filter="&quot;CLASSID&quot; = '602031603'" symbol="24" key="{34e8151f-0701-4fa5-bee5-9fdb639185d0}"/>
        <rule label="Пешеходный переход в разных уровнях" filter="&quot;CLASSID&quot; = '602031604'" symbol="25" key="{0ae1c60f-a9d5-450a-a90d-ec5156d73196}"/>
        <rule label="Саморегулируемое пересечение в одном уровне" filter="&quot;CLASSID&quot; = '602031606'" symbol="26" key="{5bbaa2f2-56b6-4080-8215-525379b4ec02}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="27" key="{919349a6-cf78-4762-b39c-d0a37de81af2}">
        <rule label="Мостовое сооружение" filter="&quot;CLASSID&quot; = '602031601'" symbol="28" key="{e04f95a0-ebf1-4072-a59b-2b44803ada6f}"/>
        <rule label="Транспортная развязка в разных уровнях" filter="&quot;CLASSID&quot; = '602031602'" symbol="29" key="{14080e97-28c1-4b16-afe3-2a08d600d863}"/>
        <rule label="Тоннель" filter="&quot;CLASSID&quot; = '602031603'" symbol="30" key="{1fedeb92-73d7-46f8-961e-13ad8db27219}"/>
        <rule label="Пешеходный переход в разных уровнях" filter="&quot;CLASSID&quot; = '602031604'" symbol="31" key="{c68a6401-5c48-4b43-9275-cfc80013b336}"/>
        <rule label="Железнодорожный переезд" filter="&quot;CLASSID&quot; = '602031605'" symbol="32" key="{6409671a-1926-483d-b5ff-16b9055e0fac}"/>
        <rule label="Саморегулируемое пересечение в одном уровне" filter="&quot;CLASSID&quot; = '602031606'" symbol="33" key="{dd4e8e69-5af2-46f8-952c-dbe5f08ce11b}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="34" key="{a905e4e7-3d87-4188-98fb-d5e9138e1882}">
        <rule label="Мостовое сооружение" filter="&quot;CLASSID&quot; = '602031601'" symbol="35" key="{053b51bf-c57b-4a80-9029-b4725db2592d}"/>
        <rule label="Транспортная развязка в разных уровнях" filter="&quot;CLASSID&quot; = '602031602'" symbol="36" key="{fbf8f291-dea7-49f6-b5fa-45152810c7bf}"/>
        <rule label="Тоннель" filter="&quot;CLASSID&quot; = '602031603'" symbol="37" key="{04531fa6-8c27-4fa4-af26-016b69521484}"/>
        <rule label="Пешеходный переход в разных уровнях" filter="&quot;CLASSID&quot; = '602031604'" symbol="38" key="{4788a40d-1f39-4ff2-96fc-11f686323cfb}"/>
        <rule label="Железнодорожный переезд" filter="&quot;CLASSID&quot; = '602031605'" symbol="39" key="{a492b739-19aa-4395-b1b6-df418dc1386b}"/>
        <rule label="Саморегулируемое пересечение в одном уровне" filter="&quot;CLASSID&quot; = '602031606'" symbol="40" key="{08c0d57f-5007-4486-a575-722dffd71edf}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="41" key="{ddaea09d-e9df-46ef-b145-c49f364004a1}">
        <rule label="Мостовое сооружение" filter="&quot;CLASSID&quot; = '602031601'" symbol="42" key="{1719ea0d-5a33-4448-b33b-6c0e66817278}"/>
        <rule label="Транспортная развязка в разных уровнях" filter="&quot;CLASSID&quot; = '602031602'" symbol="43" key="{c1c93e14-3dab-422f-b521-3098542b44f9}"/>
        <rule label="Тоннель" filter="&quot;CLASSID&quot; = '602031603'" symbol="44" key="{7a38985c-a9a1-45ec-b3f4-9765ee75d807}"/>
        <rule label="Пешеходный переход в разных уровнях" filter="&quot;CLASSID&quot; = '602031604'" symbol="45" key="{170e1d1c-5349-496e-8df3-535fca6bb002}"/>
        <rule label="Железнодорожный переезд" filter="&quot;CLASSID&quot; = '602031605'" symbol="46" key="{577d8e1e-f829-4c4a-9109-8920325f5e5a}"/>
        <rule label="Саморегулируемое пересечение в одном уровне" filter="&quot;CLASSID&quot; = '602031606'" symbol="47" key="{a65c8fdb-889f-4648-977e-037acb07f97c}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты регионального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 2" symbol="48" key="{9e3d92ec-2166-4a2b-b2ab-15e5dd16431c}">
        <rule label="Мостовое сооружение" filter="&quot;CLASSID&quot; = '602031601'" symbol="49" key="{3c7e1263-fa1b-49bd-adfb-41717ff6f94a}"/>
        <rule label="Транспортная развязка в разных уровнях" filter="&quot;CLASSID&quot; = '602031602'" symbol="50" key="{93c9ec26-9ca7-4e2d-a6d2-b27fb610df91}"/>
        <rule label="Тоннель" filter="&quot;CLASSID&quot; = '602031603'" symbol="51" key="{8ab9c069-5fad-4e63-b4e5-391e8bdee8c3}"/>
        <rule label="Пешеходный переход в разных уровнях" filter="&quot;CLASSID&quot; = '602031604'" symbol="52" key="{504bee0f-6d20-4073-9b1c-8ab6f53ef6cf}"/>
        <rule label="Саморегулируемое пересечение в одном уровне" filter="&quot;CLASSID&quot; = '602031606'" symbol="53" key="{367fc5d9-2ab9-4ffa-a651-50b26539d90e}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="54" key="{ca466e42-5d20-4c90-8f22-80f0a032902e}">
        <rule label="Мостовое сооружение" filter="&quot;CLASSID&quot; = '602031601'" symbol="55" key="{fdf7ac76-798b-4068-a3fd-5a9dff29d874}"/>
        <rule label="Транспортная развязка в разных уровнях" filter="&quot;CLASSID&quot; = '602031602'" symbol="56" key="{701dee67-8f79-43eb-b3ec-6494b6b8dae6}"/>
        <rule label="Тоннель" filter="&quot;CLASSID&quot; = '602031603'" symbol="57" key="{d26b100b-6316-447b-b1d6-89dc7c0a5e73}"/>
        <rule label="Пешеходный переход в разных уровнях" filter="&quot;CLASSID&quot; = '602031604'" symbol="58" key="{d9363393-84c6-43c7-99d3-a4f253d04c85}"/>
        <rule label="Железнодорожный переезд" filter="&quot;CLASSID&quot; = '602031605'" symbol="59" key="{1bc3e24b-5c8d-430f-b9f9-4d231b290e61}"/>
        <rule label="Саморегулируемое пересечение в одном уровне" filter="&quot;CLASSID&quot; = '602031606'" symbol="60" key="{7ec5cbbf-f4d8-440a-9ec0-58a8ef19aabd}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="61" key="{25f32713-f516-4a47-8c1d-780343494954}">
        <rule label="Мостовое сооружение" filter="&quot;CLASSID&quot; = '602031601'" symbol="62" key="{32c667dc-a66d-4e94-b5cf-b5fb7b87ea1d}"/>
        <rule label="Транспортная развязка в разных уровнях" filter="&quot;CLASSID&quot; = '602031602'" symbol="63" key="{df111190-361e-4f3f-8f4f-05468f2e6905}"/>
        <rule label="Тоннель" filter="&quot;CLASSID&quot; = '602031603'" symbol="64" key="{68c132f7-fe51-4a17-aeec-b87cadbafc68}"/>
        <rule label="Пешеходный переход в разных уровнях" filter="&quot;CLASSID&quot; = '602031604'" symbol="65" key="{9690bffd-4070-4bae-9815-6cf281a6c49b}"/>
        <rule label="Железнодорожный переезд" filter="&quot;CLASSID&quot; = '602031605'" symbol="66" key="{ff7f36df-d9a2-4b44-baee-114c3632b205}"/>
        <rule label="Саморегулируемое пересечение в одном уровне" filter="&quot;CLASSID&quot; = '602031606'" symbol="67" key="{3caff735-e284-47c4-9892-dfbd682ac1a6}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="68" key="{0f360dc0-7ce4-4bd8-bea6-4e60bc567abb}">
        <rule label="Мостовое сооружение" filter="&quot;CLASSID&quot; = '602031601'" symbol="69" key="{77da682e-4b1e-40cc-b2f1-969e7b1c75b5}"/>
        <rule label="Транспортная развязка в разных уровнях" filter="&quot;CLASSID&quot; = '602031602'" symbol="70" key="{5e88f38b-0d42-4b5c-b549-4753fac19c89}"/>
        <rule label="Тоннель" filter="&quot;CLASSID&quot; = '602031603'" symbol="71" key="{e7c8a9d8-bb94-4566-91b6-1e6baa72b645}"/>
        <rule label="Пешеходный переход в разных уровнях" filter="&quot;CLASSID&quot; = '602031604'" symbol="72" key="{85b8d785-d90c-4669-bef9-ef7d1abe8431}"/>
        <rule label="Железнодорожный переезд" filter="&quot;CLASSID&quot; = '602031605'" symbol="73" key="{b7ae5dd3-420f-4b83-a830-17d4ba9550d8}"/>
        <rule label="Саморегулируемое пересечение в одном уровне" filter="&quot;CLASSID&quot; = '602031606'" symbol="74" key="{9df39f99-63d1-40fc-b9db-3d93dae6f7dd}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты федерального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 1" symbol="75" key="{f72be2e9-d8af-4027-980f-7955073cdf19}">
        <rule label="Мостовое сооружение" filter="&quot;CLASSID&quot; = '602031601'" symbol="76" key="{8087fd8a-510a-4306-a7de-28c157732129}"/>
        <rule label="Транспортная развязка в разных уровнях" filter="&quot;CLASSID&quot; = '602031602'" symbol="77" key="{e139b38b-b1ca-473d-8c32-7cfed8829953}"/>
        <rule label="Тоннель" filter="&quot;CLASSID&quot; = '602031603'" symbol="78" key="{ad8af82d-7f41-4696-bc64-6b09cbca4551}"/>
        <rule label="Пешеходный переход в разных уровнях" filter="&quot;CLASSID&quot; = '602031604'" symbol="79" key="{575d1a02-19a5-4ecf-bfa9-523dcf2a01f1}"/>
        <rule label="Саморегулируемое пересечение в одном уровне" filter="&quot;CLASSID&quot; = '602031606'" symbol="80" key="{4cfe5b36-9164-4d6e-91b7-ac3527e3f6de}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzcuNjYxbW0iIGhlaWdodD0iMTcxLjkxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDc3LjY2MSAxNzEuOTEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM3LjgyIDE1NC44NSkiPjxyZWN0IHg9IjQzLjAzNSIgeT0iMTMyLjg1IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTE3LjAzIDJlLTYgNS45NjcxIDIyLjI3NiAyMi4yNzYgOC43ODc2LTguNzg3Ni0xOS40NTYtMTkuNDU2eiIvPjxwYXRoIGQ9Im0xOTIuNjcgMTE3LjAzdjUuOTY3MWwtMjIuMjc2IDIyLjI3Ni04Ljc4NzYtOC43ODc2IDE5LjQ1Ni0xOS40NTZ6Ii8+PHJlY3QgdHJhbnNmb3JtPSJzY2FsZSgxLC0xKSIgeD0iNDMuMDM1IiB5PSItMTc4Ljg4IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTk0LjY5IDJlLTYgLTUuOTY3MSAyMi4yNzYtMjIuMjc2IDguNzg3NiA4Ljc4NzYtMTkuNDU2IDE5LjQ1NnoiLz48cGF0aCBkPSJtMTkyLjY3IDE5NC42OXYtNS45NjcxbC0yMi4yNzYtMjIuMjc2LTguNzg3NiA4Ljc4NzYgMTkuNDU2IDE5LjQ1NnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.52982" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTI1LjExbW0iIGhlaWdodD0iMTI0LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyNS4xMSAxMjQuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyLjI4MSAtODMuODgpIj48ZyBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im03My4yNjMgODMuODgtMzAuOTgyIDMxLjkzNnY5Mi44NzhoMzIuMjMydi04Mi42NTFzMTIuMTAzLTE3LjE0IDIzLjMwMy0xNy4xNGgxNC4wNDRjMTEuMTA0IDAgMjMuMzAzIDE3LjE0IDIzLjMwMyAxNy4xNHY4Mi42NTFoMzIuMjMydi05Mi44NzhsLTMwLjk4Mi0zMS45MzZ6IiBzdHJva2Utd2lkdGg9IjIwLjE3MyIvPjxwYXRoIGQ9Im0xMDIuMzEgMTU4LjI2Yy00LjAzNzggMC04LjQwMDkgNi4xNzg4LTguNDAwOSA2LjE3ODh2MzEuMTg4aDIxLjg2NXYtMzEuMTg4cy00LjM5NzgtNi4xNzg4LTguNDAwOS02LjE3ODhoLTUuMDYyN3oiIHN0cm9rZS13aWR0aD0iOS42NTI2Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,-0.20000000000000001" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.41058" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTczLjAybW0iIGhlaWdodD0iMjEwLjYxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3My4wMiAyMTAuNjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzLjgyNzUpIj48cGF0aCBkPSJtMCAxMzkuNjV2MTkuMTEyaDQxLjIzNXYxNi4wMDhoNDEuMjM1djE2LjAwN2g0MS4yMzV2MTYuMDA4aDQ5LjMxOHYtMTkuMTEyaC00MS4yMzV2LTE2LjAwN2gtNDEuMjM1di0xNi4wMDhoLTQxLjIzNXYtMTYuMDA4eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZD0ibTg5LjY2MSA3Ni4yODEtMTUuMTQyIDYuNTUwMmMtNS42NzUgMi40NTUxLTExLjU2OSAxLjM2OTMtMTMuMjE0LTIuNDM0Ny0xLjY0NTYtMy44MDQgMS41OTg0LTguODQzMSA3LjI3MzYtMTEuMjk5bDIxLjIyOS05LjE4MzhjMCA5LjkxNS0wLjE0NzE5IDkuMTgzOC0wLjE0NzE5IDE2LjM2N3oiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjg5OSIvPjxwYXRoIGQ9Im0xMTguOTQgOTkuNjk4YzIuNzc4MyAyMC4zMjMgNS44MDExIDM2LjI4MyA4LjU4ODggNTYuODA2IDAuMzkyMyAxLjgyNDcgMC4yNjA5MyAzLjI3NjQtMC40NTYwMSA1LjA1MzktMC40Njk1NyAxLjE2MTYtMC43NjcyNiAxLjY4NDItMS4zMjU0IDIuMzIyMy0yLjQ5NDggMi44NTE5LTYuMzQ2IDMuNzY4OS05LjgxMTEgMi4zMzU4LTAuNTUwNi0wLjIyNzY1LTEuMzMyNS0wLjY2MTUyLTEuNzM3Ny0wLjk2NDM3LTEuNjQyMi0xLjIyNzMtMi43MjEzLTIuOTA5OS0zLjM2MDMtNS4yMzk4LTAuMjE5NzgtMC44MDEyOS00LjE3MzktMzQuNTktNi45MzQ1LTU0LjE3OXoiIHN0cm9rZS13aWR0aD0iLjE2MTY2Ii8+PHBhdGggZD0ibTExMy4yIDI4Ljg1MmMwLjU2MjQzLTAuMDA4NSAxLjA5MzQgMC4wMjQ2NiAxLjQ4MjEgMC4xMDY0NSAwLjQyMTQ2IDAuMDg4NjggMS4xMTA3IDAuMzAzMjYgMS41MzIyIDAuNDc2OTcgMC40MjE0NiAwLjE3MzcxIDYuNDk1OSAzLjYzNTcgMTMuNDk4IDcuNjkzMSAxMC40NDQgNi4wNTE1IDEyLjk3NSA3LjUxNTIgMTQuMDE3IDguNjcyM2wtMTYuMDQ0IDAuMDAxNnYzLjU2MzZjLTMuMDAxLTEuNzI4Ni01LjQ2OTktMy4wOTg5LTUuNTQ1NC0zLjA3MzctMC4wOTY2IDAuMDMyMi0wLjE2NTk0IDUuNDY5Ni0wLjIxMjkxIDE2LjY4NWwtMC4wNjk4IDIxLjI4NnMtMC4zMDgwNCAzLjA4NDMtMS4wMjYxIDQuNDEyOWMtMC42MzU4MSAxLjE3NjQtMC45NzIyOSAyLjExMjctMi43NzExIDIuOTAwOS02LjgxNTQgMi45ODY1LTE2LjIzMSA3LjIzNDMtMjQuNTI2IDEwLjEzOC01LjA2NDcgMS43NzI2LTEyLjY2NiA0LjE1NjQtMTIuNDAzIDkuNjY4NmwwLjk0NzkzIDE5Ljg5M2MwLjcwMzk5IDE0Ljc3NC0xLjYyMzkgMTcuMDcxLTIuMDEzNiAxNy44NjctMC45NjU3NiAxLjk3MjUtMy4yMDcyIDMuNjI1OC01LjM3MDIgMy45NjE1LTEuMTQ1OCAwLjE3Nzc4LTEuNTI3NCAwLjE2Njk4LTIuNjQ3NC0wLjA3NTQtMS40NDM4LTAuMzEyNjgtMi41OTAyLTAuOTU0OTMtMy42OTQzLTIuMDY5MS0xLjA0OTctMS4wNTkzLTEuNTk3Ni0yLjAwMzMtMS45NDM2LTMuMzQ5Ny0wLjQ3MjYxLTEuODM5LTAuNzUzNTEgMC45NzQ0Ny0xLjg5OC0yNi45OTgtMS4xNDQ2LTMyLjkwNS0wLjUwNjgxLTI1LjYxNCAyMS41ODItMzQuODgzIDAgMCA1LjQzMDgtMS45Njg2IDguMDQ1Mi0zLjEzOTcgMS40OTg5LTAuNjcxNDQgMy40ODM1LTEuODQxIDMuNDgzNS0zLjQ4NDZ2LTIxLjc0NmM3LjhlLTQgLTAuNzgwMiAyZS0zIC00LjM3MTMgMC04LjQwODN2LTExLjIyN2MwLjA4MzItMS4zNjg3IDEuMDM3NS0xLjc3MjEgNi44ODQzLTUuMTQ3IDIuOTQ4LTEuNzAxNiA1LjcwNjctMy4yMTcxIDYuMTMwNC0zLjM2ODMgMC42MDAwMi0wLjIxNDA4IDEuNjI1Mi0wLjM0NDM5IDIuNTYyNi0wLjM1ODYzeiIgc3Ryb2tlLXdpZHRoPSIuMTM5MzMiLz48cGF0aCBkPSJtMTIwLjE3IDUuNTk3MWMwLjQyMTk0IDQuMDMyMy0xLjA1OTUgOC4zMjA2LTMuMzI4NCAxMS42OTktMS4zNDk2IDIuMDA5My0zLjMxMDIgMy41OTUzLTUuMzI0NCA0LjkzNzUtMi42NDQ4IDEuNzYyNS01LjU2NzIgMy4yOTE1LTguNjc1MiAzLjk1NjctMS4xODk2IDAuMjU0NTgtMi41MDE2IDAuMzgwMjItMy42NDk0LTAuMDIyOC0xLjQzNDQtMC41MDM2NS0yLjcyNjEtMS41Njk0LTMuNTc3NC0yLjgyOS0xLjI5NzQtMS45MTk1LTEuNjg4OC00LjM2NjEtMS45Njc3LTYuNjY2LTAuMjg4NjYtMi4zNzk5LTAuMzUxOS00Ljg4NTcgMC4zMjgxMi03LjE4NDcgMC44MjI3NS0yLjc4MTUgMi40Mjk0LTUuMzc3NSA0LjM5NTctNy41MDk5IDEuODEyMi0xLjk2NTMgNC4wNDAyLTMuNzM2MyA2LjU3MDctNC41OTgzIDIuMzY2Ny0wLjgwNjIgNS4wNjA0LTAuOTIzMDQgNy40OTI5LTAuMzQ1IDEuNzAyIDAuNDA0NDMgMy4zNTMzIDEuMzIwNCA0LjU3MzUgMi41NzM5IDEuNTc0NiAxLjYxNzYgMi45MjY2IDMuNzQzOCAzLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTEzMS40NCA0MC42ODFjMTAuNzY4IDMuNjUwOCAxMS4zNSAzLjk0OTYgMTIuNTggNS40NjEyIDEuMzI1OCAxLjYyOTUgMS4zNjcgMC45NTI4MiA0LjU1NDYgMTYuOTU3IDAgMCAyLjIyNTcgOS4yMzYgMi42NTA2IDE0LjM4NCAwLjAyMzkgMC4yOTAyNC0wLjE2MDIgMC44NTg4Ni0wLjE2MDIgMC44NTg4Ni0wLjIwOTQyIDEuMTIzMy0xLjE4MTUgMi43MDkyLTIuMDg2MiAzLjQwMzQtMi43OTM4IDIuMTQzNy02LjU1ODcgMS40ODMzLTguNTUzNS0xLjUwMDctMC40MTk4NS0wLjYyODA1LTAuNDY4MjUtMC44MzY5NS0zLjA4MDktMTMuNDM2bC0yLjY1MzYtMTIuNzk4LTAuMTkxMi0wLjcxMjYyLTkuODUzOS01LjY2NDQtMS4wOTQzLTUuMzYwMnoiIHN0cm9rZS13aWR0aD0iLjEzOTMzIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.51815" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTMzLjUxbW0iIGhlaWdodD0iMTM1Ljc4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEzMy41MSAxMzUuNzgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM4LjYxMyAtODUuODA4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utd2lkdGg9IjguNjc4Ij48cGF0aCBkPSJtNTkuNjcxIDE2OS4yOS0xNS42NzQtMy45ODY2IDQuMzg0NS0xNS41NjcgMzQuNDA5LTE5Ljg2Ni0zNC40MDktMTkuODY2LTQuMzg0NS0xNS41NjcgMTUuNjc0LTMuOTg2NiA0NS42OTggMjYuMzg0IDQ1LjY5OC0yNi4zODQgMTUuNjc0IDMuOTg2Ni00LjM4NDUgMTUuNTY3LTM0LjQwOSAxOS44NjYgMzQuNDA5IDE5Ljg2NiA0LjM4NDUgMTUuNTY3LTE1LjY3NCAzLjk4NjYtNDUuNjk4LTI2LjM4NHoiLz48cGF0aCBkPSJtMTA1LjM3IDE2NC40OS01Ni45ODggMzIuOTAyLTQuMzg0NSAxNS41NjcgMTUuNjc0IDMuOTg2NiA0NS42OTgtMjYuMzg0IDQ1LjY5OCAyNi4zODQgMTUuNjc0LTMuOTg2Ni00LjM4NDUtMTUuNTY3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTUzLjc5bW0iIGhlaWdodD0iMTUzLjc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1My43OSAxNTMuNzkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI5LjcxOSAtNzEuODY4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIj48Y2lyY2xlIGN4PSIxMDYuNjEiIGN5PSIxNDguNzYiIHI9IjQ3LjczMyIgc3Ryb2tlLXdpZHRoPSIxNSIvPjxwYXRoIGQ9Im0xMDYuNjEgNzEuODY4djI5LjE2MW0wIDk1LjQ2NnYyOS4xNjEiIHN0cm9rZS13aWR0aD0iOC4wNzc5Ii8+PHBhdGggZD0ibTE4My41MSAxNDguNzZoLTI5LjE2MW0tOTUuNDY2IDFlLTUgLTI5LjE2MS0xZS01IiBzdHJva2Utd2lkdGg9IjguMDc3OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzcuNjYxbW0iIGhlaWdodD0iMTcxLjkxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDc3LjY2MSAxNzEuOTEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM3LjgyIDE1NC44NSkiPjxyZWN0IHg9IjQzLjAzNSIgeT0iMTMyLjg1IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTE3LjAzIDJlLTYgNS45NjcxIDIyLjI3NiAyMi4yNzYgOC43ODc2LTguNzg3Ni0xOS40NTYtMTkuNDU2eiIvPjxwYXRoIGQ9Im0xOTIuNjcgMTE3LjAzdjUuOTY3MWwtMjIuMjc2IDIyLjI3Ni04Ljc4NzYtOC43ODc2IDE5LjQ1Ni0xOS40NTZ6Ii8+PHJlY3QgdHJhbnNmb3JtPSJzY2FsZSgxLC0xKSIgeD0iNDMuMDM1IiB5PSItMTc4Ljg4IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTk0LjY5IDJlLTYgLTUuOTY3MSAyMi4yNzYtMjIuMjc2IDguNzg3NiA4Ljc4NzYtMTkuNDU2IDE5LjQ1NnoiLz48cGF0aCBkPSJtMTkyLjY3IDE5NC42OXYtNS45NjcxbC0yMi4yNzYtMjIuMjc2LTguNzg3NiA4Ljc4NzYgMTkuNDU2IDE5LjQ1NnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.52982" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE5LjU3bW0iIGhlaWdodD0iMTE3Ljg2bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExOS41NyAxMTcuODYiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxLjQ0NyAtODguNjcxKSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48cGF0aCBkPSJtOTIuMDA5IDg4LjY3MS0xMS43NDQgNDEuOTE0aDE3Ljk1M2wxLjAzMy00MS45MTR6bS0xNy4wMzYgNjAuNzk4LTE1Ljk4OSA1Ny4wNjVoMzcuMzYybDEuNDA2Ni01Ny4wNjV6IiBzdHJva2Utd2lkdGg9IjIwLjk1MSIvPjxwYXRoIGQ9Im0xMDMuMjEgODguNjcxIDEuMDMzIDQxLjkxNGgxNy45NTNsLTExLjc0NC00MS45MTR6bTEuNDk4NiA2MC43OTggMS40MDY2IDU3LjA2NWgzNy4zNjJsLTE1Ljk5LTU3LjA2NXoiIHN0cm9rZS13aWR0aD0iMjAuOTUxIi8+PHBhdGggZD0ibTQxLjQ0NyAxMzUuNDl2OS4wNzU5aDE1Ljc0N3YxMy40NDFoMTAuNTc2bDIuMDkzOS0xMy40NDFoNjIuNzM4bDIuMDkzOSAxMy40NDFoMTAuNTc2di0xMy40NDFoMTUuNzQ3di05LjA3NTl6IiBzdHJva2Utd2lkdGg9IjE4LjYzNiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.47835" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTI1LjExbW0iIGhlaWdodD0iMTI0LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyNS4xMSAxMjQuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyLjI4MSAtODMuODgpIj48ZyBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im03My4yNjMgODMuODgtMzAuOTgyIDMxLjkzNnY5Mi44NzhoMzIuMjMydi04Mi42NTFzMTIuMTAzLTE3LjE0IDIzLjMwMy0xNy4xNGgxNC4wNDRjMTEuMTA0IDAgMjMuMzAzIDE3LjE0IDIzLjMwMyAxNy4xNHY4Mi42NTFoMzIuMjMydi05Mi44NzhsLTMwLjk4Mi0zMS45MzZ6IiBzdHJva2Utd2lkdGg9IjIwLjE3MyIvPjxwYXRoIGQ9Im0xMDIuMzEgMTU4LjI2Yy00LjAzNzggMC04LjQwMDkgNi4xNzg4LTguNDAwOSA2LjE3ODh2MzEuMTg4aDIxLjg2NXYtMzEuMTg4cy00LjM5NzgtNi4xNzg4LTguNDAwOS02LjE3ODhoLTUuMDYyN3oiIHN0cm9rZS13aWR0aD0iOS42NTI2Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,-0.20000000000000001" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.41058" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTczLjAybW0iIGhlaWdodD0iMjEwLjYxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3My4wMiAyMTAuNjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzLjgyNzUpIj48cGF0aCBkPSJtMCAxMzkuNjV2MTkuMTEyaDQxLjIzNXYxNi4wMDhoNDEuMjM1djE2LjAwN2g0MS4yMzV2MTYuMDA4aDQ5LjMxOHYtMTkuMTEyaC00MS4yMzV2LTE2LjAwN2gtNDEuMjM1di0xNi4wMDhoLTQxLjIzNXYtMTYuMDA4eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZD0ibTg5LjY2MSA3Ni4yODEtMTUuMTQyIDYuNTUwMmMtNS42NzUgMi40NTUxLTExLjU2OSAxLjM2OTMtMTMuMjE0LTIuNDM0Ny0xLjY0NTYtMy44MDQgMS41OTg0LTguODQzMSA3LjI3MzYtMTEuMjk5bDIxLjIyOS05LjE4MzhjMCA5LjkxNS0wLjE0NzE5IDkuMTgzOC0wLjE0NzE5IDE2LjM2N3oiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjg5OSIvPjxwYXRoIGQ9Im0xMTguOTQgOTkuNjk4YzIuNzc4MyAyMC4zMjMgNS44MDExIDM2LjI4MyA4LjU4ODggNTYuODA2IDAuMzkyMyAxLjgyNDcgMC4yNjA5MyAzLjI3NjQtMC40NTYwMSA1LjA1MzktMC40Njk1NyAxLjE2MTYtMC43NjcyNiAxLjY4NDItMS4zMjU0IDIuMzIyMy0yLjQ5NDggMi44NTE5LTYuMzQ2IDMuNzY4OS05LjgxMTEgMi4zMzU4LTAuNTUwNi0wLjIyNzY1LTEuMzMyNS0wLjY2MTUyLTEuNzM3Ny0wLjk2NDM3LTEuNjQyMi0xLjIyNzMtMi43MjEzLTIuOTA5OS0zLjM2MDMtNS4yMzk4LTAuMjE5NzgtMC44MDEyOS00LjE3MzktMzQuNTktNi45MzQ1LTU0LjE3OXoiIHN0cm9rZS13aWR0aD0iLjE2MTY2Ii8+PHBhdGggZD0ibTExMy4yIDI4Ljg1MmMwLjU2MjQzLTAuMDA4NSAxLjA5MzQgMC4wMjQ2NiAxLjQ4MjEgMC4xMDY0NSAwLjQyMTQ2IDAuMDg4NjggMS4xMTA3IDAuMzAzMjYgMS41MzIyIDAuNDc2OTcgMC40MjE0NiAwLjE3MzcxIDYuNDk1OSAzLjYzNTcgMTMuNDk4IDcuNjkzMSAxMC40NDQgNi4wNTE1IDEyLjk3NSA3LjUxNTIgMTQuMDE3IDguNjcyM2wtMTYuMDQ0IDAuMDAxNnYzLjU2MzZjLTMuMDAxLTEuNzI4Ni01LjQ2OTktMy4wOTg5LTUuNTQ1NC0zLjA3MzctMC4wOTY2IDAuMDMyMi0wLjE2NTk0IDUuNDY5Ni0wLjIxMjkxIDE2LjY4NWwtMC4wNjk4IDIxLjI4NnMtMC4zMDgwNCAzLjA4NDMtMS4wMjYxIDQuNDEyOWMtMC42MzU4MSAxLjE3NjQtMC45NzIyOSAyLjExMjctMi43NzExIDIuOTAwOS02LjgxNTQgMi45ODY1LTE2LjIzMSA3LjIzNDMtMjQuNTI2IDEwLjEzOC01LjA2NDcgMS43NzI2LTEyLjY2NiA0LjE1NjQtMTIuNDAzIDkuNjY4NmwwLjk0NzkzIDE5Ljg5M2MwLjcwMzk5IDE0Ljc3NC0xLjYyMzkgMTcuMDcxLTIuMDEzNiAxNy44NjctMC45NjU3NiAxLjk3MjUtMy4yMDcyIDMuNjI1OC01LjM3MDIgMy45NjE1LTEuMTQ1OCAwLjE3Nzc4LTEuNTI3NCAwLjE2Njk4LTIuNjQ3NC0wLjA3NTQtMS40NDM4LTAuMzEyNjgtMi41OTAyLTAuOTU0OTMtMy42OTQzLTIuMDY5MS0xLjA0OTctMS4wNTkzLTEuNTk3Ni0yLjAwMzMtMS45NDM2LTMuMzQ5Ny0wLjQ3MjYxLTEuODM5LTAuNzUzNTEgMC45NzQ0Ny0xLjg5OC0yNi45OTgtMS4xNDQ2LTMyLjkwNS0wLjUwNjgxLTI1LjYxNCAyMS41ODItMzQuODgzIDAgMCA1LjQzMDgtMS45Njg2IDguMDQ1Mi0zLjEzOTcgMS40OTg5LTAuNjcxNDQgMy40ODM1LTEuODQxIDMuNDgzNS0zLjQ4NDZ2LTIxLjc0NmM3LjhlLTQgLTAuNzgwMiAyZS0zIC00LjM3MTMgMC04LjQwODN2LTExLjIyN2MwLjA4MzItMS4zNjg3IDEuMDM3NS0xLjc3MjEgNi44ODQzLTUuMTQ3IDIuOTQ4LTEuNzAxNiA1LjcwNjctMy4yMTcxIDYuMTMwNC0zLjM2ODMgMC42MDAwMi0wLjIxNDA4IDEuNjI1Mi0wLjM0NDM5IDIuNTYyNi0wLjM1ODYzeiIgc3Ryb2tlLXdpZHRoPSIuMTM5MzMiLz48cGF0aCBkPSJtMTIwLjE3IDUuNTk3MWMwLjQyMTk0IDQuMDMyMy0xLjA1OTUgOC4zMjA2LTMuMzI4NCAxMS42OTktMS4zNDk2IDIuMDA5My0zLjMxMDIgMy41OTUzLTUuMzI0NCA0LjkzNzUtMi42NDQ4IDEuNzYyNS01LjU2NzIgMy4yOTE1LTguNjc1MiAzLjk1NjctMS4xODk2IDAuMjU0NTgtMi41MDE2IDAuMzgwMjItMy42NDk0LTAuMDIyOC0xLjQzNDQtMC41MDM2NS0yLjcyNjEtMS41Njk0LTMuNTc3NC0yLjgyOS0xLjI5NzQtMS45MTk1LTEuNjg4OC00LjM2NjEtMS45Njc3LTYuNjY2LTAuMjg4NjYtMi4zNzk5LTAuMzUxOS00Ljg4NTcgMC4zMjgxMi03LjE4NDcgMC44MjI3NS0yLjc4MTUgMi40Mjk0LTUuMzc3NSA0LjM5NTctNy41MDk5IDEuODEyMi0xLjk2NTMgNC4wNDAyLTMuNzM2MyA2LjU3MDctNC41OTgzIDIuMzY2Ny0wLjgwNjIgNS4wNjA0LTAuOTIzMDQgNy40OTI5LTAuMzQ1IDEuNzAyIDAuNDA0NDMgMy4zNTMzIDEuMzIwNCA0LjU3MzUgMi41NzM5IDEuNTc0NiAxLjYxNzYgMi45MjY2IDMuNzQzOCAzLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTEzMS40NCA0MC42ODFjMTAuNzY4IDMuNjUwOCAxMS4zNSAzLjk0OTYgMTIuNTggNS40NjEyIDEuMzI1OCAxLjYyOTUgMS4zNjcgMC45NTI4MiA0LjU1NDYgMTYuOTU3IDAgMCAyLjIyNTcgOS4yMzYgMi42NTA2IDE0LjM4NCAwLjAyMzkgMC4yOTAyNC0wLjE2MDIgMC44NTg4Ni0wLjE2MDIgMC44NTg4Ni0wLjIwOTQyIDEuMTIzMy0xLjE4MTUgMi43MDkyLTIuMDg2MiAzLjQwMzQtMi43OTM4IDIuMTQzNy02LjU1ODcgMS40ODMzLTguNTUzNS0xLjUwMDctMC40MTk4NS0wLjYyODA1LTAuNDY4MjUtMC44MzY5NS0zLjA4MDktMTMuNDM2bC0yLjY1MzYtMTIuNzk4LTAuMTkxMi0wLjcxMjYyLTkuODUzOS01LjY2NDQtMS4wOTQzLTUuMzYwMnoiIHN0cm9rZS13aWR0aD0iLjEzOTMzIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.51815" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTMzLjUxbW0iIGhlaWdodD0iMTM1Ljc4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEzMy41MSAxMzUuNzgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM4LjYxMyAtODUuODA4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utd2lkdGg9IjguNjc4Ij48cGF0aCBkPSJtNTkuNjcxIDE2OS4yOS0xNS42NzQtMy45ODY2IDQuMzg0NS0xNS41NjcgMzQuNDA5LTE5Ljg2Ni0zNC40MDktMTkuODY2LTQuMzg0NS0xNS41NjcgMTUuNjc0LTMuOTg2NiA0NS42OTggMjYuMzg0IDQ1LjY5OC0yNi4zODQgMTUuNjc0IDMuOTg2Ni00LjM4NDUgMTUuNTY3LTM0LjQwOSAxOS44NjYgMzQuNDA5IDE5Ljg2NiA0LjM4NDUgMTUuNTY3LTE1LjY3NCAzLjk4NjYtNDUuNjk4LTI2LjM4NHoiLz48cGF0aCBkPSJtMTA1LjM3IDE2NC40OS01Ni45ODggMzIuOTAyLTQuMzg0NSAxNS41NjcgMTUuNjc0IDMuOTg2NiA0NS42OTgtMjYuMzg0IDQ1LjY5OCAyNi4zODQgMTUuNjc0LTMuOTg2Ni00LjM4NDUtMTUuNTY3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE5LjU3bW0iIGhlaWdodD0iMTE3Ljg2bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExOS41NyAxMTcuODYiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxLjQ0NyAtODguNjcxKSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48cGF0aCBkPSJtOTIuMDA5IDg4LjY3MS0xMS43NDQgNDEuOTE0aDE3Ljk1M2wxLjAzMy00MS45MTR6bS0xNy4wMzYgNjAuNzk4LTE1Ljk4OSA1Ny4wNjVoMzcuMzYybDEuNDA2Ni01Ny4wNjV6IiBzdHJva2Utd2lkdGg9IjIwLjk1MSIvPjxwYXRoIGQ9Im0xMDMuMjEgODguNjcxIDEuMDMzIDQxLjkxNGgxNy45NTNsLTExLjc0NC00MS45MTR6bTEuNDk4NiA2MC43OTggMS40MDY2IDU3LjA2NWgzNy4zNjJsLTE1Ljk5LTU3LjA2NXoiIHN0cm9rZS13aWR0aD0iMjAuOTUxIi8+PHBhdGggZD0ibTQxLjQ0NyAxMzUuNDl2OS4wNzU5aDE1Ljc0N3YxMy40NDFoMTAuNTc2bDIuMDkzOS0xMy40NDFoNjIuNzM4bDIuMDkzOSAxMy40NDFoMTAuNTc2di0xMy40NDFoMTUuNzQ3di05LjA3NTl6IiBzdHJva2Utd2lkdGg9IjE4LjYzNiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.47835" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTUzLjc5bW0iIGhlaWdodD0iMTUzLjc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1My43OSAxNTMuNzkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI5LjcxOSAtNzEuODY4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIj48Y2lyY2xlIGN4PSIxMDYuNjEiIGN5PSIxNDguNzYiIHI9IjQ3LjczMyIgc3Ryb2tlLXdpZHRoPSIxNSIvPjxwYXRoIGQ9Im0xMDYuNjEgNzEuODY4djI5LjE2MW0wIDk1LjQ2NnYyOS4xNjEiIHN0cm9rZS13aWR0aD0iOC4wNzc5Ii8+PHBhdGggZD0ibTE4My41MSAxNDguNzZoLTI5LjE2MW0tOTUuNDY2IDFlLTUgLTI5LjE2MS0xZS01IiBzdHJva2Utd2lkdGg9IjguMDc3OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzcuNjYxbW0iIGhlaWdodD0iMTcxLjkxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDc3LjY2MSAxNzEuOTEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM3LjgyIDE1NC44NSkiPjxyZWN0IHg9IjQzLjAzNSIgeT0iMTMyLjg1IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTE3LjAzIDJlLTYgNS45NjcxIDIyLjI3NiAyMi4yNzYgOC43ODc2LTguNzg3Ni0xOS40NTYtMTkuNDU2eiIvPjxwYXRoIGQ9Im0xOTIuNjcgMTE3LjAzdjUuOTY3MWwtMjIuMjc2IDIyLjI3Ni04Ljc4NzYtOC43ODc2IDE5LjQ1Ni0xOS40NTZ6Ii8+PHJlY3QgdHJhbnNmb3JtPSJzY2FsZSgxLC0xKSIgeD0iNDMuMDM1IiB5PSItMTc4Ljg4IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTk0LjY5IDJlLTYgLTUuOTY3MSAyMi4yNzYtMjIuMjc2IDguNzg3NiA4Ljc4NzYtMTkuNDU2IDE5LjQ1NnoiLz48cGF0aCBkPSJtMTkyLjY3IDE5NC42OXYtNS45NjcxbC0yMi4yNzYtMjIuMjc2LTguNzg3NiA4Ljc4NzYgMTkuNDU2IDE5LjQ1NnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.52982" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE5LjU3bW0iIGhlaWdodD0iMTE3Ljg2bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExOS41NyAxMTcuODYiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxLjQ0NyAtODguNjcxKSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48cGF0aCBkPSJtOTIuMDA5IDg4LjY3MS0xMS43NDQgNDEuOTE0aDE3Ljk1M2wxLjAzMy00MS45MTR6bS0xNy4wMzYgNjAuNzk4LTE1Ljk4OSA1Ny4wNjVoMzcuMzYybDEuNDA2Ni01Ny4wNjV6IiBzdHJva2Utd2lkdGg9IjIwLjk1MSIvPjxwYXRoIGQ9Im0xMDMuMjEgODguNjcxIDEuMDMzIDQxLjkxNGgxNy45NTNsLTExLjc0NC00MS45MTR6bTEuNDk4NiA2MC43OTggMS40MDY2IDU3LjA2NWgzNy4zNjJsLTE1Ljk5LTU3LjA2NXoiIHN0cm9rZS13aWR0aD0iMjAuOTUxIi8+PHBhdGggZD0ibTQxLjQ0NyAxMzUuNDl2OS4wNzU5aDE1Ljc0N3YxMy40NDFoMTAuNTc2bDIuMDkzOS0xMy40NDFoNjIuNzM4bDIuMDkzOSAxMy40NDFoMTAuNTc2di0xMy40NDFoMTUuNzQ3di05LjA3NTl6IiBzdHJva2Utd2lkdGg9IjE4LjYzNiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.47835" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTI1LjExbW0iIGhlaWdodD0iMTI0LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyNS4xMSAxMjQuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyLjI4MSAtODMuODgpIj48ZyBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im03My4yNjMgODMuODgtMzAuOTgyIDMxLjkzNnY5Mi44NzhoMzIuMjMydi04Mi42NTFzMTIuMTAzLTE3LjE0IDIzLjMwMy0xNy4xNGgxNC4wNDRjMTEuMTA0IDAgMjMuMzAzIDE3LjE0IDIzLjMwMyAxNy4xNHY4Mi42NTFoMzIuMjMydi05Mi44NzhsLTMwLjk4Mi0zMS45MzZ6IiBzdHJva2Utd2lkdGg9IjIwLjE3MyIvPjxwYXRoIGQ9Im0xMDIuMzEgMTU4LjI2Yy00LjAzNzggMC04LjQwMDkgNi4xNzg4LTguNDAwOSA2LjE3ODh2MzEuMTg4aDIxLjg2NXYtMzEuMTg4cy00LjM5NzgtNi4xNzg4LTguNDAwOS02LjE3ODhoLTUuMDYyN3oiIHN0cm9rZS13aWR0aD0iOS42NTI2Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,-0.20000000000000001" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.41058" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTczLjAybW0iIGhlaWdodD0iMjEwLjYxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3My4wMiAyMTAuNjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzLjgyNzUpIj48cGF0aCBkPSJtMCAxMzkuNjV2MTkuMTEyaDQxLjIzNXYxNi4wMDhoNDEuMjM1djE2LjAwN2g0MS4yMzV2MTYuMDA4aDQ5LjMxOHYtMTkuMTEyaC00MS4yMzV2LTE2LjAwN2gtNDEuMjM1di0xNi4wMDhoLTQxLjIzNXYtMTYuMDA4eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZD0ibTg5LjY2MSA3Ni4yODEtMTUuMTQyIDYuNTUwMmMtNS42NzUgMi40NTUxLTExLjU2OSAxLjM2OTMtMTMuMjE0LTIuNDM0Ny0xLjY0NTYtMy44MDQgMS41OTg0LTguODQzMSA3LjI3MzYtMTEuMjk5bDIxLjIyOS05LjE4MzhjMCA5LjkxNS0wLjE0NzE5IDkuMTgzOC0wLjE0NzE5IDE2LjM2N3oiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjg5OSIvPjxwYXRoIGQ9Im0xMTguOTQgOTkuNjk4YzIuNzc4MyAyMC4zMjMgNS44MDExIDM2LjI4MyA4LjU4ODggNTYuODA2IDAuMzkyMyAxLjgyNDcgMC4yNjA5MyAzLjI3NjQtMC40NTYwMSA1LjA1MzktMC40Njk1NyAxLjE2MTYtMC43NjcyNiAxLjY4NDItMS4zMjU0IDIuMzIyMy0yLjQ5NDggMi44NTE5LTYuMzQ2IDMuNzY4OS05LjgxMTEgMi4zMzU4LTAuNTUwNi0wLjIyNzY1LTEuMzMyNS0wLjY2MTUyLTEuNzM3Ny0wLjk2NDM3LTEuNjQyMi0xLjIyNzMtMi43MjEzLTIuOTA5OS0zLjM2MDMtNS4yMzk4LTAuMjE5NzgtMC44MDEyOS00LjE3MzktMzQuNTktNi45MzQ1LTU0LjE3OXoiIHN0cm9rZS13aWR0aD0iLjE2MTY2Ii8+PHBhdGggZD0ibTExMy4yIDI4Ljg1MmMwLjU2MjQzLTAuMDA4NSAxLjA5MzQgMC4wMjQ2NiAxLjQ4MjEgMC4xMDY0NSAwLjQyMTQ2IDAuMDg4NjggMS4xMTA3IDAuMzAzMjYgMS41MzIyIDAuNDc2OTcgMC40MjE0NiAwLjE3MzcxIDYuNDk1OSAzLjYzNTcgMTMuNDk4IDcuNjkzMSAxMC40NDQgNi4wNTE1IDEyLjk3NSA3LjUxNTIgMTQuMDE3IDguNjcyM2wtMTYuMDQ0IDAuMDAxNnYzLjU2MzZjLTMuMDAxLTEuNzI4Ni01LjQ2OTktMy4wOTg5LTUuNTQ1NC0zLjA3MzctMC4wOTY2IDAuMDMyMi0wLjE2NTk0IDUuNDY5Ni0wLjIxMjkxIDE2LjY4NWwtMC4wNjk4IDIxLjI4NnMtMC4zMDgwNCAzLjA4NDMtMS4wMjYxIDQuNDEyOWMtMC42MzU4MSAxLjE3NjQtMC45NzIyOSAyLjExMjctMi43NzExIDIuOTAwOS02LjgxNTQgMi45ODY1LTE2LjIzMSA3LjIzNDMtMjQuNTI2IDEwLjEzOC01LjA2NDcgMS43NzI2LTEyLjY2NiA0LjE1NjQtMTIuNDAzIDkuNjY4NmwwLjk0NzkzIDE5Ljg5M2MwLjcwMzk5IDE0Ljc3NC0xLjYyMzkgMTcuMDcxLTIuMDEzNiAxNy44NjctMC45NjU3NiAxLjk3MjUtMy4yMDcyIDMuNjI1OC01LjM3MDIgMy45NjE1LTEuMTQ1OCAwLjE3Nzc4LTEuNTI3NCAwLjE2Njk4LTIuNjQ3NC0wLjA3NTQtMS40NDM4LTAuMzEyNjgtMi41OTAyLTAuOTU0OTMtMy42OTQzLTIuMDY5MS0xLjA0OTctMS4wNTkzLTEuNTk3Ni0yLjAwMzMtMS45NDM2LTMuMzQ5Ny0wLjQ3MjYxLTEuODM5LTAuNzUzNTEgMC45NzQ0Ny0xLjg5OC0yNi45OTgtMS4xNDQ2LTMyLjkwNS0wLjUwNjgxLTI1LjYxNCAyMS41ODItMzQuODgzIDAgMCA1LjQzMDgtMS45Njg2IDguMDQ1Mi0zLjEzOTcgMS40OTg5LTAuNjcxNDQgMy40ODM1LTEuODQxIDMuNDgzNS0zLjQ4NDZ2LTIxLjc0NmM3LjhlLTQgLTAuNzgwMiAyZS0zIC00LjM3MTMgMC04LjQwODN2LTExLjIyN2MwLjA4MzItMS4zNjg3IDEuMDM3NS0xLjc3MjEgNi44ODQzLTUuMTQ3IDIuOTQ4LTEuNzAxNiA1LjcwNjctMy4yMTcxIDYuMTMwNC0zLjM2ODMgMC42MDAwMi0wLjIxNDA4IDEuNjI1Mi0wLjM0NDM5IDIuNTYyNi0wLjM1ODYzeiIgc3Ryb2tlLXdpZHRoPSIuMTM5MzMiLz48cGF0aCBkPSJtMTIwLjE3IDUuNTk3MWMwLjQyMTk0IDQuMDMyMy0xLjA1OTUgOC4zMjA2LTMuMzI4NCAxMS42OTktMS4zNDk2IDIuMDA5My0zLjMxMDIgMy41OTUzLTUuMzI0NCA0LjkzNzUtMi42NDQ4IDEuNzYyNS01LjU2NzIgMy4yOTE1LTguNjc1MiAzLjk1NjctMS4xODk2IDAuMjU0NTgtMi41MDE2IDAuMzgwMjItMy42NDk0LTAuMDIyOC0xLjQzNDQtMC41MDM2NS0yLjcyNjEtMS41Njk0LTMuNTc3NC0yLjgyOS0xLjI5NzQtMS45MTk1LTEuNjg4OC00LjM2NjEtMS45Njc3LTYuNjY2LTAuMjg4NjYtMi4zNzk5LTAuMzUxOS00Ljg4NTcgMC4zMjgxMi03LjE4NDcgMC44MjI3NS0yLjc4MTUgMi40Mjk0LTUuMzc3NSA0LjM5NTctNy41MDk5IDEuODEyMi0xLjk2NTMgNC4wNDAyLTMuNzM2MyA2LjU3MDctNC41OTgzIDIuMzY2Ny0wLjgwNjIgNS4wNjA0LTAuOTIzMDQgNy40OTI5LTAuMzQ1IDEuNzAyIDAuNDA0NDMgMy4zNTMzIDEuMzIwNCA0LjU3MzUgMi41NzM5IDEuNTc0NiAxLjYxNzYgMi45MjY2IDMuNzQzOCAzLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTEzMS40NCA0MC42ODFjMTAuNzY4IDMuNjUwOCAxMS4zNSAzLjk0OTYgMTIuNTggNS40NjEyIDEuMzI1OCAxLjYyOTUgMS4zNjcgMC45NTI4MiA0LjU1NDYgMTYuOTU3IDAgMCAyLjIyNTcgOS4yMzYgMi42NTA2IDE0LjM4NCAwLjAyMzkgMC4yOTAyNC0wLjE2MDIgMC44NTg4Ni0wLjE2MDIgMC44NTg4Ni0wLjIwOTQyIDEuMTIzMy0xLjE4MTUgMi43MDkyLTIuMDg2MiAzLjQwMzQtMi43OTM4IDIuMTQzNy02LjU1ODcgMS40ODMzLTguNTUzNS0xLjUwMDctMC40MTk4NS0wLjYyODA1LTAuNDY4MjUtMC44MzY5NS0zLjA4MDktMTMuNDM2bC0yLjY1MzYtMTIuNzk4LTAuMTkxMi0wLjcxMjYyLTkuODUzOS01LjY2NDQtMS4wOTQzLTUuMzYwMnoiIHN0cm9rZS13aWR0aD0iLjEzOTMzIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.51815" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTUzLjc5bW0iIGhlaWdodD0iMTUzLjc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1My43OSAxNTMuNzkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI5LjcxOSAtNzEuODY4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIj48Y2lyY2xlIGN4PSIxMDYuNjEiIGN5PSIxNDguNzYiIHI9IjQ3LjczMyIgc3Ryb2tlLXdpZHRoPSIxNSIvPjxwYXRoIGQ9Im0xMDYuNjEgNzEuODY4djI5LjE2MW0wIDk1LjQ2NnYyOS4xNjEiIHN0cm9rZS13aWR0aD0iOC4wNzc5Ii8+PHBhdGggZD0ibTE4My41MSAxNDguNzZoLTI5LjE2MW0tOTUuNDY2IDFlLTUgLTI5LjE2MS0xZS01IiBzdHJva2Utd2lkdGg9IjguMDc3OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzcuNjYxbW0iIGhlaWdodD0iMTcxLjkxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDc3LjY2MSAxNzEuOTEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM3LjgyIDE1NC44NSkiPjxyZWN0IHg9IjQzLjAzNSIgeT0iMTMyLjg1IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTE3LjAzIDJlLTYgNS45NjcxIDIyLjI3NiAyMi4yNzYgOC43ODc2LTguNzg3Ni0xOS40NTYtMTkuNDU2eiIvPjxwYXRoIGQ9Im0xOTIuNjcgMTE3LjAzdjUuOTY3MWwtMjIuMjc2IDIyLjI3Ni04Ljc4NzYtOC43ODc2IDE5LjQ1Ni0xOS40NTZ6Ii8+PHJlY3QgdHJhbnNmb3JtPSJzY2FsZSgxLC0xKSIgeD0iNDMuMDM1IiB5PSItMTc4Ljg4IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTk0LjY5IDJlLTYgLTUuOTY3MSAyMi4yNzYtMjIuMjc2IDguNzg3NiA4Ljc4NzYtMTkuNDU2IDE5LjQ1NnoiLz48cGF0aCBkPSJtMTkyLjY3IDE5NC42OXYtNS45NjcxbC0yMi4yNzYtMjIuMjc2LTguNzg3NiA4Ljc4NzYgMTkuNDU2IDE5LjQ1NnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.52982" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE5LjU3bW0iIGhlaWdodD0iMTE3Ljg2bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExOS41NyAxMTcuODYiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxLjQ0NyAtODguNjcxKSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48cGF0aCBkPSJtOTIuMDA5IDg4LjY3MS0xMS43NDQgNDEuOTE0aDE3Ljk1M2wxLjAzMy00MS45MTR6bS0xNy4wMzYgNjAuNzk4LTE1Ljk4OSA1Ny4wNjVoMzcuMzYybDEuNDA2Ni01Ny4wNjV6IiBzdHJva2Utd2lkdGg9IjIwLjk1MSIvPjxwYXRoIGQ9Im0xMDMuMjEgODguNjcxIDEuMDMzIDQxLjkxNGgxNy45NTNsLTExLjc0NC00MS45MTR6bTEuNDk4NiA2MC43OTggMS40MDY2IDU3LjA2NWgzNy4zNjJsLTE1Ljk5LTU3LjA2NXoiIHN0cm9rZS13aWR0aD0iMjAuOTUxIi8+PHBhdGggZD0ibTQxLjQ0NyAxMzUuNDl2OS4wNzU5aDE1Ljc0N3YxMy40NDFoMTAuNTc2bDIuMDkzOS0xMy40NDFoNjIuNzM4bDIuMDkzOSAxMy40NDFoMTAuNTc2di0xMy40NDFoMTUuNzQ3di05LjA3NTl6IiBzdHJva2Utd2lkdGg9IjE4LjYzNiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.47835" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTI1LjExbW0iIGhlaWdodD0iMTI0LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyNS4xMSAxMjQuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyLjI4MSAtODMuODgpIj48ZyBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im03My4yNjMgODMuODgtMzAuOTgyIDMxLjkzNnY5Mi44NzhoMzIuMjMydi04Mi42NTFzMTIuMTAzLTE3LjE0IDIzLjMwMy0xNy4xNGgxNC4wNDRjMTEuMTA0IDAgMjMuMzAzIDE3LjE0IDIzLjMwMyAxNy4xNHY4Mi42NTFoMzIuMjMydi05Mi44NzhsLTMwLjk4Mi0zMS45MzZ6IiBzdHJva2Utd2lkdGg9IjIwLjE3MyIvPjxwYXRoIGQ9Im0xMDIuMzEgMTU4LjI2Yy00LjAzNzggMC04LjQwMDkgNi4xNzg4LTguNDAwOSA2LjE3ODh2MzEuMTg4aDIxLjg2NXYtMzEuMTg4cy00LjM5NzgtNi4xNzg4LTguNDAwOS02LjE3ODhoLTUuMDYyN3oiIHN0cm9rZS13aWR0aD0iOS42NTI2Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,-0.20000000000000001" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.41058" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTI1LjExbW0iIGhlaWdodD0iMTI0LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyNS4xMSAxMjQuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyLjI4MSAtODMuODgpIj48ZyBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im03My4yNjMgODMuODgtMzAuOTgyIDMxLjkzNnY5Mi44NzhoMzIuMjMydi04Mi42NTFzMTIuMTAzLTE3LjE0IDIzLjMwMy0xNy4xNGgxNC4wNDRjMTEuMTA0IDAgMjMuMzAzIDE3LjE0IDIzLjMwMyAxNy4xNHY4Mi42NTFoMzIuMjMydi05Mi44NzhsLTMwLjk4Mi0zMS45MzZ6IiBzdHJva2Utd2lkdGg9IjIwLjE3MyIvPjxwYXRoIGQ9Im0xMDIuMzEgMTU4LjI2Yy00LjAzNzggMC04LjQwMDkgNi4xNzg4LTguNDAwOSA2LjE3ODh2MzEuMTg4aDIxLjg2NXYtMzEuMTg4cy00LjM5NzgtNi4xNzg4LTguNDAwOS02LjE3ODhoLTUuMDYyN3oiIHN0cm9rZS13aWR0aD0iOS42NTI2Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,-0.20000000000000001" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.41058" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTczLjAybW0iIGhlaWdodD0iMjEwLjYxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3My4wMiAyMTAuNjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzLjgyNzUpIj48cGF0aCBkPSJtMCAxMzkuNjV2MTkuMTEyaDQxLjIzNXYxNi4wMDhoNDEuMjM1djE2LjAwN2g0MS4yMzV2MTYuMDA4aDQ5LjMxOHYtMTkuMTEyaC00MS4yMzV2LTE2LjAwN2gtNDEuMjM1di0xNi4wMDhoLTQxLjIzNXYtMTYuMDA4eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZD0ibTg5LjY2MSA3Ni4yODEtMTUuMTQyIDYuNTUwMmMtNS42NzUgMi40NTUxLTExLjU2OSAxLjM2OTMtMTMuMjE0LTIuNDM0Ny0xLjY0NTYtMy44MDQgMS41OTg0LTguODQzMSA3LjI3MzYtMTEuMjk5bDIxLjIyOS05LjE4MzhjMCA5LjkxNS0wLjE0NzE5IDkuMTgzOC0wLjE0NzE5IDE2LjM2N3oiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjg5OSIvPjxwYXRoIGQ9Im0xMTguOTQgOTkuNjk4YzIuNzc4MyAyMC4zMjMgNS44MDExIDM2LjI4MyA4LjU4ODggNTYuODA2IDAuMzkyMyAxLjgyNDcgMC4yNjA5MyAzLjI3NjQtMC40NTYwMSA1LjA1MzktMC40Njk1NyAxLjE2MTYtMC43NjcyNiAxLjY4NDItMS4zMjU0IDIuMzIyMy0yLjQ5NDggMi44NTE5LTYuMzQ2IDMuNzY4OS05LjgxMTEgMi4zMzU4LTAuNTUwNi0wLjIyNzY1LTEuMzMyNS0wLjY2MTUyLTEuNzM3Ny0wLjk2NDM3LTEuNjQyMi0xLjIyNzMtMi43MjEzLTIuOTA5OS0zLjM2MDMtNS4yMzk4LTAuMjE5NzgtMC44MDEyOS00LjE3MzktMzQuNTktNi45MzQ1LTU0LjE3OXoiIHN0cm9rZS13aWR0aD0iLjE2MTY2Ii8+PHBhdGggZD0ibTExMy4yIDI4Ljg1MmMwLjU2MjQzLTAuMDA4NSAxLjA5MzQgMC4wMjQ2NiAxLjQ4MjEgMC4xMDY0NSAwLjQyMTQ2IDAuMDg4NjggMS4xMTA3IDAuMzAzMjYgMS41MzIyIDAuNDc2OTcgMC40MjE0NiAwLjE3MzcxIDYuNDk1OSAzLjYzNTcgMTMuNDk4IDcuNjkzMSAxMC40NDQgNi4wNTE1IDEyLjk3NSA3LjUxNTIgMTQuMDE3IDguNjcyM2wtMTYuMDQ0IDAuMDAxNnYzLjU2MzZjLTMuMDAxLTEuNzI4Ni01LjQ2OTktMy4wOTg5LTUuNTQ1NC0zLjA3MzctMC4wOTY2IDAuMDMyMi0wLjE2NTk0IDUuNDY5Ni0wLjIxMjkxIDE2LjY4NWwtMC4wNjk4IDIxLjI4NnMtMC4zMDgwNCAzLjA4NDMtMS4wMjYxIDQuNDEyOWMtMC42MzU4MSAxLjE3NjQtMC45NzIyOSAyLjExMjctMi43NzExIDIuOTAwOS02LjgxNTQgMi45ODY1LTE2LjIzMSA3LjIzNDMtMjQuNTI2IDEwLjEzOC01LjA2NDcgMS43NzI2LTEyLjY2NiA0LjE1NjQtMTIuNDAzIDkuNjY4NmwwLjk0NzkzIDE5Ljg5M2MwLjcwMzk5IDE0Ljc3NC0xLjYyMzkgMTcuMDcxLTIuMDEzNiAxNy44NjctMC45NjU3NiAxLjk3MjUtMy4yMDcyIDMuNjI1OC01LjM3MDIgMy45NjE1LTEuMTQ1OCAwLjE3Nzc4LTEuNTI3NCAwLjE2Njk4LTIuNjQ3NC0wLjA3NTQtMS40NDM4LTAuMzEyNjgtMi41OTAyLTAuOTU0OTMtMy42OTQzLTIuMDY5MS0xLjA0OTctMS4wNTkzLTEuNTk3Ni0yLjAwMzMtMS45NDM2LTMuMzQ5Ny0wLjQ3MjYxLTEuODM5LTAuNzUzNTEgMC45NzQ0Ny0xLjg5OC0yNi45OTgtMS4xNDQ2LTMyLjkwNS0wLjUwNjgxLTI1LjYxNCAyMS41ODItMzQuODgzIDAgMCA1LjQzMDgtMS45Njg2IDguMDQ1Mi0zLjEzOTcgMS40OTg5LTAuNjcxNDQgMy40ODM1LTEuODQxIDMuNDgzNS0zLjQ4NDZ2LTIxLjc0NmM3LjhlLTQgLTAuNzgwMiAyZS0zIC00LjM3MTMgMC04LjQwODN2LTExLjIyN2MwLjA4MzItMS4zNjg3IDEuMDM3NS0xLjc3MjEgNi44ODQzLTUuMTQ3IDIuOTQ4LTEuNzAxNiA1LjcwNjctMy4yMTcxIDYuMTMwNC0zLjM2ODMgMC42MDAwMi0wLjIxNDA4IDEuNjI1Mi0wLjM0NDM5IDIuNTYyNi0wLjM1ODYzeiIgc3Ryb2tlLXdpZHRoPSIuMTM5MzMiLz48cGF0aCBkPSJtMTIwLjE3IDUuNTk3MWMwLjQyMTk0IDQuMDMyMy0xLjA1OTUgOC4zMjA2LTMuMzI4NCAxMS42OTktMS4zNDk2IDIuMDA5My0zLjMxMDIgMy41OTUzLTUuMzI0NCA0LjkzNzUtMi42NDQ4IDEuNzYyNS01LjU2NzIgMy4yOTE1LTguNjc1MiAzLjk1NjctMS4xODk2IDAuMjU0NTgtMi41MDE2IDAuMzgwMjItMy42NDk0LTAuMDIyOC0xLjQzNDQtMC41MDM2NS0yLjcyNjEtMS41Njk0LTMuNTc3NC0yLjgyOS0xLjI5NzQtMS45MTk1LTEuNjg4OC00LjM2NjEtMS45Njc3LTYuNjY2LTAuMjg4NjYtMi4zNzk5LTAuMzUxOS00Ljg4NTcgMC4zMjgxMi03LjE4NDcgMC44MjI3NS0yLjc4MTUgMi40Mjk0LTUuMzc3NSA0LjM5NTctNy41MDk5IDEuODEyMi0xLjk2NTMgNC4wNDAyLTMuNzM2MyA2LjU3MDctNC41OTgzIDIuMzY2Ny0wLjgwNjIgNS4wNjA0LTAuOTIzMDQgNy40OTI5LTAuMzQ1IDEuNzAyIDAuNDA0NDMgMy4zNTMzIDEuMzIwNCA0LjU3MzUgMi41NzM5IDEuNTc0NiAxLjYxNzYgMi45MjY2IDMuNzQzOCAzLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTEzMS40NCA0MC42ODFjMTAuNzY4IDMuNjUwOCAxMS4zNSAzLjk0OTYgMTIuNTggNS40NjEyIDEuMzI1OCAxLjYyOTUgMS4zNjcgMC45NTI4MiA0LjU1NDYgMTYuOTU3IDAgMCAyLjIyNTcgOS4yMzYgMi42NTA2IDE0LjM4NCAwLjAyMzkgMC4yOTAyNC0wLjE2MDIgMC44NTg4Ni0wLjE2MDIgMC44NTg4Ni0wLjIwOTQyIDEuMTIzMy0xLjE4MTUgMi43MDkyLTIuMDg2MiAzLjQwMzQtMi43OTM4IDIuMTQzNy02LjU1ODcgMS40ODMzLTguNTUzNS0xLjUwMDctMC40MTk4NS0wLjYyODA1LTAuNDY4MjUtMC44MzY5NS0zLjA4MDktMTMuNDM2bC0yLjY1MzYtMTIuNzk4LTAuMTkxMi0wLjcxMjYyLTkuODUzOS01LjY2NDQtMS4wOTQzLTUuMzYwMnoiIHN0cm9rZS13aWR0aD0iLjEzOTMzIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.51815" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTMzLjUxbW0iIGhlaWdodD0iMTM1Ljc4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEzMy41MSAxMzUuNzgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM4LjYxMyAtODUuODA4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utd2lkdGg9IjguNjc4Ij48cGF0aCBkPSJtNTkuNjcxIDE2OS4yOS0xNS42NzQtMy45ODY2IDQuMzg0NS0xNS41NjcgMzQuNDA5LTE5Ljg2Ni0zNC40MDktMTkuODY2LTQuMzg0NS0xNS41NjcgMTUuNjc0LTMuOTg2NiA0NS42OTggMjYuMzg0IDQ1LjY5OC0yNi4zODQgMTUuNjc0IDMuOTg2Ni00LjM4NDUgMTUuNTY3LTM0LjQwOSAxOS44NjYgMzQuNDA5IDE5Ljg2NiA0LjM4NDUgMTUuNTY3LTE1LjY3NCAzLjk4NjYtNDUuNjk4LTI2LjM4NHoiLz48cGF0aCBkPSJtMTA1LjM3IDE2NC40OS01Ni45ODggMzIuOTAyLTQuMzg0NSAxNS41NjcgMTUuNjc0IDMuOTg2NiA0NS42OTgtMjYuMzg0IDQ1LjY5OCAyNi4zODQgMTUuNjc0LTMuOTg2Ni00LjM4NDUtMTUuNTY3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTUzLjc5bW0iIGhlaWdodD0iMTUzLjc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1My43OSAxNTMuNzkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI5LjcxOSAtNzEuODY4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIj48Y2lyY2xlIGN4PSIxMDYuNjEiIGN5PSIxNDguNzYiIHI9IjQ3LjczMyIgc3Ryb2tlLXdpZHRoPSIxNSIvPjxwYXRoIGQ9Im0xMDYuNjEgNzEuODY4djI5LjE2MW0wIDk1LjQ2NnYyOS4xNjEiIHN0cm9rZS13aWR0aD0iOC4wNzc5Ii8+PHBhdGggZD0ibTE4My41MSAxNDguNzZoLTI5LjE2MW0tOTUuNDY2IDFlLTUgLTI5LjE2MS0xZS01IiBzdHJva2Utd2lkdGg9IjguMDc3OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzcuNjYxbW0iIGhlaWdodD0iMTcxLjkxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDc3LjY2MSAxNzEuOTEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM3LjgyIDE1NC44NSkiPjxyZWN0IHg9IjQzLjAzNSIgeT0iMTMyLjg1IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTE3LjAzIDJlLTYgNS45NjcxIDIyLjI3NiAyMi4yNzYgOC43ODc2LTguNzg3Ni0xOS40NTYtMTkuNDU2eiIvPjxwYXRoIGQ9Im0xOTIuNjcgMTE3LjAzdjUuOTY3MWwtMjIuMjc2IDIyLjI3Ni04Ljc4NzYtOC43ODc2IDE5LjQ1Ni0xOS40NTZ6Ii8+PHJlY3QgdHJhbnNmb3JtPSJzY2FsZSgxLC0xKSIgeD0iNDMuMDM1IiB5PSItMTc4Ljg4IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTk0LjY5IDJlLTYgLTUuOTY3MSAyMi4yNzYtMjIuMjc2IDguNzg3NiA4Ljc4NzYtMTkuNDU2IDE5LjQ1NnoiLz48cGF0aCBkPSJtMTkyLjY3IDE5NC42OXYtNS45NjcxbC0yMi4yNzYtMjIuMjc2LTguNzg3NiA4Ljc4NzYgMTkuNDU2IDE5LjQ1NnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.52982" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="36" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE5LjU3bW0iIGhlaWdodD0iMTE3Ljg2bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExOS41NyAxMTcuODYiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxLjQ0NyAtODguNjcxKSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48cGF0aCBkPSJtOTIuMDA5IDg4LjY3MS0xMS43NDQgNDEuOTE0aDE3Ljk1M2wxLjAzMy00MS45MTR6bS0xNy4wMzYgNjAuNzk4LTE1Ljk4OSA1Ny4wNjVoMzcuMzYybDEuNDA2Ni01Ny4wNjV6IiBzdHJva2Utd2lkdGg9IjIwLjk1MSIvPjxwYXRoIGQ9Im0xMDMuMjEgODguNjcxIDEuMDMzIDQxLjkxNGgxNy45NTNsLTExLjc0NC00MS45MTR6bTEuNDk4NiA2MC43OTggMS40MDY2IDU3LjA2NWgzNy4zNjJsLTE1Ljk5LTU3LjA2NXoiIHN0cm9rZS13aWR0aD0iMjAuOTUxIi8+PHBhdGggZD0ibTQxLjQ0NyAxMzUuNDl2OS4wNzU5aDE1Ljc0N3YxMy40NDFoMTAuNTc2bDIuMDkzOS0xMy40NDFoNjIuNzM4bDIuMDkzOSAxMy40NDFoMTAuNTc2di0xMy40NDFoMTUuNzQ3di05LjA3NTl6IiBzdHJva2Utd2lkdGg9IjE4LjYzNiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.47835" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="37" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTI1LjExbW0iIGhlaWdodD0iMTI0LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyNS4xMSAxMjQuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyLjI4MSAtODMuODgpIj48ZyBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im03My4yNjMgODMuODgtMzAuOTgyIDMxLjkzNnY5Mi44NzhoMzIuMjMydi04Mi42NTFzMTIuMTAzLTE3LjE0IDIzLjMwMy0xNy4xNGgxNC4wNDRjMTEuMTA0IDAgMjMuMzAzIDE3LjE0IDIzLjMwMyAxNy4xNHY4Mi42NTFoMzIuMjMydi05Mi44NzhsLTMwLjk4Mi0zMS45MzZ6IiBzdHJva2Utd2lkdGg9IjIwLjE3MyIvPjxwYXRoIGQ9Im0xMDIuMzEgMTU4LjI2Yy00LjAzNzggMC04LjQwMDkgNi4xNzg4LTguNDAwOSA2LjE3ODh2MzEuMTg4aDIxLjg2NXYtMzEuMTg4cy00LjM5NzgtNi4xNzg4LTguNDAwOS02LjE3ODhoLTUuMDYyN3oiIHN0cm9rZS13aWR0aD0iOS42NTI2Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,-0.20000000000000001" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.41058" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="38" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTczLjAybW0iIGhlaWdodD0iMjEwLjYxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3My4wMiAyMTAuNjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzLjgyNzUpIj48cGF0aCBkPSJtMCAxMzkuNjV2MTkuMTEyaDQxLjIzNXYxNi4wMDhoNDEuMjM1djE2LjAwN2g0MS4yMzV2MTYuMDA4aDQ5LjMxOHYtMTkuMTEyaC00MS4yMzV2LTE2LjAwN2gtNDEuMjM1di0xNi4wMDhoLTQxLjIzNXYtMTYuMDA4eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZD0ibTg5LjY2MSA3Ni4yODEtMTUuMTQyIDYuNTUwMmMtNS42NzUgMi40NTUxLTExLjU2OSAxLjM2OTMtMTMuMjE0LTIuNDM0Ny0xLjY0NTYtMy44MDQgMS41OTg0LTguODQzMSA3LjI3MzYtMTEuMjk5bDIxLjIyOS05LjE4MzhjMCA5LjkxNS0wLjE0NzE5IDkuMTgzOC0wLjE0NzE5IDE2LjM2N3oiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjg5OSIvPjxwYXRoIGQ9Im0xMTguOTQgOTkuNjk4YzIuNzc4MyAyMC4zMjMgNS44MDExIDM2LjI4MyA4LjU4ODggNTYuODA2IDAuMzkyMyAxLjgyNDcgMC4yNjA5MyAzLjI3NjQtMC40NTYwMSA1LjA1MzktMC40Njk1NyAxLjE2MTYtMC43NjcyNiAxLjY4NDItMS4zMjU0IDIuMzIyMy0yLjQ5NDggMi44NTE5LTYuMzQ2IDMuNzY4OS05LjgxMTEgMi4zMzU4LTAuNTUwNi0wLjIyNzY1LTEuMzMyNS0wLjY2MTUyLTEuNzM3Ny0wLjk2NDM3LTEuNjQyMi0xLjIyNzMtMi43MjEzLTIuOTA5OS0zLjM2MDMtNS4yMzk4LTAuMjE5NzgtMC44MDEyOS00LjE3MzktMzQuNTktNi45MzQ1LTU0LjE3OXoiIHN0cm9rZS13aWR0aD0iLjE2MTY2Ii8+PHBhdGggZD0ibTExMy4yIDI4Ljg1MmMwLjU2MjQzLTAuMDA4NSAxLjA5MzQgMC4wMjQ2NiAxLjQ4MjEgMC4xMDY0NSAwLjQyMTQ2IDAuMDg4NjggMS4xMTA3IDAuMzAzMjYgMS41MzIyIDAuNDc2OTcgMC40MjE0NiAwLjE3MzcxIDYuNDk1OSAzLjYzNTcgMTMuNDk4IDcuNjkzMSAxMC40NDQgNi4wNTE1IDEyLjk3NSA3LjUxNTIgMTQuMDE3IDguNjcyM2wtMTYuMDQ0IDAuMDAxNnYzLjU2MzZjLTMuMDAxLTEuNzI4Ni01LjQ2OTktMy4wOTg5LTUuNTQ1NC0zLjA3MzctMC4wOTY2IDAuMDMyMi0wLjE2NTk0IDUuNDY5Ni0wLjIxMjkxIDE2LjY4NWwtMC4wNjk4IDIxLjI4NnMtMC4zMDgwNCAzLjA4NDMtMS4wMjYxIDQuNDEyOWMtMC42MzU4MSAxLjE3NjQtMC45NzIyOSAyLjExMjctMi43NzExIDIuOTAwOS02LjgxNTQgMi45ODY1LTE2LjIzMSA3LjIzNDMtMjQuNTI2IDEwLjEzOC01LjA2NDcgMS43NzI2LTEyLjY2NiA0LjE1NjQtMTIuNDAzIDkuNjY4NmwwLjk0NzkzIDE5Ljg5M2MwLjcwMzk5IDE0Ljc3NC0xLjYyMzkgMTcuMDcxLTIuMDEzNiAxNy44NjctMC45NjU3NiAxLjk3MjUtMy4yMDcyIDMuNjI1OC01LjM3MDIgMy45NjE1LTEuMTQ1OCAwLjE3Nzc4LTEuNTI3NCAwLjE2Njk4LTIuNjQ3NC0wLjA3NTQtMS40NDM4LTAuMzEyNjgtMi41OTAyLTAuOTU0OTMtMy42OTQzLTIuMDY5MS0xLjA0OTctMS4wNTkzLTEuNTk3Ni0yLjAwMzMtMS45NDM2LTMuMzQ5Ny0wLjQ3MjYxLTEuODM5LTAuNzUzNTEgMC45NzQ0Ny0xLjg5OC0yNi45OTgtMS4xNDQ2LTMyLjkwNS0wLjUwNjgxLTI1LjYxNCAyMS41ODItMzQuODgzIDAgMCA1LjQzMDgtMS45Njg2IDguMDQ1Mi0zLjEzOTcgMS40OTg5LTAuNjcxNDQgMy40ODM1LTEuODQxIDMuNDgzNS0zLjQ4NDZ2LTIxLjc0NmM3LjhlLTQgLTAuNzgwMiAyZS0zIC00LjM3MTMgMC04LjQwODN2LTExLjIyN2MwLjA4MzItMS4zNjg3IDEuMDM3NS0xLjc3MjEgNi44ODQzLTUuMTQ3IDIuOTQ4LTEuNzAxNiA1LjcwNjctMy4yMTcxIDYuMTMwNC0zLjM2ODMgMC42MDAwMi0wLjIxNDA4IDEuNjI1Mi0wLjM0NDM5IDIuNTYyNi0wLjM1ODYzeiIgc3Ryb2tlLXdpZHRoPSIuMTM5MzMiLz48cGF0aCBkPSJtMTIwLjE3IDUuNTk3MWMwLjQyMTk0IDQuMDMyMy0xLjA1OTUgOC4zMjA2LTMuMzI4NCAxMS42OTktMS4zNDk2IDIuMDA5My0zLjMxMDIgMy41OTUzLTUuMzI0NCA0LjkzNzUtMi42NDQ4IDEuNzYyNS01LjU2NzIgMy4yOTE1LTguNjc1MiAzLjk1NjctMS4xODk2IDAuMjU0NTgtMi41MDE2IDAuMzgwMjItMy42NDk0LTAuMDIyOC0xLjQzNDQtMC41MDM2NS0yLjcyNjEtMS41Njk0LTMuNTc3NC0yLjgyOS0xLjI5NzQtMS45MTk1LTEuNjg4OC00LjM2NjEtMS45Njc3LTYuNjY2LTAuMjg4NjYtMi4zNzk5LTAuMzUxOS00Ljg4NTcgMC4zMjgxMi03LjE4NDcgMC44MjI3NS0yLjc4MTUgMi40Mjk0LTUuMzc3NSA0LjM5NTctNy41MDk5IDEuODEyMi0xLjk2NTMgNC4wNDAyLTMuNzM2MyA2LjU3MDctNC41OTgzIDIuMzY2Ny0wLjgwNjIgNS4wNjA0LTAuOTIzMDQgNy40OTI5LTAuMzQ1IDEuNzAyIDAuNDA0NDMgMy4zNTMzIDEuMzIwNCA0LjU3MzUgMi41NzM5IDEuNTc0NiAxLjYxNzYgMi45MjY2IDMuNzQzOCAzLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTEzMS40NCA0MC42ODFjMTAuNzY4IDMuNjUwOCAxMS4zNSAzLjk0OTYgMTIuNTggNS40NjEyIDEuMzI1OCAxLjYyOTUgMS4zNjcgMC45NTI4MiA0LjU1NDYgMTYuOTU3IDAgMCAyLjIyNTcgOS4yMzYgMi42NTA2IDE0LjM4NCAwLjAyMzkgMC4yOTAyNC0wLjE2MDIgMC44NTg4Ni0wLjE2MDIgMC44NTg4Ni0wLjIwOTQyIDEuMTIzMy0xLjE4MTUgMi43MDkyLTIuMDg2MiAzLjQwMzQtMi43OTM4IDIuMTQzNy02LjU1ODcgMS40ODMzLTguNTUzNS0xLjUwMDctMC40MTk4NS0wLjYyODA1LTAuNDY4MjUtMC44MzY5NS0zLjA4MDktMTMuNDM2bC0yLjY1MzYtMTIuNzk4LTAuMTkxMi0wLjcxMjYyLTkuODUzOS01LjY2NDQtMS4wOTQzLTUuMzYwMnoiIHN0cm9rZS13aWR0aD0iLjEzOTMzIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.51815" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="39" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTMzLjUxbW0iIGhlaWdodD0iMTM1Ljc4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEzMy41MSAxMzUuNzgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM4LjYxMyAtODUuODA4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utd2lkdGg9IjguNjc4Ij48cGF0aCBkPSJtNTkuNjcxIDE2OS4yOS0xNS42NzQtMy45ODY2IDQuMzg0NS0xNS41NjcgMzQuNDA5LTE5Ljg2Ni0zNC40MDktMTkuODY2LTQuMzg0NS0xNS41NjcgMTUuNjc0LTMuOTg2NiA0NS42OTggMjYuMzg0IDQ1LjY5OC0yNi4zODQgMTUuNjc0IDMuOTg2Ni00LjM4NDUgMTUuNTY3LTM0LjQwOSAxOS44NjYgMzQuNDA5IDE5Ljg2NiA0LjM4NDUgMTUuNTY3LTE1LjY3NCAzLjk4NjYtNDUuNjk4LTI2LjM4NHoiLz48cGF0aCBkPSJtMTA1LjM3IDE2NC40OS01Ni45ODggMzIuOTAyLTQuMzg0NSAxNS41NjcgMTUuNjc0IDMuOTg2NiA0NS42OTgtMjYuMzg0IDQ1LjY5OCAyNi4zODQgMTUuNjc0LTMuOTg2Ni00LjM4NDUtMTUuNTY3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTczLjAybW0iIGhlaWdodD0iMjEwLjYxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3My4wMiAyMTAuNjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzLjgyNzUpIj48cGF0aCBkPSJtMCAxMzkuNjV2MTkuMTEyaDQxLjIzNXYxNi4wMDhoNDEuMjM1djE2LjAwN2g0MS4yMzV2MTYuMDA4aDQ5LjMxOHYtMTkuMTEyaC00MS4yMzV2LTE2LjAwN2gtNDEuMjM1di0xNi4wMDhoLTQxLjIzNXYtMTYuMDA4eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZD0ibTg5LjY2MSA3Ni4yODEtMTUuMTQyIDYuNTUwMmMtNS42NzUgMi40NTUxLTExLjU2OSAxLjM2OTMtMTMuMjE0LTIuNDM0Ny0xLjY0NTYtMy44MDQgMS41OTg0LTguODQzMSA3LjI3MzYtMTEuMjk5bDIxLjIyOS05LjE4MzhjMCA5LjkxNS0wLjE0NzE5IDkuMTgzOC0wLjE0NzE5IDE2LjM2N3oiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjg5OSIvPjxwYXRoIGQ9Im0xMTguOTQgOTkuNjk4YzIuNzc4MyAyMC4zMjMgNS44MDExIDM2LjI4MyA4LjU4ODggNTYuODA2IDAuMzkyMyAxLjgyNDcgMC4yNjA5MyAzLjI3NjQtMC40NTYwMSA1LjA1MzktMC40Njk1NyAxLjE2MTYtMC43NjcyNiAxLjY4NDItMS4zMjU0IDIuMzIyMy0yLjQ5NDggMi44NTE5LTYuMzQ2IDMuNzY4OS05LjgxMTEgMi4zMzU4LTAuNTUwNi0wLjIyNzY1LTEuMzMyNS0wLjY2MTUyLTEuNzM3Ny0wLjk2NDM3LTEuNjQyMi0xLjIyNzMtMi43MjEzLTIuOTA5OS0zLjM2MDMtNS4yMzk4LTAuMjE5NzgtMC44MDEyOS00LjE3MzktMzQuNTktNi45MzQ1LTU0LjE3OXoiIHN0cm9rZS13aWR0aD0iLjE2MTY2Ii8+PHBhdGggZD0ibTExMy4yIDI4Ljg1MmMwLjU2MjQzLTAuMDA4NSAxLjA5MzQgMC4wMjQ2NiAxLjQ4MjEgMC4xMDY0NSAwLjQyMTQ2IDAuMDg4NjggMS4xMTA3IDAuMzAzMjYgMS41MzIyIDAuNDc2OTcgMC40MjE0NiAwLjE3MzcxIDYuNDk1OSAzLjYzNTcgMTMuNDk4IDcuNjkzMSAxMC40NDQgNi4wNTE1IDEyLjk3NSA3LjUxNTIgMTQuMDE3IDguNjcyM2wtMTYuMDQ0IDAuMDAxNnYzLjU2MzZjLTMuMDAxLTEuNzI4Ni01LjQ2OTktMy4wOTg5LTUuNTQ1NC0zLjA3MzctMC4wOTY2IDAuMDMyMi0wLjE2NTk0IDUuNDY5Ni0wLjIxMjkxIDE2LjY4NWwtMC4wNjk4IDIxLjI4NnMtMC4zMDgwNCAzLjA4NDMtMS4wMjYxIDQuNDEyOWMtMC42MzU4MSAxLjE3NjQtMC45NzIyOSAyLjExMjctMi43NzExIDIuOTAwOS02LjgxNTQgMi45ODY1LTE2LjIzMSA3LjIzNDMtMjQuNTI2IDEwLjEzOC01LjA2NDcgMS43NzI2LTEyLjY2NiA0LjE1NjQtMTIuNDAzIDkuNjY4NmwwLjk0NzkzIDE5Ljg5M2MwLjcwMzk5IDE0Ljc3NC0xLjYyMzkgMTcuMDcxLTIuMDEzNiAxNy44NjctMC45NjU3NiAxLjk3MjUtMy4yMDcyIDMuNjI1OC01LjM3MDIgMy45NjE1LTEuMTQ1OCAwLjE3Nzc4LTEuNTI3NCAwLjE2Njk4LTIuNjQ3NC0wLjA3NTQtMS40NDM4LTAuMzEyNjgtMi41OTAyLTAuOTU0OTMtMy42OTQzLTIuMDY5MS0xLjA0OTctMS4wNTkzLTEuNTk3Ni0yLjAwMzMtMS45NDM2LTMuMzQ5Ny0wLjQ3MjYxLTEuODM5LTAuNzUzNTEgMC45NzQ0Ny0xLjg5OC0yNi45OTgtMS4xNDQ2LTMyLjkwNS0wLjUwNjgxLTI1LjYxNCAyMS41ODItMzQuODgzIDAgMCA1LjQzMDgtMS45Njg2IDguMDQ1Mi0zLjEzOTcgMS40OTg5LTAuNjcxNDQgMy40ODM1LTEuODQxIDMuNDgzNS0zLjQ4NDZ2LTIxLjc0NmM3LjhlLTQgLTAuNzgwMiAyZS0zIC00LjM3MTMgMC04LjQwODN2LTExLjIyN2MwLjA4MzItMS4zNjg3IDEuMDM3NS0xLjc3MjEgNi44ODQzLTUuMTQ3IDIuOTQ4LTEuNzAxNiA1LjcwNjctMy4yMTcxIDYuMTMwNC0zLjM2ODMgMC42MDAwMi0wLjIxNDA4IDEuNjI1Mi0wLjM0NDM5IDIuNTYyNi0wLjM1ODYzeiIgc3Ryb2tlLXdpZHRoPSIuMTM5MzMiLz48cGF0aCBkPSJtMTIwLjE3IDUuNTk3MWMwLjQyMTk0IDQuMDMyMy0xLjA1OTUgOC4zMjA2LTMuMzI4NCAxMS42OTktMS4zNDk2IDIuMDA5My0zLjMxMDIgMy41OTUzLTUuMzI0NCA0LjkzNzUtMi42NDQ4IDEuNzYyNS01LjU2NzIgMy4yOTE1LTguNjc1MiAzLjk1NjctMS4xODk2IDAuMjU0NTgtMi41MDE2IDAuMzgwMjItMy42NDk0LTAuMDIyOC0xLjQzNDQtMC41MDM2NS0yLjcyNjEtMS41Njk0LTMuNTc3NC0yLjgyOS0xLjI5NzQtMS45MTk1LTEuNjg4OC00LjM2NjEtMS45Njc3LTYuNjY2LTAuMjg4NjYtMi4zNzk5LTAuMzUxOS00Ljg4NTcgMC4zMjgxMi03LjE4NDcgMC44MjI3NS0yLjc4MTUgMi40Mjk0LTUuMzc3NSA0LjM5NTctNy41MDk5IDEuODEyMi0xLjk2NTMgNC4wNDAyLTMuNzM2MyA2LjU3MDctNC41OTgzIDIuMzY2Ny0wLjgwNjIgNS4wNjA0LTAuOTIzMDQgNy40OTI5LTAuMzQ1IDEuNzAyIDAuNDA0NDMgMy4zNTMzIDEuMzIwNCA0LjU3MzUgMi41NzM5IDEuNTc0NiAxLjYxNzYgMi45MjY2IDMuNzQzOCAzLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTEzMS40NCA0MC42ODFjMTAuNzY4IDMuNjUwOCAxMS4zNSAzLjk0OTYgMTIuNTggNS40NjEyIDEuMzI1OCAxLjYyOTUgMS4zNjcgMC45NTI4MiA0LjU1NDYgMTYuOTU3IDAgMCAyLjIyNTcgOS4yMzYgMi42NTA2IDE0LjM4NCAwLjAyMzkgMC4yOTAyNC0wLjE2MDIgMC44NTg4Ni0wLjE2MDIgMC44NTg4Ni0wLjIwOTQyIDEuMTIzMy0xLjE4MTUgMi43MDkyLTIuMDg2MiAzLjQwMzQtMi43OTM4IDIuMTQzNy02LjU1ODcgMS40ODMzLTguNTUzNS0xLjUwMDctMC40MTk4NS0wLjYyODA1LTAuNDY4MjUtMC44MzY5NS0zLjA4MDktMTMuNDM2bC0yLjY1MzYtMTIuNzk4LTAuMTkxMi0wLjcxMjYyLTkuODUzOS01LjY2NDQtMS4wOTQzLTUuMzYwMnoiIHN0cm9rZS13aWR0aD0iLjEzOTMzIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.51815" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="40" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTUzLjc5bW0iIGhlaWdodD0iMTUzLjc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1My43OSAxNTMuNzkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI5LjcxOSAtNzEuODY4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIj48Y2lyY2xlIGN4PSIxMDYuNjEiIGN5PSIxNDguNzYiIHI9IjQ3LjczMyIgc3Ryb2tlLXdpZHRoPSIxNSIvPjxwYXRoIGQ9Im0xMDYuNjEgNzEuODY4djI5LjE2MW0wIDk1LjQ2NnYyOS4xNjEiIHN0cm9rZS13aWR0aD0iOC4wNzc5Ii8+PHBhdGggZD0ibTE4My41MSAxNDguNzZoLTI5LjE2MW0tOTUuNDY2IDFlLTUgLTI5LjE2MS0xZS01IiBzdHJva2Utd2lkdGg9IjguMDc3OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="41" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="42" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzcuNjYxbW0iIGhlaWdodD0iMTcxLjkxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDc3LjY2MSAxNzEuOTEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM3LjgyIDE1NC44NSkiPjxyZWN0IHg9IjQzLjAzNSIgeT0iMTMyLjg1IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTE3LjAzIDJlLTYgNS45NjcxIDIyLjI3NiAyMi4yNzYgOC43ODc2LTguNzg3Ni0xOS40NTYtMTkuNDU2eiIvPjxwYXRoIGQ9Im0xOTIuNjcgMTE3LjAzdjUuOTY3MWwtMjIuMjc2IDIyLjI3Ni04Ljc4NzYtOC43ODc2IDE5LjQ1Ni0xOS40NTZ6Ii8+PHJlY3QgdHJhbnNmb3JtPSJzY2FsZSgxLC0xKSIgeD0iNDMuMDM1IiB5PSItMTc4Ljg4IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTk0LjY5IDJlLTYgLTUuOTY3MSAyMi4yNzYtMjIuMjc2IDguNzg3NiA4Ljc4NzYtMTkuNDU2IDE5LjQ1NnoiLz48cGF0aCBkPSJtMTkyLjY3IDE5NC42OXYtNS45NjcxbC0yMi4yNzYtMjIuMjc2LTguNzg3NiA4Ljc4NzYgMTkuNDU2IDE5LjQ1NnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.52982" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="43" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE5LjU3bW0iIGhlaWdodD0iMTE3Ljg2bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExOS41NyAxMTcuODYiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxLjQ0NyAtODguNjcxKSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48cGF0aCBkPSJtOTIuMDA5IDg4LjY3MS0xMS43NDQgNDEuOTE0aDE3Ljk1M2wxLjAzMy00MS45MTR6bS0xNy4wMzYgNjAuNzk4LTE1Ljk4OSA1Ny4wNjVoMzcuMzYybDEuNDA2Ni01Ny4wNjV6IiBzdHJva2Utd2lkdGg9IjIwLjk1MSIvPjxwYXRoIGQ9Im0xMDMuMjEgODguNjcxIDEuMDMzIDQxLjkxNGgxNy45NTNsLTExLjc0NC00MS45MTR6bTEuNDk4NiA2MC43OTggMS40MDY2IDU3LjA2NWgzNy4zNjJsLTE1Ljk5LTU3LjA2NXoiIHN0cm9rZS13aWR0aD0iMjAuOTUxIi8+PHBhdGggZD0ibTQxLjQ0NyAxMzUuNDl2OS4wNzU5aDE1Ljc0N3YxMy40NDFoMTAuNTc2bDIuMDkzOS0xMy40NDFoNjIuNzM4bDIuMDkzOSAxMy40NDFoMTAuNTc2di0xMy40NDFoMTUuNzQ3di05LjA3NTl6IiBzdHJva2Utd2lkdGg9IjE4LjYzNiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.47835" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="44" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTI1LjExbW0iIGhlaWdodD0iMTI0LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyNS4xMSAxMjQuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyLjI4MSAtODMuODgpIj48ZyBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im03My4yNjMgODMuODgtMzAuOTgyIDMxLjkzNnY5Mi44NzhoMzIuMjMydi04Mi42NTFzMTIuMTAzLTE3LjE0IDIzLjMwMy0xNy4xNGgxNC4wNDRjMTEuMTA0IDAgMjMuMzAzIDE3LjE0IDIzLjMwMyAxNy4xNHY4Mi42NTFoMzIuMjMydi05Mi44NzhsLTMwLjk4Mi0zMS45MzZ6IiBzdHJva2Utd2lkdGg9IjIwLjE3MyIvPjxwYXRoIGQ9Im0xMDIuMzEgMTU4LjI2Yy00LjAzNzggMC04LjQwMDkgNi4xNzg4LTguNDAwOSA2LjE3ODh2MzEuMTg4aDIxLjg2NXYtMzEuMTg4cy00LjM5NzgtNi4xNzg4LTguNDAwOS02LjE3ODhoLTUuMDYyN3oiIHN0cm9rZS13aWR0aD0iOS42NTI2Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,-0.20000000000000001" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.41058" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="45" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTczLjAybW0iIGhlaWdodD0iMjEwLjYxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3My4wMiAyMTAuNjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzLjgyNzUpIj48cGF0aCBkPSJtMCAxMzkuNjV2MTkuMTEyaDQxLjIzNXYxNi4wMDhoNDEuMjM1djE2LjAwN2g0MS4yMzV2MTYuMDA4aDQ5LjMxOHYtMTkuMTEyaC00MS4yMzV2LTE2LjAwN2gtNDEuMjM1di0xNi4wMDhoLTQxLjIzNXYtMTYuMDA4eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZD0ibTg5LjY2MSA3Ni4yODEtMTUuMTQyIDYuNTUwMmMtNS42NzUgMi40NTUxLTExLjU2OSAxLjM2OTMtMTMuMjE0LTIuNDM0Ny0xLjY0NTYtMy44MDQgMS41OTg0LTguODQzMSA3LjI3MzYtMTEuMjk5bDIxLjIyOS05LjE4MzhjMCA5LjkxNS0wLjE0NzE5IDkuMTgzOC0wLjE0NzE5IDE2LjM2N3oiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjg5OSIvPjxwYXRoIGQ9Im0xMTguOTQgOTkuNjk4YzIuNzc4MyAyMC4zMjMgNS44MDExIDM2LjI4MyA4LjU4ODggNTYuODA2IDAuMzkyMyAxLjgyNDcgMC4yNjA5MyAzLjI3NjQtMC40NTYwMSA1LjA1MzktMC40Njk1NyAxLjE2MTYtMC43NjcyNiAxLjY4NDItMS4zMjU0IDIuMzIyMy0yLjQ5NDggMi44NTE5LTYuMzQ2IDMuNzY4OS05LjgxMTEgMi4zMzU4LTAuNTUwNi0wLjIyNzY1LTEuMzMyNS0wLjY2MTUyLTEuNzM3Ny0wLjk2NDM3LTEuNjQyMi0xLjIyNzMtMi43MjEzLTIuOTA5OS0zLjM2MDMtNS4yMzk4LTAuMjE5NzgtMC44MDEyOS00LjE3MzktMzQuNTktNi45MzQ1LTU0LjE3OXoiIHN0cm9rZS13aWR0aD0iLjE2MTY2Ii8+PHBhdGggZD0ibTExMy4yIDI4Ljg1MmMwLjU2MjQzLTAuMDA4NSAxLjA5MzQgMC4wMjQ2NiAxLjQ4MjEgMC4xMDY0NSAwLjQyMTQ2IDAuMDg4NjggMS4xMTA3IDAuMzAzMjYgMS41MzIyIDAuNDc2OTcgMC40MjE0NiAwLjE3MzcxIDYuNDk1OSAzLjYzNTcgMTMuNDk4IDcuNjkzMSAxMC40NDQgNi4wNTE1IDEyLjk3NSA3LjUxNTIgMTQuMDE3IDguNjcyM2wtMTYuMDQ0IDAuMDAxNnYzLjU2MzZjLTMuMDAxLTEuNzI4Ni01LjQ2OTktMy4wOTg5LTUuNTQ1NC0zLjA3MzctMC4wOTY2IDAuMDMyMi0wLjE2NTk0IDUuNDY5Ni0wLjIxMjkxIDE2LjY4NWwtMC4wNjk4IDIxLjI4NnMtMC4zMDgwNCAzLjA4NDMtMS4wMjYxIDQuNDEyOWMtMC42MzU4MSAxLjE3NjQtMC45NzIyOSAyLjExMjctMi43NzExIDIuOTAwOS02LjgxNTQgMi45ODY1LTE2LjIzMSA3LjIzNDMtMjQuNTI2IDEwLjEzOC01LjA2NDcgMS43NzI2LTEyLjY2NiA0LjE1NjQtMTIuNDAzIDkuNjY4NmwwLjk0NzkzIDE5Ljg5M2MwLjcwMzk5IDE0Ljc3NC0xLjYyMzkgMTcuMDcxLTIuMDEzNiAxNy44NjctMC45NjU3NiAxLjk3MjUtMy4yMDcyIDMuNjI1OC01LjM3MDIgMy45NjE1LTEuMTQ1OCAwLjE3Nzc4LTEuNTI3NCAwLjE2Njk4LTIuNjQ3NC0wLjA3NTQtMS40NDM4LTAuMzEyNjgtMi41OTAyLTAuOTU0OTMtMy42OTQzLTIuMDY5MS0xLjA0OTctMS4wNTkzLTEuNTk3Ni0yLjAwMzMtMS45NDM2LTMuMzQ5Ny0wLjQ3MjYxLTEuODM5LTAuNzUzNTEgMC45NzQ0Ny0xLjg5OC0yNi45OTgtMS4xNDQ2LTMyLjkwNS0wLjUwNjgxLTI1LjYxNCAyMS41ODItMzQuODgzIDAgMCA1LjQzMDgtMS45Njg2IDguMDQ1Mi0zLjEzOTcgMS40OTg5LTAuNjcxNDQgMy40ODM1LTEuODQxIDMuNDgzNS0zLjQ4NDZ2LTIxLjc0NmM3LjhlLTQgLTAuNzgwMiAyZS0zIC00LjM3MTMgMC04LjQwODN2LTExLjIyN2MwLjA4MzItMS4zNjg3IDEuMDM3NS0xLjc3MjEgNi44ODQzLTUuMTQ3IDIuOTQ4LTEuNzAxNiA1LjcwNjctMy4yMTcxIDYuMTMwNC0zLjM2ODMgMC42MDAwMi0wLjIxNDA4IDEuNjI1Mi0wLjM0NDM5IDIuNTYyNi0wLjM1ODYzeiIgc3Ryb2tlLXdpZHRoPSIuMTM5MzMiLz48cGF0aCBkPSJtMTIwLjE3IDUuNTk3MWMwLjQyMTk0IDQuMDMyMy0xLjA1OTUgOC4zMjA2LTMuMzI4NCAxMS42OTktMS4zNDk2IDIuMDA5My0zLjMxMDIgMy41OTUzLTUuMzI0NCA0LjkzNzUtMi42NDQ4IDEuNzYyNS01LjU2NzIgMy4yOTE1LTguNjc1MiAzLjk1NjctMS4xODk2IDAuMjU0NTgtMi41MDE2IDAuMzgwMjItMy42NDk0LTAuMDIyOC0xLjQzNDQtMC41MDM2NS0yLjcyNjEtMS41Njk0LTMuNTc3NC0yLjgyOS0xLjI5NzQtMS45MTk1LTEuNjg4OC00LjM2NjEtMS45Njc3LTYuNjY2LTAuMjg4NjYtMi4zNzk5LTAuMzUxOS00Ljg4NTcgMC4zMjgxMi03LjE4NDcgMC44MjI3NS0yLjc4MTUgMi40Mjk0LTUuMzc3NSA0LjM5NTctNy41MDk5IDEuODEyMi0xLjk2NTMgNC4wNDAyLTMuNzM2MyA2LjU3MDctNC41OTgzIDIuMzY2Ny0wLjgwNjIgNS4wNjA0LTAuOTIzMDQgNy40OTI5LTAuMzQ1IDEuNzAyIDAuNDA0NDMgMy4zNTMzIDEuMzIwNCA0LjU3MzUgMi41NzM5IDEuNTc0NiAxLjYxNzYgMi45MjY2IDMuNzQzOCAzLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTEzMS40NCA0MC42ODFjMTAuNzY4IDMuNjUwOCAxMS4zNSAzLjk0OTYgMTIuNTggNS40NjEyIDEuMzI1OCAxLjYyOTUgMS4zNjcgMC45NTI4MiA0LjU1NDYgMTYuOTU3IDAgMCAyLjIyNTcgOS4yMzYgMi42NTA2IDE0LjM4NCAwLjAyMzkgMC4yOTAyNC0wLjE2MDIgMC44NTg4Ni0wLjE2MDIgMC44NTg4Ni0wLjIwOTQyIDEuMTIzMy0xLjE4MTUgMi43MDkyLTIuMDg2MiAzLjQwMzQtMi43OTM4IDIuMTQzNy02LjU1ODcgMS40ODMzLTguNTUzNS0xLjUwMDctMC40MTk4NS0wLjYyODA1LTAuNDY4MjUtMC44MzY5NS0zLjA4MDktMTMuNDM2bC0yLjY1MzYtMTIuNzk4LTAuMTkxMi0wLjcxMjYyLTkuODUzOS01LjY2NDQtMS4wOTQzLTUuMzYwMnoiIHN0cm9rZS13aWR0aD0iLjEzOTMzIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.51815" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="46" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTMzLjUxbW0iIGhlaWdodD0iMTM1Ljc4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEzMy41MSAxMzUuNzgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM4LjYxMyAtODUuODA4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utd2lkdGg9IjguNjc4Ij48cGF0aCBkPSJtNTkuNjcxIDE2OS4yOS0xNS42NzQtMy45ODY2IDQuMzg0NS0xNS41NjcgMzQuNDA5LTE5Ljg2Ni0zNC40MDktMTkuODY2LTQuMzg0NS0xNS41NjcgMTUuNjc0LTMuOTg2NiA0NS42OTggMjYuMzg0IDQ1LjY5OC0yNi4zODQgMTUuNjc0IDMuOTg2Ni00LjM4NDUgMTUuNTY3LTM0LjQwOSAxOS44NjYgMzQuNDA5IDE5Ljg2NiA0LjM4NDUgMTUuNTY3LTE1LjY3NCAzLjk4NjYtNDUuNjk4LTI2LjM4NHoiLz48cGF0aCBkPSJtMTA1LjM3IDE2NC40OS01Ni45ODggMzIuOTAyLTQuMzg0NSAxNS41NjcgMTUuNjc0IDMuOTg2NiA0NS42OTgtMjYuMzg0IDQ1LjY5OCAyNi4zODQgMTUuNjc0LTMuOTg2Ni00LjM4NDUtMTUuNTY3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="47" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTUzLjc5bW0iIGhlaWdodD0iMTUzLjc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1My43OSAxNTMuNzkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI5LjcxOSAtNzEuODY4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIj48Y2lyY2xlIGN4PSIxMDYuNjEiIGN5PSIxNDguNzYiIHI9IjQ3LjczMyIgc3Ryb2tlLXdpZHRoPSIxNSIvPjxwYXRoIGQ9Im0xMDYuNjEgNzEuODY4djI5LjE2MW0wIDk1LjQ2NnYyOS4xNjEiIHN0cm9rZS13aWR0aD0iOC4wNzc5Ii8+PHBhdGggZD0ibTE4My41MSAxNDguNzZoLTI5LjE2MW0tOTUuNDY2IDFlLTUgLTI5LjE2MS0xZS01IiBzdHJva2Utd2lkdGg9IjguMDc3OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="48" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="49" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzcuNjYxbW0iIGhlaWdodD0iMTcxLjkxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDc3LjY2MSAxNzEuOTEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM3LjgyIDE1NC44NSkiPjxyZWN0IHg9IjQzLjAzNSIgeT0iMTMyLjg1IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTE3LjAzIDJlLTYgNS45NjcxIDIyLjI3NiAyMi4yNzYgOC43ODc2LTguNzg3Ni0xOS40NTYtMTkuNDU2eiIvPjxwYXRoIGQ9Im0xOTIuNjcgMTE3LjAzdjUuOTY3MWwtMjIuMjc2IDIyLjI3Ni04Ljc4NzYtOC43ODc2IDE5LjQ1Ni0xOS40NTZ6Ii8+PHJlY3QgdHJhbnNmb3JtPSJzY2FsZSgxLC0xKSIgeD0iNDMuMDM1IiB5PSItMTc4Ljg4IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTk0LjY5IDJlLTYgLTUuOTY3MSAyMi4yNzYtMjIuMjc2IDguNzg3NiA4Ljc4NzYtMTkuNDU2IDE5LjQ1NnoiLz48cGF0aCBkPSJtMTkyLjY3IDE5NC42OXYtNS45NjcxbC0yMi4yNzYtMjIuMjc2LTguNzg3NiA4Ljc4NzYgMTkuNDU2IDE5LjQ1NnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.52982" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTMzLjUxbW0iIGhlaWdodD0iMTM1Ljc4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEzMy41MSAxMzUuNzgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM4LjYxMyAtODUuODA4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utd2lkdGg9IjguNjc4Ij48cGF0aCBkPSJtNTkuNjcxIDE2OS4yOS0xNS42NzQtMy45ODY2IDQuMzg0NS0xNS41NjcgMzQuNDA5LTE5Ljg2Ni0zNC40MDktMTkuODY2LTQuMzg0NS0xNS41NjcgMTUuNjc0LTMuOTg2NiA0NS42OTggMjYuMzg0IDQ1LjY5OC0yNi4zODQgMTUuNjc0IDMuOTg2Ni00LjM4NDUgMTUuNTY3LTM0LjQwOSAxOS44NjYgMzQuNDA5IDE5Ljg2NiA0LjM4NDUgMTUuNTY3LTE1LjY3NCAzLjk4NjYtNDUuNjk4LTI2LjM4NHoiLz48cGF0aCBkPSJtMTA1LjM3IDE2NC40OS01Ni45ODggMzIuOTAyLTQuMzg0NSAxNS41NjcgMTUuNjc0IDMuOTg2NiA0NS42OTgtMjYuMzg0IDQ1LjY5OCAyNi4zODQgMTUuNjc0LTMuOTg2Ni00LjM4NDUtMTUuNTY3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="50" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE5LjU3bW0iIGhlaWdodD0iMTE3Ljg2bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExOS41NyAxMTcuODYiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxLjQ0NyAtODguNjcxKSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48cGF0aCBkPSJtOTIuMDA5IDg4LjY3MS0xMS43NDQgNDEuOTE0aDE3Ljk1M2wxLjAzMy00MS45MTR6bS0xNy4wMzYgNjAuNzk4LTE1Ljk4OSA1Ny4wNjVoMzcuMzYybDEuNDA2Ni01Ny4wNjV6IiBzdHJva2Utd2lkdGg9IjIwLjk1MSIvPjxwYXRoIGQ9Im0xMDMuMjEgODguNjcxIDEuMDMzIDQxLjkxNGgxNy45NTNsLTExLjc0NC00MS45MTR6bTEuNDk4NiA2MC43OTggMS40MDY2IDU3LjA2NWgzNy4zNjJsLTE1Ljk5LTU3LjA2NXoiIHN0cm9rZS13aWR0aD0iMjAuOTUxIi8+PHBhdGggZD0ibTQxLjQ0NyAxMzUuNDl2OS4wNzU5aDE1Ljc0N3YxMy40NDFoMTAuNTc2bDIuMDkzOS0xMy40NDFoNjIuNzM4bDIuMDkzOSAxMy40NDFoMTAuNTc2di0xMy40NDFoMTUuNzQ3di05LjA3NTl6IiBzdHJva2Utd2lkdGg9IjE4LjYzNiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.47835" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="51" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTI1LjExbW0iIGhlaWdodD0iMTI0LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyNS4xMSAxMjQuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyLjI4MSAtODMuODgpIj48ZyBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im03My4yNjMgODMuODgtMzAuOTgyIDMxLjkzNnY5Mi44NzhoMzIuMjMydi04Mi42NTFzMTIuMTAzLTE3LjE0IDIzLjMwMy0xNy4xNGgxNC4wNDRjMTEuMTA0IDAgMjMuMzAzIDE3LjE0IDIzLjMwMyAxNy4xNHY4Mi42NTFoMzIuMjMydi05Mi44NzhsLTMwLjk4Mi0zMS45MzZ6IiBzdHJva2Utd2lkdGg9IjIwLjE3MyIvPjxwYXRoIGQ9Im0xMDIuMzEgMTU4LjI2Yy00LjAzNzggMC04LjQwMDkgNi4xNzg4LTguNDAwOSA2LjE3ODh2MzEuMTg4aDIxLjg2NXYtMzEuMTg4cy00LjM5NzgtNi4xNzg4LTguNDAwOS02LjE3ODhoLTUuMDYyN3oiIHN0cm9rZS13aWR0aD0iOS42NTI2Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,-0.20000000000000001" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.41058" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="52" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTczLjAybW0iIGhlaWdodD0iMjEwLjYxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3My4wMiAyMTAuNjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzLjgyNzUpIj48cGF0aCBkPSJtMCAxMzkuNjV2MTkuMTEyaDQxLjIzNXYxNi4wMDhoNDEuMjM1djE2LjAwN2g0MS4yMzV2MTYuMDA4aDQ5LjMxOHYtMTkuMTEyaC00MS4yMzV2LTE2LjAwN2gtNDEuMjM1di0xNi4wMDhoLTQxLjIzNXYtMTYuMDA4eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZD0ibTg5LjY2MSA3Ni4yODEtMTUuMTQyIDYuNTUwMmMtNS42NzUgMi40NTUxLTExLjU2OSAxLjM2OTMtMTMuMjE0LTIuNDM0Ny0xLjY0NTYtMy44MDQgMS41OTg0LTguODQzMSA3LjI3MzYtMTEuMjk5bDIxLjIyOS05LjE4MzhjMCA5LjkxNS0wLjE0NzE5IDkuMTgzOC0wLjE0NzE5IDE2LjM2N3oiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjg5OSIvPjxwYXRoIGQ9Im0xMTguOTQgOTkuNjk4YzIuNzc4MyAyMC4zMjMgNS44MDExIDM2LjI4MyA4LjU4ODggNTYuODA2IDAuMzkyMyAxLjgyNDcgMC4yNjA5MyAzLjI3NjQtMC40NTYwMSA1LjA1MzktMC40Njk1NyAxLjE2MTYtMC43NjcyNiAxLjY4NDItMS4zMjU0IDIuMzIyMy0yLjQ5NDggMi44NTE5LTYuMzQ2IDMuNzY4OS05LjgxMTEgMi4zMzU4LTAuNTUwNi0wLjIyNzY1LTEuMzMyNS0wLjY2MTUyLTEuNzM3Ny0wLjk2NDM3LTEuNjQyMi0xLjIyNzMtMi43MjEzLTIuOTA5OS0zLjM2MDMtNS4yMzk4LTAuMjE5NzgtMC44MDEyOS00LjE3MzktMzQuNTktNi45MzQ1LTU0LjE3OXoiIHN0cm9rZS13aWR0aD0iLjE2MTY2Ii8+PHBhdGggZD0ibTExMy4yIDI4Ljg1MmMwLjU2MjQzLTAuMDA4NSAxLjA5MzQgMC4wMjQ2NiAxLjQ4MjEgMC4xMDY0NSAwLjQyMTQ2IDAuMDg4NjggMS4xMTA3IDAuMzAzMjYgMS41MzIyIDAuNDc2OTcgMC40MjE0NiAwLjE3MzcxIDYuNDk1OSAzLjYzNTcgMTMuNDk4IDcuNjkzMSAxMC40NDQgNi4wNTE1IDEyLjk3NSA3LjUxNTIgMTQuMDE3IDguNjcyM2wtMTYuMDQ0IDAuMDAxNnYzLjU2MzZjLTMuMDAxLTEuNzI4Ni01LjQ2OTktMy4wOTg5LTUuNTQ1NC0zLjA3MzctMC4wOTY2IDAuMDMyMi0wLjE2NTk0IDUuNDY5Ni0wLjIxMjkxIDE2LjY4NWwtMC4wNjk4IDIxLjI4NnMtMC4zMDgwNCAzLjA4NDMtMS4wMjYxIDQuNDEyOWMtMC42MzU4MSAxLjE3NjQtMC45NzIyOSAyLjExMjctMi43NzExIDIuOTAwOS02LjgxNTQgMi45ODY1LTE2LjIzMSA3LjIzNDMtMjQuNTI2IDEwLjEzOC01LjA2NDcgMS43NzI2LTEyLjY2NiA0LjE1NjQtMTIuNDAzIDkuNjY4NmwwLjk0NzkzIDE5Ljg5M2MwLjcwMzk5IDE0Ljc3NC0xLjYyMzkgMTcuMDcxLTIuMDEzNiAxNy44NjctMC45NjU3NiAxLjk3MjUtMy4yMDcyIDMuNjI1OC01LjM3MDIgMy45NjE1LTEuMTQ1OCAwLjE3Nzc4LTEuNTI3NCAwLjE2Njk4LTIuNjQ3NC0wLjA3NTQtMS40NDM4LTAuMzEyNjgtMi41OTAyLTAuOTU0OTMtMy42OTQzLTIuMDY5MS0xLjA0OTctMS4wNTkzLTEuNTk3Ni0yLjAwMzMtMS45NDM2LTMuMzQ5Ny0wLjQ3MjYxLTEuODM5LTAuNzUzNTEgMC45NzQ0Ny0xLjg5OC0yNi45OTgtMS4xNDQ2LTMyLjkwNS0wLjUwNjgxLTI1LjYxNCAyMS41ODItMzQuODgzIDAgMCA1LjQzMDgtMS45Njg2IDguMDQ1Mi0zLjEzOTcgMS40OTg5LTAuNjcxNDQgMy40ODM1LTEuODQxIDMuNDgzNS0zLjQ4NDZ2LTIxLjc0NmM3LjhlLTQgLTAuNzgwMiAyZS0zIC00LjM3MTMgMC04LjQwODN2LTExLjIyN2MwLjA4MzItMS4zNjg3IDEuMDM3NS0xLjc3MjEgNi44ODQzLTUuMTQ3IDIuOTQ4LTEuNzAxNiA1LjcwNjctMy4yMTcxIDYuMTMwNC0zLjM2ODMgMC42MDAwMi0wLjIxNDA4IDEuNjI1Mi0wLjM0NDM5IDIuNTYyNi0wLjM1ODYzeiIgc3Ryb2tlLXdpZHRoPSIuMTM5MzMiLz48cGF0aCBkPSJtMTIwLjE3IDUuNTk3MWMwLjQyMTk0IDQuMDMyMy0xLjA1OTUgOC4zMjA2LTMuMzI4NCAxMS42OTktMS4zNDk2IDIuMDA5My0zLjMxMDIgMy41OTUzLTUuMzI0NCA0LjkzNzUtMi42NDQ4IDEuNzYyNS01LjU2NzIgMy4yOTE1LTguNjc1MiAzLjk1NjctMS4xODk2IDAuMjU0NTgtMi41MDE2IDAuMzgwMjItMy42NDk0LTAuMDIyOC0xLjQzNDQtMC41MDM2NS0yLjcyNjEtMS41Njk0LTMuNTc3NC0yLjgyOS0xLjI5NzQtMS45MTk1LTEuNjg4OC00LjM2NjEtMS45Njc3LTYuNjY2LTAuMjg4NjYtMi4zNzk5LTAuMzUxOS00Ljg4NTcgMC4zMjgxMi03LjE4NDcgMC44MjI3NS0yLjc4MTUgMi40Mjk0LTUuMzc3NSA0LjM5NTctNy41MDk5IDEuODEyMi0xLjk2NTMgNC4wNDAyLTMuNzM2MyA2LjU3MDctNC41OTgzIDIuMzY2Ny0wLjgwNjIgNS4wNjA0LTAuOTIzMDQgNy40OTI5LTAuMzQ1IDEuNzAyIDAuNDA0NDMgMy4zNTMzIDEuMzIwNCA0LjU3MzUgMi41NzM5IDEuNTc0NiAxLjYxNzYgMi45MjY2IDMuNzQzOCAzLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTEzMS40NCA0MC42ODFjMTAuNzY4IDMuNjUwOCAxMS4zNSAzLjk0OTYgMTIuNTggNS40NjEyIDEuMzI1OCAxLjYyOTUgMS4zNjcgMC45NTI4MiA0LjU1NDYgMTYuOTU3IDAgMCAyLjIyNTcgOS4yMzYgMi42NTA2IDE0LjM4NCAwLjAyMzkgMC4yOTAyNC0wLjE2MDIgMC44NTg4Ni0wLjE2MDIgMC44NTg4Ni0wLjIwOTQyIDEuMTIzMy0xLjE4MTUgMi43MDkyLTIuMDg2MiAzLjQwMzQtMi43OTM4IDIuMTQzNy02LjU1ODcgMS40ODMzLTguNTUzNS0xLjUwMDctMC40MTk4NS0wLjYyODA1LTAuNDY4MjUtMC44MzY5NS0zLjA4MDktMTMuNDM2bC0yLjY1MzYtMTIuNzk4LTAuMTkxMi0wLjcxMjYyLTkuODUzOS01LjY2NDQtMS4wOTQzLTUuMzYwMnoiIHN0cm9rZS13aWR0aD0iLjEzOTMzIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.51815" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="53" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTUzLjc5bW0iIGhlaWdodD0iMTUzLjc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1My43OSAxNTMuNzkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI5LjcxOSAtNzEuODY4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIj48Y2lyY2xlIGN4PSIxMDYuNjEiIGN5PSIxNDguNzYiIHI9IjQ3LjczMyIgc3Ryb2tlLXdpZHRoPSIxNSIvPjxwYXRoIGQ9Im0xMDYuNjEgNzEuODY4djI5LjE2MW0wIDk1LjQ2NnYyOS4xNjEiIHN0cm9rZS13aWR0aD0iOC4wNzc5Ii8+PHBhdGggZD0ibTE4My41MSAxNDguNzZoLTI5LjE2MW0tOTUuNDY2IDFlLTUgLTI5LjE2MS0xZS01IiBzdHJva2Utd2lkdGg9IjguMDc3OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="54" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="55" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzcuNjYxbW0iIGhlaWdodD0iMTcxLjkxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDc3LjY2MSAxNzEuOTEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM3LjgyIDE1NC44NSkiPjxyZWN0IHg9IjQzLjAzNSIgeT0iMTMyLjg1IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTE3LjAzIDJlLTYgNS45NjcxIDIyLjI3NiAyMi4yNzYgOC43ODc2LTguNzg3Ni0xOS40NTYtMTkuNDU2eiIvPjxwYXRoIGQ9Im0xOTIuNjcgMTE3LjAzdjUuOTY3MWwtMjIuMjc2IDIyLjI3Ni04Ljc4NzYtOC43ODc2IDE5LjQ1Ni0xOS40NTZ6Ii8+PHJlY3QgdHJhbnNmb3JtPSJzY2FsZSgxLC0xKSIgeD0iNDMuMDM1IiB5PSItMTc4Ljg4IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTk0LjY5IDJlLTYgLTUuOTY3MSAyMi4yNzYtMjIuMjc2IDguNzg3NiA4Ljc4NzYtMTkuNDU2IDE5LjQ1NnoiLz48cGF0aCBkPSJtMTkyLjY3IDE5NC42OXYtNS45NjcxbC0yMi4yNzYtMjIuMjc2LTguNzg3NiA4Ljc4NzYgMTkuNDU2IDE5LjQ1NnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.52982" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="56" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE5LjU3bW0iIGhlaWdodD0iMTE3Ljg2bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExOS41NyAxMTcuODYiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxLjQ0NyAtODguNjcxKSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48cGF0aCBkPSJtOTIuMDA5IDg4LjY3MS0xMS43NDQgNDEuOTE0aDE3Ljk1M2wxLjAzMy00MS45MTR6bS0xNy4wMzYgNjAuNzk4LTE1Ljk4OSA1Ny4wNjVoMzcuMzYybDEuNDA2Ni01Ny4wNjV6IiBzdHJva2Utd2lkdGg9IjIwLjk1MSIvPjxwYXRoIGQ9Im0xMDMuMjEgODguNjcxIDEuMDMzIDQxLjkxNGgxNy45NTNsLTExLjc0NC00MS45MTR6bTEuNDk4NiA2MC43OTggMS40MDY2IDU3LjA2NWgzNy4zNjJsLTE1Ljk5LTU3LjA2NXoiIHN0cm9rZS13aWR0aD0iMjAuOTUxIi8+PHBhdGggZD0ibTQxLjQ0NyAxMzUuNDl2OS4wNzU5aDE1Ljc0N3YxMy40NDFoMTAuNTc2bDIuMDkzOS0xMy40NDFoNjIuNzM4bDIuMDkzOSAxMy40NDFoMTAuNTc2di0xMy40NDFoMTUuNzQ3di05LjA3NTl6IiBzdHJva2Utd2lkdGg9IjE4LjYzNiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.47835" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="57" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTI1LjExbW0iIGhlaWdodD0iMTI0LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyNS4xMSAxMjQuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyLjI4MSAtODMuODgpIj48ZyBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im03My4yNjMgODMuODgtMzAuOTgyIDMxLjkzNnY5Mi44NzhoMzIuMjMydi04Mi42NTFzMTIuMTAzLTE3LjE0IDIzLjMwMy0xNy4xNGgxNC4wNDRjMTEuMTA0IDAgMjMuMzAzIDE3LjE0IDIzLjMwMyAxNy4xNHY4Mi42NTFoMzIuMjMydi05Mi44NzhsLTMwLjk4Mi0zMS45MzZ6IiBzdHJva2Utd2lkdGg9IjIwLjE3MyIvPjxwYXRoIGQ9Im0xMDIuMzEgMTU4LjI2Yy00LjAzNzggMC04LjQwMDkgNi4xNzg4LTguNDAwOSA2LjE3ODh2MzEuMTg4aDIxLjg2NXYtMzEuMTg4cy00LjM5NzgtNi4xNzg4LTguNDAwOS02LjE3ODhoLTUuMDYyN3oiIHN0cm9rZS13aWR0aD0iOS42NTI2Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,-0.20000000000000001" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.41058" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="58" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTczLjAybW0iIGhlaWdodD0iMjEwLjYxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3My4wMiAyMTAuNjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzLjgyNzUpIj48cGF0aCBkPSJtMCAxMzkuNjV2MTkuMTEyaDQxLjIzNXYxNi4wMDhoNDEuMjM1djE2LjAwN2g0MS4yMzV2MTYuMDA4aDQ5LjMxOHYtMTkuMTEyaC00MS4yMzV2LTE2LjAwN2gtNDEuMjM1di0xNi4wMDhoLTQxLjIzNXYtMTYuMDA4eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZD0ibTg5LjY2MSA3Ni4yODEtMTUuMTQyIDYuNTUwMmMtNS42NzUgMi40NTUxLTExLjU2OSAxLjM2OTMtMTMuMjE0LTIuNDM0Ny0xLjY0NTYtMy44MDQgMS41OTg0LTguODQzMSA3LjI3MzYtMTEuMjk5bDIxLjIyOS05LjE4MzhjMCA5LjkxNS0wLjE0NzE5IDkuMTgzOC0wLjE0NzE5IDE2LjM2N3oiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjg5OSIvPjxwYXRoIGQ9Im0xMTguOTQgOTkuNjk4YzIuNzc4MyAyMC4zMjMgNS44MDExIDM2LjI4MyA4LjU4ODggNTYuODA2IDAuMzkyMyAxLjgyNDcgMC4yNjA5MyAzLjI3NjQtMC40NTYwMSA1LjA1MzktMC40Njk1NyAxLjE2MTYtMC43NjcyNiAxLjY4NDItMS4zMjU0IDIuMzIyMy0yLjQ5NDggMi44NTE5LTYuMzQ2IDMuNzY4OS05LjgxMTEgMi4zMzU4LTAuNTUwNi0wLjIyNzY1LTEuMzMyNS0wLjY2MTUyLTEuNzM3Ny0wLjk2NDM3LTEuNjQyMi0xLjIyNzMtMi43MjEzLTIuOTA5OS0zLjM2MDMtNS4yMzk4LTAuMjE5NzgtMC44MDEyOS00LjE3MzktMzQuNTktNi45MzQ1LTU0LjE3OXoiIHN0cm9rZS13aWR0aD0iLjE2MTY2Ii8+PHBhdGggZD0ibTExMy4yIDI4Ljg1MmMwLjU2MjQzLTAuMDA4NSAxLjA5MzQgMC4wMjQ2NiAxLjQ4MjEgMC4xMDY0NSAwLjQyMTQ2IDAuMDg4NjggMS4xMTA3IDAuMzAzMjYgMS41MzIyIDAuNDc2OTcgMC40MjE0NiAwLjE3MzcxIDYuNDk1OSAzLjYzNTcgMTMuNDk4IDcuNjkzMSAxMC40NDQgNi4wNTE1IDEyLjk3NSA3LjUxNTIgMTQuMDE3IDguNjcyM2wtMTYuMDQ0IDAuMDAxNnYzLjU2MzZjLTMuMDAxLTEuNzI4Ni01LjQ2OTktMy4wOTg5LTUuNTQ1NC0zLjA3MzctMC4wOTY2IDAuMDMyMi0wLjE2NTk0IDUuNDY5Ni0wLjIxMjkxIDE2LjY4NWwtMC4wNjk4IDIxLjI4NnMtMC4zMDgwNCAzLjA4NDMtMS4wMjYxIDQuNDEyOWMtMC42MzU4MSAxLjE3NjQtMC45NzIyOSAyLjExMjctMi43NzExIDIuOTAwOS02LjgxNTQgMi45ODY1LTE2LjIzMSA3LjIzNDMtMjQuNTI2IDEwLjEzOC01LjA2NDcgMS43NzI2LTEyLjY2NiA0LjE1NjQtMTIuNDAzIDkuNjY4NmwwLjk0NzkzIDE5Ljg5M2MwLjcwMzk5IDE0Ljc3NC0xLjYyMzkgMTcuMDcxLTIuMDEzNiAxNy44NjctMC45NjU3NiAxLjk3MjUtMy4yMDcyIDMuNjI1OC01LjM3MDIgMy45NjE1LTEuMTQ1OCAwLjE3Nzc4LTEuNTI3NCAwLjE2Njk4LTIuNjQ3NC0wLjA3NTQtMS40NDM4LTAuMzEyNjgtMi41OTAyLTAuOTU0OTMtMy42OTQzLTIuMDY5MS0xLjA0OTctMS4wNTkzLTEuNTk3Ni0yLjAwMzMtMS45NDM2LTMuMzQ5Ny0wLjQ3MjYxLTEuODM5LTAuNzUzNTEgMC45NzQ0Ny0xLjg5OC0yNi45OTgtMS4xNDQ2LTMyLjkwNS0wLjUwNjgxLTI1LjYxNCAyMS41ODItMzQuODgzIDAgMCA1LjQzMDgtMS45Njg2IDguMDQ1Mi0zLjEzOTcgMS40OTg5LTAuNjcxNDQgMy40ODM1LTEuODQxIDMuNDgzNS0zLjQ4NDZ2LTIxLjc0NmM3LjhlLTQgLTAuNzgwMiAyZS0zIC00LjM3MTMgMC04LjQwODN2LTExLjIyN2MwLjA4MzItMS4zNjg3IDEuMDM3NS0xLjc3MjEgNi44ODQzLTUuMTQ3IDIuOTQ4LTEuNzAxNiA1LjcwNjctMy4yMTcxIDYuMTMwNC0zLjM2ODMgMC42MDAwMi0wLjIxNDA4IDEuNjI1Mi0wLjM0NDM5IDIuNTYyNi0wLjM1ODYzeiIgc3Ryb2tlLXdpZHRoPSIuMTM5MzMiLz48cGF0aCBkPSJtMTIwLjE3IDUuNTk3MWMwLjQyMTk0IDQuMDMyMy0xLjA1OTUgOC4zMjA2LTMuMzI4NCAxMS42OTktMS4zNDk2IDIuMDA5My0zLjMxMDIgMy41OTUzLTUuMzI0NCA0LjkzNzUtMi42NDQ4IDEuNzYyNS01LjU2NzIgMy4yOTE1LTguNjc1MiAzLjk1NjctMS4xODk2IDAuMjU0NTgtMi41MDE2IDAuMzgwMjItMy42NDk0LTAuMDIyOC0xLjQzNDQtMC41MDM2NS0yLjcyNjEtMS41Njk0LTMuNTc3NC0yLjgyOS0xLjI5NzQtMS45MTk1LTEuNjg4OC00LjM2NjEtMS45Njc3LTYuNjY2LTAuMjg4NjYtMi4zNzk5LTAuMzUxOS00Ljg4NTcgMC4zMjgxMi03LjE4NDcgMC44MjI3NS0yLjc4MTUgMi40Mjk0LTUuMzc3NSA0LjM5NTctNy41MDk5IDEuODEyMi0xLjk2NTMgNC4wNDAyLTMuNzM2MyA2LjU3MDctNC41OTgzIDIuMzY2Ny0wLjgwNjIgNS4wNjA0LTAuOTIzMDQgNy40OTI5LTAuMzQ1IDEuNzAyIDAuNDA0NDMgMy4zNTMzIDEuMzIwNCA0LjU3MzUgMi41NzM5IDEuNTc0NiAxLjYxNzYgMi45MjY2IDMuNzQzOCAzLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTEzMS40NCA0MC42ODFjMTAuNzY4IDMuNjUwOCAxMS4zNSAzLjk0OTYgMTIuNTggNS40NjEyIDEuMzI1OCAxLjYyOTUgMS4zNjcgMC45NTI4MiA0LjU1NDYgMTYuOTU3IDAgMCAyLjIyNTcgOS4yMzYgMi42NTA2IDE0LjM4NCAwLjAyMzkgMC4yOTAyNC0wLjE2MDIgMC44NTg4Ni0wLjE2MDIgMC44NTg4Ni0wLjIwOTQyIDEuMTIzMy0xLjE4MTUgMi43MDkyLTIuMDg2MiAzLjQwMzQtMi43OTM4IDIuMTQzNy02LjU1ODcgMS40ODMzLTguNTUzNS0xLjUwMDctMC40MTk4NS0wLjYyODA1LTAuNDY4MjUtMC44MzY5NS0zLjA4MDktMTMuNDM2bC0yLjY1MzYtMTIuNzk4LTAuMTkxMi0wLjcxMjYyLTkuODUzOS01LjY2NDQtMS4wOTQzLTUuMzYwMnoiIHN0cm9rZS13aWR0aD0iLjEzOTMzIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.51815" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="59" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTMzLjUxbW0iIGhlaWdodD0iMTM1Ljc4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEzMy41MSAxMzUuNzgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM4LjYxMyAtODUuODA4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utd2lkdGg9IjguNjc4Ij48cGF0aCBkPSJtNTkuNjcxIDE2OS4yOS0xNS42NzQtMy45ODY2IDQuMzg0NS0xNS41NjcgMzQuNDA5LTE5Ljg2Ni0zNC40MDktMTkuODY2LTQuMzg0NS0xNS41NjcgMTUuNjc0LTMuOTg2NiA0NS42OTggMjYuMzg0IDQ1LjY5OC0yNi4zODQgMTUuNjc0IDMuOTg2Ni00LjM4NDUgMTUuNTY3LTM0LjQwOSAxOS44NjYgMzQuNDA5IDE5Ljg2NiA0LjM4NDUgMTUuNTY3LTE1LjY3NCAzLjk4NjYtNDUuNjk4LTI2LjM4NHoiLz48cGF0aCBkPSJtMTA1LjM3IDE2NC40OS01Ni45ODggMzIuOTAyLTQuMzg0NSAxNS41NjcgMTUuNjc0IDMuOTg2NiA0NS42OTgtMjYuMzg0IDQ1LjY5OCAyNi4zODQgMTUuNjc0LTMuOTg2Ni00LjM4NDUtMTUuNTY3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTUzLjc5bW0iIGhlaWdodD0iMTUzLjc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1My43OSAxNTMuNzkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI5LjcxOSAtNzEuODY4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIj48Y2lyY2xlIGN4PSIxMDYuNjEiIGN5PSIxNDguNzYiIHI9IjQ3LjczMyIgc3Ryb2tlLXdpZHRoPSIxNSIvPjxwYXRoIGQ9Im0xMDYuNjEgNzEuODY4djI5LjE2MW0wIDk1LjQ2NnYyOS4xNjEiIHN0cm9rZS13aWR0aD0iOC4wNzc5Ii8+PHBhdGggZD0ibTE4My41MSAxNDguNzZoLTI5LjE2MW0tOTUuNDY2IDFlLTUgLTI5LjE2MS0xZS01IiBzdHJva2Utd2lkdGg9IjguMDc3OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="60" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTUzLjc5bW0iIGhlaWdodD0iMTUzLjc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1My43OSAxNTMuNzkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI5LjcxOSAtNzEuODY4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIj48Y2lyY2xlIGN4PSIxMDYuNjEiIGN5PSIxNDguNzYiIHI9IjQ3LjczMyIgc3Ryb2tlLXdpZHRoPSIxNSIvPjxwYXRoIGQ9Im0xMDYuNjEgNzEuODY4djI5LjE2MW0wIDk1LjQ2NnYyOS4xNjEiIHN0cm9rZS13aWR0aD0iOC4wNzc5Ii8+PHBhdGggZD0ibTE4My41MSAxNDguNzZoLTI5LjE2MW0tOTUuNDY2IDFlLTUgLTI5LjE2MS0xZS01IiBzdHJva2Utd2lkdGg9IjguMDc3OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="61" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="62" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzcuNjYxbW0iIGhlaWdodD0iMTcxLjkxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDc3LjY2MSAxNzEuOTEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM3LjgyIDE1NC44NSkiPjxyZWN0IHg9IjQzLjAzNSIgeT0iMTMyLjg1IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTE3LjAzIDJlLTYgNS45NjcxIDIyLjI3NiAyMi4yNzYgOC43ODc2LTguNzg3Ni0xOS40NTYtMTkuNDU2eiIvPjxwYXRoIGQ9Im0xOTIuNjcgMTE3LjAzdjUuOTY3MWwtMjIuMjc2IDIyLjI3Ni04Ljc4NzYtOC43ODc2IDE5LjQ1Ni0xOS40NTZ6Ii8+PHJlY3QgdHJhbnNmb3JtPSJzY2FsZSgxLC0xKSIgeD0iNDMuMDM1IiB5PSItMTc4Ljg4IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTk0LjY5IDJlLTYgLTUuOTY3MSAyMi4yNzYtMjIuMjc2IDguNzg3NiA4Ljc4NzYtMTkuNDU2IDE5LjQ1NnoiLz48cGF0aCBkPSJtMTkyLjY3IDE5NC42OXYtNS45NjcxbC0yMi4yNzYtMjIuMjc2LTguNzg3NiA4Ljc4NzYgMTkuNDU2IDE5LjQ1NnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.52982" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="63" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE5LjU3bW0iIGhlaWdodD0iMTE3Ljg2bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExOS41NyAxMTcuODYiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxLjQ0NyAtODguNjcxKSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48cGF0aCBkPSJtOTIuMDA5IDg4LjY3MS0xMS43NDQgNDEuOTE0aDE3Ljk1M2wxLjAzMy00MS45MTR6bS0xNy4wMzYgNjAuNzk4LTE1Ljk4OSA1Ny4wNjVoMzcuMzYybDEuNDA2Ni01Ny4wNjV6IiBzdHJva2Utd2lkdGg9IjIwLjk1MSIvPjxwYXRoIGQ9Im0xMDMuMjEgODguNjcxIDEuMDMzIDQxLjkxNGgxNy45NTNsLTExLjc0NC00MS45MTR6bTEuNDk4NiA2MC43OTggMS40MDY2IDU3LjA2NWgzNy4zNjJsLTE1Ljk5LTU3LjA2NXoiIHN0cm9rZS13aWR0aD0iMjAuOTUxIi8+PHBhdGggZD0ibTQxLjQ0NyAxMzUuNDl2OS4wNzU5aDE1Ljc0N3YxMy40NDFoMTAuNTc2bDIuMDkzOS0xMy40NDFoNjIuNzM4bDIuMDkzOSAxMy40NDFoMTAuNTc2di0xMy40NDFoMTUuNzQ3di05LjA3NTl6IiBzdHJva2Utd2lkdGg9IjE4LjYzNiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.47835" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="64" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTI1LjExbW0iIGhlaWdodD0iMTI0LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyNS4xMSAxMjQuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyLjI4MSAtODMuODgpIj48ZyBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im03My4yNjMgODMuODgtMzAuOTgyIDMxLjkzNnY5Mi44NzhoMzIuMjMydi04Mi42NTFzMTIuMTAzLTE3LjE0IDIzLjMwMy0xNy4xNGgxNC4wNDRjMTEuMTA0IDAgMjMuMzAzIDE3LjE0IDIzLjMwMyAxNy4xNHY4Mi42NTFoMzIuMjMydi05Mi44NzhsLTMwLjk4Mi0zMS45MzZ6IiBzdHJva2Utd2lkdGg9IjIwLjE3MyIvPjxwYXRoIGQ9Im0xMDIuMzEgMTU4LjI2Yy00LjAzNzggMC04LjQwMDkgNi4xNzg4LTguNDAwOSA2LjE3ODh2MzEuMTg4aDIxLjg2NXYtMzEuMTg4cy00LjM5NzgtNi4xNzg4LTguNDAwOS02LjE3ODhoLTUuMDYyN3oiIHN0cm9rZS13aWR0aD0iOS42NTI2Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,-0.20000000000000001" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.41058" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="65" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTczLjAybW0iIGhlaWdodD0iMjEwLjYxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3My4wMiAyMTAuNjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzLjgyNzUpIj48cGF0aCBkPSJtMCAxMzkuNjV2MTkuMTEyaDQxLjIzNXYxNi4wMDhoNDEuMjM1djE2LjAwN2g0MS4yMzV2MTYuMDA4aDQ5LjMxOHYtMTkuMTEyaC00MS4yMzV2LTE2LjAwN2gtNDEuMjM1di0xNi4wMDhoLTQxLjIzNXYtMTYuMDA4eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZD0ibTg5LjY2MSA3Ni4yODEtMTUuMTQyIDYuNTUwMmMtNS42NzUgMi40NTUxLTExLjU2OSAxLjM2OTMtMTMuMjE0LTIuNDM0Ny0xLjY0NTYtMy44MDQgMS41OTg0LTguODQzMSA3LjI3MzYtMTEuMjk5bDIxLjIyOS05LjE4MzhjMCA5LjkxNS0wLjE0NzE5IDkuMTgzOC0wLjE0NzE5IDE2LjM2N3oiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjg5OSIvPjxwYXRoIGQ9Im0xMTguOTQgOTkuNjk4YzIuNzc4MyAyMC4zMjMgNS44MDExIDM2LjI4MyA4LjU4ODggNTYuODA2IDAuMzkyMyAxLjgyNDcgMC4yNjA5MyAzLjI3NjQtMC40NTYwMSA1LjA1MzktMC40Njk1NyAxLjE2MTYtMC43NjcyNiAxLjY4NDItMS4zMjU0IDIuMzIyMy0yLjQ5NDggMi44NTE5LTYuMzQ2IDMuNzY4OS05LjgxMTEgMi4zMzU4LTAuNTUwNi0wLjIyNzY1LTEuMzMyNS0wLjY2MTUyLTEuNzM3Ny0wLjk2NDM3LTEuNjQyMi0xLjIyNzMtMi43MjEzLTIuOTA5OS0zLjM2MDMtNS4yMzk4LTAuMjE5NzgtMC44MDEyOS00LjE3MzktMzQuNTktNi45MzQ1LTU0LjE3OXoiIHN0cm9rZS13aWR0aD0iLjE2MTY2Ii8+PHBhdGggZD0ibTExMy4yIDI4Ljg1MmMwLjU2MjQzLTAuMDA4NSAxLjA5MzQgMC4wMjQ2NiAxLjQ4MjEgMC4xMDY0NSAwLjQyMTQ2IDAuMDg4NjggMS4xMTA3IDAuMzAzMjYgMS41MzIyIDAuNDc2OTcgMC40MjE0NiAwLjE3MzcxIDYuNDk1OSAzLjYzNTcgMTMuNDk4IDcuNjkzMSAxMC40NDQgNi4wNTE1IDEyLjk3NSA3LjUxNTIgMTQuMDE3IDguNjcyM2wtMTYuMDQ0IDAuMDAxNnYzLjU2MzZjLTMuMDAxLTEuNzI4Ni01LjQ2OTktMy4wOTg5LTUuNTQ1NC0zLjA3MzctMC4wOTY2IDAuMDMyMi0wLjE2NTk0IDUuNDY5Ni0wLjIxMjkxIDE2LjY4NWwtMC4wNjk4IDIxLjI4NnMtMC4zMDgwNCAzLjA4NDMtMS4wMjYxIDQuNDEyOWMtMC42MzU4MSAxLjE3NjQtMC45NzIyOSAyLjExMjctMi43NzExIDIuOTAwOS02LjgxNTQgMi45ODY1LTE2LjIzMSA3LjIzNDMtMjQuNTI2IDEwLjEzOC01LjA2NDcgMS43NzI2LTEyLjY2NiA0LjE1NjQtMTIuNDAzIDkuNjY4NmwwLjk0NzkzIDE5Ljg5M2MwLjcwMzk5IDE0Ljc3NC0xLjYyMzkgMTcuMDcxLTIuMDEzNiAxNy44NjctMC45NjU3NiAxLjk3MjUtMy4yMDcyIDMuNjI1OC01LjM3MDIgMy45NjE1LTEuMTQ1OCAwLjE3Nzc4LTEuNTI3NCAwLjE2Njk4LTIuNjQ3NC0wLjA3NTQtMS40NDM4LTAuMzEyNjgtMi41OTAyLTAuOTU0OTMtMy42OTQzLTIuMDY5MS0xLjA0OTctMS4wNTkzLTEuNTk3Ni0yLjAwMzMtMS45NDM2LTMuMzQ5Ny0wLjQ3MjYxLTEuODM5LTAuNzUzNTEgMC45NzQ0Ny0xLjg5OC0yNi45OTgtMS4xNDQ2LTMyLjkwNS0wLjUwNjgxLTI1LjYxNCAyMS41ODItMzQuODgzIDAgMCA1LjQzMDgtMS45Njg2IDguMDQ1Mi0zLjEzOTcgMS40OTg5LTAuNjcxNDQgMy40ODM1LTEuODQxIDMuNDgzNS0zLjQ4NDZ2LTIxLjc0NmM3LjhlLTQgLTAuNzgwMiAyZS0zIC00LjM3MTMgMC04LjQwODN2LTExLjIyN2MwLjA4MzItMS4zNjg3IDEuMDM3NS0xLjc3MjEgNi44ODQzLTUuMTQ3IDIuOTQ4LTEuNzAxNiA1LjcwNjctMy4yMTcxIDYuMTMwNC0zLjM2ODMgMC42MDAwMi0wLjIxNDA4IDEuNjI1Mi0wLjM0NDM5IDIuNTYyNi0wLjM1ODYzeiIgc3Ryb2tlLXdpZHRoPSIuMTM5MzMiLz48cGF0aCBkPSJtMTIwLjE3IDUuNTk3MWMwLjQyMTk0IDQuMDMyMy0xLjA1OTUgOC4zMjA2LTMuMzI4NCAxMS42OTktMS4zNDk2IDIuMDA5My0zLjMxMDIgMy41OTUzLTUuMzI0NCA0LjkzNzUtMi42NDQ4IDEuNzYyNS01LjU2NzIgMy4yOTE1LTguNjc1MiAzLjk1NjctMS4xODk2IDAuMjU0NTgtMi41MDE2IDAuMzgwMjItMy42NDk0LTAuMDIyOC0xLjQzNDQtMC41MDM2NS0yLjcyNjEtMS41Njk0LTMuNTc3NC0yLjgyOS0xLjI5NzQtMS45MTk1LTEuNjg4OC00LjM2NjEtMS45Njc3LTYuNjY2LTAuMjg4NjYtMi4zNzk5LTAuMzUxOS00Ljg4NTcgMC4zMjgxMi03LjE4NDcgMC44MjI3NS0yLjc4MTUgMi40Mjk0LTUuMzc3NSA0LjM5NTctNy41MDk5IDEuODEyMi0xLjk2NTMgNC4wNDAyLTMuNzM2MyA2LjU3MDctNC41OTgzIDIuMzY2Ny0wLjgwNjIgNS4wNjA0LTAuOTIzMDQgNy40OTI5LTAuMzQ1IDEuNzAyIDAuNDA0NDMgMy4zNTMzIDEuMzIwNCA0LjU3MzUgMi41NzM5IDEuNTc0NiAxLjYxNzYgMi45MjY2IDMuNzQzOCAzLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTEzMS40NCA0MC42ODFjMTAuNzY4IDMuNjUwOCAxMS4zNSAzLjk0OTYgMTIuNTggNS40NjEyIDEuMzI1OCAxLjYyOTUgMS4zNjcgMC45NTI4MiA0LjU1NDYgMTYuOTU3IDAgMCAyLjIyNTcgOS4yMzYgMi42NTA2IDE0LjM4NCAwLjAyMzkgMC4yOTAyNC0wLjE2MDIgMC44NTg4Ni0wLjE2MDIgMC44NTg4Ni0wLjIwOTQyIDEuMTIzMy0xLjE4MTUgMi43MDkyLTIuMDg2MiAzLjQwMzQtMi43OTM4IDIuMTQzNy02LjU1ODcgMS40ODMzLTguNTUzNS0xLjUwMDctMC40MTk4NS0wLjYyODA1LTAuNDY4MjUtMC44MzY5NS0zLjA4MDktMTMuNDM2bC0yLjY1MzYtMTIuNzk4LTAuMTkxMi0wLjcxMjYyLTkuODUzOS01LjY2NDQtMS4wOTQzLTUuMzYwMnoiIHN0cm9rZS13aWR0aD0iLjEzOTMzIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.51815" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="66" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTMzLjUxbW0iIGhlaWdodD0iMTM1Ljc4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEzMy41MSAxMzUuNzgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM4LjYxMyAtODUuODA4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utd2lkdGg9IjguNjc4Ij48cGF0aCBkPSJtNTkuNjcxIDE2OS4yOS0xNS42NzQtMy45ODY2IDQuMzg0NS0xNS41NjcgMzQuNDA5LTE5Ljg2Ni0zNC40MDktMTkuODY2LTQuMzg0NS0xNS41NjcgMTUuNjc0LTMuOTg2NiA0NS42OTggMjYuMzg0IDQ1LjY5OC0yNi4zODQgMTUuNjc0IDMuOTg2Ni00LjM4NDUgMTUuNTY3LTM0LjQwOSAxOS44NjYgMzQuNDA5IDE5Ljg2NiA0LjM4NDUgMTUuNTY3LTE1LjY3NCAzLjk4NjYtNDUuNjk4LTI2LjM4NHoiLz48cGF0aCBkPSJtMTA1LjM3IDE2NC40OS01Ni45ODggMzIuOTAyLTQuMzg0NSAxNS41NjcgMTUuNjc0IDMuOTg2NiA0NS42OTgtMjYuMzg0IDQ1LjY5OCAyNi4zODQgMTUuNjc0LTMuOTg2Ni00LjM4NDUtMTUuNTY3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="67" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTUzLjc5bW0iIGhlaWdodD0iMTUzLjc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1My43OSAxNTMuNzkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI5LjcxOSAtNzEuODY4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIj48Y2lyY2xlIGN4PSIxMDYuNjEiIGN5PSIxNDguNzYiIHI9IjQ3LjczMyIgc3Ryb2tlLXdpZHRoPSIxNSIvPjxwYXRoIGQ9Im0xMDYuNjEgNzEuODY4djI5LjE2MW0wIDk1LjQ2NnYyOS4xNjEiIHN0cm9rZS13aWR0aD0iOC4wNzc5Ii8+PHBhdGggZD0ibTE4My41MSAxNDguNzZoLTI5LjE2MW0tOTUuNDY2IDFlLTUgLTI5LjE2MS0xZS01IiBzdHJva2Utd2lkdGg9IjguMDc3OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="68" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="69" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzcuNjYxbW0iIGhlaWdodD0iMTcxLjkxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDc3LjY2MSAxNzEuOTEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM3LjgyIDE1NC44NSkiPjxyZWN0IHg9IjQzLjAzNSIgeT0iMTMyLjg1IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTE3LjAzIDJlLTYgNS45NjcxIDIyLjI3NiAyMi4yNzYgOC43ODc2LTguNzg3Ni0xOS40NTYtMTkuNDU2eiIvPjxwYXRoIGQ9Im0xOTIuNjcgMTE3LjAzdjUuOTY3MWwtMjIuMjc2IDIyLjI3Ni04Ljc4NzYtOC43ODc2IDE5LjQ1Ni0xOS40NTZ6Ii8+PHJlY3QgdHJhbnNmb3JtPSJzY2FsZSgxLC0xKSIgeD0iNDMuMDM1IiB5PSItMTc4Ljg4IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTk0LjY5IDJlLTYgLTUuOTY3MSAyMi4yNzYtMjIuMjc2IDguNzg3NiA4Ljc4NzYtMTkuNDU2IDE5LjQ1NnoiLz48cGF0aCBkPSJtMTkyLjY3IDE5NC42OXYtNS45NjcxbC0yMi4yNzYtMjIuMjc2LTguNzg3NiA4Ljc4NzYgMTkuNDU2IDE5LjQ1NnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.52982" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="70" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE5LjU3bW0iIGhlaWdodD0iMTE3Ljg2bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExOS41NyAxMTcuODYiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxLjQ0NyAtODguNjcxKSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48cGF0aCBkPSJtOTIuMDA5IDg4LjY3MS0xMS43NDQgNDEuOTE0aDE3Ljk1M2wxLjAzMy00MS45MTR6bS0xNy4wMzYgNjAuNzk4LTE1Ljk4OSA1Ny4wNjVoMzcuMzYybDEuNDA2Ni01Ny4wNjV6IiBzdHJva2Utd2lkdGg9IjIwLjk1MSIvPjxwYXRoIGQ9Im0xMDMuMjEgODguNjcxIDEuMDMzIDQxLjkxNGgxNy45NTNsLTExLjc0NC00MS45MTR6bTEuNDk4NiA2MC43OTggMS40MDY2IDU3LjA2NWgzNy4zNjJsLTE1Ljk5LTU3LjA2NXoiIHN0cm9rZS13aWR0aD0iMjAuOTUxIi8+PHBhdGggZD0ibTQxLjQ0NyAxMzUuNDl2OS4wNzU5aDE1Ljc0N3YxMy40NDFoMTAuNTc2bDIuMDkzOS0xMy40NDFoNjIuNzM4bDIuMDkzOSAxMy40NDFoMTAuNTc2di0xMy40NDFoMTUuNzQ3di05LjA3NTl6IiBzdHJva2Utd2lkdGg9IjE4LjYzNiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.47835" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="71" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTI1LjExbW0iIGhlaWdodD0iMTI0LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyNS4xMSAxMjQuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyLjI4MSAtODMuODgpIj48ZyBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im03My4yNjMgODMuODgtMzAuOTgyIDMxLjkzNnY5Mi44NzhoMzIuMjMydi04Mi42NTFzMTIuMTAzLTE3LjE0IDIzLjMwMy0xNy4xNGgxNC4wNDRjMTEuMTA0IDAgMjMuMzAzIDE3LjE0IDIzLjMwMyAxNy4xNHY4Mi42NTFoMzIuMjMydi05Mi44NzhsLTMwLjk4Mi0zMS45MzZ6IiBzdHJva2Utd2lkdGg9IjIwLjE3MyIvPjxwYXRoIGQ9Im0xMDIuMzEgMTU4LjI2Yy00LjAzNzggMC04LjQwMDkgNi4xNzg4LTguNDAwOSA2LjE3ODh2MzEuMTg4aDIxLjg2NXYtMzEuMTg4cy00LjM5NzgtNi4xNzg4LTguNDAwOS02LjE3ODhoLTUuMDYyN3oiIHN0cm9rZS13aWR0aD0iOS42NTI2Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,-0.20000000000000001" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.41058" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="72" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTczLjAybW0iIGhlaWdodD0iMjEwLjYxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3My4wMiAyMTAuNjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzLjgyNzUpIj48cGF0aCBkPSJtMCAxMzkuNjV2MTkuMTEyaDQxLjIzNXYxNi4wMDhoNDEuMjM1djE2LjAwN2g0MS4yMzV2MTYuMDA4aDQ5LjMxOHYtMTkuMTEyaC00MS4yMzV2LTE2LjAwN2gtNDEuMjM1di0xNi4wMDhoLTQxLjIzNXYtMTYuMDA4eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZD0ibTg5LjY2MSA3Ni4yODEtMTUuMTQyIDYuNTUwMmMtNS42NzUgMi40NTUxLTExLjU2OSAxLjM2OTMtMTMuMjE0LTIuNDM0Ny0xLjY0NTYtMy44MDQgMS41OTg0LTguODQzMSA3LjI3MzYtMTEuMjk5bDIxLjIyOS05LjE4MzhjMCA5LjkxNS0wLjE0NzE5IDkuMTgzOC0wLjE0NzE5IDE2LjM2N3oiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjg5OSIvPjxwYXRoIGQ9Im0xMTguOTQgOTkuNjk4YzIuNzc4MyAyMC4zMjMgNS44MDExIDM2LjI4MyA4LjU4ODggNTYuODA2IDAuMzkyMyAxLjgyNDcgMC4yNjA5MyAzLjI3NjQtMC40NTYwMSA1LjA1MzktMC40Njk1NyAxLjE2MTYtMC43NjcyNiAxLjY4NDItMS4zMjU0IDIuMzIyMy0yLjQ5NDggMi44NTE5LTYuMzQ2IDMuNzY4OS05LjgxMTEgMi4zMzU4LTAuNTUwNi0wLjIyNzY1LTEuMzMyNS0wLjY2MTUyLTEuNzM3Ny0wLjk2NDM3LTEuNjQyMi0xLjIyNzMtMi43MjEzLTIuOTA5OS0zLjM2MDMtNS4yMzk4LTAuMjE5NzgtMC44MDEyOS00LjE3MzktMzQuNTktNi45MzQ1LTU0LjE3OXoiIHN0cm9rZS13aWR0aD0iLjE2MTY2Ii8+PHBhdGggZD0ibTExMy4yIDI4Ljg1MmMwLjU2MjQzLTAuMDA4NSAxLjA5MzQgMC4wMjQ2NiAxLjQ4MjEgMC4xMDY0NSAwLjQyMTQ2IDAuMDg4NjggMS4xMTA3IDAuMzAzMjYgMS41MzIyIDAuNDc2OTcgMC40MjE0NiAwLjE3MzcxIDYuNDk1OSAzLjYzNTcgMTMuNDk4IDcuNjkzMSAxMC40NDQgNi4wNTE1IDEyLjk3NSA3LjUxNTIgMTQuMDE3IDguNjcyM2wtMTYuMDQ0IDAuMDAxNnYzLjU2MzZjLTMuMDAxLTEuNzI4Ni01LjQ2OTktMy4wOTg5LTUuNTQ1NC0zLjA3MzctMC4wOTY2IDAuMDMyMi0wLjE2NTk0IDUuNDY5Ni0wLjIxMjkxIDE2LjY4NWwtMC4wNjk4IDIxLjI4NnMtMC4zMDgwNCAzLjA4NDMtMS4wMjYxIDQuNDEyOWMtMC42MzU4MSAxLjE3NjQtMC45NzIyOSAyLjExMjctMi43NzExIDIuOTAwOS02LjgxNTQgMi45ODY1LTE2LjIzMSA3LjIzNDMtMjQuNTI2IDEwLjEzOC01LjA2NDcgMS43NzI2LTEyLjY2NiA0LjE1NjQtMTIuNDAzIDkuNjY4NmwwLjk0NzkzIDE5Ljg5M2MwLjcwMzk5IDE0Ljc3NC0xLjYyMzkgMTcuMDcxLTIuMDEzNiAxNy44NjctMC45NjU3NiAxLjk3MjUtMy4yMDcyIDMuNjI1OC01LjM3MDIgMy45NjE1LTEuMTQ1OCAwLjE3Nzc4LTEuNTI3NCAwLjE2Njk4LTIuNjQ3NC0wLjA3NTQtMS40NDM4LTAuMzEyNjgtMi41OTAyLTAuOTU0OTMtMy42OTQzLTIuMDY5MS0xLjA0OTctMS4wNTkzLTEuNTk3Ni0yLjAwMzMtMS45NDM2LTMuMzQ5Ny0wLjQ3MjYxLTEuODM5LTAuNzUzNTEgMC45NzQ0Ny0xLjg5OC0yNi45OTgtMS4xNDQ2LTMyLjkwNS0wLjUwNjgxLTI1LjYxNCAyMS41ODItMzQuODgzIDAgMCA1LjQzMDgtMS45Njg2IDguMDQ1Mi0zLjEzOTcgMS40OTg5LTAuNjcxNDQgMy40ODM1LTEuODQxIDMuNDgzNS0zLjQ4NDZ2LTIxLjc0NmM3LjhlLTQgLTAuNzgwMiAyZS0zIC00LjM3MTMgMC04LjQwODN2LTExLjIyN2MwLjA4MzItMS4zNjg3IDEuMDM3NS0xLjc3MjEgNi44ODQzLTUuMTQ3IDIuOTQ4LTEuNzAxNiA1LjcwNjctMy4yMTcxIDYuMTMwNC0zLjM2ODMgMC42MDAwMi0wLjIxNDA4IDEuNjI1Mi0wLjM0NDM5IDIuNTYyNi0wLjM1ODYzeiIgc3Ryb2tlLXdpZHRoPSIuMTM5MzMiLz48cGF0aCBkPSJtMTIwLjE3IDUuNTk3MWMwLjQyMTk0IDQuMDMyMy0xLjA1OTUgOC4zMjA2LTMuMzI4NCAxMS42OTktMS4zNDk2IDIuMDA5My0zLjMxMDIgMy41OTUzLTUuMzI0NCA0LjkzNzUtMi42NDQ4IDEuNzYyNS01LjU2NzIgMy4yOTE1LTguNjc1MiAzLjk1NjctMS4xODk2IDAuMjU0NTgtMi41MDE2IDAuMzgwMjItMy42NDk0LTAuMDIyOC0xLjQzNDQtMC41MDM2NS0yLjcyNjEtMS41Njk0LTMuNTc3NC0yLjgyOS0xLjI5NzQtMS45MTk1LTEuNjg4OC00LjM2NjEtMS45Njc3LTYuNjY2LTAuMjg4NjYtMi4zNzk5LTAuMzUxOS00Ljg4NTcgMC4zMjgxMi03LjE4NDcgMC44MjI3NS0yLjc4MTUgMi40Mjk0LTUuMzc3NSA0LjM5NTctNy41MDk5IDEuODEyMi0xLjk2NTMgNC4wNDAyLTMuNzM2MyA2LjU3MDctNC41OTgzIDIuMzY2Ny0wLjgwNjIgNS4wNjA0LTAuOTIzMDQgNy40OTI5LTAuMzQ1IDEuNzAyIDAuNDA0NDMgMy4zNTMzIDEuMzIwNCA0LjU3MzUgMi41NzM5IDEuNTc0NiAxLjYxNzYgMi45MjY2IDMuNzQzOCAzLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTEzMS40NCA0MC42ODFjMTAuNzY4IDMuNjUwOCAxMS4zNSAzLjk0OTYgMTIuNTggNS40NjEyIDEuMzI1OCAxLjYyOTUgMS4zNjcgMC45NTI4MiA0LjU1NDYgMTYuOTU3IDAgMCAyLjIyNTcgOS4yMzYgMi42NTA2IDE0LjM4NCAwLjAyMzkgMC4yOTAyNC0wLjE2MDIgMC44NTg4Ni0wLjE2MDIgMC44NTg4Ni0wLjIwOTQyIDEuMTIzMy0xLjE4MTUgMi43MDkyLTIuMDg2MiAzLjQwMzQtMi43OTM4IDIuMTQzNy02LjU1ODcgMS40ODMzLTguNTUzNS0xLjUwMDctMC40MTk4NS0wLjYyODA1LTAuNDY4MjUtMC44MzY5NS0zLjA4MDktMTMuNDM2bC0yLjY1MzYtMTIuNzk4LTAuMTkxMi0wLjcxMjYyLTkuODUzOS01LjY2NDQtMS4wOTQzLTUuMzYwMnoiIHN0cm9rZS13aWR0aD0iLjEzOTMzIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.51815" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="73" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTMzLjUxbW0iIGhlaWdodD0iMTM1Ljc4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEzMy41MSAxMzUuNzgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM4LjYxMyAtODUuODA4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utd2lkdGg9IjguNjc4Ij48cGF0aCBkPSJtNTkuNjcxIDE2OS4yOS0xNS42NzQtMy45ODY2IDQuMzg0NS0xNS41NjcgMzQuNDA5LTE5Ljg2Ni0zNC40MDktMTkuODY2LTQuMzg0NS0xNS41NjcgMTUuNjc0LTMuOTg2NiA0NS42OTggMjYuMzg0IDQ1LjY5OC0yNi4zODQgMTUuNjc0IDMuOTg2Ni00LjM4NDUgMTUuNTY3LTM0LjQwOSAxOS44NjYgMzQuNDA5IDE5Ljg2NiA0LjM4NDUgMTUuNTY3LTE1LjY3NCAzLjk4NjYtNDUuNjk4LTI2LjM4NHoiLz48cGF0aCBkPSJtMTA1LjM3IDE2NC40OS01Ni45ODggMzIuOTAyLTQuMzg0NSAxNS41NjcgMTUuNjc0IDMuOTg2NiA0NS42OTgtMjYuMzg0IDQ1LjY5OCAyNi4zODQgMTUuNjc0LTMuOTg2Ni00LjM4NDUtMTUuNTY3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="74" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTUzLjc5bW0iIGhlaWdodD0iMTUzLjc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1My43OSAxNTMuNzkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI5LjcxOSAtNzEuODY4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIj48Y2lyY2xlIGN4PSIxMDYuNjEiIGN5PSIxNDguNzYiIHI9IjQ3LjczMyIgc3Ryb2tlLXdpZHRoPSIxNSIvPjxwYXRoIGQ9Im0xMDYuNjEgNzEuODY4djI5LjE2MW0wIDk1LjQ2NnYyOS4xNjEiIHN0cm9rZS13aWR0aD0iOC4wNzc5Ii8+PHBhdGggZD0ibTE4My41MSAxNDguNzZoLTI5LjE2MW0tOTUuNDY2IDFlLTUgLTI5LjE2MS0xZS01IiBzdHJva2Utd2lkdGg9IjguMDc3OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="75" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="76" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzcuNjYxbW0iIGhlaWdodD0iMTcxLjkxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDc3LjY2MSAxNzEuOTEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM3LjgyIDE1NC44NSkiPjxyZWN0IHg9IjQzLjAzNSIgeT0iMTMyLjg1IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTE3LjAzIDJlLTYgNS45NjcxIDIyLjI3NiAyMi4yNzYgOC43ODc2LTguNzg3Ni0xOS40NTYtMTkuNDU2eiIvPjxwYXRoIGQ9Im0xOTIuNjcgMTE3LjAzdjUuOTY3MWwtMjIuMjc2IDIyLjI3Ni04Ljc4NzYtOC43ODc2IDE5LjQ1Ni0xOS40NTZ6Ii8+PHJlY3QgdHJhbnNmb3JtPSJzY2FsZSgxLC0xKSIgeD0iNDMuMDM1IiB5PSItMTc4Ljg4IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTk0LjY5IDJlLTYgLTUuOTY3MSAyMi4yNzYtMjIuMjc2IDguNzg3NiA4Ljc4NzYtMTkuNDU2IDE5LjQ1NnoiLz48cGF0aCBkPSJtMTkyLjY3IDE5NC42OXYtNS45NjcxbC0yMi4yNzYtMjIuMjc2LTguNzg3NiA4Ljc4NzYgMTkuNDU2IDE5LjQ1NnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.52982" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="77" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE5LjU3bW0iIGhlaWdodD0iMTE3Ljg2bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExOS41NyAxMTcuODYiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxLjQ0NyAtODguNjcxKSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48cGF0aCBkPSJtOTIuMDA5IDg4LjY3MS0xMS43NDQgNDEuOTE0aDE3Ljk1M2wxLjAzMy00MS45MTR6bS0xNy4wMzYgNjAuNzk4LTE1Ljk4OSA1Ny4wNjVoMzcuMzYybDEuNDA2Ni01Ny4wNjV6IiBzdHJva2Utd2lkdGg9IjIwLjk1MSIvPjxwYXRoIGQ9Im0xMDMuMjEgODguNjcxIDEuMDMzIDQxLjkxNGgxNy45NTNsLTExLjc0NC00MS45MTR6bTEuNDk4NiA2MC43OTggMS40MDY2IDU3LjA2NWgzNy4zNjJsLTE1Ljk5LTU3LjA2NXoiIHN0cm9rZS13aWR0aD0iMjAuOTUxIi8+PHBhdGggZD0ibTQxLjQ0NyAxMzUuNDl2OS4wNzU5aDE1Ljc0N3YxMy40NDFoMTAuNTc2bDIuMDkzOS0xMy40NDFoNjIuNzM4bDIuMDkzOSAxMy40NDFoMTAuNTc2di0xMy40NDFoMTUuNzQ3di05LjA3NTl6IiBzdHJva2Utd2lkdGg9IjE4LjYzNiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.47835" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="78" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTI1LjExbW0iIGhlaWdodD0iMTI0LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyNS4xMSAxMjQuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQyLjI4MSAtODMuODgpIj48ZyBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utb3BhY2l0eT0iLjUiPjxwYXRoIGQ9Im03My4yNjMgODMuODgtMzAuOTgyIDMxLjkzNnY5Mi44NzhoMzIuMjMydi04Mi42NTFzMTIuMTAzLTE3LjE0IDIzLjMwMy0xNy4xNGgxNC4wNDRjMTEuMTA0IDAgMjMuMzAzIDE3LjE0IDIzLjMwMyAxNy4xNHY4Mi42NTFoMzIuMjMydi05Mi44NzhsLTMwLjk4Mi0zMS45MzZ6IiBzdHJva2Utd2lkdGg9IjIwLjE3MyIvPjxwYXRoIGQ9Im0xMDIuMzEgMTU4LjI2Yy00LjAzNzggMC04LjQwMDkgNi4xNzg4LTguNDAwOSA2LjE3ODh2MzEuMTg4aDIxLjg2NXYtMzEuMTg4cy00LjM5NzgtNi4xNzg4LTguNDAwOS02LjE3ODhoLTUuMDYyN3oiIHN0cm9rZS13aWR0aD0iOS42NTI2Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,-0.20000000000000001" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.41058" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="79" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTczLjAybW0iIGhlaWdodD0iMjEwLjYxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3My4wMiAyMTAuNjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzLjgyNzUpIj48cGF0aCBkPSJtMCAxMzkuNjV2MTkuMTEyaDQxLjIzNXYxNi4wMDhoNDEuMjM1djE2LjAwN2g0MS4yMzV2MTYuMDA4aDQ5LjMxOHYtMTkuMTEyaC00MS4yMzV2LTE2LjAwN2gtNDEuMjM1di0xNi4wMDhoLTQxLjIzNXYtMTYuMDA4eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZD0ibTg5LjY2MSA3Ni4yODEtMTUuMTQyIDYuNTUwMmMtNS42NzUgMi40NTUxLTExLjU2OSAxLjM2OTMtMTMuMjE0LTIuNDM0Ny0xLjY0NTYtMy44MDQgMS41OTg0LTguODQzMSA3LjI3MzYtMTEuMjk5bDIxLjIyOS05LjE4MzhjMCA5LjkxNS0wLjE0NzE5IDkuMTgzOC0wLjE0NzE5IDE2LjM2N3oiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjg5OSIvPjxwYXRoIGQ9Im0xMTguOTQgOTkuNjk4YzIuNzc4MyAyMC4zMjMgNS44MDExIDM2LjI4MyA4LjU4ODggNTYuODA2IDAuMzkyMyAxLjgyNDcgMC4yNjA5MyAzLjI3NjQtMC40NTYwMSA1LjA1MzktMC40Njk1NyAxLjE2MTYtMC43NjcyNiAxLjY4NDItMS4zMjU0IDIuMzIyMy0yLjQ5NDggMi44NTE5LTYuMzQ2IDMuNzY4OS05LjgxMTEgMi4zMzU4LTAuNTUwNi0wLjIyNzY1LTEuMzMyNS0wLjY2MTUyLTEuNzM3Ny0wLjk2NDM3LTEuNjQyMi0xLjIyNzMtMi43MjEzLTIuOTA5OS0zLjM2MDMtNS4yMzk4LTAuMjE5NzgtMC44MDEyOS00LjE3MzktMzQuNTktNi45MzQ1LTU0LjE3OXoiIHN0cm9rZS13aWR0aD0iLjE2MTY2Ii8+PHBhdGggZD0ibTExMy4yIDI4Ljg1MmMwLjU2MjQzLTAuMDA4NSAxLjA5MzQgMC4wMjQ2NiAxLjQ4MjEgMC4xMDY0NSAwLjQyMTQ2IDAuMDg4NjggMS4xMTA3IDAuMzAzMjYgMS41MzIyIDAuNDc2OTcgMC40MjE0NiAwLjE3MzcxIDYuNDk1OSAzLjYzNTcgMTMuNDk4IDcuNjkzMSAxMC40NDQgNi4wNTE1IDEyLjk3NSA3LjUxNTIgMTQuMDE3IDguNjcyM2wtMTYuMDQ0IDAuMDAxNnYzLjU2MzZjLTMuMDAxLTEuNzI4Ni01LjQ2OTktMy4wOTg5LTUuNTQ1NC0zLjA3MzctMC4wOTY2IDAuMDMyMi0wLjE2NTk0IDUuNDY5Ni0wLjIxMjkxIDE2LjY4NWwtMC4wNjk4IDIxLjI4NnMtMC4zMDgwNCAzLjA4NDMtMS4wMjYxIDQuNDEyOWMtMC42MzU4MSAxLjE3NjQtMC45NzIyOSAyLjExMjctMi43NzExIDIuOTAwOS02LjgxNTQgMi45ODY1LTE2LjIzMSA3LjIzNDMtMjQuNTI2IDEwLjEzOC01LjA2NDcgMS43NzI2LTEyLjY2NiA0LjE1NjQtMTIuNDAzIDkuNjY4NmwwLjk0NzkzIDE5Ljg5M2MwLjcwMzk5IDE0Ljc3NC0xLjYyMzkgMTcuMDcxLTIuMDEzNiAxNy44NjctMC45NjU3NiAxLjk3MjUtMy4yMDcyIDMuNjI1OC01LjM3MDIgMy45NjE1LTEuMTQ1OCAwLjE3Nzc4LTEuNTI3NCAwLjE2Njk4LTIuNjQ3NC0wLjA3NTQtMS40NDM4LTAuMzEyNjgtMi41OTAyLTAuOTU0OTMtMy42OTQzLTIuMDY5MS0xLjA0OTctMS4wNTkzLTEuNTk3Ni0yLjAwMzMtMS45NDM2LTMuMzQ5Ny0wLjQ3MjYxLTEuODM5LTAuNzUzNTEgMC45NzQ0Ny0xLjg5OC0yNi45OTgtMS4xNDQ2LTMyLjkwNS0wLjUwNjgxLTI1LjYxNCAyMS41ODItMzQuODgzIDAgMCA1LjQzMDgtMS45Njg2IDguMDQ1Mi0zLjEzOTcgMS40OTg5LTAuNjcxNDQgMy40ODM1LTEuODQxIDMuNDgzNS0zLjQ4NDZ2LTIxLjc0NmM3LjhlLTQgLTAuNzgwMiAyZS0zIC00LjM3MTMgMC04LjQwODN2LTExLjIyN2MwLjA4MzItMS4zNjg3IDEuMDM3NS0xLjc3MjEgNi44ODQzLTUuMTQ3IDIuOTQ4LTEuNzAxNiA1LjcwNjctMy4yMTcxIDYuMTMwNC0zLjM2ODMgMC42MDAwMi0wLjIxNDA4IDEuNjI1Mi0wLjM0NDM5IDIuNTYyNi0wLjM1ODYzeiIgc3Ryb2tlLXdpZHRoPSIuMTM5MzMiLz48cGF0aCBkPSJtMTIwLjE3IDUuNTk3MWMwLjQyMTk0IDQuMDMyMy0xLjA1OTUgOC4zMjA2LTMuMzI4NCAxMS42OTktMS4zNDk2IDIuMDA5My0zLjMxMDIgMy41OTUzLTUuMzI0NCA0LjkzNzUtMi42NDQ4IDEuNzYyNS01LjU2NzIgMy4yOTE1LTguNjc1MiAzLjk1NjctMS4xODk2IDAuMjU0NTgtMi41MDE2IDAuMzgwMjItMy42NDk0LTAuMDIyOC0xLjQzNDQtMC41MDM2NS0yLjcyNjEtMS41Njk0LTMuNTc3NC0yLjgyOS0xLjI5NzQtMS45MTk1LTEuNjg4OC00LjM2NjEtMS45Njc3LTYuNjY2LTAuMjg4NjYtMi4zNzk5LTAuMzUxOS00Ljg4NTcgMC4zMjgxMi03LjE4NDcgMC44MjI3NS0yLjc4MTUgMi40Mjk0LTUuMzc3NSA0LjM5NTctNy41MDk5IDEuODEyMi0xLjk2NTMgNC4wNDAyLTMuNzM2MyA2LjU3MDctNC41OTgzIDIuMzY2Ny0wLjgwNjIgNS4wNjA0LTAuOTIzMDQgNy40OTI5LTAuMzQ1IDEuNzAyIDAuNDA0NDMgMy4zNTMzIDEuMzIwNCA0LjU3MzUgMi41NzM5IDEuNTc0NiAxLjYxNzYgMi45MjY2IDMuNzQzOCAzLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTEzMS40NCA0MC42ODFjMTAuNzY4IDMuNjUwOCAxMS4zNSAzLjk0OTYgMTIuNTggNS40NjEyIDEuMzI1OCAxLjYyOTUgMS4zNjcgMC45NTI4MiA0LjU1NDYgMTYuOTU3IDAgMCAyLjIyNTcgOS4yMzYgMi42NTA2IDE0LjM4NCAwLjAyMzkgMC4yOTAyNC0wLjE2MDIgMC44NTg4Ni0wLjE2MDIgMC44NTg4Ni0wLjIwOTQyIDEuMTIzMy0xLjE4MTUgMi43MDkyLTIuMDg2MiAzLjQwMzQtMi43OTM4IDIuMTQzNy02LjU1ODcgMS40ODMzLTguNTUzNS0xLjUwMDctMC40MTk4NS0wLjYyODA1LTAuNDY4MjUtMC44MzY5NS0zLjA4MDktMTMuNDM2bC0yLjY1MzYtMTIuNzk4LTAuMTkxMi0wLjcxMjYyLTkuODUzOS01LjY2NDQtMS4wOTQzLTUuMzYwMnoiIHN0cm9rZS13aWR0aD0iLjEzOTMzIi8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.51815" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzcuNjYxbW0iIGhlaWdodD0iMTcxLjkxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDc3LjY2MSAxNzEuOTEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM3LjgyIDE1NC44NSkiPjxyZWN0IHg9IjQzLjAzNSIgeT0iMTMyLjg1IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTE3LjAzIDJlLTYgNS45NjcxIDIyLjI3NiAyMi4yNzYgOC43ODc2LTguNzg3Ni0xOS40NTYtMTkuNDU2eiIvPjxwYXRoIGQ9Im0xOTIuNjcgMTE3LjAzdjUuOTY3MWwtMjIuMjc2IDIyLjI3Ni04Ljc4NzYtOC43ODc2IDE5LjQ1Ni0xOS40NTZ6Ii8+PHJlY3QgdHJhbnNmb3JtPSJzY2FsZSgxLC0xKSIgeD0iNDMuMDM1IiB5PSItMTc4Ljg4IiB3aWR0aD0iMTI3LjM2IiBoZWlnaHQ9IjEyLjQyNyIvPjxwYXRoIGQ9Im0yMC43NTggMTk0LjY5IDJlLTYgLTUuOTY3MSAyMi4yNzYtMjIuMjc2IDguNzg3NiA4Ljc4NzYtMTkuNDU2IDE5LjQ1NnoiLz48cGF0aCBkPSJtMTkyLjY3IDE5NC42OXYtNS45NjcxbC0yMi4yNzYtMjIuMjc2LTguNzg3NiA4Ljc4NzYgMTkuNDU2IDE5LjQ1NnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.52982" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="80" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTUzLjc5bW0iIGhlaWdodD0iMTUzLjc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1My43OSAxNTMuNzkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI5LjcxOSAtNzEuODY4KSI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIj48Y2lyY2xlIGN4PSIxMDYuNjEiIGN5PSIxNDguNzYiIHI9IjQ3LjczMyIgc3Ryb2tlLXdpZHRoPSIxNSIvPjxwYXRoIGQ9Im0xMDYuNjEgNzEuODY4djI5LjE2MW0wIDk1LjQ2NnYyOS4xNjEiIHN0cm9rZS13aWR0aD0iOC4wNzc5Ii8+PHBhdGggZD0ibTE4My41MSAxNDguNzZoLTI5LjE2MW0tOTUuNDY2IDFlLTUgLTI5LjE2MS0xZS01IiBzdHJva2Utd2lkdGg9IjguMDc3OSIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE5LjU3bW0iIGhlaWdodD0iMTE3Ljg2bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExOS41NyAxMTcuODYiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxLjQ0NyAtODguNjcxKSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48cGF0aCBkPSJtOTIuMDA5IDg4LjY3MS0xMS43NDQgNDEuOTE0aDE3Ljk1M2wxLjAzMy00MS45MTR6bS0xNy4wMzYgNjAuNzk4LTE1Ljk4OSA1Ny4wNjVoMzcuMzYybDEuNDA2Ni01Ny4wNjV6IiBzdHJva2Utd2lkdGg9IjIwLjk1MSIvPjxwYXRoIGQ9Im0xMDMuMjEgODguNjcxIDEuMDMzIDQxLjkxNGgxNy45NTNsLTExLjc0NC00MS45MTR6bTEuNDk4NiA2MC43OTggMS40MDY2IDU3LjA2NWgzNy4zNjJsLTE1Ljk5LTU3LjA2NXoiIHN0cm9rZS13aWR0aD0iMjAuOTUxIi8+PHBhdGggZD0ibTQxLjQ0NyAxMzUuNDl2OS4wNzU5aDE1Ljc0N3YxMy40NDFoMTAuNTc2bDIuMDkzOS0xMy40NDFoNjIuNzM4bDIuMDkzOSAxMy40NDFoMTAuNTc2di0xMy40NDFoMTUuNzQ3di05LjA3NTl6IiBzdHJva2Utd2lkdGg9IjE4LjYzNiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.47835" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Мостовое сооружение" value="602031601" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Транспортная развязка в разных уровнях" value="602031602" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Тоннель" value="602031603" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Пешеходный переход в разных уровнях" value="602031604" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожный переезд" value="602031605" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Саморегулируемое пересечение в одном уровне" value="602031606" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="BRIDGE_T" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Мост автодорожный" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Мост железнодорожный" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Мост пешеходный или велосипедный" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Мост для совмещенного движения транспортных средств" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Путепровод" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Эстакада" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Виадук" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="TUNNEL_T" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Автодорожный" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожный" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной тоннель" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CROSSP_T" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Надземные" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Подземные" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CROSSR_T" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Регулируемый" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Нерегулируемый" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FUNCTION" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="true" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к ликвидации" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="BRIDGE_T" index="6" name=""/>
    <alias field="TUNNEL_T" index="7" name=""/>
    <alias field="CROSSP_T" index="8" name=""/>
    <alias field="CROSSR_T" index="9" name=""/>
    <alias field="FUNCTION" index="10" name="Назначение объекта"/>
    <alias field="EVENT_TIME" index="11" name=""/>
    <alias field="SOURCE" index="12" name="Источник данных"/>
    <alias field="NOTE" index="13" name="Примечание"/>
    <alias field="STATUS" index="14" name="Статус объекта"/>
    <alias field="REG_STATUS" index="15" name="Значение объекта"/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602031601'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="BRIDGE_T" expression="if(&quot;CLASSID&quot; = '602031601', attribute('BRIDGE_T'), NULL)" applyOnUpdate="1"/>
    <default field="TUNNEL_T" expression="if(&quot;CLASSID&quot; = '602031603', attribute('TUNNEL_T'), NULL)" applyOnUpdate="1"/>
    <default field="CROSSP_T" expression="if(&quot;CLASSID&quot; = '602031604', attribute('CROSSP_T'), NULL)" applyOnUpdate="1"/>
    <default field="CROSSR_T" expression="if(&quot;CLASSID&quot; = '602031605', attribute('CROSSR_T'), NULL)" applyOnUpdate="1"/>
    <default field="FUNCTION" expression="''" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="BRIDGE_T" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="TUNNEL_T" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="CROSSP_T" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="CROSSR_T" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="FUNCTION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="BRIDGE_T" desc="Заполняется для объекта 602031601" exp="if(&quot;CLASSID&quot; = '602031601', &quot;BRIDGE_T&quot; IS NOT NULL, &quot;BRIDGE_T&quot; IS NULL)"/>
    <constraint field="TUNNEL_T" desc="Заполняется для объекта 602031603" exp="if(&quot;CLASSID&quot; = '602031603', &quot;TUNNEL_T&quot; IS NOT NULL, &quot;TUNNEL_T&quot; IS NULL)"/>
    <constraint field="CROSSP_T" desc="Заполняется для объекта 602031604" exp="if(&quot;CLASSID&quot; = '602031604', &quot;CROSSP_T&quot; IS NOT NULL, &quot;CROSSP_T&quot; IS NULL)"/>
    <constraint field="CROSSR_T" desc="Заполняется для объекта 602031605" exp="if(&quot;CLASSID&quot; = '602031605', &quot;CROSSR_T&quot; IS NOT NULL, &quot;CROSSR_T&quot; IS NULL)"/>
    <constraint field="FUNCTION" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xd;&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="14" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="15" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="10" name="FUNCTION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="12" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="&quot;STATUS&quot; IN (2, 3) OR &quot;CLASSID&quot; IN ('602031601', '602031603', '602031604', '602031605')">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Тип мостовых сооружений" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602031601'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="6" name="BRIDGE_T">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Тип тоннелей" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602031603'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="7" name="TUNNEL_T">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Тип пешеходных переходов в разных уровнях по расположению относительно уровня земли" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602031604'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="8" name="CROSSP_T">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Тип железнодорожного переезда" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602031605'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="9" name="CROSSR_T">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="11" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="BRIDGE_T" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="CROSSP_T" editable="1"/>
    <field name="CROSSR_T" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="FUNCTION" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="NAME" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="TUNNEL_T" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="BRIDGE_T"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="CROSSP_T"/>
    <field labelOnTop="1" name="CROSSR_T"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="FUNCTION"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS"/>
    <field labelOnTop="1" name="TUNNEL_T"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="BRIDGE_T" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="CROSSP_T" reuseLastValue="0"/>
    <field name="CROSSR_T" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="FUNCTION" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="TUNNEL_T" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
