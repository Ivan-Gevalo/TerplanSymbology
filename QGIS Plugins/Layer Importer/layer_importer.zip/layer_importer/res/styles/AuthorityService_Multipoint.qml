<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{4bfa8e4f-57fa-4c4d-a8ec-422f36ed32f8}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{bf1af63a-1b4b-4884-b862-a3616aa58b1c}">
        <rule label="Административное здание" filter="&quot;CLASSID&quot; = '602010801'" symbol="1" key="{d318c887-0023-4939-8b6e-83a70148246f}"/>
        <rule label="Объект проведения гражданских обрядов" filter="&quot;CLASSID&quot; = '602010802'" symbol="2" key="{98def5a2-9934-47ec-ad30-fcf6a4056428}"/>
        <rule label="Объект религиозной организации (объединения)" filter="&quot;CLASSID&quot; = '602010803'" symbol="3" key="{4703487d-2ad9-41d5-acc8-0637a3e25b91}"/>
        <rule label="Объекты торговли, общественного питания" filter="&quot;CLASSID&quot; = '602010804'" symbol="4" key="{6e0212fd-b3d3-4aff-80df-5f4732d91e9b}"/>
        <rule label="Непроизводственный объект по предоставлению населению государственных правовых, финансовых, консультационных и иных подобных услуг" filter="&quot;CLASSID&quot; = '602010805'" symbol="5" key="{e4f41d45-98c1-40fc-8aeb-c31de72081e0}"/>
        <rule label="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" filter="&quot;CLASSID&quot; = '602010806'" symbol="6" key="{2bfcb932-45ae-44e1-a26f-39ec6acc466b}"/>
        <rule label="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" filter="&quot;CLASSID&quot; = '602010807'" symbol="7" key="{aacaa963-067d-4d2a-aa70-ed2b6a44b4db}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="8" key="{853b79ad-c9da-44ec-b2bd-9429f987fe4c}">
        <rule label="Административное здание" filter="&quot;CLASSID&quot; = '602010801'" symbol="9" key="{2460adfb-392c-48b9-9851-9e8b7c31afe1}"/>
        <rule label="Объект проведения гражданских обрядов" filter="&quot;CLASSID&quot; = '602010802'" symbol="10" key="{58620761-fa31-4cb8-a9d8-6efdabcf912e}"/>
        <rule label="Объект религиозной организации (объединения)" filter="&quot;CLASSID&quot; = '602010803'" symbol="11" key="{78bc0531-e7ba-4f0d-bed5-e032198b49bf}"/>
        <rule label="Объекты торговли, общественного питания" filter="&quot;CLASSID&quot; = '602010804'" symbol="12" key="{348e3f09-8e07-4765-b0e6-008aca41b848}"/>
        <rule label="Непроизводственный объект по предоставлению населению государственных правовых, финансовых, консультационных и иных подобных услуг" filter="&quot;CLASSID&quot; = '602010805'" symbol="13" key="{8c198f9d-f8b0-4d5f-80e1-33c48280bbc3}"/>
        <rule label="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" filter="&quot;CLASSID&quot; = '602010806'" symbol="14" key="{fa9258bc-c13b-41e7-b91a-1892506592ff}"/>
        <rule label="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" filter="&quot;CLASSID&quot; = '602010807'" symbol="15" key="{f0632773-a579-41b5-998d-d924c31e0bbe}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="16" key="{4e59e91b-6781-4046-8f23-c9c82582a9e4}">
        <rule label="Административное здание" filter="&quot;CLASSID&quot; = '602010801'" symbol="17" key="{2698f17a-bf3e-4c86-87af-80090e095c03}"/>
        <rule label="Объект проведения гражданских обрядов" filter="&quot;CLASSID&quot; = '602010802'" symbol="18" key="{3ab9db15-31f4-40ae-98ac-dff50caa695f}"/>
        <rule label="Объект религиозной организации (объединения)" filter="&quot;CLASSID&quot; = '602010803'" symbol="19" key="{c1591af9-ff7c-4c92-b1f3-93c6f4359c74}"/>
        <rule label="Объекты торговли, общественного питания" filter="&quot;CLASSID&quot; = '602010804'" symbol="20" key="{dde90c7d-c4a3-4640-89e4-4b4ab58286f5}"/>
        <rule label="Непроизводственный объект по предоставлению населению государственных правовых, финансовых, консультационных и иных подобных услуг" filter="&quot;CLASSID&quot; = '602010805'" symbol="21" key="{7bef98d5-1717-430e-81b2-eff9ccef1ccf}"/>
        <rule label="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" filter="&quot;CLASSID&quot; = '602010806'" symbol="22" key="{80fb91ee-01d2-42e8-bd6d-dfe846a37458}"/>
        <rule label="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" filter="&quot;CLASSID&quot; = '602010807'" symbol="23" key="{753ae047-e497-44a6-bbea-63e852d2e4e6}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="24" key="{94f1cff6-b494-4582-a556-b3b412465073}">
        <rule label="Административное здание" filter="&quot;CLASSID&quot; = '602010801'" symbol="25" key="{d8f6b219-1c21-4529-a67a-4458dd6990ee}"/>
        <rule label="Объект проведения гражданских обрядов" filter="&quot;CLASSID&quot; = '602010802'" symbol="26" key="{83ce8e5b-66d6-45b6-9af4-32a5abc41691}"/>
        <rule label="Объект религиозной организации (объединения)" filter="&quot;CLASSID&quot; = '602010803'" symbol="27" key="{0d9c82e9-2fd6-4635-8565-462c1864ed7e}"/>
        <rule label="Объекты торговли, общественного питания" filter="&quot;CLASSID&quot; = '602010804'" symbol="28" key="{90459c52-f048-4534-b2a1-8838f4e328d3}"/>
        <rule label="Непроизводственный объект по предоставлению населению государственных правовых, финансовых, консультационных и иных подобных услуг" filter="&quot;CLASSID&quot; = '602010805'" symbol="29" key="{b925e20f-243b-4342-9fc5-20c1bb16933b}"/>
        <rule label="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" filter="&quot;CLASSID&quot; = '602010806'" symbol="30" key="{2687ff31-77a0-4956-bf36-6741c55448bb}"/>
        <rule label="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" filter="&quot;CLASSID&quot; = '602010807'" symbol="31" key="{4ee53b82-5c25-43b7-914f-5f92172c054e}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="32" key="{c5ae1475-3cdd-4be3-843f-7b095646ea03}">
        <rule label="Административное здание" filter="&quot;CLASSID&quot; = '602010801'" symbol="33" key="{1b6f96e2-fd33-4c17-b113-585226bd2bc3}"/>
        <rule label="Объект проведения гражданских обрядов" filter="&quot;CLASSID&quot; = '602010802'" symbol="34" key="{d2f6e8e0-c24f-4e9a-af71-2565afd63e7b}"/>
        <rule label="Объект религиозной организации (объединения)" filter="&quot;CLASSID&quot; = '602010803'" symbol="35" key="{6fb634b1-e0f4-404b-b346-c7d71be2e595}"/>
        <rule label="Объекты торговли, общественного питания" filter="&quot;CLASSID&quot; = '602010804'" symbol="36" key="{e27d77d6-ab8c-432f-8742-380a14ffba78}"/>
        <rule label="Непроизводственный объект по предоставлению населению государственных правовых, финансовых, консультационных и иных подобных услуг" filter="&quot;CLASSID&quot; = '602010805'" symbol="37" key="{b0180461-7d00-495d-b184-f7ccdfaf760b}"/>
        <rule label="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" filter="&quot;CLASSID&quot; = '602010806'" symbol="38" key="{fa229a79-4fed-46fb-82ea-32cbc346481c}"/>
        <rule label="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" filter="&quot;CLASSID&quot; = '602010807'" symbol="39" key="{684022cb-2a50-4b94-829a-a795256af364}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="40" key="{a2394db9-31a7-4fd9-8b04-6879dc722501}">
        <rule label="Административное здание" filter="&quot;CLASSID&quot; = '602010801'" symbol="41" key="{89bdd60e-ecd1-4b72-946c-7332d8fbf399}"/>
        <rule label="Объект проведения гражданских обрядов" filter="&quot;CLASSID&quot; = '602010802'" symbol="42" key="{14844312-ab2f-4a79-b0ee-f6875ece568a}"/>
        <rule label="Объект религиозной организации (объединения)" filter="&quot;CLASSID&quot; = '602010803'" symbol="43" key="{9a99746e-5091-49f9-8075-433d4189fdc3}"/>
        <rule label="Объекты торговли, общественного питания" filter="&quot;CLASSID&quot; = '602010804'" symbol="44" key="{6066becb-33df-4aca-8c3b-c9345edaa032}"/>
        <rule label="Непроизводственный объект по предоставлению населению государственных правовых, финансовых, консультационных и иных подобных услуг" filter="&quot;CLASSID&quot; = '602010805'" symbol="45" key="{0ed66a21-4a85-4762-82fa-21c4eb27c66e}"/>
        <rule label="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" filter="&quot;CLASSID&quot; = '602010806'" symbol="46" key="{df03e9d2-1c26-4e42-861f-9c44f7bf25af}"/>
        <rule label="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" filter="&quot;CLASSID&quot; = '602010807'" symbol="47" key="{c0427b0b-a666-4ff8-857d-fc90c585c1cb}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="48" key="{23c6297b-a941-4ecf-a4f2-e0c747e1ad09}">
        <rule label="Административное здание" filter="&quot;CLASSID&quot; = '602010801'" symbol="49" key="{77db542a-bd4f-4f09-a94c-740550fd4a86}"/>
        <rule label="Объект проведения гражданских обрядов" filter="&quot;CLASSID&quot; = '602010802'" symbol="50" key="{79eee445-5a00-45a3-908f-792fd57da064}"/>
        <rule label="Объект религиозной организации (объединения)" filter="&quot;CLASSID&quot; = '602010803'" symbol="51" key="{bbbc3062-a039-4fa3-b09e-683d9ca980d1}"/>
        <rule label="Объекты торговли, общественного питания" filter="&quot;CLASSID&quot; = '602010804'" symbol="52" key="{356ff21b-95c8-4717-b4a5-5b426ee3499e}"/>
        <rule label="Непроизводственный объект по предоставлению населению государственных правовых, финансовых, консультационных и иных подобных услуг" filter="&quot;CLASSID&quot; = '602010805'" symbol="53" key="{9fec4984-be83-4e50-898e-058abeb728fb}"/>
        <rule label="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" filter="&quot;CLASSID&quot; = '602010806'" symbol="54" key="{e2eae7ac-9bcd-463a-864b-0aa02a8e6503}"/>
        <rule label="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" filter="&quot;CLASSID&quot; = '602010807'" symbol="55" key="{e6db0576-71e8-488d-a023-fca461c52a74}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты регионального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 2" symbol="56" key="{ab86ce53-4f7f-4109-baa3-300cde422c1a}">
        <rule label="Административное здание" filter="&quot;CLASSID&quot; = '602010801'" symbol="57" key="{32da04bb-fe70-422b-9ad5-c8214d9465d6}"/>
        <rule label="Объект проведения гражданских обрядов" filter="&quot;CLASSID&quot; = '602010802'" symbol="58" key="{0d0feab2-e215-4629-a085-19ccb5903b79}"/>
        <rule label="Объект религиозной организации (объединения)" filter="&quot;CLASSID&quot; = '602010803'" symbol="59" key="{d8e1bb70-4b00-4209-9333-4aa98463051b}"/>
        <rule label="Объекты торговли, общественного питания" filter="&quot;CLASSID&quot; = '602010804'" symbol="60" key="{8acd87ac-d150-4a61-8a15-2bfb155907be}"/>
        <rule label="Непроизводственный объект по предоставлению населению государственных правовых, финансовых, консультационных и иных подобных услуг" filter="&quot;CLASSID&quot; = '602010805'" symbol="61" key="{6f626551-ba55-4222-8b0a-60e518e282f8}"/>
        <rule label="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" filter="&quot;CLASSID&quot; = '602010806'" symbol="62" key="{ea677ff1-f293-4eae-9544-814f66f15b92}"/>
        <rule label="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" filter="&quot;CLASSID&quot; = '602010807'" symbol="63" key="{349cc9af-78e3-4b16-b3ae-a5b7fdb1eb68}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="64" key="{64b78a5f-779a-4127-aac5-ed9ea7c66fe3}">
        <rule label="Административное здание" filter="&quot;CLASSID&quot; = '602010801'" symbol="65" key="{87d22ada-e44a-489b-8f3a-cdc081e06ea6}"/>
        <rule label="Объект проведения гражданских обрядов" filter="&quot;CLASSID&quot; = '602010802'" symbol="66" key="{31b5304c-1cdf-4984-96b7-5704e36140b8}"/>
        <rule label="Объект религиозной организации (объединения)" filter="&quot;CLASSID&quot; = '602010803'" symbol="67" key="{11cc05cd-67cc-43c9-9070-ab8a2df2b153}"/>
        <rule label="Объекты торговли, общественного питания" filter="&quot;CLASSID&quot; = '602010804'" symbol="68" key="{c54fc146-4a05-48c6-ae44-59f2ff52987f}"/>
        <rule label="Непроизводственный объект по предоставлению населению государственных правовых, финансовых, консультационных и иных подобных услуг" filter="&quot;CLASSID&quot; = '602010805'" symbol="69" key="{d8e1d95a-8aa5-44c5-91b5-ad4ce9f2607b}"/>
        <rule label="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" filter="&quot;CLASSID&quot; = '602010806'" symbol="70" key="{d2f9635d-82f8-4821-a9a4-335d8baacecf}"/>
        <rule label="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" filter="&quot;CLASSID&quot; = '602010807'" symbol="71" key="{34b8d304-cbf7-4ebe-9ade-2a3b5f90fb5f}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="72" key="{a607eed7-5046-447a-9693-508cdbe82825}">
        <rule label="Административное здание" filter="&quot;CLASSID&quot; = '602010801'" symbol="73" key="{06725422-7890-4959-9ea3-970c3c09c017}"/>
        <rule label="Объект проведения гражданских обрядов" filter="&quot;CLASSID&quot; = '602010802'" symbol="74" key="{7362b53c-51c5-4767-b86d-2a10d6af992b}"/>
        <rule label="Объект религиозной организации (объединения)" filter="&quot;CLASSID&quot; = '602010803'" symbol="75" key="{4663549c-f373-4fc2-9d90-b5d35f587edc}"/>
        <rule label="Объекты торговли, общественного питания" filter="&quot;CLASSID&quot; = '602010804'" symbol="76" key="{a203e121-0198-4b14-92d6-254ada5f457a}"/>
        <rule label="Непроизводственный объект по предоставлению населению государственных правовых, финансовых, консультационных и иных подобных услуг" filter="&quot;CLASSID&quot; = '602010805'" symbol="77" key="{1bac98c9-a1f2-4068-aa7e-9f3ef13d42fe}"/>
        <rule label="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" filter="&quot;CLASSID&quot; = '602010806'" symbol="78" key="{83d1b7da-af59-4dca-8715-2f6ad12ed77d}"/>
        <rule label="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" filter="&quot;CLASSID&quot; = '602010807'" symbol="79" key="{30ed4186-38df-4a27-a806-3ed51b180524}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="80" key="{fe3f1f62-e9ef-4570-b5e2-3de464da3e48}">
        <rule label="Административное здание" filter="&quot;CLASSID&quot; = '602010801'" symbol="81" key="{79b077c0-88bd-47da-88bb-16608ed5efa2}"/>
        <rule label="Объект проведения гражданских обрядов" filter="&quot;CLASSID&quot; = '602010802'" symbol="82" key="{db24597e-cdb4-47d4-b37a-a35f2f17d203}"/>
        <rule label="Объект религиозной организации (объединения)" filter="&quot;CLASSID&quot; = '602010803'" symbol="83" key="{3238b193-7627-47cf-a707-f5199c826f3e}"/>
        <rule label="Объекты торговли, общественного питания" filter="&quot;CLASSID&quot; = '602010804'" symbol="84" key="{3d5a9881-c959-45e9-8f64-e616203cd4a1}"/>
        <rule label="Непроизводственный объект по предоставлению населению государственных правовых, финансовых, консультационных и иных подобных услуг" filter="&quot;CLASSID&quot; = '602010805'" symbol="85" key="{f90a9c5e-09cf-4c41-8ca5-5cd9762983ee}"/>
        <rule label="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" filter="&quot;CLASSID&quot; = '602010806'" symbol="86" key="{c31bcde5-739c-4fd9-a013-1e7d78f20f3f}"/>
        <rule label="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" filter="&quot;CLASSID&quot; = '602010807'" symbol="87" key="{6d9f7f80-26c0-49f6-bb64-4f17c7a04ff2}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты федерального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 1" symbol="88" key="{aa06abfd-8675-4eee-8bba-e00b2d22638a}">
        <rule label="Административное здание" filter="&quot;CLASSID&quot; = '602010801'" symbol="89" key="{983bbef0-ff35-46e8-a89a-206fd5f706cc}"/>
        <rule label="Объект проведения гражданских обрядов" filter="&quot;CLASSID&quot; = '602010802'" symbol="90" key="{975e60e7-bb04-4cd9-8da7-ef0090f8bba5}"/>
        <rule label="Объект религиозной организации (объединения)" filter="&quot;CLASSID&quot; = '602010803'" symbol="91" key="{e0751f65-dbc0-4e9a-9222-039a20cd8fbb}"/>
        <rule label="Объекты торговли, общественного питания" filter="&quot;CLASSID&quot; = '602010804'" symbol="92" key="{150702a8-17cf-45ba-bdfb-d1310397250a}"/>
        <rule label="Непроизводственный объект по предоставлению населению государственных правовых, финансовых, консультационных и иных подобных услуг" filter="&quot;CLASSID&quot; = '602010805'" symbol="93" key="{b7f50962-7f90-4b87-8746-2dccf36e005f}"/>
        <rule label="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" filter="&quot;CLASSID&quot; = '602010806'" symbol="94" key="{7528d70b-6314-4e0c-b818-5893db316a1b}"/>
        <rule label="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" filter="&quot;CLASSID&quot; = '602010807'" symbol="95" key="{2b77efd7-0a87-4b98-b74e-9af1bdb18b49}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC45NW1tIiBoZWlnaHQ9IjExOS44bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC45NSAxMTkuOCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQuMTUxIDkwLjgwMi0wLjI0MzkxIDAuMzE5ODh2MjguNjc4aDEzMy4xM3YtMjguNjlsLTAuMjM1MTMtMC4zMDc0N2gtMzkuMTc5YTI5LjE0MyAyOS4wOTEgMCAwIDEtMTkuNzYzIDE3LjYwMSAyOS4xNDYgMjkuNDczIDAgMCAxLTEuMjM5NyAwLjMwOTU0IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDQzIDAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjU5NzMgMC4yMzYxNiAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAwMiAwLjEwMjgzIDI5LjE0NiAyOS40NzMgMCAwIDEtMi41NDQgMC4xMjQ1NCAyOS4xNDYgMjkuNDczIDAgMCAxLTAuMDAyMDY3IDAgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0yLjU0MTQtMC4xMjQ1NCAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAyNzktMC4xMDI4MyAyOS4xNDYgMjkuNDczIDAgMCAxLTEuNTkzNy0wLjIzNjE2IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDc5LTAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjI0NTQtMC4zMTE2MSAyOS4xNDMgMjkuMDkxIDAgMCAxLTE5Ljc1Ni0xNy41OTloLTM5LjE3eiIvPjxwYXRoIGQ9Im01MC4wNTQgNDMuODI1LTM2LjE0NyA0Ny4yOTdoMzkuNTQxYy0xLjM2NDEtMy40MjY1LTIuMDkyNy03LjA4MDgtMi4wOTQyLTEwLjc2OSAyLjAxZS00IC0xNi4wOTggMTMuMDUtMjkuMTQ4IDI5LjE0OS0yOS4xNDggMTYuMDk4IDJlLTQgMjkuMTQ4IDEzLjA1IDI5LjE0OCAyOS4xNDgtMmUtMyAzLjY4ODEtMC43OTM3OSA3LjM0MjMtMi4xNTc5IDEwLjc2OWgzOS41NDFsM2UtNSAtMC4wMTQ5OS0zNi4xMDktNDcuMjgyeiIvPjxyZWN0IHg9IjUyLjIzMiIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxyZWN0IHg9IjkzLjAxNCIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxwYXRoIGQ9Im0wIDUxLjA1OSAzOS40NTgtNS4yNDgydi0xMi4xMzRoLTQuOTAzOHYtMTIuOTk4bDMzLjM4NC0wLjE0ODkzdi0yMC4wMzNzLTI0LjQ0NSAxLjYyMTYtMzUuNjE0IDYuMTM1NmMtOC42MzQxIDMuNDg5Ni0xNi43OTEgOC44NjU4LTIzLjA5NiAxNS43MTktMy44NTU0IDQuMTkwNy04LjQwMzUgMTQuODczLTguNDAzNSAxNC44NzN6Ii8+PHBhdGggZD0ibTE2MC45NSA1MS4wNTktMzkuNDU4LTUuMjQ4MnYtMTIuMTM0aDQuOTAzOHYtMTIuOTk4bC0zMy4zODQtMC4xNDg5M3YtMjAuMDMzczI0LjQ0NSAxLjYyMTYgMzUuNjE0IDYuMTM1NmM4LjYzNDEgMy40ODk2IDE2Ljc5MSA4Ljg2NTggMjMuMDk2IDE1LjcxOSAzLjg1NTQgNC4xOTA3IDguNDAzNiAxNC44NzMgOC40MDM2IDE0Ljg3M3oiLz48cGF0aCBkPSJtMzQuNTU0IDIwLjY3OWg5MS44NDR2LTE0Ljg1NnMtMjIuMTUtNC40MzU4LTMzLjM4NC01LjMyNjJjLTguMzMyNy0wLjY2MDU1LTE2Ljc0NC0wLjY2NTA1LTI1LjA3NyA1ZS02IC0xMS4zMDggMC45MDI1Ni0zMy42MDEgNS4zOTgyLTMzLjYwMSA1LjM5ODJsMC4yMTcyMyAxNC43ODQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNC4yOW1tIiBoZWlnaHQ9IjE1OC4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjQuMjkgMTU4LjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC44NjcgLTY5LjQxKSI+PHJlY3QgeD0iMTUyLjU3IiB5PSI5NC4yMjUiIHdpZHRoPSIxMS4yNDMiIGhlaWdodD0iMTMzLjE5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxjaXJjbGUgY3g9IjE1OC42NSIgY3k9Ijc5LjkxMSIgcj0iMTAuNTAxIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im0xNDYuMDQgOTMuNzY1djc2LjM0MnMtMjQuNzA4IDAuMjUwNTgtMzYuMTYyIDQuMjY3NWMtMTMuMjcxIDQuNjU0MS0yMi42MDkgMTcuNDU2LTM1LjgwOSAyMi4zMDgtNi4xMjYyIDIuMjUxOC0xMi45OTkgMS40NTE3LTE5LjM2OSAyLjg3NDItMy4zNDA0IDAuNzQ1OTYtOS44MzMgMi45NTY4LTkuODMzIDIuOTU2OHYtNzYuNTY2czI2LjE5Ni0xLjcyOTIgMzcuODgxLTcuMDYxN2M5LjAyMDMtNC4xMTYzIDE0LjIxNy0xNC40OTMgMjMuMjgtMTguNTE2IDEyLjM1NS01LjQ4NDMgNDAuMDExLTYuNjA0OCA0MC4wMTEtNi42MDQ4eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.0903" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OC4yN21tIiBoZWlnaHQ9IjE0Ni4wNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDguMjcgMTQ2LjA2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMi44MDQgLTc1LjU0OCkiPjxwYXRoIGQ9Im0zMi44MDQgNzUuNTQ4czM1LjAwOSAyLjEyNTkgNTAuOTU1IDE4LjY1NGMxOS4yMDUgMTkuOTA2IDIzLjE4IDU0LjM3NyAyMy4xOCA1NC4zNzdzLTMyLjk5MS0xLjY4MzEtNTMuNDA3LTIxLjcxNmMtMTkuMTEzLTE4Ljc1NS0yMC43MjctNTEuMzE0LTIwLjcyNy01MS4zMTR6Ii8+PHBhdGggZD0ibTE4MS4wNyA3NS41NDhzLTM1LjAwOSAyLjEyNTktNTAuOTU1IDE4LjY1NGMtMTkuMjA1IDE5LjkwNi0yMy4xOCA1NC4zNzctMjMuMTggNTQuMzc3czMyLjk5MS0xLjY4MzEgNTMuNDA3LTIxLjcxNmMxOS4xMTMtMTguNzU1IDIwLjcyNy01MS4zMTQgMjAuNzI3LTUxLjMxNHoiLz48cGF0aCBkPSJtMTgxLjA3IDIyMS42MXMtMzUuMDA5LTIuMTI1OS01MC45NTUtMTguNjU0Yy0xOS4yMDUtMTkuOTA2LTIzLjE4LTU0LjM3Ny0yMy4xOC01NC4zNzdzMzIuOTkxIDEuNjgzMSA1My40MDcgMjEuNzE2YzE5LjExMyAxOC43NTUgMjAuNzI3IDUxLjMxNCAyMC43MjcgNTEuMzE0eiIvPjxwYXRoIGQ9Im0zMi44MDQgMjIxLjYxczM1LjAwOS0yLjEyNTkgNTAuOTU1LTE4LjY1NGMxOS4yMDUtMTkuOTA2IDIzLjE4LTU0LjM3NyAyMy4xOC01NC4zNzdzLTMyLjk5MSAxLjY4MzEtNTMuNDA3IDIxLjcxNmMtMTkuMTEzIDE4Ljc1NS0yMC43MjcgNTEuMzE0LTIwLjcyNyA1MS4zMTR6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg5LjAwNG1tIiBoZWlnaHQ9IjE2MS4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4OS4wMDQgMTYxLjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxyZWN0IHg9IjE0LjY3NiIgeT0iNTguNzQ4IiB3aWR0aD0iMTYuMTY5IiBoZWlnaHQ9IjEwMi4yNiIgcnk9IjcuMzI5MiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cGF0aCBkPSJtMWUtNiAzNy45ODV2MjAuODMxYzAgNC45MTY3IDMuOTU4MiA4Ljg3NTQgOC44NzQ5IDguODc1NGgyNy43NzJjNC45MTY3IDAgOC44NzQ5LTMuOTU4NyA4Ljg3NDktOC44NzU0di0yMC44MzFoLTguNzg3MWMtMWUtNiA1LjM3ODEtNy4yN2UtNCA5LjcxLTAuMDAxNiA5LjcxaC01LjMyOTljLTMuODdlLTQgMC0wLjAwMTUtNC4zMzE5LTAuMDAxNS05LjcxaC01Ljk3NDNjLTFlLTYgNS4zNzgxLTcuMjdlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc0ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTYtOS43MWgtNS45NzQzYzAgNS4zNzgxLTcuMjVlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc1ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTUtOS43MXoiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iLTQuMTI2ZS03IiB5PSIuMDAyMDciIHdpZHRoPSI4Ljc4ODYiIGhlaWdodD0iNDcuODQyIiByeD0iMCIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMzYuNzMzIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjguNzg4NiIgaGVpZ2h0PSI0Ny44NDIiIHJ4PSIwIiByeT0iMCIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSIxNC4xMTkiIHk9IjIuNDU5ZS02IiB3aWR0aD0iNS45Nzc0IiBoZWlnaHQ9IjQ3LjY5NSIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMjUuNDI2IiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjUuOTc3NCIgaGVpZ2h0PSI0Ny42OTUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjcxLjQ2MSIgeT0iMi40NTllLTYiIHdpZHRoPSIxNy41NDMiIGhlaWdodD0iMTYxLjAxIiByeT0iNy40NDA1IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im03My43OTUgMGMtOC4zNzU0IDAtMTUuMTE4IDYuNjI3Ni0xNS4xMTggMTQuODZ2MjguMThoMzAuMzI3di0yOC4xOGMwLTguMjMyNS02Ljc0MzEtMTQuODYtMTUuMTE4LTE0Ljg2eiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSI1OC42NzciIHk9IjMyLjAyMiIgd2lkdGg9IjMwLjMyNyIgaGVpZ2h0PSI2NS45MzMiIHJ5PSI5LjA5NjkiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iNzMuNzExIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjE1LjI5MyIgaGVpZ2h0PSIyNC40MzUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.0956" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MG1tIiBoZWlnaHQ9IjE1Ni4ybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MCAxNTYuMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjUuOTIyIC03MC45OCkiPjxnPjxwYXRoIGQ9Im0xNTIgOTQuNzA1LTMzLjIgOTEuMzgzcy0yLjY1MTIgOS4yNjg1IDEuNjc5NSAxOS43OTNjNC4xMTk0IDEwLjAxMSAxNC43OCAyMS4zMDUgMzEuNTIgMjEuMzA1IDE1LjUyIDAgMjYuMjI3LTEwLjA5MiAzMC42MzUtMTkuMjkzIDUuMzQ1OS0xMS4xNTcgMi41NzYxLTIxLjgwNCAyLjU3NjEtMjEuODA0em02ZS0zIDMxLjU5MSAyMy4zNjcgNTkuNzkyaC00Ni43MzR6Ii8+PHBhdGggZD0ibTU5LjkyNSA5NC43MDQtMzMuMiA5MS4zODNzLTIuNjUxMiA5LjI2ODUgMS42Nzk1IDE5Ljc5M2M0LjExOTQgMTAuMDExIDE0Ljc4IDIxLjMwNSAzMS41MiAyMS4zMDUgMTUuNTIgMCAyNi4yMjctMTAuMDkyIDMwLjYzNS0xOS4yOTMgNS4zNDU5LTExLjE1NyAyLjU3NjEtMjEuODA0IDIuNTc2MS0yMS44MDR6bTAuMDA1NyAzMS41OTEgMjMuMzY3IDU5Ljc5MmgtNDYuNzM0eiIvPjxyZWN0IHg9Ijk2LjEwMyIgeT0iNzAuOTgiIHdpZHRoPSIxOS43MTQiIGhlaWdodD0iMjQuOTUzIiByeT0iMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjEuOTQ4IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjU2LjIzNCIgeT0iOTIuMzE0IiB3aWR0aD0iOTkuNDYzIiBoZWlnaHQ9IjEyLjU2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjAuNDM5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48cGF0aCBjbGFzcz0iVW5vcHRpbWljZWRUcmFuc2Zvcm1zIiBkPSJtMCAwIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE1Ni4xOG1tIiBoZWlnaHQ9IjkwLjY4NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNTYuMTggOTAuNjg1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjE3LjQwMiIgY3k9IjE3LjQwMiIgcj0iMTQuMTg5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utb3BhY2l0eT0iLjk5MDE0IiBzdHJva2Utd2lkdGg9IjYuNDI1IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PGNpcmNsZSBjeD0iMTcuNDAyIiBjeT0iNzMuMjgzIiByPSIxNC4xODkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS1vcGFjaXR5PSIuOTkwMTQiIHN0cm9rZS13aWR0aD0iNi40MjUiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48Zz48cGF0aCBkPSJtMjYuMzA0IDMxLjY4NSA5LjE3OTUtMC40NDkxIDg5LjAyOSAzOS40M2gyOS4wNzFsLTExNi41OC00Ni42ODQtNS40MTE5LTYuNTgwNXoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjYuOSIvPjxwYXRoIGQ9Im0yNi4zMDQgNTkgOS4xNzk1IDAuNDQ5MSA4OS4wMjktMzkuNDNoMjkuMDcxbC0xMTYuNTggNDYuNjg0LTUuNDExOSA2LjU4MDV6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI2LjkiLz48cGF0aCBkPSJtNzUuNDE0IDQ1LjU2MS0xOC42ODUgOC43MTUydi0xNy40M3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ni4yNG1tIiBoZWlnaHQ9IjEzNi44Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDYuMjQgMTM2LjgyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zOC41MDYgLTc4LjkyOSkiPjxwYXRoIGQ9Im0xNjYuMDIgNzguOTI5cy04LjU0OTggMC43Nzc3OS0xMi4xNSAyLjg2MzljLTUuNzc0NyAzLjM0Ni05LjY3ODUgOS4yNzkzLTEzLjY3NyAxNC42MjMtMi4zNTQ0IDMuMTQ2My01LjU2MjYgOC45MTMyLTcuMzI1MSAxMi4xODJsMjEuNDc2IDIxLjQ3NmMwLjA3MzMtMC4wOTMgMC45MTUzLTAuOTQxOTMgMC4yMDgyNi0wLjI2ODcyIDEuMTM5MS0xLjU0OTYgMC4wMjUxLTUuMDkzNiAyLjg4NjgtNS4yNjE4IDUuNTY5LTAuMzI3MzYgMTMuMzYtMi4yMDkxIDE0LjIwMi0yLjMzOTkgMC44NDI4OC0wLjEzMDg1IDExLjU0NC0xLjYwMzYgMTIuNjYtNS43NjY3IDAuNjQ2MTgtMi40MTE2IDAuMzk5MzktMy40NTU0IDAuMzk5MzktNi41MzMyIDAtNC45Mjg2LTkuNjU3NC01LjEwNzctMTMuNjQ0LTguMjEwOS0zLjA3NDktMi4zOTMzLTUuMTAyLTUuMTA3Ny01LjkyNTctOC45MTYzLTEuMDAzMy00LjYzODkgMC44OTAzOS0xMy44NDcgMC44OTAzOS0xMy44NDd6Ii8+PHBhdGggZD0ibTQ4LjEwMSA5Mi44ODdzLTkuMjI0OCA5LjMzODYtOS41ODA4IDE1LjM2M2MtMC4zOTUzNSA2LjY5MTEgNy4yMjU4IDExLjUwNSA4LjU1NjYgMTguMTk3IDAuNDE1MjcgMi4wODg0IDAuNTc0MzIgMy45NTYtMC4yNTA2MyA1LjkxOS0xLjA1NTIgMi41MTEtMy40ODE5IDMuNTc3NC00LjMzNDEgNi4xMDItMC44NzAwNyAyLjU3NzYtMS45MDQxIDUuNTMyOC0wLjU4NTQ5IDguNjE3NiAwLjUwNjM3IDEuMTg0NiAxLjE2NjQgMi41ODMgMS41MDY0IDMuODI1NiAxLjM5ODIgNS4xMTEgMS4zMjAxIDEwLjIyMSAwLjAzNDExIDE1LjYxNy0wLjc0MTggMy4xMTI2LTMuMzc1OCA1LjcwMjgtNC4zODExIDguNzQwNi0wLjY2NDQ0IDIuMDA3Ny0wLjYyMTQ1IDQuMjUzNi0wLjI2ODIgNi4zMzg2IDEuMjg5OCA3LjYxMjggNi41OTEgMTQuMDYgOC41NDczIDIxLjUyOSAwLjg5MzY1IDMuNDEyMS0yLjA3NDggMTAuNDg2IDEuNDE3NSAxMC40ODYgNC41MzE5IDAgNC4yMDI3LTAuMDEzNCA4LjEzNDQtMC4wMTM0IDIuODA4MiAwLTAuMTEwMDMtNS42NDUtMC42NjE5OC04LjM5ODQtMC41NzQ2OC0yLjg2NjktMS4zNjY2LTUuODA3Ni0xLjg1MDMtOC42OTItMC40ODI5OS0yLjg4MDMtMC45NDc3Mi01LjI5MTggMC4yMjQ0OC04LjIzNzggMS4yMTAyLTMuMDQxNSAyLjc4NzgtMi41NzAxIDMuNTAyMS0xLjM2OTIgMi4zNDk3IDMuOTUwMyAyLjczNDcgOS42MzkgMy41ODc0IDEzLjY4MiAwLjE2NzAzIDAuNzkxOTIgMi43MTQ2IDYuNTgwNSAyLjcxNDYgNi41ODA1czAuMDE3MTYgNy44MTA0IDIuNzgwNyA3LjgxMDRoMTIuMTAyYzEuNjY4OCAwIDIuOTk0NS0yLjUwNiAyLjc4MzgtNC4xNjE1LTAuNTA3NjUtMy45ODgyLTkuMDA0MS00LjAwNDUtOS4wMDQxLTguMDI0OCAwLTkuNDAzOC0yLjY2NjMtMTkuOTIyIDAtMjkuODczIDAuNDU0MzMtMS42OTU2IDIuODM0Mi0yLjAzOTUgMy44MDI0LTMuNjQzMiAyLjAxNDgtMy4zMzc0IDAuNjY2MzUtNy43MTQyIDIuNDkyNC0xMS4yNTkgMS4yNzExLTIuNDY3MyAyLjY4NzEtNC41ODg0IDUuNTYzLTUuNzM0NSAzLjYwMTUtMS40MzU0IDcuNjkyOC0xLjI0NTQgMTEuMjQzIDAuMzEzMTYgNy4yNDY4IDMuMTgxNiAxMC45NzUgMTEuODk0IDE3LjM4OSAxNS41MjYgMy40NTg0IDEuOTU4NSA4LjgwNTItMC4yMjIyNCAxMi41IDEuMjQyMyAxLjQ5NTIgMC41OTI2NyAyLjg3NTQgMS4wNDc0IDMuMDI4MiAyLjMwNzQgMC41NjI2OSA0LjY0IDEuMDQ1NiA4LjczOTkgMCAxMi42NDItMC4zMTE5OSAxLjE2NDQtMC42OTQ4MSAwLjk2OTE5LTEuMDE4OSAyLjEzMDItMC44NjQ5NyAzLjA5ODQtMC43NTcwNCA0LjgzNzUtMC4yODQ5MyA3LjYwMTQgMC4xNjk4NyAwLjk5NDQ2IDEuMDA0NyAxLjkyODUgMS4wMDQ3IDIuOTM3NCAwIDcuMDE5NC00LjQ0NTEgMTguNzU2IDEuODE0NCAxOC43NTZoMTQuNDE3YzEuNjMyOSAwIDIuMTU2LTEuMjA3NSAyLjkxMjUtMi42NTQ2IDAuNzMxNjctMS4zOTk2IDAuOTMwMTctNC4yODQyIDAuMTg2MDQtNS42NzcyLTEuNTQ2Ni0yLjg5NTItNi4zODYtMC43Njg0NC03LjEzMzQtMy41NTc5LTIuODk0Mi0xMC44MDEtMC4wMzItMjQuMjU5LTAuMDMyLTM2LjMwOCAwLTUuNzUzMiA4LjE1MDctOC43MDM0IDkuNzgwOC0xNC4yMjEgMS4zODIxLTQuNjc3OSAyLjkwNzctOS44OTg0IDEuNzEtMTQuNTI0bC0yNC41LTI0LjVjLTEuMjExMS0wLjM2Mzc1LTIuNDM2Ny0wLjYzODQyLTMuNjczMi0wLjc5OTk1LTUuMjA5NC0wLjY4MDUzLTE0LjEyIDYuNTc2OS0xNC4xMiA2LjU3NjloLTU0LjUwNWMtMy4xNTI2IDAtNC45Njg5LTEuMjg4OC03LjIwNDktNC4yODI0LTEuNTgxNC0yLjExNzEtMy43NzA4LTYuMzc0Ny0zLjc0ODQtOC43MTI5IDAuMDI2MjEtMi43NDQ4IDIuMjIxMy01LjE2OTYgMy42MDctOC4yMTQ4IDAuNzk2MS0xLjc0OTUtMC4yMDQxMi01Ljk4MzEtMC4yMDQxMi01Ljk4MzF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0.10476190476190476,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC45NW1tIiBoZWlnaHQ9IjExOS44bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC45NSAxMTkuOCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQuMTUxIDkwLjgwMi0wLjI0MzkxIDAuMzE5ODh2MjguNjc4aDEzMy4xM3YtMjguNjlsLTAuMjM1MTMtMC4zMDc0N2gtMzkuMTc5YTI5LjE0MyAyOS4wOTEgMCAwIDEtMTkuNzYzIDE3LjYwMSAyOS4xNDYgMjkuNDczIDAgMCAxLTEuMjM5NyAwLjMwOTU0IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDQzIDAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjU5NzMgMC4yMzYxNiAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAwMiAwLjEwMjgzIDI5LjE0NiAyOS40NzMgMCAwIDEtMi41NDQgMC4xMjQ1NCAyOS4xNDYgMjkuNDczIDAgMCAxLTAuMDAyMDY3IDAgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0yLjU0MTQtMC4xMjQ1NCAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAyNzktMC4xMDI4MyAyOS4xNDYgMjkuNDczIDAgMCAxLTEuNTkzNy0wLjIzNjE2IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDc5LTAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjI0NTQtMC4zMTE2MSAyOS4xNDMgMjkuMDkxIDAgMCAxLTE5Ljc1Ni0xNy41OTloLTM5LjE3eiIvPjxwYXRoIGQ9Im01MC4wNTQgNDMuODI1LTM2LjE0NyA0Ny4yOTdoMzkuNTQxYy0xLjM2NDEtMy40MjY1LTIuMDkyNy03LjA4MDgtMi4wOTQyLTEwLjc2OSAyLjAxZS00IC0xNi4wOTggMTMuMDUtMjkuMTQ4IDI5LjE0OS0yOS4xNDggMTYuMDk4IDJlLTQgMjkuMTQ4IDEzLjA1IDI5LjE0OCAyOS4xNDgtMmUtMyAzLjY4ODEtMC43OTM3OSA3LjM0MjMtMi4xNTc5IDEwLjc2OWgzOS41NDFsM2UtNSAtMC4wMTQ5OS0zNi4xMDktNDcuMjgyeiIvPjxyZWN0IHg9IjUyLjIzMiIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxyZWN0IHg9IjkzLjAxNCIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxwYXRoIGQ9Im0wIDUxLjA1OSAzOS40NTgtNS4yNDgydi0xMi4xMzRoLTQuOTAzOHYtMTIuOTk4bDMzLjM4NC0wLjE0ODkzdi0yMC4wMzNzLTI0LjQ0NSAxLjYyMTYtMzUuNjE0IDYuMTM1NmMtOC42MzQxIDMuNDg5Ni0xNi43OTEgOC44NjU4LTIzLjA5NiAxNS43MTktMy44NTU0IDQuMTkwNy04LjQwMzUgMTQuODczLTguNDAzNSAxNC44NzN6Ii8+PHBhdGggZD0ibTE2MC45NSA1MS4wNTktMzkuNDU4LTUuMjQ4MnYtMTIuMTM0aDQuOTAzOHYtMTIuOTk4bC0zMy4zODQtMC4xNDg5M3YtMjAuMDMzczI0LjQ0NSAxLjYyMTYgMzUuNjE0IDYuMTM1NmM4LjYzNDEgMy40ODk2IDE2Ljc5MSA4Ljg2NTggMjMuMDk2IDE1LjcxOSAzLjg1NTQgNC4xOTA3IDguNDAzNiAxNC44NzMgOC40MDM2IDE0Ljg3M3oiLz48cGF0aCBkPSJtMzQuNTU0IDIwLjY3OWg5MS44NDR2LTE0Ljg1NnMtMjIuMTUtNC40MzU4LTMzLjM4NC01LjMyNjJjLTguMzMyNy0wLjY2MDU1LTE2Ljc0NC0wLjY2NTA1LTI1LjA3NyA1ZS02IC0xMS4zMDggMC45MDI1Ni0zMy42MDEgNS4zOTgyLTMzLjYwMSA1LjM5ODJsMC4yMTcyMyAxNC43ODQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNC4yOW1tIiBoZWlnaHQ9IjE1OC4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjQuMjkgMTU4LjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC44NjcgLTY5LjQxKSI+PHJlY3QgeD0iMTUyLjU3IiB5PSI5NC4yMjUiIHdpZHRoPSIxMS4yNDMiIGhlaWdodD0iMTMzLjE5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxjaXJjbGUgY3g9IjE1OC42NSIgY3k9Ijc5LjkxMSIgcj0iMTAuNTAxIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im0xNDYuMDQgOTMuNzY1djc2LjM0MnMtMjQuNzA4IDAuMjUwNTgtMzYuMTYyIDQuMjY3NWMtMTMuMjcxIDQuNjU0MS0yMi42MDkgMTcuNDU2LTM1LjgwOSAyMi4zMDgtNi4xMjYyIDIuMjUxOC0xMi45OTkgMS40NTE3LTE5LjM2OSAyLjg3NDItMy4zNDA0IDAuNzQ1OTYtOS44MzMgMi45NTY4LTkuODMzIDIuOTU2OHYtNzYuNTY2czI2LjE5Ni0xLjcyOTIgMzcuODgxLTcuMDYxN2M5LjAyMDMtNC4xMTYzIDE0LjIxNy0xNC40OTMgMjMuMjgtMTguNTE2IDEyLjM1NS01LjQ4NDMgNDAuMDExLTYuNjA0OCA0MC4wMTEtNi42MDQ4eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28508" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OC4yN21tIiBoZWlnaHQ9IjE0Ni4wNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDguMjcgMTQ2LjA2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMi44MDQgLTc1LjU0OCkiPjxwYXRoIGQ9Im0zMi44MDQgNzUuNTQ4czM1LjAwOSAyLjEyNTkgNTAuOTU1IDE4LjY1NGMxOS4yMDUgMTkuOTA2IDIzLjE4IDU0LjM3NyAyMy4xOCA1NC4zNzdzLTMyLjk5MS0xLjY4MzEtNTMuNDA3LTIxLjcxNmMtMTkuMTEzLTE4Ljc1NS0yMC43MjctNTEuMzE0LTIwLjcyNy01MS4zMTR6Ii8+PHBhdGggZD0ibTE4MS4wNyA3NS41NDhzLTM1LjAwOSAyLjEyNTktNTAuOTU1IDE4LjY1NGMtMTkuMjA1IDE5LjkwNi0yMy4xOCA1NC4zNzctMjMuMTggNTQuMzc3czMyLjk5MS0xLjY4MzEgNTMuNDA3LTIxLjcxNmMxOS4xMTMtMTguNzU1IDIwLjcyNy01MS4zMTQgMjAuNzI3LTUxLjMxNHoiLz48cGF0aCBkPSJtMTgxLjA3IDIyMS42MXMtMzUuMDA5LTIuMTI1OS01MC45NTUtMTguNjU0Yy0xOS4yMDUtMTkuOTA2LTIzLjE4LTU0LjM3Ny0yMy4xOC01NC4zNzdzMzIuOTkxIDEuNjgzMSA1My40MDcgMjEuNzE2YzE5LjExMyAxOC43NTUgMjAuNzI3IDUxLjMxNCAyMC43MjcgNTEuMzE0eiIvPjxwYXRoIGQ9Im0zMi44MDQgMjIxLjYxczM1LjAwOS0yLjEyNTkgNTAuOTU1LTE4LjY1NGMxOS4yMDUtMTkuOTA2IDIzLjE4LTU0LjM3NyAyMy4xOC01NC4zNzdzLTMyLjk5MSAxLjY4MzEtNTMuNDA3IDIxLjcxNmMtMTkuMTEzIDE4Ljc1NS0yMC43MjcgNTEuMzE0LTIwLjcyNyA1MS4zMTR6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNC4yOW1tIiBoZWlnaHQ9IjE1OC4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjQuMjkgMTU4LjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC44NjcgLTY5LjQxKSI+PHJlY3QgeD0iMTUyLjU3IiB5PSI5NC4yMjUiIHdpZHRoPSIxMS4yNDMiIGhlaWdodD0iMTMzLjE5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxjaXJjbGUgY3g9IjE1OC42NSIgY3k9Ijc5LjkxMSIgcj0iMTAuNTAxIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im0xNDYuMDQgOTMuNzY1djc2LjM0MnMtMjQuNzA4IDAuMjUwNTgtMzYuMTYyIDQuMjY3NWMtMTMuMjcxIDQuNjU0MS0yMi42MDkgMTcuNDU2LTM1LjgwOSAyMi4zMDgtNi4xMjYyIDIuMjUxOC0xMi45OTkgMS40NTE3LTE5LjM2OSAyLjg3NDItMy4zNDA0IDAuNzQ1OTYtOS44MzMgMi45NTY4LTkuODMzIDIuOTU2OHYtNzYuNTY2czI2LjE5Ni0xLjcyOTIgMzcuODgxLTcuMDYxN2M5LjAyMDMtNC4xMTYzIDE0LjIxNy0xNC40OTMgMjMuMjgtMTguNTE2IDEyLjM1NS01LjQ4NDMgNDAuMDExLTYuNjA0OCA0MC4wMTEtNi42MDQ4eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.0903" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg5LjAwNG1tIiBoZWlnaHQ9IjE2MS4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4OS4wMDQgMTYxLjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxyZWN0IHg9IjE0LjY3NiIgeT0iNTguNzQ4IiB3aWR0aD0iMTYuMTY5IiBoZWlnaHQ9IjEwMi4yNiIgcnk9IjcuMzI5MiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cGF0aCBkPSJtMWUtNiAzNy45ODV2MjAuODMxYzAgNC45MTY3IDMuOTU4MiA4Ljg3NTQgOC44NzQ5IDguODc1NGgyNy43NzJjNC45MTY3IDAgOC44NzQ5LTMuOTU4NyA4Ljg3NDktOC44NzU0di0yMC44MzFoLTguNzg3MWMtMWUtNiA1LjM3ODEtNy4yN2UtNCA5LjcxLTAuMDAxNiA5LjcxaC01LjMyOTljLTMuODdlLTQgMC0wLjAwMTUtNC4zMzE5LTAuMDAxNS05LjcxaC01Ljk3NDNjLTFlLTYgNS4zNzgxLTcuMjdlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc0ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTYtOS43MWgtNS45NzQzYzAgNS4zNzgxLTcuMjVlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc1ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTUtOS43MXoiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iLTQuMTI2ZS03IiB5PSIuMDAyMDciIHdpZHRoPSI4Ljc4ODYiIGhlaWdodD0iNDcuODQyIiByeD0iMCIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMzYuNzMzIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjguNzg4NiIgaGVpZ2h0PSI0Ny44NDIiIHJ4PSIwIiByeT0iMCIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSIxNC4xMTkiIHk9IjIuNDU5ZS02IiB3aWR0aD0iNS45Nzc0IiBoZWlnaHQ9IjQ3LjY5NSIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMjUuNDI2IiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjUuOTc3NCIgaGVpZ2h0PSI0Ny42OTUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjcxLjQ2MSIgeT0iMi40NTllLTYiIHdpZHRoPSIxNy41NDMiIGhlaWdodD0iMTYxLjAxIiByeT0iNy40NDA1IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im03My43OTUgMGMtOC4zNzU0IDAtMTUuMTE4IDYuNjI3Ni0xNS4xMTggMTQuODZ2MjguMThoMzAuMzI3di0yOC4xOGMwLTguMjMyNS02Ljc0MzEtMTQuODYtMTUuMTE4LTE0Ljg2eiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSI1OC42NzciIHk9IjMyLjAyMiIgd2lkdGg9IjMwLjMyNyIgaGVpZ2h0PSI2NS45MzMiIHJ5PSI5LjA5NjkiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iNzMuNzExIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjE1LjI5MyIgaGVpZ2h0PSIyNC40MzUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.0956" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MG1tIiBoZWlnaHQ9IjE1Ni4ybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MCAxNTYuMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjUuOTIyIC03MC45OCkiPjxnPjxwYXRoIGQ9Im0xNTIgOTQuNzA1LTMzLjIgOTEuMzgzcy0yLjY1MTIgOS4yNjg1IDEuNjc5NSAxOS43OTNjNC4xMTk0IDEwLjAxMSAxNC43OCAyMS4zMDUgMzEuNTIgMjEuMzA1IDE1LjUyIDAgMjYuMjI3LTEwLjA5MiAzMC42MzUtMTkuMjkzIDUuMzQ1OS0xMS4xNTcgMi41NzYxLTIxLjgwNCAyLjU3NjEtMjEuODA0em02ZS0zIDMxLjU5MSAyMy4zNjcgNTkuNzkyaC00Ni43MzR6Ii8+PHBhdGggZD0ibTU5LjkyNSA5NC43MDQtMzMuMiA5MS4zODNzLTIuNjUxMiA5LjI2ODUgMS42Nzk1IDE5Ljc5M2M0LjExOTQgMTAuMDExIDE0Ljc4IDIxLjMwNSAzMS41MiAyMS4zMDUgMTUuNTIgMCAyNi4yMjctMTAuMDkyIDMwLjYzNS0xOS4yOTMgNS4zNDU5LTExLjE1NyAyLjU3NjEtMjEuODA0IDIuNTc2MS0yMS44MDR6bTAuMDA1NyAzMS41OTEgMjMuMzY3IDU5Ljc5MmgtNDYuNzM0eiIvPjxyZWN0IHg9Ijk2LjEwMyIgeT0iNzAuOTgiIHdpZHRoPSIxOS43MTQiIGhlaWdodD0iMjQuOTUzIiByeT0iMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjEuOTQ4IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjU2LjIzNCIgeT0iOTIuMzE0IiB3aWR0aD0iOTkuNDYzIiBoZWlnaHQ9IjEyLjU2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjAuNDM5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48cGF0aCBjbGFzcz0iVW5vcHRpbWljZWRUcmFuc2Zvcm1zIiBkPSJtMCAwIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE1Ni4xOG1tIiBoZWlnaHQ9IjkwLjY4NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNTYuMTggOTAuNjg1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjE3LjQwMiIgY3k9IjE3LjQwMiIgcj0iMTQuMTg5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utb3BhY2l0eT0iLjk5MDE0IiBzdHJva2Utd2lkdGg9IjYuNDI1IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PGNpcmNsZSBjeD0iMTcuNDAyIiBjeT0iNzMuMjgzIiByPSIxNC4xODkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS1vcGFjaXR5PSIuOTkwMTQiIHN0cm9rZS13aWR0aD0iNi40MjUiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48Zz48cGF0aCBkPSJtMjYuMzA0IDMxLjY4NSA5LjE3OTUtMC40NDkxIDg5LjAyOSAzOS40M2gyOS4wNzFsLTExNi41OC00Ni42ODQtNS40MTE5LTYuNTgwNXoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjYuOSIvPjxwYXRoIGQ9Im0yNi4zMDQgNTkgOS4xNzk1IDAuNDQ5MSA4OS4wMjktMzkuNDNoMjkuMDcxbC0xMTYuNTggNDYuNjg0LTUuNDExOSA2LjU4MDV6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI2LjkiLz48cGF0aCBkPSJtNzUuNDE0IDQ1LjU2MS0xOC42ODUgOC43MTUydi0xNy40M3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ni4yNG1tIiBoZWlnaHQ9IjEzNi44Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDYuMjQgMTM2LjgyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zOC41MDYgLTc4LjkyOSkiPjxwYXRoIGQ9Im0xNjYuMDIgNzguOTI5cy04LjU0OTggMC43Nzc3OS0xMi4xNSAyLjg2MzljLTUuNzc0NyAzLjM0Ni05LjY3ODUgOS4yNzkzLTEzLjY3NyAxNC42MjMtMi4zNTQ0IDMuMTQ2My01LjU2MjYgOC45MTMyLTcuMzI1MSAxMi4xODJsMjEuNDc2IDIxLjQ3NmMwLjA3MzMtMC4wOTMgMC45MTUzLTAuOTQxOTMgMC4yMDgyNi0wLjI2ODcyIDEuMTM5MS0xLjU0OTYgMC4wMjUxLTUuMDkzNiAyLjg4NjgtNS4yNjE4IDUuNTY5LTAuMzI3MzYgMTMuMzYtMi4yMDkxIDE0LjIwMi0yLjMzOTkgMC44NDI4OC0wLjEzMDg1IDExLjU0NC0xLjYwMzYgMTIuNjYtNS43NjY3IDAuNjQ2MTgtMi40MTE2IDAuMzk5MzktMy40NTU0IDAuMzk5MzktNi41MzMyIDAtNC45Mjg2LTkuNjU3NC01LjEwNzctMTMuNjQ0LTguMjEwOS0zLjA3NDktMi4zOTMzLTUuMTAyLTUuMTA3Ny01LjkyNTctOC45MTYzLTEuMDAzMy00LjYzODkgMC44OTAzOS0xMy44NDcgMC44OTAzOS0xMy44NDd6Ii8+PHBhdGggZD0ibTQ4LjEwMSA5Mi44ODdzLTkuMjI0OCA5LjMzODYtOS41ODA4IDE1LjM2M2MtMC4zOTUzNSA2LjY5MTEgNy4yMjU4IDExLjUwNSA4LjU1NjYgMTguMTk3IDAuNDE1MjcgMi4wODg0IDAuNTc0MzIgMy45NTYtMC4yNTA2MyA1LjkxOS0xLjA1NTIgMi41MTEtMy40ODE5IDMuNTc3NC00LjMzNDEgNi4xMDItMC44NzAwNyAyLjU3NzYtMS45MDQxIDUuNTMyOC0wLjU4NTQ5IDguNjE3NiAwLjUwNjM3IDEuMTg0NiAxLjE2NjQgMi41ODMgMS41MDY0IDMuODI1NiAxLjM5ODIgNS4xMTEgMS4zMjAxIDEwLjIyMSAwLjAzNDExIDE1LjYxNy0wLjc0MTggMy4xMTI2LTMuMzc1OCA1LjcwMjgtNC4zODExIDguNzQwNi0wLjY2NDQ0IDIuMDA3Ny0wLjYyMTQ1IDQuMjUzNi0wLjI2ODIgNi4zMzg2IDEuMjg5OCA3LjYxMjggNi41OTEgMTQuMDYgOC41NDczIDIxLjUyOSAwLjg5MzY1IDMuNDEyMS0yLjA3NDggMTAuNDg2IDEuNDE3NSAxMC40ODYgNC41MzE5IDAgNC4yMDI3LTAuMDEzNCA4LjEzNDQtMC4wMTM0IDIuODA4MiAwLTAuMTEwMDMtNS42NDUtMC42NjE5OC04LjM5ODQtMC41NzQ2OC0yLjg2NjktMS4zNjY2LTUuODA3Ni0xLjg1MDMtOC42OTItMC40ODI5OS0yLjg4MDMtMC45NDc3Mi01LjI5MTggMC4yMjQ0OC04LjIzNzggMS4yMTAyLTMuMDQxNSAyLjc4NzgtMi41NzAxIDMuNTAyMS0xLjM2OTIgMi4zNDk3IDMuOTUwMyAyLjczNDcgOS42MzkgMy41ODc0IDEzLjY4MiAwLjE2NzAzIDAuNzkxOTIgMi43MTQ2IDYuNTgwNSAyLjcxNDYgNi41ODA1czAuMDE3MTYgNy44MTA0IDIuNzgwNyA3LjgxMDRoMTIuMTAyYzEuNjY4OCAwIDIuOTk0NS0yLjUwNiAyLjc4MzgtNC4xNjE1LTAuNTA3NjUtMy45ODgyLTkuMDA0MS00LjAwNDUtOS4wMDQxLTguMDI0OCAwLTkuNDAzOC0yLjY2NjMtMTkuOTIyIDAtMjkuODczIDAuNDU0MzMtMS42OTU2IDIuODM0Mi0yLjAzOTUgMy44MDI0LTMuNjQzMiAyLjAxNDgtMy4zMzc0IDAuNjY2MzUtNy43MTQyIDIuNDkyNC0xMS4yNTkgMS4yNzExLTIuNDY3MyAyLjY4NzEtNC41ODg0IDUuNTYzLTUuNzM0NSAzLjYwMTUtMS40MzU0IDcuNjkyOC0xLjI0NTQgMTEuMjQzIDAuMzEzMTYgNy4yNDY4IDMuMTgxNiAxMC45NzUgMTEuODk0IDE3LjM4OSAxNS41MjYgMy40NTg0IDEuOTU4NSA4LjgwNTItMC4yMjIyNCAxMi41IDEuMjQyMyAxLjQ5NTIgMC41OTI2NyAyLjg3NTQgMS4wNDc0IDMuMDI4MiAyLjMwNzQgMC41NjI2OSA0LjY0IDEuMDQ1NiA4LjczOTkgMCAxMi42NDItMC4zMTE5OSAxLjE2NDQtMC42OTQ4MSAwLjk2OTE5LTEuMDE4OSAyLjEzMDItMC44NjQ5NyAzLjA5ODQtMC43NTcwNCA0LjgzNzUtMC4yODQ5MyA3LjYwMTQgMC4xNjk4NyAwLjk5NDQ2IDEuMDA0NyAxLjkyODUgMS4wMDQ3IDIuOTM3NCAwIDcuMDE5NC00LjQ0NTEgMTguNzU2IDEuODE0NCAxOC43NTZoMTQuNDE3YzEuNjMyOSAwIDIuMTU2LTEuMjA3NSAyLjkxMjUtMi42NTQ2IDAuNzMxNjctMS4zOTk2IDAuOTMwMTctNC4yODQyIDAuMTg2MDQtNS42NzcyLTEuNTQ2Ni0yLjg5NTItNi4zODYtMC43Njg0NC03LjEzMzQtMy41NTc5LTIuODk0Mi0xMC44MDEtMC4wMzItMjQuMjU5LTAuMDMyLTM2LjMwOCAwLTUuNzUzMiA4LjE1MDctOC43MDM0IDkuNzgwOC0xNC4yMjEgMS4zODIxLTQuNjc3OSAyLjkwNzctOS44OTg0IDEuNzEtMTQuNTI0bC0yNC41LTI0LjVjLTEuMjExMS0wLjM2Mzc1LTIuNDM2Ny0wLjYzODQyLTMuNjczMi0wLjc5OTk1LTUuMjA5NC0wLjY4MDUzLTE0LjEyIDYuNTc2OS0xNC4xMiA2LjU3NjloLTU0LjUwNWMtMy4xNTI2IDAtNC45Njg5LTEuMjg4OC03LjIwNDktNC4yODI0LTEuNTgxNC0yLjExNzEtMy43NzA4LTYuMzc0Ny0zLjc0ODQtOC43MTI5IDAuMDI2MjEtMi43NDQ4IDIuMjIxMy01LjE2OTYgMy42MDctOC4yMTQ4IDAuNzk2MS0xLjc0OTUtMC4yMDQxMi01Ljk4MzEtMC4yMDQxMi01Ljk4MzF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0.10476190476190476,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="231,113,72,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC45NW1tIiBoZWlnaHQ9IjExOS44bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC45NSAxMTkuOCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQuMTUxIDkwLjgwMi0wLjI0MzkxIDAuMzE5ODh2MjguNjc4aDEzMy4xM3YtMjguNjlsLTAuMjM1MTMtMC4zMDc0N2gtMzkuMTc5YTI5LjE0MyAyOS4wOTEgMCAwIDEtMTkuNzYzIDE3LjYwMSAyOS4xNDYgMjkuNDczIDAgMCAxLTEuMjM5NyAwLjMwOTU0IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDQzIDAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjU5NzMgMC4yMzYxNiAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAwMiAwLjEwMjgzIDI5LjE0NiAyOS40NzMgMCAwIDEtMi41NDQgMC4xMjQ1NCAyOS4xNDYgMjkuNDczIDAgMCAxLTAuMDAyMDY3IDAgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0yLjU0MTQtMC4xMjQ1NCAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAyNzktMC4xMDI4MyAyOS4xNDYgMjkuNDczIDAgMCAxLTEuNTkzNy0wLjIzNjE2IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDc5LTAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjI0NTQtMC4zMTE2MSAyOS4xNDMgMjkuMDkxIDAgMCAxLTE5Ljc1Ni0xNy41OTloLTM5LjE3eiIvPjxwYXRoIGQ9Im01MC4wNTQgNDMuODI1LTM2LjE0NyA0Ny4yOTdoMzkuNTQxYy0xLjM2NDEtMy40MjY1LTIuMDkyNy03LjA4MDgtMi4wOTQyLTEwLjc2OSAyLjAxZS00IC0xNi4wOTggMTMuMDUtMjkuMTQ4IDI5LjE0OS0yOS4xNDggMTYuMDk4IDJlLTQgMjkuMTQ4IDEzLjA1IDI5LjE0OCAyOS4xNDgtMmUtMyAzLjY4ODEtMC43OTM3OSA3LjM0MjMtMi4xNTc5IDEwLjc2OWgzOS41NDFsM2UtNSAtMC4wMTQ5OS0zNi4xMDktNDcuMjgyeiIvPjxyZWN0IHg9IjUyLjIzMiIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxyZWN0IHg9IjkzLjAxNCIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxwYXRoIGQ9Im0wIDUxLjA1OSAzOS40NTgtNS4yNDgydi0xMi4xMzRoLTQuOTAzOHYtMTIuOTk4bDMzLjM4NC0wLjE0ODkzdi0yMC4wMzNzLTI0LjQ0NSAxLjYyMTYtMzUuNjE0IDYuMTM1NmMtOC42MzQxIDMuNDg5Ni0xNi43OTEgOC44NjU4LTIzLjA5NiAxNS43MTktMy44NTU0IDQuMTkwNy04LjQwMzUgMTQuODczLTguNDAzNSAxNC44NzN6Ii8+PHBhdGggZD0ibTE2MC45NSA1MS4wNTktMzkuNDU4LTUuMjQ4MnYtMTIuMTM0aDQuOTAzOHYtMTIuOTk4bC0zMy4zODQtMC4xNDg5M3YtMjAuMDMzczI0LjQ0NSAxLjYyMTYgMzUuNjE0IDYuMTM1NmM4LjYzNDEgMy40ODk2IDE2Ljc5MSA4Ljg2NTggMjMuMDk2IDE1LjcxOSAzLjg1NTQgNC4xOTA3IDguNDAzNiAxNC44NzMgOC40MDM2IDE0Ljg3M3oiLz48cGF0aCBkPSJtMzQuNTU0IDIwLjY3OWg5MS44NDR2LTE0Ljg1NnMtMjIuMTUtNC40MzU4LTMzLjM4NC01LjMyNjJjLTguMzMyNy0wLjY2MDU1LTE2Ljc0NC0wLjY2NTA1LTI1LjA3NyA1ZS02IC0xMS4zMDggMC45MDI1Ni0zMy42MDEgNS4zOTgyLTMzLjYwMSA1LjM5ODJsMC4yMTcyMyAxNC43ODQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNC4yOW1tIiBoZWlnaHQ9IjE1OC4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjQuMjkgMTU4LjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC44NjcgLTY5LjQxKSI+PHJlY3QgeD0iMTUyLjU3IiB5PSI5NC4yMjUiIHdpZHRoPSIxMS4yNDMiIGhlaWdodD0iMTMzLjE5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxjaXJjbGUgY3g9IjE1OC42NSIgY3k9Ijc5LjkxMSIgcj0iMTAuNTAxIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im0xNDYuMDQgOTMuNzY1djc2LjM0MnMtMjQuNzA4IDAuMjUwNTgtMzYuMTYyIDQuMjY3NWMtMTMuMjcxIDQuNjU0MS0yMi42MDkgMTcuNDU2LTM1LjgwOSAyMi4zMDgtNi4xMjYyIDIuMjUxOC0xMi45OTkgMS40NTE3LTE5LjM2OSAyLjg3NDItMy4zNDA0IDAuNzQ1OTYtOS44MzMgMi45NTY4LTkuODMzIDIuOTU2OHYtNzYuNTY2czI2LjE5Ni0xLjcyOTIgMzcuODgxLTcuMDYxN2M5LjAyMDMtNC4xMTYzIDE0LjIxNy0xNC40OTMgMjMuMjgtMTguNTE2IDEyLjM1NS01LjQ4NDMgNDAuMDExLTYuNjA0OCA0MC4wMTEtNi42MDQ4eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.0903" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OC4yN21tIiBoZWlnaHQ9IjE0Ni4wNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDguMjcgMTQ2LjA2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMi44MDQgLTc1LjU0OCkiPjxwYXRoIGQ9Im0zMi44MDQgNzUuNTQ4czM1LjAwOSAyLjEyNTkgNTAuOTU1IDE4LjY1NGMxOS4yMDUgMTkuOTA2IDIzLjE4IDU0LjM3NyAyMy4xOCA1NC4zNzdzLTMyLjk5MS0xLjY4MzEtNTMuNDA3LTIxLjcxNmMtMTkuMTEzLTE4Ljc1NS0yMC43MjctNTEuMzE0LTIwLjcyNy01MS4zMTR6Ii8+PHBhdGggZD0ibTE4MS4wNyA3NS41NDhzLTM1LjAwOSAyLjEyNTktNTAuOTU1IDE4LjY1NGMtMTkuMjA1IDE5LjkwNi0yMy4xOCA1NC4zNzctMjMuMTggNTQuMzc3czMyLjk5MS0xLjY4MzEgNTMuNDA3LTIxLjcxNmMxOS4xMTMtMTguNzU1IDIwLjcyNy01MS4zMTQgMjAuNzI3LTUxLjMxNHoiLz48cGF0aCBkPSJtMTgxLjA3IDIyMS42MXMtMzUuMDA5LTIuMTI1OS01MC45NTUtMTguNjU0Yy0xOS4yMDUtMTkuOTA2LTIzLjE4LTU0LjM3Ny0yMy4xOC01NC4zNzdzMzIuOTkxIDEuNjgzMSA1My40MDcgMjEuNzE2YzE5LjExMyAxOC43NTUgMjAuNzI3IDUxLjMxNCAyMC43MjcgNTEuMzE0eiIvPjxwYXRoIGQ9Im0zMi44MDQgMjIxLjYxczM1LjAwOS0yLjEyNTkgNTAuOTU1LTE4LjY1NGMxOS4yMDUtMTkuOTA2IDIzLjE4LTU0LjM3NyAyMy4xOC01NC4zNzdzLTMyLjk5MSAxLjY4MzEtNTMuNDA3IDIxLjcxNmMtMTkuMTEzIDE4Ljc1NS0yMC43MjcgNTEuMzE0LTIwLjcyNyA1MS4zMTR6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg5LjAwNG1tIiBoZWlnaHQ9IjE2MS4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4OS4wMDQgMTYxLjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxyZWN0IHg9IjE0LjY3NiIgeT0iNTguNzQ4IiB3aWR0aD0iMTYuMTY5IiBoZWlnaHQ9IjEwMi4yNiIgcnk9IjcuMzI5MiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cGF0aCBkPSJtMWUtNiAzNy45ODV2MjAuODMxYzAgNC45MTY3IDMuOTU4MiA4Ljg3NTQgOC44NzQ5IDguODc1NGgyNy43NzJjNC45MTY3IDAgOC44NzQ5LTMuOTU4NyA4Ljg3NDktOC44NzU0di0yMC44MzFoLTguNzg3MWMtMWUtNiA1LjM3ODEtNy4yN2UtNCA5LjcxLTAuMDAxNiA5LjcxaC01LjMyOTljLTMuODdlLTQgMC0wLjAwMTUtNC4zMzE5LTAuMDAxNS05LjcxaC01Ljk3NDNjLTFlLTYgNS4zNzgxLTcuMjdlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc0ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTYtOS43MWgtNS45NzQzYzAgNS4zNzgxLTcuMjVlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc1ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTUtOS43MXoiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iLTQuMTI2ZS03IiB5PSIuMDAyMDciIHdpZHRoPSI4Ljc4ODYiIGhlaWdodD0iNDcuODQyIiByeD0iMCIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMzYuNzMzIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjguNzg4NiIgaGVpZ2h0PSI0Ny44NDIiIHJ4PSIwIiByeT0iMCIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSIxNC4xMTkiIHk9IjIuNDU5ZS02IiB3aWR0aD0iNS45Nzc0IiBoZWlnaHQ9IjQ3LjY5NSIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMjUuNDI2IiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjUuOTc3NCIgaGVpZ2h0PSI0Ny42OTUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjcxLjQ2MSIgeT0iMi40NTllLTYiIHdpZHRoPSIxNy41NDMiIGhlaWdodD0iMTYxLjAxIiByeT0iNy40NDA1IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im03My43OTUgMGMtOC4zNzU0IDAtMTUuMTE4IDYuNjI3Ni0xNS4xMTggMTQuODZ2MjguMThoMzAuMzI3di0yOC4xOGMwLTguMjMyNS02Ljc0MzEtMTQuODYtMTUuMTE4LTE0Ljg2eiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSI1OC42NzciIHk9IjMyLjAyMiIgd2lkdGg9IjMwLjMyNyIgaGVpZ2h0PSI2NS45MzMiIHJ5PSI5LjA5NjkiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iNzMuNzExIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjE1LjI5MyIgaGVpZ2h0PSIyNC40MzUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.0956" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MG1tIiBoZWlnaHQ9IjE1Ni4ybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MCAxNTYuMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjUuOTIyIC03MC45OCkiPjxnPjxwYXRoIGQ9Im0xNTIgOTQuNzA1LTMzLjIgOTEuMzgzcy0yLjY1MTIgOS4yNjg1IDEuNjc5NSAxOS43OTNjNC4xMTk0IDEwLjAxMSAxNC43OCAyMS4zMDUgMzEuNTIgMjEuMzA1IDE1LjUyIDAgMjYuMjI3LTEwLjA5MiAzMC42MzUtMTkuMjkzIDUuMzQ1OS0xMS4xNTcgMi41NzYxLTIxLjgwNCAyLjU3NjEtMjEuODA0em02ZS0zIDMxLjU5MSAyMy4zNjcgNTkuNzkyaC00Ni43MzR6Ii8+PHBhdGggZD0ibTU5LjkyNSA5NC43MDQtMzMuMiA5MS4zODNzLTIuNjUxMiA5LjI2ODUgMS42Nzk1IDE5Ljc5M2M0LjExOTQgMTAuMDExIDE0Ljc4IDIxLjMwNSAzMS41MiAyMS4zMDUgMTUuNTIgMCAyNi4yMjctMTAuMDkyIDMwLjYzNS0xOS4yOTMgNS4zNDU5LTExLjE1NyAyLjU3NjEtMjEuODA0IDIuNTc2MS0yMS44MDR6bTAuMDA1NyAzMS41OTEgMjMuMzY3IDU5Ljc5MmgtNDYuNzM0eiIvPjxyZWN0IHg9Ijk2LjEwMyIgeT0iNzAuOTgiIHdpZHRoPSIxOS43MTQiIGhlaWdodD0iMjQuOTUzIiByeT0iMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjEuOTQ4IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjU2LjIzNCIgeT0iOTIuMzE0IiB3aWR0aD0iOTkuNDYzIiBoZWlnaHQ9IjEyLjU2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjAuNDM5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48cGF0aCBjbGFzcz0iVW5vcHRpbWljZWRUcmFuc2Zvcm1zIiBkPSJtMCAwIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OC4yN21tIiBoZWlnaHQ9IjE0Ni4wNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDguMjcgMTQ2LjA2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMi44MDQgLTc1LjU0OCkiPjxwYXRoIGQ9Im0zMi44MDQgNzUuNTQ4czM1LjAwOSAyLjEyNTkgNTAuOTU1IDE4LjY1NGMxOS4yMDUgMTkuOTA2IDIzLjE4IDU0LjM3NyAyMy4xOCA1NC4zNzdzLTMyLjk5MS0xLjY4MzEtNTMuNDA3LTIxLjcxNmMtMTkuMTEzLTE4Ljc1NS0yMC43MjctNTEuMzE0LTIwLjcyNy01MS4zMTR6Ii8+PHBhdGggZD0ibTE4MS4wNyA3NS41NDhzLTM1LjAwOSAyLjEyNTktNTAuOTU1IDE4LjY1NGMtMTkuMjA1IDE5LjkwNi0yMy4xOCA1NC4zNzctMjMuMTggNTQuMzc3czMyLjk5MS0xLjY4MzEgNTMuNDA3LTIxLjcxNmMxOS4xMTMtMTguNzU1IDIwLjcyNy01MS4zMTQgMjAuNzI3LTUxLjMxNHoiLz48cGF0aCBkPSJtMTgxLjA3IDIyMS42MXMtMzUuMDA5LTIuMTI1OS01MC45NTUtMTguNjU0Yy0xOS4yMDUtMTkuOTA2LTIzLjE4LTU0LjM3Ny0yMy4xOC01NC4zNzdzMzIuOTkxIDEuNjgzMSA1My40MDcgMjEuNzE2YzE5LjExMyAxOC43NTUgMjAuNzI3IDUxLjMxNCAyMC43MjcgNTEuMzE0eiIvPjxwYXRoIGQ9Im0zMi44MDQgMjIxLjYxczM1LjAwOS0yLjEyNTkgNTAuOTU1LTE4LjY1NGMxOS4yMDUtMTkuOTA2IDIzLjE4LTU0LjM3NyAyMy4xOC01NC4zNzdzLTMyLjk5MSAxLjY4MzEtNTMuNDA3IDIxLjcxNmMtMTkuMTEzIDE4Ljc1NS0yMC43MjcgNTEuMzE0LTIwLjcyNyA1MS4zMTR6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE1Ni4xOG1tIiBoZWlnaHQ9IjkwLjY4NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNTYuMTggOTAuNjg1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjE3LjQwMiIgY3k9IjE3LjQwMiIgcj0iMTQuMTg5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utb3BhY2l0eT0iLjk5MDE0IiBzdHJva2Utd2lkdGg9IjYuNDI1IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PGNpcmNsZSBjeD0iMTcuNDAyIiBjeT0iNzMuMjgzIiByPSIxNC4xODkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS1vcGFjaXR5PSIuOTkwMTQiIHN0cm9rZS13aWR0aD0iNi40MjUiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48Zz48cGF0aCBkPSJtMjYuMzA0IDMxLjY4NSA5LjE3OTUtMC40NDkxIDg5LjAyOSAzOS40M2gyOS4wNzFsLTExNi41OC00Ni42ODQtNS40MTE5LTYuNTgwNXoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjYuOSIvPjxwYXRoIGQ9Im0yNi4zMDQgNTkgOS4xNzk1IDAuNDQ5MSA4OS4wMjktMzkuNDNoMjkuMDcxbC0xMTYuNTggNDYuNjg0LTUuNDExOSA2LjU4MDV6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI2LjkiLz48cGF0aCBkPSJtNzUuNDE0IDQ1LjU2MS0xOC42ODUgOC43MTUydi0xNy40M3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ni4yNG1tIiBoZWlnaHQ9IjEzNi44Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDYuMjQgMTM2LjgyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zOC41MDYgLTc4LjkyOSkiPjxwYXRoIGQ9Im0xNjYuMDIgNzguOTI5cy04LjU0OTggMC43Nzc3OS0xMi4xNSAyLjg2MzljLTUuNzc0NyAzLjM0Ni05LjY3ODUgOS4yNzkzLTEzLjY3NyAxNC42MjMtMi4zNTQ0IDMuMTQ2My01LjU2MjYgOC45MTMyLTcuMzI1MSAxMi4xODJsMjEuNDc2IDIxLjQ3NmMwLjA3MzMtMC4wOTMgMC45MTUzLTAuOTQxOTMgMC4yMDgyNi0wLjI2ODcyIDEuMTM5MS0xLjU0OTYgMC4wMjUxLTUuMDkzNiAyLjg4NjgtNS4yNjE4IDUuNTY5LTAuMzI3MzYgMTMuMzYtMi4yMDkxIDE0LjIwMi0yLjMzOTkgMC44NDI4OC0wLjEzMDg1IDExLjU0NC0xLjYwMzYgMTIuNjYtNS43NjY3IDAuNjQ2MTgtMi40MTE2IDAuMzk5MzktMy40NTU0IDAuMzk5MzktNi41MzMyIDAtNC45Mjg2LTkuNjU3NC01LjEwNzctMTMuNjQ0LTguMjEwOS0zLjA3NDktMi4zOTMzLTUuMTAyLTUuMTA3Ny01LjkyNTctOC45MTYzLTEuMDAzMy00LjYzODkgMC44OTAzOS0xMy44NDcgMC44OTAzOS0xMy44NDd6Ii8+PHBhdGggZD0ibTQ4LjEwMSA5Mi44ODdzLTkuMjI0OCA5LjMzODYtOS41ODA4IDE1LjM2M2MtMC4zOTUzNSA2LjY5MTEgNy4yMjU4IDExLjUwNSA4LjU1NjYgMTguMTk3IDAuNDE1MjcgMi4wODg0IDAuNTc0MzIgMy45NTYtMC4yNTA2MyA1LjkxOS0xLjA1NTIgMi41MTEtMy40ODE5IDMuNTc3NC00LjMzNDEgNi4xMDItMC44NzAwNyAyLjU3NzYtMS45MDQxIDUuNTMyOC0wLjU4NTQ5IDguNjE3NiAwLjUwNjM3IDEuMTg0NiAxLjE2NjQgMi41ODMgMS41MDY0IDMuODI1NiAxLjM5ODIgNS4xMTEgMS4zMjAxIDEwLjIyMSAwLjAzNDExIDE1LjYxNy0wLjc0MTggMy4xMTI2LTMuMzc1OCA1LjcwMjgtNC4zODExIDguNzQwNi0wLjY2NDQ0IDIuMDA3Ny0wLjYyMTQ1IDQuMjUzNi0wLjI2ODIgNi4zMzg2IDEuMjg5OCA3LjYxMjggNi41OTEgMTQuMDYgOC41NDczIDIxLjUyOSAwLjg5MzY1IDMuNDEyMS0yLjA3NDggMTAuNDg2IDEuNDE3NSAxMC40ODYgNC41MzE5IDAgNC4yMDI3LTAuMDEzNCA4LjEzNDQtMC4wMTM0IDIuODA4MiAwLTAuMTEwMDMtNS42NDUtMC42NjE5OC04LjM5ODQtMC41NzQ2OC0yLjg2NjktMS4zNjY2LTUuODA3Ni0xLjg1MDMtOC42OTItMC40ODI5OS0yLjg4MDMtMC45NDc3Mi01LjI5MTggMC4yMjQ0OC04LjIzNzggMS4yMTAyLTMuMDQxNSAyLjc4NzgtMi41NzAxIDMuNTAyMS0xLjM2OTIgMi4zNDk3IDMuOTUwMyAyLjczNDcgOS42MzkgMy41ODc0IDEzLjY4MiAwLjE2NzAzIDAuNzkxOTIgMi43MTQ2IDYuNTgwNSAyLjcxNDYgNi41ODA1czAuMDE3MTYgNy44MTA0IDIuNzgwNyA3LjgxMDRoMTIuMTAyYzEuNjY4OCAwIDIuOTk0NS0yLjUwNiAyLjc4MzgtNC4xNjE1LTAuNTA3NjUtMy45ODgyLTkuMDA0MS00LjAwNDUtOS4wMDQxLTguMDI0OCAwLTkuNDAzOC0yLjY2NjMtMTkuOTIyIDAtMjkuODczIDAuNDU0MzMtMS42OTU2IDIuODM0Mi0yLjAzOTUgMy44MDI0LTMuNjQzMiAyLjAxNDgtMy4zMzc0IDAuNjY2MzUtNy43MTQyIDIuNDkyNC0xMS4yNTkgMS4yNzExLTIuNDY3MyAyLjY4NzEtNC41ODg0IDUuNTYzLTUuNzM0NSAzLjYwMTUtMS40MzU0IDcuNjkyOC0xLjI0NTQgMTEuMjQzIDAuMzEzMTYgNy4yNDY4IDMuMTgxNiAxMC45NzUgMTEuODk0IDE3LjM4OSAxNS41MjYgMy40NTg0IDEuOTU4NSA4LjgwNTItMC4yMjIyNCAxMi41IDEuMjQyMyAxLjQ5NTIgMC41OTI2NyAyLjg3NTQgMS4wNDc0IDMuMDI4MiAyLjMwNzQgMC41NjI2OSA0LjY0IDEuMDQ1NiA4LjczOTkgMCAxMi42NDItMC4zMTE5OSAxLjE2NDQtMC42OTQ4MSAwLjk2OTE5LTEuMDE4OSAyLjEzMDItMC44NjQ5NyAzLjA5ODQtMC43NTcwNCA0LjgzNzUtMC4yODQ5MyA3LjYwMTQgMC4xNjk4NyAwLjk5NDQ2IDEuMDA0NyAxLjkyODUgMS4wMDQ3IDIuOTM3NCAwIDcuMDE5NC00LjQ0NTEgMTguNzU2IDEuODE0NCAxOC43NTZoMTQuNDE3YzEuNjMyOSAwIDIuMTU2LTEuMjA3NSAyLjkxMjUtMi42NTQ2IDAuNzMxNjctMS4zOTk2IDAuOTMwMTctNC4yODQyIDAuMTg2MDQtNS42NzcyLTEuNTQ2Ni0yLjg5NTItNi4zODYtMC43Njg0NC03LjEzMzQtMy41NTc5LTIuODk0Mi0xMC44MDEtMC4wMzItMjQuMjU5LTAuMDMyLTM2LjMwOCAwLTUuNzUzMiA4LjE1MDctOC43MDM0IDkuNzgwOC0xNC4yMjEgMS4zODIxLTQuNjc3OSAyLjkwNzctOS44OTg0IDEuNzEtMTQuNTI0bC0yNC41LTI0LjVjLTEuMjExMS0wLjM2Mzc1LTIuNDM2Ny0wLjYzODQyLTMuNjczMi0wLjc5OTk1LTUuMjA5NC0wLjY4MDUzLTE0LjEyIDYuNTc2OS0xNC4xMiA2LjU3NjloLTU0LjUwNWMtMy4xNTI2IDAtNC45Njg5LTEuMjg4OC03LjIwNDktNC4yODI0LTEuNTgxNC0yLjExNzEtMy43NzA4LTYuMzc0Ny0zLjc0ODQtOC43MTI5IDAuMDI2MjEtMi43NDQ4IDIuMjIxMy01LjE2OTYgMy42MDctOC4yMTQ4IDAuNzk2MS0xLjc0OTUtMC4yMDQxMi01Ljk4MzEtMC4yMDQxMi01Ljk4MzF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0.10476190476190476,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC45NW1tIiBoZWlnaHQ9IjExOS44bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC45NSAxMTkuOCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQuMTUxIDkwLjgwMi0wLjI0MzkxIDAuMzE5ODh2MjguNjc4aDEzMy4xM3YtMjguNjlsLTAuMjM1MTMtMC4zMDc0N2gtMzkuMTc5YTI5LjE0MyAyOS4wOTEgMCAwIDEtMTkuNzYzIDE3LjYwMSAyOS4xNDYgMjkuNDczIDAgMCAxLTEuMjM5NyAwLjMwOTU0IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDQzIDAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjU5NzMgMC4yMzYxNiAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAwMiAwLjEwMjgzIDI5LjE0NiAyOS40NzMgMCAwIDEtMi41NDQgMC4xMjQ1NCAyOS4xNDYgMjkuNDczIDAgMCAxLTAuMDAyMDY3IDAgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0yLjU0MTQtMC4xMjQ1NCAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAyNzktMC4xMDI4MyAyOS4xNDYgMjkuNDczIDAgMCAxLTEuNTkzNy0wLjIzNjE2IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDc5LTAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjI0NTQtMC4zMTE2MSAyOS4xNDMgMjkuMDkxIDAgMCAxLTE5Ljc1Ni0xNy41OTloLTM5LjE3eiIvPjxwYXRoIGQ9Im01MC4wNTQgNDMuODI1LTM2LjE0NyA0Ny4yOTdoMzkuNTQxYy0xLjM2NDEtMy40MjY1LTIuMDkyNy03LjA4MDgtMi4wOTQyLTEwLjc2OSAyLjAxZS00IC0xNi4wOTggMTMuMDUtMjkuMTQ4IDI5LjE0OS0yOS4xNDggMTYuMDk4IDJlLTQgMjkuMTQ4IDEzLjA1IDI5LjE0OCAyOS4xNDgtMmUtMyAzLjY4ODEtMC43OTM3OSA3LjM0MjMtMi4xNTc5IDEwLjc2OWgzOS41NDFsM2UtNSAtMC4wMTQ5OS0zNi4xMDktNDcuMjgyeiIvPjxyZWN0IHg9IjUyLjIzMiIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxyZWN0IHg9IjkzLjAxNCIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxwYXRoIGQ9Im0wIDUxLjA1OSAzOS40NTgtNS4yNDgydi0xMi4xMzRoLTQuOTAzOHYtMTIuOTk4bDMzLjM4NC0wLjE0ODkzdi0yMC4wMzNzLTI0LjQ0NSAxLjYyMTYtMzUuNjE0IDYuMTM1NmMtOC42MzQxIDMuNDg5Ni0xNi43OTEgOC44NjU4LTIzLjA5NiAxNS43MTktMy44NTU0IDQuMTkwNy04LjQwMzUgMTQuODczLTguNDAzNSAxNC44NzN6Ii8+PHBhdGggZD0ibTE2MC45NSA1MS4wNTktMzkuNDU4LTUuMjQ4MnYtMTIuMTM0aDQuOTAzOHYtMTIuOTk4bC0zMy4zODQtMC4xNDg5M3YtMjAuMDMzczI0LjQ0NSAxLjYyMTYgMzUuNjE0IDYuMTM1NmM4LjYzNDEgMy40ODk2IDE2Ljc5MSA4Ljg2NTggMjMuMDk2IDE1LjcxOSAzLjg1NTQgNC4xOTA3IDguNDAzNiAxNC44NzMgOC40MDM2IDE0Ljg3M3oiLz48cGF0aCBkPSJtMzQuNTU0IDIwLjY3OWg5MS44NDR2LTE0Ljg1NnMtMjIuMTUtNC40MzU4LTMzLjM4NC01LjMyNjJjLTguMzMyNy0wLjY2MDU1LTE2Ljc0NC0wLjY2NTA1LTI1LjA3NyA1ZS02IC0xMS4zMDggMC45MDI1Ni0zMy42MDEgNS4zOTgyLTMzLjYwMSA1LjM5ODJsMC4yMTcyMyAxNC43ODQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNC4yOW1tIiBoZWlnaHQ9IjE1OC4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjQuMjkgMTU4LjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC44NjcgLTY5LjQxKSI+PHJlY3QgeD0iMTUyLjU3IiB5PSI5NC4yMjUiIHdpZHRoPSIxMS4yNDMiIGhlaWdodD0iMTMzLjE5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxjaXJjbGUgY3g9IjE1OC42NSIgY3k9Ijc5LjkxMSIgcj0iMTAuNTAxIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im0xNDYuMDQgOTMuNzY1djc2LjM0MnMtMjQuNzA4IDAuMjUwNTgtMzYuMTYyIDQuMjY3NWMtMTMuMjcxIDQuNjU0MS0yMi42MDkgMTcuNDU2LTM1LjgwOSAyMi4zMDgtNi4xMjYyIDIuMjUxOC0xMi45OTkgMS40NTE3LTE5LjM2OSAyLjg3NDItMy4zNDA0IDAuNzQ1OTYtOS44MzMgMi45NTY4LTkuODMzIDIuOTU2OHYtNzYuNTY2czI2LjE5Ni0xLjcyOTIgMzcuODgxLTcuMDYxN2M5LjAyMDMtNC4xMTYzIDE0LjIxNy0xNC40OTMgMjMuMjgtMTguNTE2IDEyLjM1NS01LjQ4NDMgNDAuMDExLTYuNjA0OCA0MC4wMTEtNi42MDQ4eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.0903" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OC4yN21tIiBoZWlnaHQ9IjE0Ni4wNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDguMjcgMTQ2LjA2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMi44MDQgLTc1LjU0OCkiPjxwYXRoIGQ9Im0zMi44MDQgNzUuNTQ4czM1LjAwOSAyLjEyNTkgNTAuOTU1IDE4LjY1NGMxOS4yMDUgMTkuOTA2IDIzLjE4IDU0LjM3NyAyMy4xOCA1NC4zNzdzLTMyLjk5MS0xLjY4MzEtNTMuNDA3LTIxLjcxNmMtMTkuMTEzLTE4Ljc1NS0yMC43MjctNTEuMzE0LTIwLjcyNy01MS4zMTR6Ii8+PHBhdGggZD0ibTE4MS4wNyA3NS41NDhzLTM1LjAwOSAyLjEyNTktNTAuOTU1IDE4LjY1NGMtMTkuMjA1IDE5LjkwNi0yMy4xOCA1NC4zNzctMjMuMTggNTQuMzc3czMyLjk5MS0xLjY4MzEgNTMuNDA3LTIxLjcxNmMxOS4xMTMtMTguNzU1IDIwLjcyNy01MS4zMTQgMjAuNzI3LTUxLjMxNHoiLz48cGF0aCBkPSJtMTgxLjA3IDIyMS42MXMtMzUuMDA5LTIuMTI1OS01MC45NTUtMTguNjU0Yy0xOS4yMDUtMTkuOTA2LTIzLjE4LTU0LjM3Ny0yMy4xOC01NC4zNzdzMzIuOTkxIDEuNjgzMSA1My40MDcgMjEuNzE2YzE5LjExMyAxOC43NTUgMjAuNzI3IDUxLjMxNCAyMC43MjcgNTEuMzE0eiIvPjxwYXRoIGQ9Im0zMi44MDQgMjIxLjYxczM1LjAwOS0yLjEyNTkgNTAuOTU1LTE4LjY1NGMxOS4yMDUtMTkuOTA2IDIzLjE4LTU0LjM3NyAyMy4xOC01NC4zNzdzLTMyLjk5MSAxLjY4MzEtNTMuNDA3IDIxLjcxNmMtMTkuMTEzIDE4Ljc1NS0yMC43MjcgNTEuMzE0LTIwLjcyNyA1MS4zMTR6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="36" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg5LjAwNG1tIiBoZWlnaHQ9IjE2MS4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4OS4wMDQgMTYxLjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxyZWN0IHg9IjE0LjY3NiIgeT0iNTguNzQ4IiB3aWR0aD0iMTYuMTY5IiBoZWlnaHQ9IjEwMi4yNiIgcnk9IjcuMzI5MiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cGF0aCBkPSJtMWUtNiAzNy45ODV2MjAuODMxYzAgNC45MTY3IDMuOTU4MiA4Ljg3NTQgOC44NzQ5IDguODc1NGgyNy43NzJjNC45MTY3IDAgOC44NzQ5LTMuOTU4NyA4Ljg3NDktOC44NzU0di0yMC44MzFoLTguNzg3MWMtMWUtNiA1LjM3ODEtNy4yN2UtNCA5LjcxLTAuMDAxNiA5LjcxaC01LjMyOTljLTMuODdlLTQgMC0wLjAwMTUtNC4zMzE5LTAuMDAxNS05LjcxaC01Ljk3NDNjLTFlLTYgNS4zNzgxLTcuMjdlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc0ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTYtOS43MWgtNS45NzQzYzAgNS4zNzgxLTcuMjVlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc1ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTUtOS43MXoiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iLTQuMTI2ZS03IiB5PSIuMDAyMDciIHdpZHRoPSI4Ljc4ODYiIGhlaWdodD0iNDcuODQyIiByeD0iMCIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMzYuNzMzIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjguNzg4NiIgaGVpZ2h0PSI0Ny44NDIiIHJ4PSIwIiByeT0iMCIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSIxNC4xMTkiIHk9IjIuNDU5ZS02IiB3aWR0aD0iNS45Nzc0IiBoZWlnaHQ9IjQ3LjY5NSIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMjUuNDI2IiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjUuOTc3NCIgaGVpZ2h0PSI0Ny42OTUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjcxLjQ2MSIgeT0iMi40NTllLTYiIHdpZHRoPSIxNy41NDMiIGhlaWdodD0iMTYxLjAxIiByeT0iNy40NDA1IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im03My43OTUgMGMtOC4zNzU0IDAtMTUuMTE4IDYuNjI3Ni0xNS4xMTggMTQuODZ2MjguMThoMzAuMzI3di0yOC4xOGMwLTguMjMyNS02Ljc0MzEtMTQuODYtMTUuMTE4LTE0Ljg2eiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSI1OC42NzciIHk9IjMyLjAyMiIgd2lkdGg9IjMwLjMyNyIgaGVpZ2h0PSI2NS45MzMiIHJ5PSI5LjA5NjkiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iNzMuNzExIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjE1LjI5MyIgaGVpZ2h0PSIyNC40MzUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.0956" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="37" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MG1tIiBoZWlnaHQ9IjE1Ni4ybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MCAxNTYuMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjUuOTIyIC03MC45OCkiPjxnPjxwYXRoIGQ9Im0xNTIgOTQuNzA1LTMzLjIgOTEuMzgzcy0yLjY1MTIgOS4yNjg1IDEuNjc5NSAxOS43OTNjNC4xMTk0IDEwLjAxMSAxNC43OCAyMS4zMDUgMzEuNTIgMjEuMzA1IDE1LjUyIDAgMjYuMjI3LTEwLjA5MiAzMC42MzUtMTkuMjkzIDUuMzQ1OS0xMS4xNTcgMi41NzYxLTIxLjgwNCAyLjU3NjEtMjEuODA0em02ZS0zIDMxLjU5MSAyMy4zNjcgNTkuNzkyaC00Ni43MzR6Ii8+PHBhdGggZD0ibTU5LjkyNSA5NC43MDQtMzMuMiA5MS4zODNzLTIuNjUxMiA5LjI2ODUgMS42Nzk1IDE5Ljc5M2M0LjExOTQgMTAuMDExIDE0Ljc4IDIxLjMwNSAzMS41MiAyMS4zMDUgMTUuNTIgMCAyNi4yMjctMTAuMDkyIDMwLjYzNS0xOS4yOTMgNS4zNDU5LTExLjE1NyAyLjU3NjEtMjEuODA0IDIuNTc2MS0yMS44MDR6bTAuMDA1NyAzMS41OTEgMjMuMzY3IDU5Ljc5MmgtNDYuNzM0eiIvPjxyZWN0IHg9Ijk2LjEwMyIgeT0iNzAuOTgiIHdpZHRoPSIxOS43MTQiIGhlaWdodD0iMjQuOTUzIiByeT0iMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjEuOTQ4IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjU2LjIzNCIgeT0iOTIuMzE0IiB3aWR0aD0iOTkuNDYzIiBoZWlnaHQ9IjEyLjU2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjAuNDM5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48cGF0aCBjbGFzcz0iVW5vcHRpbWljZWRUcmFuc2Zvcm1zIiBkPSJtMCAwIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="38" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE1Ni4xOG1tIiBoZWlnaHQ9IjkwLjY4NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNTYuMTggOTAuNjg1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjE3LjQwMiIgY3k9IjE3LjQwMiIgcj0iMTQuMTg5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utb3BhY2l0eT0iLjk5MDE0IiBzdHJva2Utd2lkdGg9IjYuNDI1IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PGNpcmNsZSBjeD0iMTcuNDAyIiBjeT0iNzMuMjgzIiByPSIxNC4xODkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS1vcGFjaXR5PSIuOTkwMTQiIHN0cm9rZS13aWR0aD0iNi40MjUiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48Zz48cGF0aCBkPSJtMjYuMzA0IDMxLjY4NSA5LjE3OTUtMC40NDkxIDg5LjAyOSAzOS40M2gyOS4wNzFsLTExNi41OC00Ni42ODQtNS40MTE5LTYuNTgwNXoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjYuOSIvPjxwYXRoIGQ9Im0yNi4zMDQgNTkgOS4xNzk1IDAuNDQ5MSA4OS4wMjktMzkuNDNoMjkuMDcxbC0xMTYuNTggNDYuNjg0LTUuNDExOSA2LjU4MDV6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI2LjkiLz48cGF0aCBkPSJtNzUuNDE0IDQ1LjU2MS0xOC42ODUgOC43MTUydi0xNy40M3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="39" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ni4yNG1tIiBoZWlnaHQ9IjEzNi44Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDYuMjQgMTM2LjgyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zOC41MDYgLTc4LjkyOSkiPjxwYXRoIGQ9Im0xNjYuMDIgNzguOTI5cy04LjU0OTggMC43Nzc3OS0xMi4xNSAyLjg2MzljLTUuNzc0NyAzLjM0Ni05LjY3ODUgOS4yNzkzLTEzLjY3NyAxNC42MjMtMi4zNTQ0IDMuMTQ2My01LjU2MjYgOC45MTMyLTcuMzI1MSAxMi4xODJsMjEuNDc2IDIxLjQ3NmMwLjA3MzMtMC4wOTMgMC45MTUzLTAuOTQxOTMgMC4yMDgyNi0wLjI2ODcyIDEuMTM5MS0xLjU0OTYgMC4wMjUxLTUuMDkzNiAyLjg4NjgtNS4yNjE4IDUuNTY5LTAuMzI3MzYgMTMuMzYtMi4yMDkxIDE0LjIwMi0yLjMzOTkgMC44NDI4OC0wLjEzMDg1IDExLjU0NC0xLjYwMzYgMTIuNjYtNS43NjY3IDAuNjQ2MTgtMi40MTE2IDAuMzk5MzktMy40NTU0IDAuMzk5MzktNi41MzMyIDAtNC45Mjg2LTkuNjU3NC01LjEwNzctMTMuNjQ0LTguMjEwOS0zLjA3NDktMi4zOTMzLTUuMTAyLTUuMTA3Ny01LjkyNTctOC45MTYzLTEuMDAzMy00LjYzODkgMC44OTAzOS0xMy44NDcgMC44OTAzOS0xMy44NDd6Ii8+PHBhdGggZD0ibTQ4LjEwMSA5Mi44ODdzLTkuMjI0OCA5LjMzODYtOS41ODA4IDE1LjM2M2MtMC4zOTUzNSA2LjY5MTEgNy4yMjU4IDExLjUwNSA4LjU1NjYgMTguMTk3IDAuNDE1MjcgMi4wODg0IDAuNTc0MzIgMy45NTYtMC4yNTA2MyA1LjkxOS0xLjA1NTIgMi41MTEtMy40ODE5IDMuNTc3NC00LjMzNDEgNi4xMDItMC44NzAwNyAyLjU3NzYtMS45MDQxIDUuNTMyOC0wLjU4NTQ5IDguNjE3NiAwLjUwNjM3IDEuMTg0NiAxLjE2NjQgMi41ODMgMS41MDY0IDMuODI1NiAxLjM5ODIgNS4xMTEgMS4zMjAxIDEwLjIyMSAwLjAzNDExIDE1LjYxNy0wLjc0MTggMy4xMTI2LTMuMzc1OCA1LjcwMjgtNC4zODExIDguNzQwNi0wLjY2NDQ0IDIuMDA3Ny0wLjYyMTQ1IDQuMjUzNi0wLjI2ODIgNi4zMzg2IDEuMjg5OCA3LjYxMjggNi41OTEgMTQuMDYgOC41NDczIDIxLjUyOSAwLjg5MzY1IDMuNDEyMS0yLjA3NDggMTAuNDg2IDEuNDE3NSAxMC40ODYgNC41MzE5IDAgNC4yMDI3LTAuMDEzNCA4LjEzNDQtMC4wMTM0IDIuODA4MiAwLTAuMTEwMDMtNS42NDUtMC42NjE5OC04LjM5ODQtMC41NzQ2OC0yLjg2NjktMS4zNjY2LTUuODA3Ni0xLjg1MDMtOC42OTItMC40ODI5OS0yLjg4MDMtMC45NDc3Mi01LjI5MTggMC4yMjQ0OC04LjIzNzggMS4yMTAyLTMuMDQxNSAyLjc4NzgtMi41NzAxIDMuNTAyMS0xLjM2OTIgMi4zNDk3IDMuOTUwMyAyLjczNDcgOS42MzkgMy41ODc0IDEzLjY4MiAwLjE2NzAzIDAuNzkxOTIgMi43MTQ2IDYuNTgwNSAyLjcxNDYgNi41ODA1czAuMDE3MTYgNy44MTA0IDIuNzgwNyA3LjgxMDRoMTIuMTAyYzEuNjY4OCAwIDIuOTk0NS0yLjUwNiAyLjc4MzgtNC4xNjE1LTAuNTA3NjUtMy45ODgyLTkuMDA0MS00LjAwNDUtOS4wMDQxLTguMDI0OCAwLTkuNDAzOC0yLjY2NjMtMTkuOTIyIDAtMjkuODczIDAuNDU0MzMtMS42OTU2IDIuODM0Mi0yLjAzOTUgMy44MDI0LTMuNjQzMiAyLjAxNDgtMy4zMzc0IDAuNjY2MzUtNy43MTQyIDIuNDkyNC0xMS4yNTkgMS4yNzExLTIuNDY3MyAyLjY4NzEtNC41ODg0IDUuNTYzLTUuNzM0NSAzLjYwMTUtMS40MzU0IDcuNjkyOC0xLjI0NTQgMTEuMjQzIDAuMzEzMTYgNy4yNDY4IDMuMTgxNiAxMC45NzUgMTEuODk0IDE3LjM4OSAxNS41MjYgMy40NTg0IDEuOTU4NSA4LjgwNTItMC4yMjIyNCAxMi41IDEuMjQyMyAxLjQ5NTIgMC41OTI2NyAyLjg3NTQgMS4wNDc0IDMuMDI4MiAyLjMwNzQgMC41NjI2OSA0LjY0IDEuMDQ1NiA4LjczOTkgMCAxMi42NDItMC4zMTE5OSAxLjE2NDQtMC42OTQ4MSAwLjk2OTE5LTEuMDE4OSAyLjEzMDItMC44NjQ5NyAzLjA5ODQtMC43NTcwNCA0LjgzNzUtMC4yODQ5MyA3LjYwMTQgMC4xNjk4NyAwLjk5NDQ2IDEuMDA0NyAxLjkyODUgMS4wMDQ3IDIuOTM3NCAwIDcuMDE5NC00LjQ0NTEgMTguNzU2IDEuODE0NCAxOC43NTZoMTQuNDE3YzEuNjMyOSAwIDIuMTU2LTEuMjA3NSAyLjkxMjUtMi42NTQ2IDAuNzMxNjctMS4zOTk2IDAuOTMwMTctNC4yODQyIDAuMTg2MDQtNS42NzcyLTEuNTQ2Ni0yLjg5NTItNi4zODYtMC43Njg0NC03LjEzMzQtMy41NTc5LTIuODk0Mi0xMC44MDEtMC4wMzItMjQuMjU5LTAuMDMyLTM2LjMwOCAwLTUuNzUzMiA4LjE1MDctOC43MDM0IDkuNzgwOC0xNC4yMjEgMS4zODIxLTQuNjc3OSAyLjkwNzctOS44OTg0IDEuNzEtMTQuNTI0bC0yNC41LTI0LjVjLTEuMjExMS0wLjM2Mzc1LTIuNDM2Ny0wLjYzODQyLTMuNjczMi0wLjc5OTk1LTUuMjA5NC0wLjY4MDUzLTE0LjEyIDYuNTc2OS0xNC4xMiA2LjU3NjloLTU0LjUwNWMtMy4xNTI2IDAtNC45Njg5LTEuMjg4OC03LjIwNDktNC4yODI0LTEuNTgxNC0yLjExNzEtMy43NzA4LTYuMzc0Ny0zLjc0ODQtOC43MTI5IDAuMDI2MjEtMi43NDQ4IDIuMjIxMy01LjE2OTYgMy42MDctOC4yMTQ4IDAuNzk2MS0xLjc0OTUtMC4yMDQxMi01Ljk4MzEtMC4yMDQxMi01Ljk4MzF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0.10476190476190478,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg5LjAwNG1tIiBoZWlnaHQ9IjE2MS4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4OS4wMDQgMTYxLjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxyZWN0IHg9IjE0LjY3NiIgeT0iNTguNzQ4IiB3aWR0aD0iMTYuMTY5IiBoZWlnaHQ9IjEwMi4yNiIgcnk9IjcuMzI5MiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cGF0aCBkPSJtMWUtNiAzNy45ODV2MjAuODMxYzAgNC45MTY3IDMuOTU4MiA4Ljg3NTQgOC44NzQ5IDguODc1NGgyNy43NzJjNC45MTY3IDAgOC44NzQ5LTMuOTU4NyA4Ljg3NDktOC44NzU0di0yMC44MzFoLTguNzg3MWMtMWUtNiA1LjM3ODEtNy4yN2UtNCA5LjcxLTAuMDAxNiA5LjcxaC01LjMyOTljLTMuODdlLTQgMC0wLjAwMTUtNC4zMzE5LTAuMDAxNS05LjcxaC01Ljk3NDNjLTFlLTYgNS4zNzgxLTcuMjdlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc0ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTYtOS43MWgtNS45NzQzYzAgNS4zNzgxLTcuMjVlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc1ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTUtOS43MXoiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iLTQuMTI2ZS03IiB5PSIuMDAyMDciIHdpZHRoPSI4Ljc4ODYiIGhlaWdodD0iNDcuODQyIiByeD0iMCIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMzYuNzMzIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjguNzg4NiIgaGVpZ2h0PSI0Ny44NDIiIHJ4PSIwIiByeT0iMCIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSIxNC4xMTkiIHk9IjIuNDU5ZS02IiB3aWR0aD0iNS45Nzc0IiBoZWlnaHQ9IjQ3LjY5NSIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMjUuNDI2IiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjUuOTc3NCIgaGVpZ2h0PSI0Ny42OTUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjcxLjQ2MSIgeT0iMi40NTllLTYiIHdpZHRoPSIxNy41NDMiIGhlaWdodD0iMTYxLjAxIiByeT0iNy40NDA1IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im03My43OTUgMGMtOC4zNzU0IDAtMTUuMTE4IDYuNjI3Ni0xNS4xMTggMTQuODZ2MjguMThoMzAuMzI3di0yOC4xOGMwLTguMjMyNS02Ljc0MzEtMTQuODYtMTUuMTE4LTE0Ljg2eiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSI1OC42NzciIHk9IjMyLjAyMiIgd2lkdGg9IjMwLjMyNyIgaGVpZ2h0PSI2NS45MzMiIHJ5PSI5LjA5NjkiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iNzMuNzExIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjE1LjI5MyIgaGVpZ2h0PSIyNC40MzUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.0956" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="40" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="41" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC45NW1tIiBoZWlnaHQ9IjExOS44bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC45NSAxMTkuOCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQuMTUxIDkwLjgwMi0wLjI0MzkxIDAuMzE5ODh2MjguNjc4aDEzMy4xM3YtMjguNjlsLTAuMjM1MTMtMC4zMDc0N2gtMzkuMTc5YTI5LjE0MyAyOS4wOTEgMCAwIDEtMTkuNzYzIDE3LjYwMSAyOS4xNDYgMjkuNDczIDAgMCAxLTEuMjM5NyAwLjMwOTU0IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDQzIDAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjU5NzMgMC4yMzYxNiAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAwMiAwLjEwMjgzIDI5LjE0NiAyOS40NzMgMCAwIDEtMi41NDQgMC4xMjQ1NCAyOS4xNDYgMjkuNDczIDAgMCAxLTAuMDAyMDY3IDAgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0yLjU0MTQtMC4xMjQ1NCAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAyNzktMC4xMDI4MyAyOS4xNDYgMjkuNDczIDAgMCAxLTEuNTkzNy0wLjIzNjE2IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDc5LTAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjI0NTQtMC4zMTE2MSAyOS4xNDMgMjkuMDkxIDAgMCAxLTE5Ljc1Ni0xNy41OTloLTM5LjE3eiIvPjxwYXRoIGQ9Im01MC4wNTQgNDMuODI1LTM2LjE0NyA0Ny4yOTdoMzkuNTQxYy0xLjM2NDEtMy40MjY1LTIuMDkyNy03LjA4MDgtMi4wOTQyLTEwLjc2OSAyLjAxZS00IC0xNi4wOTggMTMuMDUtMjkuMTQ4IDI5LjE0OS0yOS4xNDggMTYuMDk4IDJlLTQgMjkuMTQ4IDEzLjA1IDI5LjE0OCAyOS4xNDgtMmUtMyAzLjY4ODEtMC43OTM3OSA3LjM0MjMtMi4xNTc5IDEwLjc2OWgzOS41NDFsM2UtNSAtMC4wMTQ5OS0zNi4xMDktNDcuMjgyeiIvPjxyZWN0IHg9IjUyLjIzMiIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxyZWN0IHg9IjkzLjAxNCIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxwYXRoIGQ9Im0wIDUxLjA1OSAzOS40NTgtNS4yNDgydi0xMi4xMzRoLTQuOTAzOHYtMTIuOTk4bDMzLjM4NC0wLjE0ODkzdi0yMC4wMzNzLTI0LjQ0NSAxLjYyMTYtMzUuNjE0IDYuMTM1NmMtOC42MzQxIDMuNDg5Ni0xNi43OTEgOC44NjU4LTIzLjA5NiAxNS43MTktMy44NTU0IDQuMTkwNy04LjQwMzUgMTQuODczLTguNDAzNSAxNC44NzN6Ii8+PHBhdGggZD0ibTE2MC45NSA1MS4wNTktMzkuNDU4LTUuMjQ4MnYtMTIuMTM0aDQuOTAzOHYtMTIuOTk4bC0zMy4zODQtMC4xNDg5M3YtMjAuMDMzczI0LjQ0NSAxLjYyMTYgMzUuNjE0IDYuMTM1NmM4LjYzNDEgMy40ODk2IDE2Ljc5MSA4Ljg2NTggMjMuMDk2IDE1LjcxOSAzLjg1NTQgNC4xOTA3IDguNDAzNiAxNC44NzMgOC40MDM2IDE0Ljg3M3oiLz48cGF0aCBkPSJtMzQuNTU0IDIwLjY3OWg5MS44NDR2LTE0Ljg1NnMtMjIuMTUtNC40MzU4LTMzLjM4NC01LjMyNjJjLTguMzMyNy0wLjY2MDU1LTE2Ljc0NC0wLjY2NTA1LTI1LjA3NyA1ZS02IC0xMS4zMDggMC45MDI1Ni0zMy42MDEgNS4zOTgyLTMzLjYwMSA1LjM5ODJsMC4yMTcyMyAxNC43ODQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="42" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNC4yOW1tIiBoZWlnaHQ9IjE1OC4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjQuMjkgMTU4LjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC44NjcgLTY5LjQxKSI+PHJlY3QgeD0iMTUyLjU3IiB5PSI5NC4yMjUiIHdpZHRoPSIxMS4yNDMiIGhlaWdodD0iMTMzLjE5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxjaXJjbGUgY3g9IjE1OC42NSIgY3k9Ijc5LjkxMSIgcj0iMTAuNTAxIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im0xNDYuMDQgOTMuNzY1djc2LjM0MnMtMjQuNzA4IDAuMjUwNTgtMzYuMTYyIDQuMjY3NWMtMTMuMjcxIDQuNjU0MS0yMi42MDkgMTcuNDU2LTM1LjgwOSAyMi4zMDgtNi4xMjYyIDIuMjUxOC0xMi45OTkgMS40NTE3LTE5LjM2OSAyLjg3NDItMy4zNDA0IDAuNzQ1OTYtOS44MzMgMi45NTY4LTkuODMzIDIuOTU2OHYtNzYuNTY2czI2LjE5Ni0xLjcyOTIgMzcuODgxLTcuMDYxN2M5LjAyMDMtNC4xMTYzIDE0LjIxNy0xNC40OTMgMjMuMjgtMTguNTE2IDEyLjM1NS01LjQ4NDMgNDAuMDExLTYuNjA0OCA0MC4wMTEtNi42MDQ4eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.0903" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="43" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OC4yN21tIiBoZWlnaHQ9IjE0Ni4wNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDguMjcgMTQ2LjA2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMi44MDQgLTc1LjU0OCkiPjxwYXRoIGQ9Im0zMi44MDQgNzUuNTQ4czM1LjAwOSAyLjEyNTkgNTAuOTU1IDE4LjY1NGMxOS4yMDUgMTkuOTA2IDIzLjE4IDU0LjM3NyAyMy4xOCA1NC4zNzdzLTMyLjk5MS0xLjY4MzEtNTMuNDA3LTIxLjcxNmMtMTkuMTEzLTE4Ljc1NS0yMC43MjctNTEuMzE0LTIwLjcyNy01MS4zMTR6Ii8+PHBhdGggZD0ibTE4MS4wNyA3NS41NDhzLTM1LjAwOSAyLjEyNTktNTAuOTU1IDE4LjY1NGMtMTkuMjA1IDE5LjkwNi0yMy4xOCA1NC4zNzctMjMuMTggNTQuMzc3czMyLjk5MS0xLjY4MzEgNTMuNDA3LTIxLjcxNmMxOS4xMTMtMTguNzU1IDIwLjcyNy01MS4zMTQgMjAuNzI3LTUxLjMxNHoiLz48cGF0aCBkPSJtMTgxLjA3IDIyMS42MXMtMzUuMDA5LTIuMTI1OS01MC45NTUtMTguNjU0Yy0xOS4yMDUtMTkuOTA2LTIzLjE4LTU0LjM3Ny0yMy4xOC01NC4zNzdzMzIuOTkxIDEuNjgzMSA1My40MDcgMjEuNzE2YzE5LjExMyAxOC43NTUgMjAuNzI3IDUxLjMxNCAyMC43MjcgNTEuMzE0eiIvPjxwYXRoIGQ9Im0zMi44MDQgMjIxLjYxczM1LjAwOS0yLjEyNTkgNTAuOTU1LTE4LjY1NGMxOS4yMDUtMTkuOTA2IDIzLjE4LTU0LjM3NyAyMy4xOC01NC4zNzdzLTMyLjk5MSAxLjY4MzEtNTMuNDA3IDIxLjcxNmMtMTkuMTEzIDE4Ljc1NS0yMC43MjcgNTEuMzE0LTIwLjcyNyA1MS4zMTR6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="44" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg5LjAwNG1tIiBoZWlnaHQ9IjE2MS4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4OS4wMDQgMTYxLjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxyZWN0IHg9IjE0LjY3NiIgeT0iNTguNzQ4IiB3aWR0aD0iMTYuMTY5IiBoZWlnaHQ9IjEwMi4yNiIgcnk9IjcuMzI5MiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cGF0aCBkPSJtMWUtNiAzNy45ODV2MjAuODMxYzAgNC45MTY3IDMuOTU4MiA4Ljg3NTQgOC44NzQ5IDguODc1NGgyNy43NzJjNC45MTY3IDAgOC44NzQ5LTMuOTU4NyA4Ljg3NDktOC44NzU0di0yMC44MzFoLTguNzg3MWMtMWUtNiA1LjM3ODEtNy4yN2UtNCA5LjcxLTAuMDAxNiA5LjcxaC01LjMyOTljLTMuODdlLTQgMC0wLjAwMTUtNC4zMzE5LTAuMDAxNS05LjcxaC01Ljk3NDNjLTFlLTYgNS4zNzgxLTcuMjdlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc0ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTYtOS43MWgtNS45NzQzYzAgNS4zNzgxLTcuMjVlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc1ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTUtOS43MXoiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iLTQuMTI2ZS03IiB5PSIuMDAyMDciIHdpZHRoPSI4Ljc4ODYiIGhlaWdodD0iNDcuODQyIiByeD0iMCIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMzYuNzMzIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjguNzg4NiIgaGVpZ2h0PSI0Ny44NDIiIHJ4PSIwIiByeT0iMCIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSIxNC4xMTkiIHk9IjIuNDU5ZS02IiB3aWR0aD0iNS45Nzc0IiBoZWlnaHQ9IjQ3LjY5NSIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMjUuNDI2IiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjUuOTc3NCIgaGVpZ2h0PSI0Ny42OTUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjcxLjQ2MSIgeT0iMi40NTllLTYiIHdpZHRoPSIxNy41NDMiIGhlaWdodD0iMTYxLjAxIiByeT0iNy40NDA1IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im03My43OTUgMGMtOC4zNzU0IDAtMTUuMTE4IDYuNjI3Ni0xNS4xMTggMTQuODZ2MjguMThoMzAuMzI3di0yOC4xOGMwLTguMjMyNS02Ljc0MzEtMTQuODYtMTUuMTE4LTE0Ljg2eiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSI1OC42NzciIHk9IjMyLjAyMiIgd2lkdGg9IjMwLjMyNyIgaGVpZ2h0PSI2NS45MzMiIHJ5PSI5LjA5NjkiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iNzMuNzExIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjE1LjI5MyIgaGVpZ2h0PSIyNC40MzUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.0956" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="45" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MG1tIiBoZWlnaHQ9IjE1Ni4ybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MCAxNTYuMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjUuOTIyIC03MC45OCkiPjxnPjxwYXRoIGQ9Im0xNTIgOTQuNzA1LTMzLjIgOTEuMzgzcy0yLjY1MTIgOS4yNjg1IDEuNjc5NSAxOS43OTNjNC4xMTk0IDEwLjAxMSAxNC43OCAyMS4zMDUgMzEuNTIgMjEuMzA1IDE1LjUyIDAgMjYuMjI3LTEwLjA5MiAzMC42MzUtMTkuMjkzIDUuMzQ1OS0xMS4xNTcgMi41NzYxLTIxLjgwNCAyLjU3NjEtMjEuODA0em02ZS0zIDMxLjU5MSAyMy4zNjcgNTkuNzkyaC00Ni43MzR6Ii8+PHBhdGggZD0ibTU5LjkyNSA5NC43MDQtMzMuMiA5MS4zODNzLTIuNjUxMiA5LjI2ODUgMS42Nzk1IDE5Ljc5M2M0LjExOTQgMTAuMDExIDE0Ljc4IDIxLjMwNSAzMS41MiAyMS4zMDUgMTUuNTIgMCAyNi4yMjctMTAuMDkyIDMwLjYzNS0xOS4yOTMgNS4zNDU5LTExLjE1NyAyLjU3NjEtMjEuODA0IDIuNTc2MS0yMS44MDR6bTAuMDA1NyAzMS41OTEgMjMuMzY3IDU5Ljc5MmgtNDYuNzM0eiIvPjxyZWN0IHg9Ijk2LjEwMyIgeT0iNzAuOTgiIHdpZHRoPSIxOS43MTQiIGhlaWdodD0iMjQuOTUzIiByeT0iMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjEuOTQ4IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjU2LjIzNCIgeT0iOTIuMzE0IiB3aWR0aD0iOTkuNDYzIiBoZWlnaHQ9IjEyLjU2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjAuNDM5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48cGF0aCBjbGFzcz0iVW5vcHRpbWljZWRUcmFuc2Zvcm1zIiBkPSJtMCAwIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="46" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE1Ni4xOG1tIiBoZWlnaHQ9IjkwLjY4NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNTYuMTggOTAuNjg1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjE3LjQwMiIgY3k9IjE3LjQwMiIgcj0iMTQuMTg5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utb3BhY2l0eT0iLjk5MDE0IiBzdHJva2Utd2lkdGg9IjYuNDI1IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PGNpcmNsZSBjeD0iMTcuNDAyIiBjeT0iNzMuMjgzIiByPSIxNC4xODkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS1vcGFjaXR5PSIuOTkwMTQiIHN0cm9rZS13aWR0aD0iNi40MjUiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48Zz48cGF0aCBkPSJtMjYuMzA0IDMxLjY4NSA5LjE3OTUtMC40NDkxIDg5LjAyOSAzOS40M2gyOS4wNzFsLTExNi41OC00Ni42ODQtNS40MTE5LTYuNTgwNXoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjYuOSIvPjxwYXRoIGQ9Im0yNi4zMDQgNTkgOS4xNzk1IDAuNDQ5MSA4OS4wMjktMzkuNDNoMjkuMDcxbC0xMTYuNTggNDYuNjg0LTUuNDExOSA2LjU4MDV6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI2LjkiLz48cGF0aCBkPSJtNzUuNDE0IDQ1LjU2MS0xOC42ODUgOC43MTUydi0xNy40M3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="47" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ni4yNG1tIiBoZWlnaHQ9IjEzNi44Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDYuMjQgMTM2LjgyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zOC41MDYgLTc4LjkyOSkiPjxwYXRoIGQ9Im0xNjYuMDIgNzguOTI5cy04LjU0OTggMC43Nzc3OS0xMi4xNSAyLjg2MzljLTUuNzc0NyAzLjM0Ni05LjY3ODUgOS4yNzkzLTEzLjY3NyAxNC42MjMtMi4zNTQ0IDMuMTQ2My01LjU2MjYgOC45MTMyLTcuMzI1MSAxMi4xODJsMjEuNDc2IDIxLjQ3NmMwLjA3MzMtMC4wOTMgMC45MTUzLTAuOTQxOTMgMC4yMDgyNi0wLjI2ODcyIDEuMTM5MS0xLjU0OTYgMC4wMjUxLTUuMDkzNiAyLjg4NjgtNS4yNjE4IDUuNTY5LTAuMzI3MzYgMTMuMzYtMi4yMDkxIDE0LjIwMi0yLjMzOTkgMC44NDI4OC0wLjEzMDg1IDExLjU0NC0xLjYwMzYgMTIuNjYtNS43NjY3IDAuNjQ2MTgtMi40MTE2IDAuMzk5MzktMy40NTU0IDAuMzk5MzktNi41MzMyIDAtNC45Mjg2LTkuNjU3NC01LjEwNzctMTMuNjQ0LTguMjEwOS0zLjA3NDktMi4zOTMzLTUuMTAyLTUuMTA3Ny01LjkyNTctOC45MTYzLTEuMDAzMy00LjYzODkgMC44OTAzOS0xMy44NDcgMC44OTAzOS0xMy44NDd6Ii8+PHBhdGggZD0ibTQ4LjEwMSA5Mi44ODdzLTkuMjI0OCA5LjMzODYtOS41ODA4IDE1LjM2M2MtMC4zOTUzNSA2LjY5MTEgNy4yMjU4IDExLjUwNSA4LjU1NjYgMTguMTk3IDAuNDE1MjcgMi4wODg0IDAuNTc0MzIgMy45NTYtMC4yNTA2MyA1LjkxOS0xLjA1NTIgMi41MTEtMy40ODE5IDMuNTc3NC00LjMzNDEgNi4xMDItMC44NzAwNyAyLjU3NzYtMS45MDQxIDUuNTMyOC0wLjU4NTQ5IDguNjE3NiAwLjUwNjM3IDEuMTg0NiAxLjE2NjQgMi41ODMgMS41MDY0IDMuODI1NiAxLjM5ODIgNS4xMTEgMS4zMjAxIDEwLjIyMSAwLjAzNDExIDE1LjYxNy0wLjc0MTggMy4xMTI2LTMuMzc1OCA1LjcwMjgtNC4zODExIDguNzQwNi0wLjY2NDQ0IDIuMDA3Ny0wLjYyMTQ1IDQuMjUzNi0wLjI2ODIgNi4zMzg2IDEuMjg5OCA3LjYxMjggNi41OTEgMTQuMDYgOC41NDczIDIxLjUyOSAwLjg5MzY1IDMuNDEyMS0yLjA3NDggMTAuNDg2IDEuNDE3NSAxMC40ODYgNC41MzE5IDAgNC4yMDI3LTAuMDEzNCA4LjEzNDQtMC4wMTM0IDIuODA4MiAwLTAuMTEwMDMtNS42NDUtMC42NjE5OC04LjM5ODQtMC41NzQ2OC0yLjg2NjktMS4zNjY2LTUuODA3Ni0xLjg1MDMtOC42OTItMC40ODI5OS0yLjg4MDMtMC45NDc3Mi01LjI5MTggMC4yMjQ0OC04LjIzNzggMS4yMTAyLTMuMDQxNSAyLjc4NzgtMi41NzAxIDMuNTAyMS0xLjM2OTIgMi4zNDk3IDMuOTUwMyAyLjczNDcgOS42MzkgMy41ODc0IDEzLjY4MiAwLjE2NzAzIDAuNzkxOTIgMi43MTQ2IDYuNTgwNSAyLjcxNDYgNi41ODA1czAuMDE3MTYgNy44MTA0IDIuNzgwNyA3LjgxMDRoMTIuMTAyYzEuNjY4OCAwIDIuOTk0NS0yLjUwNiAyLjc4MzgtNC4xNjE1LTAuNTA3NjUtMy45ODgyLTkuMDA0MS00LjAwNDUtOS4wMDQxLTguMDI0OCAwLTkuNDAzOC0yLjY2NjMtMTkuOTIyIDAtMjkuODczIDAuNDU0MzMtMS42OTU2IDIuODM0Mi0yLjAzOTUgMy44MDI0LTMuNjQzMiAyLjAxNDgtMy4zMzc0IDAuNjY2MzUtNy43MTQyIDIuNDkyNC0xMS4yNTkgMS4yNzExLTIuNDY3MyAyLjY4NzEtNC41ODg0IDUuNTYzLTUuNzM0NSAzLjYwMTUtMS40MzU0IDcuNjkyOC0xLjI0NTQgMTEuMjQzIDAuMzEzMTYgNy4yNDY4IDMuMTgxNiAxMC45NzUgMTEuODk0IDE3LjM4OSAxNS41MjYgMy40NTg0IDEuOTU4NSA4LjgwNTItMC4yMjIyNCAxMi41IDEuMjQyMyAxLjQ5NTIgMC41OTI2NyAyLjg3NTQgMS4wNDc0IDMuMDI4MiAyLjMwNzQgMC41NjI2OSA0LjY0IDEuMDQ1NiA4LjczOTkgMCAxMi42NDItMC4zMTE5OSAxLjE2NDQtMC42OTQ4MSAwLjk2OTE5LTEuMDE4OSAyLjEzMDItMC44NjQ5NyAzLjA5ODQtMC43NTcwNCA0LjgzNzUtMC4yODQ5MyA3LjYwMTQgMC4xNjk4NyAwLjk5NDQ2IDEuMDA0NyAxLjkyODUgMS4wMDQ3IDIuOTM3NCAwIDcuMDE5NC00LjQ0NTEgMTguNzU2IDEuODE0NCAxOC43NTZoMTQuNDE3YzEuNjMyOSAwIDIuMTU2LTEuMjA3NSAyLjkxMjUtMi42NTQ2IDAuNzMxNjctMS4zOTk2IDAuOTMwMTctNC4yODQyIDAuMTg2MDQtNS42NzcyLTEuNTQ2Ni0yLjg5NTItNi4zODYtMC43Njg0NC03LjEzMzQtMy41NTc5LTIuODk0Mi0xMC44MDEtMC4wMzItMjQuMjU5LTAuMDMyLTM2LjMwOCAwLTUuNzUzMiA4LjE1MDctOC43MDM0IDkuNzgwOC0xNC4yMjEgMS4zODIxLTQuNjc3OSAyLjkwNzctOS44OTg0IDEuNzEtMTQuNTI0bC0yNC41LTI0LjVjLTEuMjExMS0wLjM2Mzc1LTIuNDM2Ny0wLjYzODQyLTMuNjczMi0wLjc5OTk1LTUuMjA5NC0wLjY4MDUzLTE0LjEyIDYuNTc2OS0xNC4xMiA2LjU3NjloLTU0LjUwNWMtMy4xNTI2IDAtNC45Njg5LTEuMjg4OC03LjIwNDktNC4yODI0LTEuNTgxNC0yLjExNzEtMy43NzA4LTYuMzc0Ny0zLjc0ODQtOC43MTI5IDAuMDI2MjEtMi43NDQ4IDIuMjIxMy01LjE2OTYgMy42MDctOC4yMTQ4IDAuNzk2MS0xLjc0OTUtMC4yMDQxMi01Ljk4MzEtMC4yMDQxMi01Ljk4MzF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0.10476190476190476,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="48" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="49" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC45NW1tIiBoZWlnaHQ9IjExOS44bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC45NSAxMTkuOCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQuMTUxIDkwLjgwMi0wLjI0MzkxIDAuMzE5ODh2MjguNjc4aDEzMy4xM3YtMjguNjlsLTAuMjM1MTMtMC4zMDc0N2gtMzkuMTc5YTI5LjE0MyAyOS4wOTEgMCAwIDEtMTkuNzYzIDE3LjYwMSAyOS4xNDYgMjkuNDczIDAgMCAxLTEuMjM5NyAwLjMwOTU0IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDQzIDAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjU5NzMgMC4yMzYxNiAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAwMiAwLjEwMjgzIDI5LjE0NiAyOS40NzMgMCAwIDEtMi41NDQgMC4xMjQ1NCAyOS4xNDYgMjkuNDczIDAgMCAxLTAuMDAyMDY3IDAgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0yLjU0MTQtMC4xMjQ1NCAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAyNzktMC4xMDI4MyAyOS4xNDYgMjkuNDczIDAgMCAxLTEuNTkzNy0wLjIzNjE2IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDc5LTAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjI0NTQtMC4zMTE2MSAyOS4xNDMgMjkuMDkxIDAgMCAxLTE5Ljc1Ni0xNy41OTloLTM5LjE3eiIvPjxwYXRoIGQ9Im01MC4wNTQgNDMuODI1LTM2LjE0NyA0Ny4yOTdoMzkuNTQxYy0xLjM2NDEtMy40MjY1LTIuMDkyNy03LjA4MDgtMi4wOTQyLTEwLjc2OSAyLjAxZS00IC0xNi4wOTggMTMuMDUtMjkuMTQ4IDI5LjE0OS0yOS4xNDggMTYuMDk4IDJlLTQgMjkuMTQ4IDEzLjA1IDI5LjE0OCAyOS4xNDgtMmUtMyAzLjY4ODEtMC43OTM3OSA3LjM0MjMtMi4xNTc5IDEwLjc2OWgzOS41NDFsM2UtNSAtMC4wMTQ5OS0zNi4xMDktNDcuMjgyeiIvPjxyZWN0IHg9IjUyLjIzMiIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxyZWN0IHg9IjkzLjAxNCIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxwYXRoIGQ9Im0wIDUxLjA1OSAzOS40NTgtNS4yNDgydi0xMi4xMzRoLTQuOTAzOHYtMTIuOTk4bDMzLjM4NC0wLjE0ODkzdi0yMC4wMzNzLTI0LjQ0NSAxLjYyMTYtMzUuNjE0IDYuMTM1NmMtOC42MzQxIDMuNDg5Ni0xNi43OTEgOC44NjU4LTIzLjA5NiAxNS43MTktMy44NTU0IDQuMTkwNy04LjQwMzUgMTQuODczLTguNDAzNSAxNC44NzN6Ii8+PHBhdGggZD0ibTE2MC45NSA1MS4wNTktMzkuNDU4LTUuMjQ4MnYtMTIuMTM0aDQuOTAzOHYtMTIuOTk4bC0zMy4zODQtMC4xNDg5M3YtMjAuMDMzczI0LjQ0NSAxLjYyMTYgMzUuNjE0IDYuMTM1NmM4LjYzNDEgMy40ODk2IDE2Ljc5MSA4Ljg2NTggMjMuMDk2IDE1LjcxOSAzLjg1NTQgNC4xOTA3IDguNDAzNiAxNC44NzMgOC40MDM2IDE0Ljg3M3oiLz48cGF0aCBkPSJtMzQuNTU0IDIwLjY3OWg5MS44NDR2LTE0Ljg1NnMtMjIuMTUtNC40MzU4LTMzLjM4NC01LjMyNjJjLTguMzMyNy0wLjY2MDU1LTE2Ljc0NC0wLjY2NTA1LTI1LjA3NyA1ZS02IC0xMS4zMDggMC45MDI1Ni0zMy42MDEgNS4zOTgyLTMzLjYwMSA1LjM5ODJsMC4yMTcyMyAxNC43ODQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MG1tIiBoZWlnaHQ9IjE1Ni4ybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MCAxNTYuMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjUuOTIyIC03MC45OCkiPjxnPjxwYXRoIGQ9Im0xNTIgOTQuNzA1LTMzLjIgOTEuMzgzcy0yLjY1MTIgOS4yNjg1IDEuNjc5NSAxOS43OTNjNC4xMTk0IDEwLjAxMSAxNC43OCAyMS4zMDUgMzEuNTIgMjEuMzA1IDE1LjUyIDAgMjYuMjI3LTEwLjA5MiAzMC42MzUtMTkuMjkzIDUuMzQ1OS0xMS4xNTcgMi41NzYxLTIxLjgwNCAyLjU3NjEtMjEuODA0em02ZS0zIDMxLjU5MSAyMy4zNjcgNTkuNzkyaC00Ni43MzR6Ii8+PHBhdGggZD0ibTU5LjkyNSA5NC43MDQtMzMuMiA5MS4zODNzLTIuNjUxMiA5LjI2ODUgMS42Nzk1IDE5Ljc5M2M0LjExOTQgMTAuMDExIDE0Ljc4IDIxLjMwNSAzMS41MiAyMS4zMDUgMTUuNTIgMCAyNi4yMjctMTAuMDkyIDMwLjYzNS0xOS4yOTMgNS4zNDU5LTExLjE1NyAyLjU3NjEtMjEuODA0IDIuNTc2MS0yMS44MDR6bTAuMDA1NyAzMS41OTEgMjMuMzY3IDU5Ljc5MmgtNDYuNzM0eiIvPjxyZWN0IHg9Ijk2LjEwMyIgeT0iNzAuOTgiIHdpZHRoPSIxOS43MTQiIGhlaWdodD0iMjQuOTUzIiByeT0iMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjEuOTQ4IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjU2LjIzNCIgeT0iOTIuMzE0IiB3aWR0aD0iOTkuNDYzIiBoZWlnaHQ9IjEyLjU2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjAuNDM5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48cGF0aCBjbGFzcz0iVW5vcHRpbWljZWRUcmFuc2Zvcm1zIiBkPSJtMCAwIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="50" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNC4yOW1tIiBoZWlnaHQ9IjE1OC4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjQuMjkgMTU4LjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC44NjcgLTY5LjQxKSI+PHJlY3QgeD0iMTUyLjU3IiB5PSI5NC4yMjUiIHdpZHRoPSIxMS4yNDMiIGhlaWdodD0iMTMzLjE5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxjaXJjbGUgY3g9IjE1OC42NSIgY3k9Ijc5LjkxMSIgcj0iMTAuNTAxIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im0xNDYuMDQgOTMuNzY1djc2LjM0MnMtMjQuNzA4IDAuMjUwNTgtMzYuMTYyIDQuMjY3NWMtMTMuMjcxIDQuNjU0MS0yMi42MDkgMTcuNDU2LTM1LjgwOSAyMi4zMDgtNi4xMjYyIDIuMjUxOC0xMi45OTkgMS40NTE3LTE5LjM2OSAyLjg3NDItMy4zNDA0IDAuNzQ1OTYtOS44MzMgMi45NTY4LTkuODMzIDIuOTU2OHYtNzYuNTY2czI2LjE5Ni0xLjcyOTIgMzcuODgxLTcuMDYxN2M5LjAyMDMtNC4xMTYzIDE0LjIxNy0xNC40OTMgMjMuMjgtMTguNTE2IDEyLjM1NS01LjQ4NDMgNDAuMDExLTYuNjA0OCA0MC4wMTEtNi42MDQ4eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28508" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="51" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OC4yN21tIiBoZWlnaHQ9IjE0Ni4wNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDguMjcgMTQ2LjA2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMi44MDQgLTc1LjU0OCkiPjxwYXRoIGQ9Im0zMi44MDQgNzUuNTQ4czM1LjAwOSAyLjEyNTkgNTAuOTU1IDE4LjY1NGMxOS4yMDUgMTkuOTA2IDIzLjE4IDU0LjM3NyAyMy4xOCA1NC4zNzdzLTMyLjk5MS0xLjY4MzEtNTMuNDA3LTIxLjcxNmMtMTkuMTEzLTE4Ljc1NS0yMC43MjctNTEuMzE0LTIwLjcyNy01MS4zMTR6Ii8+PHBhdGggZD0ibTE4MS4wNyA3NS41NDhzLTM1LjAwOSAyLjEyNTktNTAuOTU1IDE4LjY1NGMtMTkuMjA1IDE5LjkwNi0yMy4xOCA1NC4zNzctMjMuMTggNTQuMzc3czMyLjk5MS0xLjY4MzEgNTMuNDA3LTIxLjcxNmMxOS4xMTMtMTguNzU1IDIwLjcyNy01MS4zMTQgMjAuNzI3LTUxLjMxNHoiLz48cGF0aCBkPSJtMTgxLjA3IDIyMS42MXMtMzUuMDA5LTIuMTI1OS01MC45NTUtMTguNjU0Yy0xOS4yMDUtMTkuOTA2LTIzLjE4LTU0LjM3Ny0yMy4xOC01NC4zNzdzMzIuOTkxIDEuNjgzMSA1My40MDcgMjEuNzE2YzE5LjExMyAxOC43NTUgMjAuNzI3IDUxLjMxNCAyMC43MjcgNTEuMzE0eiIvPjxwYXRoIGQ9Im0zMi44MDQgMjIxLjYxczM1LjAwOS0yLjEyNTkgNTAuOTU1LTE4LjY1NGMxOS4yMDUtMTkuOTA2IDIzLjE4LTU0LjM3NyAyMy4xOC01NC4zNzdzLTMyLjk5MSAxLjY4MzEtNTMuNDA3IDIxLjcxNmMtMTkuMTEzIDE4Ljc1NS0yMC43MjcgNTEuMzE0LTIwLjcyNyA1MS4zMTR6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="52" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg5LjAwNG1tIiBoZWlnaHQ9IjE2MS4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4OS4wMDQgMTYxLjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxyZWN0IHg9IjE0LjY3NiIgeT0iNTguNzQ4IiB3aWR0aD0iMTYuMTY5IiBoZWlnaHQ9IjEwMi4yNiIgcnk9IjcuMzI5MiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cGF0aCBkPSJtMWUtNiAzNy45ODV2MjAuODMxYzAgNC45MTY3IDMuOTU4MiA4Ljg3NTQgOC44NzQ5IDguODc1NGgyNy43NzJjNC45MTY3IDAgOC44NzQ5LTMuOTU4NyA4Ljg3NDktOC44NzU0di0yMC44MzFoLTguNzg3MWMtMWUtNiA1LjM3ODEtNy4yN2UtNCA5LjcxLTAuMDAxNiA5LjcxaC01LjMyOTljLTMuODdlLTQgMC0wLjAwMTUtNC4zMzE5LTAuMDAxNS05LjcxaC01Ljk3NDNjLTFlLTYgNS4zNzgxLTcuMjdlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc0ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTYtOS43MWgtNS45NzQzYzAgNS4zNzgxLTcuMjVlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc1ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTUtOS43MXoiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iLTQuMTI2ZS03IiB5PSIuMDAyMDciIHdpZHRoPSI4Ljc4ODYiIGhlaWdodD0iNDcuODQyIiByeD0iMCIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMzYuNzMzIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjguNzg4NiIgaGVpZ2h0PSI0Ny44NDIiIHJ4PSIwIiByeT0iMCIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSIxNC4xMTkiIHk9IjIuNDU5ZS02IiB3aWR0aD0iNS45Nzc0IiBoZWlnaHQ9IjQ3LjY5NSIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMjUuNDI2IiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjUuOTc3NCIgaGVpZ2h0PSI0Ny42OTUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjcxLjQ2MSIgeT0iMi40NTllLTYiIHdpZHRoPSIxNy41NDMiIGhlaWdodD0iMTYxLjAxIiByeT0iNy40NDA1IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im03My43OTUgMGMtOC4zNzU0IDAtMTUuMTE4IDYuNjI3Ni0xNS4xMTggMTQuODZ2MjguMThoMzAuMzI3di0yOC4xOGMwLTguMjMyNS02Ljc0MzEtMTQuODYtMTUuMTE4LTE0Ljg2eiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSI1OC42NzciIHk9IjMyLjAyMiIgd2lkdGg9IjMwLjMyNyIgaGVpZ2h0PSI2NS45MzMiIHJ5PSI5LjA5NjkiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iNzMuNzExIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjE1LjI5MyIgaGVpZ2h0PSIyNC40MzUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.0956" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="53" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MG1tIiBoZWlnaHQ9IjE1Ni4ybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MCAxNTYuMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjUuOTIyIC03MC45OCkiPjxnPjxwYXRoIGQ9Im0xNTIgOTQuNzA1LTMzLjIgOTEuMzgzcy0yLjY1MTIgOS4yNjg1IDEuNjc5NSAxOS43OTNjNC4xMTk0IDEwLjAxMSAxNC43OCAyMS4zMDUgMzEuNTIgMjEuMzA1IDE1LjUyIDAgMjYuMjI3LTEwLjA5MiAzMC42MzUtMTkuMjkzIDUuMzQ1OS0xMS4xNTcgMi41NzYxLTIxLjgwNCAyLjU3NjEtMjEuODA0em02ZS0zIDMxLjU5MSAyMy4zNjcgNTkuNzkyaC00Ni43MzR6Ii8+PHBhdGggZD0ibTU5LjkyNSA5NC43MDQtMzMuMiA5MS4zODNzLTIuNjUxMiA5LjI2ODUgMS42Nzk1IDE5Ljc5M2M0LjExOTQgMTAuMDExIDE0Ljc4IDIxLjMwNSAzMS41MiAyMS4zMDUgMTUuNTIgMCAyNi4yMjctMTAuMDkyIDMwLjYzNS0xOS4yOTMgNS4zNDU5LTExLjE1NyAyLjU3NjEtMjEuODA0IDIuNTc2MS0yMS44MDR6bTAuMDA1NyAzMS41OTEgMjMuMzY3IDU5Ljc5MmgtNDYuNzM0eiIvPjxyZWN0IHg9Ijk2LjEwMyIgeT0iNzAuOTgiIHdpZHRoPSIxOS43MTQiIGhlaWdodD0iMjQuOTUzIiByeT0iMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjEuOTQ4IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjU2LjIzNCIgeT0iOTIuMzE0IiB3aWR0aD0iOTkuNDYzIiBoZWlnaHQ9IjEyLjU2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjAuNDM5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48cGF0aCBjbGFzcz0iVW5vcHRpbWljZWRUcmFuc2Zvcm1zIiBkPSJtMCAwIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="54" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE1Ni4xOG1tIiBoZWlnaHQ9IjkwLjY4NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNTYuMTggOTAuNjg1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjE3LjQwMiIgY3k9IjE3LjQwMiIgcj0iMTQuMTg5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utb3BhY2l0eT0iLjk5MDE0IiBzdHJva2Utd2lkdGg9IjYuNDI1IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PGNpcmNsZSBjeD0iMTcuNDAyIiBjeT0iNzMuMjgzIiByPSIxNC4xODkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS1vcGFjaXR5PSIuOTkwMTQiIHN0cm9rZS13aWR0aD0iNi40MjUiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48Zz48cGF0aCBkPSJtMjYuMzA0IDMxLjY4NSA5LjE3OTUtMC40NDkxIDg5LjAyOSAzOS40M2gyOS4wNzFsLTExNi41OC00Ni42ODQtNS40MTE5LTYuNTgwNXoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjYuOSIvPjxwYXRoIGQ9Im0yNi4zMDQgNTkgOS4xNzk1IDAuNDQ5MSA4OS4wMjktMzkuNDNoMjkuMDcxbC0xMTYuNTggNDYuNjg0LTUuNDExOSA2LjU4MDV6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI2LjkiLz48cGF0aCBkPSJtNzUuNDE0IDQ1LjU2MS0xOC42ODUgOC43MTUydi0xNy40M3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="55" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ni4yNG1tIiBoZWlnaHQ9IjEzNi44Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDYuMjQgMTM2LjgyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zOC41MDYgLTc4LjkyOSkiPjxwYXRoIGQ9Im0xNjYuMDIgNzguOTI5cy04LjU0OTggMC43Nzc3OS0xMi4xNSAyLjg2MzljLTUuNzc0NyAzLjM0Ni05LjY3ODUgOS4yNzkzLTEzLjY3NyAxNC42MjMtMi4zNTQ0IDMuMTQ2My01LjU2MjYgOC45MTMyLTcuMzI1MSAxMi4xODJsMjEuNDc2IDIxLjQ3NmMwLjA3MzMtMC4wOTMgMC45MTUzLTAuOTQxOTMgMC4yMDgyNi0wLjI2ODcyIDEuMTM5MS0xLjU0OTYgMC4wMjUxLTUuMDkzNiAyLjg4NjgtNS4yNjE4IDUuNTY5LTAuMzI3MzYgMTMuMzYtMi4yMDkxIDE0LjIwMi0yLjMzOTkgMC44NDI4OC0wLjEzMDg1IDExLjU0NC0xLjYwMzYgMTIuNjYtNS43NjY3IDAuNjQ2MTgtMi40MTE2IDAuMzk5MzktMy40NTU0IDAuMzk5MzktNi41MzMyIDAtNC45Mjg2LTkuNjU3NC01LjEwNzctMTMuNjQ0LTguMjEwOS0zLjA3NDktMi4zOTMzLTUuMTAyLTUuMTA3Ny01LjkyNTctOC45MTYzLTEuMDAzMy00LjYzODkgMC44OTAzOS0xMy44NDcgMC44OTAzOS0xMy44NDd6Ii8+PHBhdGggZD0ibTQ4LjEwMSA5Mi44ODdzLTkuMjI0OCA5LjMzODYtOS41ODA4IDE1LjM2M2MtMC4zOTUzNSA2LjY5MTEgNy4yMjU4IDExLjUwNSA4LjU1NjYgMTguMTk3IDAuNDE1MjcgMi4wODg0IDAuNTc0MzIgMy45NTYtMC4yNTA2MyA1LjkxOS0xLjA1NTIgMi41MTEtMy40ODE5IDMuNTc3NC00LjMzNDEgNi4xMDItMC44NzAwNyAyLjU3NzYtMS45MDQxIDUuNTMyOC0wLjU4NTQ5IDguNjE3NiAwLjUwNjM3IDEuMTg0NiAxLjE2NjQgMi41ODMgMS41MDY0IDMuODI1NiAxLjM5ODIgNS4xMTEgMS4zMjAxIDEwLjIyMSAwLjAzNDExIDE1LjYxNy0wLjc0MTggMy4xMTI2LTMuMzc1OCA1LjcwMjgtNC4zODExIDguNzQwNi0wLjY2NDQ0IDIuMDA3Ny0wLjYyMTQ1IDQuMjUzNi0wLjI2ODIgNi4zMzg2IDEuMjg5OCA3LjYxMjggNi41OTEgMTQuMDYgOC41NDczIDIxLjUyOSAwLjg5MzY1IDMuNDEyMS0yLjA3NDggMTAuNDg2IDEuNDE3NSAxMC40ODYgNC41MzE5IDAgNC4yMDI3LTAuMDEzNCA4LjEzNDQtMC4wMTM0IDIuODA4MiAwLTAuMTEwMDMtNS42NDUtMC42NjE5OC04LjM5ODQtMC41NzQ2OC0yLjg2NjktMS4zNjY2LTUuODA3Ni0xLjg1MDMtOC42OTItMC40ODI5OS0yLjg4MDMtMC45NDc3Mi01LjI5MTggMC4yMjQ0OC04LjIzNzggMS4yMTAyLTMuMDQxNSAyLjc4NzgtMi41NzAxIDMuNTAyMS0xLjM2OTIgMi4zNDk3IDMuOTUwMyAyLjczNDcgOS42MzkgMy41ODc0IDEzLjY4MiAwLjE2NzAzIDAuNzkxOTIgMi43MTQ2IDYuNTgwNSAyLjcxNDYgNi41ODA1czAuMDE3MTYgNy44MTA0IDIuNzgwNyA3LjgxMDRoMTIuMTAyYzEuNjY4OCAwIDIuOTk0NS0yLjUwNiAyLjc4MzgtNC4xNjE1LTAuNTA3NjUtMy45ODgyLTkuMDA0MS00LjAwNDUtOS4wMDQxLTguMDI0OCAwLTkuNDAzOC0yLjY2NjMtMTkuOTIyIDAtMjkuODczIDAuNDU0MzMtMS42OTU2IDIuODM0Mi0yLjAzOTUgMy44MDI0LTMuNjQzMiAyLjAxNDgtMy4zMzc0IDAuNjY2MzUtNy43MTQyIDIuNDkyNC0xMS4yNTkgMS4yNzExLTIuNDY3MyAyLjY4NzEtNC41ODg0IDUuNTYzLTUuNzM0NSAzLjYwMTUtMS40MzU0IDcuNjkyOC0xLjI0NTQgMTEuMjQzIDAuMzEzMTYgNy4yNDY4IDMuMTgxNiAxMC45NzUgMTEuODk0IDE3LjM4OSAxNS41MjYgMy40NTg0IDEuOTU4NSA4LjgwNTItMC4yMjIyNCAxMi41IDEuMjQyMyAxLjQ5NTIgMC41OTI2NyAyLjg3NTQgMS4wNDc0IDMuMDI4MiAyLjMwNzQgMC41NjI2OSA0LjY0IDEuMDQ1NiA4LjczOTkgMCAxMi42NDItMC4zMTE5OSAxLjE2NDQtMC42OTQ4MSAwLjk2OTE5LTEuMDE4OSAyLjEzMDItMC44NjQ5NyAzLjA5ODQtMC43NTcwNCA0LjgzNzUtMC4yODQ5MyA3LjYwMTQgMC4xNjk4NyAwLjk5NDQ2IDEuMDA0NyAxLjkyODUgMS4wMDQ3IDIuOTM3NCAwIDcuMDE5NC00LjQ0NTEgMTguNzU2IDEuODE0NCAxOC43NTZoMTQuNDE3YzEuNjMyOSAwIDIuMTU2LTEuMjA3NSAyLjkxMjUtMi42NTQ2IDAuNzMxNjctMS4zOTk2IDAuOTMwMTctNC4yODQyIDAuMTg2MDQtNS42NzcyLTEuNTQ2Ni0yLjg5NTItNi4zODYtMC43Njg0NC03LjEzMzQtMy41NTc5LTIuODk0Mi0xMC44MDEtMC4wMzItMjQuMjU5LTAuMDMyLTM2LjMwOCAwLTUuNzUzMiA4LjE1MDctOC43MDM0IDkuNzgwOC0xNC4yMjEgMS4zODIxLTQuNjc3OSAyLjkwNzctOS44OTg0IDEuNzEtMTQuNTI0bC0yNC41LTI0LjVjLTEuMjExMS0wLjM2Mzc1LTIuNDM2Ny0wLjYzODQyLTMuNjczMi0wLjc5OTk1LTUuMjA5NC0wLjY4MDUzLTE0LjEyIDYuNTc2OS0xNC4xMiA2LjU3NjloLTU0LjUwNWMtMy4xNTI2IDAtNC45Njg5LTEuMjg4OC03LjIwNDktNC4yODI0LTEuNTgxNC0yLjExNzEtMy43NzA4LTYuMzc0Ny0zLjc0ODQtOC43MTI5IDAuMDI2MjEtMi43NDQ4IDIuMjIxMy01LjE2OTYgMy42MDctOC4yMTQ4IDAuNzk2MS0xLjc0OTUtMC4yMDQxMi01Ljk4MzEtMC4yMDQxMi01Ljk4MzF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0.10476190476190476,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="56" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="231,113,72,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="57" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC45NW1tIiBoZWlnaHQ9IjExOS44bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC45NSAxMTkuOCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQuMTUxIDkwLjgwMi0wLjI0MzkxIDAuMzE5ODh2MjguNjc4aDEzMy4xM3YtMjguNjlsLTAuMjM1MTMtMC4zMDc0N2gtMzkuMTc5YTI5LjE0MyAyOS4wOTEgMCAwIDEtMTkuNzYzIDE3LjYwMSAyOS4xNDYgMjkuNDczIDAgMCAxLTEuMjM5NyAwLjMwOTU0IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDQzIDAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjU5NzMgMC4yMzYxNiAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAwMiAwLjEwMjgzIDI5LjE0NiAyOS40NzMgMCAwIDEtMi41NDQgMC4xMjQ1NCAyOS4xNDYgMjkuNDczIDAgMCAxLTAuMDAyMDY3IDAgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0yLjU0MTQtMC4xMjQ1NCAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAyNzktMC4xMDI4MyAyOS4xNDYgMjkuNDczIDAgMCAxLTEuNTkzNy0wLjIzNjE2IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDc5LTAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjI0NTQtMC4zMTE2MSAyOS4xNDMgMjkuMDkxIDAgMCAxLTE5Ljc1Ni0xNy41OTloLTM5LjE3eiIvPjxwYXRoIGQ9Im01MC4wNTQgNDMuODI1LTM2LjE0NyA0Ny4yOTdoMzkuNTQxYy0xLjM2NDEtMy40MjY1LTIuMDkyNy03LjA4MDgtMi4wOTQyLTEwLjc2OSAyLjAxZS00IC0xNi4wOTggMTMuMDUtMjkuMTQ4IDI5LjE0OS0yOS4xNDggMTYuMDk4IDJlLTQgMjkuMTQ4IDEzLjA1IDI5LjE0OCAyOS4xNDgtMmUtMyAzLjY4ODEtMC43OTM3OSA3LjM0MjMtMi4xNTc5IDEwLjc2OWgzOS41NDFsM2UtNSAtMC4wMTQ5OS0zNi4xMDktNDcuMjgyeiIvPjxyZWN0IHg9IjUyLjIzMiIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxyZWN0IHg9IjkzLjAxNCIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxwYXRoIGQ9Im0wIDUxLjA1OSAzOS40NTgtNS4yNDgydi0xMi4xMzRoLTQuOTAzOHYtMTIuOTk4bDMzLjM4NC0wLjE0ODkzdi0yMC4wMzNzLTI0LjQ0NSAxLjYyMTYtMzUuNjE0IDYuMTM1NmMtOC42MzQxIDMuNDg5Ni0xNi43OTEgOC44NjU4LTIzLjA5NiAxNS43MTktMy44NTU0IDQuMTkwNy04LjQwMzUgMTQuODczLTguNDAzNSAxNC44NzN6Ii8+PHBhdGggZD0ibTE2MC45NSA1MS4wNTktMzkuNDU4LTUuMjQ4MnYtMTIuMTM0aDQuOTAzOHYtMTIuOTk4bC0zMy4zODQtMC4xNDg5M3YtMjAuMDMzczI0LjQ0NSAxLjYyMTYgMzUuNjE0IDYuMTM1NmM4LjYzNDEgMy40ODk2IDE2Ljc5MSA4Ljg2NTggMjMuMDk2IDE1LjcxOSAzLjg1NTQgNC4xOTA3IDguNDAzNiAxNC44NzMgOC40MDM2IDE0Ljg3M3oiLz48cGF0aCBkPSJtMzQuNTU0IDIwLjY3OWg5MS44NDR2LTE0Ljg1NnMtMjIuMTUtNC40MzU4LTMzLjM4NC01LjMyNjJjLTguMzMyNy0wLjY2MDU1LTE2Ljc0NC0wLjY2NTA1LTI1LjA3NyA1ZS02IC0xMS4zMDggMC45MDI1Ni0zMy42MDEgNS4zOTgyLTMzLjYwMSA1LjM5ODJsMC4yMTcyMyAxNC43ODQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="58" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNC4yOW1tIiBoZWlnaHQ9IjE1OC4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjQuMjkgMTU4LjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC44NjcgLTY5LjQxKSI+PHJlY3QgeD0iMTUyLjU3IiB5PSI5NC4yMjUiIHdpZHRoPSIxMS4yNDMiIGhlaWdodD0iMTMzLjE5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxjaXJjbGUgY3g9IjE1OC42NSIgY3k9Ijc5LjkxMSIgcj0iMTAuNTAxIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im0xNDYuMDQgOTMuNzY1djc2LjM0MnMtMjQuNzA4IDAuMjUwNTgtMzYuMTYyIDQuMjY3NWMtMTMuMjcxIDQuNjU0MS0yMi42MDkgMTcuNDU2LTM1LjgwOSAyMi4zMDgtNi4xMjYyIDIuMjUxOC0xMi45OTkgMS40NTE3LTE5LjM2OSAyLjg3NDItMy4zNDA0IDAuNzQ1OTYtOS44MzMgMi45NTY4LTkuODMzIDIuOTU2OHYtNzYuNTY2czI2LjE5Ni0xLjcyOTIgMzcuODgxLTcuMDYxN2M5LjAyMDMtNC4xMTYzIDE0LjIxNy0xNC40OTMgMjMuMjgtMTguNTE2IDEyLjM1NS01LjQ4NDMgNDAuMDExLTYuNjA0OCA0MC4wMTEtNi42MDQ4eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.0903" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="59" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OC4yN21tIiBoZWlnaHQ9IjE0Ni4wNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDguMjcgMTQ2LjA2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMi44MDQgLTc1LjU0OCkiPjxwYXRoIGQ9Im0zMi44MDQgNzUuNTQ4czM1LjAwOSAyLjEyNTkgNTAuOTU1IDE4LjY1NGMxOS4yMDUgMTkuOTA2IDIzLjE4IDU0LjM3NyAyMy4xOCA1NC4zNzdzLTMyLjk5MS0xLjY4MzEtNTMuNDA3LTIxLjcxNmMtMTkuMTEzLTE4Ljc1NS0yMC43MjctNTEuMzE0LTIwLjcyNy01MS4zMTR6Ii8+PHBhdGggZD0ibTE4MS4wNyA3NS41NDhzLTM1LjAwOSAyLjEyNTktNTAuOTU1IDE4LjY1NGMtMTkuMjA1IDE5LjkwNi0yMy4xOCA1NC4zNzctMjMuMTggNTQuMzc3czMyLjk5MS0xLjY4MzEgNTMuNDA3LTIxLjcxNmMxOS4xMTMtMTguNzU1IDIwLjcyNy01MS4zMTQgMjAuNzI3LTUxLjMxNHoiLz48cGF0aCBkPSJtMTgxLjA3IDIyMS42MXMtMzUuMDA5LTIuMTI1OS01MC45NTUtMTguNjU0Yy0xOS4yMDUtMTkuOTA2LTIzLjE4LTU0LjM3Ny0yMy4xOC01NC4zNzdzMzIuOTkxIDEuNjgzMSA1My40MDcgMjEuNzE2YzE5LjExMyAxOC43NTUgMjAuNzI3IDUxLjMxNCAyMC43MjcgNTEuMzE0eiIvPjxwYXRoIGQ9Im0zMi44MDQgMjIxLjYxczM1LjAwOS0yLjEyNTkgNTAuOTU1LTE4LjY1NGMxOS4yMDUtMTkuOTA2IDIzLjE4LTU0LjM3NyAyMy4xOC01NC4zNzdzLTMyLjk5MSAxLjY4MzEtNTMuNDA3IDIxLjcxNmMtMTkuMTEzIDE4Ljc1NS0yMC43MjcgNTEuMzE0LTIwLjcyNyA1MS4zMTR6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE1Ni4xOG1tIiBoZWlnaHQ9IjkwLjY4NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNTYuMTggOTAuNjg1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjE3LjQwMiIgY3k9IjE3LjQwMiIgcj0iMTQuMTg5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utb3BhY2l0eT0iLjk5MDE0IiBzdHJva2Utd2lkdGg9IjYuNDI1IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PGNpcmNsZSBjeD0iMTcuNDAyIiBjeT0iNzMuMjgzIiByPSIxNC4xODkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS1vcGFjaXR5PSIuOTkwMTQiIHN0cm9rZS13aWR0aD0iNi40MjUiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48Zz48cGF0aCBkPSJtMjYuMzA0IDMxLjY4NSA5LjE3OTUtMC40NDkxIDg5LjAyOSAzOS40M2gyOS4wNzFsLTExNi41OC00Ni42ODQtNS40MTE5LTYuNTgwNXoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjYuOSIvPjxwYXRoIGQ9Im0yNi4zMDQgNTkgOS4xNzk1IDAuNDQ5MSA4OS4wMjktMzkuNDNoMjkuMDcxbC0xMTYuNTggNDYuNjg0LTUuNDExOSA2LjU4MDV6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI2LjkiLz48cGF0aCBkPSJtNzUuNDE0IDQ1LjU2MS0xOC42ODUgOC43MTUydi0xNy40M3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="60" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg5LjAwNG1tIiBoZWlnaHQ9IjE2MS4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4OS4wMDQgMTYxLjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxyZWN0IHg9IjE0LjY3NiIgeT0iNTguNzQ4IiB3aWR0aD0iMTYuMTY5IiBoZWlnaHQ9IjEwMi4yNiIgcnk9IjcuMzI5MiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cGF0aCBkPSJtMWUtNiAzNy45ODV2MjAuODMxYzAgNC45MTY3IDMuOTU4MiA4Ljg3NTQgOC44NzQ5IDguODc1NGgyNy43NzJjNC45MTY3IDAgOC44NzQ5LTMuOTU4NyA4Ljg3NDktOC44NzU0di0yMC44MzFoLTguNzg3MWMtMWUtNiA1LjM3ODEtNy4yN2UtNCA5LjcxLTAuMDAxNiA5LjcxaC01LjMyOTljLTMuODdlLTQgMC0wLjAwMTUtNC4zMzE5LTAuMDAxNS05LjcxaC01Ljk3NDNjLTFlLTYgNS4zNzgxLTcuMjdlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc0ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTYtOS43MWgtNS45NzQzYzAgNS4zNzgxLTcuMjVlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc1ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTUtOS43MXoiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iLTQuMTI2ZS03IiB5PSIuMDAyMDciIHdpZHRoPSI4Ljc4ODYiIGhlaWdodD0iNDcuODQyIiByeD0iMCIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMzYuNzMzIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjguNzg4NiIgaGVpZ2h0PSI0Ny44NDIiIHJ4PSIwIiByeT0iMCIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSIxNC4xMTkiIHk9IjIuNDU5ZS02IiB3aWR0aD0iNS45Nzc0IiBoZWlnaHQ9IjQ3LjY5NSIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMjUuNDI2IiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjUuOTc3NCIgaGVpZ2h0PSI0Ny42OTUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjcxLjQ2MSIgeT0iMi40NTllLTYiIHdpZHRoPSIxNy41NDMiIGhlaWdodD0iMTYxLjAxIiByeT0iNy40NDA1IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im03My43OTUgMGMtOC4zNzU0IDAtMTUuMTE4IDYuNjI3Ni0xNS4xMTggMTQuODZ2MjguMThoMzAuMzI3di0yOC4xOGMwLTguMjMyNS02Ljc0MzEtMTQuODYtMTUuMTE4LTE0Ljg2eiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSI1OC42NzciIHk9IjMyLjAyMiIgd2lkdGg9IjMwLjMyNyIgaGVpZ2h0PSI2NS45MzMiIHJ5PSI5LjA5NjkiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iNzMuNzExIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjE1LjI5MyIgaGVpZ2h0PSIyNC40MzUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.0956" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="61" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MG1tIiBoZWlnaHQ9IjE1Ni4ybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MCAxNTYuMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjUuOTIyIC03MC45OCkiPjxnPjxwYXRoIGQ9Im0xNTIgOTQuNzA1LTMzLjIgOTEuMzgzcy0yLjY1MTIgOS4yNjg1IDEuNjc5NSAxOS43OTNjNC4xMTk0IDEwLjAxMSAxNC43OCAyMS4zMDUgMzEuNTIgMjEuMzA1IDE1LjUyIDAgMjYuMjI3LTEwLjA5MiAzMC42MzUtMTkuMjkzIDUuMzQ1OS0xMS4xNTcgMi41NzYxLTIxLjgwNCAyLjU3NjEtMjEuODA0em02ZS0zIDMxLjU5MSAyMy4zNjcgNTkuNzkyaC00Ni43MzR6Ii8+PHBhdGggZD0ibTU5LjkyNSA5NC43MDQtMzMuMiA5MS4zODNzLTIuNjUxMiA5LjI2ODUgMS42Nzk1IDE5Ljc5M2M0LjExOTQgMTAuMDExIDE0Ljc4IDIxLjMwNSAzMS41MiAyMS4zMDUgMTUuNTIgMCAyNi4yMjctMTAuMDkyIDMwLjYzNS0xOS4yOTMgNS4zNDU5LTExLjE1NyAyLjU3NjEtMjEuODA0IDIuNTc2MS0yMS44MDR6bTAuMDA1NyAzMS41OTEgMjMuMzY3IDU5Ljc5MmgtNDYuNzM0eiIvPjxyZWN0IHg9Ijk2LjEwMyIgeT0iNzAuOTgiIHdpZHRoPSIxOS43MTQiIGhlaWdodD0iMjQuOTUzIiByeT0iMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjEuOTQ4IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjU2LjIzNCIgeT0iOTIuMzE0IiB3aWR0aD0iOTkuNDYzIiBoZWlnaHQ9IjEyLjU2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjAuNDM5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48cGF0aCBjbGFzcz0iVW5vcHRpbWljZWRUcmFuc2Zvcm1zIiBkPSJtMCAwIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="62" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE1Ni4xOG1tIiBoZWlnaHQ9IjkwLjY4NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNTYuMTggOTAuNjg1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjE3LjQwMiIgY3k9IjE3LjQwMiIgcj0iMTQuMTg5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utb3BhY2l0eT0iLjk5MDE0IiBzdHJva2Utd2lkdGg9IjYuNDI1IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PGNpcmNsZSBjeD0iMTcuNDAyIiBjeT0iNzMuMjgzIiByPSIxNC4xODkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS1vcGFjaXR5PSIuOTkwMTQiIHN0cm9rZS13aWR0aD0iNi40MjUiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48Zz48cGF0aCBkPSJtMjYuMzA0IDMxLjY4NSA5LjE3OTUtMC40NDkxIDg5LjAyOSAzOS40M2gyOS4wNzFsLTExNi41OC00Ni42ODQtNS40MTE5LTYuNTgwNXoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjYuOSIvPjxwYXRoIGQ9Im0yNi4zMDQgNTkgOS4xNzk1IDAuNDQ5MSA4OS4wMjktMzkuNDNoMjkuMDcxbC0xMTYuNTggNDYuNjg0LTUuNDExOSA2LjU4MDV6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI2LjkiLz48cGF0aCBkPSJtNzUuNDE0IDQ1LjU2MS0xOC42ODUgOC43MTUydi0xNy40M3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="63" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ni4yNG1tIiBoZWlnaHQ9IjEzNi44Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDYuMjQgMTM2LjgyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zOC41MDYgLTc4LjkyOSkiPjxwYXRoIGQ9Im0xNjYuMDIgNzguOTI5cy04LjU0OTggMC43Nzc3OS0xMi4xNSAyLjg2MzljLTUuNzc0NyAzLjM0Ni05LjY3ODUgOS4yNzkzLTEzLjY3NyAxNC42MjMtMi4zNTQ0IDMuMTQ2My01LjU2MjYgOC45MTMyLTcuMzI1MSAxMi4xODJsMjEuNDc2IDIxLjQ3NmMwLjA3MzMtMC4wOTMgMC45MTUzLTAuOTQxOTMgMC4yMDgyNi0wLjI2ODcyIDEuMTM5MS0xLjU0OTYgMC4wMjUxLTUuMDkzNiAyLjg4NjgtNS4yNjE4IDUuNTY5LTAuMzI3MzYgMTMuMzYtMi4yMDkxIDE0LjIwMi0yLjMzOTkgMC44NDI4OC0wLjEzMDg1IDExLjU0NC0xLjYwMzYgMTIuNjYtNS43NjY3IDAuNjQ2MTgtMi40MTE2IDAuMzk5MzktMy40NTU0IDAuMzk5MzktNi41MzMyIDAtNC45Mjg2LTkuNjU3NC01LjEwNzctMTMuNjQ0LTguMjEwOS0zLjA3NDktMi4zOTMzLTUuMTAyLTUuMTA3Ny01LjkyNTctOC45MTYzLTEuMDAzMy00LjYzODkgMC44OTAzOS0xMy44NDcgMC44OTAzOS0xMy44NDd6Ii8+PHBhdGggZD0ibTQ4LjEwMSA5Mi44ODdzLTkuMjI0OCA5LjMzODYtOS41ODA4IDE1LjM2M2MtMC4zOTUzNSA2LjY5MTEgNy4yMjU4IDExLjUwNSA4LjU1NjYgMTguMTk3IDAuNDE1MjcgMi4wODg0IDAuNTc0MzIgMy45NTYtMC4yNTA2MyA1LjkxOS0xLjA1NTIgMi41MTEtMy40ODE5IDMuNTc3NC00LjMzNDEgNi4xMDItMC44NzAwNyAyLjU3NzYtMS45MDQxIDUuNTMyOC0wLjU4NTQ5IDguNjE3NiAwLjUwNjM3IDEuMTg0NiAxLjE2NjQgMi41ODMgMS41MDY0IDMuODI1NiAxLjM5ODIgNS4xMTEgMS4zMjAxIDEwLjIyMSAwLjAzNDExIDE1LjYxNy0wLjc0MTggMy4xMTI2LTMuMzc1OCA1LjcwMjgtNC4zODExIDguNzQwNi0wLjY2NDQ0IDIuMDA3Ny0wLjYyMTQ1IDQuMjUzNi0wLjI2ODIgNi4zMzg2IDEuMjg5OCA3LjYxMjggNi41OTEgMTQuMDYgOC41NDczIDIxLjUyOSAwLjg5MzY1IDMuNDEyMS0yLjA3NDggMTAuNDg2IDEuNDE3NSAxMC40ODYgNC41MzE5IDAgNC4yMDI3LTAuMDEzNCA4LjEzNDQtMC4wMTM0IDIuODA4MiAwLTAuMTEwMDMtNS42NDUtMC42NjE5OC04LjM5ODQtMC41NzQ2OC0yLjg2NjktMS4zNjY2LTUuODA3Ni0xLjg1MDMtOC42OTItMC40ODI5OS0yLjg4MDMtMC45NDc3Mi01LjI5MTggMC4yMjQ0OC04LjIzNzggMS4yMTAyLTMuMDQxNSAyLjc4NzgtMi41NzAxIDMuNTAyMS0xLjM2OTIgMi4zNDk3IDMuOTUwMyAyLjczNDcgOS42MzkgMy41ODc0IDEzLjY4MiAwLjE2NzAzIDAuNzkxOTIgMi43MTQ2IDYuNTgwNSAyLjcxNDYgNi41ODA1czAuMDE3MTYgNy44MTA0IDIuNzgwNyA3LjgxMDRoMTIuMTAyYzEuNjY4OCAwIDIuOTk0NS0yLjUwNiAyLjc4MzgtNC4xNjE1LTAuNTA3NjUtMy45ODgyLTkuMDA0MS00LjAwNDUtOS4wMDQxLTguMDI0OCAwLTkuNDAzOC0yLjY2NjMtMTkuOTIyIDAtMjkuODczIDAuNDU0MzMtMS42OTU2IDIuODM0Mi0yLjAzOTUgMy44MDI0LTMuNjQzMiAyLjAxNDgtMy4zMzc0IDAuNjY2MzUtNy43MTQyIDIuNDkyNC0xMS4yNTkgMS4yNzExLTIuNDY3MyAyLjY4NzEtNC41ODg0IDUuNTYzLTUuNzM0NSAzLjYwMTUtMS40MzU0IDcuNjkyOC0xLjI0NTQgMTEuMjQzIDAuMzEzMTYgNy4yNDY4IDMuMTgxNiAxMC45NzUgMTEuODk0IDE3LjM4OSAxNS41MjYgMy40NTg0IDEuOTU4NSA4LjgwNTItMC4yMjIyNCAxMi41IDEuMjQyMyAxLjQ5NTIgMC41OTI2NyAyLjg3NTQgMS4wNDc0IDMuMDI4MiAyLjMwNzQgMC41NjI2OSA0LjY0IDEuMDQ1NiA4LjczOTkgMCAxMi42NDItMC4zMTE5OSAxLjE2NDQtMC42OTQ4MSAwLjk2OTE5LTEuMDE4OSAyLjEzMDItMC44NjQ5NyAzLjA5ODQtMC43NTcwNCA0LjgzNzUtMC4yODQ5MyA3LjYwMTQgMC4xNjk4NyAwLjk5NDQ2IDEuMDA0NyAxLjkyODUgMS4wMDQ3IDIuOTM3NCAwIDcuMDE5NC00LjQ0NTEgMTguNzU2IDEuODE0NCAxOC43NTZoMTQuNDE3YzEuNjMyOSAwIDIuMTU2LTEuMjA3NSAyLjkxMjUtMi42NTQ2IDAuNzMxNjctMS4zOTk2IDAuOTMwMTctNC4yODQyIDAuMTg2MDQtNS42NzcyLTEuNTQ2Ni0yLjg5NTItNi4zODYtMC43Njg0NC03LjEzMzQtMy41NTc5LTIuODk0Mi0xMC44MDEtMC4wMzItMjQuMjU5LTAuMDMyLTM2LjMwOCAwLTUuNzUzMiA4LjE1MDctOC43MDM0IDkuNzgwOC0xNC4yMjEgMS4zODIxLTQuNjc3OSAyLjkwNzctOS44OTg0IDEuNzEtMTQuNTI0bC0yNC41LTI0LjVjLTEuMjExMS0wLjM2Mzc1LTIuNDM2Ny0wLjYzODQyLTMuNjczMi0wLjc5OTk1LTUuMjA5NC0wLjY4MDUzLTE0LjEyIDYuNTc2OS0xNC4xMiA2LjU3NjloLTU0LjUwNWMtMy4xNTI2IDAtNC45Njg5LTEuMjg4OC03LjIwNDktNC4yODI0LTEuNTgxNC0yLjExNzEtMy43NzA4LTYuMzc0Ny0zLjc0ODQtOC43MTI5IDAuMDI2MjEtMi43NDQ4IDIuMjIxMy01LjE2OTYgMy42MDctOC4yMTQ4IDAuNzk2MS0xLjc0OTUtMC4yMDQxMi01Ljk4MzEtMC4yMDQxMi01Ljk4MzF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0.10476190476190476,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="64" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="65" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC45NW1tIiBoZWlnaHQ9IjExOS44bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC45NSAxMTkuOCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQuMTUxIDkwLjgwMi0wLjI0MzkxIDAuMzE5ODh2MjguNjc4aDEzMy4xM3YtMjguNjlsLTAuMjM1MTMtMC4zMDc0N2gtMzkuMTc5YTI5LjE0MyAyOS4wOTEgMCAwIDEtMTkuNzYzIDE3LjYwMSAyOS4xNDYgMjkuNDczIDAgMCAxLTEuMjM5NyAwLjMwOTU0IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDQzIDAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjU5NzMgMC4yMzYxNiAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAwMiAwLjEwMjgzIDI5LjE0NiAyOS40NzMgMCAwIDEtMi41NDQgMC4xMjQ1NCAyOS4xNDYgMjkuNDczIDAgMCAxLTAuMDAyMDY3IDAgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0yLjU0MTQtMC4xMjQ1NCAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAyNzktMC4xMDI4MyAyOS4xNDYgMjkuNDczIDAgMCAxLTEuNTkzNy0wLjIzNjE2IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDc5LTAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjI0NTQtMC4zMTE2MSAyOS4xNDMgMjkuMDkxIDAgMCAxLTE5Ljc1Ni0xNy41OTloLTM5LjE3eiIvPjxwYXRoIGQ9Im01MC4wNTQgNDMuODI1LTM2LjE0NyA0Ny4yOTdoMzkuNTQxYy0xLjM2NDEtMy40MjY1LTIuMDkyNy03LjA4MDgtMi4wOTQyLTEwLjc2OSAyLjAxZS00IC0xNi4wOTggMTMuMDUtMjkuMTQ4IDI5LjE0OS0yOS4xNDggMTYuMDk4IDJlLTQgMjkuMTQ4IDEzLjA1IDI5LjE0OCAyOS4xNDgtMmUtMyAzLjY4ODEtMC43OTM3OSA3LjM0MjMtMi4xNTc5IDEwLjc2OWgzOS41NDFsM2UtNSAtMC4wMTQ5OS0zNi4xMDktNDcuMjgyeiIvPjxyZWN0IHg9IjUyLjIzMiIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxyZWN0IHg9IjkzLjAxNCIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxwYXRoIGQ9Im0wIDUxLjA1OSAzOS40NTgtNS4yNDgydi0xMi4xMzRoLTQuOTAzOHYtMTIuOTk4bDMzLjM4NC0wLjE0ODkzdi0yMC4wMzNzLTI0LjQ0NSAxLjYyMTYtMzUuNjE0IDYuMTM1NmMtOC42MzQxIDMuNDg5Ni0xNi43OTEgOC44NjU4LTIzLjA5NiAxNS43MTktMy44NTU0IDQuMTkwNy04LjQwMzUgMTQuODczLTguNDAzNSAxNC44NzN6Ii8+PHBhdGggZD0ibTE2MC45NSA1MS4wNTktMzkuNDU4LTUuMjQ4MnYtMTIuMTM0aDQuOTAzOHYtMTIuOTk4bC0zMy4zODQtMC4xNDg5M3YtMjAuMDMzczI0LjQ0NSAxLjYyMTYgMzUuNjE0IDYuMTM1NmM4LjYzNDEgMy40ODk2IDE2Ljc5MSA4Ljg2NTggMjMuMDk2IDE1LjcxOSAzLjg1NTQgNC4xOTA3IDguNDAzNiAxNC44NzMgOC40MDM2IDE0Ljg3M3oiLz48cGF0aCBkPSJtMzQuNTU0IDIwLjY3OWg5MS44NDR2LTE0Ljg1NnMtMjIuMTUtNC40MzU4LTMzLjM4NC01LjMyNjJjLTguMzMyNy0wLjY2MDU1LTE2Ljc0NC0wLjY2NTA1LTI1LjA3NyA1ZS02IC0xMS4zMDggMC45MDI1Ni0zMy42MDEgNS4zOTgyLTMzLjYwMSA1LjM5ODJsMC4yMTcyMyAxNC43ODQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="66" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNC4yOW1tIiBoZWlnaHQ9IjE1OC4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjQuMjkgMTU4LjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC44NjcgLTY5LjQxKSI+PHJlY3QgeD0iMTUyLjU3IiB5PSI5NC4yMjUiIHdpZHRoPSIxMS4yNDMiIGhlaWdodD0iMTMzLjE5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxjaXJjbGUgY3g9IjE1OC42NSIgY3k9Ijc5LjkxMSIgcj0iMTAuNTAxIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im0xNDYuMDQgOTMuNzY1djc2LjM0MnMtMjQuNzA4IDAuMjUwNTgtMzYuMTYyIDQuMjY3NWMtMTMuMjcxIDQuNjU0MS0yMi42MDkgMTcuNDU2LTM1LjgwOSAyMi4zMDgtNi4xMjYyIDIuMjUxOC0xMi45OTkgMS40NTE3LTE5LjM2OSAyLjg3NDItMy4zNDA0IDAuNzQ1OTYtOS44MzMgMi45NTY4LTkuODMzIDIuOTU2OHYtNzYuNTY2czI2LjE5Ni0xLjcyOTIgMzcuODgxLTcuMDYxN2M5LjAyMDMtNC4xMTYzIDE0LjIxNy0xNC40OTMgMjMuMjgtMTguNTE2IDEyLjM1NS01LjQ4NDMgNDAuMDExLTYuNjA0OCA0MC4wMTEtNi42MDQ4eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.0903" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="67" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OC4yN21tIiBoZWlnaHQ9IjE0Ni4wNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDguMjcgMTQ2LjA2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMi44MDQgLTc1LjU0OCkiPjxwYXRoIGQ9Im0zMi44MDQgNzUuNTQ4czM1LjAwOSAyLjEyNTkgNTAuOTU1IDE4LjY1NGMxOS4yMDUgMTkuOTA2IDIzLjE4IDU0LjM3NyAyMy4xOCA1NC4zNzdzLTMyLjk5MS0xLjY4MzEtNTMuNDA3LTIxLjcxNmMtMTkuMTEzLTE4Ljc1NS0yMC43MjctNTEuMzE0LTIwLjcyNy01MS4zMTR6Ii8+PHBhdGggZD0ibTE4MS4wNyA3NS41NDhzLTM1LjAwOSAyLjEyNTktNTAuOTU1IDE4LjY1NGMtMTkuMjA1IDE5LjkwNi0yMy4xOCA1NC4zNzctMjMuMTggNTQuMzc3czMyLjk5MS0xLjY4MzEgNTMuNDA3LTIxLjcxNmMxOS4xMTMtMTguNzU1IDIwLjcyNy01MS4zMTQgMjAuNzI3LTUxLjMxNHoiLz48cGF0aCBkPSJtMTgxLjA3IDIyMS42MXMtMzUuMDA5LTIuMTI1OS01MC45NTUtMTguNjU0Yy0xOS4yMDUtMTkuOTA2LTIzLjE4LTU0LjM3Ny0yMy4xOC01NC4zNzdzMzIuOTkxIDEuNjgzMSA1My40MDcgMjEuNzE2YzE5LjExMyAxOC43NTUgMjAuNzI3IDUxLjMxNCAyMC43MjcgNTEuMzE0eiIvPjxwYXRoIGQ9Im0zMi44MDQgMjIxLjYxczM1LjAwOS0yLjEyNTkgNTAuOTU1LTE4LjY1NGMxOS4yMDUtMTkuOTA2IDIzLjE4LTU0LjM3NyAyMy4xOC01NC4zNzdzLTMyLjk5MSAxLjY4MzEtNTMuNDA3IDIxLjcxNmMtMTkuMTEzIDE4Ljc1NS0yMC43MjcgNTEuMzE0LTIwLjcyNyA1MS4zMTR6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="68" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg5LjAwNG1tIiBoZWlnaHQ9IjE2MS4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4OS4wMDQgMTYxLjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxyZWN0IHg9IjE0LjY3NiIgeT0iNTguNzQ4IiB3aWR0aD0iMTYuMTY5IiBoZWlnaHQ9IjEwMi4yNiIgcnk9IjcuMzI5MiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cGF0aCBkPSJtMWUtNiAzNy45ODV2MjAuODMxYzAgNC45MTY3IDMuOTU4MiA4Ljg3NTQgOC44NzQ5IDguODc1NGgyNy43NzJjNC45MTY3IDAgOC44NzQ5LTMuOTU4NyA4Ljg3NDktOC44NzU0di0yMC44MzFoLTguNzg3MWMtMWUtNiA1LjM3ODEtNy4yN2UtNCA5LjcxLTAuMDAxNiA5LjcxaC01LjMyOTljLTMuODdlLTQgMC0wLjAwMTUtNC4zMzE5LTAuMDAxNS05LjcxaC01Ljk3NDNjLTFlLTYgNS4zNzgxLTcuMjdlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc0ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTYtOS43MWgtNS45NzQzYzAgNS4zNzgxLTcuMjVlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc1ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTUtOS43MXoiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iLTQuMTI2ZS03IiB5PSIuMDAyMDciIHdpZHRoPSI4Ljc4ODYiIGhlaWdodD0iNDcuODQyIiByeD0iMCIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMzYuNzMzIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjguNzg4NiIgaGVpZ2h0PSI0Ny44NDIiIHJ4PSIwIiByeT0iMCIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSIxNC4xMTkiIHk9IjIuNDU5ZS02IiB3aWR0aD0iNS45Nzc0IiBoZWlnaHQ9IjQ3LjY5NSIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMjUuNDI2IiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjUuOTc3NCIgaGVpZ2h0PSI0Ny42OTUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjcxLjQ2MSIgeT0iMi40NTllLTYiIHdpZHRoPSIxNy41NDMiIGhlaWdodD0iMTYxLjAxIiByeT0iNy40NDA1IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im03My43OTUgMGMtOC4zNzU0IDAtMTUuMTE4IDYuNjI3Ni0xNS4xMTggMTQuODZ2MjguMThoMzAuMzI3di0yOC4xOGMwLTguMjMyNS02Ljc0MzEtMTQuODYtMTUuMTE4LTE0Ljg2eiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSI1OC42NzciIHk9IjMyLjAyMiIgd2lkdGg9IjMwLjMyNyIgaGVpZ2h0PSI2NS45MzMiIHJ5PSI5LjA5NjkiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iNzMuNzExIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjE1LjI5MyIgaGVpZ2h0PSIyNC40MzUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.0956" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="69" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MG1tIiBoZWlnaHQ9IjE1Ni4ybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MCAxNTYuMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjUuOTIyIC03MC45OCkiPjxnPjxwYXRoIGQ9Im0xNTIgOTQuNzA1LTMzLjIgOTEuMzgzcy0yLjY1MTIgOS4yNjg1IDEuNjc5NSAxOS43OTNjNC4xMTk0IDEwLjAxMSAxNC43OCAyMS4zMDUgMzEuNTIgMjEuMzA1IDE1LjUyIDAgMjYuMjI3LTEwLjA5MiAzMC42MzUtMTkuMjkzIDUuMzQ1OS0xMS4xNTcgMi41NzYxLTIxLjgwNCAyLjU3NjEtMjEuODA0em02ZS0zIDMxLjU5MSAyMy4zNjcgNTkuNzkyaC00Ni43MzR6Ii8+PHBhdGggZD0ibTU5LjkyNSA5NC43MDQtMzMuMiA5MS4zODNzLTIuNjUxMiA5LjI2ODUgMS42Nzk1IDE5Ljc5M2M0LjExOTQgMTAuMDExIDE0Ljc4IDIxLjMwNSAzMS41MiAyMS4zMDUgMTUuNTIgMCAyNi4yMjctMTAuMDkyIDMwLjYzNS0xOS4yOTMgNS4zNDU5LTExLjE1NyAyLjU3NjEtMjEuODA0IDIuNTc2MS0yMS44MDR6bTAuMDA1NyAzMS41OTEgMjMuMzY3IDU5Ljc5MmgtNDYuNzM0eiIvPjxyZWN0IHg9Ijk2LjEwMyIgeT0iNzAuOTgiIHdpZHRoPSIxOS43MTQiIGhlaWdodD0iMjQuOTUzIiByeT0iMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjEuOTQ4IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjU2LjIzNCIgeT0iOTIuMzE0IiB3aWR0aD0iOTkuNDYzIiBoZWlnaHQ9IjEyLjU2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjAuNDM5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48cGF0aCBjbGFzcz0iVW5vcHRpbWljZWRUcmFuc2Zvcm1zIiBkPSJtMCAwIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ni4yNG1tIiBoZWlnaHQ9IjEzNi44Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDYuMjQgMTM2LjgyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zOC41MDYgLTc4LjkyOSkiPjxwYXRoIGQ9Im0xNjYuMDIgNzguOTI5cy04LjU0OTggMC43Nzc3OS0xMi4xNSAyLjg2MzljLTUuNzc0NyAzLjM0Ni05LjY3ODUgOS4yNzkzLTEzLjY3NyAxNC42MjMtMi4zNTQ0IDMuMTQ2My01LjU2MjYgOC45MTMyLTcuMzI1MSAxMi4xODJsMjEuNDc2IDIxLjQ3NmMwLjA3MzMtMC4wOTMgMC45MTUzLTAuOTQxOTMgMC4yMDgyNi0wLjI2ODcyIDEuMTM5MS0xLjU0OTYgMC4wMjUxLTUuMDkzNiAyLjg4NjgtNS4yNjE4IDUuNTY5LTAuMzI3MzYgMTMuMzYtMi4yMDkxIDE0LjIwMi0yLjMzOTkgMC44NDI4OC0wLjEzMDg1IDExLjU0NC0xLjYwMzYgMTIuNjYtNS43NjY3IDAuNjQ2MTgtMi40MTE2IDAuMzk5MzktMy40NTU0IDAuMzk5MzktNi41MzMyIDAtNC45Mjg2LTkuNjU3NC01LjEwNzctMTMuNjQ0LTguMjEwOS0zLjA3NDktMi4zOTMzLTUuMTAyLTUuMTA3Ny01LjkyNTctOC45MTYzLTEuMDAzMy00LjYzODkgMC44OTAzOS0xMy44NDcgMC44OTAzOS0xMy44NDd6Ii8+PHBhdGggZD0ibTQ4LjEwMSA5Mi44ODdzLTkuMjI0OCA5LjMzODYtOS41ODA4IDE1LjM2M2MtMC4zOTUzNSA2LjY5MTEgNy4yMjU4IDExLjUwNSA4LjU1NjYgMTguMTk3IDAuNDE1MjcgMi4wODg0IDAuNTc0MzIgMy45NTYtMC4yNTA2MyA1LjkxOS0xLjA1NTIgMi41MTEtMy40ODE5IDMuNTc3NC00LjMzNDEgNi4xMDItMC44NzAwNyAyLjU3NzYtMS45MDQxIDUuNTMyOC0wLjU4NTQ5IDguNjE3NiAwLjUwNjM3IDEuMTg0NiAxLjE2NjQgMi41ODMgMS41MDY0IDMuODI1NiAxLjM5ODIgNS4xMTEgMS4zMjAxIDEwLjIyMSAwLjAzNDExIDE1LjYxNy0wLjc0MTggMy4xMTI2LTMuMzc1OCA1LjcwMjgtNC4zODExIDguNzQwNi0wLjY2NDQ0IDIuMDA3Ny0wLjYyMTQ1IDQuMjUzNi0wLjI2ODIgNi4zMzg2IDEuMjg5OCA3LjYxMjggNi41OTEgMTQuMDYgOC41NDczIDIxLjUyOSAwLjg5MzY1IDMuNDEyMS0yLjA3NDggMTAuNDg2IDEuNDE3NSAxMC40ODYgNC41MzE5IDAgNC4yMDI3LTAuMDEzNCA4LjEzNDQtMC4wMTM0IDIuODA4MiAwLTAuMTEwMDMtNS42NDUtMC42NjE5OC04LjM5ODQtMC41NzQ2OC0yLjg2NjktMS4zNjY2LTUuODA3Ni0xLjg1MDMtOC42OTItMC40ODI5OS0yLjg4MDMtMC45NDc3Mi01LjI5MTggMC4yMjQ0OC04LjIzNzggMS4yMTAyLTMuMDQxNSAyLjc4NzgtMi41NzAxIDMuNTAyMS0xLjM2OTIgMi4zNDk3IDMuOTUwMyAyLjczNDcgOS42MzkgMy41ODc0IDEzLjY4MiAwLjE2NzAzIDAuNzkxOTIgMi43MTQ2IDYuNTgwNSAyLjcxNDYgNi41ODA1czAuMDE3MTYgNy44MTA0IDIuNzgwNyA3LjgxMDRoMTIuMTAyYzEuNjY4OCAwIDIuOTk0NS0yLjUwNiAyLjc4MzgtNC4xNjE1LTAuNTA3NjUtMy45ODgyLTkuMDA0MS00LjAwNDUtOS4wMDQxLTguMDI0OCAwLTkuNDAzOC0yLjY2NjMtMTkuOTIyIDAtMjkuODczIDAuNDU0MzMtMS42OTU2IDIuODM0Mi0yLjAzOTUgMy44MDI0LTMuNjQzMiAyLjAxNDgtMy4zMzc0IDAuNjY2MzUtNy43MTQyIDIuNDkyNC0xMS4yNTkgMS4yNzExLTIuNDY3MyAyLjY4NzEtNC41ODg0IDUuNTYzLTUuNzM0NSAzLjYwMTUtMS40MzU0IDcuNjkyOC0xLjI0NTQgMTEuMjQzIDAuMzEzMTYgNy4yNDY4IDMuMTgxNiAxMC45NzUgMTEuODk0IDE3LjM4OSAxNS41MjYgMy40NTg0IDEuOTU4NSA4LjgwNTItMC4yMjIyNCAxMi41IDEuMjQyMyAxLjQ5NTIgMC41OTI2NyAyLjg3NTQgMS4wNDc0IDMuMDI4MiAyLjMwNzQgMC41NjI2OSA0LjY0IDEuMDQ1NiA4LjczOTkgMCAxMi42NDItMC4zMTE5OSAxLjE2NDQtMC42OTQ4MSAwLjk2OTE5LTEuMDE4OSAyLjEzMDItMC44NjQ5NyAzLjA5ODQtMC43NTcwNCA0LjgzNzUtMC4yODQ5MyA3LjYwMTQgMC4xNjk4NyAwLjk5NDQ2IDEuMDA0NyAxLjkyODUgMS4wMDQ3IDIuOTM3NCAwIDcuMDE5NC00LjQ0NTEgMTguNzU2IDEuODE0NCAxOC43NTZoMTQuNDE3YzEuNjMyOSAwIDIuMTU2LTEuMjA3NSAyLjkxMjUtMi42NTQ2IDAuNzMxNjctMS4zOTk2IDAuOTMwMTctNC4yODQyIDAuMTg2MDQtNS42NzcyLTEuNTQ2Ni0yLjg5NTItNi4zODYtMC43Njg0NC03LjEzMzQtMy41NTc5LTIuODk0Mi0xMC44MDEtMC4wMzItMjQuMjU5LTAuMDMyLTM2LjMwOCAwLTUuNzUzMiA4LjE1MDctOC43MDM0IDkuNzgwOC0xNC4yMjEgMS4zODIxLTQuNjc3OSAyLjkwNzctOS44OTg0IDEuNzEtMTQuNTI0bC0yNC41LTI0LjVjLTEuMjExMS0wLjM2Mzc1LTIuNDM2Ny0wLjYzODQyLTMuNjczMi0wLjc5OTk1LTUuMjA5NC0wLjY4MDUzLTE0LjEyIDYuNTc2OS0xNC4xMiA2LjU3NjloLTU0LjUwNWMtMy4xNTI2IDAtNC45Njg5LTEuMjg4OC03LjIwNDktNC4yODI0LTEuNTgxNC0yLjExNzEtMy43NzA4LTYuMzc0Ny0zLjc0ODQtOC43MTI5IDAuMDI2MjEtMi43NDQ4IDIuMjIxMy01LjE2OTYgMy42MDctOC4yMTQ4IDAuNzk2MS0xLjc0OTUtMC4yMDQxMi01Ljk4MzEtMC4yMDQxMi01Ljk4MzF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0.10476190476190478,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="70" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE1Ni4xOG1tIiBoZWlnaHQ9IjkwLjY4NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNTYuMTggOTAuNjg1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjE3LjQwMiIgY3k9IjE3LjQwMiIgcj0iMTQuMTg5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utb3BhY2l0eT0iLjk5MDE0IiBzdHJva2Utd2lkdGg9IjYuNDI1IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PGNpcmNsZSBjeD0iMTcuNDAyIiBjeT0iNzMuMjgzIiByPSIxNC4xODkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS1vcGFjaXR5PSIuOTkwMTQiIHN0cm9rZS13aWR0aD0iNi40MjUiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48Zz48cGF0aCBkPSJtMjYuMzA0IDMxLjY4NSA5LjE3OTUtMC40NDkxIDg5LjAyOSAzOS40M2gyOS4wNzFsLTExNi41OC00Ni42ODQtNS40MTE5LTYuNTgwNXoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjYuOSIvPjxwYXRoIGQ9Im0yNi4zMDQgNTkgOS4xNzk1IDAuNDQ5MSA4OS4wMjktMzkuNDNoMjkuMDcxbC0xMTYuNTggNDYuNjg0LTUuNDExOSA2LjU4MDV6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI2LjkiLz48cGF0aCBkPSJtNzUuNDE0IDQ1LjU2MS0xOC42ODUgOC43MTUydi0xNy40M3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="71" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ni4yNG1tIiBoZWlnaHQ9IjEzNi44Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDYuMjQgMTM2LjgyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zOC41MDYgLTc4LjkyOSkiPjxwYXRoIGQ9Im0xNjYuMDIgNzguOTI5cy04LjU0OTggMC43Nzc3OS0xMi4xNSAyLjg2MzljLTUuNzc0NyAzLjM0Ni05LjY3ODUgOS4yNzkzLTEzLjY3NyAxNC42MjMtMi4zNTQ0IDMuMTQ2My01LjU2MjYgOC45MTMyLTcuMzI1MSAxMi4xODJsMjEuNDc2IDIxLjQ3NmMwLjA3MzMtMC4wOTMgMC45MTUzLTAuOTQxOTMgMC4yMDgyNi0wLjI2ODcyIDEuMTM5MS0xLjU0OTYgMC4wMjUxLTUuMDkzNiAyLjg4NjgtNS4yNjE4IDUuNTY5LTAuMzI3MzYgMTMuMzYtMi4yMDkxIDE0LjIwMi0yLjMzOTkgMC44NDI4OC0wLjEzMDg1IDExLjU0NC0xLjYwMzYgMTIuNjYtNS43NjY3IDAuNjQ2MTgtMi40MTE2IDAuMzk5MzktMy40NTU0IDAuMzk5MzktNi41MzMyIDAtNC45Mjg2LTkuNjU3NC01LjEwNzctMTMuNjQ0LTguMjEwOS0zLjA3NDktMi4zOTMzLTUuMTAyLTUuMTA3Ny01LjkyNTctOC45MTYzLTEuMDAzMy00LjYzODkgMC44OTAzOS0xMy44NDcgMC44OTAzOS0xMy44NDd6Ii8+PHBhdGggZD0ibTQ4LjEwMSA5Mi44ODdzLTkuMjI0OCA5LjMzODYtOS41ODA4IDE1LjM2M2MtMC4zOTUzNSA2LjY5MTEgNy4yMjU4IDExLjUwNSA4LjU1NjYgMTguMTk3IDAuNDE1MjcgMi4wODg0IDAuNTc0MzIgMy45NTYtMC4yNTA2MyA1LjkxOS0xLjA1NTIgMi41MTEtMy40ODE5IDMuNTc3NC00LjMzNDEgNi4xMDItMC44NzAwNyAyLjU3NzYtMS45MDQxIDUuNTMyOC0wLjU4NTQ5IDguNjE3NiAwLjUwNjM3IDEuMTg0NiAxLjE2NjQgMi41ODMgMS41MDY0IDMuODI1NiAxLjM5ODIgNS4xMTEgMS4zMjAxIDEwLjIyMSAwLjAzNDExIDE1LjYxNy0wLjc0MTggMy4xMTI2LTMuMzc1OCA1LjcwMjgtNC4zODExIDguNzQwNi0wLjY2NDQ0IDIuMDA3Ny0wLjYyMTQ1IDQuMjUzNi0wLjI2ODIgNi4zMzg2IDEuMjg5OCA3LjYxMjggNi41OTEgMTQuMDYgOC41NDczIDIxLjUyOSAwLjg5MzY1IDMuNDEyMS0yLjA3NDggMTAuNDg2IDEuNDE3NSAxMC40ODYgNC41MzE5IDAgNC4yMDI3LTAuMDEzNCA4LjEzNDQtMC4wMTM0IDIuODA4MiAwLTAuMTEwMDMtNS42NDUtMC42NjE5OC04LjM5ODQtMC41NzQ2OC0yLjg2NjktMS4zNjY2LTUuODA3Ni0xLjg1MDMtOC42OTItMC40ODI5OS0yLjg4MDMtMC45NDc3Mi01LjI5MTggMC4yMjQ0OC04LjIzNzggMS4yMTAyLTMuMDQxNSAyLjc4NzgtMi41NzAxIDMuNTAyMS0xLjM2OTIgMi4zNDk3IDMuOTUwMyAyLjczNDcgOS42MzkgMy41ODc0IDEzLjY4MiAwLjE2NzAzIDAuNzkxOTIgMi43MTQ2IDYuNTgwNSAyLjcxNDYgNi41ODA1czAuMDE3MTYgNy44MTA0IDIuNzgwNyA3LjgxMDRoMTIuMTAyYzEuNjY4OCAwIDIuOTk0NS0yLjUwNiAyLjc4MzgtNC4xNjE1LTAuNTA3NjUtMy45ODgyLTkuMDA0MS00LjAwNDUtOS4wMDQxLTguMDI0OCAwLTkuNDAzOC0yLjY2NjMtMTkuOTIyIDAtMjkuODczIDAuNDU0MzMtMS42OTU2IDIuODM0Mi0yLjAzOTUgMy44MDI0LTMuNjQzMiAyLjAxNDgtMy4zMzc0IDAuNjY2MzUtNy43MTQyIDIuNDkyNC0xMS4yNTkgMS4yNzExLTIuNDY3MyAyLjY4NzEtNC41ODg0IDUuNTYzLTUuNzM0NSAzLjYwMTUtMS40MzU0IDcuNjkyOC0xLjI0NTQgMTEuMjQzIDAuMzEzMTYgNy4yNDY4IDMuMTgxNiAxMC45NzUgMTEuODk0IDE3LjM4OSAxNS41MjYgMy40NTg0IDEuOTU4NSA4LjgwNTItMC4yMjIyNCAxMi41IDEuMjQyMyAxLjQ5NTIgMC41OTI2NyAyLjg3NTQgMS4wNDc0IDMuMDI4MiAyLjMwNzQgMC41NjI2OSA0LjY0IDEuMDQ1NiA4LjczOTkgMCAxMi42NDItMC4zMTE5OSAxLjE2NDQtMC42OTQ4MSAwLjk2OTE5LTEuMDE4OSAyLjEzMDItMC44NjQ5NyAzLjA5ODQtMC43NTcwNCA0LjgzNzUtMC4yODQ5MyA3LjYwMTQgMC4xNjk4NyAwLjk5NDQ2IDEuMDA0NyAxLjkyODUgMS4wMDQ3IDIuOTM3NCAwIDcuMDE5NC00LjQ0NTEgMTguNzU2IDEuODE0NCAxOC43NTZoMTQuNDE3YzEuNjMyOSAwIDIuMTU2LTEuMjA3NSAyLjkxMjUtMi42NTQ2IDAuNzMxNjctMS4zOTk2IDAuOTMwMTctNC4yODQyIDAuMTg2MDQtNS42NzcyLTEuNTQ2Ni0yLjg5NTItNi4zODYtMC43Njg0NC03LjEzMzQtMy41NTc5LTIuODk0Mi0xMC44MDEtMC4wMzItMjQuMjU5LTAuMDMyLTM2LjMwOCAwLTUuNzUzMiA4LjE1MDctOC43MDM0IDkuNzgwOC0xNC4yMjEgMS4zODIxLTQuNjc3OSAyLjkwNzctOS44OTg0IDEuNzEtMTQuNTI0bC0yNC41LTI0LjVjLTEuMjExMS0wLjM2Mzc1LTIuNDM2Ny0wLjYzODQyLTMuNjczMi0wLjc5OTk1LTUuMjA5NC0wLjY4MDUzLTE0LjEyIDYuNTc2OS0xNC4xMiA2LjU3NjloLTU0LjUwNWMtMy4xNTI2IDAtNC45Njg5LTEuMjg4OC03LjIwNDktNC4yODI0LTEuNTgxNC0yLjExNzEtMy43NzA4LTYuMzc0Ny0zLjc0ODQtOC43MTI5IDAuMDI2MjEtMi43NDQ4IDIuMjIxMy01LjE2OTYgMy42MDctOC4yMTQ4IDAuNzk2MS0xLjc0OTUtMC4yMDQxMi01Ljk4MzEtMC4yMDQxMi01Ljk4MzF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0.10476190476190478,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="72" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="73" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC45NW1tIiBoZWlnaHQ9IjExOS44bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC45NSAxMTkuOCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQuMTUxIDkwLjgwMi0wLjI0MzkxIDAuMzE5ODh2MjguNjc4aDEzMy4xM3YtMjguNjlsLTAuMjM1MTMtMC4zMDc0N2gtMzkuMTc5YTI5LjE0MyAyOS4wOTEgMCAwIDEtMTkuNzYzIDE3LjYwMSAyOS4xNDYgMjkuNDczIDAgMCAxLTEuMjM5NyAwLjMwOTU0IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDQzIDAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjU5NzMgMC4yMzYxNiAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAwMiAwLjEwMjgzIDI5LjE0NiAyOS40NzMgMCAwIDEtMi41NDQgMC4xMjQ1NCAyOS4xNDYgMjkuNDczIDAgMCAxLTAuMDAyMDY3IDAgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0yLjU0MTQtMC4xMjQ1NCAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAyNzktMC4xMDI4MyAyOS4xNDYgMjkuNDczIDAgMCAxLTEuNTkzNy0wLjIzNjE2IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDc5LTAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjI0NTQtMC4zMTE2MSAyOS4xNDMgMjkuMDkxIDAgMCAxLTE5Ljc1Ni0xNy41OTloLTM5LjE3eiIvPjxwYXRoIGQ9Im01MC4wNTQgNDMuODI1LTM2LjE0NyA0Ny4yOTdoMzkuNTQxYy0xLjM2NDEtMy40MjY1LTIuMDkyNy03LjA4MDgtMi4wOTQyLTEwLjc2OSAyLjAxZS00IC0xNi4wOTggMTMuMDUtMjkuMTQ4IDI5LjE0OS0yOS4xNDggMTYuMDk4IDJlLTQgMjkuMTQ4IDEzLjA1IDI5LjE0OCAyOS4xNDgtMmUtMyAzLjY4ODEtMC43OTM3OSA3LjM0MjMtMi4xNTc5IDEwLjc2OWgzOS41NDFsM2UtNSAtMC4wMTQ5OS0zNi4xMDktNDcuMjgyeiIvPjxyZWN0IHg9IjUyLjIzMiIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxyZWN0IHg9IjkzLjAxNCIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxwYXRoIGQ9Im0wIDUxLjA1OSAzOS40NTgtNS4yNDgydi0xMi4xMzRoLTQuOTAzOHYtMTIuOTk4bDMzLjM4NC0wLjE0ODkzdi0yMC4wMzNzLTI0LjQ0NSAxLjYyMTYtMzUuNjE0IDYuMTM1NmMtOC42MzQxIDMuNDg5Ni0xNi43OTEgOC44NjU4LTIzLjA5NiAxNS43MTktMy44NTU0IDQuMTkwNy04LjQwMzUgMTQuODczLTguNDAzNSAxNC44NzN6Ii8+PHBhdGggZD0ibTE2MC45NSA1MS4wNTktMzkuNDU4LTUuMjQ4MnYtMTIuMTM0aDQuOTAzOHYtMTIuOTk4bC0zMy4zODQtMC4xNDg5M3YtMjAuMDMzczI0LjQ0NSAxLjYyMTYgMzUuNjE0IDYuMTM1NmM4LjYzNDEgMy40ODk2IDE2Ljc5MSA4Ljg2NTggMjMuMDk2IDE1LjcxOSAzLjg1NTQgNC4xOTA3IDguNDAzNiAxNC44NzMgOC40MDM2IDE0Ljg3M3oiLz48cGF0aCBkPSJtMzQuNTU0IDIwLjY3OWg5MS44NDR2LTE0Ljg1NnMtMjIuMTUtNC40MzU4LTMzLjM4NC01LjMyNjJjLTguMzMyNy0wLjY2MDU1LTE2Ljc0NC0wLjY2NTA1LTI1LjA3NyA1ZS02IC0xMS4zMDggMC45MDI1Ni0zMy42MDEgNS4zOTgyLTMzLjYwMSA1LjM5ODJsMC4yMTcyMyAxNC43ODQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="74" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNC4yOW1tIiBoZWlnaHQ9IjE1OC4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjQuMjkgMTU4LjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC44NjcgLTY5LjQxKSI+PHJlY3QgeD0iMTUyLjU3IiB5PSI5NC4yMjUiIHdpZHRoPSIxMS4yNDMiIGhlaWdodD0iMTMzLjE5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxjaXJjbGUgY3g9IjE1OC42NSIgY3k9Ijc5LjkxMSIgcj0iMTAuNTAxIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im0xNDYuMDQgOTMuNzY1djc2LjM0MnMtMjQuNzA4IDAuMjUwNTgtMzYuMTYyIDQuMjY3NWMtMTMuMjcxIDQuNjU0MS0yMi42MDkgMTcuNDU2LTM1LjgwOSAyMi4zMDgtNi4xMjYyIDIuMjUxOC0xMi45OTkgMS40NTE3LTE5LjM2OSAyLjg3NDItMy4zNDA0IDAuNzQ1OTYtOS44MzMgMi45NTY4LTkuODMzIDIuOTU2OHYtNzYuNTY2czI2LjE5Ni0xLjcyOTIgMzcuODgxLTcuMDYxN2M5LjAyMDMtNC4xMTYzIDE0LjIxNy0xNC40OTMgMjMuMjgtMTguNTE2IDEyLjM1NS01LjQ4NDMgNDAuMDExLTYuNjA0OCA0MC4wMTEtNi42MDQ4eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.0903" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="75" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OC4yN21tIiBoZWlnaHQ9IjE0Ni4wNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDguMjcgMTQ2LjA2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMi44MDQgLTc1LjU0OCkiPjxwYXRoIGQ9Im0zMi44MDQgNzUuNTQ4czM1LjAwOSAyLjEyNTkgNTAuOTU1IDE4LjY1NGMxOS4yMDUgMTkuOTA2IDIzLjE4IDU0LjM3NyAyMy4xOCA1NC4zNzdzLTMyLjk5MS0xLjY4MzEtNTMuNDA3LTIxLjcxNmMtMTkuMTEzLTE4Ljc1NS0yMC43MjctNTEuMzE0LTIwLjcyNy01MS4zMTR6Ii8+PHBhdGggZD0ibTE4MS4wNyA3NS41NDhzLTM1LjAwOSAyLjEyNTktNTAuOTU1IDE4LjY1NGMtMTkuMjA1IDE5LjkwNi0yMy4xOCA1NC4zNzctMjMuMTggNTQuMzc3czMyLjk5MS0xLjY4MzEgNTMuNDA3LTIxLjcxNmMxOS4xMTMtMTguNzU1IDIwLjcyNy01MS4zMTQgMjAuNzI3LTUxLjMxNHoiLz48cGF0aCBkPSJtMTgxLjA3IDIyMS42MXMtMzUuMDA5LTIuMTI1OS01MC45NTUtMTguNjU0Yy0xOS4yMDUtMTkuOTA2LTIzLjE4LTU0LjM3Ny0yMy4xOC01NC4zNzdzMzIuOTkxIDEuNjgzMSA1My40MDcgMjEuNzE2YzE5LjExMyAxOC43NTUgMjAuNzI3IDUxLjMxNCAyMC43MjcgNTEuMzE0eiIvPjxwYXRoIGQ9Im0zMi44MDQgMjIxLjYxczM1LjAwOS0yLjEyNTkgNTAuOTU1LTE4LjY1NGMxOS4yMDUtMTkuOTA2IDIzLjE4LTU0LjM3NyAyMy4xOC01NC4zNzdzLTMyLjk5MSAxLjY4MzEtNTMuNDA3IDIxLjcxNmMtMTkuMTEzIDE4Ljc1NS0yMC43MjcgNTEuMzE0LTIwLjcyNyA1MS4zMTR6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="76" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg5LjAwNG1tIiBoZWlnaHQ9IjE2MS4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4OS4wMDQgMTYxLjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxyZWN0IHg9IjE0LjY3NiIgeT0iNTguNzQ4IiB3aWR0aD0iMTYuMTY5IiBoZWlnaHQ9IjEwMi4yNiIgcnk9IjcuMzI5MiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cGF0aCBkPSJtMWUtNiAzNy45ODV2MjAuODMxYzAgNC45MTY3IDMuOTU4MiA4Ljg3NTQgOC44NzQ5IDguODc1NGgyNy43NzJjNC45MTY3IDAgOC44NzQ5LTMuOTU4NyA4Ljg3NDktOC44NzU0di0yMC44MzFoLTguNzg3MWMtMWUtNiA1LjM3ODEtNy4yN2UtNCA5LjcxLTAuMDAxNiA5LjcxaC01LjMyOTljLTMuODdlLTQgMC0wLjAwMTUtNC4zMzE5LTAuMDAxNS05LjcxaC01Ljk3NDNjLTFlLTYgNS4zNzgxLTcuMjdlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc0ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTYtOS43MWgtNS45NzQzYzAgNS4zNzgxLTcuMjVlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc1ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTUtOS43MXoiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iLTQuMTI2ZS03IiB5PSIuMDAyMDciIHdpZHRoPSI4Ljc4ODYiIGhlaWdodD0iNDcuODQyIiByeD0iMCIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMzYuNzMzIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjguNzg4NiIgaGVpZ2h0PSI0Ny44NDIiIHJ4PSIwIiByeT0iMCIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSIxNC4xMTkiIHk9IjIuNDU5ZS02IiB3aWR0aD0iNS45Nzc0IiBoZWlnaHQ9IjQ3LjY5NSIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMjUuNDI2IiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjUuOTc3NCIgaGVpZ2h0PSI0Ny42OTUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjcxLjQ2MSIgeT0iMi40NTllLTYiIHdpZHRoPSIxNy41NDMiIGhlaWdodD0iMTYxLjAxIiByeT0iNy40NDA1IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im03My43OTUgMGMtOC4zNzU0IDAtMTUuMTE4IDYuNjI3Ni0xNS4xMTggMTQuODZ2MjguMThoMzAuMzI3di0yOC4xOGMwLTguMjMyNS02Ljc0MzEtMTQuODYtMTUuMTE4LTE0Ljg2eiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSI1OC42NzciIHk9IjMyLjAyMiIgd2lkdGg9IjMwLjMyNyIgaGVpZ2h0PSI2NS45MzMiIHJ5PSI5LjA5NjkiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iNzMuNzExIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjE1LjI5MyIgaGVpZ2h0PSIyNC40MzUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.0956" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="77" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MG1tIiBoZWlnaHQ9IjE1Ni4ybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MCAxNTYuMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjUuOTIyIC03MC45OCkiPjxnPjxwYXRoIGQ9Im0xNTIgOTQuNzA1LTMzLjIgOTEuMzgzcy0yLjY1MTIgOS4yNjg1IDEuNjc5NSAxOS43OTNjNC4xMTk0IDEwLjAxMSAxNC43OCAyMS4zMDUgMzEuNTIgMjEuMzA1IDE1LjUyIDAgMjYuMjI3LTEwLjA5MiAzMC42MzUtMTkuMjkzIDUuMzQ1OS0xMS4xNTcgMi41NzYxLTIxLjgwNCAyLjU3NjEtMjEuODA0em02ZS0zIDMxLjU5MSAyMy4zNjcgNTkuNzkyaC00Ni43MzR6Ii8+PHBhdGggZD0ibTU5LjkyNSA5NC43MDQtMzMuMiA5MS4zODNzLTIuNjUxMiA5LjI2ODUgMS42Nzk1IDE5Ljc5M2M0LjExOTQgMTAuMDExIDE0Ljc4IDIxLjMwNSAzMS41MiAyMS4zMDUgMTUuNTIgMCAyNi4yMjctMTAuMDkyIDMwLjYzNS0xOS4yOTMgNS4zNDU5LTExLjE1NyAyLjU3NjEtMjEuODA0IDIuNTc2MS0yMS44MDR6bTAuMDA1NyAzMS41OTEgMjMuMzY3IDU5Ljc5MmgtNDYuNzM0eiIvPjxyZWN0IHg9Ijk2LjEwMyIgeT0iNzAuOTgiIHdpZHRoPSIxOS43MTQiIGhlaWdodD0iMjQuOTUzIiByeT0iMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjEuOTQ4IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjU2LjIzNCIgeT0iOTIuMzE0IiB3aWR0aD0iOTkuNDYzIiBoZWlnaHQ9IjEyLjU2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjAuNDM5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48cGF0aCBjbGFzcz0iVW5vcHRpbWljZWRUcmFuc2Zvcm1zIiBkPSJtMCAwIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="78" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE1Ni4xOG1tIiBoZWlnaHQ9IjkwLjY4NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNTYuMTggOTAuNjg1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjE3LjQwMiIgY3k9IjE3LjQwMiIgcj0iMTQuMTg5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utb3BhY2l0eT0iLjk5MDE0IiBzdHJva2Utd2lkdGg9IjYuNDI1IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PGNpcmNsZSBjeD0iMTcuNDAyIiBjeT0iNzMuMjgzIiByPSIxNC4xODkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS1vcGFjaXR5PSIuOTkwMTQiIHN0cm9rZS13aWR0aD0iNi40MjUiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48Zz48cGF0aCBkPSJtMjYuMzA0IDMxLjY4NSA5LjE3OTUtMC40NDkxIDg5LjAyOSAzOS40M2gyOS4wNzFsLTExNi41OC00Ni42ODQtNS40MTE5LTYuNTgwNXoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjYuOSIvPjxwYXRoIGQ9Im0yNi4zMDQgNTkgOS4xNzk1IDAuNDQ5MSA4OS4wMjktMzkuNDNoMjkuMDcxbC0xMTYuNTggNDYuNjg0LTUuNDExOSA2LjU4MDV6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI2LjkiLz48cGF0aCBkPSJtNzUuNDE0IDQ1LjU2MS0xOC42ODUgOC43MTUydi0xNy40M3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="79" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ni4yNG1tIiBoZWlnaHQ9IjEzNi44Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDYuMjQgMTM2LjgyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zOC41MDYgLTc4LjkyOSkiPjxwYXRoIGQ9Im0xNjYuMDIgNzguOTI5cy04LjU0OTggMC43Nzc3OS0xMi4xNSAyLjg2MzljLTUuNzc0NyAzLjM0Ni05LjY3ODUgOS4yNzkzLTEzLjY3NyAxNC42MjMtMi4zNTQ0IDMuMTQ2My01LjU2MjYgOC45MTMyLTcuMzI1MSAxMi4xODJsMjEuNDc2IDIxLjQ3NmMwLjA3MzMtMC4wOTMgMC45MTUzLTAuOTQxOTMgMC4yMDgyNi0wLjI2ODcyIDEuMTM5MS0xLjU0OTYgMC4wMjUxLTUuMDkzNiAyLjg4NjgtNS4yNjE4IDUuNTY5LTAuMzI3MzYgMTMuMzYtMi4yMDkxIDE0LjIwMi0yLjMzOTkgMC44NDI4OC0wLjEzMDg1IDExLjU0NC0xLjYwMzYgMTIuNjYtNS43NjY3IDAuNjQ2MTgtMi40MTE2IDAuMzk5MzktMy40NTU0IDAuMzk5MzktNi41MzMyIDAtNC45Mjg2LTkuNjU3NC01LjEwNzctMTMuNjQ0LTguMjEwOS0zLjA3NDktMi4zOTMzLTUuMTAyLTUuMTA3Ny01LjkyNTctOC45MTYzLTEuMDAzMy00LjYzODkgMC44OTAzOS0xMy44NDcgMC44OTAzOS0xMy44NDd6Ii8+PHBhdGggZD0ibTQ4LjEwMSA5Mi44ODdzLTkuMjI0OCA5LjMzODYtOS41ODA4IDE1LjM2M2MtMC4zOTUzNSA2LjY5MTEgNy4yMjU4IDExLjUwNSA4LjU1NjYgMTguMTk3IDAuNDE1MjcgMi4wODg0IDAuNTc0MzIgMy45NTYtMC4yNTA2MyA1LjkxOS0xLjA1NTIgMi41MTEtMy40ODE5IDMuNTc3NC00LjMzNDEgNi4xMDItMC44NzAwNyAyLjU3NzYtMS45MDQxIDUuNTMyOC0wLjU4NTQ5IDguNjE3NiAwLjUwNjM3IDEuMTg0NiAxLjE2NjQgMi41ODMgMS41MDY0IDMuODI1NiAxLjM5ODIgNS4xMTEgMS4zMjAxIDEwLjIyMSAwLjAzNDExIDE1LjYxNy0wLjc0MTggMy4xMTI2LTMuMzc1OCA1LjcwMjgtNC4zODExIDguNzQwNi0wLjY2NDQ0IDIuMDA3Ny0wLjYyMTQ1IDQuMjUzNi0wLjI2ODIgNi4zMzg2IDEuMjg5OCA3LjYxMjggNi41OTEgMTQuMDYgOC41NDczIDIxLjUyOSAwLjg5MzY1IDMuNDEyMS0yLjA3NDggMTAuNDg2IDEuNDE3NSAxMC40ODYgNC41MzE5IDAgNC4yMDI3LTAuMDEzNCA4LjEzNDQtMC4wMTM0IDIuODA4MiAwLTAuMTEwMDMtNS42NDUtMC42NjE5OC04LjM5ODQtMC41NzQ2OC0yLjg2NjktMS4zNjY2LTUuODA3Ni0xLjg1MDMtOC42OTItMC40ODI5OS0yLjg4MDMtMC45NDc3Mi01LjI5MTggMC4yMjQ0OC04LjIzNzggMS4yMTAyLTMuMDQxNSAyLjc4NzgtMi41NzAxIDMuNTAyMS0xLjM2OTIgMi4zNDk3IDMuOTUwMyAyLjczNDcgOS42MzkgMy41ODc0IDEzLjY4MiAwLjE2NzAzIDAuNzkxOTIgMi43MTQ2IDYuNTgwNSAyLjcxNDYgNi41ODA1czAuMDE3MTYgNy44MTA0IDIuNzgwNyA3LjgxMDRoMTIuMTAyYzEuNjY4OCAwIDIuOTk0NS0yLjUwNiAyLjc4MzgtNC4xNjE1LTAuNTA3NjUtMy45ODgyLTkuMDA0MS00LjAwNDUtOS4wMDQxLTguMDI0OCAwLTkuNDAzOC0yLjY2NjMtMTkuOTIyIDAtMjkuODczIDAuNDU0MzMtMS42OTU2IDIuODM0Mi0yLjAzOTUgMy44MDI0LTMuNjQzMiAyLjAxNDgtMy4zMzc0IDAuNjY2MzUtNy43MTQyIDIuNDkyNC0xMS4yNTkgMS4yNzExLTIuNDY3MyAyLjY4NzEtNC41ODg0IDUuNTYzLTUuNzM0NSAzLjYwMTUtMS40MzU0IDcuNjkyOC0xLjI0NTQgMTEuMjQzIDAuMzEzMTYgNy4yNDY4IDMuMTgxNiAxMC45NzUgMTEuODk0IDE3LjM4OSAxNS41MjYgMy40NTg0IDEuOTU4NSA4LjgwNTItMC4yMjIyNCAxMi41IDEuMjQyMyAxLjQ5NTIgMC41OTI2NyAyLjg3NTQgMS4wNDc0IDMuMDI4MiAyLjMwNzQgMC41NjI2OSA0LjY0IDEuMDQ1NiA4LjczOTkgMCAxMi42NDItMC4zMTE5OSAxLjE2NDQtMC42OTQ4MSAwLjk2OTE5LTEuMDE4OSAyLjEzMDItMC44NjQ5NyAzLjA5ODQtMC43NTcwNCA0LjgzNzUtMC4yODQ5MyA3LjYwMTQgMC4xNjk4NyAwLjk5NDQ2IDEuMDA0NyAxLjkyODUgMS4wMDQ3IDIuOTM3NCAwIDcuMDE5NC00LjQ0NTEgMTguNzU2IDEuODE0NCAxOC43NTZoMTQuNDE3YzEuNjMyOSAwIDIuMTU2LTEuMjA3NSAyLjkxMjUtMi42NTQ2IDAuNzMxNjctMS4zOTk2IDAuOTMwMTctNC4yODQyIDAuMTg2MDQtNS42NzcyLTEuNTQ2Ni0yLjg5NTItNi4zODYtMC43Njg0NC03LjEzMzQtMy41NTc5LTIuODk0Mi0xMC44MDEtMC4wMzItMjQuMjU5LTAuMDMyLTM2LjMwOCAwLTUuNzUzMiA4LjE1MDctOC43MDM0IDkuNzgwOC0xNC4yMjEgMS4zODIxLTQuNjc3OSAyLjkwNzctOS44OTg0IDEuNzEtMTQuNTI0bC0yNC41LTI0LjVjLTEuMjExMS0wLjM2Mzc1LTIuNDM2Ny0wLjYzODQyLTMuNjczMi0wLjc5OTk1LTUuMjA5NC0wLjY4MDUzLTE0LjEyIDYuNTc2OS0xNC4xMiA2LjU3NjloLTU0LjUwNWMtMy4xNTI2IDAtNC45Njg5LTEuMjg4OC03LjIwNDktNC4yODI0LTEuNTgxNC0yLjExNzEtMy43NzA4LTYuMzc0Ny0zLjc0ODQtOC43MTI5IDAuMDI2MjEtMi43NDQ4IDIuMjIxMy01LjE2OTYgMy42MDctOC4yMTQ4IDAuNzk2MS0xLjc0OTUtMC4yMDQxMi01Ljk4MzEtMC4yMDQxMi01Ljk4MzF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0.10476190476190476,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="80" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="81" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC45NW1tIiBoZWlnaHQ9IjExOS44bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC45NSAxMTkuOCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQuMTUxIDkwLjgwMi0wLjI0MzkxIDAuMzE5ODh2MjguNjc4aDEzMy4xM3YtMjguNjlsLTAuMjM1MTMtMC4zMDc0N2gtMzkuMTc5YTI5LjE0MyAyOS4wOTEgMCAwIDEtMTkuNzYzIDE3LjYwMSAyOS4xNDYgMjkuNDczIDAgMCAxLTEuMjM5NyAwLjMwOTU0IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDQzIDAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjU5NzMgMC4yMzYxNiAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAwMiAwLjEwMjgzIDI5LjE0NiAyOS40NzMgMCAwIDEtMi41NDQgMC4xMjQ1NCAyOS4xNDYgMjkuNDczIDAgMCAxLTAuMDAyMDY3IDAgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0yLjU0MTQtMC4xMjQ1NCAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAyNzktMC4xMDI4MyAyOS4xNDYgMjkuNDczIDAgMCAxLTEuNTkzNy0wLjIzNjE2IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDc5LTAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjI0NTQtMC4zMTE2MSAyOS4xNDMgMjkuMDkxIDAgMCAxLTE5Ljc1Ni0xNy41OTloLTM5LjE3eiIvPjxwYXRoIGQ9Im01MC4wNTQgNDMuODI1LTM2LjE0NyA0Ny4yOTdoMzkuNTQxYy0xLjM2NDEtMy40MjY1LTIuMDkyNy03LjA4MDgtMi4wOTQyLTEwLjc2OSAyLjAxZS00IC0xNi4wOTggMTMuMDUtMjkuMTQ4IDI5LjE0OS0yOS4xNDggMTYuMDk4IDJlLTQgMjkuMTQ4IDEzLjA1IDI5LjE0OCAyOS4xNDgtMmUtMyAzLjY4ODEtMC43OTM3OSA3LjM0MjMtMi4xNTc5IDEwLjc2OWgzOS41NDFsM2UtNSAtMC4wMTQ5OS0zNi4xMDktNDcuMjgyeiIvPjxyZWN0IHg9IjUyLjIzMiIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxyZWN0IHg9IjkzLjAxNCIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxwYXRoIGQ9Im0wIDUxLjA1OSAzOS40NTgtNS4yNDgydi0xMi4xMzRoLTQuOTAzOHYtMTIuOTk4bDMzLjM4NC0wLjE0ODkzdi0yMC4wMzNzLTI0LjQ0NSAxLjYyMTYtMzUuNjE0IDYuMTM1NmMtOC42MzQxIDMuNDg5Ni0xNi43OTEgOC44NjU4LTIzLjA5NiAxNS43MTktMy44NTU0IDQuMTkwNy04LjQwMzUgMTQuODczLTguNDAzNSAxNC44NzN6Ii8+PHBhdGggZD0ibTE2MC45NSA1MS4wNTktMzkuNDU4LTUuMjQ4MnYtMTIuMTM0aDQuOTAzOHYtMTIuOTk4bC0zMy4zODQtMC4xNDg5M3YtMjAuMDMzczI0LjQ0NSAxLjYyMTYgMzUuNjE0IDYuMTM1NmM4LjYzNDEgMy40ODk2IDE2Ljc5MSA4Ljg2NTggMjMuMDk2IDE1LjcxOSAzLjg1NTQgNC4xOTA3IDguNDAzNiAxNC44NzMgOC40MDM2IDE0Ljg3M3oiLz48cGF0aCBkPSJtMzQuNTU0IDIwLjY3OWg5MS44NDR2LTE0Ljg1NnMtMjIuMTUtNC40MzU4LTMzLjM4NC01LjMyNjJjLTguMzMyNy0wLjY2MDU1LTE2Ljc0NC0wLjY2NTA1LTI1LjA3NyA1ZS02IC0xMS4zMDggMC45MDI1Ni0zMy42MDEgNS4zOTgyLTMzLjYwMSA1LjM5ODJsMC4yMTcyMyAxNC43ODQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="82" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNC4yOW1tIiBoZWlnaHQ9IjE1OC4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjQuMjkgMTU4LjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC44NjcgLTY5LjQxKSI+PHJlY3QgeD0iMTUyLjU3IiB5PSI5NC4yMjUiIHdpZHRoPSIxMS4yNDMiIGhlaWdodD0iMTMzLjE5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxjaXJjbGUgY3g9IjE1OC42NSIgY3k9Ijc5LjkxMSIgcj0iMTAuNTAxIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im0xNDYuMDQgOTMuNzY1djc2LjM0MnMtMjQuNzA4IDAuMjUwNTgtMzYuMTYyIDQuMjY3NWMtMTMuMjcxIDQuNjU0MS0yMi42MDkgMTcuNDU2LTM1LjgwOSAyMi4zMDgtNi4xMjYyIDIuMjUxOC0xMi45OTkgMS40NTE3LTE5LjM2OSAyLjg3NDItMy4zNDA0IDAuNzQ1OTYtOS44MzMgMi45NTY4LTkuODMzIDIuOTU2OHYtNzYuNTY2czI2LjE5Ni0xLjcyOTIgMzcuODgxLTcuMDYxN2M5LjAyMDMtNC4xMTYzIDE0LjIxNy0xNC40OTMgMjMuMjgtMTguNTE2IDEyLjM1NS01LjQ4NDMgNDAuMDExLTYuNjA0OCA0MC4wMTEtNi42MDQ4eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28508" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="83" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OC4yN21tIiBoZWlnaHQ9IjE0Ni4wNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDguMjcgMTQ2LjA2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMi44MDQgLTc1LjU0OCkiPjxwYXRoIGQ9Im0zMi44MDQgNzUuNTQ4czM1LjAwOSAyLjEyNTkgNTAuOTU1IDE4LjY1NGMxOS4yMDUgMTkuOTA2IDIzLjE4IDU0LjM3NyAyMy4xOCA1NC4zNzdzLTMyLjk5MS0xLjY4MzEtNTMuNDA3LTIxLjcxNmMtMTkuMTEzLTE4Ljc1NS0yMC43MjctNTEuMzE0LTIwLjcyNy01MS4zMTR6Ii8+PHBhdGggZD0ibTE4MS4wNyA3NS41NDhzLTM1LjAwOSAyLjEyNTktNTAuOTU1IDE4LjY1NGMtMTkuMjA1IDE5LjkwNi0yMy4xOCA1NC4zNzctMjMuMTggNTQuMzc3czMyLjk5MS0xLjY4MzEgNTMuNDA3LTIxLjcxNmMxOS4xMTMtMTguNzU1IDIwLjcyNy01MS4zMTQgMjAuNzI3LTUxLjMxNHoiLz48cGF0aCBkPSJtMTgxLjA3IDIyMS42MXMtMzUuMDA5LTIuMTI1OS01MC45NTUtMTguNjU0Yy0xOS4yMDUtMTkuOTA2LTIzLjE4LTU0LjM3Ny0yMy4xOC01NC4zNzdzMzIuOTkxIDEuNjgzMSA1My40MDcgMjEuNzE2YzE5LjExMyAxOC43NTUgMjAuNzI3IDUxLjMxNCAyMC43MjcgNTEuMzE0eiIvPjxwYXRoIGQ9Im0zMi44MDQgMjIxLjYxczM1LjAwOS0yLjEyNTkgNTAuOTU1LTE4LjY1NGMxOS4yMDUtMTkuOTA2IDIzLjE4LTU0LjM3NyAyMy4xOC01NC4zNzdzLTMyLjk5MSAxLjY4MzEtNTMuNDA3IDIxLjcxNmMtMTkuMTEzIDE4Ljc1NS0yMC43MjcgNTEuMzE0LTIwLjcyNyA1MS4zMTR6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="84" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg5LjAwNG1tIiBoZWlnaHQ9IjE2MS4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4OS4wMDQgMTYxLjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxyZWN0IHg9IjE0LjY3NiIgeT0iNTguNzQ4IiB3aWR0aD0iMTYuMTY5IiBoZWlnaHQ9IjEwMi4yNiIgcnk9IjcuMzI5MiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cGF0aCBkPSJtMWUtNiAzNy45ODV2MjAuODMxYzAgNC45MTY3IDMuOTU4MiA4Ljg3NTQgOC44NzQ5IDguODc1NGgyNy43NzJjNC45MTY3IDAgOC44NzQ5LTMuOTU4NyA4Ljg3NDktOC44NzU0di0yMC44MzFoLTguNzg3MWMtMWUtNiA1LjM3ODEtNy4yN2UtNCA5LjcxLTAuMDAxNiA5LjcxaC01LjMyOTljLTMuODdlLTQgMC0wLjAwMTUtNC4zMzE5LTAuMDAxNS05LjcxaC01Ljk3NDNjLTFlLTYgNS4zNzgxLTcuMjdlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc0ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTYtOS43MWgtNS45NzQzYzAgNS4zNzgxLTcuMjVlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc1ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTUtOS43MXoiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iLTQuMTI2ZS03IiB5PSIuMDAyMDciIHdpZHRoPSI4Ljc4ODYiIGhlaWdodD0iNDcuODQyIiByeD0iMCIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMzYuNzMzIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjguNzg4NiIgaGVpZ2h0PSI0Ny44NDIiIHJ4PSIwIiByeT0iMCIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSIxNC4xMTkiIHk9IjIuNDU5ZS02IiB3aWR0aD0iNS45Nzc0IiBoZWlnaHQ9IjQ3LjY5NSIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMjUuNDI2IiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjUuOTc3NCIgaGVpZ2h0PSI0Ny42OTUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjcxLjQ2MSIgeT0iMi40NTllLTYiIHdpZHRoPSIxNy41NDMiIGhlaWdodD0iMTYxLjAxIiByeT0iNy40NDA1IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im03My43OTUgMGMtOC4zNzU0IDAtMTUuMTE4IDYuNjI3Ni0xNS4xMTggMTQuODZ2MjguMThoMzAuMzI3di0yOC4xOGMwLTguMjMyNS02Ljc0MzEtMTQuODYtMTUuMTE4LTE0Ljg2eiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSI1OC42NzciIHk9IjMyLjAyMiIgd2lkdGg9IjMwLjMyNyIgaGVpZ2h0PSI2NS45MzMiIHJ5PSI5LjA5NjkiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iNzMuNzExIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjE1LjI5MyIgaGVpZ2h0PSIyNC40MzUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.0956" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="85" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MG1tIiBoZWlnaHQ9IjE1Ni4ybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MCAxNTYuMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjUuOTIyIC03MC45OCkiPjxnPjxwYXRoIGQ9Im0xNTIgOTQuNzA1LTMzLjIgOTEuMzgzcy0yLjY1MTIgOS4yNjg1IDEuNjc5NSAxOS43OTNjNC4xMTk0IDEwLjAxMSAxNC43OCAyMS4zMDUgMzEuNTIgMjEuMzA1IDE1LjUyIDAgMjYuMjI3LTEwLjA5MiAzMC42MzUtMTkuMjkzIDUuMzQ1OS0xMS4xNTcgMi41NzYxLTIxLjgwNCAyLjU3NjEtMjEuODA0em02ZS0zIDMxLjU5MSAyMy4zNjcgNTkuNzkyaC00Ni43MzR6Ii8+PHBhdGggZD0ibTU5LjkyNSA5NC43MDQtMzMuMiA5MS4zODNzLTIuNjUxMiA5LjI2ODUgMS42Nzk1IDE5Ljc5M2M0LjExOTQgMTAuMDExIDE0Ljc4IDIxLjMwNSAzMS41MiAyMS4zMDUgMTUuNTIgMCAyNi4yMjctMTAuMDkyIDMwLjYzNS0xOS4yOTMgNS4zNDU5LTExLjE1NyAyLjU3NjEtMjEuODA0IDIuNTc2MS0yMS44MDR6bTAuMDA1NyAzMS41OTEgMjMuMzY3IDU5Ljc5MmgtNDYuNzM0eiIvPjxyZWN0IHg9Ijk2LjEwMyIgeT0iNzAuOTgiIHdpZHRoPSIxOS43MTQiIGhlaWdodD0iMjQuOTUzIiByeT0iMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjEuOTQ4IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjU2LjIzNCIgeT0iOTIuMzE0IiB3aWR0aD0iOTkuNDYzIiBoZWlnaHQ9IjEyLjU2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjAuNDM5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48cGF0aCBjbGFzcz0iVW5vcHRpbWljZWRUcmFuc2Zvcm1zIiBkPSJtMCAwIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="86" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE1Ni4xOG1tIiBoZWlnaHQ9IjkwLjY4NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNTYuMTggOTAuNjg1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjE3LjQwMiIgY3k9IjE3LjQwMiIgcj0iMTQuMTg5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utb3BhY2l0eT0iLjk5MDE0IiBzdHJva2Utd2lkdGg9IjYuNDI1IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PGNpcmNsZSBjeD0iMTcuNDAyIiBjeT0iNzMuMjgzIiByPSIxNC4xODkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS1vcGFjaXR5PSIuOTkwMTQiIHN0cm9rZS13aWR0aD0iNi40MjUiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48Zz48cGF0aCBkPSJtMjYuMzA0IDMxLjY4NSA5LjE3OTUtMC40NDkxIDg5LjAyOSAzOS40M2gyOS4wNzFsLTExNi41OC00Ni42ODQtNS40MTE5LTYuNTgwNXoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjYuOSIvPjxwYXRoIGQ9Im0yNi4zMDQgNTkgOS4xNzk1IDAuNDQ5MSA4OS4wMjktMzkuNDNoMjkuMDcxbC0xMTYuNTggNDYuNjg0LTUuNDExOSA2LjU4MDV6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI2LjkiLz48cGF0aCBkPSJtNzUuNDE0IDQ1LjU2MS0xOC42ODUgOC43MTUydi0xNy40M3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="87" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ni4yNG1tIiBoZWlnaHQ9IjEzNi44Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDYuMjQgMTM2LjgyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zOC41MDYgLTc4LjkyOSkiPjxwYXRoIGQ9Im0xNjYuMDIgNzguOTI5cy04LjU0OTggMC43Nzc3OS0xMi4xNSAyLjg2MzljLTUuNzc0NyAzLjM0Ni05LjY3ODUgOS4yNzkzLTEzLjY3NyAxNC42MjMtMi4zNTQ0IDMuMTQ2My01LjU2MjYgOC45MTMyLTcuMzI1MSAxMi4xODJsMjEuNDc2IDIxLjQ3NmMwLjA3MzMtMC4wOTMgMC45MTUzLTAuOTQxOTMgMC4yMDgyNi0wLjI2ODcyIDEuMTM5MS0xLjU0OTYgMC4wMjUxLTUuMDkzNiAyLjg4NjgtNS4yNjE4IDUuNTY5LTAuMzI3MzYgMTMuMzYtMi4yMDkxIDE0LjIwMi0yLjMzOTkgMC44NDI4OC0wLjEzMDg1IDExLjU0NC0xLjYwMzYgMTIuNjYtNS43NjY3IDAuNjQ2MTgtMi40MTE2IDAuMzk5MzktMy40NTU0IDAuMzk5MzktNi41MzMyIDAtNC45Mjg2LTkuNjU3NC01LjEwNzctMTMuNjQ0LTguMjEwOS0zLjA3NDktMi4zOTMzLTUuMTAyLTUuMTA3Ny01LjkyNTctOC45MTYzLTEuMDAzMy00LjYzODkgMC44OTAzOS0xMy44NDcgMC44OTAzOS0xMy44NDd6Ii8+PHBhdGggZD0ibTQ4LjEwMSA5Mi44ODdzLTkuMjI0OCA5LjMzODYtOS41ODA4IDE1LjM2M2MtMC4zOTUzNSA2LjY5MTEgNy4yMjU4IDExLjUwNSA4LjU1NjYgMTguMTk3IDAuNDE1MjcgMi4wODg0IDAuNTc0MzIgMy45NTYtMC4yNTA2MyA1LjkxOS0xLjA1NTIgMi41MTEtMy40ODE5IDMuNTc3NC00LjMzNDEgNi4xMDItMC44NzAwNyAyLjU3NzYtMS45MDQxIDUuNTMyOC0wLjU4NTQ5IDguNjE3NiAwLjUwNjM3IDEuMTg0NiAxLjE2NjQgMi41ODMgMS41MDY0IDMuODI1NiAxLjM5ODIgNS4xMTEgMS4zMjAxIDEwLjIyMSAwLjAzNDExIDE1LjYxNy0wLjc0MTggMy4xMTI2LTMuMzc1OCA1LjcwMjgtNC4zODExIDguNzQwNi0wLjY2NDQ0IDIuMDA3Ny0wLjYyMTQ1IDQuMjUzNi0wLjI2ODIgNi4zMzg2IDEuMjg5OCA3LjYxMjggNi41OTEgMTQuMDYgOC41NDczIDIxLjUyOSAwLjg5MzY1IDMuNDEyMS0yLjA3NDggMTAuNDg2IDEuNDE3NSAxMC40ODYgNC41MzE5IDAgNC4yMDI3LTAuMDEzNCA4LjEzNDQtMC4wMTM0IDIuODA4MiAwLTAuMTEwMDMtNS42NDUtMC42NjE5OC04LjM5ODQtMC41NzQ2OC0yLjg2NjktMS4zNjY2LTUuODA3Ni0xLjg1MDMtOC42OTItMC40ODI5OS0yLjg4MDMtMC45NDc3Mi01LjI5MTggMC4yMjQ0OC04LjIzNzggMS4yMTAyLTMuMDQxNSAyLjc4NzgtMi41NzAxIDMuNTAyMS0xLjM2OTIgMi4zNDk3IDMuOTUwMyAyLjczNDcgOS42MzkgMy41ODc0IDEzLjY4MiAwLjE2NzAzIDAuNzkxOTIgMi43MTQ2IDYuNTgwNSAyLjcxNDYgNi41ODA1czAuMDE3MTYgNy44MTA0IDIuNzgwNyA3LjgxMDRoMTIuMTAyYzEuNjY4OCAwIDIuOTk0NS0yLjUwNiAyLjc4MzgtNC4xNjE1LTAuNTA3NjUtMy45ODgyLTkuMDA0MS00LjAwNDUtOS4wMDQxLTguMDI0OCAwLTkuNDAzOC0yLjY2NjMtMTkuOTIyIDAtMjkuODczIDAuNDU0MzMtMS42OTU2IDIuODM0Mi0yLjAzOTUgMy44MDI0LTMuNjQzMiAyLjAxNDgtMy4zMzc0IDAuNjY2MzUtNy43MTQyIDIuNDkyNC0xMS4yNTkgMS4yNzExLTIuNDY3MyAyLjY4NzEtNC41ODg0IDUuNTYzLTUuNzM0NSAzLjYwMTUtMS40MzU0IDcuNjkyOC0xLjI0NTQgMTEuMjQzIDAuMzEzMTYgNy4yNDY4IDMuMTgxNiAxMC45NzUgMTEuODk0IDE3LjM4OSAxNS41MjYgMy40NTg0IDEuOTU4NSA4LjgwNTItMC4yMjIyNCAxMi41IDEuMjQyMyAxLjQ5NTIgMC41OTI2NyAyLjg3NTQgMS4wNDc0IDMuMDI4MiAyLjMwNzQgMC41NjI2OSA0LjY0IDEuMDQ1NiA4LjczOTkgMCAxMi42NDItMC4zMTE5OSAxLjE2NDQtMC42OTQ4MSAwLjk2OTE5LTEuMDE4OSAyLjEzMDItMC44NjQ5NyAzLjA5ODQtMC43NTcwNCA0LjgzNzUtMC4yODQ5MyA3LjYwMTQgMC4xNjk4NyAwLjk5NDQ2IDEuMDA0NyAxLjkyODUgMS4wMDQ3IDIuOTM3NCAwIDcuMDE5NC00LjQ0NTEgMTguNzU2IDEuODE0NCAxOC43NTZoMTQuNDE3YzEuNjMyOSAwIDIuMTU2LTEuMjA3NSAyLjkxMjUtMi42NTQ2IDAuNzMxNjctMS4zOTk2IDAuOTMwMTctNC4yODQyIDAuMTg2MDQtNS42NzcyLTEuNTQ2Ni0yLjg5NTItNi4zODYtMC43Njg0NC03LjEzMzQtMy41NTc5LTIuODk0Mi0xMC44MDEtMC4wMzItMjQuMjU5LTAuMDMyLTM2LjMwOCAwLTUuNzUzMiA4LjE1MDctOC43MDM0IDkuNzgwOC0xNC4yMjEgMS4zODIxLTQuNjc3OSAyLjkwNzctOS44OTg0IDEuNzEtMTQuNTI0bC0yNC41LTI0LjVjLTEuMjExMS0wLjM2Mzc1LTIuNDM2Ny0wLjYzODQyLTMuNjczMi0wLjc5OTk1LTUuMjA5NC0wLjY4MDUzLTE0LjEyIDYuNTc2OS0xNC4xMiA2LjU3NjloLTU0LjUwNWMtMy4xNTI2IDAtNC45Njg5LTEuMjg4OC03LjIwNDktNC4yODI0LTEuNTgxNC0yLjExNzEtMy43NzA4LTYuMzc0Ny0zLjc0ODQtOC43MTI5IDAuMDI2MjEtMi43NDQ4IDIuMjIxMy01LjE2OTYgMy42MDctOC4yMTQ4IDAuNzk2MS0xLjc0OTUtMC4yMDQxMi01Ljk4MzEtMC4yMDQxMi01Ljk4MzF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0.10476190476190476,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="88" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="231,113,72,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="89" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC45NW1tIiBoZWlnaHQ9IjExOS44bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC45NSAxMTkuOCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQuMTUxIDkwLjgwMi0wLjI0MzkxIDAuMzE5ODh2MjguNjc4aDEzMy4xM3YtMjguNjlsLTAuMjM1MTMtMC4zMDc0N2gtMzkuMTc5YTI5LjE0MyAyOS4wOTEgMCAwIDEtMTkuNzYzIDE3LjYwMSAyOS4xNDYgMjkuNDczIDAgMCAxLTEuMjM5NyAwLjMwOTU0IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDQzIDAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjU5NzMgMC4yMzYxNiAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAwMiAwLjEwMjgzIDI5LjE0NiAyOS40NzMgMCAwIDEtMi41NDQgMC4xMjQ1NCAyOS4xNDYgMjkuNDczIDAgMCAxLTAuMDAyMDY3IDAgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0yLjU0MTQtMC4xMjQ1NCAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAyNzktMC4xMDI4MyAyOS4xNDYgMjkuNDczIDAgMCAxLTEuNTkzNy0wLjIzNjE2IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDc5LTAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjI0NTQtMC4zMTE2MSAyOS4xNDMgMjkuMDkxIDAgMCAxLTE5Ljc1Ni0xNy41OTloLTM5LjE3eiIvPjxwYXRoIGQ9Im01MC4wNTQgNDMuODI1LTM2LjE0NyA0Ny4yOTdoMzkuNTQxYy0xLjM2NDEtMy40MjY1LTIuMDkyNy03LjA4MDgtMi4wOTQyLTEwLjc2OSAyLjAxZS00IC0xNi4wOTggMTMuMDUtMjkuMTQ4IDI5LjE0OS0yOS4xNDggMTYuMDk4IDJlLTQgMjkuMTQ4IDEzLjA1IDI5LjE0OCAyOS4xNDgtMmUtMyAzLjY4ODEtMC43OTM3OSA3LjM0MjMtMi4xNTc5IDEwLjc2OWgzOS41NDFsM2UtNSAtMC4wMTQ5OS0zNi4xMDktNDcuMjgyeiIvPjxyZWN0IHg9IjUyLjIzMiIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxyZWN0IHg9IjkzLjAxNCIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxwYXRoIGQ9Im0wIDUxLjA1OSAzOS40NTgtNS4yNDgydi0xMi4xMzRoLTQuOTAzOHYtMTIuOTk4bDMzLjM4NC0wLjE0ODkzdi0yMC4wMzNzLTI0LjQ0NSAxLjYyMTYtMzUuNjE0IDYuMTM1NmMtOC42MzQxIDMuNDg5Ni0xNi43OTEgOC44NjU4LTIzLjA5NiAxNS43MTktMy44NTU0IDQuMTkwNy04LjQwMzUgMTQuODczLTguNDAzNSAxNC44NzN6Ii8+PHBhdGggZD0ibTE2MC45NSA1MS4wNTktMzkuNDU4LTUuMjQ4MnYtMTIuMTM0aDQuOTAzOHYtMTIuOTk4bC0zMy4zODQtMC4xNDg5M3YtMjAuMDMzczI0LjQ0NSAxLjYyMTYgMzUuNjE0IDYuMTM1NmM4LjYzNDEgMy40ODk2IDE2Ljc5MSA4Ljg2NTggMjMuMDk2IDE1LjcxOSAzLjg1NTQgNC4xOTA3IDguNDAzNiAxNC44NzMgOC40MDM2IDE0Ljg3M3oiLz48cGF0aCBkPSJtMzQuNTU0IDIwLjY3OWg5MS44NDR2LTE0Ljg1NnMtMjIuMTUtNC40MzU4LTMzLjM4NC01LjMyNjJjLTguMzMyNy0wLjY2MDU1LTE2Ljc0NC0wLjY2NTA1LTI1LjA3NyA1ZS02IC0xMS4zMDggMC45MDI1Ni0zMy42MDEgNS4zOTgyLTMzLjYwMSA1LjM5ODJsMC4yMTcyMyAxNC43ODQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.44762" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC45NW1tIiBoZWlnaHQ9IjExOS44bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC45NSAxMTkuOCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQuMTUxIDkwLjgwMi0wLjI0MzkxIDAuMzE5ODh2MjguNjc4aDEzMy4xM3YtMjguNjlsLTAuMjM1MTMtMC4zMDc0N2gtMzkuMTc5YTI5LjE0MyAyOS4wOTEgMCAwIDEtMTkuNzYzIDE3LjYwMSAyOS4xNDYgMjkuNDczIDAgMCAxLTEuMjM5NyAwLjMwOTU0IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDQzIDAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjU5NzMgMC4yMzYxNiAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAwMiAwLjEwMjgzIDI5LjE0NiAyOS40NzMgMCAwIDEtMi41NDQgMC4xMjQ1NCAyOS4xNDYgMjkuNDczIDAgMCAxLTAuMDAyMDY3IDAgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0yLjU0MTQtMC4xMjQ1NCAyOS4xNDMgMjkuMDkxIDAgMCAxLTAuOTAyNzktMC4xMDI4MyAyOS4xNDYgMjkuNDczIDAgMCAxLTEuNTkzNy0wLjIzNjE2IDI5LjE0MyAyOS4wOTEgMCAwIDEtMS4xMDc5LTAuMjEwODQgMjkuMTQ2IDI5LjQ3MyAwIDAgMS0xLjI0NTQtMC4zMTE2MSAyOS4xNDMgMjkuMDkxIDAgMCAxLTE5Ljc1Ni0xNy41OTloLTM5LjE3eiIvPjxwYXRoIGQ9Im01MC4wNTQgNDMuODI1LTM2LjE0NyA0Ny4yOTdoMzkuNTQxYy0xLjM2NDEtMy40MjY1LTIuMDkyNy03LjA4MDgtMi4wOTQyLTEwLjc2OSAyLjAxZS00IC0xNi4wOTggMTMuMDUtMjkuMTQ4IDI5LjE0OS0yOS4xNDggMTYuMDk4IDJlLTQgMjkuMTQ4IDEzLjA1IDI5LjE0OCAyOS4xNDgtMmUtMyAzLjY4ODEtMC43OTM3OSA3LjM0MjMtMi4xNTc5IDEwLjc2OWgzOS41NDFsM2UtNSAtMC4wMTQ5OS0zNi4xMDktNDcuMjgyeiIvPjxyZWN0IHg9IjUyLjIzMiIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxyZWN0IHg9IjkzLjAxNCIgeT0iMjAuNTY1IiB3aWR0aD0iMTUuNzA2IiBoZWlnaHQ9IjI4LjA3MSIvPjxwYXRoIGQ9Im0wIDUxLjA1OSAzOS40NTgtNS4yNDgydi0xMi4xMzRoLTQuOTAzOHYtMTIuOTk4bDMzLjM4NC0wLjE0ODkzdi0yMC4wMzNzLTI0LjQ0NSAxLjYyMTYtMzUuNjE0IDYuMTM1NmMtOC42MzQxIDMuNDg5Ni0xNi43OTEgOC44NjU4LTIzLjA5NiAxNS43MTktMy44NTU0IDQuMTkwNy04LjQwMzUgMTQuODczLTguNDAzNSAxNC44NzN6Ii8+PHBhdGggZD0ibTE2MC45NSA1MS4wNTktMzkuNDU4LTUuMjQ4MnYtMTIuMTM0aDQuOTAzOHYtMTIuOTk4bC0zMy4zODQtMC4xNDg5M3YtMjAuMDMzczI0LjQ0NSAxLjYyMTYgMzUuNjE0IDYuMTM1NmM4LjYzNDEgMy40ODk2IDE2Ljc5MSA4Ljg2NTggMjMuMDk2IDE1LjcxOSAzLjg1NTQgNC4xOTA3IDguNDAzNiAxNC44NzMgOC40MDM2IDE0Ljg3M3oiLz48cGF0aCBkPSJtMzQuNTU0IDIwLjY3OWg5MS44NDR2LTE0Ljg1NnMtMjIuMTUtNC40MzU4LTMzLjM4NC01LjMyNjJjLTguMzMyNy0wLjY2MDU1LTE2Ljc0NC0wLjY2NTA1LTI1LjA3NyA1ZS02IC0xMS4zMDggMC45MDI1Ni0zMy42MDEgNS4zOTgyLTMzLjYwMSA1LjM5ODJsMC4yMTcyMyAxNC43ODQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="90" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyNC4yOW1tIiBoZWlnaHQ9IjE1OC4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMjQuMjkgMTU4LjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00NC44NjcgLTY5LjQxKSI+PHJlY3QgeD0iMTUyLjU3IiB5PSI5NC4yMjUiIHdpZHRoPSIxMS4yNDMiIGhlaWdodD0iMTMzLjE5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxjaXJjbGUgY3g9IjE1OC42NSIgY3k9Ijc5LjkxMSIgcj0iMTAuNTAxIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im0xNDYuMDQgOTMuNzY1djc2LjM0MnMtMjQuNzA4IDAuMjUwNTgtMzYuMTYyIDQuMjY3NWMtMTMuMjcxIDQuNjU0MS0yMi42MDkgMTcuNDU2LTM1LjgwOSAyMi4zMDgtNi4xMjYyIDIuMjUxOC0xMi45OTkgMS40NTE3LTE5LjM2OSAyLjg3NDItMy4zNDA0IDAuNzQ1OTYtOS44MzMgMi45NTY4LTkuODMzIDIuOTU2OHYtNzYuNTY2czI2LjE5Ni0xLjcyOTIgMzcuODgxLTcuMDYxN2M5LjAyMDMtNC4xMTYzIDE0LjIxNy0xNC40OTMgMjMuMjgtMTguNTE2IDEyLjM1NS01LjQ4NDMgNDAuMDExLTYuNjA0OCA0MC4wMTEtNi42MDQ4eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.0903" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="91" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OC4yN21tIiBoZWlnaHQ9IjE0Ni4wNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDguMjcgMTQ2LjA2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMi44MDQgLTc1LjU0OCkiPjxwYXRoIGQ9Im0zMi44MDQgNzUuNTQ4czM1LjAwOSAyLjEyNTkgNTAuOTU1IDE4LjY1NGMxOS4yMDUgMTkuOTA2IDIzLjE4IDU0LjM3NyAyMy4xOCA1NC4zNzdzLTMyLjk5MS0xLjY4MzEtNTMuNDA3LTIxLjcxNmMtMTkuMTEzLTE4Ljc1NS0yMC43MjctNTEuMzE0LTIwLjcyNy01MS4zMTR6Ii8+PHBhdGggZD0ibTE4MS4wNyA3NS41NDhzLTM1LjAwOSAyLjEyNTktNTAuOTU1IDE4LjY1NGMtMTkuMjA1IDE5LjkwNi0yMy4xOCA1NC4zNzctMjMuMTggNTQuMzc3czMyLjk5MS0xLjY4MzEgNTMuNDA3LTIxLjcxNmMxOS4xMTMtMTguNzU1IDIwLjcyNy01MS4zMTQgMjAuNzI3LTUxLjMxNHoiLz48cGF0aCBkPSJtMTgxLjA3IDIyMS42MXMtMzUuMDA5LTIuMTI1OS01MC45NTUtMTguNjU0Yy0xOS4yMDUtMTkuOTA2LTIzLjE4LTU0LjM3Ny0yMy4xOC01NC4zNzdzMzIuOTkxIDEuNjgzMSA1My40MDcgMjEuNzE2YzE5LjExMyAxOC43NTUgMjAuNzI3IDUxLjMxNCAyMC43MjcgNTEuMzE0eiIvPjxwYXRoIGQ9Im0zMi44MDQgMjIxLjYxczM1LjAwOS0yLjEyNTkgNTAuOTU1LTE4LjY1NGMxOS4yMDUtMTkuOTA2IDIzLjE4LTU0LjM3NyAyMy4xOC01NC4zNzdzLTMyLjk5MSAxLjY4MzEtNTMuNDA3IDIxLjcxNmMtMTkuMTEzIDE4Ljc1NS0yMC43MjcgNTEuMzE0LTIwLjcyNyA1MS4zMTR6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="92" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg5LjAwNG1tIiBoZWlnaHQ9IjE2MS4wMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4OS4wMDQgMTYxLjAxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxyZWN0IHg9IjE0LjY3NiIgeT0iNTguNzQ4IiB3aWR0aD0iMTYuMTY5IiBoZWlnaHQ9IjEwMi4yNiIgcnk9IjcuMzI5MiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cGF0aCBkPSJtMWUtNiAzNy45ODV2MjAuODMxYzAgNC45MTY3IDMuOTU4MiA4Ljg3NTQgOC44NzQ5IDguODc1NGgyNy43NzJjNC45MTY3IDAgOC44NzQ5LTMuOTU4NyA4Ljg3NDktOC44NzU0di0yMC44MzFoLTguNzg3MWMtMWUtNiA1LjM3ODEtNy4yN2UtNCA5LjcxLTAuMDAxNiA5LjcxaC01LjMyOTljLTMuODdlLTQgMC0wLjAwMTUtNC4zMzE5LTAuMDAxNS05LjcxaC01Ljk3NDNjLTFlLTYgNS4zNzgxLTcuMjdlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc0ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTYtOS43MWgtNS45NzQzYzAgNS4zNzgxLTcuMjVlLTQgOS43MS0wLjAwMTYgOS43MWgtNS4zMjk5Yy03Ljc1ZS00IDAtMC4wMDE1LTQuMzMxOS0wLjAwMTUtOS43MXoiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iLTQuMTI2ZS03IiB5PSIuMDAyMDciIHdpZHRoPSI4Ljc4ODYiIGhlaWdodD0iNDcuODQyIiByeD0iMCIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMzYuNzMzIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjguNzg4NiIgaGVpZ2h0PSI0Ny44NDIiIHJ4PSIwIiByeT0iMCIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSIxNC4xMTkiIHk9IjIuNDU5ZS02IiB3aWR0aD0iNS45Nzc0IiBoZWlnaHQ9IjQ3LjY5NSIgcnk9IjAiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iMjUuNDI2IiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjUuOTc3NCIgaGVpZ2h0PSI0Ny42OTUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjcxLjQ2MSIgeT0iMi40NTllLTYiIHdpZHRoPSIxNy41NDMiIGhlaWdodD0iMTYxLjAxIiByeT0iNy40NDA1IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxwYXRoIGQ9Im03My43OTUgMGMtOC4zNzU0IDAtMTUuMTE4IDYuNjI3Ni0xNS4xMTggMTQuODZ2MjguMThoMzAuMzI3di0yOC4xOGMwLTguMjMyNS02Ljc0MzEtMTQuODYtMTUuMTE4LTE0Ljg2eiIgc3R5bGU9InBhaW50LW9yZGVyOnN0cm9rZSBmaWxsIG1hcmtlcnMiLz48cmVjdCB4PSI1OC42NzciIHk9IjMyLjAyMiIgd2lkdGg9IjMwLjMyNyIgaGVpZ2h0PSI2NS45MzMiIHJ5PSI5LjA5NjkiIHN0eWxlPSJwYWludC1vcmRlcjpzdHJva2UgZmlsbCBtYXJrZXJzIi8+PHJlY3QgeD0iNzMuNzExIiB5PSIyLjQ1OWUtNiIgd2lkdGg9IjE1LjI5MyIgaGVpZ2h0PSIyNC40MzUiIHJ5PSIwIiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.0956" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="93" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MG1tIiBoZWlnaHQ9IjE1Ni4ybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MCAxNTYuMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjUuOTIyIC03MC45OCkiPjxnPjxwYXRoIGQ9Im0xNTIgOTQuNzA1LTMzLjIgOTEuMzgzcy0yLjY1MTIgOS4yNjg1IDEuNjc5NSAxOS43OTNjNC4xMTk0IDEwLjAxMSAxNC43OCAyMS4zMDUgMzEuNTIgMjEuMzA1IDE1LjUyIDAgMjYuMjI3LTEwLjA5MiAzMC42MzUtMTkuMjkzIDUuMzQ1OS0xMS4xNTcgMi41NzYxLTIxLjgwNCAyLjU3NjEtMjEuODA0em02ZS0zIDMxLjU5MSAyMy4zNjcgNTkuNzkyaC00Ni43MzR6Ii8+PHBhdGggZD0ibTU5LjkyNSA5NC43MDQtMzMuMiA5MS4zODNzLTIuNjUxMiA5LjI2ODUgMS42Nzk1IDE5Ljc5M2M0LjExOTQgMTAuMDExIDE0Ljc4IDIxLjMwNSAzMS41MiAyMS4zMDUgMTUuNTIgMCAyNi4yMjctMTAuMDkyIDMwLjYzNS0xOS4yOTMgNS4zNDU5LTExLjE1NyAyLjU3NjEtMjEuODA0IDIuNTc2MS0yMS44MDR6bTAuMDA1NyAzMS41OTEgMjMuMzY3IDU5Ljc5MmgtNDYuNzM0eiIvPjxyZWN0IHg9Ijk2LjEwMyIgeT0iNzAuOTgiIHdpZHRoPSIxOS43MTQiIGhlaWdodD0iMjQuOTUzIiByeT0iMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjEuOTQ4IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjxyZWN0IHg9IjU2LjIzNCIgeT0iOTIuMzE0IiB3aWR0aD0iOTkuNDYzIiBoZWlnaHQ9IjEyLjU2NCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS13aWR0aD0iMjAuNDM5IiBzdHlsZT0icGFpbnQtb3JkZXI6c3Ryb2tlIGZpbGwgbWFya2VycyIvPjwvZz48cGF0aCBjbGFzcz0iVW5vcHRpbWljZWRUcmFuc2Zvcm1zIiBkPSJtMCAwIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="94" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE1Ni4xOG1tIiBoZWlnaHQ9IjkwLjY4NW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNTYuMTggOTAuNjg1IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjE3LjQwMiIgY3k9IjE3LjQwMiIgcj0iMTQuMTg5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utb3BhY2l0eT0iLjk5MDE0IiBzdHJva2Utd2lkdGg9IjYuNDI1IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PGNpcmNsZSBjeD0iMTcuNDAyIiBjeT0iNzMuMjgzIiByPSIxNC4xODkiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjAiIHN0cm9rZS1vcGFjaXR5PSIuOTkwMTQiIHN0cm9rZS13aWR0aD0iNi40MjUiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48Zz48cGF0aCBkPSJtMjYuMzA0IDMxLjY4NSA5LjE3OTUtMC40NDkxIDg5LjAyOSAzOS40M2gyOS4wNzFsLTExNi41OC00Ni42ODQtNS40MTE5LTYuNTgwNXoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjYuOSIvPjxwYXRoIGQ9Im0yNi4zMDQgNTkgOS4xNzk1IDAuNDQ5MSA4OS4wMjktMzkuNDNoMjkuMDcxbC0xMTYuNTggNDYuNjg0LTUuNDExOSA2LjU4MDV6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI2LjkiLz48cGF0aCBkPSJtNzUuNDE0IDQ1LjU2MS0xOC42ODUgOC43MTUydi0xNy40M3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="95" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ni4yNG1tIiBoZWlnaHQ9IjEzNi44Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDYuMjQgMTM2LjgyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zOC41MDYgLTc4LjkyOSkiPjxwYXRoIGQ9Im0xNjYuMDIgNzguOTI5cy04LjU0OTggMC43Nzc3OS0xMi4xNSAyLjg2MzljLTUuNzc0NyAzLjM0Ni05LjY3ODUgOS4yNzkzLTEzLjY3NyAxNC42MjMtMi4zNTQ0IDMuMTQ2My01LjU2MjYgOC45MTMyLTcuMzI1MSAxMi4xODJsMjEuNDc2IDIxLjQ3NmMwLjA3MzMtMC4wOTMgMC45MTUzLTAuOTQxOTMgMC4yMDgyNi0wLjI2ODcyIDEuMTM5MS0xLjU0OTYgMC4wMjUxLTUuMDkzNiAyLjg4NjgtNS4yNjE4IDUuNTY5LTAuMzI3MzYgMTMuMzYtMi4yMDkxIDE0LjIwMi0yLjMzOTkgMC44NDI4OC0wLjEzMDg1IDExLjU0NC0xLjYwMzYgMTIuNjYtNS43NjY3IDAuNjQ2MTgtMi40MTE2IDAuMzk5MzktMy40NTU0IDAuMzk5MzktNi41MzMyIDAtNC45Mjg2LTkuNjU3NC01LjEwNzctMTMuNjQ0LTguMjEwOS0zLjA3NDktMi4zOTMzLTUuMTAyLTUuMTA3Ny01LjkyNTctOC45MTYzLTEuMDAzMy00LjYzODkgMC44OTAzOS0xMy44NDcgMC44OTAzOS0xMy44NDd6Ii8+PHBhdGggZD0ibTQ4LjEwMSA5Mi44ODdzLTkuMjI0OCA5LjMzODYtOS41ODA4IDE1LjM2M2MtMC4zOTUzNSA2LjY5MTEgNy4yMjU4IDExLjUwNSA4LjU1NjYgMTguMTk3IDAuNDE1MjcgMi4wODg0IDAuNTc0MzIgMy45NTYtMC4yNTA2MyA1LjkxOS0xLjA1NTIgMi41MTEtMy40ODE5IDMuNTc3NC00LjMzNDEgNi4xMDItMC44NzAwNyAyLjU3NzYtMS45MDQxIDUuNTMyOC0wLjU4NTQ5IDguNjE3NiAwLjUwNjM3IDEuMTg0NiAxLjE2NjQgMi41ODMgMS41MDY0IDMuODI1NiAxLjM5ODIgNS4xMTEgMS4zMjAxIDEwLjIyMSAwLjAzNDExIDE1LjYxNy0wLjc0MTggMy4xMTI2LTMuMzc1OCA1LjcwMjgtNC4zODExIDguNzQwNi0wLjY2NDQ0IDIuMDA3Ny0wLjYyMTQ1IDQuMjUzNi0wLjI2ODIgNi4zMzg2IDEuMjg5OCA3LjYxMjggNi41OTEgMTQuMDYgOC41NDczIDIxLjUyOSAwLjg5MzY1IDMuNDEyMS0yLjA3NDggMTAuNDg2IDEuNDE3NSAxMC40ODYgNC41MzE5IDAgNC4yMDI3LTAuMDEzNCA4LjEzNDQtMC4wMTM0IDIuODA4MiAwLTAuMTEwMDMtNS42NDUtMC42NjE5OC04LjM5ODQtMC41NzQ2OC0yLjg2NjktMS4zNjY2LTUuODA3Ni0xLjg1MDMtOC42OTItMC40ODI5OS0yLjg4MDMtMC45NDc3Mi01LjI5MTggMC4yMjQ0OC04LjIzNzggMS4yMTAyLTMuMDQxNSAyLjc4NzgtMi41NzAxIDMuNTAyMS0xLjM2OTIgMi4zNDk3IDMuOTUwMyAyLjczNDcgOS42MzkgMy41ODc0IDEzLjY4MiAwLjE2NzAzIDAuNzkxOTIgMi43MTQ2IDYuNTgwNSAyLjcxNDYgNi41ODA1czAuMDE3MTYgNy44MTA0IDIuNzgwNyA3LjgxMDRoMTIuMTAyYzEuNjY4OCAwIDIuOTk0NS0yLjUwNiAyLjc4MzgtNC4xNjE1LTAuNTA3NjUtMy45ODgyLTkuMDA0MS00LjAwNDUtOS4wMDQxLTguMDI0OCAwLTkuNDAzOC0yLjY2NjMtMTkuOTIyIDAtMjkuODczIDAuNDU0MzMtMS42OTU2IDIuODM0Mi0yLjAzOTUgMy44MDI0LTMuNjQzMiAyLjAxNDgtMy4zMzc0IDAuNjY2MzUtNy43MTQyIDIuNDkyNC0xMS4yNTkgMS4yNzExLTIuNDY3MyAyLjY4NzEtNC41ODg0IDUuNTYzLTUuNzM0NSAzLjYwMTUtMS40MzU0IDcuNjkyOC0xLjI0NTQgMTEuMjQzIDAuMzEzMTYgNy4yNDY4IDMuMTgxNiAxMC45NzUgMTEuODk0IDE3LjM4OSAxNS41MjYgMy40NTg0IDEuOTU4NSA4LjgwNTItMC4yMjIyNCAxMi41IDEuMjQyMyAxLjQ5NTIgMC41OTI2NyAyLjg3NTQgMS4wNDc0IDMuMDI4MiAyLjMwNzQgMC41NjI2OSA0LjY0IDEuMDQ1NiA4LjczOTkgMCAxMi42NDItMC4zMTE5OSAxLjE2NDQtMC42OTQ4MSAwLjk2OTE5LTEuMDE4OSAyLjEzMDItMC44NjQ5NyAzLjA5ODQtMC43NTcwNCA0LjgzNzUtMC4yODQ5MyA3LjYwMTQgMC4xNjk4NyAwLjk5NDQ2IDEuMDA0NyAxLjkyODUgMS4wMDQ3IDIuOTM3NCAwIDcuMDE5NC00LjQ0NTEgMTguNzU2IDEuODE0NCAxOC43NTZoMTQuNDE3YzEuNjMyOSAwIDIuMTU2LTEuMjA3NSAyLjkxMjUtMi42NTQ2IDAuNzMxNjctMS4zOTk2IDAuOTMwMTctNC4yODQyIDAuMTg2MDQtNS42NzcyLTEuNTQ2Ni0yLjg5NTItNi4zODYtMC43Njg0NC03LjEzMzQtMy41NTc5LTIuODk0Mi0xMC44MDEtMC4wMzItMjQuMjU5LTAuMDMyLTM2LjMwOCAwLTUuNzUzMiA4LjE1MDctOC43MDM0IDkuNzgwOC0xNC4yMjEgMS4zODIxLTQuNjc3OSAyLjkwNzctOS44OTg0IDEuNzEtMTQuNTI0bC0yNC41LTI0LjVjLTEuMjExMS0wLjM2Mzc1LTIuNDM2Ny0wLjYzODQyLTMuNjczMi0wLjc5OTk1LTUuMjA5NC0wLjY4MDUzLTE0LjEyIDYuNTc2OS0xNC4xMiA2LjU3NjloLTU0LjUwNWMtMy4xNTI2IDAtNC45Njg5LTEuMjg4OC03LjIwNDktNC4yODI0LTEuNTgxNC0yLjExNzEtMy43NzA4LTYuMzc0Ny0zLjc0ODQtOC43MTI5IDAuMDI2MjEtMi43NDQ4IDIuMjIxMy01LjE2OTYgMy42MDctOC4yMTQ4IDAuNzk2MS0xLjc0OTUtMC4yMDQxMi01Ljk4MzEtMC4yMDQxMi01Ljk4MzF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0.10476190476190476,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Административное здание" value="602010801" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объект проведения гражданских обрядов" value="602010802" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объект религиозной организации (объединения)" value="602010803" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты торговли, общественного питания" value="602010804" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Непроизводственный объект по предоставлению населению государственных, правовых, финансовых, консультационных и иных подобных услуг" value="602010805" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Непроизводственные объекты коммунально-бытового обслуживания и предоставления персональных услуг" value="602010806" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Ветеринарная лечебница, питомник животных, кинологический центр, приют для животных, иной подобный объект" value="602010807" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="AB_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Государственный орган законодательной, исполнительной власти Российской Федерации, его территориальный орган" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Государственный орган законодательной, исполнительной власти субъекта Российской Федерации" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Орган местного самоуправления муниципального района, городского округа, поселения, городского округа с внутригородским делением, внутригородского района, внутригородской территории (внутригородского муниципального образования)" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Суды" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Полиция" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Следственный комитет" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Прокуратура" value="9" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CR_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Дома и дворцы бракосочетаний, отделы записи актов гражданского состояния" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Бюро похоронного обслуживания, дом траурных обрядов" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной объект проведения гражданских обрядов" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="TRD_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Магазин, торгово-развлекательный комплекс, магазин кулинарии" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Рыночный комплекс" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объект общественного питания" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Розничный рынок, ярмарка" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной объект торговли, общественного питания" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="RS_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Многофункциональный центр предоставления государственных и муниципальных услуг" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Отделение, филиал банка, кредитно-финансовой организации, страховой компании" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Юридическая консультация, нотариальная контора" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Центр занятости населения, биржа труда, бюро по трудоустройству" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной непроизводственный объект по предоставлению населению государственных, правовых, финансовых, консультационных и иных подобных услуг" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="PU_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Объект непосредственного бытового обслуживания" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объект коммунального обслуживания (прачечные, химчистки, бани, парикмахерские)" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Жилищно-эксплуатационная организация" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Пункт приема вторичного сырья" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной непроизводственный объект коммунально-бытового обслуживания и предоставления персональных услуг" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="BLD_AREA" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="TRD_AREA" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="TRD_COUNT" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CAPACITY" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="WRK_COUNT" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FUNCTION" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к ликвидации" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTROKS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTRZU" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="AB_STYPE" index="6" name=""/>
    <alias field="CR_STYPE" index="7" name=""/>
    <alias field="TRD_STYPE" index="8" name=""/>
    <alias field="RS_STYPE" index="9" name=""/>
    <alias field="PU_STYPE" index="10" name=""/>
    <alias field="BLD_AREA" index="11" name="Общая площадь здания, комплекса зданий, кв. м"/>
    <alias field="TRD_AREA" index="12" name=""/>
    <alias field="TRD_COUNT" index="13" name=""/>
    <alias field="CAPACITY" index="14" name="Количество посадочных мест объекта общественного питания, единиц"/>
    <alias field="WRK_COUNT" index="15" name="Количество рабочих (операционных) мест, единиц"/>
    <alias field="FUNCTION" index="16" name="Назначение объекта"/>
    <alias field="EVENT_TIME" index="17" name=""/>
    <alias field="SOURCE" index="18" name="Источник данных"/>
    <alias field="NOTE" index="19" name="Примечание"/>
    <alias field="STATUS" index="20" name="Статус объекта"/>
    <alias field="REG_STATUS" index="21" name="Значение объекта"/>
    <alias field="KADASTROKS" index="22" name="Кадастровый номер объекта капитального строительства"/>
    <alias field="KADASTRZU" index="23" name=""/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602010801'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="AB_STYPE" expression="if(&quot;CLASSID&quot; = '602010801', attribute('AB_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="CR_STYPE" expression="if(&quot;CLASSID&quot; = '602010802', attribute('CR_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="TRD_STYPE" expression="if(&quot;CLASSID&quot; = '602010804', attribute('TRD_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="RS_STYPE" expression="if(&quot;CLASSID&quot; = '602010805', attribute('RS_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="PU_STYPE" expression="if(&quot;CLASSID&quot; = '602010806', attribute('PU_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="BLD_AREA" expression="0" applyOnUpdate="0"/>
    <default field="TRD_AREA" expression="0" applyOnUpdate="0"/>
    <default field="TRD_COUNT" expression="0" applyOnUpdate="0"/>
    <default field="CAPACITY" expression="0" applyOnUpdate="0"/>
    <default field="WRK_COUNT" expression="0" applyOnUpdate="0"/>
    <default field="FUNCTION" expression="''" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
    <default field="KADASTROKS" expression="''" applyOnUpdate="0"/>
    <default field="KADASTRZU" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="AB_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="CR_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="TRD_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="RS_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="PU_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="BLD_AREA" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="TRD_AREA" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="TRD_COUNT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="CAPACITY" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="WRK_COUNT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FUNCTION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="2" field="KADASTROKS" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="KADASTRZU" unique_strength="0" notnull_strength="0" constraints="4"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="AB_STYPE" desc="Заполняется для объекта 602010801" exp="if(&quot;CLASSID&quot; = '602010801', &quot;AB_STYPE&quot; IS NOT NULL, &quot;AB_STYPE&quot; IS NULL)"/>
    <constraint field="CR_STYPE" desc="Заполняется для объекта 602010802" exp="if(&quot;CLASSID&quot; = '602010802', &quot;CR_STYPE&quot; IS NOT NULL, &quot;CR_STYPE&quot; IS NULL)"/>
    <constraint field="TRD_STYPE" desc="Заполняется для объекта 602010804" exp="if(&quot;CLASSID&quot; = '602010804', &quot;TRD_STYPE&quot; IS NOT NULL, &quot;TRD_STYPE&quot; IS NULL)"/>
    <constraint field="RS_STYPE" desc="Заполняется для объекта 602010805" exp="if(&quot;CLASSID&quot; = '602010805', &quot;RS_STYPE&quot; IS NOT NULL, &quot;RS_STYPE&quot; IS NULL)"/>
    <constraint field="PU_STYPE" desc="Заполняется для объекта 602010806" exp="if(&quot;CLASSID&quot; = '602010806', &quot;PU_STYPE&quot; IS NOT NULL, &quot;PU_STYPE&quot; IS NULL)"/>
    <constraint field="BLD_AREA" desc="" exp=""/>
    <constraint field="TRD_AREA" desc="" exp=""/>
    <constraint field="TRD_COUNT" desc="" exp=""/>
    <constraint field="CAPACITY" desc="Заполняется для объекта 3 справочника TRD_STYPE" exp="if (&quot;CLASSID&quot; = '602010804' AND &quot;TRD_STYPE&quot; = 3,&#xa;&#x9;&quot;CAPACITY&quot; > 0,&#xa;&#x9;&quot;CAPACITY&quot; >= 0)"/>
    <constraint field="WRK_COUNT" desc="" exp=""/>
    <constraint field="FUNCTION" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
    <constraint field="KADASTROKS" desc="Формат кадастрового номера, принятый в ЕГРН" exp="regexp_match(&quot;KADASTROKS&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$')"/>
    <constraint field="KADASTRZU" desc="Обязательно для значений атрибута &quot;STATUS&quot; 1, 3, 4" exp="if (&quot;STATUS&quot; = 1 OR &quot;STATUS&quot; = 3 OR &quot;STATUS&quot; = 4,&#xa;&#x9;regexp_match(&quot;KADASTRZU&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$|^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1})$'),&#xa;&#x9;length(&quot;KADASTRZU&quot;) >= 0)"/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="20" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="21" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="11" name="BLD_AREA">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="15" name="WRK_COUNT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="16" name="FUNCTION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="18" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="19" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="22" name="KADASTROKS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип административного здания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010801'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="6" name="AB_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип объекта проведения гражданских обрядов" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010802'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="7" name="CR_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип объекта торговли, общественного питания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010804'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="8" name="TRD_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Торговая площадь, кв. м" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010804'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="12" name="TRD_AREA">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Количество торговых мест рыночного комплекса, единиц" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010804' AND &quot;TRD_STYPE&quot; = 2">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="13" name="TRD_COUNT">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Количество посадочных мест объекта общественного питания, единиц" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010804' AND &quot;TRD_STYPE&quot; = 3">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="14" name="CAPACITY">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип непроизводственного объекта по предоставлению населению государственных, правовых, финансовых, консультационных и иных подобных услуг" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010805'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="9" name="RS_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип непроизводственного объекта коммунально-бытового обслуживания и предоставления персональных услуг" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010806'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="10" name="PU_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="17" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Кадастровый номер земельного участка и (или) номер кадастрового квартала, в границах которого расположен объект" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (1, 3, 4)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="23" name="KADASTRZU">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="AB_STYPE" editable="1"/>
    <field name="ADDRESS" editable="1"/>
    <field name="BLD_AREA" editable="1"/>
    <field name="CAPACITY" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="CR_STYPE" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="FUNCTION" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="KADASTROKS" editable="1"/>
    <field name="KADASTRZU" editable="1"/>
    <field name="NAME" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="PU_STYPE" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="RS_STYPE" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="TRD_AREA" editable="1"/>
    <field name="TRD_COUNT" editable="1"/>
    <field name="TRD_STYPE" editable="1"/>
    <field name="WRK_COUNT" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="AB_STYPE"/>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="BLD_AREA"/>
    <field labelOnTop="1" name="CAPACITY"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="CR_STYPE"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="FUNCTION"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="KADASTROKS"/>
    <field labelOnTop="1" name="KADASTRZU"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="PU_STYPE"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="RS_STYPE"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS"/>
    <field labelOnTop="1" name="TRD_AREA"/>
    <field labelOnTop="1" name="TRD_COUNT"/>
    <field labelOnTop="1" name="TRD_STYPE"/>
    <field labelOnTop="1" name="WRK_COUNT"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="AB_STYPE" reuseLastValue="0"/>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="BLD_AREA" reuseLastValue="0"/>
    <field name="CAPACITY" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="CR_STYPE" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="FUNCTION" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="KADASTROKS" reuseLastValue="0"/>
    <field name="KADASTRZU" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="PU_STYPE" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="RS_STYPE" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="TRD_AREA" reuseLastValue="0"/>
    <field name="TRD_COUNT" reuseLastValue="0"/>
    <field name="TRD_STYPE" reuseLastValue="0"/>
    <field name="WRK_COUNT" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
