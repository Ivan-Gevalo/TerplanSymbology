<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{0848332f-9dfc-4d5d-86bc-294a505c3582}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{1d0a96db-b531-472a-a970-a36c2779ca4d}">
        <rule label="Объект культурно-просветительного назначения" filter="&quot;CLASSID&quot; = '602010201'" symbol="1" key="{19f1b753-f663-4e59-9c49-7a23143aa208}"/>
        <rule label="Объект культурно-досугового (клубного) типа" filter="&quot;CLASSID&quot; = '602010202'" symbol="2" key="{93fc8d59-c81b-4888-90eb-1223d239b34f}"/>
        <rule label="Зрелищная организация" filter="&quot;CLASSID&quot; = '602010203'" symbol="3" key="{4b263505-1e12-49b0-a366-cb159aa46bd3}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="4" key="{68cdaecc-012e-4471-87e8-aa75f2dfc9f1}">
        <rule label="Объект культурно-просветительного назначения" filter="&quot;CLASSID&quot; = '602010201'" symbol="5" key="{28b8cdd2-09b6-45fa-9bdf-44e2702e24bc}"/>
        <rule label="Объект культурно-досугового (клубного) типа" filter="&quot;CLASSID&quot; = '602010202'" symbol="6" key="{89510739-533a-49ee-875d-27210c1c21a0}"/>
        <rule label="Зрелищная организация" filter="&quot;CLASSID&quot; = '602010203'" symbol="7" key="{d4d657b3-0f01-4186-bfa7-8976ddbebfe8}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="8" key="{644eaed9-9bf1-4fe9-9d88-899fa8bf6f75}">
        <rule label="Объект культурно-просветительного назначения" filter="&quot;CLASSID&quot; = '602010201'" symbol="9" key="{44d136bb-1697-435c-bc4e-fb94a2fcf025}"/>
        <rule label="Объект культурно-досугового (клубного) типа" filter="&quot;CLASSID&quot; = '602010202'" symbol="10" key="{38463f5e-e5ce-489f-bd72-6af6d6fedc00}"/>
        <rule label="Зрелищная организация" filter="&quot;CLASSID&quot; = '602010203'" symbol="11" key="{e89ee147-5afd-441a-a4b9-b02c33477f4d}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="12" key="{52e3b788-7577-4c72-a07e-72bdaa544927}">
        <rule label="Объект культурно-просветительного назначения" filter="&quot;CLASSID&quot; = '602010201'" symbol="13" key="{cd2b3f5d-0422-41d7-acaf-b833856051c3}"/>
        <rule label="Объект культурно-досугового (клубного) типа" filter="&quot;CLASSID&quot; = '602010202'" symbol="14" key="{83d3d15f-9f03-43dd-9fec-a69732d7bf14}"/>
        <rule label="Зрелищная организация" filter="&quot;CLASSID&quot; = '602010203'" symbol="15" key="{dca4638b-03e7-4856-b348-c26e7a4e6f95}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регинального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="16" key="{08a24bb2-d432-4668-8bc9-b2b21afa05bf}">
        <rule label="Объект культурно-просветительного назначения" filter="&quot;CLASSID&quot; = '602010201'" symbol="17" key="{8b55e37e-5d3c-4ec8-9aa3-9b6b810449ad}"/>
        <rule label="Объект культурно-досугового (клубного) типа" filter="&quot;CLASSID&quot; = '602010202'" symbol="18" key="{49ada12f-b54c-4ba8-b38e-5de5acdcd2f2}"/>
        <rule label="Зрелищная организация" filter="&quot;CLASSID&quot; = '602010203'" symbol="19" key="{879d20c7-aa77-40a3-9540-75a6c27b70b6}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="20" key="{f8c2243e-a491-4939-8d6b-f49d521235b0}">
        <rule label="Объект культурно-просветительного назначения" filter="&quot;CLASSID&quot; = '602010201'" symbol="21" key="{1d8736ed-c144-4b76-906a-b94e56426af4}"/>
        <rule label="Объект культурно-досугового (клубного) типа" filter="&quot;CLASSID&quot; = '602010202'" symbol="22" key="{06b3c8e2-58ee-46f6-8a95-e89624ffdd22}"/>
        <rule label="Зрелищная организация" filter="&quot;CLASSID&quot; = '602010203'" symbol="23" key="{7ea70bad-e668-492c-b48d-6531c6162489}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="24" key="{a6ef5afc-f1c7-46ed-b2f7-2d2528c80074}">
        <rule label="Объект культурно-просветительного назначения" filter="&quot;CLASSID&quot; = '602010201'" symbol="25" key="{c101928f-5483-4a8b-a26e-e5dee897e716}"/>
        <rule label="Объект культурно-досугового (клубного) типа" filter="&quot;CLASSID&quot; = '602010202'" symbol="26" key="{2b17217e-932c-49cd-a78a-d0e7f73fad7b}"/>
        <rule label="Зрелищная организация" filter="&quot;CLASSID&quot; = '602010203'" symbol="27" key="{1b68de55-96d2-403f-8788-168ce8885737}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты регионального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 2" symbol="28" key="{a729fcc7-097c-4c9d-8dd8-9ed9413001a5}">
        <rule label="Объект культурно-просветительного назначения" filter="&quot;CLASSID&quot; = '602010201'" symbol="29" key="{e0b6ae40-5dee-48d3-b32a-cc9da41725d5}"/>
        <rule label="Объект культурно-досугового (клубного) типа" filter="&quot;CLASSID&quot; = '602010202'" symbol="30" key="{cab3f5c7-9007-4326-90b9-5d63045f2e0b}"/>
        <rule label="Зрелищная организация" filter="&quot;CLASSID&quot; = '602010203'" symbol="31" key="{cf2b8002-a425-42d9-92d6-b819fe083276}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="32" key="{9931abd3-9837-4bd3-8f75-2ba8e2797a97}">
        <rule label="Объект культурно-просветительного назначения" filter="&quot;CLASSID&quot; = '602010201'" symbol="33" key="{d2ac45f6-6532-481c-a8db-300bb2c06c31}"/>
        <rule label="Объект культурно-досугового (клубного) типа" filter="&quot;CLASSID&quot; = '602010202'" symbol="34" key="{5139cd9c-3d78-4706-babe-3cf7961fa4bb}"/>
        <rule label="Зрелищная организация" filter="&quot;CLASSID&quot; = '602010203'" symbol="35" key="{c283e2df-9b02-419a-940a-f1b5e943991c}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="36" key="{9f9ea5a6-e961-4d2e-a0f7-3f8e72e2faa8}">
        <rule label="Объект культурно-просветительного назначения" filter="&quot;CLASSID&quot; = '602010201'" symbol="37" key="{77b14fe0-b373-4972-8445-557497c4f8f9}"/>
        <rule label="Объект культурно-досугового (клубного) типа" filter="&quot;CLASSID&quot; = '602010202'" symbol="38" key="{f5e9a98f-b20e-40fc-af44-779730a07de1}"/>
        <rule label="Зрелищная организация" filter="&quot;CLASSID&quot; = '602010203'" symbol="39" key="{f840350f-e927-49be-8fdf-d5b50050a2a4}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="40" key="{9de42ab5-760f-45f1-8176-3660de1d95ef}">
        <rule label="Объект культурно-просветительного назначения" filter="&quot;CLASSID&quot; = '602010201'" symbol="41" key="{fc3802a3-d634-4e73-b581-b99edc64304d}"/>
        <rule label="Объект культурно-досугового (клубного) типа" filter="&quot;CLASSID&quot; = '602010202'" symbol="42" key="{d18adbfc-6319-4971-9090-6800a75ddf63}"/>
        <rule label="Зрелищная организация" filter="&quot;CLASSID&quot; = '602010203'" symbol="43" key="{5df8cc0e-b0ae-4e73-bcde-2bb148efdd13}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты федерального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 1" symbol="44" key="{ca5eb6e3-96b5-4b17-b5a4-1170f8d64a07}">
        <rule label="Объект культурно-просветительного назначения" filter="&quot;CLASSID&quot; = '602010201'" symbol="45" key="{beb7d48a-e1b2-42ed-9341-322b098b7757}"/>
        <rule label="Объект культурно-досугового (клубного) типа" filter="&quot;CLASSID&quot; = '602010202'" symbol="46" key="{d23c7eb7-824e-4d19-90bf-de5ac74b25ba}"/>
        <rule label="Зрелищная организация" filter="&quot;CLASSID&quot; = '602010203'" symbol="47" key="{0c049e49-4ad4-4cb0-88c5-37acc8ad21e0}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="152,125,183,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTU2LjQ4bW0iIGhlaWdodD0iMjkxLjI4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1Ni40OCAyOTEuMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYuMDI0IC0zLjE0MDQpIj4KICA8cGF0aCBkPSJtNjMuMjE3IDI4NC42MnYtOS43OTgyaDE5Ljg1OGwwLjA5NTgtMS4yMjQ4YzAuMjQ2MjQtMy4xNDg5IDAuNTM5OTMtOS42NzY4IDAuNjI2MTYtMTMuOTE4IDAuMjA3LTEwLjE4MS0wLjY2NDk3LTE3LjMzNS0yLjg5NzctMjMuNzczLTEuODI4Ni01LjI3MjctNS40MjI0LTEyLjEwOC0xMC45ODQtMjAuODkzLTE1LjY0LTI0LjcwMi0yMy44MTYtMzkuNDY5LTMwLjI1OC01NC42NTItNy41MjctMTcuNzQtMTEuODYxLTM1LjE1NC0xMy4zNTUtNTMuNjY4LTAuMzY5NTYtNC41NzgyLTAuMzcxNjktMTQuODUyLTRlLTMgLTE4Ljg1NCAyLjAzNTYtMjIuMTQ5IDkuNDg4My0zMy4zMzggMjYuNDA5LTM5LjY0OCA1LjAxNzEtMS44NzEgMTEuMDQ4LTMuMzA4NyAyMC42MDMtNC45MTE4bDQuMjI5Ni0wLjcwOTYgMS4wNTQ0LTEuMDQ0MmMxLjU5MjgtMS41NzczIDIuMzI2Ni0zLjM0MjIgMi43MTgxLTYuNTM3MSAwLjE5OTg2LTEuNjMwOSAwLjIxMjA4LTQuODE2OCAwLjAxOTctNS4xMjEyLTAuMTIyMDYtMC4xOTMwNy0xLjU5NDEtMC4yMjkxMy0xMS4yODEtMC4yNzYzbC0xMS4xNC0wLjA1NDI1di0yNi4zOTNoOTAuNzA4djI2LjM5M2wtMTEuMTQgMC4wNTQyNWMtOS42ODY1IDAuMDQ3MTctMTEuMTU4IDAuMDgzMjItMTEuMjgxIDAuMjc2My0wLjE5MjQzIDAuMzA0MzktMC4xODAyIDMuNDkwMyAwLjAxOTYgNS4xMjEyIDAuMzkxNTMgMy4xOTUgMS4xMjU0IDQuOTU5OCAyLjcxODEgNi41MzcxbDEuMDU0NCAxLjA0NDIgNC4yMjk2IDAuNzA5NmM3LjU3MzUgMS4yNzA2IDEyLjQgMi4zMTkzIDE2Ljg5MiAzLjY3MDIgNS45NDgxIDEuNzg4OSAxMS4xNTEgNC4yODU0IDE0LjkzNCA3LjE2NjEgOS4xMzM0IDYuOTU0MyAxMy42NDcgMTYuOTc5IDE1LjE4NiAzMy43MjQgMC4zNjc4MSA0LjAwMiAwLjM2NTY5IDE0LjI3Ni00ZS0zIDE4Ljg1NC0xLjQ5NDQgMTguNTEzLTUuODI4IDM1LjkyOC0xMy4zNTUgNTMuNjY4LTYuNDQyMiAxNS4xODMtMTQuNjE4IDI5Ljk1LTMwLjI1OCA1NC42NTItNS41NjIgOC43ODQ4LTkuMTU1OCAxNS42Mi0xMC45ODQgMjAuODkzLTIuMjMyNyA2LjQzOC0zLjEwNDcgMTMuNTkyLTIuODk3NyAyMy43NzMgMC4wODYyIDQuMjQxMiAwLjM3OTkyIDEwLjc2OSAwLjYyNjE2IDEzLjkxOGwwLjA5NTggMS4yMjQ4aDE5Ljg1OHYxOS41OTZoLTgyLjA5N3YtOS43OTgyeiIgc3Ryb2tlLXdpZHRoPSIuMTQ4NDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.79352" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3LjQzbW0iIGhlaWdodD0iMjAzLjA5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy40MyAyMDMuMDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMS40Nzk2IC0zNy41NjkpIj4KICA8cGF0aCBkPSJtNzMuNTY0IDI0MC42MmMtMS4xNTQ5LTAuMTA4NDgtMy4xODkzLTAuNTM3MjktNC4zNDg2LTAuOTE2NjItNi42MzI5LTIuMTcwMi0xMS43OTEtNy42MDI0LTEzLjQ5LTE0LjIwNy0wLjY2OTQ4LTIuNjAyMi0wLjYyMjM1LTAuMzMzMjItMC42NjQ4Ni0zMi4wMWwtMC4wMzkxLTI5LjE0NS0xOS4wMjQtMjEuMDMyYy0xMC40NjMtMTEuNTY3LTE5Ljg2NC0yMS45NTMtMjAuODkxLTIzLjA3OS00LjE2MjQtNC41NjM2LTYuNjA4Ny04LjA5MTYtOC44MTcyLTEyLjcxNi0yLjg3NjktNi4wMjM4LTQuMzU0My0xMS44NTgtNC43MzYyLTE4LjcwMy0wLjU1NjY3LTkuOTc3NCAyLjExNy0yMC4xMiA3LjU0OTgtMjguNjQxIDUuNTc3Mi04Ljc0NjggMTMuNjgtMTUuNDIzIDIzLjM1LTE5LjI0IDExLjM3Mi00LjQ4ODUgMjQuMzQ0LTQuNDg5MyAzNS42NzMtMC4wMDIzIDE0LjQ1NCA1LjcyNDggMjUuMjM1IDE3Ljc1OCAyOS4yODkgMzIuNjkzIDIuNzE4OSAxMC4wMTUgMi4xMTQzIDIwLjk5NS0xLjY4NCAzMC41ODUtNC4xODE5IDEwLjU1OS0xMS42NjYgMTkuMTQyLTIxLjYwOCAyNC43ODItMi4zMzMgMS4zMjM2LTYuMjMyMSAzLjAyNzgtOC44MTMxIDMuODUyMi03LjkzOTkgMi41MzU5LTE2LjU1MiAzLjAxMS0yNC43NTYgMS4zNjU2LTEuNTMzNy0wLjMwNzU5LTQuNDY4My0xLjA3NjgtNS42MjAxLTEuNDczLTAuMzU2NjktMC4xMjI3MS0wLjY2OTA4LTAuMjAyNTYtMC42OTQyMS0wLjE3NzQzLTAuMDI1MSAwLjAyNTEgNC45NjI0IDUuNTgxNiAxMS4wODMgMTIuMzQ4IDYuMTIxIDYuNzY2MiAxMS4xNDYgMTIuMjg1IDExLjE2NiAxMi4yNjUgMC4wMjA1LTAuMDIwNiAwLjMzNjc5LTAuNjM1NjYgMC43MDI4Mi0xLjM2NjkgMi44NDM3LTUuNjgwOSA4LjAyMzUtOS42NjM2IDE0LjIyNi0xMC45MzggMi4wNzg5LTAuNDI3MjYgMi44NDA0LTAuNDM2NCAzMi42NzMtMC4zOTIwNiAzMS43NzggMC4wNDcyIDI5LjUwNC0xLjJlLTQgMzIuMTA2IDAuNjY5MiAyLjc3ODEgMC43MTQ3MiA1LjU4MzIgMi4xODA4IDcuOTUzNCA0LjE1NjggMy4xNDk3IDIuNjI1OSA1LjQ0MyA2LjI3MyA2LjYxMDcgMTAuNTEzbDAuMTkwMjYgMC42OTA5MSAwLjMyNzkzLTAuMzQwMDNjMS4xMDk1LTEuMTUwNSAyNC45MjMtMjcuNTY4IDI0Ljg4NS0yNy42MDYtMC4wMjU3LTAuMDI1OC0wLjI3ODcxIDAuMDM1OC0wLjU2MjE0IDAuMTM2ODctMS4xMDQ1IDAuMzkzNjctMy44MjA4IDEuMTE1MS01LjQ3MjIgMS40NTM0LTkuNDQyOSAxLjkzNDQtMTkuMDc5IDEuMTI2MS0yNy44NTEtMi4zMzYyLTExLjUxMS00LjU0MzQtMjAuODktMTMuMjUzLTI2LjE2NC0yNC4yOTUtMi44NzY5LTYuMDIzOC00LjM1NDMtMTEuODU4LTQuNzM2Mi0xOC43MDMtMC41NTY2Ni05Ljk3NzQgMi4xMTctMjAuMTIgNy41NDk4LTI4LjY0MSA1LjU3NzItOC43NDY4IDEzLjY4LTE1LjQyMyAyMy4zNS0xOS4yNCAxMS4zNzItNC40ODg1IDI0LjM0NC00LjQ4OTMgMzUuNjczLTAuMDAyMyAxNC40NTQgNS43MjQ4IDI1LjIzNSAxNy43NTggMjkuMjg5IDMyLjY5MyAyLjQzNTIgOC45NzA1IDIuMjAyOSAxOC44MjItMC42NTQ3OSAyNy43Ny0wLjgyNDM0IDIuNTgxLTIuNTI4NiA2LjQ4MDEtMy44NTIyIDguODEzMS0yLjE1MDcgMy43OTA5LTQuMDcxMiA2LjM0MS04LjEyNjUgMTAuNzktMS40MDkxIDEuNTQ1OS0xMS42OTQgMTIuOTA3LTIyLjg1NSAyNS4yNDdsLTIwLjI5MyAyMi40MzYtMC4wMzEyIDMuMDI4NS0wLjAzMTIgMy4wMjg1aDI4LjU0MnYtOC4xODczaDE4LjAxMnY0NC40NDVoLTE4LjAxMnYtOC4xODczaC0yOC41MjdsLTAuMDM5NCA5LjkxMjRjLTAuMDM4NCA5LjY3NzctMC4wNDU1IDkuOTQzNS0wLjI5ODQxIDExLjIyMy0wLjU1NTI3IDIuODA5Mi0xLjkwNDEgNS45NzQ2LTMuNTAyOSA4LjIyMDktMS4wMTMyIDEuNDIzNS0zLjI4NTggMy42OTYxLTQuNzA5MyA0LjcwOTMtMi4yNDA5IDEuNTk1LTUuMzkzIDIuOTM5Ni04LjIyMDkgMy41MDY3bC0xLjMxMDYgMC4yNjI4NS0yOS42NSAwLjAxMTNjLTE2LjMwNyA2ZS0zIC0yOS44Ni04ZS0zIC0zMC4xMTctMC4wMzI2em0tMTguNTk3LTExNy40MWM2LjYzODQtMC44OTkzOCAxMi4zMzYtMy4yMjU5IDE3LjcyLTcuMjM2IDIuMTY3OS0xLjYxNDcgNS41OTMzLTUuMDQwMSA3LjIwOC03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzgtNi45Njg4LTMuNDE4MS0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS00LjU2NzYgNS41MDMtNy4zMDYgMTEuNzktOC4zMzc2IDE5LjE0My0wLjI4ODc3IDIuMDU4MS0wLjI4ODc3IDcuMTgxOCAwIDkuMjM5OSAwLjk3ODk1IDYuOTc3MSAzLjM4NjEgMTIuNzU5IDcuNTk2OSAxOC4yNDYgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6bTEwOS44MyAwYzYuNjM4NC0wLjg5OTM4IDEyLjMzNi0zLjIyNTkgMTcuNzItNy4yMzYgMi4xNjc5LTEuNjE0NyA1LjU5MzMtNS4wNDAxIDcuMjA3OS03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzktNi45Njg4LTMuNDE4Mi0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS0zLjkxNjggNC43MTktNi42NTgyIDEwLjM5OC03Ljg0MjIgMTYuMjQ3LTAuNTgxODcgMi44NzQyLTAuNzAwNDkgNC4xNDY5LTAuNzAwNDkgNy41MTU2IDAgMy4zNjg3IDAuMTE4NjIgNC42NDE0IDAuNzAwNDkgNy41MTU2IDEuMTEwNCA1LjQ4NTIgMy41MDc2IDEwLjY2NyA3LjEwMTYgMTUuMzUgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6IiBzdHJva2Utd2lkdGg9Ii4xMTY5NiIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3Ljg1bW0iIGhlaWdodD0iMjIzLjUxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy44NSAyMjMuNTEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjc4NTk4IC0yNS41ODYpIj4KICA8cGF0aCBkPSJtMTAwLjQgMjQ5LjA2Yy0xMS44NDQtMC43NTUyNi0yMi4zOTMtMy42Mjc3LTMzLjAxNi04Ljk5MDMtMy42Njk0LTEuODUyNC01LjkzNDYtMy4xNzE0LTkuNDQyMi01LjQ5ODQtNS44NTY2LTMuODg1NC0xMC4yNDctNy40NjU1LTE1LjQ5LTEyLjYzLTYuMjA2MS02LjExMzctMTEuMDMzLTExLjk3LTE1Ljk5LTE5LjQtMTQuNTg1LTIxLjg2Mi0yMy4zNy00OC44OTUtMjUuMjk3LTc3LjgzOS0wLjM3OTc3LTUuNzA2LTAuNDg3MTMtMTMuNjctMC4yNDg2Ni0xOC40NDcgMC4yNTQwNS01LjA4OSAxLjU2NzktMTQuMTM0IDIuODc5My0xOS44MjIgMC4xMzQ3OS0wLjU4NDY2IDAuNDQ0NTUtMS45MzUzIDAuNjg4MzUtMy4wMDE1IDAuNTM0OTMtMi4zMzkzIDAuOTE2MzQtMy42NzUyIDIuMTI0Ni03LjQ0MTIgMi44MTc4LTguNzgyNiA1LjEzOTEtMTUuMTM0IDcuOTg0Mi0yMS44NDUgMy4yMi03LjU5NTUgNy4wNzM4LTE1LjA5MiAxMy42MTktMjYuNDkxbDEuMTg0Ny0yLjA2MzVoMTUwLjY0bDEuOTI5NyAzLjM3NjdjMS4wNjEzIDEuODU3MiAyLjE1ODYgMy43OTg4IDIuNDM4NSA0LjMxNDYgMC4yNzk4NSAwLjUxNTg4IDAuNTQ5NzggMC45OTQyNCAwLjU5OTg2IDEuMDYzIDAuMjk5MTkgMC40MTA5NyAzLjc5OTEgNy4wMjIzIDUuMTk3MSA5LjgxNzQgMi4wNDA3IDQuMDggMy4xMTE5IDYuMzg1OCA0LjYxODkgOS45NDI0IDIuOTAzNSA2Ljg1MjYgNS40NDUgMTMuNzY4IDcuODM2NSAyMS4zMjMgMS41NzkgNC45ODgzIDEuNjU3OCA1LjI3OTggMi45NzU5IDExLjAwNSAxLjIxODEgNS4yOTE1IDIuNTMyMyAxNC4xMTYgMi44NzU4IDE5LjMxIDAuMTY3NDggMi41MzI3IDAuMTcwMDggMTEuMDY4IDVlLTMgMTQuNzktMS4zNjI0IDMwLjYyNi0xMC4xNzcgNTguOTIxLTI1LjU1MSA4Mi4wMTgtNC45MDkgNy4zNzUzLTkuNjg3IDEzLjE3NC0xNS45MjQgMTkuMzI3LTUuMjk3OCA1LjIyNi05Ljc2MDEgOC44NjkyLTE1LjU1MiAxMi42OTctMy41NTgxIDIuMzUxNS01LjgxODQgMy42NjY0LTkuNDQyMiA1LjQ5MjYtOS43ODg1IDQuOTMyOS0xOS4zNDkgNy43MTk5LTMwLjA3NyA4Ljc2NzctMS45NjA0IDAuMTkxNDctOS43MjA1IDAuMzQxNTUtMTEuNTY4IDAuMjIzNzN6bTYuODQ3Ni00NC45NDNjNS41OTU4IDFlLTMgMTIuMzMyIDAuODEwMDUgMTUuNjAxIDEuODczOCA0LjUwNjYgMS40NjY0IDcuOTMyIDQuNTAzNyAxMS4wNiA5LjgwNjggMS41NTUgMi42MzY2IDIuMzQ5NSA0LjAzNTIgMi44ODQ0IDUuMDc3NCAwLjk5NTc3IDEuOTQwMyAxLjI3MjQgMi4xMjY3IDMuMTU0MSAyLjEyNDggMS40NDUtMmUtMyAyLjI4My0wLjMwODQ0IDIuODQxOC0xLjA0MSAxLjE2LTEuNTIwOSAxLjExODktMy42MzE0LTAuMTg1NC05LjUwNDQtMi40OTYyLTExLjI0LTYuNzY1NC0xOC40MTktMTIuNjg0LTIxLjMzLTIuNzc3LTEuMzY1Ni04LjAzMTEtMi43NTE3LTEzLjUxMS0zLjU2NDMtMi4zMDU5LTAuMzQxOTMtNi4wODI0LTAuNzY2NC03Ljg3ODktMC44ODU1OC0wLjYxOTA1LTAuMDQxMS0xLjUwNTQtMC4xMDY3NC0xLjk2OTctMC4xNDU5NGwtMC44NDQxNy0wLjA3MTN2LTIxLjk1OGwzLjY1ODEtMC4wNjI3YzMuODkzMy0wLjA2NjggNC42NjI3LTAuMTYyNjEgNi4zMjM2LTAuNzg3NzUgMS4zODQ0LTAuNTIxMTEgMi4yNjYyLTEuMTQ4OSAzLjg0ODYtMi43NDAyIDEuMTk3LTEuMjAzOCAxLjY0MzktMS43NTQ4IDIuMTQ3NC0yLjY0ODEgMC43NjUyNy0xLjM1NzUgMS4xNzIxLTIuMzExNCAxLjQ4NDYtMy40ODA5IDAuMzI3MDgtMS4yMjM5IDAuMzI4NTUtNS44MDY2IDJlLTMgLTcuNTY2Mi0xLjMzNzUtNy4yMTY4LTQuNDY3LTE2LjAyOS0xMy44MzQtMzguOTUyLTEuMDM4OC0yLjU0MjQtMi4yNTI2LTUuNTY4OS0yLjY5NzQtNi43MjU3bC0wLjgwODU4LTIuMTAzMnYtNjMuMDI0aC02Ni45MDdsLTIuMzkyNiA0Ljc4MzZjLTcuMDk2NSAxNC4xODgtMTAuOTg3IDIyLjc0NC0xNC4xNzQgMzEuMTcyLTcuNTQ4MyAxOS45NTgtOS45OTMyIDM2LjU1OC04LjAwMzMgNTQuMzM5IDIuNzI3MiAyNC4zNjkgMTMuNzY1IDUwLjk0NSAyOS4xNDEgNzAuMTYgNC4zMjE4IDUuNDAxIDEwLjE5NSAxMS4zNSAxNS43NTEgMTUuOTU0IDUuNTAzNiA0LjU2MDUgMTIuNDA3IDkuMjYwNiAxOS44MjIgMTMuNDk2IDQuNDQxNyAyLjUzNjkgNi42MDUgMy42NzI4IDE0LjE5NSA3LjQ1MzMgMy45ODk1IDEuOTg3MiA4LjQwNzMgNC4yMjMgOS44MTczIDQuOTY4M2wyLjU2MzggMS4zNTUxIDAuMDYzNC0zNS45NzNoMS41MzE2em0tMTQuMTAxLTAuMTM4ODdjLTYuNjk0LTAuMzE3NjItMTIuNTE4LTEuMjgwNC0xNi4zMDYtMi42OTUzLTkuNTcyOC0zLjU3Ni0xNC41MjEtMTIuMzY0LTE1LjA5NC0yNi44MDYtMC4xMjY4Ny0zLjE5OSAwLjE4NDU5LTQuNzAyNSAxLjE3MzgtNS42NjY0IDAuNzAyLTAuNjg0MDMgMS4yNzA3LTAuODcwOTYgMi42NDk4LTAuODcwOTYgMS4zMTcyIDAgMS45ODM0IDAuMTk3NDcgMi4yOTQ5IDAuNjgwMjUgMC4xMDM1OCAwLjE2MDUxIDAuNDgwODMgMC45NjcxNyAwLjgzODM0IDEuNzkyNiAxLjMxMTUgMy4wMjggMy4yNjcyIDYuODkxMiA0LjE5MDUgOC4yNzc2IDEuNjczOCAyLjUxMzUgMy44MjMxIDQuNTA5NCA2LjEyMjcgNS42ODYgMi42NTE1IDEuMzU2NyAzLjEwMDUgMS40MDM2IDE3LjgxOSAxLjg2MDggNC4zNjc4IDAuMTM1NzEgOC4xNTI1IDAuMjQ2NTYgOC40MTA0IDAuMjQ2MzZoMC40Njg5OHYxNy42MzRsLTUuMjIxMy0wLjAxODljLTIuODcxNy0wLjAxMDQtNi4xNzgxLTAuMDY0My03LjM0NzQtMC4xMTk3M3ptLTM0LjM5Mi04MC43MjVjLTAuMjc1MTQtMC4wMjcyLTEuMTQ3NC0wLjExMTEtMS45Mzg1LTAuMTg2NTMtNS44ODA5LTAuNTYwNzgtMTEuOTU0LTIuNDg0MS0xNi40NDYtNS4yMDgtNi45NDQtNC4yMTE1LTEwLjQzOC0xMC4yODQtOS4zODM3LTE2LjMwNyAxLjMzOTUtNy42NDg0IDkuNzIzMS0xNC4xNSAyMS4zMjctMTYuNTQxIDMuNDE2NS0wLjcwMzY5IDUuMzU1My0wLjg4MTA4IDkuNjI5OC0wLjg4MTA4IDQuMjc0NCAwIDYuMjEzMyAwLjE3NzQgOS42Mjk4IDAuODgxMDggMTIuNDUgMi41NjQzIDIxLjA0MiA5Ljc2NzggMjEuNDczIDE4LjAwMyAwLjIwMDU4IDMuODI5NC0xLjI0ODYgNy40MzcxLTQuMjgxNCAxMC42NTktNC42MTU3IDQuOTAzMi0xMi4wODYgOC4yMDg2LTIxLjEzMSA5LjM0OTgtMS40MjExIDAuMTc5MjktNy43MzYgMC4zNDI4Ny04Ljg3OTQgMC4yMzAwMXptMTIwLjYyLTE5LjQ4MmMwLTYuOTgyNy01LjY1NzUtMTMuMzA4LTE1LjEzMi0xNi45Mi0yLjk1NTctMS4xMjY2LTYuMjg5OS0xLjkzNzYtMTAuMDY3LTIuNDQ4OC0yLjkxMDctMC4zOTM5Mi04Ljk3MDItMC4zOTM5Mi0xMS44ODEgMC04Ljc4MiAxLjE4ODUtMTUuNzYgNC4yMTE3LTIwLjM5OCA4LjgzNzYtMy4xNjQyIDMuMTU2LTQuODAyMyA2Ljc0ODItNC44MDIzIDEwLjUzMXYxLjE3MTdoNjIuMjgxeiIgc3Ryb2tlLXdpZHRoPSIuMTI1MDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.46369" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,207,80,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTU2LjQ4bW0iIGhlaWdodD0iMjkxLjI4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1Ni40OCAyOTEuMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYuMDI0IC0zLjE0MDQpIj4KICA8cGF0aCBkPSJtNjMuMjE3IDI4NC42MnYtOS43OTgyaDE5Ljg1OGwwLjA5NTgtMS4yMjQ4YzAuMjQ2MjQtMy4xNDg5IDAuNTM5OTMtOS42NzY4IDAuNjI2MTYtMTMuOTE4IDAuMjA3LTEwLjE4MS0wLjY2NDk3LTE3LjMzNS0yLjg5NzctMjMuNzczLTEuODI4Ni01LjI3MjctNS40MjI0LTEyLjEwOC0xMC45ODQtMjAuODkzLTE1LjY0LTI0LjcwMi0yMy44MTYtMzkuNDY5LTMwLjI1OC01NC42NTItNy41MjctMTcuNzQtMTEuODYxLTM1LjE1NC0xMy4zNTUtNTMuNjY4LTAuMzY5NTYtNC41NzgyLTAuMzcxNjktMTQuODUyLTRlLTMgLTE4Ljg1NCAyLjAzNTYtMjIuMTQ5IDkuNDg4My0zMy4zMzggMjYuNDA5LTM5LjY0OCA1LjAxNzEtMS44NzEgMTEuMDQ4LTMuMzA4NyAyMC42MDMtNC45MTE4bDQuMjI5Ni0wLjcwOTYgMS4wNTQ0LTEuMDQ0MmMxLjU5MjgtMS41NzczIDIuMzI2Ni0zLjM0MjIgMi43MTgxLTYuNTM3MSAwLjE5OTg2LTEuNjMwOSAwLjIxMjA4LTQuODE2OCAwLjAxOTctNS4xMjEyLTAuMTIyMDYtMC4xOTMwNy0xLjU5NDEtMC4yMjkxMy0xMS4yODEtMC4yNzYzbC0xMS4xNC0wLjA1NDI1di0yNi4zOTNoOTAuNzA4djI2LjM5M2wtMTEuMTQgMC4wNTQyNWMtOS42ODY1IDAuMDQ3MTctMTEuMTU4IDAuMDgzMjItMTEuMjgxIDAuMjc2My0wLjE5MjQzIDAuMzA0MzktMC4xODAyIDMuNDkwMyAwLjAxOTYgNS4xMjEyIDAuMzkxNTMgMy4xOTUgMS4xMjU0IDQuOTU5OCAyLjcxODEgNi41MzcxbDEuMDU0NCAxLjA0NDIgNC4yMjk2IDAuNzA5NmM3LjU3MzUgMS4yNzA2IDEyLjQgMi4zMTkzIDE2Ljg5MiAzLjY3MDIgNS45NDgxIDEuNzg4OSAxMS4xNTEgNC4yODU0IDE0LjkzNCA3LjE2NjEgOS4xMzM0IDYuOTU0MyAxMy42NDcgMTYuOTc5IDE1LjE4NiAzMy43MjQgMC4zNjc4MSA0LjAwMiAwLjM2NTY5IDE0LjI3Ni00ZS0zIDE4Ljg1NC0xLjQ5NDQgMTguNTEzLTUuODI4IDM1LjkyOC0xMy4zNTUgNTMuNjY4LTYuNDQyMiAxNS4xODMtMTQuNjE4IDI5Ljk1LTMwLjI1OCA1NC42NTItNS41NjIgOC43ODQ4LTkuMTU1OCAxNS42Mi0xMC45ODQgMjAuODkzLTIuMjMyNyA2LjQzOC0zLjEwNDcgMTMuNTkyLTIuODk3NyAyMy43NzMgMC4wODYyIDQuMjQxMiAwLjM3OTkyIDEwLjc2OSAwLjYyNjE2IDEzLjkxOGwwLjA5NTggMS4yMjQ4aDE5Ljg1OHYxOS41OTZoLTgyLjA5N3YtOS43OTgyeiIgc3Ryb2tlLXdpZHRoPSIuMTQ4NDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.79352" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="255,0,0,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3LjQzbW0iIGhlaWdodD0iMjAzLjA5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy40MyAyMDMuMDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMS40Nzk2IC0zNy41NjkpIj4KICA8cGF0aCBkPSJtNzMuNTY0IDI0MC42MmMtMS4xNTQ5LTAuMTA4NDgtMy4xODkzLTAuNTM3MjktNC4zNDg2LTAuOTE2NjItNi42MzI5LTIuMTcwMi0xMS43OTEtNy42MDI0LTEzLjQ5LTE0LjIwNy0wLjY2OTQ4LTIuNjAyMi0wLjYyMjM1LTAuMzMzMjItMC42NjQ4Ni0zMi4wMWwtMC4wMzkxLTI5LjE0NS0xOS4wMjQtMjEuMDMyYy0xMC40NjMtMTEuNTY3LTE5Ljg2NC0yMS45NTMtMjAuODkxLTIzLjA3OS00LjE2MjQtNC41NjM2LTYuNjA4Ny04LjA5MTYtOC44MTcyLTEyLjcxNi0yLjg3NjktNi4wMjM4LTQuMzU0My0xMS44NTgtNC43MzYyLTE4LjcwMy0wLjU1NjY3LTkuOTc3NCAyLjExNy0yMC4xMiA3LjU0OTgtMjguNjQxIDUuNTc3Mi04Ljc0NjggMTMuNjgtMTUuNDIzIDIzLjM1LTE5LjI0IDExLjM3Mi00LjQ4ODUgMjQuMzQ0LTQuNDg5MyAzNS42NzMtMC4wMDIzIDE0LjQ1NCA1LjcyNDggMjUuMjM1IDE3Ljc1OCAyOS4yODkgMzIuNjkzIDIuNzE4OSAxMC4wMTUgMi4xMTQzIDIwLjk5NS0xLjY4NCAzMC41ODUtNC4xODE5IDEwLjU1OS0xMS42NjYgMTkuMTQyLTIxLjYwOCAyNC43ODItMi4zMzMgMS4zMjM2LTYuMjMyMSAzLjAyNzgtOC44MTMxIDMuODUyMi03LjkzOTkgMi41MzU5LTE2LjU1MiAzLjAxMS0yNC43NTYgMS4zNjU2LTEuNTMzNy0wLjMwNzU5LTQuNDY4My0xLjA3NjgtNS42MjAxLTEuNDczLTAuMzU2NjktMC4xMjI3MS0wLjY2OTA4LTAuMjAyNTYtMC42OTQyMS0wLjE3NzQzLTAuMDI1MSAwLjAyNTEgNC45NjI0IDUuNTgxNiAxMS4wODMgMTIuMzQ4IDYuMTIxIDYuNzY2MiAxMS4xNDYgMTIuMjg1IDExLjE2NiAxMi4yNjUgMC4wMjA1LTAuMDIwNiAwLjMzNjc5LTAuNjM1NjYgMC43MDI4Mi0xLjM2NjkgMi44NDM3LTUuNjgwOSA4LjAyMzUtOS42NjM2IDE0LjIyNi0xMC45MzggMi4wNzg5LTAuNDI3MjYgMi44NDA0LTAuNDM2NCAzMi42NzMtMC4zOTIwNiAzMS43NzggMC4wNDcyIDI5LjUwNC0xLjJlLTQgMzIuMTA2IDAuNjY5MiAyLjc3ODEgMC43MTQ3MiA1LjU4MzIgMi4xODA4IDcuOTUzNCA0LjE1NjggMy4xNDk3IDIuNjI1OSA1LjQ0MyA2LjI3MyA2LjYxMDcgMTAuNTEzbDAuMTkwMjYgMC42OTA5MSAwLjMyNzkzLTAuMzQwMDNjMS4xMDk1LTEuMTUwNSAyNC45MjMtMjcuNTY4IDI0Ljg4NS0yNy42MDYtMC4wMjU3LTAuMDI1OC0wLjI3ODcxIDAuMDM1OC0wLjU2MjE0IDAuMTM2ODctMS4xMDQ1IDAuMzkzNjctMy44MjA4IDEuMTE1MS01LjQ3MjIgMS40NTM0LTkuNDQyOSAxLjkzNDQtMTkuMDc5IDEuMTI2MS0yNy44NTEtMi4zMzYyLTExLjUxMS00LjU0MzQtMjAuODktMTMuMjUzLTI2LjE2NC0yNC4yOTUtMi44NzY5LTYuMDIzOC00LjM1NDMtMTEuODU4LTQuNzM2Mi0xOC43MDMtMC41NTY2Ni05Ljk3NzQgMi4xMTctMjAuMTIgNy41NDk4LTI4LjY0MSA1LjU3NzItOC43NDY4IDEzLjY4LTE1LjQyMyAyMy4zNS0xOS4yNCAxMS4zNzItNC40ODg1IDI0LjM0NC00LjQ4OTMgMzUuNjczLTAuMDAyMyAxNC40NTQgNS43MjQ4IDI1LjIzNSAxNy43NTggMjkuMjg5IDMyLjY5MyAyLjQzNTIgOC45NzA1IDIuMjAyOSAxOC44MjItMC42NTQ3OSAyNy43Ny0wLjgyNDM0IDIuNTgxLTIuNTI4NiA2LjQ4MDEtMy44NTIyIDguODEzMS0yLjE1MDcgMy43OTA5LTQuMDcxMiA2LjM0MS04LjEyNjUgMTAuNzktMS40MDkxIDEuNTQ1OS0xMS42OTQgMTIuOTA3LTIyLjg1NSAyNS4yNDdsLTIwLjI5MyAyMi40MzYtMC4wMzEyIDMuMDI4NS0wLjAzMTIgMy4wMjg1aDI4LjU0MnYtOC4xODczaDE4LjAxMnY0NC40NDVoLTE4LjAxMnYtOC4xODczaC0yOC41MjdsLTAuMDM5NCA5LjkxMjRjLTAuMDM4NCA5LjY3NzctMC4wNDU1IDkuOTQzNS0wLjI5ODQxIDExLjIyMy0wLjU1NTI3IDIuODA5Mi0xLjkwNDEgNS45NzQ2LTMuNTAyOSA4LjIyMDktMS4wMTMyIDEuNDIzNS0zLjI4NTggMy42OTYxLTQuNzA5MyA0LjcwOTMtMi4yNDA5IDEuNTk1LTUuMzkzIDIuOTM5Ni04LjIyMDkgMy41MDY3bC0xLjMxMDYgMC4yNjI4NS0yOS42NSAwLjAxMTNjLTE2LjMwNyA2ZS0zIC0yOS44Ni04ZS0zIC0zMC4xMTctMC4wMzI2em0tMTguNTk3LTExNy40MWM2LjYzODQtMC44OTkzOCAxMi4zMzYtMy4yMjU5IDE3LjcyLTcuMjM2IDIuMTY3OS0xLjYxNDcgNS41OTMzLTUuMDQwMSA3LjIwOC03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzgtNi45Njg4LTMuNDE4MS0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS00LjU2NzYgNS41MDMtNy4zMDYgMTEuNzktOC4zMzc2IDE5LjE0My0wLjI4ODc3IDIuMDU4MS0wLjI4ODc3IDcuMTgxOCAwIDkuMjM5OSAwLjk3ODk1IDYuOTc3MSAzLjM4NjEgMTIuNzU5IDcuNTk2OSAxOC4yNDYgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6bTEwOS44MyAwYzYuNjM4NC0wLjg5OTM4IDEyLjMzNi0zLjIyNTkgMTcuNzItNy4yMzYgMi4xNjc5LTEuNjE0NyA1LjU5MzMtNS4wNDAxIDcuMjA3OS03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzktNi45Njg4LTMuNDE4Mi0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS0zLjkxNjggNC43MTktNi42NTgyIDEwLjM5OC03Ljg0MjIgMTYuMjQ3LTAuNTgxODcgMi44NzQyLTAuNzAwNDkgNC4xNDY5LTAuNzAwNDkgNy41MTU2IDAgMy4zNjg3IDAuMTE4NjIgNC42NDE0IDAuNzAwNDkgNy41MTU2IDEuMTEwNCA1LjQ4NTIgMy41MDc2IDEwLjY2NyA3LjEwMTYgMTUuMzUgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6IiBzdHJva2Utd2lkdGg9Ii4xMTY5NiIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3Ljg1bW0iIGhlaWdodD0iMjIzLjUxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy44NSAyMjMuNTEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjc4NTk4IC0yNS41ODYpIj4KICA8cGF0aCBkPSJtMTAwLjQgMjQ5LjA2Yy0xMS44NDQtMC43NTUyNi0yMi4zOTMtMy42Mjc3LTMzLjAxNi04Ljk5MDMtMy42Njk0LTEuODUyNC01LjkzNDYtMy4xNzE0LTkuNDQyMi01LjQ5ODQtNS44NTY2LTMuODg1NC0xMC4yNDctNy40NjU1LTE1LjQ5LTEyLjYzLTYuMjA2MS02LjExMzctMTEuMDMzLTExLjk3LTE1Ljk5LTE5LjQtMTQuNTg1LTIxLjg2Mi0yMy4zNy00OC44OTUtMjUuMjk3LTc3LjgzOS0wLjM3OTc3LTUuNzA2LTAuNDg3MTMtMTMuNjctMC4yNDg2Ni0xOC40NDcgMC4yNTQwNS01LjA4OSAxLjU2NzktMTQuMTM0IDIuODc5My0xOS44MjIgMC4xMzQ3OS0wLjU4NDY2IDAuNDQ0NTUtMS45MzUzIDAuNjg4MzUtMy4wMDE1IDAuNTM0OTMtMi4zMzkzIDAuOTE2MzQtMy42NzUyIDIuMTI0Ni03LjQ0MTIgMi44MTc4LTguNzgyNiA1LjEzOTEtMTUuMTM0IDcuOTg0Mi0yMS44NDUgMy4yMi03LjU5NTUgNy4wNzM4LTE1LjA5MiAxMy42MTktMjYuNDkxbDEuMTg0Ny0yLjA2MzVoMTUwLjY0bDEuOTI5NyAzLjM3NjdjMS4wNjEzIDEuODU3MiAyLjE1ODYgMy43OTg4IDIuNDM4NSA0LjMxNDYgMC4yNzk4NSAwLjUxNTg4IDAuNTQ5NzggMC45OTQyNCAwLjU5OTg2IDEuMDYzIDAuMjk5MTkgMC40MTA5NyAzLjc5OTEgNy4wMjIzIDUuMTk3MSA5LjgxNzQgMi4wNDA3IDQuMDggMy4xMTE5IDYuMzg1OCA0LjYxODkgOS45NDI0IDIuOTAzNSA2Ljg1MjYgNS40NDUgMTMuNzY4IDcuODM2NSAyMS4zMjMgMS41NzkgNC45ODgzIDEuNjU3OCA1LjI3OTggMi45NzU5IDExLjAwNSAxLjIxODEgNS4yOTE1IDIuNTMyMyAxNC4xMTYgMi44NzU4IDE5LjMxIDAuMTY3NDggMi41MzI3IDAuMTcwMDggMTEuMDY4IDVlLTMgMTQuNzktMS4zNjI0IDMwLjYyNi0xMC4xNzcgNTguOTIxLTI1LjU1MSA4Mi4wMTgtNC45MDkgNy4zNzUzLTkuNjg3IDEzLjE3NC0xNS45MjQgMTkuMzI3LTUuMjk3OCA1LjIyNi05Ljc2MDEgOC44NjkyLTE1LjU1MiAxMi42OTctMy41NTgxIDIuMzUxNS01LjgxODQgMy42NjY0LTkuNDQyMiA1LjQ5MjYtOS43ODg1IDQuOTMyOS0xOS4zNDkgNy43MTk5LTMwLjA3NyA4Ljc2NzctMS45NjA0IDAuMTkxNDctOS43MjA1IDAuMzQxNTUtMTEuNTY4IDAuMjIzNzN6bTYuODQ3Ni00NC45NDNjNS41OTU4IDFlLTMgMTIuMzMyIDAuODEwMDUgMTUuNjAxIDEuODczOCA0LjUwNjYgMS40NjY0IDcuOTMyIDQuNTAzNyAxMS4wNiA5LjgwNjggMS41NTUgMi42MzY2IDIuMzQ5NSA0LjAzNTIgMi44ODQ0IDUuMDc3NCAwLjk5NTc3IDEuOTQwMyAxLjI3MjQgMi4xMjY3IDMuMTU0MSAyLjEyNDggMS40NDUtMmUtMyAyLjI4My0wLjMwODQ0IDIuODQxOC0xLjA0MSAxLjE2LTEuNTIwOSAxLjExODktMy42MzE0LTAuMTg1NC05LjUwNDQtMi40OTYyLTExLjI0LTYuNzY1NC0xOC40MTktMTIuNjg0LTIxLjMzLTIuNzc3LTEuMzY1Ni04LjAzMTEtMi43NTE3LTEzLjUxMS0zLjU2NDMtMi4zMDU5LTAuMzQxOTMtNi4wODI0LTAuNzY2NC03Ljg3ODktMC44ODU1OC0wLjYxOTA1LTAuMDQxMS0xLjUwNTQtMC4xMDY3NC0xLjk2OTctMC4xNDU5NGwtMC44NDQxNy0wLjA3MTN2LTIxLjk1OGwzLjY1ODEtMC4wNjI3YzMuODkzMy0wLjA2NjggNC42NjI3LTAuMTYyNjEgNi4zMjM2LTAuNzg3NzUgMS4zODQ0LTAuNTIxMTEgMi4yNjYyLTEuMTQ4OSAzLjg0ODYtMi43NDAyIDEuMTk3LTEuMjAzOCAxLjY0MzktMS43NTQ4IDIuMTQ3NC0yLjY0ODEgMC43NjUyNy0xLjM1NzUgMS4xNzIxLTIuMzExNCAxLjQ4NDYtMy40ODA5IDAuMzI3MDgtMS4yMjM5IDAuMzI4NTUtNS44MDY2IDJlLTMgLTcuNTY2Mi0xLjMzNzUtNy4yMTY4LTQuNDY3LTE2LjAyOS0xMy44MzQtMzguOTUyLTEuMDM4OC0yLjU0MjQtMi4yNTI2LTUuNTY4OS0yLjY5NzQtNi43MjU3bC0wLjgwODU4LTIuMTAzMnYtNjMuMDI0aC02Ni45MDdsLTIuMzkyNiA0Ljc4MzZjLTcuMDk2NSAxNC4xODgtMTAuOTg3IDIyLjc0NC0xNC4xNzQgMzEuMTcyLTcuNTQ4MyAxOS45NTgtOS45OTMyIDM2LjU1OC04LjAwMzMgNTQuMzM5IDIuNzI3MiAyNC4zNjkgMTMuNzY1IDUwLjk0NSAyOS4xNDEgNzAuMTYgNC4zMjE4IDUuNDAxIDEwLjE5NSAxMS4zNSAxNS43NTEgMTUuOTU0IDUuNTAzNiA0LjU2MDUgMTIuNDA3IDkuMjYwNiAxOS44MjIgMTMuNDk2IDQuNDQxNyAyLjUzNjkgNi42MDUgMy42NzI4IDE0LjE5NSA3LjQ1MzMgMy45ODk1IDEuOTg3MiA4LjQwNzMgNC4yMjMgOS44MTczIDQuOTY4M2wyLjU2MzggMS4zNTUxIDAuMDYzNC0zNS45NzNoMS41MzE2em0tMTQuMTAxLTAuMTM4ODdjLTYuNjk0LTAuMzE3NjItMTIuNTE4LTEuMjgwNC0xNi4zMDYtMi42OTUzLTkuNTcyOC0zLjU3Ni0xNC41MjEtMTIuMzY0LTE1LjA5NC0yNi44MDYtMC4xMjY4Ny0zLjE5OSAwLjE4NDU5LTQuNzAyNSAxLjE3MzgtNS42NjY0IDAuNzAyLTAuNjg0MDMgMS4yNzA3LTAuODcwOTYgMi42NDk4LTAuODcwOTYgMS4zMTcyIDAgMS45ODM0IDAuMTk3NDcgMi4yOTQ5IDAuNjgwMjUgMC4xMDM1OCAwLjE2MDUxIDAuNDgwODMgMC45NjcxNyAwLjgzODM0IDEuNzkyNiAxLjMxMTUgMy4wMjggMy4yNjcyIDYuODkxMiA0LjE5MDUgOC4yNzc2IDEuNjczOCAyLjUxMzUgMy44MjMxIDQuNTA5NCA2LjEyMjcgNS42ODYgMi42NTE1IDEuMzU2NyAzLjEwMDUgMS40MDM2IDE3LjgxOSAxLjg2MDggNC4zNjc4IDAuMTM1NzEgOC4xNTI1IDAuMjQ2NTYgOC40MTA0IDAuMjQ2MzZoMC40Njg5OHYxNy42MzRsLTUuMjIxMy0wLjAxODljLTIuODcxNy0wLjAxMDQtNi4xNzgxLTAuMDY0My03LjM0NzQtMC4xMTk3M3ptLTM0LjM5Mi04MC43MjVjLTAuMjc1MTQtMC4wMjcyLTEuMTQ3NC0wLjExMTEtMS45Mzg1LTAuMTg2NTMtNS44ODA5LTAuNTYwNzgtMTEuOTU0LTIuNDg0MS0xNi40NDYtNS4yMDgtNi45NDQtNC4yMTE1LTEwLjQzOC0xMC4yODQtOS4zODM3LTE2LjMwNyAxLjMzOTUtNy42NDg0IDkuNzIzMS0xNC4xNSAyMS4zMjctMTYuNTQxIDMuNDE2NS0wLjcwMzY5IDUuMzU1My0wLjg4MTA4IDkuNjI5OC0wLjg4MTA4IDQuMjc0NCAwIDYuMjEzMyAwLjE3NzQgOS42Mjk4IDAuODgxMDggMTIuNDUgMi41NjQzIDIxLjA0MiA5Ljc2NzggMjEuNDczIDE4LjAwMyAwLjIwMDU4IDMuODI5NC0xLjI0ODYgNy40MzcxLTQuMjgxNCAxMC42NTktNC42MTU3IDQuOTAzMi0xMi4wODYgOC4yMDg2LTIxLjEzMSA5LjM0OTgtMS40MjExIDAuMTc5MjktNy43MzYgMC4zNDI4Ny04Ljg3OTQgMC4yMzAwMXptMTIwLjYyLTE5LjQ4MmMwLTYuOTgyNy01LjY1NzUtMTMuMzA4LTE1LjEzMi0xNi45Mi0yLjk1NTctMS4xMjY2LTYuMjg5OS0xLjkzNzYtMTAuMDY3LTIuNDQ4OC0yLjkxMDctMC4zOTM5Mi04Ljk3MDItMC4zOTM5Mi0xMS44ODEgMC04Ljc4MiAxLjE4ODUtMTUuNzYgNC4yMTE3LTIwLjM5OCA4LjgzNzYtMy4xNjQyIDMuMTU2LTQuODAyMyA2Ljc0ODItNC44MDIzIDEwLjUzMXYxLjE3MTdoNjIuMjgxeiIgc3Ryb2tlLXdpZHRoPSIuMTI1MDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.46369" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="152,125,183,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTU2LjQ4bW0iIGhlaWdodD0iMjkxLjI4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1Ni40OCAyOTEuMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYuMDI0IC0zLjE0MDQpIj4KICA8cGF0aCBkPSJtNjMuMjE3IDI4NC42MnYtOS43OTgyaDE5Ljg1OGwwLjA5NTgtMS4yMjQ4YzAuMjQ2MjQtMy4xNDg5IDAuNTM5OTMtOS42NzY4IDAuNjI2MTYtMTMuOTE4IDAuMjA3LTEwLjE4MS0wLjY2NDk3LTE3LjMzNS0yLjg5NzctMjMuNzczLTEuODI4Ni01LjI3MjctNS40MjI0LTEyLjEwOC0xMC45ODQtMjAuODkzLTE1LjY0LTI0LjcwMi0yMy44MTYtMzkuNDY5LTMwLjI1OC01NC42NTItNy41MjctMTcuNzQtMTEuODYxLTM1LjE1NC0xMy4zNTUtNTMuNjY4LTAuMzY5NTYtNC41NzgyLTAuMzcxNjktMTQuODUyLTRlLTMgLTE4Ljg1NCAyLjAzNTYtMjIuMTQ5IDkuNDg4My0zMy4zMzggMjYuNDA5LTM5LjY0OCA1LjAxNzEtMS44NzEgMTEuMDQ4LTMuMzA4NyAyMC42MDMtNC45MTE4bDQuMjI5Ni0wLjcwOTYgMS4wNTQ0LTEuMDQ0MmMxLjU5MjgtMS41NzczIDIuMzI2Ni0zLjM0MjIgMi43MTgxLTYuNTM3MSAwLjE5OTg2LTEuNjMwOSAwLjIxMjA4LTQuODE2OCAwLjAxOTctNS4xMjEyLTAuMTIyMDYtMC4xOTMwNy0xLjU5NDEtMC4yMjkxMy0xMS4yODEtMC4yNzYzbC0xMS4xNC0wLjA1NDI1di0yNi4zOTNoOTAuNzA4djI2LjM5M2wtMTEuMTQgMC4wNTQyNWMtOS42ODY1IDAuMDQ3MTctMTEuMTU4IDAuMDgzMjItMTEuMjgxIDAuMjc2My0wLjE5MjQzIDAuMzA0MzktMC4xODAyIDMuNDkwMyAwLjAxOTYgNS4xMjEyIDAuMzkxNTMgMy4xOTUgMS4xMjU0IDQuOTU5OCAyLjcxODEgNi41MzcxbDEuMDU0NCAxLjA0NDIgNC4yMjk2IDAuNzA5NmM3LjU3MzUgMS4yNzA2IDEyLjQgMi4zMTkzIDE2Ljg5MiAzLjY3MDIgNS45NDgxIDEuNzg4OSAxMS4xNTEgNC4yODU0IDE0LjkzNCA3LjE2NjEgOS4xMzM0IDYuOTU0MyAxMy42NDcgMTYuOTc5IDE1LjE4NiAzMy43MjQgMC4zNjc4MSA0LjAwMiAwLjM2NTY5IDE0LjI3Ni00ZS0zIDE4Ljg1NC0xLjQ5NDQgMTguNTEzLTUuODI4IDM1LjkyOC0xMy4zNTUgNTMuNjY4LTYuNDQyMiAxNS4xODMtMTQuNjE4IDI5Ljk1LTMwLjI1OCA1NC42NTItNS41NjIgOC43ODQ4LTkuMTU1OCAxNS42Mi0xMC45ODQgMjAuODkzLTIuMjMyNyA2LjQzOC0zLjEwNDcgMTMuNTkyLTIuODk3NyAyMy43NzMgMC4wODYyIDQuMjQxMiAwLjM3OTkyIDEwLjc2OSAwLjYyNjE2IDEzLjkxOGwwLjA5NTggMS4yMjQ4aDE5Ljg1OHYxOS41OTZoLTgyLjA5N3YtOS43OTgyeiIgc3Ryb2tlLXdpZHRoPSIuMTQ4NDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.79352" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3LjQzbW0iIGhlaWdodD0iMjAzLjA5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy40MyAyMDMuMDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMS40Nzk2IC0zNy41NjkpIj4KICA8cGF0aCBkPSJtNzMuNTY0IDI0MC42MmMtMS4xNTQ5LTAuMTA4NDgtMy4xODkzLTAuNTM3MjktNC4zNDg2LTAuOTE2NjItNi42MzI5LTIuMTcwMi0xMS43OTEtNy42MDI0LTEzLjQ5LTE0LjIwNy0wLjY2OTQ4LTIuNjAyMi0wLjYyMjM1LTAuMzMzMjItMC42NjQ4Ni0zMi4wMWwtMC4wMzkxLTI5LjE0NS0xOS4wMjQtMjEuMDMyYy0xMC40NjMtMTEuNTY3LTE5Ljg2NC0yMS45NTMtMjAuODkxLTIzLjA3OS00LjE2MjQtNC41NjM2LTYuNjA4Ny04LjA5MTYtOC44MTcyLTEyLjcxNi0yLjg3NjktNi4wMjM4LTQuMzU0My0xMS44NTgtNC43MzYyLTE4LjcwMy0wLjU1NjY3LTkuOTc3NCAyLjExNy0yMC4xMiA3LjU0OTgtMjguNjQxIDUuNTc3Mi04Ljc0NjggMTMuNjgtMTUuNDIzIDIzLjM1LTE5LjI0IDExLjM3Mi00LjQ4ODUgMjQuMzQ0LTQuNDg5MyAzNS42NzMtMC4wMDIzIDE0LjQ1NCA1LjcyNDggMjUuMjM1IDE3Ljc1OCAyOS4yODkgMzIuNjkzIDIuNzE4OSAxMC4wMTUgMi4xMTQzIDIwLjk5NS0xLjY4NCAzMC41ODUtNC4xODE5IDEwLjU1OS0xMS42NjYgMTkuMTQyLTIxLjYwOCAyNC43ODItMi4zMzMgMS4zMjM2LTYuMjMyMSAzLjAyNzgtOC44MTMxIDMuODUyMi03LjkzOTkgMi41MzU5LTE2LjU1MiAzLjAxMS0yNC43NTYgMS4zNjU2LTEuNTMzNy0wLjMwNzU5LTQuNDY4My0xLjA3NjgtNS42MjAxLTEuNDczLTAuMzU2NjktMC4xMjI3MS0wLjY2OTA4LTAuMjAyNTYtMC42OTQyMS0wLjE3NzQzLTAuMDI1MSAwLjAyNTEgNC45NjI0IDUuNTgxNiAxMS4wODMgMTIuMzQ4IDYuMTIxIDYuNzY2MiAxMS4xNDYgMTIuMjg1IDExLjE2NiAxMi4yNjUgMC4wMjA1LTAuMDIwNiAwLjMzNjc5LTAuNjM1NjYgMC43MDI4Mi0xLjM2NjkgMi44NDM3LTUuNjgwOSA4LjAyMzUtOS42NjM2IDE0LjIyNi0xMC45MzggMi4wNzg5LTAuNDI3MjYgMi44NDA0LTAuNDM2NCAzMi42NzMtMC4zOTIwNiAzMS43NzggMC4wNDcyIDI5LjUwNC0xLjJlLTQgMzIuMTA2IDAuNjY5MiAyLjc3ODEgMC43MTQ3MiA1LjU4MzIgMi4xODA4IDcuOTUzNCA0LjE1NjggMy4xNDk3IDIuNjI1OSA1LjQ0MyA2LjI3MyA2LjYxMDcgMTAuNTEzbDAuMTkwMjYgMC42OTA5MSAwLjMyNzkzLTAuMzQwMDNjMS4xMDk1LTEuMTUwNSAyNC45MjMtMjcuNTY4IDI0Ljg4NS0yNy42MDYtMC4wMjU3LTAuMDI1OC0wLjI3ODcxIDAuMDM1OC0wLjU2MjE0IDAuMTM2ODctMS4xMDQ1IDAuMzkzNjctMy44MjA4IDEuMTE1MS01LjQ3MjIgMS40NTM0LTkuNDQyOSAxLjkzNDQtMTkuMDc5IDEuMTI2MS0yNy44NTEtMi4zMzYyLTExLjUxMS00LjU0MzQtMjAuODktMTMuMjUzLTI2LjE2NC0yNC4yOTUtMi44NzY5LTYuMDIzOC00LjM1NDMtMTEuODU4LTQuNzM2Mi0xOC43MDMtMC41NTY2Ni05Ljk3NzQgMi4xMTctMjAuMTIgNy41NDk4LTI4LjY0MSA1LjU3NzItOC43NDY4IDEzLjY4LTE1LjQyMyAyMy4zNS0xOS4yNCAxMS4zNzItNC40ODg1IDI0LjM0NC00LjQ4OTMgMzUuNjczLTAuMDAyMyAxNC40NTQgNS43MjQ4IDI1LjIzNSAxNy43NTggMjkuMjg5IDMyLjY5MyAyLjQzNTIgOC45NzA1IDIuMjAyOSAxOC44MjItMC42NTQ3OSAyNy43Ny0wLjgyNDM0IDIuNTgxLTIuNTI4NiA2LjQ4MDEtMy44NTIyIDguODEzMS0yLjE1MDcgMy43OTA5LTQuMDcxMiA2LjM0MS04LjEyNjUgMTAuNzktMS40MDkxIDEuNTQ1OS0xMS42OTQgMTIuOTA3LTIyLjg1NSAyNS4yNDdsLTIwLjI5MyAyMi40MzYtMC4wMzEyIDMuMDI4NS0wLjAzMTIgMy4wMjg1aDI4LjU0MnYtOC4xODczaDE4LjAxMnY0NC40NDVoLTE4LjAxMnYtOC4xODczaC0yOC41MjdsLTAuMDM5NCA5LjkxMjRjLTAuMDM4NCA5LjY3NzctMC4wNDU1IDkuOTQzNS0wLjI5ODQxIDExLjIyMy0wLjU1NTI3IDIuODA5Mi0xLjkwNDEgNS45NzQ2LTMuNTAyOSA4LjIyMDktMS4wMTMyIDEuNDIzNS0zLjI4NTggMy42OTYxLTQuNzA5MyA0LjcwOTMtMi4yNDA5IDEuNTk1LTUuMzkzIDIuOTM5Ni04LjIyMDkgMy41MDY3bC0xLjMxMDYgMC4yNjI4NS0yOS42NSAwLjAxMTNjLTE2LjMwNyA2ZS0zIC0yOS44Ni04ZS0zIC0zMC4xMTctMC4wMzI2em0tMTguNTk3LTExNy40MWM2LjYzODQtMC44OTkzOCAxMi4zMzYtMy4yMjU5IDE3LjcyLTcuMjM2IDIuMTY3OS0xLjYxNDcgNS41OTMzLTUuMDQwMSA3LjIwOC03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzgtNi45Njg4LTMuNDE4MS0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS00LjU2NzYgNS41MDMtNy4zMDYgMTEuNzktOC4zMzc2IDE5LjE0My0wLjI4ODc3IDIuMDU4MS0wLjI4ODc3IDcuMTgxOCAwIDkuMjM5OSAwLjk3ODk1IDYuOTc3MSAzLjM4NjEgMTIuNzU5IDcuNTk2OSAxOC4yNDYgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6bTEwOS44MyAwYzYuNjM4NC0wLjg5OTM4IDEyLjMzNi0zLjIyNTkgMTcuNzItNy4yMzYgMi4xNjc5LTEuNjE0NyA1LjU5MzMtNS4wNDAxIDcuMjA3OS03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzktNi45Njg4LTMuNDE4Mi0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS0zLjkxNjggNC43MTktNi42NTgyIDEwLjM5OC03Ljg0MjIgMTYuMjQ3LTAuNTgxODcgMi44NzQyLTAuNzAwNDkgNC4xNDY5LTAuNzAwNDkgNy41MTU2IDAgMy4zNjg3IDAuMTE4NjIgNC42NDE0IDAuNzAwNDkgNy41MTU2IDEuMTEwNCA1LjQ4NTIgMy41MDc2IDEwLjY2NyA3LjEwMTYgMTUuMzUgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6IiBzdHJva2Utd2lkdGg9Ii4xMTY5NiIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3Ljg1bW0iIGhlaWdodD0iMjIzLjUxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy44NSAyMjMuNTEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjc4NTk4IC0yNS41ODYpIj4KICA8cGF0aCBkPSJtMTAwLjQgMjQ5LjA2Yy0xMS44NDQtMC43NTUyNi0yMi4zOTMtMy42Mjc3LTMzLjAxNi04Ljk5MDMtMy42Njk0LTEuODUyNC01LjkzNDYtMy4xNzE0LTkuNDQyMi01LjQ5ODQtNS44NTY2LTMuODg1NC0xMC4yNDctNy40NjU1LTE1LjQ5LTEyLjYzLTYuMjA2MS02LjExMzctMTEuMDMzLTExLjk3LTE1Ljk5LTE5LjQtMTQuNTg1LTIxLjg2Mi0yMy4zNy00OC44OTUtMjUuMjk3LTc3LjgzOS0wLjM3OTc3LTUuNzA2LTAuNDg3MTMtMTMuNjctMC4yNDg2Ni0xOC40NDcgMC4yNTQwNS01LjA4OSAxLjU2NzktMTQuMTM0IDIuODc5My0xOS44MjIgMC4xMzQ3OS0wLjU4NDY2IDAuNDQ0NTUtMS45MzUzIDAuNjg4MzUtMy4wMDE1IDAuNTM0OTMtMi4zMzkzIDAuOTE2MzQtMy42NzUyIDIuMTI0Ni03LjQ0MTIgMi44MTc4LTguNzgyNiA1LjEzOTEtMTUuMTM0IDcuOTg0Mi0yMS44NDUgMy4yMi03LjU5NTUgNy4wNzM4LTE1LjA5MiAxMy42MTktMjYuNDkxbDEuMTg0Ny0yLjA2MzVoMTUwLjY0bDEuOTI5NyAzLjM3NjdjMS4wNjEzIDEuODU3MiAyLjE1ODYgMy43OTg4IDIuNDM4NSA0LjMxNDYgMC4yNzk4NSAwLjUxNTg4IDAuNTQ5NzggMC45OTQyNCAwLjU5OTg2IDEuMDYzIDAuMjk5MTkgMC40MTA5NyAzLjc5OTEgNy4wMjIzIDUuMTk3MSA5LjgxNzQgMi4wNDA3IDQuMDggMy4xMTE5IDYuMzg1OCA0LjYxODkgOS45NDI0IDIuOTAzNSA2Ljg1MjYgNS40NDUgMTMuNzY4IDcuODM2NSAyMS4zMjMgMS41NzkgNC45ODgzIDEuNjU3OCA1LjI3OTggMi45NzU5IDExLjAwNSAxLjIxODEgNS4yOTE1IDIuNTMyMyAxNC4xMTYgMi44NzU4IDE5LjMxIDAuMTY3NDggMi41MzI3IDAuMTcwMDggMTEuMDY4IDVlLTMgMTQuNzktMS4zNjI0IDMwLjYyNi0xMC4xNzcgNTguOTIxLTI1LjU1MSA4Mi4wMTgtNC45MDkgNy4zNzUzLTkuNjg3IDEzLjE3NC0xNS45MjQgMTkuMzI3LTUuMjk3OCA1LjIyNi05Ljc2MDEgOC44NjkyLTE1LjU1MiAxMi42OTctMy41NTgxIDIuMzUxNS01LjgxODQgMy42NjY0LTkuNDQyMiA1LjQ5MjYtOS43ODg1IDQuOTMyOS0xOS4zNDkgNy43MTk5LTMwLjA3NyA4Ljc2NzctMS45NjA0IDAuMTkxNDctOS43MjA1IDAuMzQxNTUtMTEuNTY4IDAuMjIzNzN6bTYuODQ3Ni00NC45NDNjNS41OTU4IDFlLTMgMTIuMzMyIDAuODEwMDUgMTUuNjAxIDEuODczOCA0LjUwNjYgMS40NjY0IDcuOTMyIDQuNTAzNyAxMS4wNiA5LjgwNjggMS41NTUgMi42MzY2IDIuMzQ5NSA0LjAzNTIgMi44ODQ0IDUuMDc3NCAwLjk5NTc3IDEuOTQwMyAxLjI3MjQgMi4xMjY3IDMuMTU0MSAyLjEyNDggMS40NDUtMmUtMyAyLjI4My0wLjMwODQ0IDIuODQxOC0xLjA0MSAxLjE2LTEuNTIwOSAxLjExODktMy42MzE0LTAuMTg1NC05LjUwNDQtMi40OTYyLTExLjI0LTYuNzY1NC0xOC40MTktMTIuNjg0LTIxLjMzLTIuNzc3LTEuMzY1Ni04LjAzMTEtMi43NTE3LTEzLjUxMS0zLjU2NDMtMi4zMDU5LTAuMzQxOTMtNi4wODI0LTAuNzY2NC03Ljg3ODktMC44ODU1OC0wLjYxOTA1LTAuMDQxMS0xLjUwNTQtMC4xMDY3NC0xLjk2OTctMC4xNDU5NGwtMC44NDQxNy0wLjA3MTN2LTIxLjk1OGwzLjY1ODEtMC4wNjI3YzMuODkzMy0wLjA2NjggNC42NjI3LTAuMTYyNjEgNi4zMjM2LTAuNzg3NzUgMS4zODQ0LTAuNTIxMTEgMi4yNjYyLTEuMTQ4OSAzLjg0ODYtMi43NDAyIDEuMTk3LTEuMjAzOCAxLjY0MzktMS43NTQ4IDIuMTQ3NC0yLjY0ODEgMC43NjUyNy0xLjM1NzUgMS4xNzIxLTIuMzExNCAxLjQ4NDYtMy40ODA5IDAuMzI3MDgtMS4yMjM5IDAuMzI4NTUtNS44MDY2IDJlLTMgLTcuNTY2Mi0xLjMzNzUtNy4yMTY4LTQuNDY3LTE2LjAyOS0xMy44MzQtMzguOTUyLTEuMDM4OC0yLjU0MjQtMi4yNTI2LTUuNTY4OS0yLjY5NzQtNi43MjU3bC0wLjgwODU4LTIuMTAzMnYtNjMuMDI0aC02Ni45MDdsLTIuMzkyNiA0Ljc4MzZjLTcuMDk2NSAxNC4xODgtMTAuOTg3IDIyLjc0NC0xNC4xNzQgMzEuMTcyLTcuNTQ4MyAxOS45NTgtOS45OTMyIDM2LjU1OC04LjAwMzMgNTQuMzM5IDIuNzI3MiAyNC4zNjkgMTMuNzY1IDUwLjk0NSAyOS4xNDEgNzAuMTYgNC4zMjE4IDUuNDAxIDEwLjE5NSAxMS4zNSAxNS43NTEgMTUuOTU0IDUuNTAzNiA0LjU2MDUgMTIuNDA3IDkuMjYwNiAxOS44MjIgMTMuNDk2IDQuNDQxNyAyLjUzNjkgNi42MDUgMy42NzI4IDE0LjE5NSA3LjQ1MzMgMy45ODk1IDEuOTg3MiA4LjQwNzMgNC4yMjMgOS44MTczIDQuOTY4M2wyLjU2MzggMS4zNTUxIDAuMDYzNC0zNS45NzNoMS41MzE2em0tMTQuMTAxLTAuMTM4ODdjLTYuNjk0LTAuMzE3NjItMTIuNTE4LTEuMjgwNC0xNi4zMDYtMi42OTUzLTkuNTcyOC0zLjU3Ni0xNC41MjEtMTIuMzY0LTE1LjA5NC0yNi44MDYtMC4xMjY4Ny0zLjE5OSAwLjE4NDU5LTQuNzAyNSAxLjE3MzgtNS42NjY0IDAuNzAyLTAuNjg0MDMgMS4yNzA3LTAuODcwOTYgMi42NDk4LTAuODcwOTYgMS4zMTcyIDAgMS45ODM0IDAuMTk3NDcgMi4yOTQ5IDAuNjgwMjUgMC4xMDM1OCAwLjE2MDUxIDAuNDgwODMgMC45NjcxNyAwLjgzODM0IDEuNzkyNiAxLjMxMTUgMy4wMjggMy4yNjcyIDYuODkxMiA0LjE5MDUgOC4yNzc2IDEuNjczOCAyLjUxMzUgMy44MjMxIDQuNTA5NCA2LjEyMjcgNS42ODYgMi42NTE1IDEuMzU2NyAzLjEwMDUgMS40MDM2IDE3LjgxOSAxLjg2MDggNC4zNjc4IDAuMTM1NzEgOC4xNTI1IDAuMjQ2NTYgOC40MTA0IDAuMjQ2MzZoMC40Njg5OHYxNy42MzRsLTUuMjIxMy0wLjAxODljLTIuODcxNy0wLjAxMDQtNi4xNzgxLTAuMDY0My03LjM0NzQtMC4xMTk3M3ptLTM0LjM5Mi04MC43MjVjLTAuMjc1MTQtMC4wMjcyLTEuMTQ3NC0wLjExMTEtMS45Mzg1LTAuMTg2NTMtNS44ODA5LTAuNTYwNzgtMTEuOTU0LTIuNDg0MS0xNi40NDYtNS4yMDgtNi45NDQtNC4yMTE1LTEwLjQzOC0xMC4yODQtOS4zODM3LTE2LjMwNyAxLjMzOTUtNy42NDg0IDkuNzIzMS0xNC4xNSAyMS4zMjctMTYuNTQxIDMuNDE2NS0wLjcwMzY5IDUuMzU1My0wLjg4MTA4IDkuNjI5OC0wLjg4MTA4IDQuMjc0NCAwIDYuMjEzMyAwLjE3NzQgOS42Mjk4IDAuODgxMDggMTIuNDUgMi41NjQzIDIxLjA0MiA5Ljc2NzggMjEuNDczIDE4LjAwMyAwLjIwMDU4IDMuODI5NC0xLjI0ODYgNy40MzcxLTQuMjgxNCAxMC42NTktNC42MTU3IDQuOTAzMi0xMi4wODYgOC4yMDg2LTIxLjEzMSA5LjM0OTgtMS40MjExIDAuMTc5MjktNy43MzYgMC4zNDI4Ny04Ljg3OTQgMC4yMzAwMXptMTIwLjYyLTE5LjQ4MmMwLTYuOTgyNy01LjY1NzUtMTMuMzA4LTE1LjEzMi0xNi45Mi0yLjk1NTctMS4xMjY2LTYuMjg5OS0xLjkzNzYtMTAuMDY3LTIuNDQ4OC0yLjkxMDctMC4zOTM5Mi04Ljk3MDItMC4zOTM5Mi0xMS44ODEgMC04Ljc4MiAxLjE4ODUtMTUuNzYgNC4yMTE3LTIwLjM5OCA4LjgzNzYtMy4xNjQyIDMuMTU2LTQuODAyMyA2Ljc0ODItNC44MDIzIDEwLjUzMXYxLjE3MTdoNjIuMjgxeiIgc3Ryb2tlLXdpZHRoPSIuMTI1MDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.46369" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3LjQzbW0iIGhlaWdodD0iMjAzLjA5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy40MyAyMDMuMDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMS40Nzk2IC0zNy41NjkpIj4KICA8cGF0aCBkPSJtNzMuNTY0IDI0MC42MmMtMS4xNTQ5LTAuMTA4NDgtMy4xODkzLTAuNTM3MjktNC4zNDg2LTAuOTE2NjItNi42MzI5LTIuMTcwMi0xMS43OTEtNy42MDI0LTEzLjQ5LTE0LjIwNy0wLjY2OTQ4LTIuNjAyMi0wLjYyMjM1LTAuMzMzMjItMC42NjQ4Ni0zMi4wMWwtMC4wMzkxLTI5LjE0NS0xOS4wMjQtMjEuMDMyYy0xMC40NjMtMTEuNTY3LTE5Ljg2NC0yMS45NTMtMjAuODkxLTIzLjA3OS00LjE2MjQtNC41NjM2LTYuNjA4Ny04LjA5MTYtOC44MTcyLTEyLjcxNi0yLjg3NjktNi4wMjM4LTQuMzU0My0xMS44NTgtNC43MzYyLTE4LjcwMy0wLjU1NjY3LTkuOTc3NCAyLjExNy0yMC4xMiA3LjU0OTgtMjguNjQxIDUuNTc3Mi04Ljc0NjggMTMuNjgtMTUuNDIzIDIzLjM1LTE5LjI0IDExLjM3Mi00LjQ4ODUgMjQuMzQ0LTQuNDg5MyAzNS42NzMtMC4wMDIzIDE0LjQ1NCA1LjcyNDggMjUuMjM1IDE3Ljc1OCAyOS4yODkgMzIuNjkzIDIuNzE4OSAxMC4wMTUgMi4xMTQzIDIwLjk5NS0xLjY4NCAzMC41ODUtNC4xODE5IDEwLjU1OS0xMS42NjYgMTkuMTQyLTIxLjYwOCAyNC43ODItMi4zMzMgMS4zMjM2LTYuMjMyMSAzLjAyNzgtOC44MTMxIDMuODUyMi03LjkzOTkgMi41MzU5LTE2LjU1MiAzLjAxMS0yNC43NTYgMS4zNjU2LTEuNTMzNy0wLjMwNzU5LTQuNDY4My0xLjA3NjgtNS42MjAxLTEuNDczLTAuMzU2NjktMC4xMjI3MS0wLjY2OTA4LTAuMjAyNTYtMC42OTQyMS0wLjE3NzQzLTAuMDI1MSAwLjAyNTEgNC45NjI0IDUuNTgxNiAxMS4wODMgMTIuMzQ4IDYuMTIxIDYuNzY2MiAxMS4xNDYgMTIuMjg1IDExLjE2NiAxMi4yNjUgMC4wMjA1LTAuMDIwNiAwLjMzNjc5LTAuNjM1NjYgMC43MDI4Mi0xLjM2NjkgMi44NDM3LTUuNjgwOSA4LjAyMzUtOS42NjM2IDE0LjIyNi0xMC45MzggMi4wNzg5LTAuNDI3MjYgMi44NDA0LTAuNDM2NCAzMi42NzMtMC4zOTIwNiAzMS43NzggMC4wNDcyIDI5LjUwNC0xLjJlLTQgMzIuMTA2IDAuNjY5MiAyLjc3ODEgMC43MTQ3MiA1LjU4MzIgMi4xODA4IDcuOTUzNCA0LjE1NjggMy4xNDk3IDIuNjI1OSA1LjQ0MyA2LjI3MyA2LjYxMDcgMTAuNTEzbDAuMTkwMjYgMC42OTA5MSAwLjMyNzkzLTAuMzQwMDNjMS4xMDk1LTEuMTUwNSAyNC45MjMtMjcuNTY4IDI0Ljg4NS0yNy42MDYtMC4wMjU3LTAuMDI1OC0wLjI3ODcxIDAuMDM1OC0wLjU2MjE0IDAuMTM2ODctMS4xMDQ1IDAuMzkzNjctMy44MjA4IDEuMTE1MS01LjQ3MjIgMS40NTM0LTkuNDQyOSAxLjkzNDQtMTkuMDc5IDEuMTI2MS0yNy44NTEtMi4zMzYyLTExLjUxMS00LjU0MzQtMjAuODktMTMuMjUzLTI2LjE2NC0yNC4yOTUtMi44NzY5LTYuMDIzOC00LjM1NDMtMTEuODU4LTQuNzM2Mi0xOC43MDMtMC41NTY2Ni05Ljk3NzQgMi4xMTctMjAuMTIgNy41NDk4LTI4LjY0MSA1LjU3NzItOC43NDY4IDEzLjY4LTE1LjQyMyAyMy4zNS0xOS4yNCAxMS4zNzItNC40ODg1IDI0LjM0NC00LjQ4OTMgMzUuNjczLTAuMDAyMyAxNC40NTQgNS43MjQ4IDI1LjIzNSAxNy43NTggMjkuMjg5IDMyLjY5MyAyLjQzNTIgOC45NzA1IDIuMjAyOSAxOC44MjItMC42NTQ3OSAyNy43Ny0wLjgyNDM0IDIuNTgxLTIuNTI4NiA2LjQ4MDEtMy44NTIyIDguODEzMS0yLjE1MDcgMy43OTA5LTQuMDcxMiA2LjM0MS04LjEyNjUgMTAuNzktMS40MDkxIDEuNTQ1OS0xMS42OTQgMTIuOTA3LTIyLjg1NSAyNS4yNDdsLTIwLjI5MyAyMi40MzYtMC4wMzEyIDMuMDI4NS0wLjAzMTIgMy4wMjg1aDI4LjU0MnYtOC4xODczaDE4LjAxMnY0NC40NDVoLTE4LjAxMnYtOC4xODczaC0yOC41MjdsLTAuMDM5NCA5LjkxMjRjLTAuMDM4NCA5LjY3NzctMC4wNDU1IDkuOTQzNS0wLjI5ODQxIDExLjIyMy0wLjU1NTI3IDIuODA5Mi0xLjkwNDEgNS45NzQ2LTMuNTAyOSA4LjIyMDktMS4wMTMyIDEuNDIzNS0zLjI4NTggMy42OTYxLTQuNzA5MyA0LjcwOTMtMi4yNDA5IDEuNTk1LTUuMzkzIDIuOTM5Ni04LjIyMDkgMy41MDY3bC0xLjMxMDYgMC4yNjI4NS0yOS42NSAwLjAxMTNjLTE2LjMwNyA2ZS0zIC0yOS44Ni04ZS0zIC0zMC4xMTctMC4wMzI2em0tMTguNTk3LTExNy40MWM2LjYzODQtMC44OTkzOCAxMi4zMzYtMy4yMjU5IDE3LjcyLTcuMjM2IDIuMTY3OS0xLjYxNDcgNS41OTMzLTUuMDQwMSA3LjIwOC03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzgtNi45Njg4LTMuNDE4MS0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS00LjU2NzYgNS41MDMtNy4zMDYgMTEuNzktOC4zMzc2IDE5LjE0My0wLjI4ODc3IDIuMDU4MS0wLjI4ODc3IDcuMTgxOCAwIDkuMjM5OSAwLjk3ODk1IDYuOTc3MSAzLjM4NjEgMTIuNzU5IDcuNTk2OSAxOC4yNDYgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6bTEwOS44MyAwYzYuNjM4NC0wLjg5OTM4IDEyLjMzNi0zLjIyNTkgMTcuNzItNy4yMzYgMi4xNjc5LTEuNjE0NyA1LjU5MzMtNS4wNDAxIDcuMjA3OS03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzktNi45Njg4LTMuNDE4Mi0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS0zLjkxNjggNC43MTktNi42NTgyIDEwLjM5OC03Ljg0MjIgMTYuMjQ3LTAuNTgxODcgMi44NzQyLTAuNzAwNDkgNC4xNDY5LTAuNzAwNDkgNy41MTU2IDAgMy4zNjg3IDAuMTE4NjIgNC42NDE0IDAuNzAwNDkgNy41MTU2IDEuMTEwNCA1LjQ4NTIgMy41MDc2IDEwLjY2NyA3LjEwMTYgMTUuMzUgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6IiBzdHJva2Utd2lkdGg9Ii4xMTY5NiIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,207,80,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTU2LjQ4bW0iIGhlaWdodD0iMjkxLjI4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1Ni40OCAyOTEuMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYuMDI0IC0zLjE0MDQpIj4KICA8cGF0aCBkPSJtNjMuMjE3IDI4NC42MnYtOS43OTgyaDE5Ljg1OGwwLjA5NTgtMS4yMjQ4YzAuMjQ2MjQtMy4xNDg5IDAuNTM5OTMtOS42NzY4IDAuNjI2MTYtMTMuOTE4IDAuMjA3LTEwLjE4MS0wLjY2NDk3LTE3LjMzNS0yLjg5NzctMjMuNzczLTEuODI4Ni01LjI3MjctNS40MjI0LTEyLjEwOC0xMC45ODQtMjAuODkzLTE1LjY0LTI0LjcwMi0yMy44MTYtMzkuNDY5LTMwLjI1OC01NC42NTItNy41MjctMTcuNzQtMTEuODYxLTM1LjE1NC0xMy4zNTUtNTMuNjY4LTAuMzY5NTYtNC41NzgyLTAuMzcxNjktMTQuODUyLTRlLTMgLTE4Ljg1NCAyLjAzNTYtMjIuMTQ5IDkuNDg4My0zMy4zMzggMjYuNDA5LTM5LjY0OCA1LjAxNzEtMS44NzEgMTEuMDQ4LTMuMzA4NyAyMC42MDMtNC45MTE4bDQuMjI5Ni0wLjcwOTYgMS4wNTQ0LTEuMDQ0MmMxLjU5MjgtMS41NzczIDIuMzI2Ni0zLjM0MjIgMi43MTgxLTYuNTM3MSAwLjE5OTg2LTEuNjMwOSAwLjIxMjA4LTQuODE2OCAwLjAxOTctNS4xMjEyLTAuMTIyMDYtMC4xOTMwNy0xLjU5NDEtMC4yMjkxMy0xMS4yODEtMC4yNzYzbC0xMS4xNC0wLjA1NDI1di0yNi4zOTNoOTAuNzA4djI2LjM5M2wtMTEuMTQgMC4wNTQyNWMtOS42ODY1IDAuMDQ3MTctMTEuMTU4IDAuMDgzMjItMTEuMjgxIDAuMjc2My0wLjE5MjQzIDAuMzA0MzktMC4xODAyIDMuNDkwMyAwLjAxOTYgNS4xMjEyIDAuMzkxNTMgMy4xOTUgMS4xMjU0IDQuOTU5OCAyLjcxODEgNi41MzcxbDEuMDU0NCAxLjA0NDIgNC4yMjk2IDAuNzA5NmM3LjU3MzUgMS4yNzA2IDEyLjQgMi4zMTkzIDE2Ljg5MiAzLjY3MDIgNS45NDgxIDEuNzg4OSAxMS4xNTEgNC4yODU0IDE0LjkzNCA3LjE2NjEgOS4xMzM0IDYuOTU0MyAxMy42NDcgMTYuOTc5IDE1LjE4NiAzMy43MjQgMC4zNjc4MSA0LjAwMiAwLjM2NTY5IDE0LjI3Ni00ZS0zIDE4Ljg1NC0xLjQ5NDQgMTguNTEzLTUuODI4IDM1LjkyOC0xMy4zNTUgNTMuNjY4LTYuNDQyMiAxNS4xODMtMTQuNjE4IDI5Ljk1LTMwLjI1OCA1NC42NTItNS41NjIgOC43ODQ4LTkuMTU1OCAxNS42Mi0xMC45ODQgMjAuODkzLTIuMjMyNyA2LjQzOC0zLjEwNDcgMTMuNTkyLTIuODk3NyAyMy43NzMgMC4wODYyIDQuMjQxMiAwLjM3OTkyIDEwLjc2OSAwLjYyNjE2IDEzLjkxOGwwLjA5NTggMS4yMjQ4aDE5Ljg1OHYxOS41OTZoLTgyLjA5N3YtOS43OTgyeiIgc3Ryb2tlLXdpZHRoPSIuMTQ4NDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.79352" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3LjQzbW0iIGhlaWdodD0iMjAzLjA5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy40MyAyMDMuMDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMS40Nzk2IC0zNy41NjkpIj4KICA8cGF0aCBkPSJtNzMuNTY0IDI0MC42MmMtMS4xNTQ5LTAuMTA4NDgtMy4xODkzLTAuNTM3MjktNC4zNDg2LTAuOTE2NjItNi42MzI5LTIuMTcwMi0xMS43OTEtNy42MDI0LTEzLjQ5LTE0LjIwNy0wLjY2OTQ4LTIuNjAyMi0wLjYyMjM1LTAuMzMzMjItMC42NjQ4Ni0zMi4wMWwtMC4wMzkxLTI5LjE0NS0xOS4wMjQtMjEuMDMyYy0xMC40NjMtMTEuNTY3LTE5Ljg2NC0yMS45NTMtMjAuODkxLTIzLjA3OS00LjE2MjQtNC41NjM2LTYuNjA4Ny04LjA5MTYtOC44MTcyLTEyLjcxNi0yLjg3NjktNi4wMjM4LTQuMzU0My0xMS44NTgtNC43MzYyLTE4LjcwMy0wLjU1NjY3LTkuOTc3NCAyLjExNy0yMC4xMiA3LjU0OTgtMjguNjQxIDUuNTc3Mi04Ljc0NjggMTMuNjgtMTUuNDIzIDIzLjM1LTE5LjI0IDExLjM3Mi00LjQ4ODUgMjQuMzQ0LTQuNDg5MyAzNS42NzMtMC4wMDIzIDE0LjQ1NCA1LjcyNDggMjUuMjM1IDE3Ljc1OCAyOS4yODkgMzIuNjkzIDIuNzE4OSAxMC4wMTUgMi4xMTQzIDIwLjk5NS0xLjY4NCAzMC41ODUtNC4xODE5IDEwLjU1OS0xMS42NjYgMTkuMTQyLTIxLjYwOCAyNC43ODItMi4zMzMgMS4zMjM2LTYuMjMyMSAzLjAyNzgtOC44MTMxIDMuODUyMi03LjkzOTkgMi41MzU5LTE2LjU1MiAzLjAxMS0yNC43NTYgMS4zNjU2LTEuNTMzNy0wLjMwNzU5LTQuNDY4My0xLjA3NjgtNS42MjAxLTEuNDczLTAuMzU2NjktMC4xMjI3MS0wLjY2OTA4LTAuMjAyNTYtMC42OTQyMS0wLjE3NzQzLTAuMDI1MSAwLjAyNTEgNC45NjI0IDUuNTgxNiAxMS4wODMgMTIuMzQ4IDYuMTIxIDYuNzY2MiAxMS4xNDYgMTIuMjg1IDExLjE2NiAxMi4yNjUgMC4wMjA1LTAuMDIwNiAwLjMzNjc5LTAuNjM1NjYgMC43MDI4Mi0xLjM2NjkgMi44NDM3LTUuNjgwOSA4LjAyMzUtOS42NjM2IDE0LjIyNi0xMC45MzggMi4wNzg5LTAuNDI3MjYgMi44NDA0LTAuNDM2NCAzMi42NzMtMC4zOTIwNiAzMS43NzggMC4wNDcyIDI5LjUwNC0xLjJlLTQgMzIuMTA2IDAuNjY5MiAyLjc3ODEgMC43MTQ3MiA1LjU4MzIgMi4xODA4IDcuOTUzNCA0LjE1NjggMy4xNDk3IDIuNjI1OSA1LjQ0MyA2LjI3MyA2LjYxMDcgMTAuNTEzbDAuMTkwMjYgMC42OTA5MSAwLjMyNzkzLTAuMzQwMDNjMS4xMDk1LTEuMTUwNSAyNC45MjMtMjcuNTY4IDI0Ljg4NS0yNy42MDYtMC4wMjU3LTAuMDI1OC0wLjI3ODcxIDAuMDM1OC0wLjU2MjE0IDAuMTM2ODctMS4xMDQ1IDAuMzkzNjctMy44MjA4IDEuMTE1MS01LjQ3MjIgMS40NTM0LTkuNDQyOSAxLjkzNDQtMTkuMDc5IDEuMTI2MS0yNy44NTEtMi4zMzYyLTExLjUxMS00LjU0MzQtMjAuODktMTMuMjUzLTI2LjE2NC0yNC4yOTUtMi44NzY5LTYuMDIzOC00LjM1NDMtMTEuODU4LTQuNzM2Mi0xOC43MDMtMC41NTY2Ni05Ljk3NzQgMi4xMTctMjAuMTIgNy41NDk4LTI4LjY0MSA1LjU3NzItOC43NDY4IDEzLjY4LTE1LjQyMyAyMy4zNS0xOS4yNCAxMS4zNzItNC40ODg1IDI0LjM0NC00LjQ4OTMgMzUuNjczLTAuMDAyMyAxNC40NTQgNS43MjQ4IDI1LjIzNSAxNy43NTggMjkuMjg5IDMyLjY5MyAyLjQzNTIgOC45NzA1IDIuMjAyOSAxOC44MjItMC42NTQ3OSAyNy43Ny0wLjgyNDM0IDIuNTgxLTIuNTI4NiA2LjQ4MDEtMy44NTIyIDguODEzMS0yLjE1MDcgMy43OTA5LTQuMDcxMiA2LjM0MS04LjEyNjUgMTAuNzktMS40MDkxIDEuNTQ1OS0xMS42OTQgMTIuOTA3LTIyLjg1NSAyNS4yNDdsLTIwLjI5MyAyMi40MzYtMC4wMzEyIDMuMDI4NS0wLjAzMTIgMy4wMjg1aDI4LjU0MnYtOC4xODczaDE4LjAxMnY0NC40NDVoLTE4LjAxMnYtOC4xODczaC0yOC41MjdsLTAuMDM5NCA5LjkxMjRjLTAuMDM4NCA5LjY3NzctMC4wNDU1IDkuOTQzNS0wLjI5ODQxIDExLjIyMy0wLjU1NTI3IDIuODA5Mi0xLjkwNDEgNS45NzQ2LTMuNTAyOSA4LjIyMDktMS4wMTMyIDEuNDIzNS0zLjI4NTggMy42OTYxLTQuNzA5MyA0LjcwOTMtMi4yNDA5IDEuNTk1LTUuMzkzIDIuOTM5Ni04LjIyMDkgMy41MDY3bC0xLjMxMDYgMC4yNjI4NS0yOS42NSAwLjAxMTNjLTE2LjMwNyA2ZS0zIC0yOS44Ni04ZS0zIC0zMC4xMTctMC4wMzI2em0tMTguNTk3LTExNy40MWM2LjYzODQtMC44OTkzOCAxMi4zMzYtMy4yMjU5IDE3LjcyLTcuMjM2IDIuMTY3OS0xLjYxNDcgNS41OTMzLTUuMDQwMSA3LjIwOC03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzgtNi45Njg4LTMuNDE4MS0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS00LjU2NzYgNS41MDMtNy4zMDYgMTEuNzktOC4zMzc2IDE5LjE0My0wLjI4ODc3IDIuMDU4MS0wLjI4ODc3IDcuMTgxOCAwIDkuMjM5OSAwLjk3ODk1IDYuOTc3MSAzLjM4NjEgMTIuNzU5IDcuNTk2OSAxOC4yNDYgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6bTEwOS44MyAwYzYuNjM4NC0wLjg5OTM4IDEyLjMzNi0zLjIyNTkgMTcuNzItNy4yMzYgMi4xNjc5LTEuNjE0NyA1LjU5MzMtNS4wNDAxIDcuMjA3OS03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzktNi45Njg4LTMuNDE4Mi0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS0zLjkxNjggNC43MTktNi42NTgyIDEwLjM5OC03Ljg0MjIgMTYuMjQ3LTAuNTgxODcgMi44NzQyLTAuNzAwNDkgNC4xNDY5LTAuNzAwNDkgNy41MTU2IDAgMy4zNjg3IDAuMTE4NjIgNC42NDE0IDAuNzAwNDkgNy41MTU2IDEuMTEwNCA1LjQ4NTIgMy41MDc2IDEwLjY2NyA3LjEwMTYgMTUuMzUgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6IiBzdHJva2Utd2lkdGg9Ii4xMTY5NiIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3Ljg1bW0iIGhlaWdodD0iMjIzLjUxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy44NSAyMjMuNTEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjc4NTk4IC0yNS41ODYpIj4KICA8cGF0aCBkPSJtMTAwLjQgMjQ5LjA2Yy0xMS44NDQtMC43NTUyNi0yMi4zOTMtMy42Mjc3LTMzLjAxNi04Ljk5MDMtMy42Njk0LTEuODUyNC01LjkzNDYtMy4xNzE0LTkuNDQyMi01LjQ5ODQtNS44NTY2LTMuODg1NC0xMC4yNDctNy40NjU1LTE1LjQ5LTEyLjYzLTYuMjA2MS02LjExMzctMTEuMDMzLTExLjk3LTE1Ljk5LTE5LjQtMTQuNTg1LTIxLjg2Mi0yMy4zNy00OC44OTUtMjUuMjk3LTc3LjgzOS0wLjM3OTc3LTUuNzA2LTAuNDg3MTMtMTMuNjctMC4yNDg2Ni0xOC40NDcgMC4yNTQwNS01LjA4OSAxLjU2NzktMTQuMTM0IDIuODc5My0xOS44MjIgMC4xMzQ3OS0wLjU4NDY2IDAuNDQ0NTUtMS45MzUzIDAuNjg4MzUtMy4wMDE1IDAuNTM0OTMtMi4zMzkzIDAuOTE2MzQtMy42NzUyIDIuMTI0Ni03LjQ0MTIgMi44MTc4LTguNzgyNiA1LjEzOTEtMTUuMTM0IDcuOTg0Mi0yMS44NDUgMy4yMi03LjU5NTUgNy4wNzM4LTE1LjA5MiAxMy42MTktMjYuNDkxbDEuMTg0Ny0yLjA2MzVoMTUwLjY0bDEuOTI5NyAzLjM3NjdjMS4wNjEzIDEuODU3MiAyLjE1ODYgMy43OTg4IDIuNDM4NSA0LjMxNDYgMC4yNzk4NSAwLjUxNTg4IDAuNTQ5NzggMC45OTQyNCAwLjU5OTg2IDEuMDYzIDAuMjk5MTkgMC40MTA5NyAzLjc5OTEgNy4wMjIzIDUuMTk3MSA5LjgxNzQgMi4wNDA3IDQuMDggMy4xMTE5IDYuMzg1OCA0LjYxODkgOS45NDI0IDIuOTAzNSA2Ljg1MjYgNS40NDUgMTMuNzY4IDcuODM2NSAyMS4zMjMgMS41NzkgNC45ODgzIDEuNjU3OCA1LjI3OTggMi45NzU5IDExLjAwNSAxLjIxODEgNS4yOTE1IDIuNTMyMyAxNC4xMTYgMi44NzU4IDE5LjMxIDAuMTY3NDggMi41MzI3IDAuMTcwMDggMTEuMDY4IDVlLTMgMTQuNzktMS4zNjI0IDMwLjYyNi0xMC4xNzcgNTguOTIxLTI1LjU1MSA4Mi4wMTgtNC45MDkgNy4zNzUzLTkuNjg3IDEzLjE3NC0xNS45MjQgMTkuMzI3LTUuMjk3OCA1LjIyNi05Ljc2MDEgOC44NjkyLTE1LjU1MiAxMi42OTctMy41NTgxIDIuMzUxNS01LjgxODQgMy42NjY0LTkuNDQyMiA1LjQ5MjYtOS43ODg1IDQuOTMyOS0xOS4zNDkgNy43MTk5LTMwLjA3NyA4Ljc2NzctMS45NjA0IDAuMTkxNDctOS43MjA1IDAuMzQxNTUtMTEuNTY4IDAuMjIzNzN6bTYuODQ3Ni00NC45NDNjNS41OTU4IDFlLTMgMTIuMzMyIDAuODEwMDUgMTUuNjAxIDEuODczOCA0LjUwNjYgMS40NjY0IDcuOTMyIDQuNTAzNyAxMS4wNiA5LjgwNjggMS41NTUgMi42MzY2IDIuMzQ5NSA0LjAzNTIgMi44ODQ0IDUuMDc3NCAwLjk5NTc3IDEuOTQwMyAxLjI3MjQgMi4xMjY3IDMuMTU0MSAyLjEyNDggMS40NDUtMmUtMyAyLjI4My0wLjMwODQ0IDIuODQxOC0xLjA0MSAxLjE2LTEuNTIwOSAxLjExODktMy42MzE0LTAuMTg1NC05LjUwNDQtMi40OTYyLTExLjI0LTYuNzY1NC0xOC40MTktMTIuNjg0LTIxLjMzLTIuNzc3LTEuMzY1Ni04LjAzMTEtMi43NTE3LTEzLjUxMS0zLjU2NDMtMi4zMDU5LTAuMzQxOTMtNi4wODI0LTAuNzY2NC03Ljg3ODktMC44ODU1OC0wLjYxOTA1LTAuMDQxMS0xLjUwNTQtMC4xMDY3NC0xLjk2OTctMC4xNDU5NGwtMC44NDQxNy0wLjA3MTN2LTIxLjk1OGwzLjY1ODEtMC4wNjI3YzMuODkzMy0wLjA2NjggNC42NjI3LTAuMTYyNjEgNi4zMjM2LTAuNzg3NzUgMS4zODQ0LTAuNTIxMTEgMi4yNjYyLTEuMTQ4OSAzLjg0ODYtMi43NDAyIDEuMTk3LTEuMjAzOCAxLjY0MzktMS43NTQ4IDIuMTQ3NC0yLjY0ODEgMC43NjUyNy0xLjM1NzUgMS4xNzIxLTIuMzExNCAxLjQ4NDYtMy40ODA5IDAuMzI3MDgtMS4yMjM5IDAuMzI4NTUtNS44MDY2IDJlLTMgLTcuNTY2Mi0xLjMzNzUtNy4yMTY4LTQuNDY3LTE2LjAyOS0xMy44MzQtMzguOTUyLTEuMDM4OC0yLjU0MjQtMi4yNTI2LTUuNTY4OS0yLjY5NzQtNi43MjU3bC0wLjgwODU4LTIuMTAzMnYtNjMuMDI0aC02Ni45MDdsLTIuMzkyNiA0Ljc4MzZjLTcuMDk2NSAxNC4xODgtMTAuOTg3IDIyLjc0NC0xNC4xNzQgMzEuMTcyLTcuNTQ4MyAxOS45NTgtOS45OTMyIDM2LjU1OC04LjAwMzMgNTQuMzM5IDIuNzI3MiAyNC4zNjkgMTMuNzY1IDUwLjk0NSAyOS4xNDEgNzAuMTYgNC4zMjE4IDUuNDAxIDEwLjE5NSAxMS4zNSAxNS43NTEgMTUuOTU0IDUuNTAzNiA0LjU2MDUgMTIuNDA3IDkuMjYwNiAxOS44MjIgMTMuNDk2IDQuNDQxNyAyLjUzNjkgNi42MDUgMy42NzI4IDE0LjE5NSA3LjQ1MzMgMy45ODk1IDEuOTg3MiA4LjQwNzMgNC4yMjMgOS44MTczIDQuOTY4M2wyLjU2MzggMS4zNTUxIDAuMDYzNC0zNS45NzNoMS41MzE2em0tMTQuMTAxLTAuMTM4ODdjLTYuNjk0LTAuMzE3NjItMTIuNTE4LTEuMjgwNC0xNi4zMDYtMi42OTUzLTkuNTcyOC0zLjU3Ni0xNC41MjEtMTIuMzY0LTE1LjA5NC0yNi44MDYtMC4xMjY4Ny0zLjE5OSAwLjE4NDU5LTQuNzAyNSAxLjE3MzgtNS42NjY0IDAuNzAyLTAuNjg0MDMgMS4yNzA3LTAuODcwOTYgMi42NDk4LTAuODcwOTYgMS4zMTcyIDAgMS45ODM0IDAuMTk3NDcgMi4yOTQ5IDAuNjgwMjUgMC4xMDM1OCAwLjE2MDUxIDAuNDgwODMgMC45NjcxNyAwLjgzODM0IDEuNzkyNiAxLjMxMTUgMy4wMjggMy4yNjcyIDYuODkxMiA0LjE5MDUgOC4yNzc2IDEuNjczOCAyLjUxMzUgMy44MjMxIDQuNTA5NCA2LjEyMjcgNS42ODYgMi42NTE1IDEuMzU2NyAzLjEwMDUgMS40MDM2IDE3LjgxOSAxLjg2MDggNC4zNjc4IDAuMTM1NzEgOC4xNTI1IDAuMjQ2NTYgOC40MTA0IDAuMjQ2MzZoMC40Njg5OHYxNy42MzRsLTUuMjIxMy0wLjAxODljLTIuODcxNy0wLjAxMDQtNi4xNzgxLTAuMDY0My03LjM0NzQtMC4xMTk3M3ptLTM0LjM5Mi04MC43MjVjLTAuMjc1MTQtMC4wMjcyLTEuMTQ3NC0wLjExMTEtMS45Mzg1LTAuMTg2NTMtNS44ODA5LTAuNTYwNzgtMTEuOTU0LTIuNDg0MS0xNi40NDYtNS4yMDgtNi45NDQtNC4yMTE1LTEwLjQzOC0xMC4yODQtOS4zODM3LTE2LjMwNyAxLjMzOTUtNy42NDg0IDkuNzIzMS0xNC4xNSAyMS4zMjctMTYuNTQxIDMuNDE2NS0wLjcwMzY5IDUuMzU1My0wLjg4MTA4IDkuNjI5OC0wLjg4MTA4IDQuMjc0NCAwIDYuMjEzMyAwLjE3NzQgOS42Mjk4IDAuODgxMDggMTIuNDUgMi41NjQzIDIxLjA0MiA5Ljc2NzggMjEuNDczIDE4LjAwMyAwLjIwMDU4IDMuODI5NC0xLjI0ODYgNy40MzcxLTQuMjgxNCAxMC42NTktNC42MTU3IDQuOTAzMi0xMi4wODYgOC4yMDg2LTIxLjEzMSA5LjM0OTgtMS40MjExIDAuMTc5MjktNy43MzYgMC4zNDI4Ny04Ljg3OTQgMC4yMzAwMXptMTIwLjYyLTE5LjQ4MmMwLTYuOTgyNy01LjY1NzUtMTMuMzA4LTE1LjEzMi0xNi45Mi0yLjk1NTctMS4xMjY2LTYuMjg5OS0xLjkzNzYtMTAuMDY3LTIuNDQ4OC0yLjkxMDctMC4zOTM5Mi04Ljk3MDItMC4zOTM5Mi0xMS44ODEgMC04Ljc4MiAxLjE4ODUtMTUuNzYgNC4yMTE3LTIwLjM5OCA4LjgzNzYtMy4xNjQyIDMuMTU2LTQuODAyMyA2Ljc0ODItNC44MDIzIDEwLjUzMXYxLjE3MTdoNjIuMjgxeiIgc3Ryb2tlLXdpZHRoPSIuMTI1MDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.46369" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,207,80,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTU2LjQ4bW0iIGhlaWdodD0iMjkxLjI4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1Ni40OCAyOTEuMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYuMDI0IC0zLjE0MDQpIj4KICA8cGF0aCBkPSJtNjMuMjE3IDI4NC42MnYtOS43OTgyaDE5Ljg1OGwwLjA5NTgtMS4yMjQ4YzAuMjQ2MjQtMy4xNDg5IDAuNTM5OTMtOS42NzY4IDAuNjI2MTYtMTMuOTE4IDAuMjA3LTEwLjE4MS0wLjY2NDk3LTE3LjMzNS0yLjg5NzctMjMuNzczLTEuODI4Ni01LjI3MjctNS40MjI0LTEyLjEwOC0xMC45ODQtMjAuODkzLTE1LjY0LTI0LjcwMi0yMy44MTYtMzkuNDY5LTMwLjI1OC01NC42NTItNy41MjctMTcuNzQtMTEuODYxLTM1LjE1NC0xMy4zNTUtNTMuNjY4LTAuMzY5NTYtNC41NzgyLTAuMzcxNjktMTQuODUyLTRlLTMgLTE4Ljg1NCAyLjAzNTYtMjIuMTQ5IDkuNDg4My0zMy4zMzggMjYuNDA5LTM5LjY0OCA1LjAxNzEtMS44NzEgMTEuMDQ4LTMuMzA4NyAyMC42MDMtNC45MTE4bDQuMjI5Ni0wLjcwOTYgMS4wNTQ0LTEuMDQ0MmMxLjU5MjgtMS41NzczIDIuMzI2Ni0zLjM0MjIgMi43MTgxLTYuNTM3MSAwLjE5OTg2LTEuNjMwOSAwLjIxMjA4LTQuODE2OCAwLjAxOTctNS4xMjEyLTAuMTIyMDYtMC4xOTMwNy0xLjU5NDEtMC4yMjkxMy0xMS4yODEtMC4yNzYzbC0xMS4xNC0wLjA1NDI1di0yNi4zOTNoOTAuNzA4djI2LjM5M2wtMTEuMTQgMC4wNTQyNWMtOS42ODY1IDAuMDQ3MTctMTEuMTU4IDAuMDgzMjItMTEuMjgxIDAuMjc2My0wLjE5MjQzIDAuMzA0MzktMC4xODAyIDMuNDkwMyAwLjAxOTYgNS4xMjEyIDAuMzkxNTMgMy4xOTUgMS4xMjU0IDQuOTU5OCAyLjcxODEgNi41MzcxbDEuMDU0NCAxLjA0NDIgNC4yMjk2IDAuNzA5NmM3LjU3MzUgMS4yNzA2IDEyLjQgMi4zMTkzIDE2Ljg5MiAzLjY3MDIgNS45NDgxIDEuNzg4OSAxMS4xNTEgNC4yODU0IDE0LjkzNCA3LjE2NjEgOS4xMzM0IDYuOTU0MyAxMy42NDcgMTYuOTc5IDE1LjE4NiAzMy43MjQgMC4zNjc4MSA0LjAwMiAwLjM2NTY5IDE0LjI3Ni00ZS0zIDE4Ljg1NC0xLjQ5NDQgMTguNTEzLTUuODI4IDM1LjkyOC0xMy4zNTUgNTMuNjY4LTYuNDQyMiAxNS4xODMtMTQuNjE4IDI5Ljk1LTMwLjI1OCA1NC42NTItNS41NjIgOC43ODQ4LTkuMTU1OCAxNS42Mi0xMC45ODQgMjAuODkzLTIuMjMyNyA2LjQzOC0zLjEwNDcgMTMuNTkyLTIuODk3NyAyMy43NzMgMC4wODYyIDQuMjQxMiAwLjM3OTkyIDEwLjc2OSAwLjYyNjE2IDEzLjkxOGwwLjA5NTggMS4yMjQ4aDE5Ljg1OHYxOS41OTZoLTgyLjA5N3YtOS43OTgyeiIgc3Ryb2tlLXdpZHRoPSIuMTQ4NDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.79352" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3LjQzbW0iIGhlaWdodD0iMjAzLjA5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy40MyAyMDMuMDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMS40Nzk2IC0zNy41NjkpIj4KICA8cGF0aCBkPSJtNzMuNTY0IDI0MC42MmMtMS4xNTQ5LTAuMTA4NDgtMy4xODkzLTAuNTM3MjktNC4zNDg2LTAuOTE2NjItNi42MzI5LTIuMTcwMi0xMS43OTEtNy42MDI0LTEzLjQ5LTE0LjIwNy0wLjY2OTQ4LTIuNjAyMi0wLjYyMjM1LTAuMzMzMjItMC42NjQ4Ni0zMi4wMWwtMC4wMzkxLTI5LjE0NS0xOS4wMjQtMjEuMDMyYy0xMC40NjMtMTEuNTY3LTE5Ljg2NC0yMS45NTMtMjAuODkxLTIzLjA3OS00LjE2MjQtNC41NjM2LTYuNjA4Ny04LjA5MTYtOC44MTcyLTEyLjcxNi0yLjg3NjktNi4wMjM4LTQuMzU0My0xMS44NTgtNC43MzYyLTE4LjcwMy0wLjU1NjY3LTkuOTc3NCAyLjExNy0yMC4xMiA3LjU0OTgtMjguNjQxIDUuNTc3Mi04Ljc0NjggMTMuNjgtMTUuNDIzIDIzLjM1LTE5LjI0IDExLjM3Mi00LjQ4ODUgMjQuMzQ0LTQuNDg5MyAzNS42NzMtMC4wMDIzIDE0LjQ1NCA1LjcyNDggMjUuMjM1IDE3Ljc1OCAyOS4yODkgMzIuNjkzIDIuNzE4OSAxMC4wMTUgMi4xMTQzIDIwLjk5NS0xLjY4NCAzMC41ODUtNC4xODE5IDEwLjU1OS0xMS42NjYgMTkuMTQyLTIxLjYwOCAyNC43ODItMi4zMzMgMS4zMjM2LTYuMjMyMSAzLjAyNzgtOC44MTMxIDMuODUyMi03LjkzOTkgMi41MzU5LTE2LjU1MiAzLjAxMS0yNC43NTYgMS4zNjU2LTEuNTMzNy0wLjMwNzU5LTQuNDY4My0xLjA3NjgtNS42MjAxLTEuNDczLTAuMzU2NjktMC4xMjI3MS0wLjY2OTA4LTAuMjAyNTYtMC42OTQyMS0wLjE3NzQzLTAuMDI1MSAwLjAyNTEgNC45NjI0IDUuNTgxNiAxMS4wODMgMTIuMzQ4IDYuMTIxIDYuNzY2MiAxMS4xNDYgMTIuMjg1IDExLjE2NiAxMi4yNjUgMC4wMjA1LTAuMDIwNiAwLjMzNjc5LTAuNjM1NjYgMC43MDI4Mi0xLjM2NjkgMi44NDM3LTUuNjgwOSA4LjAyMzUtOS42NjM2IDE0LjIyNi0xMC45MzggMi4wNzg5LTAuNDI3MjYgMi44NDA0LTAuNDM2NCAzMi42NzMtMC4zOTIwNiAzMS43NzggMC4wNDcyIDI5LjUwNC0xLjJlLTQgMzIuMTA2IDAuNjY5MiAyLjc3ODEgMC43MTQ3MiA1LjU4MzIgMi4xODA4IDcuOTUzNCA0LjE1NjggMy4xNDk3IDIuNjI1OSA1LjQ0MyA2LjI3MyA2LjYxMDcgMTAuNTEzbDAuMTkwMjYgMC42OTA5MSAwLjMyNzkzLTAuMzQwMDNjMS4xMDk1LTEuMTUwNSAyNC45MjMtMjcuNTY4IDI0Ljg4NS0yNy42MDYtMC4wMjU3LTAuMDI1OC0wLjI3ODcxIDAuMDM1OC0wLjU2MjE0IDAuMTM2ODctMS4xMDQ1IDAuMzkzNjctMy44MjA4IDEuMTE1MS01LjQ3MjIgMS40NTM0LTkuNDQyOSAxLjkzNDQtMTkuMDc5IDEuMTI2MS0yNy44NTEtMi4zMzYyLTExLjUxMS00LjU0MzQtMjAuODktMTMuMjUzLTI2LjE2NC0yNC4yOTUtMi44NzY5LTYuMDIzOC00LjM1NDMtMTEuODU4LTQuNzM2Mi0xOC43MDMtMC41NTY2Ni05Ljk3NzQgMi4xMTctMjAuMTIgNy41NDk4LTI4LjY0MSA1LjU3NzItOC43NDY4IDEzLjY4LTE1LjQyMyAyMy4zNS0xOS4yNCAxMS4zNzItNC40ODg1IDI0LjM0NC00LjQ4OTMgMzUuNjczLTAuMDAyMyAxNC40NTQgNS43MjQ4IDI1LjIzNSAxNy43NTggMjkuMjg5IDMyLjY5MyAyLjQzNTIgOC45NzA1IDIuMjAyOSAxOC44MjItMC42NTQ3OSAyNy43Ny0wLjgyNDM0IDIuNTgxLTIuNTI4NiA2LjQ4MDEtMy44NTIyIDguODEzMS0yLjE1MDcgMy43OTA5LTQuMDcxMiA2LjM0MS04LjEyNjUgMTAuNzktMS40MDkxIDEuNTQ1OS0xMS42OTQgMTIuOTA3LTIyLjg1NSAyNS4yNDdsLTIwLjI5MyAyMi40MzYtMC4wMzEyIDMuMDI4NS0wLjAzMTIgMy4wMjg1aDI4LjU0MnYtOC4xODczaDE4LjAxMnY0NC40NDVoLTE4LjAxMnYtOC4xODczaC0yOC41MjdsLTAuMDM5NCA5LjkxMjRjLTAuMDM4NCA5LjY3NzctMC4wNDU1IDkuOTQzNS0wLjI5ODQxIDExLjIyMy0wLjU1NTI3IDIuODA5Mi0xLjkwNDEgNS45NzQ2LTMuNTAyOSA4LjIyMDktMS4wMTMyIDEuNDIzNS0zLjI4NTggMy42OTYxLTQuNzA5MyA0LjcwOTMtMi4yNDA5IDEuNTk1LTUuMzkzIDIuOTM5Ni04LjIyMDkgMy41MDY3bC0xLjMxMDYgMC4yNjI4NS0yOS42NSAwLjAxMTNjLTE2LjMwNyA2ZS0zIC0yOS44Ni04ZS0zIC0zMC4xMTctMC4wMzI2em0tMTguNTk3LTExNy40MWM2LjYzODQtMC44OTkzOCAxMi4zMzYtMy4yMjU5IDE3LjcyLTcuMjM2IDIuMTY3OS0xLjYxNDcgNS41OTMzLTUuMDQwMSA3LjIwOC03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzgtNi45Njg4LTMuNDE4MS0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS00LjU2NzYgNS41MDMtNy4zMDYgMTEuNzktOC4zMzc2IDE5LjE0My0wLjI4ODc3IDIuMDU4MS0wLjI4ODc3IDcuMTgxOCAwIDkuMjM5OSAwLjk3ODk1IDYuOTc3MSAzLjM4NjEgMTIuNzU5IDcuNTk2OSAxOC4yNDYgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6bTEwOS44MyAwYzYuNjM4NC0wLjg5OTM4IDEyLjMzNi0zLjIyNTkgMTcuNzItNy4yMzYgMi4xNjc5LTEuNjE0NyA1LjU5MzMtNS4wNDAxIDcuMjA3OS03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzktNi45Njg4LTMuNDE4Mi0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS0zLjkxNjggNC43MTktNi42NTgyIDEwLjM5OC03Ljg0MjIgMTYuMjQ3LTAuNTgxODcgMi44NzQyLTAuNzAwNDkgNC4xNDY5LTAuNzAwNDkgNy41MTU2IDAgMy4zNjg3IDAuMTE4NjIgNC42NDE0IDAuNzAwNDkgNy41MTU2IDEuMTEwNCA1LjQ4NTIgMy41MDc2IDEwLjY2NyA3LjEwMTYgMTUuMzUgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6IiBzdHJva2Utd2lkdGg9Ii4xMTY5NiIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3Ljg1bW0iIGhlaWdodD0iMjIzLjUxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy44NSAyMjMuNTEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjc4NTk4IC0yNS41ODYpIj4KICA8cGF0aCBkPSJtMTAwLjQgMjQ5LjA2Yy0xMS44NDQtMC43NTUyNi0yMi4zOTMtMy42Mjc3LTMzLjAxNi04Ljk5MDMtMy42Njk0LTEuODUyNC01LjkzNDYtMy4xNzE0LTkuNDQyMi01LjQ5ODQtNS44NTY2LTMuODg1NC0xMC4yNDctNy40NjU1LTE1LjQ5LTEyLjYzLTYuMjA2MS02LjExMzctMTEuMDMzLTExLjk3LTE1Ljk5LTE5LjQtMTQuNTg1LTIxLjg2Mi0yMy4zNy00OC44OTUtMjUuMjk3LTc3LjgzOS0wLjM3OTc3LTUuNzA2LTAuNDg3MTMtMTMuNjctMC4yNDg2Ni0xOC40NDcgMC4yNTQwNS01LjA4OSAxLjU2NzktMTQuMTM0IDIuODc5My0xOS44MjIgMC4xMzQ3OS0wLjU4NDY2IDAuNDQ0NTUtMS45MzUzIDAuNjg4MzUtMy4wMDE1IDAuNTM0OTMtMi4zMzkzIDAuOTE2MzQtMy42NzUyIDIuMTI0Ni03LjQ0MTIgMi44MTc4LTguNzgyNiA1LjEzOTEtMTUuMTM0IDcuOTg0Mi0yMS44NDUgMy4yMi03LjU5NTUgNy4wNzM4LTE1LjA5MiAxMy42MTktMjYuNDkxbDEuMTg0Ny0yLjA2MzVoMTUwLjY0bDEuOTI5NyAzLjM3NjdjMS4wNjEzIDEuODU3MiAyLjE1ODYgMy43OTg4IDIuNDM4NSA0LjMxNDYgMC4yNzk4NSAwLjUxNTg4IDAuNTQ5NzggMC45OTQyNCAwLjU5OTg2IDEuMDYzIDAuMjk5MTkgMC40MTA5NyAzLjc5OTEgNy4wMjIzIDUuMTk3MSA5LjgxNzQgMi4wNDA3IDQuMDggMy4xMTE5IDYuMzg1OCA0LjYxODkgOS45NDI0IDIuOTAzNSA2Ljg1MjYgNS40NDUgMTMuNzY4IDcuODM2NSAyMS4zMjMgMS41NzkgNC45ODgzIDEuNjU3OCA1LjI3OTggMi45NzU5IDExLjAwNSAxLjIxODEgNS4yOTE1IDIuNTMyMyAxNC4xMTYgMi44NzU4IDE5LjMxIDAuMTY3NDggMi41MzI3IDAuMTcwMDggMTEuMDY4IDVlLTMgMTQuNzktMS4zNjI0IDMwLjYyNi0xMC4xNzcgNTguOTIxLTI1LjU1MSA4Mi4wMTgtNC45MDkgNy4zNzUzLTkuNjg3IDEzLjE3NC0xNS45MjQgMTkuMzI3LTUuMjk3OCA1LjIyNi05Ljc2MDEgOC44NjkyLTE1LjU1MiAxMi42OTctMy41NTgxIDIuMzUxNS01LjgxODQgMy42NjY0LTkuNDQyMiA1LjQ5MjYtOS43ODg1IDQuOTMyOS0xOS4zNDkgNy43MTk5LTMwLjA3NyA4Ljc2NzctMS45NjA0IDAuMTkxNDctOS43MjA1IDAuMzQxNTUtMTEuNTY4IDAuMjIzNzN6bTYuODQ3Ni00NC45NDNjNS41OTU4IDFlLTMgMTIuMzMyIDAuODEwMDUgMTUuNjAxIDEuODczOCA0LjUwNjYgMS40NjY0IDcuOTMyIDQuNTAzNyAxMS4wNiA5LjgwNjggMS41NTUgMi42MzY2IDIuMzQ5NSA0LjAzNTIgMi44ODQ0IDUuMDc3NCAwLjk5NTc3IDEuOTQwMyAxLjI3MjQgMi4xMjY3IDMuMTU0MSAyLjEyNDggMS40NDUtMmUtMyAyLjI4My0wLjMwODQ0IDIuODQxOC0xLjA0MSAxLjE2LTEuNTIwOSAxLjExODktMy42MzE0LTAuMTg1NC05LjUwNDQtMi40OTYyLTExLjI0LTYuNzY1NC0xOC40MTktMTIuNjg0LTIxLjMzLTIuNzc3LTEuMzY1Ni04LjAzMTEtMi43NTE3LTEzLjUxMS0zLjU2NDMtMi4zMDU5LTAuMzQxOTMtNi4wODI0LTAuNzY2NC03Ljg3ODktMC44ODU1OC0wLjYxOTA1LTAuMDQxMS0xLjUwNTQtMC4xMDY3NC0xLjk2OTctMC4xNDU5NGwtMC44NDQxNy0wLjA3MTN2LTIxLjk1OGwzLjY1ODEtMC4wNjI3YzMuODkzMy0wLjA2NjggNC42NjI3LTAuMTYyNjEgNi4zMjM2LTAuNzg3NzUgMS4zODQ0LTAuNTIxMTEgMi4yNjYyLTEuMTQ4OSAzLjg0ODYtMi43NDAyIDEuMTk3LTEuMjAzOCAxLjY0MzktMS43NTQ4IDIuMTQ3NC0yLjY0ODEgMC43NjUyNy0xLjM1NzUgMS4xNzIxLTIuMzExNCAxLjQ4NDYtMy40ODA5IDAuMzI3MDgtMS4yMjM5IDAuMzI4NTUtNS44MDY2IDJlLTMgLTcuNTY2Mi0xLjMzNzUtNy4yMTY4LTQuNDY3LTE2LjAyOS0xMy44MzQtMzguOTUyLTEuMDM4OC0yLjU0MjQtMi4yNTI2LTUuNTY4OS0yLjY5NzQtNi43MjU3bC0wLjgwODU4LTIuMTAzMnYtNjMuMDI0aC02Ni45MDdsLTIuMzkyNiA0Ljc4MzZjLTcuMDk2NSAxNC4xODgtMTAuOTg3IDIyLjc0NC0xNC4xNzQgMzEuMTcyLTcuNTQ4MyAxOS45NTgtOS45OTMyIDM2LjU1OC04LjAwMzMgNTQuMzM5IDIuNzI3MiAyNC4zNjkgMTMuNzY1IDUwLjk0NSAyOS4xNDEgNzAuMTYgNC4zMjE4IDUuNDAxIDEwLjE5NSAxMS4zNSAxNS43NTEgMTUuOTU0IDUuNTAzNiA0LjU2MDUgMTIuNDA3IDkuMjYwNiAxOS44MjIgMTMuNDk2IDQuNDQxNyAyLjUzNjkgNi42MDUgMy42NzI4IDE0LjE5NSA3LjQ1MzMgMy45ODk1IDEuOTg3MiA4LjQwNzMgNC4yMjMgOS44MTczIDQuOTY4M2wyLjU2MzggMS4zNTUxIDAuMDYzNC0zNS45NzNoMS41MzE2em0tMTQuMTAxLTAuMTM4ODdjLTYuNjk0LTAuMzE3NjItMTIuNTE4LTEuMjgwNC0xNi4zMDYtMi42OTUzLTkuNTcyOC0zLjU3Ni0xNC41MjEtMTIuMzY0LTE1LjA5NC0yNi44MDYtMC4xMjY4Ny0zLjE5OSAwLjE4NDU5LTQuNzAyNSAxLjE3MzgtNS42NjY0IDAuNzAyLTAuNjg0MDMgMS4yNzA3LTAuODcwOTYgMi42NDk4LTAuODcwOTYgMS4zMTcyIDAgMS45ODM0IDAuMTk3NDcgMi4yOTQ5IDAuNjgwMjUgMC4xMDM1OCAwLjE2MDUxIDAuNDgwODMgMC45NjcxNyAwLjgzODM0IDEuNzkyNiAxLjMxMTUgMy4wMjggMy4yNjcyIDYuODkxMiA0LjE5MDUgOC4yNzc2IDEuNjczOCAyLjUxMzUgMy44MjMxIDQuNTA5NCA2LjEyMjcgNS42ODYgMi42NTE1IDEuMzU2NyAzLjEwMDUgMS40MDM2IDE3LjgxOSAxLjg2MDggNC4zNjc4IDAuMTM1NzEgOC4xNTI1IDAuMjQ2NTYgOC40MTA0IDAuMjQ2MzZoMC40Njg5OHYxNy42MzRsLTUuMjIxMy0wLjAxODljLTIuODcxNy0wLjAxMDQtNi4xNzgxLTAuMDY0My03LjM0NzQtMC4xMTk3M3ptLTM0LjM5Mi04MC43MjVjLTAuMjc1MTQtMC4wMjcyLTEuMTQ3NC0wLjExMTEtMS45Mzg1LTAuMTg2NTMtNS44ODA5LTAuNTYwNzgtMTEuOTU0LTIuNDg0MS0xNi40NDYtNS4yMDgtNi45NDQtNC4yMTE1LTEwLjQzOC0xMC4yODQtOS4zODM3LTE2LjMwNyAxLjMzOTUtNy42NDg0IDkuNzIzMS0xNC4xNSAyMS4zMjctMTYuNTQxIDMuNDE2NS0wLjcwMzY5IDUuMzU1My0wLjg4MTA4IDkuNjI5OC0wLjg4MTA4IDQuMjc0NCAwIDYuMjEzMyAwLjE3NzQgOS42Mjk4IDAuODgxMDggMTIuNDUgMi41NjQzIDIxLjA0MiA5Ljc2NzggMjEuNDczIDE4LjAwMyAwLjIwMDU4IDMuODI5NC0xLjI0ODYgNy40MzcxLTQuMjgxNCAxMC42NTktNC42MTU3IDQuOTAzMi0xMi4wODYgOC4yMDg2LTIxLjEzMSA5LjM0OTgtMS40MjExIDAuMTc5MjktNy43MzYgMC4zNDI4Ny04Ljg3OTQgMC4yMzAwMXptMTIwLjYyLTE5LjQ4MmMwLTYuOTgyNy01LjY1NzUtMTMuMzA4LTE1LjEzMi0xNi45Mi0yLjk1NTctMS4xMjY2LTYuMjg5OS0xLjkzNzYtMTAuMDY3LTIuNDQ4OC0yLjkxMDctMC4zOTM5Mi04Ljk3MDItMC4zOTM5Mi0xMS44ODEgMC04Ljc4MiAxLjE4ODUtMTUuNzYgNC4yMTE3LTIwLjM5OCA4LjgzNzYtMy4xNjQyIDMuMTU2LTQuODAyMyA2Ljc0ODItNC44MDIzIDEwLjUzMXYxLjE3MTdoNjIuMjgxeiIgc3Ryb2tlLXdpZHRoPSIuMTI1MDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.46369" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,207,80,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTU2LjQ4bW0iIGhlaWdodD0iMjkxLjI4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1Ni40OCAyOTEuMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYuMDI0IC0zLjE0MDQpIj4KICA8cGF0aCBkPSJtNjMuMjE3IDI4NC42MnYtOS43OTgyaDE5Ljg1OGwwLjA5NTgtMS4yMjQ4YzAuMjQ2MjQtMy4xNDg5IDAuNTM5OTMtOS42NzY4IDAuNjI2MTYtMTMuOTE4IDAuMjA3LTEwLjE4MS0wLjY2NDk3LTE3LjMzNS0yLjg5NzctMjMuNzczLTEuODI4Ni01LjI3MjctNS40MjI0LTEyLjEwOC0xMC45ODQtMjAuODkzLTE1LjY0LTI0LjcwMi0yMy44MTYtMzkuNDY5LTMwLjI1OC01NC42NTItNy41MjctMTcuNzQtMTEuODYxLTM1LjE1NC0xMy4zNTUtNTMuNjY4LTAuMzY5NTYtNC41NzgyLTAuMzcxNjktMTQuODUyLTRlLTMgLTE4Ljg1NCAyLjAzNTYtMjIuMTQ5IDkuNDg4My0zMy4zMzggMjYuNDA5LTM5LjY0OCA1LjAxNzEtMS44NzEgMTEuMDQ4LTMuMzA4NyAyMC42MDMtNC45MTE4bDQuMjI5Ni0wLjcwOTYgMS4wNTQ0LTEuMDQ0MmMxLjU5MjgtMS41NzczIDIuMzI2Ni0zLjM0MjIgMi43MTgxLTYuNTM3MSAwLjE5OTg2LTEuNjMwOSAwLjIxMjA4LTQuODE2OCAwLjAxOTctNS4xMjEyLTAuMTIyMDYtMC4xOTMwNy0xLjU5NDEtMC4yMjkxMy0xMS4yODEtMC4yNzYzbC0xMS4xNC0wLjA1NDI1di0yNi4zOTNoOTAuNzA4djI2LjM5M2wtMTEuMTQgMC4wNTQyNWMtOS42ODY1IDAuMDQ3MTctMTEuMTU4IDAuMDgzMjItMTEuMjgxIDAuMjc2My0wLjE5MjQzIDAuMzA0MzktMC4xODAyIDMuNDkwMyAwLjAxOTYgNS4xMjEyIDAuMzkxNTMgMy4xOTUgMS4xMjU0IDQuOTU5OCAyLjcxODEgNi41MzcxbDEuMDU0NCAxLjA0NDIgNC4yMjk2IDAuNzA5NmM3LjU3MzUgMS4yNzA2IDEyLjQgMi4zMTkzIDE2Ljg5MiAzLjY3MDIgNS45NDgxIDEuNzg4OSAxMS4xNTEgNC4yODU0IDE0LjkzNCA3LjE2NjEgOS4xMzM0IDYuOTU0MyAxMy42NDcgMTYuOTc5IDE1LjE4NiAzMy43MjQgMC4zNjc4MSA0LjAwMiAwLjM2NTY5IDE0LjI3Ni00ZS0zIDE4Ljg1NC0xLjQ5NDQgMTguNTEzLTUuODI4IDM1LjkyOC0xMy4zNTUgNTMuNjY4LTYuNDQyMiAxNS4xODMtMTQuNjE4IDI5Ljk1LTMwLjI1OCA1NC42NTItNS41NjIgOC43ODQ4LTkuMTU1OCAxNS42Mi0xMC45ODQgMjAuODkzLTIuMjMyNyA2LjQzOC0zLjEwNDcgMTMuNTkyLTIuODk3NyAyMy43NzMgMC4wODYyIDQuMjQxMiAwLjM3OTkyIDEwLjc2OSAwLjYyNjE2IDEzLjkxOGwwLjA5NTggMS4yMjQ4aDE5Ljg1OHYxOS41OTZoLTgyLjA5N3YtOS43OTgyeiIgc3Ryb2tlLXdpZHRoPSIuMTQ4NDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.79352" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="255,0,0,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3Ljg1bW0iIGhlaWdodD0iMjIzLjUxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy44NSAyMjMuNTEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjc4NTk4IC0yNS41ODYpIj4KICA8cGF0aCBkPSJtMTAwLjQgMjQ5LjA2Yy0xMS44NDQtMC43NTUyNi0yMi4zOTMtMy42Mjc3LTMzLjAxNi04Ljk5MDMtMy42Njk0LTEuODUyNC01LjkzNDYtMy4xNzE0LTkuNDQyMi01LjQ5ODQtNS44NTY2LTMuODg1NC0xMC4yNDctNy40NjU1LTE1LjQ5LTEyLjYzLTYuMjA2MS02LjExMzctMTEuMDMzLTExLjk3LTE1Ljk5LTE5LjQtMTQuNTg1LTIxLjg2Mi0yMy4zNy00OC44OTUtMjUuMjk3LTc3LjgzOS0wLjM3OTc3LTUuNzA2LTAuNDg3MTMtMTMuNjctMC4yNDg2Ni0xOC40NDcgMC4yNTQwNS01LjA4OSAxLjU2NzktMTQuMTM0IDIuODc5My0xOS44MjIgMC4xMzQ3OS0wLjU4NDY2IDAuNDQ0NTUtMS45MzUzIDAuNjg4MzUtMy4wMDE1IDAuNTM0OTMtMi4zMzkzIDAuOTE2MzQtMy42NzUyIDIuMTI0Ni03LjQ0MTIgMi44MTc4LTguNzgyNiA1LjEzOTEtMTUuMTM0IDcuOTg0Mi0yMS44NDUgMy4yMi03LjU5NTUgNy4wNzM4LTE1LjA5MiAxMy42MTktMjYuNDkxbDEuMTg0Ny0yLjA2MzVoMTUwLjY0bDEuOTI5NyAzLjM3NjdjMS4wNjEzIDEuODU3MiAyLjE1ODYgMy43OTg4IDIuNDM4NSA0LjMxNDYgMC4yNzk4NSAwLjUxNTg4IDAuNTQ5NzggMC45OTQyNCAwLjU5OTg2IDEuMDYzIDAuMjk5MTkgMC40MTA5NyAzLjc5OTEgNy4wMjIzIDUuMTk3MSA5LjgxNzQgMi4wNDA3IDQuMDggMy4xMTE5IDYuMzg1OCA0LjYxODkgOS45NDI0IDIuOTAzNSA2Ljg1MjYgNS40NDUgMTMuNzY4IDcuODM2NSAyMS4zMjMgMS41NzkgNC45ODgzIDEuNjU3OCA1LjI3OTggMi45NzU5IDExLjAwNSAxLjIxODEgNS4yOTE1IDIuNTMyMyAxNC4xMTYgMi44NzU4IDE5LjMxIDAuMTY3NDggMi41MzI3IDAuMTcwMDggMTEuMDY4IDVlLTMgMTQuNzktMS4zNjI0IDMwLjYyNi0xMC4xNzcgNTguOTIxLTI1LjU1MSA4Mi4wMTgtNC45MDkgNy4zNzUzLTkuNjg3IDEzLjE3NC0xNS45MjQgMTkuMzI3LTUuMjk3OCA1LjIyNi05Ljc2MDEgOC44NjkyLTE1LjU1MiAxMi42OTctMy41NTgxIDIuMzUxNS01LjgxODQgMy42NjY0LTkuNDQyMiA1LjQ5MjYtOS43ODg1IDQuOTMyOS0xOS4zNDkgNy43MTk5LTMwLjA3NyA4Ljc2NzctMS45NjA0IDAuMTkxNDctOS43MjA1IDAuMzQxNTUtMTEuNTY4IDAuMjIzNzN6bTYuODQ3Ni00NC45NDNjNS41OTU4IDFlLTMgMTIuMzMyIDAuODEwMDUgMTUuNjAxIDEuODczOCA0LjUwNjYgMS40NjY0IDcuOTMyIDQuNTAzNyAxMS4wNiA5LjgwNjggMS41NTUgMi42MzY2IDIuMzQ5NSA0LjAzNTIgMi44ODQ0IDUuMDc3NCAwLjk5NTc3IDEuOTQwMyAxLjI3MjQgMi4xMjY3IDMuMTU0MSAyLjEyNDggMS40NDUtMmUtMyAyLjI4My0wLjMwODQ0IDIuODQxOC0xLjA0MSAxLjE2LTEuNTIwOSAxLjExODktMy42MzE0LTAuMTg1NC05LjUwNDQtMi40OTYyLTExLjI0LTYuNzY1NC0xOC40MTktMTIuNjg0LTIxLjMzLTIuNzc3LTEuMzY1Ni04LjAzMTEtMi43NTE3LTEzLjUxMS0zLjU2NDMtMi4zMDU5LTAuMzQxOTMtNi4wODI0LTAuNzY2NC03Ljg3ODktMC44ODU1OC0wLjYxOTA1LTAuMDQxMS0xLjUwNTQtMC4xMDY3NC0xLjk2OTctMC4xNDU5NGwtMC44NDQxNy0wLjA3MTN2LTIxLjk1OGwzLjY1ODEtMC4wNjI3YzMuODkzMy0wLjA2NjggNC42NjI3LTAuMTYyNjEgNi4zMjM2LTAuNzg3NzUgMS4zODQ0LTAuNTIxMTEgMi4yNjYyLTEuMTQ4OSAzLjg0ODYtMi43NDAyIDEuMTk3LTEuMjAzOCAxLjY0MzktMS43NTQ4IDIuMTQ3NC0yLjY0ODEgMC43NjUyNy0xLjM1NzUgMS4xNzIxLTIuMzExNCAxLjQ4NDYtMy40ODA5IDAuMzI3MDgtMS4yMjM5IDAuMzI4NTUtNS44MDY2IDJlLTMgLTcuNTY2Mi0xLjMzNzUtNy4yMTY4LTQuNDY3LTE2LjAyOS0xMy44MzQtMzguOTUyLTEuMDM4OC0yLjU0MjQtMi4yNTI2LTUuNTY4OS0yLjY5NzQtNi43MjU3bC0wLjgwODU4LTIuMTAzMnYtNjMuMDI0aC02Ni45MDdsLTIuMzkyNiA0Ljc4MzZjLTcuMDk2NSAxNC4xODgtMTAuOTg3IDIyLjc0NC0xNC4xNzQgMzEuMTcyLTcuNTQ4MyAxOS45NTgtOS45OTMyIDM2LjU1OC04LjAwMzMgNTQuMzM5IDIuNzI3MiAyNC4zNjkgMTMuNzY1IDUwLjk0NSAyOS4xNDEgNzAuMTYgNC4zMjE4IDUuNDAxIDEwLjE5NSAxMS4zNSAxNS43NTEgMTUuOTU0IDUuNTAzNiA0LjU2MDUgMTIuNDA3IDkuMjYwNiAxOS44MjIgMTMuNDk2IDQuNDQxNyAyLjUzNjkgNi42MDUgMy42NzI4IDE0LjE5NSA3LjQ1MzMgMy45ODk1IDEuOTg3MiA4LjQwNzMgNC4yMjMgOS44MTczIDQuOTY4M2wyLjU2MzggMS4zNTUxIDAuMDYzNC0zNS45NzNoMS41MzE2em0tMTQuMTAxLTAuMTM4ODdjLTYuNjk0LTAuMzE3NjItMTIuNTE4LTEuMjgwNC0xNi4zMDYtMi42OTUzLTkuNTcyOC0zLjU3Ni0xNC41MjEtMTIuMzY0LTE1LjA5NC0yNi44MDYtMC4xMjY4Ny0zLjE5OSAwLjE4NDU5LTQuNzAyNSAxLjE3MzgtNS42NjY0IDAuNzAyLTAuNjg0MDMgMS4yNzA3LTAuODcwOTYgMi42NDk4LTAuODcwOTYgMS4zMTcyIDAgMS45ODM0IDAuMTk3NDcgMi4yOTQ5IDAuNjgwMjUgMC4xMDM1OCAwLjE2MDUxIDAuNDgwODMgMC45NjcxNyAwLjgzODM0IDEuNzkyNiAxLjMxMTUgMy4wMjggMy4yNjcyIDYuODkxMiA0LjE5MDUgOC4yNzc2IDEuNjczOCAyLjUxMzUgMy44MjMxIDQuNTA5NCA2LjEyMjcgNS42ODYgMi42NTE1IDEuMzU2NyAzLjEwMDUgMS40MDM2IDE3LjgxOSAxLjg2MDggNC4zNjc4IDAuMTM1NzEgOC4xNTI1IDAuMjQ2NTYgOC40MTA0IDAuMjQ2MzZoMC40Njg5OHYxNy42MzRsLTUuMjIxMy0wLjAxODljLTIuODcxNy0wLjAxMDQtNi4xNzgxLTAuMDY0My03LjM0NzQtMC4xMTk3M3ptLTM0LjM5Mi04MC43MjVjLTAuMjc1MTQtMC4wMjcyLTEuMTQ3NC0wLjExMTEtMS45Mzg1LTAuMTg2NTMtNS44ODA5LTAuNTYwNzgtMTEuOTU0LTIuNDg0MS0xNi40NDYtNS4yMDgtNi45NDQtNC4yMTE1LTEwLjQzOC0xMC4yODQtOS4zODM3LTE2LjMwNyAxLjMzOTUtNy42NDg0IDkuNzIzMS0xNC4xNSAyMS4zMjctMTYuNTQxIDMuNDE2NS0wLjcwMzY5IDUuMzU1My0wLjg4MTA4IDkuNjI5OC0wLjg4MTA4IDQuMjc0NCAwIDYuMjEzMyAwLjE3NzQgOS42Mjk4IDAuODgxMDggMTIuNDUgMi41NjQzIDIxLjA0MiA5Ljc2NzggMjEuNDczIDE4LjAwMyAwLjIwMDU4IDMuODI5NC0xLjI0ODYgNy40MzcxLTQuMjgxNCAxMC42NTktNC42MTU3IDQuOTAzMi0xMi4wODYgOC4yMDg2LTIxLjEzMSA5LjM0OTgtMS40MjExIDAuMTc5MjktNy43MzYgMC4zNDI4Ny04Ljg3OTQgMC4yMzAwMXptMTIwLjYyLTE5LjQ4MmMwLTYuOTgyNy01LjY1NzUtMTMuMzA4LTE1LjEzMi0xNi45Mi0yLjk1NTctMS4xMjY2LTYuMjg5OS0xLjkzNzYtMTAuMDY3LTIuNDQ4OC0yLjkxMDctMC4zOTM5Mi04Ljk3MDItMC4zOTM5Mi0xMS44ODEgMC04Ljc4MiAxLjE4ODUtMTUuNzYgNC4yMTE3LTIwLjM5OCA4LjgzNzYtMy4xNjQyIDMuMTU2LTQuODAyMyA2Ljc0ODItNC44MDIzIDEwLjUzMXYxLjE3MTdoNjIuMjgxeiIgc3Ryb2tlLXdpZHRoPSIuMTI1MDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.46369" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3LjQzbW0iIGhlaWdodD0iMjAzLjA5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy40MyAyMDMuMDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMS40Nzk2IC0zNy41NjkpIj4KICA8cGF0aCBkPSJtNzMuNTY0IDI0MC42MmMtMS4xNTQ5LTAuMTA4NDgtMy4xODkzLTAuNTM3MjktNC4zNDg2LTAuOTE2NjItNi42MzI5LTIuMTcwMi0xMS43OTEtNy42MDI0LTEzLjQ5LTE0LjIwNy0wLjY2OTQ4LTIuNjAyMi0wLjYyMjM1LTAuMzMzMjItMC42NjQ4Ni0zMi4wMWwtMC4wMzkxLTI5LjE0NS0xOS4wMjQtMjEuMDMyYy0xMC40NjMtMTEuNTY3LTE5Ljg2NC0yMS45NTMtMjAuODkxLTIzLjA3OS00LjE2MjQtNC41NjM2LTYuNjA4Ny04LjA5MTYtOC44MTcyLTEyLjcxNi0yLjg3NjktNi4wMjM4LTQuMzU0My0xMS44NTgtNC43MzYyLTE4LjcwMy0wLjU1NjY3LTkuOTc3NCAyLjExNy0yMC4xMiA3LjU0OTgtMjguNjQxIDUuNTc3Mi04Ljc0NjggMTMuNjgtMTUuNDIzIDIzLjM1LTE5LjI0IDExLjM3Mi00LjQ4ODUgMjQuMzQ0LTQuNDg5MyAzNS42NzMtMC4wMDIzIDE0LjQ1NCA1LjcyNDggMjUuMjM1IDE3Ljc1OCAyOS4yODkgMzIuNjkzIDIuNzE4OSAxMC4wMTUgMi4xMTQzIDIwLjk5NS0xLjY4NCAzMC41ODUtNC4xODE5IDEwLjU1OS0xMS42NjYgMTkuMTQyLTIxLjYwOCAyNC43ODItMi4zMzMgMS4zMjM2LTYuMjMyMSAzLjAyNzgtOC44MTMxIDMuODUyMi03LjkzOTkgMi41MzU5LTE2LjU1MiAzLjAxMS0yNC43NTYgMS4zNjU2LTEuNTMzNy0wLjMwNzU5LTQuNDY4My0xLjA3NjgtNS42MjAxLTEuNDczLTAuMzU2NjktMC4xMjI3MS0wLjY2OTA4LTAuMjAyNTYtMC42OTQyMS0wLjE3NzQzLTAuMDI1MSAwLjAyNTEgNC45NjI0IDUuNTgxNiAxMS4wODMgMTIuMzQ4IDYuMTIxIDYuNzY2MiAxMS4xNDYgMTIuMjg1IDExLjE2NiAxMi4yNjUgMC4wMjA1LTAuMDIwNiAwLjMzNjc5LTAuNjM1NjYgMC43MDI4Mi0xLjM2NjkgMi44NDM3LTUuNjgwOSA4LjAyMzUtOS42NjM2IDE0LjIyNi0xMC45MzggMi4wNzg5LTAuNDI3MjYgMi44NDA0LTAuNDM2NCAzMi42NzMtMC4zOTIwNiAzMS43NzggMC4wNDcyIDI5LjUwNC0xLjJlLTQgMzIuMTA2IDAuNjY5MiAyLjc3ODEgMC43MTQ3MiA1LjU4MzIgMi4xODA4IDcuOTUzNCA0LjE1NjggMy4xNDk3IDIuNjI1OSA1LjQ0MyA2LjI3MyA2LjYxMDcgMTAuNTEzbDAuMTkwMjYgMC42OTA5MSAwLjMyNzkzLTAuMzQwMDNjMS4xMDk1LTEuMTUwNSAyNC45MjMtMjcuNTY4IDI0Ljg4NS0yNy42MDYtMC4wMjU3LTAuMDI1OC0wLjI3ODcxIDAuMDM1OC0wLjU2MjE0IDAuMTM2ODctMS4xMDQ1IDAuMzkzNjctMy44MjA4IDEuMTE1MS01LjQ3MjIgMS40NTM0LTkuNDQyOSAxLjkzNDQtMTkuMDc5IDEuMTI2MS0yNy44NTEtMi4zMzYyLTExLjUxMS00LjU0MzQtMjAuODktMTMuMjUzLTI2LjE2NC0yNC4yOTUtMi44NzY5LTYuMDIzOC00LjM1NDMtMTEuODU4LTQuNzM2Mi0xOC43MDMtMC41NTY2Ni05Ljk3NzQgMi4xMTctMjAuMTIgNy41NDk4LTI4LjY0MSA1LjU3NzItOC43NDY4IDEzLjY4LTE1LjQyMyAyMy4zNS0xOS4yNCAxMS4zNzItNC40ODg1IDI0LjM0NC00LjQ4OTMgMzUuNjczLTAuMDAyMyAxNC40NTQgNS43MjQ4IDI1LjIzNSAxNy43NTggMjkuMjg5IDMyLjY5MyAyLjQzNTIgOC45NzA1IDIuMjAyOSAxOC44MjItMC42NTQ3OSAyNy43Ny0wLjgyNDM0IDIuNTgxLTIuNTI4NiA2LjQ4MDEtMy44NTIyIDguODEzMS0yLjE1MDcgMy43OTA5LTQuMDcxMiA2LjM0MS04LjEyNjUgMTAuNzktMS40MDkxIDEuNTQ1OS0xMS42OTQgMTIuOTA3LTIyLjg1NSAyNS4yNDdsLTIwLjI5MyAyMi40MzYtMC4wMzEyIDMuMDI4NS0wLjAzMTIgMy4wMjg1aDI4LjU0MnYtOC4xODczaDE4LjAxMnY0NC40NDVoLTE4LjAxMnYtOC4xODczaC0yOC41MjdsLTAuMDM5NCA5LjkxMjRjLTAuMDM4NCA5LjY3NzctMC4wNDU1IDkuOTQzNS0wLjI5ODQxIDExLjIyMy0wLjU1NTI3IDIuODA5Mi0xLjkwNDEgNS45NzQ2LTMuNTAyOSA4LjIyMDktMS4wMTMyIDEuNDIzNS0zLjI4NTggMy42OTYxLTQuNzA5MyA0LjcwOTMtMi4yNDA5IDEuNTk1LTUuMzkzIDIuOTM5Ni04LjIyMDkgMy41MDY3bC0xLjMxMDYgMC4yNjI4NS0yOS42NSAwLjAxMTNjLTE2LjMwNyA2ZS0zIC0yOS44Ni04ZS0zIC0zMC4xMTctMC4wMzI2em0tMTguNTk3LTExNy40MWM2LjYzODQtMC44OTkzOCAxMi4zMzYtMy4yMjU5IDE3LjcyLTcuMjM2IDIuMTY3OS0xLjYxNDcgNS41OTMzLTUuMDQwMSA3LjIwOC03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzgtNi45Njg4LTMuNDE4MS0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS00LjU2NzYgNS41MDMtNy4zMDYgMTEuNzktOC4zMzc2IDE5LjE0My0wLjI4ODc3IDIuMDU4MS0wLjI4ODc3IDcuMTgxOCAwIDkuMjM5OSAwLjk3ODk1IDYuOTc3MSAzLjM4NjEgMTIuNzU5IDcuNTk2OSAxOC4yNDYgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6bTEwOS44MyAwYzYuNjM4NC0wLjg5OTM4IDEyLjMzNi0zLjIyNTkgMTcuNzItNy4yMzYgMi4xNjc5LTEuNjE0NyA1LjU5MzMtNS4wNDAxIDcuMjA3OS03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzktNi45Njg4LTMuNDE4Mi0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS0zLjkxNjggNC43MTktNi42NTgyIDEwLjM5OC03Ljg0MjIgMTYuMjQ3LTAuNTgxODcgMi44NzQyLTAuNzAwNDkgNC4xNDY5LTAuNzAwNDkgNy41MTU2IDAgMy4zNjg3IDAuMTE4NjIgNC42NDE0IDAuNzAwNDkgNy41MTU2IDEuMTEwNCA1LjQ4NTIgMy41MDc2IDEwLjY2NyA3LjEwMTYgMTUuMzUgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6IiBzdHJva2Utd2lkdGg9Ii4xMTY5NiIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3Ljg1bW0iIGhlaWdodD0iMjIzLjUxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy44NSAyMjMuNTEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjc4NTk4IC0yNS41ODYpIj4KICA8cGF0aCBkPSJtMTAwLjQgMjQ5LjA2Yy0xMS44NDQtMC43NTUyNi0yMi4zOTMtMy42Mjc3LTMzLjAxNi04Ljk5MDMtMy42Njk0LTEuODUyNC01LjkzNDYtMy4xNzE0LTkuNDQyMi01LjQ5ODQtNS44NTY2LTMuODg1NC0xMC4yNDctNy40NjU1LTE1LjQ5LTEyLjYzLTYuMjA2MS02LjExMzctMTEuMDMzLTExLjk3LTE1Ljk5LTE5LjQtMTQuNTg1LTIxLjg2Mi0yMy4zNy00OC44OTUtMjUuMjk3LTc3LjgzOS0wLjM3OTc3LTUuNzA2LTAuNDg3MTMtMTMuNjctMC4yNDg2Ni0xOC40NDcgMC4yNTQwNS01LjA4OSAxLjU2NzktMTQuMTM0IDIuODc5My0xOS44MjIgMC4xMzQ3OS0wLjU4NDY2IDAuNDQ0NTUtMS45MzUzIDAuNjg4MzUtMy4wMDE1IDAuNTM0OTMtMi4zMzkzIDAuOTE2MzQtMy42NzUyIDIuMTI0Ni03LjQ0MTIgMi44MTc4LTguNzgyNiA1LjEzOTEtMTUuMTM0IDcuOTg0Mi0yMS44NDUgMy4yMi03LjU5NTUgNy4wNzM4LTE1LjA5MiAxMy42MTktMjYuNDkxbDEuMTg0Ny0yLjA2MzVoMTUwLjY0bDEuOTI5NyAzLjM3NjdjMS4wNjEzIDEuODU3MiAyLjE1ODYgMy43OTg4IDIuNDM4NSA0LjMxNDYgMC4yNzk4NSAwLjUxNTg4IDAuNTQ5NzggMC45OTQyNCAwLjU5OTg2IDEuMDYzIDAuMjk5MTkgMC40MTA5NyAzLjc5OTEgNy4wMjIzIDUuMTk3MSA5LjgxNzQgMi4wNDA3IDQuMDggMy4xMTE5IDYuMzg1OCA0LjYxODkgOS45NDI0IDIuOTAzNSA2Ljg1MjYgNS40NDUgMTMuNzY4IDcuODM2NSAyMS4zMjMgMS41NzkgNC45ODgzIDEuNjU3OCA1LjI3OTggMi45NzU5IDExLjAwNSAxLjIxODEgNS4yOTE1IDIuNTMyMyAxNC4xMTYgMi44NzU4IDE5LjMxIDAuMTY3NDggMi41MzI3IDAuMTcwMDggMTEuMDY4IDVlLTMgMTQuNzktMS4zNjI0IDMwLjYyNi0xMC4xNzcgNTguOTIxLTI1LjU1MSA4Mi4wMTgtNC45MDkgNy4zNzUzLTkuNjg3IDEzLjE3NC0xNS45MjQgMTkuMzI3LTUuMjk3OCA1LjIyNi05Ljc2MDEgOC44NjkyLTE1LjU1MiAxMi42OTctMy41NTgxIDIuMzUxNS01LjgxODQgMy42NjY0LTkuNDQyMiA1LjQ5MjYtOS43ODg1IDQuOTMyOS0xOS4zNDkgNy43MTk5LTMwLjA3NyA4Ljc2NzctMS45NjA0IDAuMTkxNDctOS43MjA1IDAuMzQxNTUtMTEuNTY4IDAuMjIzNzN6bTYuODQ3Ni00NC45NDNjNS41OTU4IDFlLTMgMTIuMzMyIDAuODEwMDUgMTUuNjAxIDEuODczOCA0LjUwNjYgMS40NjY0IDcuOTMyIDQuNTAzNyAxMS4wNiA5LjgwNjggMS41NTUgMi42MzY2IDIuMzQ5NSA0LjAzNTIgMi44ODQ0IDUuMDc3NCAwLjk5NTc3IDEuOTQwMyAxLjI3MjQgMi4xMjY3IDMuMTU0MSAyLjEyNDggMS40NDUtMmUtMyAyLjI4My0wLjMwODQ0IDIuODQxOC0xLjA0MSAxLjE2LTEuNTIwOSAxLjExODktMy42MzE0LTAuMTg1NC05LjUwNDQtMi40OTYyLTExLjI0LTYuNzY1NC0xOC40MTktMTIuNjg0LTIxLjMzLTIuNzc3LTEuMzY1Ni04LjAzMTEtMi43NTE3LTEzLjUxMS0zLjU2NDMtMi4zMDU5LTAuMzQxOTMtNi4wODI0LTAuNzY2NC03Ljg3ODktMC44ODU1OC0wLjYxOTA1LTAuMDQxMS0xLjUwNTQtMC4xMDY3NC0xLjk2OTctMC4xNDU5NGwtMC44NDQxNy0wLjA3MTN2LTIxLjk1OGwzLjY1ODEtMC4wNjI3YzMuODkzMy0wLjA2NjggNC42NjI3LTAuMTYyNjEgNi4zMjM2LTAuNzg3NzUgMS4zODQ0LTAuNTIxMTEgMi4yNjYyLTEuMTQ4OSAzLjg0ODYtMi43NDAyIDEuMTk3LTEuMjAzOCAxLjY0MzktMS43NTQ4IDIuMTQ3NC0yLjY0ODEgMC43NjUyNy0xLjM1NzUgMS4xNzIxLTIuMzExNCAxLjQ4NDYtMy40ODA5IDAuMzI3MDgtMS4yMjM5IDAuMzI4NTUtNS44MDY2IDJlLTMgLTcuNTY2Mi0xLjMzNzUtNy4yMTY4LTQuNDY3LTE2LjAyOS0xMy44MzQtMzguOTUyLTEuMDM4OC0yLjU0MjQtMi4yNTI2LTUuNTY4OS0yLjY5NzQtNi43MjU3bC0wLjgwODU4LTIuMTAzMnYtNjMuMDI0aC02Ni45MDdsLTIuMzkyNiA0Ljc4MzZjLTcuMDk2NSAxNC4xODgtMTAuOTg3IDIyLjc0NC0xNC4xNzQgMzEuMTcyLTcuNTQ4MyAxOS45NTgtOS45OTMyIDM2LjU1OC04LjAwMzMgNTQuMzM5IDIuNzI3MiAyNC4zNjkgMTMuNzY1IDUwLjk0NSAyOS4xNDEgNzAuMTYgNC4zMjE4IDUuNDAxIDEwLjE5NSAxMS4zNSAxNS43NTEgMTUuOTU0IDUuNTAzNiA0LjU2MDUgMTIuNDA3IDkuMjYwNiAxOS44MjIgMTMuNDk2IDQuNDQxNyAyLjUzNjkgNi42MDUgMy42NzI4IDE0LjE5NSA3LjQ1MzMgMy45ODk1IDEuOTg3MiA4LjQwNzMgNC4yMjMgOS44MTczIDQuOTY4M2wyLjU2MzggMS4zNTUxIDAuMDYzNC0zNS45NzNoMS41MzE2em0tMTQuMTAxLTAuMTM4ODdjLTYuNjk0LTAuMzE3NjItMTIuNTE4LTEuMjgwNC0xNi4zMDYtMi42OTUzLTkuNTcyOC0zLjU3Ni0xNC41MjEtMTIuMzY0LTE1LjA5NC0yNi44MDYtMC4xMjY4Ny0zLjE5OSAwLjE4NDU5LTQuNzAyNSAxLjE3MzgtNS42NjY0IDAuNzAyLTAuNjg0MDMgMS4yNzA3LTAuODcwOTYgMi42NDk4LTAuODcwOTYgMS4zMTcyIDAgMS45ODM0IDAuMTk3NDcgMi4yOTQ5IDAuNjgwMjUgMC4xMDM1OCAwLjE2MDUxIDAuNDgwODMgMC45NjcxNyAwLjgzODM0IDEuNzkyNiAxLjMxMTUgMy4wMjggMy4yNjcyIDYuODkxMiA0LjE5MDUgOC4yNzc2IDEuNjczOCAyLjUxMzUgMy44MjMxIDQuNTA5NCA2LjEyMjcgNS42ODYgMi42NTE1IDEuMzU2NyAzLjEwMDUgMS40MDM2IDE3LjgxOSAxLjg2MDggNC4zNjc4IDAuMTM1NzEgOC4xNTI1IDAuMjQ2NTYgOC40MTA0IDAuMjQ2MzZoMC40Njg5OHYxNy42MzRsLTUuMjIxMy0wLjAxODljLTIuODcxNy0wLjAxMDQtNi4xNzgxLTAuMDY0My03LjM0NzQtMC4xMTk3M3ptLTM0LjM5Mi04MC43MjVjLTAuMjc1MTQtMC4wMjcyLTEuMTQ3NC0wLjExMTEtMS45Mzg1LTAuMTg2NTMtNS44ODA5LTAuNTYwNzgtMTEuOTU0LTIuNDg0MS0xNi40NDYtNS4yMDgtNi45NDQtNC4yMTE1LTEwLjQzOC0xMC4yODQtOS4zODM3LTE2LjMwNyAxLjMzOTUtNy42NDg0IDkuNzIzMS0xNC4xNSAyMS4zMjctMTYuNTQxIDMuNDE2NS0wLjcwMzY5IDUuMzU1My0wLjg4MTA4IDkuNjI5OC0wLjg4MTA4IDQuMjc0NCAwIDYuMjEzMyAwLjE3NzQgOS42Mjk4IDAuODgxMDggMTIuNDUgMi41NjQzIDIxLjA0MiA5Ljc2NzggMjEuNDczIDE4LjAwMyAwLjIwMDU4IDMuODI5NC0xLjI0ODYgNy40MzcxLTQuMjgxNCAxMC42NTktNC42MTU3IDQuOTAzMi0xMi4wODYgOC4yMDg2LTIxLjEzMSA5LjM0OTgtMS40MjExIDAuMTc5MjktNy43MzYgMC4zNDI4Ny04Ljg3OTQgMC4yMzAwMXptMTIwLjYyLTE5LjQ4MmMwLTYuOTgyNy01LjY1NzUtMTMuMzA4LTE1LjEzMi0xNi45Mi0yLjk1NTctMS4xMjY2LTYuMjg5OS0xLjkzNzYtMTAuMDY3LTIuNDQ4OC0yLjkxMDctMC4zOTM5Mi04Ljk3MDItMC4zOTM5Mi0xMS44ODEgMC04Ljc4MiAxLjE4ODUtMTUuNzYgNC4yMTE3LTIwLjM5OCA4LjgzNzYtMy4xNjQyIDMuMTU2LTQuODAyMyA2Ljc0ODItNC44MDIzIDEwLjUzMXYxLjE3MTdoNjIuMjgxeiIgc3Ryb2tlLXdpZHRoPSIuMTI1MDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.46369" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="152,125,183,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTU2LjQ4bW0iIGhlaWdodD0iMjkxLjI4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1Ni40OCAyOTEuMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYuMDI0IC0zLjE0MDQpIj4KICA8cGF0aCBkPSJtNjMuMjE3IDI4NC42MnYtOS43OTgyaDE5Ljg1OGwwLjA5NTgtMS4yMjQ4YzAuMjQ2MjQtMy4xNDg5IDAuNTM5OTMtOS42NzY4IDAuNjI2MTYtMTMuOTE4IDAuMjA3LTEwLjE4MS0wLjY2NDk3LTE3LjMzNS0yLjg5NzctMjMuNzczLTEuODI4Ni01LjI3MjctNS40MjI0LTEyLjEwOC0xMC45ODQtMjAuODkzLTE1LjY0LTI0LjcwMi0yMy44MTYtMzkuNDY5LTMwLjI1OC01NC42NTItNy41MjctMTcuNzQtMTEuODYxLTM1LjE1NC0xMy4zNTUtNTMuNjY4LTAuMzY5NTYtNC41NzgyLTAuMzcxNjktMTQuODUyLTRlLTMgLTE4Ljg1NCAyLjAzNTYtMjIuMTQ5IDkuNDg4My0zMy4zMzggMjYuNDA5LTM5LjY0OCA1LjAxNzEtMS44NzEgMTEuMDQ4LTMuMzA4NyAyMC42MDMtNC45MTE4bDQuMjI5Ni0wLjcwOTYgMS4wNTQ0LTEuMDQ0MmMxLjU5MjgtMS41NzczIDIuMzI2Ni0zLjM0MjIgMi43MTgxLTYuNTM3MSAwLjE5OTg2LTEuNjMwOSAwLjIxMjA4LTQuODE2OCAwLjAxOTctNS4xMjEyLTAuMTIyMDYtMC4xOTMwNy0xLjU5NDEtMC4yMjkxMy0xMS4yODEtMC4yNzYzbC0xMS4xNC0wLjA1NDI1di0yNi4zOTNoOTAuNzA4djI2LjM5M2wtMTEuMTQgMC4wNTQyNWMtOS42ODY1IDAuMDQ3MTctMTEuMTU4IDAuMDgzMjItMTEuMjgxIDAuMjc2My0wLjE5MjQzIDAuMzA0MzktMC4xODAyIDMuNDkwMyAwLjAxOTYgNS4xMjEyIDAuMzkxNTMgMy4xOTUgMS4xMjU0IDQuOTU5OCAyLjcxODEgNi41MzcxbDEuMDU0NCAxLjA0NDIgNC4yMjk2IDAuNzA5NmM3LjU3MzUgMS4yNzA2IDEyLjQgMi4zMTkzIDE2Ljg5MiAzLjY3MDIgNS45NDgxIDEuNzg4OSAxMS4xNTEgNC4yODU0IDE0LjkzNCA3LjE2NjEgOS4xMzM0IDYuOTU0MyAxMy42NDcgMTYuOTc5IDE1LjE4NiAzMy43MjQgMC4zNjc4MSA0LjAwMiAwLjM2NTY5IDE0LjI3Ni00ZS0zIDE4Ljg1NC0xLjQ5NDQgMTguNTEzLTUuODI4IDM1LjkyOC0xMy4zNTUgNTMuNjY4LTYuNDQyMiAxNS4xODMtMTQuNjE4IDI5Ljk1LTMwLjI1OCA1NC42NTItNS41NjIgOC43ODQ4LTkuMTU1OCAxNS42Mi0xMC45ODQgMjAuODkzLTIuMjMyNyA2LjQzOC0zLjEwNDcgMTMuNTkyLTIuODk3NyAyMy43NzMgMC4wODYyIDQuMjQxMiAwLjM3OTkyIDEwLjc2OSAwLjYyNjE2IDEzLjkxOGwwLjA5NTggMS4yMjQ4aDE5Ljg1OHYxOS41OTZoLTgyLjA5N3YtOS43OTgyeiIgc3Ryb2tlLXdpZHRoPSIuMTQ4NDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.79352" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3LjQzbW0iIGhlaWdodD0iMjAzLjA5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy40MyAyMDMuMDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMS40Nzk2IC0zNy41NjkpIj4KICA8cGF0aCBkPSJtNzMuNTY0IDI0MC42MmMtMS4xNTQ5LTAuMTA4NDgtMy4xODkzLTAuNTM3MjktNC4zNDg2LTAuOTE2NjItNi42MzI5LTIuMTcwMi0xMS43OTEtNy42MDI0LTEzLjQ5LTE0LjIwNy0wLjY2OTQ4LTIuNjAyMi0wLjYyMjM1LTAuMzMzMjItMC42NjQ4Ni0zMi4wMWwtMC4wMzkxLTI5LjE0NS0xOS4wMjQtMjEuMDMyYy0xMC40NjMtMTEuNTY3LTE5Ljg2NC0yMS45NTMtMjAuODkxLTIzLjA3OS00LjE2MjQtNC41NjM2LTYuNjA4Ny04LjA5MTYtOC44MTcyLTEyLjcxNi0yLjg3NjktNi4wMjM4LTQuMzU0My0xMS44NTgtNC43MzYyLTE4LjcwMy0wLjU1NjY3LTkuOTc3NCAyLjExNy0yMC4xMiA3LjU0OTgtMjguNjQxIDUuNTc3Mi04Ljc0NjggMTMuNjgtMTUuNDIzIDIzLjM1LTE5LjI0IDExLjM3Mi00LjQ4ODUgMjQuMzQ0LTQuNDg5MyAzNS42NzMtMC4wMDIzIDE0LjQ1NCA1LjcyNDggMjUuMjM1IDE3Ljc1OCAyOS4yODkgMzIuNjkzIDIuNzE4OSAxMC4wMTUgMi4xMTQzIDIwLjk5NS0xLjY4NCAzMC41ODUtNC4xODE5IDEwLjU1OS0xMS42NjYgMTkuMTQyLTIxLjYwOCAyNC43ODItMi4zMzMgMS4zMjM2LTYuMjMyMSAzLjAyNzgtOC44MTMxIDMuODUyMi03LjkzOTkgMi41MzU5LTE2LjU1MiAzLjAxMS0yNC43NTYgMS4zNjU2LTEuNTMzNy0wLjMwNzU5LTQuNDY4My0xLjA3NjgtNS42MjAxLTEuNDczLTAuMzU2NjktMC4xMjI3MS0wLjY2OTA4LTAuMjAyNTYtMC42OTQyMS0wLjE3NzQzLTAuMDI1MSAwLjAyNTEgNC45NjI0IDUuNTgxNiAxMS4wODMgMTIuMzQ4IDYuMTIxIDYuNzY2MiAxMS4xNDYgMTIuMjg1IDExLjE2NiAxMi4yNjUgMC4wMjA1LTAuMDIwNiAwLjMzNjc5LTAuNjM1NjYgMC43MDI4Mi0xLjM2NjkgMi44NDM3LTUuNjgwOSA4LjAyMzUtOS42NjM2IDE0LjIyNi0xMC45MzggMi4wNzg5LTAuNDI3MjYgMi44NDA0LTAuNDM2NCAzMi42NzMtMC4zOTIwNiAzMS43NzggMC4wNDcyIDI5LjUwNC0xLjJlLTQgMzIuMTA2IDAuNjY5MiAyLjc3ODEgMC43MTQ3MiA1LjU4MzIgMi4xODA4IDcuOTUzNCA0LjE1NjggMy4xNDk3IDIuNjI1OSA1LjQ0MyA2LjI3MyA2LjYxMDcgMTAuNTEzbDAuMTkwMjYgMC42OTA5MSAwLjMyNzkzLTAuMzQwMDNjMS4xMDk1LTEuMTUwNSAyNC45MjMtMjcuNTY4IDI0Ljg4NS0yNy42MDYtMC4wMjU3LTAuMDI1OC0wLjI3ODcxIDAuMDM1OC0wLjU2MjE0IDAuMTM2ODctMS4xMDQ1IDAuMzkzNjctMy44MjA4IDEuMTE1MS01LjQ3MjIgMS40NTM0LTkuNDQyOSAxLjkzNDQtMTkuMDc5IDEuMTI2MS0yNy44NTEtMi4zMzYyLTExLjUxMS00LjU0MzQtMjAuODktMTMuMjUzLTI2LjE2NC0yNC4yOTUtMi44NzY5LTYuMDIzOC00LjM1NDMtMTEuODU4LTQuNzM2Mi0xOC43MDMtMC41NTY2Ni05Ljk3NzQgMi4xMTctMjAuMTIgNy41NDk4LTI4LjY0MSA1LjU3NzItOC43NDY4IDEzLjY4LTE1LjQyMyAyMy4zNS0xOS4yNCAxMS4zNzItNC40ODg1IDI0LjM0NC00LjQ4OTMgMzUuNjczLTAuMDAyMyAxNC40NTQgNS43MjQ4IDI1LjIzNSAxNy43NTggMjkuMjg5IDMyLjY5MyAyLjQzNTIgOC45NzA1IDIuMjAyOSAxOC44MjItMC42NTQ3OSAyNy43Ny0wLjgyNDM0IDIuNTgxLTIuNTI4NiA2LjQ4MDEtMy44NTIyIDguODEzMS0yLjE1MDcgMy43OTA5LTQuMDcxMiA2LjM0MS04LjEyNjUgMTAuNzktMS40MDkxIDEuNTQ1OS0xMS42OTQgMTIuOTA3LTIyLjg1NSAyNS4yNDdsLTIwLjI5MyAyMi40MzYtMC4wMzEyIDMuMDI4NS0wLjAzMTIgMy4wMjg1aDI4LjU0MnYtOC4xODczaDE4LjAxMnY0NC40NDVoLTE4LjAxMnYtOC4xODczaC0yOC41MjdsLTAuMDM5NCA5LjkxMjRjLTAuMDM4NCA5LjY3NzctMC4wNDU1IDkuOTQzNS0wLjI5ODQxIDExLjIyMy0wLjU1NTI3IDIuODA5Mi0xLjkwNDEgNS45NzQ2LTMuNTAyOSA4LjIyMDktMS4wMTMyIDEuNDIzNS0zLjI4NTggMy42OTYxLTQuNzA5MyA0LjcwOTMtMi4yNDA5IDEuNTk1LTUuMzkzIDIuOTM5Ni04LjIyMDkgMy41MDY3bC0xLjMxMDYgMC4yNjI4NS0yOS42NSAwLjAxMTNjLTE2LjMwNyA2ZS0zIC0yOS44Ni04ZS0zIC0zMC4xMTctMC4wMzI2em0tMTguNTk3LTExNy40MWM2LjYzODQtMC44OTkzOCAxMi4zMzYtMy4yMjU5IDE3LjcyLTcuMjM2IDIuMTY3OS0xLjYxNDcgNS41OTMzLTUuMDQwMSA3LjIwOC03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzgtNi45Njg4LTMuNDE4MS0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS00LjU2NzYgNS41MDMtNy4zMDYgMTEuNzktOC4zMzc2IDE5LjE0My0wLjI4ODc3IDIuMDU4MS0wLjI4ODc3IDcuMTgxOCAwIDkuMjM5OSAwLjk3ODk1IDYuOTc3MSAzLjM4NjEgMTIuNzU5IDcuNTk2OSAxOC4yNDYgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6bTEwOS44MyAwYzYuNjM4NC0wLjg5OTM4IDEyLjMzNi0zLjIyNTkgMTcuNzItNy4yMzYgMi4xNjc5LTEuNjE0NyA1LjU5MzMtNS4wNDAxIDcuMjA3OS03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzktNi45Njg4LTMuNDE4Mi0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS0zLjkxNjggNC43MTktNi42NTgyIDEwLjM5OC03Ljg0MjIgMTYuMjQ3LTAuNTgxODcgMi44NzQyLTAuNzAwNDkgNC4xNDY5LTAuNzAwNDkgNy41MTU2IDAgMy4zNjg3IDAuMTE4NjIgNC42NDE0IDAuNzAwNDkgNy41MTU2IDEuMTEwNCA1LjQ4NTIgMy41MDc2IDEwLjY2NyA3LjEwMTYgMTUuMzUgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6IiBzdHJva2Utd2lkdGg9Ii4xMTY5NiIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3Ljg1bW0iIGhlaWdodD0iMjIzLjUxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy44NSAyMjMuNTEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjc4NTk4IC0yNS41ODYpIj4KICA8cGF0aCBkPSJtMTAwLjQgMjQ5LjA2Yy0xMS44NDQtMC43NTUyNi0yMi4zOTMtMy42Mjc3LTMzLjAxNi04Ljk5MDMtMy42Njk0LTEuODUyNC01LjkzNDYtMy4xNzE0LTkuNDQyMi01LjQ5ODQtNS44NTY2LTMuODg1NC0xMC4yNDctNy40NjU1LTE1LjQ5LTEyLjYzLTYuMjA2MS02LjExMzctMTEuMDMzLTExLjk3LTE1Ljk5LTE5LjQtMTQuNTg1LTIxLjg2Mi0yMy4zNy00OC44OTUtMjUuMjk3LTc3LjgzOS0wLjM3OTc3LTUuNzA2LTAuNDg3MTMtMTMuNjctMC4yNDg2Ni0xOC40NDcgMC4yNTQwNS01LjA4OSAxLjU2NzktMTQuMTM0IDIuODc5My0xOS44MjIgMC4xMzQ3OS0wLjU4NDY2IDAuNDQ0NTUtMS45MzUzIDAuNjg4MzUtMy4wMDE1IDAuNTM0OTMtMi4zMzkzIDAuOTE2MzQtMy42NzUyIDIuMTI0Ni03LjQ0MTIgMi44MTc4LTguNzgyNiA1LjEzOTEtMTUuMTM0IDcuOTg0Mi0yMS44NDUgMy4yMi03LjU5NTUgNy4wNzM4LTE1LjA5MiAxMy42MTktMjYuNDkxbDEuMTg0Ny0yLjA2MzVoMTUwLjY0bDEuOTI5NyAzLjM3NjdjMS4wNjEzIDEuODU3MiAyLjE1ODYgMy43OTg4IDIuNDM4NSA0LjMxNDYgMC4yNzk4NSAwLjUxNTg4IDAuNTQ5NzggMC45OTQyNCAwLjU5OTg2IDEuMDYzIDAuMjk5MTkgMC40MTA5NyAzLjc5OTEgNy4wMjIzIDUuMTk3MSA5LjgxNzQgMi4wNDA3IDQuMDggMy4xMTE5IDYuMzg1OCA0LjYxODkgOS45NDI0IDIuOTAzNSA2Ljg1MjYgNS40NDUgMTMuNzY4IDcuODM2NSAyMS4zMjMgMS41NzkgNC45ODgzIDEuNjU3OCA1LjI3OTggMi45NzU5IDExLjAwNSAxLjIxODEgNS4yOTE1IDIuNTMyMyAxNC4xMTYgMi44NzU4IDE5LjMxIDAuMTY3NDggMi41MzI3IDAuMTcwMDggMTEuMDY4IDVlLTMgMTQuNzktMS4zNjI0IDMwLjYyNi0xMC4xNzcgNTguOTIxLTI1LjU1MSA4Mi4wMTgtNC45MDkgNy4zNzUzLTkuNjg3IDEzLjE3NC0xNS45MjQgMTkuMzI3LTUuMjk3OCA1LjIyNi05Ljc2MDEgOC44NjkyLTE1LjU1MiAxMi42OTctMy41NTgxIDIuMzUxNS01LjgxODQgMy42NjY0LTkuNDQyMiA1LjQ5MjYtOS43ODg1IDQuOTMyOS0xOS4zNDkgNy43MTk5LTMwLjA3NyA4Ljc2NzctMS45NjA0IDAuMTkxNDctOS43MjA1IDAuMzQxNTUtMTEuNTY4IDAuMjIzNzN6bTYuODQ3Ni00NC45NDNjNS41OTU4IDFlLTMgMTIuMzMyIDAuODEwMDUgMTUuNjAxIDEuODczOCA0LjUwNjYgMS40NjY0IDcuOTMyIDQuNTAzNyAxMS4wNiA5LjgwNjggMS41NTUgMi42MzY2IDIuMzQ5NSA0LjAzNTIgMi44ODQ0IDUuMDc3NCAwLjk5NTc3IDEuOTQwMyAxLjI3MjQgMi4xMjY3IDMuMTU0MSAyLjEyNDggMS40NDUtMmUtMyAyLjI4My0wLjMwODQ0IDIuODQxOC0xLjA0MSAxLjE2LTEuNTIwOSAxLjExODktMy42MzE0LTAuMTg1NC05LjUwNDQtMi40OTYyLTExLjI0LTYuNzY1NC0xOC40MTktMTIuNjg0LTIxLjMzLTIuNzc3LTEuMzY1Ni04LjAzMTEtMi43NTE3LTEzLjUxMS0zLjU2NDMtMi4zMDU5LTAuMzQxOTMtNi4wODI0LTAuNzY2NC03Ljg3ODktMC44ODU1OC0wLjYxOTA1LTAuMDQxMS0xLjUwNTQtMC4xMDY3NC0xLjk2OTctMC4xNDU5NGwtMC44NDQxNy0wLjA3MTN2LTIxLjk1OGwzLjY1ODEtMC4wNjI3YzMuODkzMy0wLjA2NjggNC42NjI3LTAuMTYyNjEgNi4zMjM2LTAuNzg3NzUgMS4zODQ0LTAuNTIxMTEgMi4yNjYyLTEuMTQ4OSAzLjg0ODYtMi43NDAyIDEuMTk3LTEuMjAzOCAxLjY0MzktMS43NTQ4IDIuMTQ3NC0yLjY0ODEgMC43NjUyNy0xLjM1NzUgMS4xNzIxLTIuMzExNCAxLjQ4NDYtMy40ODA5IDAuMzI3MDgtMS4yMjM5IDAuMzI4NTUtNS44MDY2IDJlLTMgLTcuNTY2Mi0xLjMzNzUtNy4yMTY4LTQuNDY3LTE2LjAyOS0xMy44MzQtMzguOTUyLTEuMDM4OC0yLjU0MjQtMi4yNTI2LTUuNTY4OS0yLjY5NzQtNi43MjU3bC0wLjgwODU4LTIuMTAzMnYtNjMuMDI0aC02Ni45MDdsLTIuMzkyNiA0Ljc4MzZjLTcuMDk2NSAxNC4xODgtMTAuOTg3IDIyLjc0NC0xNC4xNzQgMzEuMTcyLTcuNTQ4MyAxOS45NTgtOS45OTMyIDM2LjU1OC04LjAwMzMgNTQuMzM5IDIuNzI3MiAyNC4zNjkgMTMuNzY1IDUwLjk0NSAyOS4xNDEgNzAuMTYgNC4zMjE4IDUuNDAxIDEwLjE5NSAxMS4zNSAxNS43NTEgMTUuOTU0IDUuNTAzNiA0LjU2MDUgMTIuNDA3IDkuMjYwNiAxOS44MjIgMTMuNDk2IDQuNDQxNyAyLjUzNjkgNi42MDUgMy42NzI4IDE0LjE5NSA3LjQ1MzMgMy45ODk1IDEuOTg3MiA4LjQwNzMgNC4yMjMgOS44MTczIDQuOTY4M2wyLjU2MzggMS4zNTUxIDAuMDYzNC0zNS45NzNoMS41MzE2em0tMTQuMTAxLTAuMTM4ODdjLTYuNjk0LTAuMzE3NjItMTIuNTE4LTEuMjgwNC0xNi4zMDYtMi42OTUzLTkuNTcyOC0zLjU3Ni0xNC41MjEtMTIuMzY0LTE1LjA5NC0yNi44MDYtMC4xMjY4Ny0zLjE5OSAwLjE4NDU5LTQuNzAyNSAxLjE3MzgtNS42NjY0IDAuNzAyLTAuNjg0MDMgMS4yNzA3LTAuODcwOTYgMi42NDk4LTAuODcwOTYgMS4zMTcyIDAgMS45ODM0IDAuMTk3NDcgMi4yOTQ5IDAuNjgwMjUgMC4xMDM1OCAwLjE2MDUxIDAuNDgwODMgMC45NjcxNyAwLjgzODM0IDEuNzkyNiAxLjMxMTUgMy4wMjggMy4yNjcyIDYuODkxMiA0LjE5MDUgOC4yNzc2IDEuNjczOCAyLjUxMzUgMy44MjMxIDQuNTA5NCA2LjEyMjcgNS42ODYgMi42NTE1IDEuMzU2NyAzLjEwMDUgMS40MDM2IDE3LjgxOSAxLjg2MDggNC4zNjc4IDAuMTM1NzEgOC4xNTI1IDAuMjQ2NTYgOC40MTA0IDAuMjQ2MzZoMC40Njg5OHYxNy42MzRsLTUuMjIxMy0wLjAxODljLTIuODcxNy0wLjAxMDQtNi4xNzgxLTAuMDY0My03LjM0NzQtMC4xMTk3M3ptLTM0LjM5Mi04MC43MjVjLTAuMjc1MTQtMC4wMjcyLTEuMTQ3NC0wLjExMTEtMS45Mzg1LTAuMTg2NTMtNS44ODA5LTAuNTYwNzgtMTEuOTU0LTIuNDg0MS0xNi40NDYtNS4yMDgtNi45NDQtNC4yMTE1LTEwLjQzOC0xMC4yODQtOS4zODM3LTE2LjMwNyAxLjMzOTUtNy42NDg0IDkuNzIzMS0xNC4xNSAyMS4zMjctMTYuNTQxIDMuNDE2NS0wLjcwMzY5IDUuMzU1My0wLjg4MTA4IDkuNjI5OC0wLjg4MTA4IDQuMjc0NCAwIDYuMjEzMyAwLjE3NzQgOS42Mjk4IDAuODgxMDggMTIuNDUgMi41NjQzIDIxLjA0MiA5Ljc2NzggMjEuNDczIDE4LjAwMyAwLjIwMDU4IDMuODI5NC0xLjI0ODYgNy40MzcxLTQuMjgxNCAxMC42NTktNC42MTU3IDQuOTAzMi0xMi4wODYgOC4yMDg2LTIxLjEzMSA5LjM0OTgtMS40MjExIDAuMTc5MjktNy43MzYgMC4zNDI4Ny04Ljg3OTQgMC4yMzAwMXptMTIwLjYyLTE5LjQ4MmMwLTYuOTgyNy01LjY1NzUtMTMuMzA4LTE1LjEzMi0xNi45Mi0yLjk1NTctMS4xMjY2LTYuMjg5OS0xLjkzNzYtMTAuMDY3LTIuNDQ4OC0yLjkxMDctMC4zOTM5Mi04Ljk3MDItMC4zOTM5Mi0xMS44ODEgMC04Ljc4MiAxLjE4ODUtMTUuNzYgNC4yMTE3LTIwLjM5OCA4LjgzNzYtMy4xNjQyIDMuMTU2LTQuODAyMyA2Ljc0ODItNC44MDIzIDEwLjUzMXYxLjE3MTdoNjIuMjgxeiIgc3Ryb2tlLXdpZHRoPSIuMTI1MDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.46369" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="36" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,207,80,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="37" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTU2LjQ4bW0iIGhlaWdodD0iMjkxLjI4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1Ni40OCAyOTEuMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYuMDI0IC0zLjE0MDQpIj4KICA8cGF0aCBkPSJtNjMuMjE3IDI4NC42MnYtOS43OTgyaDE5Ljg1OGwwLjA5NTgtMS4yMjQ4YzAuMjQ2MjQtMy4xNDg5IDAuNTM5OTMtOS42NzY4IDAuNjI2MTYtMTMuOTE4IDAuMjA3LTEwLjE4MS0wLjY2NDk3LTE3LjMzNS0yLjg5NzctMjMuNzczLTEuODI4Ni01LjI3MjctNS40MjI0LTEyLjEwOC0xMC45ODQtMjAuODkzLTE1LjY0LTI0LjcwMi0yMy44MTYtMzkuNDY5LTMwLjI1OC01NC42NTItNy41MjctMTcuNzQtMTEuODYxLTM1LjE1NC0xMy4zNTUtNTMuNjY4LTAuMzY5NTYtNC41NzgyLTAuMzcxNjktMTQuODUyLTRlLTMgLTE4Ljg1NCAyLjAzNTYtMjIuMTQ5IDkuNDg4My0zMy4zMzggMjYuNDA5LTM5LjY0OCA1LjAxNzEtMS44NzEgMTEuMDQ4LTMuMzA4NyAyMC42MDMtNC45MTE4bDQuMjI5Ni0wLjcwOTYgMS4wNTQ0LTEuMDQ0MmMxLjU5MjgtMS41NzczIDIuMzI2Ni0zLjM0MjIgMi43MTgxLTYuNTM3MSAwLjE5OTg2LTEuNjMwOSAwLjIxMjA4LTQuODE2OCAwLjAxOTctNS4xMjEyLTAuMTIyMDYtMC4xOTMwNy0xLjU5NDEtMC4yMjkxMy0xMS4yODEtMC4yNzYzbC0xMS4xNC0wLjA1NDI1di0yNi4zOTNoOTAuNzA4djI2LjM5M2wtMTEuMTQgMC4wNTQyNWMtOS42ODY1IDAuMDQ3MTctMTEuMTU4IDAuMDgzMjItMTEuMjgxIDAuMjc2My0wLjE5MjQzIDAuMzA0MzktMC4xODAyIDMuNDkwMyAwLjAxOTYgNS4xMjEyIDAuMzkxNTMgMy4xOTUgMS4xMjU0IDQuOTU5OCAyLjcxODEgNi41MzcxbDEuMDU0NCAxLjA0NDIgNC4yMjk2IDAuNzA5NmM3LjU3MzUgMS4yNzA2IDEyLjQgMi4zMTkzIDE2Ljg5MiAzLjY3MDIgNS45NDgxIDEuNzg4OSAxMS4xNTEgNC4yODU0IDE0LjkzNCA3LjE2NjEgOS4xMzM0IDYuOTU0MyAxMy42NDcgMTYuOTc5IDE1LjE4NiAzMy43MjQgMC4zNjc4MSA0LjAwMiAwLjM2NTY5IDE0LjI3Ni00ZS0zIDE4Ljg1NC0xLjQ5NDQgMTguNTEzLTUuODI4IDM1LjkyOC0xMy4zNTUgNTMuNjY4LTYuNDQyMiAxNS4xODMtMTQuNjE4IDI5Ljk1LTMwLjI1OCA1NC42NTItNS41NjIgOC43ODQ4LTkuMTU1OCAxNS42Mi0xMC45ODQgMjAuODkzLTIuMjMyNyA2LjQzOC0zLjEwNDcgMTMuNTkyLTIuODk3NyAyMy43NzMgMC4wODYyIDQuMjQxMiAwLjM3OTkyIDEwLjc2OSAwLjYyNjE2IDEzLjkxOGwwLjA5NTggMS4yMjQ4aDE5Ljg1OHYxOS41OTZoLTgyLjA5N3YtOS43OTgyeiIgc3Ryb2tlLXdpZHRoPSIuMTQ4NDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.79352" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="38" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3LjQzbW0iIGhlaWdodD0iMjAzLjA5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy40MyAyMDMuMDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMS40Nzk2IC0zNy41NjkpIj4KICA8cGF0aCBkPSJtNzMuNTY0IDI0MC42MmMtMS4xNTQ5LTAuMTA4NDgtMy4xODkzLTAuNTM3MjktNC4zNDg2LTAuOTE2NjItNi42MzI5LTIuMTcwMi0xMS43OTEtNy42MDI0LTEzLjQ5LTE0LjIwNy0wLjY2OTQ4LTIuNjAyMi0wLjYyMjM1LTAuMzMzMjItMC42NjQ4Ni0zMi4wMWwtMC4wMzkxLTI5LjE0NS0xOS4wMjQtMjEuMDMyYy0xMC40NjMtMTEuNTY3LTE5Ljg2NC0yMS45NTMtMjAuODkxLTIzLjA3OS00LjE2MjQtNC41NjM2LTYuNjA4Ny04LjA5MTYtOC44MTcyLTEyLjcxNi0yLjg3NjktNi4wMjM4LTQuMzU0My0xMS44NTgtNC43MzYyLTE4LjcwMy0wLjU1NjY3LTkuOTc3NCAyLjExNy0yMC4xMiA3LjU0OTgtMjguNjQxIDUuNTc3Mi04Ljc0NjggMTMuNjgtMTUuNDIzIDIzLjM1LTE5LjI0IDExLjM3Mi00LjQ4ODUgMjQuMzQ0LTQuNDg5MyAzNS42NzMtMC4wMDIzIDE0LjQ1NCA1LjcyNDggMjUuMjM1IDE3Ljc1OCAyOS4yODkgMzIuNjkzIDIuNzE4OSAxMC4wMTUgMi4xMTQzIDIwLjk5NS0xLjY4NCAzMC41ODUtNC4xODE5IDEwLjU1OS0xMS42NjYgMTkuMTQyLTIxLjYwOCAyNC43ODItMi4zMzMgMS4zMjM2LTYuMjMyMSAzLjAyNzgtOC44MTMxIDMuODUyMi03LjkzOTkgMi41MzU5LTE2LjU1MiAzLjAxMS0yNC43NTYgMS4zNjU2LTEuNTMzNy0wLjMwNzU5LTQuNDY4My0xLjA3NjgtNS42MjAxLTEuNDczLTAuMzU2NjktMC4xMjI3MS0wLjY2OTA4LTAuMjAyNTYtMC42OTQyMS0wLjE3NzQzLTAuMDI1MSAwLjAyNTEgNC45NjI0IDUuNTgxNiAxMS4wODMgMTIuMzQ4IDYuMTIxIDYuNzY2MiAxMS4xNDYgMTIuMjg1IDExLjE2NiAxMi4yNjUgMC4wMjA1LTAuMDIwNiAwLjMzNjc5LTAuNjM1NjYgMC43MDI4Mi0xLjM2NjkgMi44NDM3LTUuNjgwOSA4LjAyMzUtOS42NjM2IDE0LjIyNi0xMC45MzggMi4wNzg5LTAuNDI3MjYgMi44NDA0LTAuNDM2NCAzMi42NzMtMC4zOTIwNiAzMS43NzggMC4wNDcyIDI5LjUwNC0xLjJlLTQgMzIuMTA2IDAuNjY5MiAyLjc3ODEgMC43MTQ3MiA1LjU4MzIgMi4xODA4IDcuOTUzNCA0LjE1NjggMy4xNDk3IDIuNjI1OSA1LjQ0MyA2LjI3MyA2LjYxMDcgMTAuNTEzbDAuMTkwMjYgMC42OTA5MSAwLjMyNzkzLTAuMzQwMDNjMS4xMDk1LTEuMTUwNSAyNC45MjMtMjcuNTY4IDI0Ljg4NS0yNy42MDYtMC4wMjU3LTAuMDI1OC0wLjI3ODcxIDAuMDM1OC0wLjU2MjE0IDAuMTM2ODctMS4xMDQ1IDAuMzkzNjctMy44MjA4IDEuMTE1MS01LjQ3MjIgMS40NTM0LTkuNDQyOSAxLjkzNDQtMTkuMDc5IDEuMTI2MS0yNy44NTEtMi4zMzYyLTExLjUxMS00LjU0MzQtMjAuODktMTMuMjUzLTI2LjE2NC0yNC4yOTUtMi44NzY5LTYuMDIzOC00LjM1NDMtMTEuODU4LTQuNzM2Mi0xOC43MDMtMC41NTY2Ni05Ljk3NzQgMi4xMTctMjAuMTIgNy41NDk4LTI4LjY0MSA1LjU3NzItOC43NDY4IDEzLjY4LTE1LjQyMyAyMy4zNS0xOS4yNCAxMS4zNzItNC40ODg1IDI0LjM0NC00LjQ4OTMgMzUuNjczLTAuMDAyMyAxNC40NTQgNS43MjQ4IDI1LjIzNSAxNy43NTggMjkuMjg5IDMyLjY5MyAyLjQzNTIgOC45NzA1IDIuMjAyOSAxOC44MjItMC42NTQ3OSAyNy43Ny0wLjgyNDM0IDIuNTgxLTIuNTI4NiA2LjQ4MDEtMy44NTIyIDguODEzMS0yLjE1MDcgMy43OTA5LTQuMDcxMiA2LjM0MS04LjEyNjUgMTAuNzktMS40MDkxIDEuNTQ1OS0xMS42OTQgMTIuOTA3LTIyLjg1NSAyNS4yNDdsLTIwLjI5MyAyMi40MzYtMC4wMzEyIDMuMDI4NS0wLjAzMTIgMy4wMjg1aDI4LjU0MnYtOC4xODczaDE4LjAxMnY0NC40NDVoLTE4LjAxMnYtOC4xODczaC0yOC41MjdsLTAuMDM5NCA5LjkxMjRjLTAuMDM4NCA5LjY3NzctMC4wNDU1IDkuOTQzNS0wLjI5ODQxIDExLjIyMy0wLjU1NTI3IDIuODA5Mi0xLjkwNDEgNS45NzQ2LTMuNTAyOSA4LjIyMDktMS4wMTMyIDEuNDIzNS0zLjI4NTggMy42OTYxLTQuNzA5MyA0LjcwOTMtMi4yNDA5IDEuNTk1LTUuMzkzIDIuOTM5Ni04LjIyMDkgMy41MDY3bC0xLjMxMDYgMC4yNjI4NS0yOS42NSAwLjAxMTNjLTE2LjMwNyA2ZS0zIC0yOS44Ni04ZS0zIC0zMC4xMTctMC4wMzI2em0tMTguNTk3LTExNy40MWM2LjYzODQtMC44OTkzOCAxMi4zMzYtMy4yMjU5IDE3LjcyLTcuMjM2IDIuMTY3OS0xLjYxNDcgNS41OTMzLTUuMDQwMSA3LjIwOC03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzgtNi45Njg4LTMuNDE4MS0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS00LjU2NzYgNS41MDMtNy4zMDYgMTEuNzktOC4zMzc2IDE5LjE0My0wLjI4ODc3IDIuMDU4MS0wLjI4ODc3IDcuMTgxOCAwIDkuMjM5OSAwLjk3ODk1IDYuOTc3MSAzLjM4NjEgMTIuNzU5IDcuNTk2OSAxOC4yNDYgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6bTEwOS44MyAwYzYuNjM4NC0wLjg5OTM4IDEyLjMzNi0zLjIyNTkgMTcuNzItNy4yMzYgMi4xNjc5LTEuNjE0NyA1LjU5MzMtNS4wNDAxIDcuMjA3OS03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzktNi45Njg4LTMuNDE4Mi0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS0zLjkxNjggNC43MTktNi42NTgyIDEwLjM5OC03Ljg0MjIgMTYuMjQ3LTAuNTgxODcgMi44NzQyLTAuNzAwNDkgNC4xNDY5LTAuNzAwNDkgNy41MTU2IDAgMy4zNjg3IDAuMTE4NjIgNC42NDE0IDAuNzAwNDkgNy41MTU2IDEuMTEwNCA1LjQ4NTIgMy41MDc2IDEwLjY2NyA3LjEwMTYgMTUuMzUgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6IiBzdHJva2Utd2lkdGg9Ii4xMTY5NiIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="39" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3Ljg1bW0iIGhlaWdodD0iMjIzLjUxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy44NSAyMjMuNTEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjc4NTk4IC0yNS41ODYpIj4KICA8cGF0aCBkPSJtMTAwLjQgMjQ5LjA2Yy0xMS44NDQtMC43NTUyNi0yMi4zOTMtMy42Mjc3LTMzLjAxNi04Ljk5MDMtMy42Njk0LTEuODUyNC01LjkzNDYtMy4xNzE0LTkuNDQyMi01LjQ5ODQtNS44NTY2LTMuODg1NC0xMC4yNDctNy40NjU1LTE1LjQ5LTEyLjYzLTYuMjA2MS02LjExMzctMTEuMDMzLTExLjk3LTE1Ljk5LTE5LjQtMTQuNTg1LTIxLjg2Mi0yMy4zNy00OC44OTUtMjUuMjk3LTc3LjgzOS0wLjM3OTc3LTUuNzA2LTAuNDg3MTMtMTMuNjctMC4yNDg2Ni0xOC40NDcgMC4yNTQwNS01LjA4OSAxLjU2NzktMTQuMTM0IDIuODc5My0xOS44MjIgMC4xMzQ3OS0wLjU4NDY2IDAuNDQ0NTUtMS45MzUzIDAuNjg4MzUtMy4wMDE1IDAuNTM0OTMtMi4zMzkzIDAuOTE2MzQtMy42NzUyIDIuMTI0Ni03LjQ0MTIgMi44MTc4LTguNzgyNiA1LjEzOTEtMTUuMTM0IDcuOTg0Mi0yMS44NDUgMy4yMi03LjU5NTUgNy4wNzM4LTE1LjA5MiAxMy42MTktMjYuNDkxbDEuMTg0Ny0yLjA2MzVoMTUwLjY0bDEuOTI5NyAzLjM3NjdjMS4wNjEzIDEuODU3MiAyLjE1ODYgMy43OTg4IDIuNDM4NSA0LjMxNDYgMC4yNzk4NSAwLjUxNTg4IDAuNTQ5NzggMC45OTQyNCAwLjU5OTg2IDEuMDYzIDAuMjk5MTkgMC40MTA5NyAzLjc5OTEgNy4wMjIzIDUuMTk3MSA5LjgxNzQgMi4wNDA3IDQuMDggMy4xMTE5IDYuMzg1OCA0LjYxODkgOS45NDI0IDIuOTAzNSA2Ljg1MjYgNS40NDUgMTMuNzY4IDcuODM2NSAyMS4zMjMgMS41NzkgNC45ODgzIDEuNjU3OCA1LjI3OTggMi45NzU5IDExLjAwNSAxLjIxODEgNS4yOTE1IDIuNTMyMyAxNC4xMTYgMi44NzU4IDE5LjMxIDAuMTY3NDggMi41MzI3IDAuMTcwMDggMTEuMDY4IDVlLTMgMTQuNzktMS4zNjI0IDMwLjYyNi0xMC4xNzcgNTguOTIxLTI1LjU1MSA4Mi4wMTgtNC45MDkgNy4zNzUzLTkuNjg3IDEzLjE3NC0xNS45MjQgMTkuMzI3LTUuMjk3OCA1LjIyNi05Ljc2MDEgOC44NjkyLTE1LjU1MiAxMi42OTctMy41NTgxIDIuMzUxNS01LjgxODQgMy42NjY0LTkuNDQyMiA1LjQ5MjYtOS43ODg1IDQuOTMyOS0xOS4zNDkgNy43MTk5LTMwLjA3NyA4Ljc2NzctMS45NjA0IDAuMTkxNDctOS43MjA1IDAuMzQxNTUtMTEuNTY4IDAuMjIzNzN6bTYuODQ3Ni00NC45NDNjNS41OTU4IDFlLTMgMTIuMzMyIDAuODEwMDUgMTUuNjAxIDEuODczOCA0LjUwNjYgMS40NjY0IDcuOTMyIDQuNTAzNyAxMS4wNiA5LjgwNjggMS41NTUgMi42MzY2IDIuMzQ5NSA0LjAzNTIgMi44ODQ0IDUuMDc3NCAwLjk5NTc3IDEuOTQwMyAxLjI3MjQgMi4xMjY3IDMuMTU0MSAyLjEyNDggMS40NDUtMmUtMyAyLjI4My0wLjMwODQ0IDIuODQxOC0xLjA0MSAxLjE2LTEuNTIwOSAxLjExODktMy42MzE0LTAuMTg1NC05LjUwNDQtMi40OTYyLTExLjI0LTYuNzY1NC0xOC40MTktMTIuNjg0LTIxLjMzLTIuNzc3LTEuMzY1Ni04LjAzMTEtMi43NTE3LTEzLjUxMS0zLjU2NDMtMi4zMDU5LTAuMzQxOTMtNi4wODI0LTAuNzY2NC03Ljg3ODktMC44ODU1OC0wLjYxOTA1LTAuMDQxMS0xLjUwNTQtMC4xMDY3NC0xLjk2OTctMC4xNDU5NGwtMC44NDQxNy0wLjA3MTN2LTIxLjk1OGwzLjY1ODEtMC4wNjI3YzMuODkzMy0wLjA2NjggNC42NjI3LTAuMTYyNjEgNi4zMjM2LTAuNzg3NzUgMS4zODQ0LTAuNTIxMTEgMi4yNjYyLTEuMTQ4OSAzLjg0ODYtMi43NDAyIDEuMTk3LTEuMjAzOCAxLjY0MzktMS43NTQ4IDIuMTQ3NC0yLjY0ODEgMC43NjUyNy0xLjM1NzUgMS4xNzIxLTIuMzExNCAxLjQ4NDYtMy40ODA5IDAuMzI3MDgtMS4yMjM5IDAuMzI4NTUtNS44MDY2IDJlLTMgLTcuNTY2Mi0xLjMzNzUtNy4yMTY4LTQuNDY3LTE2LjAyOS0xMy44MzQtMzguOTUyLTEuMDM4OC0yLjU0MjQtMi4yNTI2LTUuNTY4OS0yLjY5NzQtNi43MjU3bC0wLjgwODU4LTIuMTAzMnYtNjMuMDI0aC02Ni45MDdsLTIuMzkyNiA0Ljc4MzZjLTcuMDk2NSAxNC4xODgtMTAuOTg3IDIyLjc0NC0xNC4xNzQgMzEuMTcyLTcuNTQ4MyAxOS45NTgtOS45OTMyIDM2LjU1OC04LjAwMzMgNTQuMzM5IDIuNzI3MiAyNC4zNjkgMTMuNzY1IDUwLjk0NSAyOS4xNDEgNzAuMTYgNC4zMjE4IDUuNDAxIDEwLjE5NSAxMS4zNSAxNS43NTEgMTUuOTU0IDUuNTAzNiA0LjU2MDUgMTIuNDA3IDkuMjYwNiAxOS44MjIgMTMuNDk2IDQuNDQxNyAyLjUzNjkgNi42MDUgMy42NzI4IDE0LjE5NSA3LjQ1MzMgMy45ODk1IDEuOTg3MiA4LjQwNzMgNC4yMjMgOS44MTczIDQuOTY4M2wyLjU2MzggMS4zNTUxIDAuMDYzNC0zNS45NzNoMS41MzE2em0tMTQuMTAxLTAuMTM4ODdjLTYuNjk0LTAuMzE3NjItMTIuNTE4LTEuMjgwNC0xNi4zMDYtMi42OTUzLTkuNTcyOC0zLjU3Ni0xNC41MjEtMTIuMzY0LTE1LjA5NC0yNi44MDYtMC4xMjY4Ny0zLjE5OSAwLjE4NDU5LTQuNzAyNSAxLjE3MzgtNS42NjY0IDAuNzAyLTAuNjg0MDMgMS4yNzA3LTAuODcwOTYgMi42NDk4LTAuODcwOTYgMS4zMTcyIDAgMS45ODM0IDAuMTk3NDcgMi4yOTQ5IDAuNjgwMjUgMC4xMDM1OCAwLjE2MDUxIDAuNDgwODMgMC45NjcxNyAwLjgzODM0IDEuNzkyNiAxLjMxMTUgMy4wMjggMy4yNjcyIDYuODkxMiA0LjE5MDUgOC4yNzc2IDEuNjczOCAyLjUxMzUgMy44MjMxIDQuNTA5NCA2LjEyMjcgNS42ODYgMi42NTE1IDEuMzU2NyAzLjEwMDUgMS40MDM2IDE3LjgxOSAxLjg2MDggNC4zNjc4IDAuMTM1NzEgOC4xNTI1IDAuMjQ2NTYgOC40MTA0IDAuMjQ2MzZoMC40Njg5OHYxNy42MzRsLTUuMjIxMy0wLjAxODljLTIuODcxNy0wLjAxMDQtNi4xNzgxLTAuMDY0My03LjM0NzQtMC4xMTk3M3ptLTM0LjM5Mi04MC43MjVjLTAuMjc1MTQtMC4wMjcyLTEuMTQ3NC0wLjExMTEtMS45Mzg1LTAuMTg2NTMtNS44ODA5LTAuNTYwNzgtMTEuOTU0LTIuNDg0MS0xNi40NDYtNS4yMDgtNi45NDQtNC4yMTE1LTEwLjQzOC0xMC4yODQtOS4zODM3LTE2LjMwNyAxLjMzOTUtNy42NDg0IDkuNzIzMS0xNC4xNSAyMS4zMjctMTYuNTQxIDMuNDE2NS0wLjcwMzY5IDUuMzU1My0wLjg4MTA4IDkuNjI5OC0wLjg4MTA4IDQuMjc0NCAwIDYuMjEzMyAwLjE3NzQgOS42Mjk4IDAuODgxMDggMTIuNDUgMi41NjQzIDIxLjA0MiA5Ljc2NzggMjEuNDczIDE4LjAwMyAwLjIwMDU4IDMuODI5NC0xLjI0ODYgNy40MzcxLTQuMjgxNCAxMC42NTktNC42MTU3IDQuOTAzMi0xMi4wODYgOC4yMDg2LTIxLjEzMSA5LjM0OTgtMS40MjExIDAuMTc5MjktNy43MzYgMC4zNDI4Ny04Ljg3OTQgMC4yMzAwMXptMTIwLjYyLTE5LjQ4MmMwLTYuOTgyNy01LjY1NzUtMTMuMzA4LTE1LjEzMi0xNi45Mi0yLjk1NTctMS4xMjY2LTYuMjg5OS0xLjkzNzYtMTAuMDY3LTIuNDQ4OC0yLjkxMDctMC4zOTM5Mi04Ljk3MDItMC4zOTM5Mi0xMS44ODEgMC04Ljc4MiAxLjE4ODUtMTUuNzYgNC4yMTE3LTIwLjM5OCA4LjgzNzYtMy4xNjQyIDMuMTU2LTQuODAyMyA2Ljc0ODItNC44MDIzIDEwLjUzMXYxLjE3MTdoNjIuMjgxeiIgc3Ryb2tlLXdpZHRoPSIuMTI1MDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.46369" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,207,80,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="40" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,207,80,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="41" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTU2LjQ4bW0iIGhlaWdodD0iMjkxLjI4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1Ni40OCAyOTEuMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYuMDI0IC0zLjE0MDQpIj4KICA8cGF0aCBkPSJtNjMuMjE3IDI4NC42MnYtOS43OTgyaDE5Ljg1OGwwLjA5NTgtMS4yMjQ4YzAuMjQ2MjQtMy4xNDg5IDAuNTM5OTMtOS42NzY4IDAuNjI2MTYtMTMuOTE4IDAuMjA3LTEwLjE4MS0wLjY2NDk3LTE3LjMzNS0yLjg5NzctMjMuNzczLTEuODI4Ni01LjI3MjctNS40MjI0LTEyLjEwOC0xMC45ODQtMjAuODkzLTE1LjY0LTI0LjcwMi0yMy44MTYtMzkuNDY5LTMwLjI1OC01NC42NTItNy41MjctMTcuNzQtMTEuODYxLTM1LjE1NC0xMy4zNTUtNTMuNjY4LTAuMzY5NTYtNC41NzgyLTAuMzcxNjktMTQuODUyLTRlLTMgLTE4Ljg1NCAyLjAzNTYtMjIuMTQ5IDkuNDg4My0zMy4zMzggMjYuNDA5LTM5LjY0OCA1LjAxNzEtMS44NzEgMTEuMDQ4LTMuMzA4NyAyMC42MDMtNC45MTE4bDQuMjI5Ni0wLjcwOTYgMS4wNTQ0LTEuMDQ0MmMxLjU5MjgtMS41NzczIDIuMzI2Ni0zLjM0MjIgMi43MTgxLTYuNTM3MSAwLjE5OTg2LTEuNjMwOSAwLjIxMjA4LTQuODE2OCAwLjAxOTctNS4xMjEyLTAuMTIyMDYtMC4xOTMwNy0xLjU5NDEtMC4yMjkxMy0xMS4yODEtMC4yNzYzbC0xMS4xNC0wLjA1NDI1di0yNi4zOTNoOTAuNzA4djI2LjM5M2wtMTEuMTQgMC4wNTQyNWMtOS42ODY1IDAuMDQ3MTctMTEuMTU4IDAuMDgzMjItMTEuMjgxIDAuMjc2My0wLjE5MjQzIDAuMzA0MzktMC4xODAyIDMuNDkwMyAwLjAxOTYgNS4xMjEyIDAuMzkxNTMgMy4xOTUgMS4xMjU0IDQuOTU5OCAyLjcxODEgNi41MzcxbDEuMDU0NCAxLjA0NDIgNC4yMjk2IDAuNzA5NmM3LjU3MzUgMS4yNzA2IDEyLjQgMi4zMTkzIDE2Ljg5MiAzLjY3MDIgNS45NDgxIDEuNzg4OSAxMS4xNTEgNC4yODU0IDE0LjkzNCA3LjE2NjEgOS4xMzM0IDYuOTU0MyAxMy42NDcgMTYuOTc5IDE1LjE4NiAzMy43MjQgMC4zNjc4MSA0LjAwMiAwLjM2NTY5IDE0LjI3Ni00ZS0zIDE4Ljg1NC0xLjQ5NDQgMTguNTEzLTUuODI4IDM1LjkyOC0xMy4zNTUgNTMuNjY4LTYuNDQyMiAxNS4xODMtMTQuNjE4IDI5Ljk1LTMwLjI1OCA1NC42NTItNS41NjIgOC43ODQ4LTkuMTU1OCAxNS42Mi0xMC45ODQgMjAuODkzLTIuMjMyNyA2LjQzOC0zLjEwNDcgMTMuNTkyLTIuODk3NyAyMy43NzMgMC4wODYyIDQuMjQxMiAwLjM3OTkyIDEwLjc2OSAwLjYyNjE2IDEzLjkxOGwwLjA5NTggMS4yMjQ4aDE5Ljg1OHYxOS41OTZoLTgyLjA5N3YtOS43OTgyeiIgc3Ryb2tlLXdpZHRoPSIuMTQ4NDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.79352" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="42" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3LjQzbW0iIGhlaWdodD0iMjAzLjA5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy40MyAyMDMuMDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMS40Nzk2IC0zNy41NjkpIj4KICA8cGF0aCBkPSJtNzMuNTY0IDI0MC42MmMtMS4xNTQ5LTAuMTA4NDgtMy4xODkzLTAuNTM3MjktNC4zNDg2LTAuOTE2NjItNi42MzI5LTIuMTcwMi0xMS43OTEtNy42MDI0LTEzLjQ5LTE0LjIwNy0wLjY2OTQ4LTIuNjAyMi0wLjYyMjM1LTAuMzMzMjItMC42NjQ4Ni0zMi4wMWwtMC4wMzkxLTI5LjE0NS0xOS4wMjQtMjEuMDMyYy0xMC40NjMtMTEuNTY3LTE5Ljg2NC0yMS45NTMtMjAuODkxLTIzLjA3OS00LjE2MjQtNC41NjM2LTYuNjA4Ny04LjA5MTYtOC44MTcyLTEyLjcxNi0yLjg3NjktNi4wMjM4LTQuMzU0My0xMS44NTgtNC43MzYyLTE4LjcwMy0wLjU1NjY3LTkuOTc3NCAyLjExNy0yMC4xMiA3LjU0OTgtMjguNjQxIDUuNTc3Mi04Ljc0NjggMTMuNjgtMTUuNDIzIDIzLjM1LTE5LjI0IDExLjM3Mi00LjQ4ODUgMjQuMzQ0LTQuNDg5MyAzNS42NzMtMC4wMDIzIDE0LjQ1NCA1LjcyNDggMjUuMjM1IDE3Ljc1OCAyOS4yODkgMzIuNjkzIDIuNzE4OSAxMC4wMTUgMi4xMTQzIDIwLjk5NS0xLjY4NCAzMC41ODUtNC4xODE5IDEwLjU1OS0xMS42NjYgMTkuMTQyLTIxLjYwOCAyNC43ODItMi4zMzMgMS4zMjM2LTYuMjMyMSAzLjAyNzgtOC44MTMxIDMuODUyMi03LjkzOTkgMi41MzU5LTE2LjU1MiAzLjAxMS0yNC43NTYgMS4zNjU2LTEuNTMzNy0wLjMwNzU5LTQuNDY4My0xLjA3NjgtNS42MjAxLTEuNDczLTAuMzU2NjktMC4xMjI3MS0wLjY2OTA4LTAuMjAyNTYtMC42OTQyMS0wLjE3NzQzLTAuMDI1MSAwLjAyNTEgNC45NjI0IDUuNTgxNiAxMS4wODMgMTIuMzQ4IDYuMTIxIDYuNzY2MiAxMS4xNDYgMTIuMjg1IDExLjE2NiAxMi4yNjUgMC4wMjA1LTAuMDIwNiAwLjMzNjc5LTAuNjM1NjYgMC43MDI4Mi0xLjM2NjkgMi44NDM3LTUuNjgwOSA4LjAyMzUtOS42NjM2IDE0LjIyNi0xMC45MzggMi4wNzg5LTAuNDI3MjYgMi44NDA0LTAuNDM2NCAzMi42NzMtMC4zOTIwNiAzMS43NzggMC4wNDcyIDI5LjUwNC0xLjJlLTQgMzIuMTA2IDAuNjY5MiAyLjc3ODEgMC43MTQ3MiA1LjU4MzIgMi4xODA4IDcuOTUzNCA0LjE1NjggMy4xNDk3IDIuNjI1OSA1LjQ0MyA2LjI3MyA2LjYxMDcgMTAuNTEzbDAuMTkwMjYgMC42OTA5MSAwLjMyNzkzLTAuMzQwMDNjMS4xMDk1LTEuMTUwNSAyNC45MjMtMjcuNTY4IDI0Ljg4NS0yNy42MDYtMC4wMjU3LTAuMDI1OC0wLjI3ODcxIDAuMDM1OC0wLjU2MjE0IDAuMTM2ODctMS4xMDQ1IDAuMzkzNjctMy44MjA4IDEuMTE1MS01LjQ3MjIgMS40NTM0LTkuNDQyOSAxLjkzNDQtMTkuMDc5IDEuMTI2MS0yNy44NTEtMi4zMzYyLTExLjUxMS00LjU0MzQtMjAuODktMTMuMjUzLTI2LjE2NC0yNC4yOTUtMi44NzY5LTYuMDIzOC00LjM1NDMtMTEuODU4LTQuNzM2Mi0xOC43MDMtMC41NTY2Ni05Ljk3NzQgMi4xMTctMjAuMTIgNy41NDk4LTI4LjY0MSA1LjU3NzItOC43NDY4IDEzLjY4LTE1LjQyMyAyMy4zNS0xOS4yNCAxMS4zNzItNC40ODg1IDI0LjM0NC00LjQ4OTMgMzUuNjczLTAuMDAyMyAxNC40NTQgNS43MjQ4IDI1LjIzNSAxNy43NTggMjkuMjg5IDMyLjY5MyAyLjQzNTIgOC45NzA1IDIuMjAyOSAxOC44MjItMC42NTQ3OSAyNy43Ny0wLjgyNDM0IDIuNTgxLTIuNTI4NiA2LjQ4MDEtMy44NTIyIDguODEzMS0yLjE1MDcgMy43OTA5LTQuMDcxMiA2LjM0MS04LjEyNjUgMTAuNzktMS40MDkxIDEuNTQ1OS0xMS42OTQgMTIuOTA3LTIyLjg1NSAyNS4yNDdsLTIwLjI5MyAyMi40MzYtMC4wMzEyIDMuMDI4NS0wLjAzMTIgMy4wMjg1aDI4LjU0MnYtOC4xODczaDE4LjAxMnY0NC40NDVoLTE4LjAxMnYtOC4xODczaC0yOC41MjdsLTAuMDM5NCA5LjkxMjRjLTAuMDM4NCA5LjY3NzctMC4wNDU1IDkuOTQzNS0wLjI5ODQxIDExLjIyMy0wLjU1NTI3IDIuODA5Mi0xLjkwNDEgNS45NzQ2LTMuNTAyOSA4LjIyMDktMS4wMTMyIDEuNDIzNS0zLjI4NTggMy42OTYxLTQuNzA5MyA0LjcwOTMtMi4yNDA5IDEuNTk1LTUuMzkzIDIuOTM5Ni04LjIyMDkgMy41MDY3bC0xLjMxMDYgMC4yNjI4NS0yOS42NSAwLjAxMTNjLTE2LjMwNyA2ZS0zIC0yOS44Ni04ZS0zIC0zMC4xMTctMC4wMzI2em0tMTguNTk3LTExNy40MWM2LjYzODQtMC44OTkzOCAxMi4zMzYtMy4yMjU5IDE3LjcyLTcuMjM2IDIuMTY3OS0xLjYxNDcgNS41OTMzLTUuMDQwMSA3LjIwOC03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzgtNi45Njg4LTMuNDE4MS0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS00LjU2NzYgNS41MDMtNy4zMDYgMTEuNzktOC4zMzc2IDE5LjE0My0wLjI4ODc3IDIuMDU4MS0wLjI4ODc3IDcuMTgxOCAwIDkuMjM5OSAwLjk3ODk1IDYuOTc3MSAzLjM4NjEgMTIuNzU5IDcuNTk2OSAxOC4yNDYgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6bTEwOS44MyAwYzYuNjM4NC0wLjg5OTM4IDEyLjMzNi0zLjIyNTkgMTcuNzItNy4yMzYgMi4xNjc5LTEuNjE0NyA1LjU5MzMtNS4wNDAxIDcuMjA3OS03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzktNi45Njg4LTMuNDE4Mi0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS0zLjkxNjggNC43MTktNi42NTgyIDEwLjM5OC03Ljg0MjIgMTYuMjQ3LTAuNTgxODcgMi44NzQyLTAuNzAwNDkgNC4xNDY5LTAuNzAwNDkgNy41MTU2IDAgMy4zNjg3IDAuMTE4NjIgNC42NDE0IDAuNzAwNDkgNy41MTU2IDEuMTEwNCA1LjQ4NTIgMy41MDc2IDEwLjY2NyA3LjEwMTYgMTUuMzUgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6IiBzdHJva2Utd2lkdGg9Ii4xMTY5NiIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="43" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3Ljg1bW0iIGhlaWdodD0iMjIzLjUxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy44NSAyMjMuNTEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjc4NTk4IC0yNS41ODYpIj4KICA8cGF0aCBkPSJtMTAwLjQgMjQ5LjA2Yy0xMS44NDQtMC43NTUyNi0yMi4zOTMtMy42Mjc3LTMzLjAxNi04Ljk5MDMtMy42Njk0LTEuODUyNC01LjkzNDYtMy4xNzE0LTkuNDQyMi01LjQ5ODQtNS44NTY2LTMuODg1NC0xMC4yNDctNy40NjU1LTE1LjQ5LTEyLjYzLTYuMjA2MS02LjExMzctMTEuMDMzLTExLjk3LTE1Ljk5LTE5LjQtMTQuNTg1LTIxLjg2Mi0yMy4zNy00OC44OTUtMjUuMjk3LTc3LjgzOS0wLjM3OTc3LTUuNzA2LTAuNDg3MTMtMTMuNjctMC4yNDg2Ni0xOC40NDcgMC4yNTQwNS01LjA4OSAxLjU2NzktMTQuMTM0IDIuODc5My0xOS44MjIgMC4xMzQ3OS0wLjU4NDY2IDAuNDQ0NTUtMS45MzUzIDAuNjg4MzUtMy4wMDE1IDAuNTM0OTMtMi4zMzkzIDAuOTE2MzQtMy42NzUyIDIuMTI0Ni03LjQ0MTIgMi44MTc4LTguNzgyNiA1LjEzOTEtMTUuMTM0IDcuOTg0Mi0yMS44NDUgMy4yMi03LjU5NTUgNy4wNzM4LTE1LjA5MiAxMy42MTktMjYuNDkxbDEuMTg0Ny0yLjA2MzVoMTUwLjY0bDEuOTI5NyAzLjM3NjdjMS4wNjEzIDEuODU3MiAyLjE1ODYgMy43OTg4IDIuNDM4NSA0LjMxNDYgMC4yNzk4NSAwLjUxNTg4IDAuNTQ5NzggMC45OTQyNCAwLjU5OTg2IDEuMDYzIDAuMjk5MTkgMC40MTA5NyAzLjc5OTEgNy4wMjIzIDUuMTk3MSA5LjgxNzQgMi4wNDA3IDQuMDggMy4xMTE5IDYuMzg1OCA0LjYxODkgOS45NDI0IDIuOTAzNSA2Ljg1MjYgNS40NDUgMTMuNzY4IDcuODM2NSAyMS4zMjMgMS41NzkgNC45ODgzIDEuNjU3OCA1LjI3OTggMi45NzU5IDExLjAwNSAxLjIxODEgNS4yOTE1IDIuNTMyMyAxNC4xMTYgMi44NzU4IDE5LjMxIDAuMTY3NDggMi41MzI3IDAuMTcwMDggMTEuMDY4IDVlLTMgMTQuNzktMS4zNjI0IDMwLjYyNi0xMC4xNzcgNTguOTIxLTI1LjU1MSA4Mi4wMTgtNC45MDkgNy4zNzUzLTkuNjg3IDEzLjE3NC0xNS45MjQgMTkuMzI3LTUuMjk3OCA1LjIyNi05Ljc2MDEgOC44NjkyLTE1LjU1MiAxMi42OTctMy41NTgxIDIuMzUxNS01LjgxODQgMy42NjY0LTkuNDQyMiA1LjQ5MjYtOS43ODg1IDQuOTMyOS0xOS4zNDkgNy43MTk5LTMwLjA3NyA4Ljc2NzctMS45NjA0IDAuMTkxNDctOS43MjA1IDAuMzQxNTUtMTEuNTY4IDAuMjIzNzN6bTYuODQ3Ni00NC45NDNjNS41OTU4IDFlLTMgMTIuMzMyIDAuODEwMDUgMTUuNjAxIDEuODczOCA0LjUwNjYgMS40NjY0IDcuOTMyIDQuNTAzNyAxMS4wNiA5LjgwNjggMS41NTUgMi42MzY2IDIuMzQ5NSA0LjAzNTIgMi44ODQ0IDUuMDc3NCAwLjk5NTc3IDEuOTQwMyAxLjI3MjQgMi4xMjY3IDMuMTU0MSAyLjEyNDggMS40NDUtMmUtMyAyLjI4My0wLjMwODQ0IDIuODQxOC0xLjA0MSAxLjE2LTEuNTIwOSAxLjExODktMy42MzE0LTAuMTg1NC05LjUwNDQtMi40OTYyLTExLjI0LTYuNzY1NC0xOC40MTktMTIuNjg0LTIxLjMzLTIuNzc3LTEuMzY1Ni04LjAzMTEtMi43NTE3LTEzLjUxMS0zLjU2NDMtMi4zMDU5LTAuMzQxOTMtNi4wODI0LTAuNzY2NC03Ljg3ODktMC44ODU1OC0wLjYxOTA1LTAuMDQxMS0xLjUwNTQtMC4xMDY3NC0xLjk2OTctMC4xNDU5NGwtMC44NDQxNy0wLjA3MTN2LTIxLjk1OGwzLjY1ODEtMC4wNjI3YzMuODkzMy0wLjA2NjggNC42NjI3LTAuMTYyNjEgNi4zMjM2LTAuNzg3NzUgMS4zODQ0LTAuNTIxMTEgMi4yNjYyLTEuMTQ4OSAzLjg0ODYtMi43NDAyIDEuMTk3LTEuMjAzOCAxLjY0MzktMS43NTQ4IDIuMTQ3NC0yLjY0ODEgMC43NjUyNy0xLjM1NzUgMS4xNzIxLTIuMzExNCAxLjQ4NDYtMy40ODA5IDAuMzI3MDgtMS4yMjM5IDAuMzI4NTUtNS44MDY2IDJlLTMgLTcuNTY2Mi0xLjMzNzUtNy4yMTY4LTQuNDY3LTE2LjAyOS0xMy44MzQtMzguOTUyLTEuMDM4OC0yLjU0MjQtMi4yNTI2LTUuNTY4OS0yLjY5NzQtNi43MjU3bC0wLjgwODU4LTIuMTAzMnYtNjMuMDI0aC02Ni45MDdsLTIuMzkyNiA0Ljc4MzZjLTcuMDk2NSAxNC4xODgtMTAuOTg3IDIyLjc0NC0xNC4xNzQgMzEuMTcyLTcuNTQ4MyAxOS45NTgtOS45OTMyIDM2LjU1OC04LjAwMzMgNTQuMzM5IDIuNzI3MiAyNC4zNjkgMTMuNzY1IDUwLjk0NSAyOS4xNDEgNzAuMTYgNC4zMjE4IDUuNDAxIDEwLjE5NSAxMS4zNSAxNS43NTEgMTUuOTU0IDUuNTAzNiA0LjU2MDUgMTIuNDA3IDkuMjYwNiAxOS44MjIgMTMuNDk2IDQuNDQxNyAyLjUzNjkgNi42MDUgMy42NzI4IDE0LjE5NSA3LjQ1MzMgMy45ODk1IDEuOTg3MiA4LjQwNzMgNC4yMjMgOS44MTczIDQuOTY4M2wyLjU2MzggMS4zNTUxIDAuMDYzNC0zNS45NzNoMS41MzE2em0tMTQuMTAxLTAuMTM4ODdjLTYuNjk0LTAuMzE3NjItMTIuNTE4LTEuMjgwNC0xNi4zMDYtMi42OTUzLTkuNTcyOC0zLjU3Ni0xNC41MjEtMTIuMzY0LTE1LjA5NC0yNi44MDYtMC4xMjY4Ny0zLjE5OSAwLjE4NDU5LTQuNzAyNSAxLjE3MzgtNS42NjY0IDAuNzAyLTAuNjg0MDMgMS4yNzA3LTAuODcwOTYgMi42NDk4LTAuODcwOTYgMS4zMTcyIDAgMS45ODM0IDAuMTk3NDcgMi4yOTQ5IDAuNjgwMjUgMC4xMDM1OCAwLjE2MDUxIDAuNDgwODMgMC45NjcxNyAwLjgzODM0IDEuNzkyNiAxLjMxMTUgMy4wMjggMy4yNjcyIDYuODkxMiA0LjE5MDUgOC4yNzc2IDEuNjczOCAyLjUxMzUgMy44MjMxIDQuNTA5NCA2LjEyMjcgNS42ODYgMi42NTE1IDEuMzU2NyAzLjEwMDUgMS40MDM2IDE3LjgxOSAxLjg2MDggNC4zNjc4IDAuMTM1NzEgOC4xNTI1IDAuMjQ2NTYgOC40MTA0IDAuMjQ2MzZoMC40Njg5OHYxNy42MzRsLTUuMjIxMy0wLjAxODljLTIuODcxNy0wLjAxMDQtNi4xNzgxLTAuMDY0My03LjM0NzQtMC4xMTk3M3ptLTM0LjM5Mi04MC43MjVjLTAuMjc1MTQtMC4wMjcyLTEuMTQ3NC0wLjExMTEtMS45Mzg1LTAuMTg2NTMtNS44ODA5LTAuNTYwNzgtMTEuOTU0LTIuNDg0MS0xNi40NDYtNS4yMDgtNi45NDQtNC4yMTE1LTEwLjQzOC0xMC4yODQtOS4zODM3LTE2LjMwNyAxLjMzOTUtNy42NDg0IDkuNzIzMS0xNC4xNSAyMS4zMjctMTYuNTQxIDMuNDE2NS0wLjcwMzY5IDUuMzU1My0wLjg4MTA4IDkuNjI5OC0wLjg4MTA4IDQuMjc0NCAwIDYuMjEzMyAwLjE3NzQgOS42Mjk4IDAuODgxMDggMTIuNDUgMi41NjQzIDIxLjA0MiA5Ljc2NzggMjEuNDczIDE4LjAwMyAwLjIwMDU4IDMuODI5NC0xLjI0ODYgNy40MzcxLTQuMjgxNCAxMC42NTktNC42MTU3IDQuOTAzMi0xMi4wODYgOC4yMDg2LTIxLjEzMSA5LjM0OTgtMS40MjExIDAuMTc5MjktNy43MzYgMC4zNDI4Ny04Ljg3OTQgMC4yMzAwMXptMTIwLjYyLTE5LjQ4MmMwLTYuOTgyNy01LjY1NzUtMTMuMzA4LTE1LjEzMi0xNi45Mi0yLjk1NTctMS4xMjY2LTYuMjg5OS0xLjkzNzYtMTAuMDY3LTIuNDQ4OC0yLjkxMDctMC4zOTM5Mi04Ljk3MDItMC4zOTM5Mi0xMS44ODEgMC04Ljc4MiAxLjE4ODUtMTUuNzYgNC4yMTE3LTIwLjM5OCA4LjgzNzYtMy4xNjQyIDMuMTU2LTQuODAyMyA2Ljc0ODItNC44MDIzIDEwLjUzMXYxLjE3MTdoNjIuMjgxeiIgc3Ryb2tlLXdpZHRoPSIuMTI1MDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.46369" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="44" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,207,80,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="45" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTU2LjQ4bW0iIGhlaWdodD0iMjkxLjI4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1Ni40OCAyOTEuMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYuMDI0IC0zLjE0MDQpIj4KICA8cGF0aCBkPSJtNjMuMjE3IDI4NC42MnYtOS43OTgyaDE5Ljg1OGwwLjA5NTgtMS4yMjQ4YzAuMjQ2MjQtMy4xNDg5IDAuNTM5OTMtOS42NzY4IDAuNjI2MTYtMTMuOTE4IDAuMjA3LTEwLjE4MS0wLjY2NDk3LTE3LjMzNS0yLjg5NzctMjMuNzczLTEuODI4Ni01LjI3MjctNS40MjI0LTEyLjEwOC0xMC45ODQtMjAuODkzLTE1LjY0LTI0LjcwMi0yMy44MTYtMzkuNDY5LTMwLjI1OC01NC42NTItNy41MjctMTcuNzQtMTEuODYxLTM1LjE1NC0xMy4zNTUtNTMuNjY4LTAuMzY5NTYtNC41NzgyLTAuMzcxNjktMTQuODUyLTRlLTMgLTE4Ljg1NCAyLjAzNTYtMjIuMTQ5IDkuNDg4My0zMy4zMzggMjYuNDA5LTM5LjY0OCA1LjAxNzEtMS44NzEgMTEuMDQ4LTMuMzA4NyAyMC42MDMtNC45MTE4bDQuMjI5Ni0wLjcwOTYgMS4wNTQ0LTEuMDQ0MmMxLjU5MjgtMS41NzczIDIuMzI2Ni0zLjM0MjIgMi43MTgxLTYuNTM3MSAwLjE5OTg2LTEuNjMwOSAwLjIxMjA4LTQuODE2OCAwLjAxOTctNS4xMjEyLTAuMTIyMDYtMC4xOTMwNy0xLjU5NDEtMC4yMjkxMy0xMS4yODEtMC4yNzYzbC0xMS4xNC0wLjA1NDI1di0yNi4zOTNoOTAuNzA4djI2LjM5M2wtMTEuMTQgMC4wNTQyNWMtOS42ODY1IDAuMDQ3MTctMTEuMTU4IDAuMDgzMjItMTEuMjgxIDAuMjc2My0wLjE5MjQzIDAuMzA0MzktMC4xODAyIDMuNDkwMyAwLjAxOTYgNS4xMjEyIDAuMzkxNTMgMy4xOTUgMS4xMjU0IDQuOTU5OCAyLjcxODEgNi41MzcxbDEuMDU0NCAxLjA0NDIgNC4yMjk2IDAuNzA5NmM3LjU3MzUgMS4yNzA2IDEyLjQgMi4zMTkzIDE2Ljg5MiAzLjY3MDIgNS45NDgxIDEuNzg4OSAxMS4xNTEgNC4yODU0IDE0LjkzNCA3LjE2NjEgOS4xMzM0IDYuOTU0MyAxMy42NDcgMTYuOTc5IDE1LjE4NiAzMy43MjQgMC4zNjc4MSA0LjAwMiAwLjM2NTY5IDE0LjI3Ni00ZS0zIDE4Ljg1NC0xLjQ5NDQgMTguNTEzLTUuODI4IDM1LjkyOC0xMy4zNTUgNTMuNjY4LTYuNDQyMiAxNS4xODMtMTQuNjE4IDI5Ljk1LTMwLjI1OCA1NC42NTItNS41NjIgOC43ODQ4LTkuMTU1OCAxNS42Mi0xMC45ODQgMjAuODkzLTIuMjMyNyA2LjQzOC0zLjEwNDcgMTMuNTkyLTIuODk3NyAyMy43NzMgMC4wODYyIDQuMjQxMiAwLjM3OTkyIDEwLjc2OSAwLjYyNjE2IDEzLjkxOGwwLjA5NTggMS4yMjQ4aDE5Ljg1OHYxOS41OTZoLTgyLjA5N3YtOS43OTgyeiIgc3Ryb2tlLXdpZHRoPSIuMTQ4NDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.79352" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="255,0,0,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="46" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3LjQzbW0iIGhlaWdodD0iMjAzLjA5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy40MyAyMDMuMDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMS40Nzk2IC0zNy41NjkpIj4KICA8cGF0aCBkPSJtNzMuNTY0IDI0MC42MmMtMS4xNTQ5LTAuMTA4NDgtMy4xODkzLTAuNTM3MjktNC4zNDg2LTAuOTE2NjItNi42MzI5LTIuMTcwMi0xMS43OTEtNy42MDI0LTEzLjQ5LTE0LjIwNy0wLjY2OTQ4LTIuNjAyMi0wLjYyMjM1LTAuMzMzMjItMC42NjQ4Ni0zMi4wMWwtMC4wMzkxLTI5LjE0NS0xOS4wMjQtMjEuMDMyYy0xMC40NjMtMTEuNTY3LTE5Ljg2NC0yMS45NTMtMjAuODkxLTIzLjA3OS00LjE2MjQtNC41NjM2LTYuNjA4Ny04LjA5MTYtOC44MTcyLTEyLjcxNi0yLjg3NjktNi4wMjM4LTQuMzU0My0xMS44NTgtNC43MzYyLTE4LjcwMy0wLjU1NjY3LTkuOTc3NCAyLjExNy0yMC4xMiA3LjU0OTgtMjguNjQxIDUuNTc3Mi04Ljc0NjggMTMuNjgtMTUuNDIzIDIzLjM1LTE5LjI0IDExLjM3Mi00LjQ4ODUgMjQuMzQ0LTQuNDg5MyAzNS42NzMtMC4wMDIzIDE0LjQ1NCA1LjcyNDggMjUuMjM1IDE3Ljc1OCAyOS4yODkgMzIuNjkzIDIuNzE4OSAxMC4wMTUgMi4xMTQzIDIwLjk5NS0xLjY4NCAzMC41ODUtNC4xODE5IDEwLjU1OS0xMS42NjYgMTkuMTQyLTIxLjYwOCAyNC43ODItMi4zMzMgMS4zMjM2LTYuMjMyMSAzLjAyNzgtOC44MTMxIDMuODUyMi03LjkzOTkgMi41MzU5LTE2LjU1MiAzLjAxMS0yNC43NTYgMS4zNjU2LTEuNTMzNy0wLjMwNzU5LTQuNDY4My0xLjA3NjgtNS42MjAxLTEuNDczLTAuMzU2NjktMC4xMjI3MS0wLjY2OTA4LTAuMjAyNTYtMC42OTQyMS0wLjE3NzQzLTAuMDI1MSAwLjAyNTEgNC45NjI0IDUuNTgxNiAxMS4wODMgMTIuMzQ4IDYuMTIxIDYuNzY2MiAxMS4xNDYgMTIuMjg1IDExLjE2NiAxMi4yNjUgMC4wMjA1LTAuMDIwNiAwLjMzNjc5LTAuNjM1NjYgMC43MDI4Mi0xLjM2NjkgMi44NDM3LTUuNjgwOSA4LjAyMzUtOS42NjM2IDE0LjIyNi0xMC45MzggMi4wNzg5LTAuNDI3MjYgMi44NDA0LTAuNDM2NCAzMi42NzMtMC4zOTIwNiAzMS43NzggMC4wNDcyIDI5LjUwNC0xLjJlLTQgMzIuMTA2IDAuNjY5MiAyLjc3ODEgMC43MTQ3MiA1LjU4MzIgMi4xODA4IDcuOTUzNCA0LjE1NjggMy4xNDk3IDIuNjI1OSA1LjQ0MyA2LjI3MyA2LjYxMDcgMTAuNTEzbDAuMTkwMjYgMC42OTA5MSAwLjMyNzkzLTAuMzQwMDNjMS4xMDk1LTEuMTUwNSAyNC45MjMtMjcuNTY4IDI0Ljg4NS0yNy42MDYtMC4wMjU3LTAuMDI1OC0wLjI3ODcxIDAuMDM1OC0wLjU2MjE0IDAuMTM2ODctMS4xMDQ1IDAuMzkzNjctMy44MjA4IDEuMTE1MS01LjQ3MjIgMS40NTM0LTkuNDQyOSAxLjkzNDQtMTkuMDc5IDEuMTI2MS0yNy44NTEtMi4zMzYyLTExLjUxMS00LjU0MzQtMjAuODktMTMuMjUzLTI2LjE2NC0yNC4yOTUtMi44NzY5LTYuMDIzOC00LjM1NDMtMTEuODU4LTQuNzM2Mi0xOC43MDMtMC41NTY2Ni05Ljk3NzQgMi4xMTctMjAuMTIgNy41NDk4LTI4LjY0MSA1LjU3NzItOC43NDY4IDEzLjY4LTE1LjQyMyAyMy4zNS0xOS4yNCAxMS4zNzItNC40ODg1IDI0LjM0NC00LjQ4OTMgMzUuNjczLTAuMDAyMyAxNC40NTQgNS43MjQ4IDI1LjIzNSAxNy43NTggMjkuMjg5IDMyLjY5MyAyLjQzNTIgOC45NzA1IDIuMjAyOSAxOC44MjItMC42NTQ3OSAyNy43Ny0wLjgyNDM0IDIuNTgxLTIuNTI4NiA2LjQ4MDEtMy44NTIyIDguODEzMS0yLjE1MDcgMy43OTA5LTQuMDcxMiA2LjM0MS04LjEyNjUgMTAuNzktMS40MDkxIDEuNTQ1OS0xMS42OTQgMTIuOTA3LTIyLjg1NSAyNS4yNDdsLTIwLjI5MyAyMi40MzYtMC4wMzEyIDMuMDI4NS0wLjAzMTIgMy4wMjg1aDI4LjU0MnYtOC4xODczaDE4LjAxMnY0NC40NDVoLTE4LjAxMnYtOC4xODczaC0yOC41MjdsLTAuMDM5NCA5LjkxMjRjLTAuMDM4NCA5LjY3NzctMC4wNDU1IDkuOTQzNS0wLjI5ODQxIDExLjIyMy0wLjU1NTI3IDIuODA5Mi0xLjkwNDEgNS45NzQ2LTMuNTAyOSA4LjIyMDktMS4wMTMyIDEuNDIzNS0zLjI4NTggMy42OTYxLTQuNzA5MyA0LjcwOTMtMi4yNDA5IDEuNTk1LTUuMzkzIDIuOTM5Ni04LjIyMDkgMy41MDY3bC0xLjMxMDYgMC4yNjI4NS0yOS42NSAwLjAxMTNjLTE2LjMwNyA2ZS0zIC0yOS44Ni04ZS0zIC0zMC4xMTctMC4wMzI2em0tMTguNTk3LTExNy40MWM2LjYzODQtMC44OTkzOCAxMi4zMzYtMy4yMjU5IDE3LjcyLTcuMjM2IDIuMTY3OS0xLjYxNDcgNS41OTMzLTUuMDQwMSA3LjIwOC03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzgtNi45Njg4LTMuNDE4MS0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS00LjU2NzYgNS41MDMtNy4zMDYgMTEuNzktOC4zMzc2IDE5LjE0My0wLjI4ODc3IDIuMDU4MS0wLjI4ODc3IDcuMTgxOCAwIDkuMjM5OSAwLjk3ODk1IDYuOTc3MSAzLjM4NjEgMTIuNzU5IDcuNTk2OSAxOC4yNDYgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6bTEwOS44MyAwYzYuNjM4NC0wLjg5OTM4IDEyLjMzNi0zLjIyNTkgMTcuNzItNy4yMzYgMi4xNjc5LTEuNjE0NyA1LjU5MzMtNS4wNDAxIDcuMjA3OS03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzktNi45Njg4LTMuNDE4Mi0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS0zLjkxNjggNC43MTktNi42NTgyIDEwLjM5OC03Ljg0MjIgMTYuMjQ3LTAuNTgxODcgMi44NzQyLTAuNzAwNDkgNC4xNDY5LTAuNzAwNDkgNy41MTU2IDAgMy4zNjg3IDAuMTE4NjIgNC42NDE0IDAuNzAwNDkgNy41MTU2IDEuMTEwNCA1LjQ4NTIgMy41MDc2IDEwLjY2NyA3LjEwMTYgMTUuMzUgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6IiBzdHJva2Utd2lkdGg9Ii4xMTY5NiIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="47" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3Ljg1bW0iIGhlaWdodD0iMjIzLjUxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy44NSAyMjMuNTEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjc4NTk4IC0yNS41ODYpIj4KICA8cGF0aCBkPSJtMTAwLjQgMjQ5LjA2Yy0xMS44NDQtMC43NTUyNi0yMi4zOTMtMy42Mjc3LTMzLjAxNi04Ljk5MDMtMy42Njk0LTEuODUyNC01LjkzNDYtMy4xNzE0LTkuNDQyMi01LjQ5ODQtNS44NTY2LTMuODg1NC0xMC4yNDctNy40NjU1LTE1LjQ5LTEyLjYzLTYuMjA2MS02LjExMzctMTEuMDMzLTExLjk3LTE1Ljk5LTE5LjQtMTQuNTg1LTIxLjg2Mi0yMy4zNy00OC44OTUtMjUuMjk3LTc3LjgzOS0wLjM3OTc3LTUuNzA2LTAuNDg3MTMtMTMuNjctMC4yNDg2Ni0xOC40NDcgMC4yNTQwNS01LjA4OSAxLjU2NzktMTQuMTM0IDIuODc5My0xOS44MjIgMC4xMzQ3OS0wLjU4NDY2IDAuNDQ0NTUtMS45MzUzIDAuNjg4MzUtMy4wMDE1IDAuNTM0OTMtMi4zMzkzIDAuOTE2MzQtMy42NzUyIDIuMTI0Ni03LjQ0MTIgMi44MTc4LTguNzgyNiA1LjEzOTEtMTUuMTM0IDcuOTg0Mi0yMS44NDUgMy4yMi03LjU5NTUgNy4wNzM4LTE1LjA5MiAxMy42MTktMjYuNDkxbDEuMTg0Ny0yLjA2MzVoMTUwLjY0bDEuOTI5NyAzLjM3NjdjMS4wNjEzIDEuODU3MiAyLjE1ODYgMy43OTg4IDIuNDM4NSA0LjMxNDYgMC4yNzk4NSAwLjUxNTg4IDAuNTQ5NzggMC45OTQyNCAwLjU5OTg2IDEuMDYzIDAuMjk5MTkgMC40MTA5NyAzLjc5OTEgNy4wMjIzIDUuMTk3MSA5LjgxNzQgMi4wNDA3IDQuMDggMy4xMTE5IDYuMzg1OCA0LjYxODkgOS45NDI0IDIuOTAzNSA2Ljg1MjYgNS40NDUgMTMuNzY4IDcuODM2NSAyMS4zMjMgMS41NzkgNC45ODgzIDEuNjU3OCA1LjI3OTggMi45NzU5IDExLjAwNSAxLjIxODEgNS4yOTE1IDIuNTMyMyAxNC4xMTYgMi44NzU4IDE5LjMxIDAuMTY3NDggMi41MzI3IDAuMTcwMDggMTEuMDY4IDVlLTMgMTQuNzktMS4zNjI0IDMwLjYyNi0xMC4xNzcgNTguOTIxLTI1LjU1MSA4Mi4wMTgtNC45MDkgNy4zNzUzLTkuNjg3IDEzLjE3NC0xNS45MjQgMTkuMzI3LTUuMjk3OCA1LjIyNi05Ljc2MDEgOC44NjkyLTE1LjU1MiAxMi42OTctMy41NTgxIDIuMzUxNS01LjgxODQgMy42NjY0LTkuNDQyMiA1LjQ5MjYtOS43ODg1IDQuOTMyOS0xOS4zNDkgNy43MTk5LTMwLjA3NyA4Ljc2NzctMS45NjA0IDAuMTkxNDctOS43MjA1IDAuMzQxNTUtMTEuNTY4IDAuMjIzNzN6bTYuODQ3Ni00NC45NDNjNS41OTU4IDFlLTMgMTIuMzMyIDAuODEwMDUgMTUuNjAxIDEuODczOCA0LjUwNjYgMS40NjY0IDcuOTMyIDQuNTAzNyAxMS4wNiA5LjgwNjggMS41NTUgMi42MzY2IDIuMzQ5NSA0LjAzNTIgMi44ODQ0IDUuMDc3NCAwLjk5NTc3IDEuOTQwMyAxLjI3MjQgMi4xMjY3IDMuMTU0MSAyLjEyNDggMS40NDUtMmUtMyAyLjI4My0wLjMwODQ0IDIuODQxOC0xLjA0MSAxLjE2LTEuNTIwOSAxLjExODktMy42MzE0LTAuMTg1NC05LjUwNDQtMi40OTYyLTExLjI0LTYuNzY1NC0xOC40MTktMTIuNjg0LTIxLjMzLTIuNzc3LTEuMzY1Ni04LjAzMTEtMi43NTE3LTEzLjUxMS0zLjU2NDMtMi4zMDU5LTAuMzQxOTMtNi4wODI0LTAuNzY2NC03Ljg3ODktMC44ODU1OC0wLjYxOTA1LTAuMDQxMS0xLjUwNTQtMC4xMDY3NC0xLjk2OTctMC4xNDU5NGwtMC44NDQxNy0wLjA3MTN2LTIxLjk1OGwzLjY1ODEtMC4wNjI3YzMuODkzMy0wLjA2NjggNC42NjI3LTAuMTYyNjEgNi4zMjM2LTAuNzg3NzUgMS4zODQ0LTAuNTIxMTEgMi4yNjYyLTEuMTQ4OSAzLjg0ODYtMi43NDAyIDEuMTk3LTEuMjAzOCAxLjY0MzktMS43NTQ4IDIuMTQ3NC0yLjY0ODEgMC43NjUyNy0xLjM1NzUgMS4xNzIxLTIuMzExNCAxLjQ4NDYtMy40ODA5IDAuMzI3MDgtMS4yMjM5IDAuMzI4NTUtNS44MDY2IDJlLTMgLTcuNTY2Mi0xLjMzNzUtNy4yMTY4LTQuNDY3LTE2LjAyOS0xMy44MzQtMzguOTUyLTEuMDM4OC0yLjU0MjQtMi4yNTI2LTUuNTY4OS0yLjY5NzQtNi43MjU3bC0wLjgwODU4LTIuMTAzMnYtNjMuMDI0aC02Ni45MDdsLTIuMzkyNiA0Ljc4MzZjLTcuMDk2NSAxNC4xODgtMTAuOTg3IDIyLjc0NC0xNC4xNzQgMzEuMTcyLTcuNTQ4MyAxOS45NTgtOS45OTMyIDM2LjU1OC04LjAwMzMgNTQuMzM5IDIuNzI3MiAyNC4zNjkgMTMuNzY1IDUwLjk0NSAyOS4xNDEgNzAuMTYgNC4zMjE4IDUuNDAxIDEwLjE5NSAxMS4zNSAxNS43NTEgMTUuOTU0IDUuNTAzNiA0LjU2MDUgMTIuNDA3IDkuMjYwNiAxOS44MjIgMTMuNDk2IDQuNDQxNyAyLjUzNjkgNi42MDUgMy42NzI4IDE0LjE5NSA3LjQ1MzMgMy45ODk1IDEuOTg3MiA4LjQwNzMgNC4yMjMgOS44MTczIDQuOTY4M2wyLjU2MzggMS4zNTUxIDAuMDYzNC0zNS45NzNoMS41MzE2em0tMTQuMTAxLTAuMTM4ODdjLTYuNjk0LTAuMzE3NjItMTIuNTE4LTEuMjgwNC0xNi4zMDYtMi42OTUzLTkuNTcyOC0zLjU3Ni0xNC41MjEtMTIuMzY0LTE1LjA5NC0yNi44MDYtMC4xMjY4Ny0zLjE5OSAwLjE4NDU5LTQuNzAyNSAxLjE3MzgtNS42NjY0IDAuNzAyLTAuNjg0MDMgMS4yNzA3LTAuODcwOTYgMi42NDk4LTAuODcwOTYgMS4zMTcyIDAgMS45ODM0IDAuMTk3NDcgMi4yOTQ5IDAuNjgwMjUgMC4xMDM1OCAwLjE2MDUxIDAuNDgwODMgMC45NjcxNyAwLjgzODM0IDEuNzkyNiAxLjMxMTUgMy4wMjggMy4yNjcyIDYuODkxMiA0LjE5MDUgOC4yNzc2IDEuNjczOCAyLjUxMzUgMy44MjMxIDQuNTA5NCA2LjEyMjcgNS42ODYgMi42NTE1IDEuMzU2NyAzLjEwMDUgMS40MDM2IDE3LjgxOSAxLjg2MDggNC4zNjc4IDAuMTM1NzEgOC4xNTI1IDAuMjQ2NTYgOC40MTA0IDAuMjQ2MzZoMC40Njg5OHYxNy42MzRsLTUuMjIxMy0wLjAxODljLTIuODcxNy0wLjAxMDQtNi4xNzgxLTAuMDY0My03LjM0NzQtMC4xMTk3M3ptLTM0LjM5Mi04MC43MjVjLTAuMjc1MTQtMC4wMjcyLTEuMTQ3NC0wLjExMTEtMS45Mzg1LTAuMTg2NTMtNS44ODA5LTAuNTYwNzgtMTEuOTU0LTIuNDg0MS0xNi40NDYtNS4yMDgtNi45NDQtNC4yMTE1LTEwLjQzOC0xMC4yODQtOS4zODM3LTE2LjMwNyAxLjMzOTUtNy42NDg0IDkuNzIzMS0xNC4xNSAyMS4zMjctMTYuNTQxIDMuNDE2NS0wLjcwMzY5IDUuMzU1My0wLjg4MTA4IDkuNjI5OC0wLjg4MTA4IDQuMjc0NCAwIDYuMjEzMyAwLjE3NzQgOS42Mjk4IDAuODgxMDggMTIuNDUgMi41NjQzIDIxLjA0MiA5Ljc2NzggMjEuNDczIDE4LjAwMyAwLjIwMDU4IDMuODI5NC0xLjI0ODYgNy40MzcxLTQuMjgxNCAxMC42NTktNC42MTU3IDQuOTAzMi0xMi4wODYgOC4yMDg2LTIxLjEzMSA5LjM0OTgtMS40MjExIDAuMTc5MjktNy43MzYgMC4zNDI4Ny04Ljg3OTQgMC4yMzAwMXptMTIwLjYyLTE5LjQ4MmMwLTYuOTgyNy01LjY1NzUtMTMuMzA4LTE1LjEzMi0xNi45Mi0yLjk1NTctMS4xMjY2LTYuMjg5OS0xLjkzNzYtMTAuMDY3LTIuNDQ4OC0yLjkxMDctMC4zOTM5Mi04Ljk3MDItMC4zOTM5Mi0xMS44ODEgMC04Ljc4MiAxLjE4ODUtMTUuNzYgNC4yMTE3LTIwLjM5OCA4LjgzNzYtMy4xNjQyIDMuMTU2LTQuODAyMyA2Ljc0ODItNC44MDIzIDEwLjUzMXYxLjE3MTdoNjIuMjgxeiIgc3Ryb2tlLXdpZHRoPSIuMTI1MDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.46369" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTU2LjQ4bW0iIGhlaWdodD0iMjkxLjI4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1Ni40OCAyOTEuMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYuMDI0IC0zLjE0MDQpIj4KICA8cGF0aCBkPSJtNjMuMjE3IDI4NC42MnYtOS43OTgyaDE5Ljg1OGwwLjA5NTgtMS4yMjQ4YzAuMjQ2MjQtMy4xNDg5IDAuNTM5OTMtOS42NzY4IDAuNjI2MTYtMTMuOTE4IDAuMjA3LTEwLjE4MS0wLjY2NDk3LTE3LjMzNS0yLjg5NzctMjMuNzczLTEuODI4Ni01LjI3MjctNS40MjI0LTEyLjEwOC0xMC45ODQtMjAuODkzLTE1LjY0LTI0LjcwMi0yMy44MTYtMzkuNDY5LTMwLjI1OC01NC42NTItNy41MjctMTcuNzQtMTEuODYxLTM1LjE1NC0xMy4zNTUtNTMuNjY4LTAuMzY5NTYtNC41NzgyLTAuMzcxNjktMTQuODUyLTRlLTMgLTE4Ljg1NCAyLjAzNTYtMjIuMTQ5IDkuNDg4My0zMy4zMzggMjYuNDA5LTM5LjY0OCA1LjAxNzEtMS44NzEgMTEuMDQ4LTMuMzA4NyAyMC42MDMtNC45MTE4bDQuMjI5Ni0wLjcwOTYgMS4wNTQ0LTEuMDQ0MmMxLjU5MjgtMS41NzczIDIuMzI2Ni0zLjM0MjIgMi43MTgxLTYuNTM3MSAwLjE5OTg2LTEuNjMwOSAwLjIxMjA4LTQuODE2OCAwLjAxOTctNS4xMjEyLTAuMTIyMDYtMC4xOTMwNy0xLjU5NDEtMC4yMjkxMy0xMS4yODEtMC4yNzYzbC0xMS4xNC0wLjA1NDI1di0yNi4zOTNoOTAuNzA4djI2LjM5M2wtMTEuMTQgMC4wNTQyNWMtOS42ODY1IDAuMDQ3MTctMTEuMTU4IDAuMDgzMjItMTEuMjgxIDAuMjc2My0wLjE5MjQzIDAuMzA0MzktMC4xODAyIDMuNDkwMyAwLjAxOTYgNS4xMjEyIDAuMzkxNTMgMy4xOTUgMS4xMjU0IDQuOTU5OCAyLjcxODEgNi41MzcxbDEuMDU0NCAxLjA0NDIgNC4yMjk2IDAuNzA5NmM3LjU3MzUgMS4yNzA2IDEyLjQgMi4zMTkzIDE2Ljg5MiAzLjY3MDIgNS45NDgxIDEuNzg4OSAxMS4xNTEgNC4yODU0IDE0LjkzNCA3LjE2NjEgOS4xMzM0IDYuOTU0MyAxMy42NDcgMTYuOTc5IDE1LjE4NiAzMy43MjQgMC4zNjc4MSA0LjAwMiAwLjM2NTY5IDE0LjI3Ni00ZS0zIDE4Ljg1NC0xLjQ5NDQgMTguNTEzLTUuODI4IDM1LjkyOC0xMy4zNTUgNTMuNjY4LTYuNDQyMiAxNS4xODMtMTQuNjE4IDI5Ljk1LTMwLjI1OCA1NC42NTItNS41NjIgOC43ODQ4LTkuMTU1OCAxNS42Mi0xMC45ODQgMjAuODkzLTIuMjMyNyA2LjQzOC0zLjEwNDcgMTMuNTkyLTIuODk3NyAyMy43NzMgMC4wODYyIDQuMjQxMiAwLjM3OTkyIDEwLjc2OSAwLjYyNjE2IDEzLjkxOGwwLjA5NTggMS4yMjQ4aDE5Ljg1OHYxOS41OTZoLTgyLjA5N3YtOS43OTgyeiIgc3Ryb2tlLXdpZHRoPSIuMTQ4NDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.79352" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3LjQzbW0iIGhlaWdodD0iMjAzLjA5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy40MyAyMDMuMDkiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMS40Nzk2IC0zNy41NjkpIj4KICA8cGF0aCBkPSJtNzMuNTY0IDI0MC42MmMtMS4xNTQ5LTAuMTA4NDgtMy4xODkzLTAuNTM3MjktNC4zNDg2LTAuOTE2NjItNi42MzI5LTIuMTcwMi0xMS43OTEtNy42MDI0LTEzLjQ5LTE0LjIwNy0wLjY2OTQ4LTIuNjAyMi0wLjYyMjM1LTAuMzMzMjItMC42NjQ4Ni0zMi4wMWwtMC4wMzkxLTI5LjE0NS0xOS4wMjQtMjEuMDMyYy0xMC40NjMtMTEuNTY3LTE5Ljg2NC0yMS45NTMtMjAuODkxLTIzLjA3OS00LjE2MjQtNC41NjM2LTYuNjA4Ny04LjA5MTYtOC44MTcyLTEyLjcxNi0yLjg3NjktNi4wMjM4LTQuMzU0My0xMS44NTgtNC43MzYyLTE4LjcwMy0wLjU1NjY3LTkuOTc3NCAyLjExNy0yMC4xMiA3LjU0OTgtMjguNjQxIDUuNTc3Mi04Ljc0NjggMTMuNjgtMTUuNDIzIDIzLjM1LTE5LjI0IDExLjM3Mi00LjQ4ODUgMjQuMzQ0LTQuNDg5MyAzNS42NzMtMC4wMDIzIDE0LjQ1NCA1LjcyNDggMjUuMjM1IDE3Ljc1OCAyOS4yODkgMzIuNjkzIDIuNzE4OSAxMC4wMTUgMi4xMTQzIDIwLjk5NS0xLjY4NCAzMC41ODUtNC4xODE5IDEwLjU1OS0xMS42NjYgMTkuMTQyLTIxLjYwOCAyNC43ODItMi4zMzMgMS4zMjM2LTYuMjMyMSAzLjAyNzgtOC44MTMxIDMuODUyMi03LjkzOTkgMi41MzU5LTE2LjU1MiAzLjAxMS0yNC43NTYgMS4zNjU2LTEuNTMzNy0wLjMwNzU5LTQuNDY4My0xLjA3NjgtNS42MjAxLTEuNDczLTAuMzU2NjktMC4xMjI3MS0wLjY2OTA4LTAuMjAyNTYtMC42OTQyMS0wLjE3NzQzLTAuMDI1MSAwLjAyNTEgNC45NjI0IDUuNTgxNiAxMS4wODMgMTIuMzQ4IDYuMTIxIDYuNzY2MiAxMS4xNDYgMTIuMjg1IDExLjE2NiAxMi4yNjUgMC4wMjA1LTAuMDIwNiAwLjMzNjc5LTAuNjM1NjYgMC43MDI4Mi0xLjM2NjkgMi44NDM3LTUuNjgwOSA4LjAyMzUtOS42NjM2IDE0LjIyNi0xMC45MzggMi4wNzg5LTAuNDI3MjYgMi44NDA0LTAuNDM2NCAzMi42NzMtMC4zOTIwNiAzMS43NzggMC4wNDcyIDI5LjUwNC0xLjJlLTQgMzIuMTA2IDAuNjY5MiAyLjc3ODEgMC43MTQ3MiA1LjU4MzIgMi4xODA4IDcuOTUzNCA0LjE1NjggMy4xNDk3IDIuNjI1OSA1LjQ0MyA2LjI3MyA2LjYxMDcgMTAuNTEzbDAuMTkwMjYgMC42OTA5MSAwLjMyNzkzLTAuMzQwMDNjMS4xMDk1LTEuMTUwNSAyNC45MjMtMjcuNTY4IDI0Ljg4NS0yNy42MDYtMC4wMjU3LTAuMDI1OC0wLjI3ODcxIDAuMDM1OC0wLjU2MjE0IDAuMTM2ODctMS4xMDQ1IDAuMzkzNjctMy44MjA4IDEuMTE1MS01LjQ3MjIgMS40NTM0LTkuNDQyOSAxLjkzNDQtMTkuMDc5IDEuMTI2MS0yNy44NTEtMi4zMzYyLTExLjUxMS00LjU0MzQtMjAuODktMTMuMjUzLTI2LjE2NC0yNC4yOTUtMi44NzY5LTYuMDIzOC00LjM1NDMtMTEuODU4LTQuNzM2Mi0xOC43MDMtMC41NTY2Ni05Ljk3NzQgMi4xMTctMjAuMTIgNy41NDk4LTI4LjY0MSA1LjU3NzItOC43NDY4IDEzLjY4LTE1LjQyMyAyMy4zNS0xOS4yNCAxMS4zNzItNC40ODg1IDI0LjM0NC00LjQ4OTMgMzUuNjczLTAuMDAyMyAxNC40NTQgNS43MjQ4IDI1LjIzNSAxNy43NTggMjkuMjg5IDMyLjY5MyAyLjQzNTIgOC45NzA1IDIuMjAyOSAxOC44MjItMC42NTQ3OSAyNy43Ny0wLjgyNDM0IDIuNTgxLTIuNTI4NiA2LjQ4MDEtMy44NTIyIDguODEzMS0yLjE1MDcgMy43OTA5LTQuMDcxMiA2LjM0MS04LjEyNjUgMTAuNzktMS40MDkxIDEuNTQ1OS0xMS42OTQgMTIuOTA3LTIyLjg1NSAyNS4yNDdsLTIwLjI5MyAyMi40MzYtMC4wMzEyIDMuMDI4NS0wLjAzMTIgMy4wMjg1aDI4LjU0MnYtOC4xODczaDE4LjAxMnY0NC40NDVoLTE4LjAxMnYtOC4xODczaC0yOC41MjdsLTAuMDM5NCA5LjkxMjRjLTAuMDM4NCA5LjY3NzctMC4wNDU1IDkuOTQzNS0wLjI5ODQxIDExLjIyMy0wLjU1NTI3IDIuODA5Mi0xLjkwNDEgNS45NzQ2LTMuNTAyOSA4LjIyMDktMS4wMTMyIDEuNDIzNS0zLjI4NTggMy42OTYxLTQuNzA5MyA0LjcwOTMtMi4yNDA5IDEuNTk1LTUuMzkzIDIuOTM5Ni04LjIyMDkgMy41MDY3bC0xLjMxMDYgMC4yNjI4NS0yOS42NSAwLjAxMTNjLTE2LjMwNyA2ZS0zIC0yOS44Ni04ZS0zIC0zMC4xMTctMC4wMzI2em0tMTguNTk3LTExNy40MWM2LjYzODQtMC44OTkzOCAxMi4zMzYtMy4yMjU5IDE3LjcyLTcuMjM2IDIuMTY3OS0xLjYxNDcgNS41OTMzLTUuMDQwMSA3LjIwOC03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzgtNi45Njg4LTMuNDE4MS0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS00LjU2NzYgNS41MDMtNy4zMDYgMTEuNzktOC4zMzc2IDE5LjE0My0wLjI4ODc3IDIuMDU4MS0wLjI4ODc3IDcuMTgxOCAwIDkuMjM5OSAwLjk3ODk1IDYuOTc3MSAzLjM4NjEgMTIuNzU5IDcuNTk2OSAxOC4yNDYgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6bTEwOS44MyAwYzYuNjM4NC0wLjg5OTM4IDEyLjMzNi0zLjIyNTkgMTcuNzItNy4yMzYgMi4xNjc5LTEuNjE0NyA1LjU5MzMtNS4wNDAxIDcuMjA3OS03LjIwOCA0LjAyMTEtNS4zOTg4IDYuMjk3NC0xMC45OCA3LjI1MTMtMTcuNzc4IDAuMjg4NzctMi4wNTgxIDAuMjg4NzctNy4xODE4IDAtOS4yMzk5LTAuOTc3NzktNi45Njg4LTMuNDE4Mi0xMi44MjctNy42MDA2LTE4LjI0Ni0xLjIzNDktMS42LTQuODI4NS01LjE5NTYtNi4zOTA4LTYuMzk0NC01LjQ4NzQtNC4yMTA4LTExLjI2OS02LjYxOC0xOC4yNDYtNy41OTY5LTIuMDU4MS0wLjI4ODc3LTcuMTgxOC0wLjI4ODc3LTkuMjM5OSAwLTcuMTAwMiAwLjk5NjIyLTEzLjEwMiAzLjUzNTQtMTguNTM4IDcuODQyNC0xLjQ4NzQgMS4xNzg1LTQuMTI2MSAzLjc2MzMtNS4zNjE5IDUuMjUyMS0zLjkxNjggNC43MTktNi42NTgyIDEwLjM5OC03Ljg0MjIgMTYuMjQ3LTAuNTgxODcgMi44NzQyLTAuNzAwNDkgNC4xNDY5LTAuNzAwNDkgNy41MTU2IDAgMy4zNjg3IDAuMTE4NjIgNC42NDE0IDAuNzAwNDkgNy41MTU2IDEuMTEwNCA1LjQ4NTIgMy41MDc2IDEwLjY2NyA3LjEwMTYgMTUuMzUgMS4xOTg5IDEuNTYyMyA0Ljc5NDUgNS4xNTU5IDYuMzk0NCA2LjM5MDggNS45NDQzIDQuNTg4IDEyLjc1MSA3LjIwNjYgMjAuMjkzIDcuODA2NSAxLjI4NDQgMC4xMDIxOCA1LjkwNS0wLjAzODggNy4yNTE2LTAuMjIxMjF6IiBzdHJva2Utd2lkdGg9Ii4xMTY5NiIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjA3Ljg1bW0iIGhlaWdodD0iMjIzLjUxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDIwNy44NSAyMjMuNTEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjc4NTk4IC0yNS41ODYpIj4KICA8cGF0aCBkPSJtMTAwLjQgMjQ5LjA2Yy0xMS44NDQtMC43NTUyNi0yMi4zOTMtMy42Mjc3LTMzLjAxNi04Ljk5MDMtMy42Njk0LTEuODUyNC01LjkzNDYtMy4xNzE0LTkuNDQyMi01LjQ5ODQtNS44NTY2LTMuODg1NC0xMC4yNDctNy40NjU1LTE1LjQ5LTEyLjYzLTYuMjA2MS02LjExMzctMTEuMDMzLTExLjk3LTE1Ljk5LTE5LjQtMTQuNTg1LTIxLjg2Mi0yMy4zNy00OC44OTUtMjUuMjk3LTc3LjgzOS0wLjM3OTc3LTUuNzA2LTAuNDg3MTMtMTMuNjctMC4yNDg2Ni0xOC40NDcgMC4yNTQwNS01LjA4OSAxLjU2NzktMTQuMTM0IDIuODc5My0xOS44MjIgMC4xMzQ3OS0wLjU4NDY2IDAuNDQ0NTUtMS45MzUzIDAuNjg4MzUtMy4wMDE1IDAuNTM0OTMtMi4zMzkzIDAuOTE2MzQtMy42NzUyIDIuMTI0Ni03LjQ0MTIgMi44MTc4LTguNzgyNiA1LjEzOTEtMTUuMTM0IDcuOTg0Mi0yMS44NDUgMy4yMi03LjU5NTUgNy4wNzM4LTE1LjA5MiAxMy42MTktMjYuNDkxbDEuMTg0Ny0yLjA2MzVoMTUwLjY0bDEuOTI5NyAzLjM3NjdjMS4wNjEzIDEuODU3MiAyLjE1ODYgMy43OTg4IDIuNDM4NSA0LjMxNDYgMC4yNzk4NSAwLjUxNTg4IDAuNTQ5NzggMC45OTQyNCAwLjU5OTg2IDEuMDYzIDAuMjk5MTkgMC40MTA5NyAzLjc5OTEgNy4wMjIzIDUuMTk3MSA5LjgxNzQgMi4wNDA3IDQuMDggMy4xMTE5IDYuMzg1OCA0LjYxODkgOS45NDI0IDIuOTAzNSA2Ljg1MjYgNS40NDUgMTMuNzY4IDcuODM2NSAyMS4zMjMgMS41NzkgNC45ODgzIDEuNjU3OCA1LjI3OTggMi45NzU5IDExLjAwNSAxLjIxODEgNS4yOTE1IDIuNTMyMyAxNC4xMTYgMi44NzU4IDE5LjMxIDAuMTY3NDggMi41MzI3IDAuMTcwMDggMTEuMDY4IDVlLTMgMTQuNzktMS4zNjI0IDMwLjYyNi0xMC4xNzcgNTguOTIxLTI1LjU1MSA4Mi4wMTgtNC45MDkgNy4zNzUzLTkuNjg3IDEzLjE3NC0xNS45MjQgMTkuMzI3LTUuMjk3OCA1LjIyNi05Ljc2MDEgOC44NjkyLTE1LjU1MiAxMi42OTctMy41NTgxIDIuMzUxNS01LjgxODQgMy42NjY0LTkuNDQyMiA1LjQ5MjYtOS43ODg1IDQuOTMyOS0xOS4zNDkgNy43MTk5LTMwLjA3NyA4Ljc2NzctMS45NjA0IDAuMTkxNDctOS43MjA1IDAuMzQxNTUtMTEuNTY4IDAuMjIzNzN6bTYuODQ3Ni00NC45NDNjNS41OTU4IDFlLTMgMTIuMzMyIDAuODEwMDUgMTUuNjAxIDEuODczOCA0LjUwNjYgMS40NjY0IDcuOTMyIDQuNTAzNyAxMS4wNiA5LjgwNjggMS41NTUgMi42MzY2IDIuMzQ5NSA0LjAzNTIgMi44ODQ0IDUuMDc3NCAwLjk5NTc3IDEuOTQwMyAxLjI3MjQgMi4xMjY3IDMuMTU0MSAyLjEyNDggMS40NDUtMmUtMyAyLjI4My0wLjMwODQ0IDIuODQxOC0xLjA0MSAxLjE2LTEuNTIwOSAxLjExODktMy42MzE0LTAuMTg1NC05LjUwNDQtMi40OTYyLTExLjI0LTYuNzY1NC0xOC40MTktMTIuNjg0LTIxLjMzLTIuNzc3LTEuMzY1Ni04LjAzMTEtMi43NTE3LTEzLjUxMS0zLjU2NDMtMi4zMDU5LTAuMzQxOTMtNi4wODI0LTAuNzY2NC03Ljg3ODktMC44ODU1OC0wLjYxOTA1LTAuMDQxMS0xLjUwNTQtMC4xMDY3NC0xLjk2OTctMC4xNDU5NGwtMC44NDQxNy0wLjA3MTN2LTIxLjk1OGwzLjY1ODEtMC4wNjI3YzMuODkzMy0wLjA2NjggNC42NjI3LTAuMTYyNjEgNi4zMjM2LTAuNzg3NzUgMS4zODQ0LTAuNTIxMTEgMi4yNjYyLTEuMTQ4OSAzLjg0ODYtMi43NDAyIDEuMTk3LTEuMjAzOCAxLjY0MzktMS43NTQ4IDIuMTQ3NC0yLjY0ODEgMC43NjUyNy0xLjM1NzUgMS4xNzIxLTIuMzExNCAxLjQ4NDYtMy40ODA5IDAuMzI3MDgtMS4yMjM5IDAuMzI4NTUtNS44MDY2IDJlLTMgLTcuNTY2Mi0xLjMzNzUtNy4yMTY4LTQuNDY3LTE2LjAyOS0xMy44MzQtMzguOTUyLTEuMDM4OC0yLjU0MjQtMi4yNTI2LTUuNTY4OS0yLjY5NzQtNi43MjU3bC0wLjgwODU4LTIuMTAzMnYtNjMuMDI0aC02Ni45MDdsLTIuMzkyNiA0Ljc4MzZjLTcuMDk2NSAxNC4xODgtMTAuOTg3IDIyLjc0NC0xNC4xNzQgMzEuMTcyLTcuNTQ4MyAxOS45NTgtOS45OTMyIDM2LjU1OC04LjAwMzMgNTQuMzM5IDIuNzI3MiAyNC4zNjkgMTMuNzY1IDUwLjk0NSAyOS4xNDEgNzAuMTYgNC4zMjE4IDUuNDAxIDEwLjE5NSAxMS4zNSAxNS43NTEgMTUuOTU0IDUuNTAzNiA0LjU2MDUgMTIuNDA3IDkuMjYwNiAxOS44MjIgMTMuNDk2IDQuNDQxNyAyLjUzNjkgNi42MDUgMy42NzI4IDE0LjE5NSA3LjQ1MzMgMy45ODk1IDEuOTg3MiA4LjQwNzMgNC4yMjMgOS44MTczIDQuOTY4M2wyLjU2MzggMS4zNTUxIDAuMDYzNC0zNS45NzNoMS41MzE2em0tMTQuMTAxLTAuMTM4ODdjLTYuNjk0LTAuMzE3NjItMTIuNTE4LTEuMjgwNC0xNi4zMDYtMi42OTUzLTkuNTcyOC0zLjU3Ni0xNC41MjEtMTIuMzY0LTE1LjA5NC0yNi44MDYtMC4xMjY4Ny0zLjE5OSAwLjE4NDU5LTQuNzAyNSAxLjE3MzgtNS42NjY0IDAuNzAyLTAuNjg0MDMgMS4yNzA3LTAuODcwOTYgMi42NDk4LTAuODcwOTYgMS4zMTcyIDAgMS45ODM0IDAuMTk3NDcgMi4yOTQ5IDAuNjgwMjUgMC4xMDM1OCAwLjE2MDUxIDAuNDgwODMgMC45NjcxNyAwLjgzODM0IDEuNzkyNiAxLjMxMTUgMy4wMjggMy4yNjcyIDYuODkxMiA0LjE5MDUgOC4yNzc2IDEuNjczOCAyLjUxMzUgMy44MjMxIDQuNTA5NCA2LjEyMjcgNS42ODYgMi42NTE1IDEuMzU2NyAzLjEwMDUgMS40MDM2IDE3LjgxOSAxLjg2MDggNC4zNjc4IDAuMTM1NzEgOC4xNTI1IDAuMjQ2NTYgOC40MTA0IDAuMjQ2MzZoMC40Njg5OHYxNy42MzRsLTUuMjIxMy0wLjAxODljLTIuODcxNy0wLjAxMDQtNi4xNzgxLTAuMDY0My03LjM0NzQtMC4xMTk3M3ptLTM0LjM5Mi04MC43MjVjLTAuMjc1MTQtMC4wMjcyLTEuMTQ3NC0wLjExMTEtMS45Mzg1LTAuMTg2NTMtNS44ODA5LTAuNTYwNzgtMTEuOTU0LTIuNDg0MS0xNi40NDYtNS4yMDgtNi45NDQtNC4yMTE1LTEwLjQzOC0xMC4yODQtOS4zODM3LTE2LjMwNyAxLjMzOTUtNy42NDg0IDkuNzIzMS0xNC4xNSAyMS4zMjctMTYuNTQxIDMuNDE2NS0wLjcwMzY5IDUuMzU1My0wLjg4MTA4IDkuNjI5OC0wLjg4MTA4IDQuMjc0NCAwIDYuMjEzMyAwLjE3NzQgOS42Mjk4IDAuODgxMDggMTIuNDUgMi41NjQzIDIxLjA0MiA5Ljc2NzggMjEuNDczIDE4LjAwMyAwLjIwMDU4IDMuODI5NC0xLjI0ODYgNy40MzcxLTQuMjgxNCAxMC42NTktNC42MTU3IDQuOTAzMi0xMi4wODYgOC4yMDg2LTIxLjEzMSA5LjM0OTgtMS40MjExIDAuMTc5MjktNy43MzYgMC4zNDI4Ny04Ljg3OTQgMC4yMzAwMXptMTIwLjYyLTE5LjQ4MmMwLTYuOTgyNy01LjY1NzUtMTMuMzA4LTE1LjEzMi0xNi45Mi0yLjk1NTctMS4xMjY2LTYuMjg5OS0xLjkzNzYtMTAuMDY3LTIuNDQ4OC0yLjkxMDctMC4zOTM5Mi04Ljk3MDItMC4zOTM5Mi0xMS44ODEgMC04Ljc4MiAxLjE4ODUtMTUuNzYgNC4yMTE3LTIwLjM5OCA4LjgzNzYtMy4xNjQyIDMuMTU2LTQuODAyMyA2Ljc0ODItNC44MDIzIDEwLjUzMXYxLjE3MTdoNjIuMjgxeiIgc3Ryb2tlLXdpZHRoPSIuMTI1MDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.46369" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,207,80,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTU2LjQ4bW0iIGhlaWdodD0iMjkxLjI4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1Ni40OCAyOTEuMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjYuMDI0IC0zLjE0MDQpIj4KICA8cGF0aCBkPSJtNjMuMjE3IDI4NC42MnYtOS43OTgyaDE5Ljg1OGwwLjA5NTgtMS4yMjQ4YzAuMjQ2MjQtMy4xNDg5IDAuNTM5OTMtOS42NzY4IDAuNjI2MTYtMTMuOTE4IDAuMjA3LTEwLjE4MS0wLjY2NDk3LTE3LjMzNS0yLjg5NzctMjMuNzczLTEuODI4Ni01LjI3MjctNS40MjI0LTEyLjEwOC0xMC45ODQtMjAuODkzLTE1LjY0LTI0LjcwMi0yMy44MTYtMzkuNDY5LTMwLjI1OC01NC42NTItNy41MjctMTcuNzQtMTEuODYxLTM1LjE1NC0xMy4zNTUtNTMuNjY4LTAuMzY5NTYtNC41NzgyLTAuMzcxNjktMTQuODUyLTRlLTMgLTE4Ljg1NCAyLjAzNTYtMjIuMTQ5IDkuNDg4My0zMy4zMzggMjYuNDA5LTM5LjY0OCA1LjAxNzEtMS44NzEgMTEuMDQ4LTMuMzA4NyAyMC42MDMtNC45MTE4bDQuMjI5Ni0wLjcwOTYgMS4wNTQ0LTEuMDQ0MmMxLjU5MjgtMS41NzczIDIuMzI2Ni0zLjM0MjIgMi43MTgxLTYuNTM3MSAwLjE5OTg2LTEuNjMwOSAwLjIxMjA4LTQuODE2OCAwLjAxOTctNS4xMjEyLTAuMTIyMDYtMC4xOTMwNy0xLjU5NDEtMC4yMjkxMy0xMS4yODEtMC4yNzYzbC0xMS4xNC0wLjA1NDI1di0yNi4zOTNoOTAuNzA4djI2LjM5M2wtMTEuMTQgMC4wNTQyNWMtOS42ODY1IDAuMDQ3MTctMTEuMTU4IDAuMDgzMjItMTEuMjgxIDAuMjc2My0wLjE5MjQzIDAuMzA0MzktMC4xODAyIDMuNDkwMyAwLjAxOTYgNS4xMjEyIDAuMzkxNTMgMy4xOTUgMS4xMjU0IDQuOTU5OCAyLjcxODEgNi41MzcxbDEuMDU0NCAxLjA0NDIgNC4yMjk2IDAuNzA5NmM3LjU3MzUgMS4yNzA2IDEyLjQgMi4zMTkzIDE2Ljg5MiAzLjY3MDIgNS45NDgxIDEuNzg4OSAxMS4xNTEgNC4yODU0IDE0LjkzNCA3LjE2NjEgOS4xMzM0IDYuOTU0MyAxMy42NDcgMTYuOTc5IDE1LjE4NiAzMy43MjQgMC4zNjc4MSA0LjAwMiAwLjM2NTY5IDE0LjI3Ni00ZS0zIDE4Ljg1NC0xLjQ5NDQgMTguNTEzLTUuODI4IDM1LjkyOC0xMy4zNTUgNTMuNjY4LTYuNDQyMiAxNS4xODMtMTQuNjE4IDI5Ljk1LTMwLjI1OCA1NC42NTItNS41NjIgOC43ODQ4LTkuMTU1OCAxNS42Mi0xMC45ODQgMjAuODkzLTIuMjMyNyA2LjQzOC0zLjEwNDcgMTMuNTkyLTIuODk3NyAyMy43NzMgMC4wODYyIDQuMjQxMiAwLjM3OTkyIDEwLjc2OSAwLjYyNjE2IDEzLjkxOGwwLjA5NTggMS4yMjQ4aDE5Ljg1OHYxOS41OTZoLTgyLjA5N3YtOS43OTgyeiIgc3Ryb2tlLXdpZHRoPSIuMTQ4NDYiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.79352" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Объект культурно-просветительного назначения" value="602010201" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объект культурно-досугового (клубного) типа" value="602010202" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Зрелищная организация" value="602010203" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CU_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Библиотека, ее филиал" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Музей, музей-филиал, территориально обособленный экспозиционный отдел музея" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Лекторий (в том числе планетарий)" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Выставочный зал, галерея" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной объект культурно-просветительного назначения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLB_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Дом (дворец, центр) культуры, культуры и досуга, культуры и искусств, его филиал" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Социально-культурный, культурно-досуговый комплекс" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Центр традиционной культуры, дом (центр) народного творчества, дом ремесел и фольклора, национально-культурный центр и их филиалы" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Клуб, в том числе клуб и (или) культурно-досуговый комплекс сельского поселения" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной объект культурно-досугового (клубного) типа" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ENT_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Театр" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Концертный зал, филармония, их филиал" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Цирк, цирковая организация, их филиал" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Кинотеатр (стационарный), объект кино-видеоцентра (иной подобной организации), предназначенный для показа и популяризации фильмов" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Здание многоцелевого центра искусств" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Здание дома национального искусства" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иная зрелищная организация" value="9" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="LB_STOCK" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CAPACITY" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2147483647" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="BLD_AREA" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EXB_AREA" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="WRK_COUNT" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FUNCTION" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к ликвидации" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTROKS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTRZU" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAMEDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="DATEDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBERDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="CU_TYPE" index="6" name=""/>
    <alias field="CLB_TYPE" index="7" name=""/>
    <alias field="ENT_TYPE" index="8" name=""/>
    <alias field="LB_STOCK" index="9" name=""/>
    <alias field="CAPACITY" index="10" name="Вместимость, читательских, посетительских, зрительских мест"/>
    <alias field="BLD_AREA" index="11" name="Общая площадь здания, комплекса зданий, кв. м"/>
    <alias field="EXB_AREA" index="12" name=""/>
    <alias field="WRK_COUNT" index="13" name="Количество рабочих мест, единиц"/>
    <alias field="FUNCTION" index="14" name="Назначение объекта"/>
    <alias field="EVENT_TIME" index="15" name=""/>
    <alias field="SOURCE" index="16" name="Источник данных"/>
    <alias field="NOTE" index="17" name="Примечание"/>
    <alias field="STATUS" index="18" name="Статус объекта"/>
    <alias field="REG_STATUS" index="19" name="Значение объекта"/>
    <alias field="KADASTROKS" index="20" name="Кадастровый номер объекта капитального строительства"/>
    <alias field="KADASTRZU" index="21" name=""/>
    <alias field="NAMEDOCOSN" index="22" name=""/>
    <alias field="DATEDOCOSN" index="23" name=""/>
    <alias field="NUMBERDOCOSN" index="24" name=""/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602010201'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="CU_TYPE" expression="if(&quot;CLASSID&quot; = '602010201', attribute('CU_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="CLB_TYPE" expression="if(&quot;CLASSID&quot; = '602010202', attribute('CLB_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="ENT_TYPE" expression="if(&quot;CLASSID&quot; = '602010203', attribute('ENT_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="LB_STOCK" expression="0" applyOnUpdate="0"/>
    <default field="CAPACITY" expression="" applyOnUpdate="0"/>
    <default field="BLD_AREA" expression="0" applyOnUpdate="0"/>
    <default field="EXB_AREA" expression="0" applyOnUpdate="0"/>
    <default field="WRK_COUNT" expression="0" applyOnUpdate="0"/>
    <default field="FUNCTION" expression="''" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
    <default field="KADASTROKS" expression="''" applyOnUpdate="0"/>
    <default field="KADASTRZU" expression="''" applyOnUpdate="0"/>
    <default field="NAMEDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="DATEDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="NUMBERDOCOSN" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="CU_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="CLB_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="ENT_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="LB_STOCK" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="CAPACITY" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="BLD_AREA" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="EXB_AREA" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="WRK_COUNT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FUNCTION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="2" field="KADASTROKS" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="KADASTRZU" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAMEDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="DATEDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NUMBERDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="CU_TYPE" desc="Заполняется для объекта 602010201" exp="if(&quot;CLASSID&quot; = '602010201', &quot;CU_TYPE&quot; IS NOT NULL, &quot;CU_TYPE&quot; IS NULL)"/>
    <constraint field="CLB_TYPE" desc="Заполняется для объекта 602010202" exp="if(&quot;CLASSID&quot; = '602010202', &quot;CLB_TYPE&quot; IS NOT NULL, &quot;CLB_TYPE&quot; IS NULL)"/>
    <constraint field="ENT_TYPE" desc="Заполняется для объекта 602010203" exp="if(&quot;CLASSID&quot; = '602010203', &quot;ENT_TYPE&quot; IS NOT NULL, &quot;ENT_TYPE&quot; IS NULL)"/>
    <constraint field="LB_STOCK" desc="" exp=""/>
    <constraint field="CAPACITY" desc="Значание атрибута должно быть представлено целым положительным числом." exp="&quot;CAPACITY&quot; > 0"/>
    <constraint field="BLD_AREA" desc="" exp=""/>
    <constraint field="EXB_AREA" desc="" exp=""/>
    <constraint field="WRK_COUNT" desc="" exp=""/>
    <constraint field="FUNCTION" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3&quot;" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
    <constraint field="KADASTROKS" desc="Кадастровый номер объекта должен соответствовать формату, принятому в ЕГРН" exp="regexp_match(&quot;KADASTROKS&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$')"/>
    <constraint field="KADASTRZU" desc="Обязательно для значений атрибута &quot;STATUS&quot; 1, 3, 4. Формат кадастрового номера, принятого в ЕГРН." exp="if (&quot;STATUS&quot; = 1 OR &quot;STATUS&quot; = 3 OR &quot;STATUS&quot; = 4,&#xa;&#x9;regexp_match(&quot;KADASTRZU&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$|^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1})$'),&#xa;&#x9;length(&quot;KADASTRZU&quot;) >= 0)"/>
    <constraint field="NAMEDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;length(&quot;NAMEDOCOSN&quot;) > 0,&#xa;&#x9;length(&quot;NAMEDOCOSN&quot;) >= 0)"/>
    <constraint field="DATEDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3. Формат даты (ДД.ММ.ГГГГ)." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;regexp_match(&quot;DATEDOCOSN&quot;, '^\\d{2}\\.\\d{2}\\.\\d{4}$'),&#xa;&#x9;length(&quot;DATEDOCOSN&quot;) >= 0)"/>
    <constraint field="NUMBERDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;length(&quot;NUMBERDOCOSN&quot;) > 0,&#xa;&#x9;length(&quot;NUMBERDOCOSN&quot;) >= 0)"/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="10" name="CAPACITY">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="18" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="19" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="11" name="BLD_AREA">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="WRK_COUNT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="14" name="FUNCTION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="16" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="17" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="20" name="KADASTROKS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип объекта культурно-просветительного назначения" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010201'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="6" name="CU_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип объекта культурно-досугового (клубного) типа" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010202'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="7" name="CLB_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип зрелищной организации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010203'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="8" name="ENT_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Фонды библиотек, тыс. экземпляров" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010201'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="9" name="LB_STOCK">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Площадь выставочных (экспозиционных) залов, кв. м" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010201' OR &quot;CLASSID&quot; = '602010202'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="12" name="EXB_AREA">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="15" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Кадастровый номер земельного участка и (или) номер кадастрового квартала, в границах которого расположен объект" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (1, 3, 4)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="21" name="KADASTRZU">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Наименование документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="22" name="NAMEDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Дата документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="23" name="DATEDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="24" name="NUMBERDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="BLD_AREA" editable="1"/>
    <field name="CAPACITY" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="CLB_TYPE" editable="1"/>
    <field name="CU_TYPE" editable="1"/>
    <field name="DATEDOCOSN" editable="1"/>
    <field name="ENT_TYPE" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="EXBAREA" editable="1"/>
    <field name="EXB_AREA" editable="1"/>
    <field name="FUNCTION" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="KADASTROKS" editable="1"/>
    <field name="KADASTRZU" editable="1"/>
    <field name="LB_STOCK" editable="1"/>
    <field name="NAME" editable="1"/>
    <field name="NAMEDOCOSN" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="NUMBERDOCOSN" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="WRK_COUNT" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="BLD_AREA"/>
    <field labelOnTop="1" name="CAPACITY"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="CLB_TYPE"/>
    <field labelOnTop="1" name="CU_TYPE"/>
    <field labelOnTop="1" name="DATEDOCOSN"/>
    <field labelOnTop="1" name="ENT_TYPE"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="EXBAREA"/>
    <field labelOnTop="1" name="EXB_AREA"/>
    <field labelOnTop="1" name="FUNCTION"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="KADASTROKS"/>
    <field labelOnTop="1" name="KADASTRZU"/>
    <field labelOnTop="1" name="LB_STOCK"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NAMEDOCOSN"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="NUMBERDOCOSN"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS"/>
    <field labelOnTop="1" name="WRK_COUNT"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="BLD_AREA" reuseLastValue="0"/>
    <field name="CAPACITY" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="CLB_TYPE" reuseLastValue="0"/>
    <field name="CU_TYPE" reuseLastValue="0"/>
    <field name="DATEDOCOSN" reuseLastValue="0"/>
    <field name="ENT_TYPE" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="EXBAREA" reuseLastValue="0"/>
    <field name="EXB_AREA" reuseLastValue="0"/>
    <field name="FUNCTION" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="KADASTROKS" reuseLastValue="0"/>
    <field name="KADASTRZU" reuseLastValue="0"/>
    <field name="LB_STOCK" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NAMEDOCOSN" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="NUMBERDOCOSN" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="WRK_COUNT" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
