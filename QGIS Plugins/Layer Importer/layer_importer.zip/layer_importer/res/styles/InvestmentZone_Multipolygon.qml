<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{46a68ef6-7d44-4ca3-a70a-daa1a4028525}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{77ab253b-a36a-4916-a747-c854c45d3028}">
        <rule label="Территория опережающего развития (ТОР)" filter="&quot;CLASSID&quot; = '704010100'" symbol="1" key="{aea6cb9e-1c0a-41dc-919e-b1780715b359}"/>
        <rule label="Зона территориального развития (ЗТР)" filter="&quot;CLASSID&quot; = '704010200'" symbol="2" key="{55cdc8af-84c4-44e1-97c2-06a3919c03bf}"/>
        <rule label="Промышленный (индустриальный) парк" filter="&quot;CLASSID&quot; = '704010300'" symbol="3" key="{dd6f43d7-ca14-4458-a3f9-75011ab02c7d}"/>
        <rule label="Инновационный территориальный кластер" filter="&quot;CLASSID&quot; = '704010400'" symbol="4" key="{73e91436-33ee-4c92-8b0d-5c4f6b031255}"/>
        <rule label="Иная зона с действием особых финансовых или нефинансовых механизмов поддержки инвестиционной и инновационной деятельности" filter="&quot;CLASSID&quot; = '704010500'" symbol="5" key="{f7a8bac7-3823-4819-b9b6-e38fbd602ba4}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="6" key="{464df784-e3fe-4cf9-a1b3-dd7055772f71}">
        <rule label="Территория опережающего развития (ТОР)" filter="&quot;CLASSID&quot; = '704010100'" symbol="7" key="{5e9cbf86-9b6e-40fd-9c7b-1d78dffb1304}"/>
        <rule label="Зона территориального развития (ЗТР)" filter="&quot;CLASSID&quot; = '704010200'" symbol="8" key="{715d9f50-1710-418a-9669-916d3c6be9b1}"/>
        <rule label="Промышленный (индустриальный) парк" filter="&quot;CLASSID&quot; = '704010300'" symbol="9" key="{a6626a9f-5789-4788-9293-7ac13e1d8e66}"/>
        <rule label="Инновационный территориальный кластер" filter="&quot;CLASSID&quot; = '704010400'" symbol="10" key="{b4cea3fe-d71c-4521-ad21-695e8da53a7f}"/>
        <rule label="Иная зона с действием особых финансовых или нефинансовых механизмов поддержки инвестиционной и инновационной деятельности" filter="&quot;CLASSID&quot; = '704010500'" symbol="11" key="{f2dfdd55-3059-4454-b3af-bb92140d46c7}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="12" key="{21648d7a-525a-4e05-bb30-f87b095f9b40}">
        <rule label="Территория опережающего развития (ТОР)" filter="&quot;CLASSID&quot; = '704010100'" symbol="13" key="{7fe22dad-b7a0-4143-9290-72e3d847f4b2}"/>
        <rule label="Зона территориального развития (ЗТР)" filter="&quot;CLASSID&quot; = '704010200'" symbol="14" key="{4c1a964d-9c23-4011-97ea-36849b40668c}"/>
        <rule label="Промышленный (индустриальный) парк" filter="&quot;CLASSID&quot; = '704010300'" symbol="15" key="{aa75a95e-b601-4142-81bb-0df8bc3f7948}"/>
        <rule label="Инновационный территориальный кластер" filter="&quot;CLASSID&quot; = '704010400'" symbol="16" key="{d96ee26b-54de-41d2-a1dc-bac3e5bf77cc}"/>
        <rule label="Иная зона с действием особых финансовых или нефинансовых механизмов поддержки инвестиционной и инновационной деятельности" filter="&quot;CLASSID&quot; = '704010500'" symbol="17" key="{644ec590-5330-4bb9-869c-6282ee59eea9}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="18" key="{b0a6a741-bd73-4afa-94dd-ae9b9d78e47f}">
        <rule label="Территория опережающего развития (ТОР)" filter="&quot;CLASSID&quot; = '704010100'" symbol="19" key="{8bda3655-3b28-49e7-ab21-4e61f9f89062}"/>
        <rule label="Зона территориального развития (ЗТР)" filter="&quot;CLASSID&quot; = '704010200'" symbol="20" key="{b3904cb6-8942-4565-8e7f-d4cc554732c8}"/>
        <rule label="Промышленный (индустриальный) парк" filter="&quot;CLASSID&quot; = '704010300'" symbol="21" key="{1e1d63f0-4a62-4159-a368-c6473ae463e5}"/>
        <rule label="Инновационный территориальный кластер" filter="&quot;CLASSID&quot; = '704010400'" symbol="22" key="{6e656d90-1bea-49eb-94c8-cbd246ba3eaf}"/>
        <rule label="Иная зона с действием особых финансовых или нефинансовых механизмов поддержки инвестиционной и инновационной деятельности" filter="&quot;CLASSID&quot; = '704010500'" symbol="23" key="{88a8bbf3-7940-4de3-a3db-1135f926521e}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="24" key="{9b605c54-cc0a-48d7-b1f2-e6946d4b3447}">
        <rule label="Территория опережающего развития (ТОР)" filter="&quot;CLASSID&quot; = '704010100'" symbol="25" key="{27316e37-a0ae-43bd-bf15-913545535596}"/>
        <rule label="Зона территориального развития (ЗТР)" filter="&quot;CLASSID&quot; = '704010200'" symbol="26" key="{8932dd31-2fc3-48c6-9067-4381c087271c}"/>
        <rule label="Промышленный (индустриальный) парк" filter="&quot;CLASSID&quot; = '704010300'" symbol="27" key="{55784885-c882-4ec5-971b-24a34cb76ae7}"/>
        <rule label="Инновационный территориальный кластер" filter="&quot;CLASSID&quot; = '704010400'" symbol="28" key="{cb02fcc2-38d6-46a2-a4cc-a9edc93c3ac4}"/>
        <rule label="Иная зона с действием особых финансовых или нефинансовых механизмов поддержки инвестиционной и инновационной деятельности" filter="&quot;CLASSID&quot; = '704010500'" symbol="29" key="{a5671440-2ee2-43be-8f4c-f80b70ae291d}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="30" key="{688d4eaf-07f4-4fe2-996d-74cab629dbc6}">
        <rule label="Территория опережающего развития (ТОР)" filter="&quot;CLASSID&quot; = '704010100'" symbol="31" key="{cd91b54c-5b24-4fef-b569-f562186a652a}"/>
        <rule label="Зона территориального развития (ЗТР)" filter="&quot;CLASSID&quot; = '704010200'" symbol="32" key="{2c49c536-94fa-42ce-9edb-1c1b3de7be75}"/>
        <rule label="Промышленный (индустриальный) парк" filter="&quot;CLASSID&quot; = '704010300'" symbol="33" key="{ce0172aa-c17c-4a75-96d5-b15685e9c9cc}"/>
        <rule label="Инновационный территориальный кластер" filter="&quot;CLASSID&quot; = '704010400'" symbol="34" key="{349c6968-51b9-450b-aa0f-011e2678380d}"/>
        <rule label="Иная зона с действием особых финансовых или нефинансовых механизмов поддержки инвестиционной и инновационной деятельности" filter="&quot;CLASSID&quot; = '704010500'" symbol="35" key="{2a7d197f-0bce-4019-9821-03c4c97503de}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="141,90,153,0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0.26" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="no" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@1@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,0,255,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@1@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="6.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,255,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@10@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,255,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@10@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="6.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,255,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@11@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,255,255,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@11@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="6.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="141,90,153,0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0.26" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="no" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@13@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,0,255,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@13@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="7.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="180,0,180,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@14@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="180,0,180,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@14@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="7.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@15@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@15@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="7.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,255,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@16@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,255,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@16@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="7.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,255,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@17@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,255,255,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@17@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="7.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="232,113,141,0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0.26" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="no" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@19@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,0,255,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@19@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="7.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="180,0,180,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@2@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="180,0,180,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@2@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="6.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="180,0,180,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@20@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="180,0,180,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@20@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="7.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@21@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@21@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="7.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,255,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@22@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,255,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@22@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="7.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,255,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@23@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,255,255,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@23@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="7.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="141,90,153,0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0.26" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="no" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@25@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,0,255,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@25@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="8.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="180,0,180,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@26@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="180,0,180,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@26@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="8.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@27@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@27@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="8.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,255,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@28@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,255,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@28@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="8.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,255,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@29@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,255,255,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@29@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="8.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@3@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@3@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="6.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="232,113,141,0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0.26" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="no" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@31@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,0,255,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@31@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="8.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="180,0,180,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@32@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="180,0,180,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@32@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="8.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@33@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@33@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="8.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,255,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@34@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,255,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@34@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="8.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,255,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@35@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,255,255,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@35@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="8.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,255,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@4@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,255,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@4@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="6.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,255,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@5@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,255,255,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="square" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="1.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@5@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="6.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="232,113,141,0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0.26" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="no" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,255,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@7@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,0,255,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@7@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="6.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="180,0,180,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@8@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="180,0,180,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@8@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="6.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="190,178,151,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.15" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="PointPatternFill">
          <Option type="Map">
            <Option name="angle" value="0" type="double"/>
            <Option name="clip_mode" value="shape" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="displacement_x" value="2" type="QString"/>
            <Option name="displacement_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_x_unit" value="MM" type="QString"/>
            <Option name="displacement_y" value="0" type="QString"/>
            <Option name="displacement_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="displacement_y_unit" value="MM" type="QString"/>
            <Option name="distance_x" value="4" type="QString"/>
            <Option name="distance_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_x_unit" value="MM" type="QString"/>
            <Option name="distance_y" value="4" type="QString"/>
            <Option name="distance_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_y_unit" value="MM" type="QString"/>
            <Option name="offset_x" value="0" type="QString"/>
            <Option name="offset_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_x_unit" value="MM" type="QString"/>
            <Option name="offset_y" value="0" type="QString"/>
            <Option name="offset_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_y_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="random_deviation_x" value="0" type="QString"/>
            <Option name="random_deviation_x_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_x_unit" value="MM" type="QString"/>
            <Option name="random_deviation_y" value="0" type="QString"/>
            <Option name="random_deviation_y_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="random_deviation_y_unit" value="MM" type="QString"/>
            <Option name="seed" value="790107145" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@9@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="CentroidFill">
          <Option type="Map">
            <Option name="clip_on_current_part_only" value="0" type="QString"/>
            <Option name="clip_points" value="0" type="QString"/>
            <Option name="point_on_all_parts" value="1" type="QString"/>
            <Option name="point_on_surface" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@9@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="6.6" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
            <layer enabled="1" locked="0" pass="0" class="SvgMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="fixedAspectRatio" value="0" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijc0LjUyNW1tIiBoZWlnaHQ9IjgyLjU0N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3NC41MjUgODIuNTQ3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02Ny43MzcgLTY4LjQxMykiPjxwYXRoIGQ9Im03My42NzcgOTQuNDgyYy0zLjI5MDQgMC01LjkzOTcgMi42NDkyLTUuOTM5NyA1LjkzOTd2NDQuNTk5YzAgMy4yOTA0IDIuNjQ5MyA1LjkzOTcgNS45Mzk3IDUuOTM5N2g2Mi42NDZjMy4yOTA0IDAgNS45MzkyLTIuNjQ5MyA1LjkzOTItNS45Mzk3di00NC41OTljMC0zLjI5MDQtMi42NDg4LTUuOTM5Ny01LjkzOTItNS45Mzk3em0yMy44NTYgNy41OThoMTkuNThjMi45ODkxIDAgNS4zOTU1IDIuNDA2NCA1LjM5NTUgNS4zOTU1djExLjk1MmMwIDIuOTg5MS0yLjQwNjQgNS4zOTU1LTUuMzk1NSA1LjM5NTVoLTIwLjkyOHY1LjA3OThoMjMuMjU4YzAuMDE5NSAwIDAuMDM1MSAwLjAxNTYgMC4wMzUxIDAuMDM1MXY0LjExNGMwIDAuMDE5NS0wLjAxNTYgMC4wMzU3LTAuMDM1MSAwLjAzNTdoLTIzLjI1OHY1Ljg1NzVjMCAwLjAyMTUtMC4wMTk2NCAwLjAzOTMtMC4wNDQ0NCAwLjAzOTNoLTMuOTQxOWMtMC4wMjQ4IDAtMC4wNDQ0NC0wLjAxNzktMC4wNDQ0NC0wLjAzOTN2LTUuODU3NWgtNC4yNTE0Yy0wLjAxOTUzIDAtMC4wMzUxNC0wLjAxNjEtMC4wMzUxNC0wLjAzNTd2LTQuMTE0YzAtMC4wMTk1IDAuMDE1NjEtMC4wMzUxIDAuMDM1MTQtMC4wMzUxaDQuMjUxNHYtNS4wNzk4aC00LjI0OTRjLTAuMDIwNSAwLTAuMDM3MjEtMC4wMTY3LTAuMDM3MjEtMC4wMzcydi00LjEyODljMC0wLjAyMDUgMC4wMTY3MS0wLjAzNzIgMC4wMzcyMS0wLjAzNzJoNC4yNDk0di0wLjc3OThjLTAuMDEwMjItMC4xMzYyNy0wLjAxNzA1LTAuMjczNC0wLjAxNzA1LTAuNDEyMzd2LTExLjk1MmMwLTIuOTg5MSAyLjQwNjQtNS4zOTU1IDUuMzk1NS01LjM5NTV6bTAuNjkwOTEgMy41NTljLTEuMjE4IDAtMi4xOTgzIDAuOTgwMzUtMi4xOTgzIDIuMTk4M3YxMS4yMjhjMCAwLjIwNDQzIDAuMDI3ODYgMC40MDIxIDAuMDc5NTggMC41ODk2M2gwLjAwOTNjMC4wMTk0IDAuMDY5OSAwLjA0MjcgMC4xMzgwNCAwLjA3MDggMC4yMDQ2NHYwLjAzMTVjMC4xMTA4NSAwLjI3NDgyIDAuMjc1MDQgMC41MjIwMiAwLjQ4MDU5IDAuNzI4MTJsNS4xN2UtNCA1LjJlLTQgMC4wMDE2IDJlLTNjMC4wNDc0MyAwLjA0NzQgMC4wOTcyMiAwLjA5MjUgMC4xNDg4MyAwLjEzNTM5bDAuMDA3MiA2ZS0zYzAuMDUzMiAwLjA0MzkgMC4xMDg2MiAwLjA4NTMgMC4xNjU4OCAwLjEyNDAyIDcuMWUtNCA0LjllLTQgMC4wMDE0IDFlLTMgMC4wMDIxIDJlLTMgMy4xNmUtNCAyLjFlLTQgNy4xOGUtNCAzZS00IDFlLTMgNS4xZS00IDAuMDU0NzIgMC4wMzY5IDAuMTExMzkgMC4wNzE0IDAuMTY5NSAwLjEwMzM1IDAuMDAzNSAyZS0zIDAuMDA2OCA0ZS0zIDAuMDEwMzMgNmUtMyA0LjdlLTQgMi41ZS00IDAuMDAxMSAyLjZlLTQgMC4wMDE2IDUuMWUtNCAwLjAwMjQgMWUtMyAwLjAwNDkgMmUtMyAwLjAwNzIgNGUtMyAwLjA1Nzg4IDAuMDMxMSAwLjExNjg5IDAuMDU5OSAwLjE3Nzc3IDAuMDg1OCAwLjAwMTkgOC4yZS00IDAuMDAzOCAyZS0zIDAuMDA1NyAzZS0zIDQuOTllLTQgMi4xZS00IDAuMDAxMSAzZS00IDAuMDAxNSA1LjFlLTQgNWUtNCAyLjFlLTQgMC4wMDExIDMuMWUtNCAwLjAwMTYgNS4yZS00IDAuMDYxMzkgMC4wMjU4IDAuMTI0NSAwLjA0ODUgMC4xODg2MiAwLjA2ODcgMC4wMDM3IDFlLTMgMC4wMDcxIDNlLTMgMC4wMTA4NSA0ZS0zIDMuMTNlLTQgMWUtNCA3LjJlLTQgLTllLTUgMWUtMyAwIDAuMDAyOSA5ZS00IDAuMDA1OSAyZS0zIDAuMDA4OCAzZS0zIDAuMDY0NiAwLjAxOTcgMC4xMzAzOSAwLjAzNjggMC4xOTc0IDAuMDUwNiAwLjAwMTQgMi45ZS00IDAuMDAyNyA3LjVlLTQgMC4wMDQxIDFlLTMgMS42NmUtNCA0ZS01IDMuNTJlLTQgLTNlLTUgNS4xN2UtNCAwIDFlLTMgMi4xZS00IDAuMDAyMSAzLjJlLTQgMC4wMDMxIDUuMmUtNCAwLjA2OTgxIDAuMDE0MSAwLjE0MDgzIDAuMDI0NyAwLjIxMjkxIDAuMDMyIDguODFlLTQgOWUtNSAwLjAwMTcgNC4zZS00IDAuMDAyNiA1LjJlLTQgMS43MWUtNCAxZS01IDMuNDdlLTQgLTJlLTUgNS4xN2UtNCAwIDMuMzllLTQgM2UtNSA2Ljk1ZS00IC00ZS01IDFlLTMgMCAwLjA3MzcyIDdlLTMgMC4xNDg1NCAwLjAxMTQgMC4yMjQyOCAwLjAxMTRoMTguMTk4YzEuMjE4IDAgMi4xOTgzLTAuOTgwMzUgMi4xOTgzLTIuMTk4M3YtMTEuMjI4YzAtMS4yMTgtMC45ODAzNC0yLjE5ODMtMi4xOTgzLTIuMTk4M3oiIGZpbGw9IiMwMjAwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxNCIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xLjM3OTcpIiBzdHJva2U9IiMwMDAiPjxyZWN0IHg9Ijg5LjMyNiIgeT0iNzAuOTEzIiB3aWR0aD0iMzQuMTA3IiBoZWlnaHQ9IjE2LjQ4MSIgcng9IjEuNzM3IiByeT0iMCIgZmlsbC1vcGFjaXR5PSIwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjUiLz48cGF0aCBkPSJtODYuODI2IDg3LjQ0MWgzOS4xMDciIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iNS4wNTE3Ii8+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="parameters"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="4.33353" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Территория опережающего социально-экономического развития (ТОСЭР)" value="704010100" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Зона территориального развития (ЗТР)" value="704010200" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Промышленный (индустриальный) парк" value="704010300" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Инновационный территориальный кластер" value="704010400" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иная зона с действием особых финансовых или нефинансовых механизмов поддержки инвестиционной и инновационной деятельности" value="704010500" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="true" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="MAIN_ACTIV" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="AREA" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="LIVE_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTROKS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTRZU" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAMEDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="DATEDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBERDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="ADDRESS" index="4" name="Местоположение, адресное описание"/>
    <alias field="MAIN_ACTIV" index="5" name="Основная специализация, перечень видов экономической деятельности, при осуществлении которых действует особый правовой режим осуществления предпринимательской деятельности"/>
    <alias field="AREA" index="6" name="Общая площадь территории зоны (кластера), га"/>
    <alias field="LIVE_TIME" index="7" name="Срок функционирования зоны"/>
    <alias field="EVENT_TIME" index="8" name=""/>
    <alias field="SOURCE" index="9" name="Источник данных (вносятся реквизиты правовых актов о решении создания объектов или другие источники данных)"/>
    <alias field="NOTE" index="10" name="Примечание"/>
    <alias field="STATUS" index="11" name="Статус объекта"/>
    <alias field="REG_STATUS" index="12" name="Значение объекта"/>
    <alias field="KADASTROKS" index="13" name="Кадастровый номер объекта капитального строительства"/>
    <alias field="KADASTRZU" index="14" name=""/>
    <alias field="NAMEDOCOSN" index="15" name=""/>
    <alias field="DATEDOCOSN" index="16" name=""/>
    <alias field="NUMBERDOCOSN" index="17" name=""/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'704010100'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="MAIN_ACTIV" expression="''" applyOnUpdate="0"/>
    <default field="AREA" expression="round(area($geometry) / 10000, 2)" applyOnUpdate="1"/>
    <default field="LIVE_TIME" expression="0" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
    <default field="KADASTROKS" expression="''" applyOnUpdate="0"/>
    <default field="KADASTRZU" expression="''" applyOnUpdate="0"/>
    <default field="NAMEDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="DATEDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="NUMBERDOCOSN" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="MAIN_ACTIV" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="AREA" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="LIVE_TIME" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="2" field="KADASTROKS" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="KADASTRZU" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAMEDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="DATEDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NUMBERDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значения атрибута &quot;STATUS&quot; 2." exp="if (&quot;STATUS&quot; = 2,&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="MAIN_ACTIV" desc="Минимальная длина строки - 1 символ" exp="length(&quot;MAIN_ACTIV&quot;) > 0"/>
    <constraint field="AREA" desc="" exp=""/>
    <constraint field="LIVE_TIME" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значения атрибута &quot;STATUS&quot; 2" exp="if (&quot;STATUS&quot; = 2,&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
    <constraint field="KADASTROKS" desc="Кадастровый номер должен соответствовать формату, принятому в ЕГРН" exp="regexp_match(&quot;KADASTROKS&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$')"/>
    <constraint field="KADASTRZU" desc="Обязательно для значения атрибута &quot;STATUS&quot; 1" exp="if (&quot;STATUS&quot; = 1,&#xa;&#x9;regexp_match(&quot;KADASTRZU&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$|^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1})$'),&#xa;&#x9;length(&quot;KADASTRZU&quot;) >= 0)"/>
    <constraint field="NAMEDOCOSN" desc="Обязательно для значения атрибута &quot;STATUS&quot; 2" exp="if (&quot;STATUS&quot; = 2,&#xa;&#x9;length(&quot;NAMEDOCOSN&quot;) > 0,&#xa;&#x9;length(&quot;NAMEDOCOSN&quot;) >= 0)"/>
    <constraint field="DATEDOCOSN" desc="Обязательно для значения атрибута &quot;STATUS&quot; 2. Формат даты (ДД.ММ.ГГГГ)." exp="if (&quot;STATUS&quot; = 2,&#xa;&#x9;regexp_match(&quot;DATEDOCOSN&quot;, '^\\d{2}\\.\\d{2}\\.\\d{4}$'),&#xa;&#x9;length(&quot;KADASTRZU&quot;) >= 0)"/>
    <constraint field="NUMBERDOCOSN" desc="Обязательно для значения атрибута &quot;STATUS&quot; 2" exp="if (&quot;STATUS&quot; = 2,&#xa;&#x9;length(&quot;NUMBERDOCOSN&quot;) > 0,&#xa;&#x9;length(&quot;NUMBERDOCOSN&quot;) >= 0)"/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="5" name="MAIN_ACTIV">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="6" name="AREA">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="11" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="12" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="4" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="7" name="LIVE_TIME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="9" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="10" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="KADASTROKS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; = 2">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; = 2">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="8" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Кадастровый номер земельного участка и (или) номер кадастрового квартала, в границах которого расположен объект" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; = 1">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="14" name="KADASTRZU">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Наименование документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; = 2">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="15" name="NAMEDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Дата документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; = 2">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="16" name="DATEDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; = 2">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="17" name="NUMBERDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="AREA" editable="0"/>
    <field name="CLASSID" editable="1"/>
    <field name="DATEDOCOSN" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="KADASTROKS" editable="1"/>
    <field name="KADASTRZU" editable="1"/>
    <field name="LIVE_TIME" editable="1"/>
    <field name="MAIN_ACTIV" editable="1"/>
    <field name="NAME" editable="1"/>
    <field name="NAMEDOCOSN" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="NUMBERDOCOSN" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="AREA"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="DATEDOCOSN"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="KADASTROKS"/>
    <field labelOnTop="1" name="KADASTRZU"/>
    <field labelOnTop="1" name="LIVE_TIME"/>
    <field labelOnTop="1" name="MAIN_ACTIV"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NAMEDOCOSN"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="NUMBERDOCOSN"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="AREA" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="DATEDOCOSN" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="KADASTROKS" reuseLastValue="0"/>
    <field name="KADASTRZU" reuseLastValue="0"/>
    <field name="LIVE_TIME" reuseLastValue="0"/>
    <field name="MAIN_ACTIV" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NAMEDOCOSN" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="NUMBERDOCOSN" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>2</layerGeometryType>
</qgis>
