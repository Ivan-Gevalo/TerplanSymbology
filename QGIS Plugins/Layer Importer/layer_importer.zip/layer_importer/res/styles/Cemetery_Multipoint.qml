<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{d49ae29d-a3c4-47f6-b2b1-15ae0014c9dd}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{4fe8ee47-7a36-45e3-8c6d-338d71aeccef}">
        <rule label="Кладбище" filter="&quot;CLASSID&quot; = '602050301'" symbol="1" key="{b9f6d436-5fe6-4799-ac83-878720e9f039}"/>
        <rule label="Воинское кладбище, военное мемориальное кладбище" filter="&quot;CLASSID&quot; = '602050302'" symbol="2" key="{d0eb36eb-8143-4cf4-9d09-b249f2840997}"/>
        <rule label="Крематорий" filter="&quot;CLASSID&quot; = '602050303'" symbol="3" key="{8a76e735-d04a-4dec-a744-5add3ea63e21}"/>
        <rule label="Историческое кладбище" filter="&quot;CLASSID&quot; = '602050304'" symbol="4" key="{d2d299f3-9ee9-42d0-9142-505fec2a0d24}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="5" key="{385c7499-199e-44f9-a141-e7f87da9a880}">
        <rule label="Кладбище" filter="&quot;CLASSID&quot; = '602050301'" symbol="6" key="{2096bdba-9114-458c-90d0-6522ebfe1f11}"/>
        <rule label="Воинское кладбище, военное мемориальное кладбище" filter="&quot;CLASSID&quot; = '602050302'" symbol="7" key="{69858318-fdc4-45d0-b427-03062867972e}"/>
        <rule label="Крематорий" filter="&quot;CLASSID&quot; = '602050303'" symbol="8" key="{43c96e85-f8a4-48a8-8b96-26ea00d29cc8}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="9" key="{70cb06ad-0a1e-4a9f-a7e0-65f7f26345c6}">
        <rule label="Кладбище" filter="&quot;CLASSID&quot; = '602050301'" symbol="10" key="{de7b4d64-dd9d-4256-bac5-54d842cc6bbb}"/>
        <rule label="Воинское кладбище, военное мемориальное кладбище" filter="&quot;CLASSID&quot; = '602050302'" symbol="11" key="{ca3d5cf7-cb48-4a17-86e0-4781bc4912f8}"/>
        <rule label="Крематорий" filter="&quot;CLASSID&quot; = '602050303'" symbol="12" key="{02005359-af8f-46fa-8fcf-addb6a2ada9a}"/>
        <rule label="Историческое кладбище" filter="&quot;CLASSID&quot; = '602050304'" symbol="13" key="{6c92a87a-4f6f-49dc-b01e-505bc9c02c4a}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="14" key="{ac0b003e-8f0a-43a2-bd9a-a5d1af94b81f}">
        <rule label="Кладбище" filter="&quot;CLASSID&quot; = '602050301'" symbol="15" key="{5a467c8d-e60e-4508-961a-9eb19b4be54b}"/>
        <rule label="Воинское кладбище, военное мемориальное кладбище" filter="&quot;CLASSID&quot; = '602050302'" symbol="16" key="{5d51cbf0-cdff-4703-af37-01075268bbc4}"/>
        <rule label="Крематорий" filter="&quot;CLASSID&quot; = '602050303'" symbol="17" key="{561e2013-cbb3-4827-b81a-9d1c7f3da1db}"/>
        <rule label="Историческое кладбище" filter="&quot;CLASSID&quot; = '602050304'" symbol="18" key="{2d254344-b554-42c1-b602-02172aa17ba5}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="19" key="{c204897e-70c9-41f1-866c-ae251fd3d721}">
        <rule label="Кладбище" filter="&quot;CLASSID&quot; = '602050301'" symbol="20" key="{46517add-3fbf-4a68-8cca-04b4f1c47e7a}"/>
        <rule label="Воинское кладбище, военное мемориальное кладбище" filter="&quot;CLASSID&quot; = '602050302'" symbol="21" key="{11ef3330-da08-452f-9f5e-ef371b5dfb3d}"/>
        <rule label="Крематорий" filter="&quot;CLASSID&quot; = '602050303'" symbol="22" key="{eb8a2143-23e5-446d-9423-3da01ed168a1}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="23" key="{9e829663-5184-4f2e-8f5e-738ad9ea343f}">
        <rule label="Кладбище" filter="&quot;CLASSID&quot; = '602050301'" symbol="24" key="{21eda44c-65e3-4c9e-b800-39f017287540}"/>
        <rule label="Воинское кладбище, военное мемориальное кладбище" filter="&quot;CLASSID&quot; = '602050302'" symbol="25" key="{93352e9e-244b-4348-b1c2-723df76dc29b}"/>
        <rule label="Крематорий" filter="&quot;CLASSID&quot; = '602050303'" symbol="26" key="{89ab6eb7-fb9a-420d-a370-ce5477792772}"/>
        <rule label="Историческое кладбище" filter="&quot;CLASSID&quot; = '602050304'" symbol="27" key="{bec14f1f-31e3-4e11-90a2-231d7089bfe7}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="28" key="{d016d62f-6180-4555-956b-84497b38b0bb}">
        <rule label="Кладбище" filter="&quot;CLASSID&quot; = '602050301'" symbol="29" key="{01f03e0f-49c8-487e-8fdb-86ce09d79241}"/>
        <rule label="Воинское кладбище, военное мемориальное кладбище" filter="&quot;CLASSID&quot; = '602050302'" symbol="30" key="{a44d8bc2-ce38-49c8-8356-7bb9b92813cd}"/>
        <rule label="Крематорий" filter="&quot;CLASSID&quot; = '602050303'" symbol="31" key="{6dc355e4-10cc-4848-894f-83eabb4fa7f4}"/>
        <rule label="Историческое кладбище" filter="&quot;CLASSID&quot; = '602050304'" symbol="32" key="{a4e07192-8040-48e1-95f1-bfb0b753d46d}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="33" key="{70257a7f-2028-427e-a2c5-2503f6ba68cc}">
        <rule label="Кладбище" filter="&quot;CLASSID&quot; = '602050301'" symbol="34" key="{79e7090e-3666-4a6b-84fc-18de6cb51723}"/>
        <rule label="Воинское кладбище, военное мемориальное кладбище" filter="&quot;CLASSID&quot; = '602050302'" symbol="35" key="{49937ccb-b04d-4440-801a-905ab3dae83a}"/>
        <rule label="Крематорий" filter="&quot;CLASSID&quot; = '602050303'" symbol="36" key="{fcdf7496-96cb-4262-93e8-5402e16e7fbd}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="37" key="{2d68c752-f209-4893-8ee5-97470b1d47e9}">
        <rule label="Кладбище" filter="&quot;CLASSID&quot; = '602050301'" symbol="38" key="{7052c99d-c02e-4f64-b12c-6e2cb01ae1e9}"/>
        <rule label="Воинское кладбище, военное мемориальное кладбище" filter="&quot;CLASSID&quot; = '602050302'" symbol="39" key="{8b930033-a692-4510-a6ea-10dfb422daff}"/>
        <rule label="Крематорий" filter="&quot;CLASSID&quot; = '602050303'" symbol="40" key="{065ec5a7-b160-4c50-b519-ef1c04233658}"/>
        <rule label="Историческое кладбище" filter="&quot;CLASSID&quot; = '602050304'" symbol="41" key="{e34259fc-b769-4791-a369-b308ea1438b9}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTk4LjUzbW0iIGhlaWdodD0iMTc2LjAybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE5OC41MyAxNzYuMDIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMi4zMjQ1IC01Mi4wMjUpIj4KICA8cGF0aCBkPSJtMi4zMjQ1IDIxNC44MnYtMTMuMjIyaDI2LjgyM2wyZS0zIC01MC43NjVjOS40ZS00IC0zMi4zNTYgMC4wNzAyLTUxLjU1MiAwLjE5MDk2LTUyLjkzNyAyLjEzOC0yNC41MTYgMjEuNDI0LTQzLjcxIDQ1LjkzOC00NS43MTcgMS43MDM0LTAuMTM5NTEgMTAuNy0wLjE4MzI0IDI4LjAxLTAuMTM2MTMgMjcuODUzIDAuMDc1OCAyNi4zNDcgMC4wMTg3OSAzMS41OTQgMS4xOTU4IDE4Ljg4MSA0LjIzNDYgMzMuNTM0IDE4LjgyNyAzNy45MTkgMzcuNzYzIDAuMTY4NDMgMC43MjcyMyAwLjQ4NjY2IDIuMzg0OCAwLjcwNzE2IDMuNjgzNCAwLjQwMDg3IDIuMzYwOSAwLjQwMDkyIDIuMzY2NyAwLjQ2Mzg5IDU0LjYzN2wwLjA2MyA1Mi4yNzZoMjYuODE1djI2LjQ0NWgtMTk4LjUzem0xMzQuODctNjQuMTE5YzAtNTUuODAyIDAuMDU5OC01Mi43NC0xLjEyMTUtNTcuNDE3LTEuNTE5OC02LjAxNzYtNC41NDcxLTExLjI2LTkuMTcxOS0xNS44ODItNS4zNzg0LTUuMzc1OS0xMS40NDMtOC41MjI0LTE4Ljk4NS05Ljg1MDgtMS44MTkyLTAuMzIwNDEtMy4yMzQ1LTAuMzQ5MzMtMTcuMDk1LTAuMzQ5MzMtMTYuMzI2IDAtMTYuMzY5IDAuMDAyMi0yMC40MzIgMS4wNDgtNi4wNzA0IDEuNTYyNi0xMS4yMjkgNC41NDMzLTE1LjgzNiA5LjE1MS01LjI4NzUgNS4yODc1LTguMjU3NSAxMC45NTMtOS44NTM2IDE4Ljc5Ni0wLjMwNDE2IDEuNDk0Ni0wLjMzMDg5IDUuMTkzOC0wLjM4NjYgNTMuNTA0bC0wLjA1OTggNTEuODk4aDkyLjk0MXoiIHN0cm9rZS13aWR0aD0iLjE4ODg5Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.96269" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTk4LjUzbW0iIGhlaWdodD0iMTc2LjAybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE5OC41MyAxNzYuMDIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMi4zMjQ1IC01Mi4wMjUpIj4KICA8cGF0aCBkPSJtMi4zMjQ1IDIxNC44MnYtMTMuMjIyaDI2LjgyM2wyZS0zIC01MC43NjVjOS40ZS00IC0zMi4zNTYgMC4wNzAyLTUxLjU1MiAwLjE5MDk2LTUyLjkzNyAyLjEzOC0yNC41MTYgMjEuNDI0LTQzLjcxIDQ1LjkzOC00NS43MTcgMS43MDM0LTAuMTM5NTEgMTAuNy0wLjE4MzI0IDI4LjAxLTAuMTM2MTMgMjcuODUzIDAuMDc1OCAyNi4zNDcgMC4wMTg3OSAzMS41OTQgMS4xOTU4IDE4Ljg4MSA0LjIzNDYgMzMuNTM0IDE4LjgyNyAzNy45MTkgMzcuNzYzIDAuMTY4NDMgMC43MjcyMyAwLjQ4NjY2IDIuMzg0OCAwLjcwNzE2IDMuNjgzNCAwLjQwMDg3IDIuMzYwOSAwLjQwMDkyIDIuMzY2NyAwLjQ2Mzg5IDU0LjYzN2wwLjA2MyA1Mi4yNzZoMjYuODE1djI2LjQ0NWgtMTk4LjUzem0xMzQuODctNjQuMTE5YzAtNTUuODAyIDAuMDU5OC01Mi43NC0xLjEyMTUtNTcuNDE3LTEuNTE5OC02LjAxNzYtNC41NDcxLTExLjI2LTkuMTcxOS0xNS44ODItNS4zNzg0LTUuMzc1OS0xMS40NDMtOC41MjI0LTE4Ljk4NS05Ljg1MDgtMS44MTkyLTAuMzIwNDEtMy4yMzQ1LTAuMzQ5MzMtMTcuMDk1LTAuMzQ5MzMtMTYuMzI2IDAtMTYuMzY5IDAuMDAyMi0yMC40MzIgMS4wNDgtNi4wNzA0IDEuNTYyNi0xMS4yMjkgNC41NDMzLTE1LjgzNiA5LjE1MS01LjI4NzUgNS4yODc1LTguMjU3NSAxMC45NTMtOS44NTM2IDE4Ljc5Ni0wLjMwNDE2IDEuNDk0Ni0wLjMzMDg5IDUuMTkzOC0wLjM4NjYgNTMuNTA0bC0wLjA1OTggNTEuODk4aDkyLjk0MXoiIHN0cm9rZS13aWR0aD0iLjE4ODg5Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.96269" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yMW1tIiBoZWlnaHQ9IjE1Mi4xbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE4Mi4yMSAxNTIuMSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtOS4wMzA5IC02MS4xMDMpIj48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE1OS44NCAyMTEuNjQtMTQ5LjI0LTkwLjU0MSAxNzkuMDktMC4xMTEwNW0tMTQ5LjM2IDkwLjY1MiAxNDkuMzYtOTAuNjUybS04OS42LTU4LjMyMyA1OS43NTYgMTQ4Ljk4bS01OS43NTYtMTQ4Ljk4LTU5Ljc1NiAxNDguOTgiIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMy4xMjIxIi8+PGc+PGc+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtMzEzLjk4IDYxNS45OGMtNDIuMTcyLTI1LjYyMy02My43NDctMzkuNTQtNjMuNi00MS4wMjYgMC4xMjIyOC0xLjIzNyAxMC4wMjYtMjYuNjIxIDIyLjAwOC01Ni40MDlsMjEuNzg1LTU0LjE2IDE2OC41NyAwLjcwNTQ4IDQ0LjU3OCAxMTEuNDQtNC42MDc4IDIuODEyYy0zMC42NDUgMTguNzAyLTEyMC40NSA3My4wNjUtMTIyLjM4IDc0LjA4LTEuOTc4IDEuMDQxNi0xNi41NjgtNy4xOTA3LTY2LjM1OC0zNy40NDJ6IiBzdHJva2Utd2lkdGg9IjE2LjA4MSIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTUxOC4yMyA1NjkuMTVjLTAuMjQ5MDEtMC42MjgyNi05LjgwNzctMjQuNDY3LTIxLjI0Mi01Mi45NzUtMTEuNDM0LTI4LjUwOC0yMC43MTItNTEuOTEtMjAuNjE5LTUyLjAwMyAwLjA5MzctMC4wOTM3IDQ4Ljk4LTAuMTExNDMgMTA4LjY0LTAuMDM5NGwxMDguNDcgMC4xMzA5LTc3LjM3NyA0Ni45NDVjLTQyLjU1NyAyNS44Mi04MS44ODUgNDkuNjc2LTg3LjM5NiA1My4wMTUtOS41OTk0IDUuODE1OS0xMC4wMzggNi4wMjIzLTEwLjQ3MiA0LjkyNzl6IiBzdHJva2Utd2lkdGg9IjUuNjg1NiIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTI5OS40NyA0NDkuODZjMC4zODE4LTAuOTI3MjIgMTUuMzczLTM4LjI3OSAzMy4zMTMtODMuMDA1bDMyLjYxOS04MS4zMTkgMjUuODQ2IDAuMjc2NzMgMzIuODc4IDgxLjk0NWMxOC4wODMgNDUuMDcgMzMuMDEgODIuMzYgMzMuMTcxIDgyLjg2NiAwLjI3OTA3IDAuODc5MjgtMy4yOTQ3IDAuOTIwODctNzkuMTE0IDAuOTIwODdoLTc5LjQwN3oiIHN0cm9rZS13aWR0aD0iNS42ODU2Ii8+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtNDkwLjcxIDcyMy41MWMtNTQuNDkyLTMzLjA1OS05OS4wMS02MC40MTQtOTguOTMtNjAuNzg5IDAuMjU3NjctMS4xOTc4IDEyMC4xNy03My43MDkgMTIwLjgtNzMuMDQ4IDAuODg3MzEgMC45Mjg3MyA3Ny44ODQgMTkzLjI2IDc3LjUxNSAxOTMuNjMtMC4xNzE2MSAwLjE3MTM5LTQ0Ljg5Ni0yNi43MzYtOTkuMzg4LTU5Ljc5NXoiIHN0cm9rZS13aWR0aD0iMTEuMzcxIi8+PC9nPjxwYXRoIGQ9Im05OS45MzIgNzUuNDM1Yy0yLjc1NTMtMC4wMzkxOS0zLjU2NTYtMC4xMDA5My0zLjUwNDEtMC4yNjcwMiAxLjgzNDQtNC45NTcgMy40NTExLTkuMjAyOCAzLjU0MzEtOS4zMDUzIDAuMDY1OTMtMC4wNzMyOCAwLjg0Nzk5IDEuODIzMyAxLjczODIgNC4yMTQ2IDAuODkwMiAyLjM5MTMgMS43MTczIDQuNjA0NyAxLjgzNzkgNC45MTg2IDAuMTIwNzEgMC4zMTM5IDAuMTYzMDMgMC41NTI1OSAwLjA5NDEgMC41MzA0NC0wLjA2ODgtMC4wMjIxNy0xLjczODEtMC4wNjMyMy0zLjcwOTMtMC4wOTEyOHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIxLjg2MDMiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNDkuODkgNTE2Ljk4LTg2LjY5NC01Mi42MTQgMTA4LjI3LTAuMTg1ODNjNTkuNTQ5LTAuMTAyMiAxMDguMzgtMC4wNzU1IDEwOC41MiAwLjA1OTIgMC41MDI3MyAwLjUwMjczLTQxLjk2MiAxMDUuMzctNDIuNjY2IDEwNS4zNi0wLjQwMzQ3LTNlLTMgLTM5Ljc0Ni0yMy42ODItODcuNDI4LTUyLjYyeiIgc3Ryb2tlLXdpZHRoPSI4LjA0MDYiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNjcuNDYgNzgxLjE4YzAuMjg5OS0xLjE1OTMgMTcuNjUyLTQ0Ljg0NCAzOC41ODEtOTcuMDc3bDM4LjA1NC05NC45NyA0LjQ5MzcgMi44NTI5YzIuNDcxNSAxLjU2OTEgMjkuMzk3IDE3Ljg5NiA1OS44MzQgMzYuMjgzczU1LjM2MSAzMy44NjIgNTUuMzg2IDM0LjM5MWMwLjAyNTIgMC41MjgzOC00Mi43MDQgMjYuODgtOTQuOTU0IDU4LjU2LTUyLjI1IDMxLjY4LTk2LjU1NyA1OC42MDUtOTguNDYxIDU5LjgzNC0yLjkyMSAxLjg4NTktMy4zNzkyIDEuOTA1OC0yLjkzNDQgMC4xMjcwNnoiIHN0cm9rZS13aWR0aD0iMTYuMDgxIi8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTc0LjAzbW0iIGhlaWdodD0iMjgyLjgzbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NC4wMyAyODIuODMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjAuODk4IC02LjgzOSkiPgogIDxwYXRoIGQ9Im00OS43NDYgMjc4LjkyYy01LjYxMjctNS44NTQtMTQuNC0xNC45ODMtMTkuNTI3LTIwLjI4Ni01LjEyNy01LjMwMzUtOS4zMjE4LTkuNzY0NS05LjMyMTgtOS45MTMzIDAtMC4xNDg4MyAxLjMwNDUtMi4yNzc2IDIuODk4OC00LjczMDUgMS41OTQzLTIuNDUzIDUuNjg0NS04Ljg3NTUgOS4wODk0LTE0LjI3MiA4LjkxNjQtMTQuMTMzIDI1Ljg0LTQwLjU0OSAzMi42MjUtNTAuOTI0IDEuNzk5Mi0yLjc1MTEgMy4yNzEyLTUuMTY1IDMuMjcxMi01LjM2NDFzMC4xNDEwNy0wLjQyMDk2IDAuMzEzNDktMC40OTI5MmMwLjE3MjQyLTAuMDcyIDIuOTg5NS00LjIyODkgNi4yNjAxLTkuMjM3N2w1Ljk0NjYtOS4xMDY5LTMuNjUxOC02LjM5NjhjLTIuMDA4NS0zLjUxODItNS43ODE4LTEwLjAzMS04LjM4NTEtMTQuNDcyLTExLjMxNy0xOS4zMDctMTQuMTk2LTI3LjE4Mi0xMy42OTYtMzcuNDU0IDAuODc5MTMtMTguMDU4IDExLjg4Mi01Ny44MyAyMC4xMjQtNzIuNzQ1IDEuOTk3Ny0zLjYxNDggOC4wMzQ1LTkuNTc3NiAxMi4xMTUtMTEuOTY2IDYuMTc0OC0zLjYxNDYgMTEuMjg5LTQuNzQxOCAyMS40MDEtNC43MTY5IDYuMTU4IDAuMDE1MTU4IDcuNzU4MyAwLjE0Nzc5IDEwLjUzMyAwLjg3Mjk3IDQuMTU3NyAxLjA4NjUgNy43MyAyLjcwNjUgMTAuNzk4IDQuODk2NSAyLjk2MjMgMi4xMTQ5IDcuODM4NCA3LjE2NDQgOS45Mzg3IDEwLjI5MiA4LjgzNSAxMy4xNTcgMTguNTI5IDM3Ljk4MSAyMi45MDIgNTguNjQ4IDEuMDgxOCA1LjExMjMgMS40NjY1IDEzLjE0MSAwLjc5NDM2IDE2LjU3OS0xLjU5NTIgOC4xNTg2LTYuNTEwNyAxOC40MTMtMTcuMDc2IDM1LjYyNC0yLjMzNSAzLjgwMzYtOS45MDY0IDE3LjA1LTExLjEyNyAxOS40NjdsLTAuODEyMzYgMS42MDg1IDEuNDMxIDIuMTIwMmMxMC43OTggMTUuOTk5IDU4LjI0MyA5MC4xOTYgNTguMzM5IDkxLjIzNSAwLjAyMjMgMC4yNDE1Ny03Ljk5NTggOC44OTE2LTE3LjgxOCAxOS4yMjJzLTE4LjU3IDE5LjU2Ny0xOS40MzggMjAuNTI1bC0xLjU3OTggMS43NDE4LTEzLjc5MS0yNS4wNzFjLTMxLjM3LTU3LjAyOS0zNC4wMjYtNjEuNzc5LTM0LjM2LTYxLjQ0NS0wLjE1OTM2IDAuMTU5MzYtMC43ODkyNSAxLjI1NTUtMS4zOTk4IDIuNDM1OC0wLjk1NTE5IDEuODQ2OC0xMC4yNzQgMTguNzU4LTI2LjkzMSA0OC44NzUtMi4zOTQ2IDQuMzI5Ni03LjcwOTcgMTMuOTk3LTExLjgxMSAyMS40ODRzLTcuNTQ1OCAxMy42MTItNy42NTM3IDEzLjYxMmMtMC4xMDc5NCAyLjhlLTQgLTQuNzg4NS00Ljc4OTEtMTAuNDAxLTEwLjY0M3ptNjguNjY1LTE4MS40N2M5LjA5NTYtMTUuMjUxIDE0LjA4OS0yNS4zMDQgMTguMzExLTM2Ljg2OCAxLjA2MTEtMi45MDU5IDEuMDk1Ni0zLjE3NTcgMC41MTkxNy00LjA1NTQtMS4yMjg1LTEuODc1LTMuNTEwNi00LjEyNTEtNS45NDYzLTUuODYzMi01LjUwMjUtMy45MjY1LTEyLjA1Ny01LjYxMy0yMS44MDUtNS42MTA0LTEwLjk3NCAwLjAwMjktMTkuMTkgMi4xNTEzLTI2LjE0MSA2LjgzNTUtNS4yODk5IDMuNTY0Ny01LjcwMzggNC4xNjM2LTQuNTkyNSA2LjY0NDcgMC4zMDQ2OCAwLjY4MDI0IDEuNTYzMyAzLjc5NzkgMi43OTY4IDYuOTI4IDQuNzI4NyAxMS45OTkgMTMuNTAyIDI4LjI1NSAyNC4wMjggNDQuNTI1bDIuNTI0NCAzLjkwMTcgMi45Mjg3LTQuNDkwNGMxLjYxMDgtMi40Njk3IDQuOTMwMi03Ljg0NjMgNy4zNzY0LTExLjk0OHoiIHN0cm9rZS13aWR0aD0iLjM5MjUiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.19965" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTcyLjdtbSIgaGVpZ2h0PSIyMjEuMzhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgMTcyLjcgMjIxLjM4IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KIDxtZXRhZGF0YT4KICA8cmRmOlJERj4KICAgPGNjOldvcmsgcmRmOmFib3V0PSIiPgogICAgPGRjOmZvcm1hdD5pbWFnZS9zdmcreG1sPC9kYzpmb3JtYXQ+CiAgICA8ZGM6dHlwZSByZGY6cmVzb3VyY2U9Imh0dHA6Ly9wdXJsLm9yZy9kYy9kY21pdHlwZS9TdGlsbEltYWdlIi8+CiAgIDwvY2M6V29yaz4KICA8L3JkZjpSREY+CiA8L21ldGFkYXRhPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTE1Ljk0OSAtMzEuODY0KSI+CiAgPHBhdGggZD0ibTE2Ljc4NyAyNTIuMjdjLTAuNDYwOTMtMC40NjA5MS0wLjgzODA2LTIuNzMxMi0wLjgzODA2LTUuMDQ1IDAtMy44NzkyIDAuNzU5MDEtNC42ODcxIDkuNzQyNS0xMC4zNyAxOS43NDEtMTIuNDg3IDIzLjIwNC0xNS40MTQgMjIuMzgxLTE4LjkxOC0wLjQwOTYyLTEuNzQzOS0xLjA4OTQtNy43MjU1LTEuNTEwNi0xMy4yOTItMC44Nzg2NS0xMS42MTQgMS4yNzgxLTIxLjIxIDYuMzU5OS0yOC4yOTkgOC4xMi0xMS4zMjYgMTQuNTgxLTIzLjAzOCAxNy4yMDctMzEuMTkyIDEuNTg3NS00LjkyOTEgMy4zNDgzLTguNTAwMiAzLjkxMjctNy45MzU3IDEuMzIzMiAxLjMyMzIgNC43NTg0IDIwLjc5NyA0Ljc2MDYgMjYuOTg4IDkuNDdlLTQgMi42MTM2LTEuNDEyNSA4LjExMi0zLjE0MSAxMi4yMTktMy40MTI4IDguMTA4My00LjM2NzMgMjAuMTEzLTEuNTk5MiAyMC4xMTMgMC44NDg5NSAwIDUuODU2My00LjI4NzUgMTEuMTI4LTkuNTI3N2w5LjU4NC05LjUyNzctMy4xMjQ3LTcuNzM1OWMtMS43MTg2LTQuMjU0OC0zLjQwMTQtMTEuMTg0LTMuNzM5Ny0xNS4zOTctMC43NDM1My05LjI2MjggMS4xMjA0LTE0LjA0IDEyLjA5Ny0zMS4wMDcgNy4zOTAyLTExLjQyMyA3LjU4Ny0xMS45NTYgOS43NDM1LTI2LjQyOSAxLjIxMDYtOC4xMjQgMi42NDQzLTE0Ljc3MSAzLjE4NjItMTQuNzcxIDAuNTQxODIgMCAyLjk1NTQgNC43MzQxIDQuMzUwNiAxMC43OTRsMi4wMDEyIDguNjkxOGMxLjYyMjMgMi42OTU4LTEuNTg3OSAxNi43NjQtMS41ODc5IDE2Ljc2NC0xLjYyMzggOC4wNjQtMi45MjcgMTcuNzczLTIuODk2MiAyMS41NzYgMC4wNTgzIDcuMTk0MyAzLjEyMiAxNS4xMDYgNS44MzA3IDE1LjA1OCAzLjQ2NDctMC4wNjIyIDEyLjE2Ni01LjAyMyAxOC4xODItMTAuMzY3IDMuNTIzNS0zLjEyOTQgOS41OTAzLTYuODgxIDEzLjQ4Mi04LjMzNyA5LjQyMjUtMy41MjU0IDE2LjE5MS03LjA0NDcgMTguMTk3LTkuNDYxMiAwLjkwMjY2LTEuMDg3NiAyLjEzNzYtMS45Nzc1IDIuNzQ0NC0xLjk3NzUgMi4wNzU0IDAgMS4wOTI2IDMuMTQyNC0yLjc1MTkgOC43OTk3LTIuMTE0NCAzLjExMTMtNS45NzQgMTAuMTkxLTguNTc2OCAxNS43MzMtNS42NTA3IDEyLjAzMS0xNC42ODEgMjAuODI0LTI4LjQ4MSAyNy43MzItMTAuNTI5IDUuMjcwNi0xOS42NDMgNi41MDk1LTI5LjEwMyAzLjk1NjVsLTYuNTMzMy0xLjc2My05LjYyNTkgMTEuODE5Yy01LjI5NDIgNi41MDA2LTkuMzMwNyAxMi4xMTQtOC45Njk5IDEyLjQ3NSAwLjM2MDc5IDAuMzYwOCAyLjgyNCAwLjk0MyA1LjQ3MzkgMS4yOTM4IDQuMTIwNiAwLjU0NTUyIDUuNjc5LTAuMDIxNiAxMC43NjctMy45MTc5IDExLjYtOC44ODMgMTcuOTYtMTEuMjY2IDI5LjkzNS0xMS4yMTYgNS45MDg2IDAuMDI0NSAxMS43OTEgMC42MzEyNCAxMy4wNzIgMS4zNDgzIDIuMDQ0MiAxLjE0NCAxLjExMzIgMi4xNTc4LTcuNjAwMSA4LjI3NTItNS40NjE0IDMuODM0My0xNC4wMzMgMTEuNTAzLTE5LjA0OSAxNy4wNDItNy40OTk4IDguMjgyMi0xMC40MDIgMTAuNTU2LTE2LjM0MiAxMi44MDQtMTAuMTA0IDMuODI0Mi0yNS44MjggNC43MTY5LTM0LjI5NyAxLjk0N2wtNi40OTg0LTIuMTI1NS03LjA5ODggNi43NDMxYy0xMy42NTUgMTIuOTcxLTI3LjA3NCAyMC4xMzktMzAuNzc0IDE2LjQzOXptMTE0LjI5LTEyMC45M2MtMS4wNzY0LTEuNzQxNiA3LjQwNDYtMzAuMzg3IDExLjIzNC0zNy45NDMgNy44Mjg3LTE1LjQ0OSA0MS4yNTctNjEuNTQyIDQ0LjYzMy02MS41NDIgMi4zMDgxIDAgMi4yNzcyIDIuNDE0NS0wLjEzMDE0IDEwLjE2NS0xLjM3NzMgNC40MzQ0LTQuNDg5OCAxNS45MDktNi45MTY4IDI1LjQ5OS0yLjQyNjkgOS41OTAyLTUuNzQzOCAyMC4wNjQtNy4zNzA5IDIzLjI3NS02LjgyNDEgMTMuNDY3LTE3LjU3NSAyNC42MDgtMzkuMjQ1IDQwLjY2OS0wLjgzNTYzIDAuNjE5MzMtMS43Nzc2IDAuNTY2OTItMi4yMDM4LTAuMTIyNjJ6IiBzdHJva2Utd2lkdGg9IjEuMjU3MSIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.21258" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTk4LjUzbW0iIGhlaWdodD0iMTc2LjAybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE5OC41MyAxNzYuMDIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMi4zMjQ1IC01Mi4wMjUpIj4KICA8cGF0aCBkPSJtMi4zMjQ1IDIxNC44MnYtMTMuMjIyaDI2LjgyM2wyZS0zIC01MC43NjVjOS40ZS00IC0zMi4zNTYgMC4wNzAyLTUxLjU1MiAwLjE5MDk2LTUyLjkzNyAyLjEzOC0yNC41MTYgMjEuNDI0LTQzLjcxIDQ1LjkzOC00NS43MTcgMS43MDM0LTAuMTM5NTEgMTAuNy0wLjE4MzI0IDI4LjAxLTAuMTM2MTMgMjcuODUzIDAuMDc1OCAyNi4zNDcgMC4wMTg3OSAzMS41OTQgMS4xOTU4IDE4Ljg4MSA0LjIzNDYgMzMuNTM0IDE4LjgyNyAzNy45MTkgMzcuNzYzIDAuMTY4NDMgMC43MjcyMyAwLjQ4NjY2IDIuMzg0OCAwLjcwNzE2IDMuNjgzNCAwLjQwMDg3IDIuMzYwOSAwLjQwMDkyIDIuMzY2NyAwLjQ2Mzg5IDU0LjYzN2wwLjA2MyA1Mi4yNzZoMjYuODE1djI2LjQ0NWgtMTk4LjUzem0xMzQuODctNjQuMTE5YzAtNTUuODAyIDAuMDU5OC01Mi43NC0xLjEyMTUtNTcuNDE3LTEuNTE5OC02LjAxNzYtNC41NDcxLTExLjI2LTkuMTcxOS0xNS44ODItNS4zNzg0LTUuMzc1OS0xMS40NDMtOC41MjI0LTE4Ljk4NS05Ljg1MDgtMS44MTkyLTAuMzIwNDEtMy4yMzQ1LTAuMzQ5MzMtMTcuMDk1LTAuMzQ5MzMtMTYuMzI2IDAtMTYuMzY5IDAuMDAyMi0yMC40MzIgMS4wNDgtNi4wNzA0IDEuNTYyNi0xMS4yMjkgNC41NDMzLTE1LjgzNiA5LjE1MS01LjI4NzUgNS4yODc1LTguMjU3NSAxMC45NTMtOS44NTM2IDE4Ljc5Ni0wLjMwNDE2IDEuNDk0Ni0wLjMzMDg5IDUuMTkzOC0wLjM4NjYgNTMuNTA0bC0wLjA1OTggNTEuODk4aDkyLjk0MXoiIHN0cm9rZS13aWR0aD0iLjE4ODg5Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.96269" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yMW1tIiBoZWlnaHQ9IjE1Mi4xbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE4Mi4yMSAxNTIuMSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtOS4wMzA5IC02MS4xMDMpIj48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE1OS44NCAyMTEuNjQtMTQ5LjI0LTkwLjU0MSAxNzkuMDktMC4xMTEwNW0tMTQ5LjM2IDkwLjY1MiAxNDkuMzYtOTAuNjUybS04OS42LTU4LjMyMyA1OS43NTYgMTQ4Ljk4bS01OS43NTYtMTQ4Ljk4LTU5Ljc1NiAxNDguOTgiIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMy4xMjIxIi8+PGc+PGc+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtMzEzLjk4IDYxNS45OGMtNDIuMTcyLTI1LjYyMy02My43NDctMzkuNTQtNjMuNi00MS4wMjYgMC4xMjIyOC0xLjIzNyAxMC4wMjYtMjYuNjIxIDIyLjAwOC01Ni40MDlsMjEuNzg1LTU0LjE2IDE2OC41NyAwLjcwNTQ4IDQ0LjU3OCAxMTEuNDQtNC42MDc4IDIuODEyYy0zMC42NDUgMTguNzAyLTEyMC40NSA3My4wNjUtMTIyLjM4IDc0LjA4LTEuOTc4IDEuMDQxNi0xNi41NjgtNy4xOTA3LTY2LjM1OC0zNy40NDJ6IiBzdHJva2Utd2lkdGg9IjE2LjA4MSIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTUxOC4yMyA1NjkuMTVjLTAuMjQ5MDEtMC42MjgyNi05LjgwNzctMjQuNDY3LTIxLjI0Mi01Mi45NzUtMTEuNDM0LTI4LjUwOC0yMC43MTItNTEuOTEtMjAuNjE5LTUyLjAwMyAwLjA5MzctMC4wOTM3IDQ4Ljk4LTAuMTExNDMgMTA4LjY0LTAuMDM5NGwxMDguNDcgMC4xMzA5LTc3LjM3NyA0Ni45NDVjLTQyLjU1NyAyNS44Mi04MS44ODUgNDkuNjc2LTg3LjM5NiA1My4wMTUtOS41OTk0IDUuODE1OS0xMC4wMzggNi4wMjIzLTEwLjQ3MiA0LjkyNzl6IiBzdHJva2Utd2lkdGg9IjUuNjg1NiIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTI5OS40NyA0NDkuODZjMC4zODE4LTAuOTI3MjIgMTUuMzczLTM4LjI3OSAzMy4zMTMtODMuMDA1bDMyLjYxOS04MS4zMTkgMjUuODQ2IDAuMjc2NzMgMzIuODc4IDgxLjk0NWMxOC4wODMgNDUuMDcgMzMuMDEgODIuMzYgMzMuMTcxIDgyLjg2NiAwLjI3OTA3IDAuODc5MjgtMy4yOTQ3IDAuOTIwODctNzkuMTE0IDAuOTIwODdoLTc5LjQwN3oiIHN0cm9rZS13aWR0aD0iNS42ODU2Ii8+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtNDkwLjcxIDcyMy41MWMtNTQuNDkyLTMzLjA1OS05OS4wMS02MC40MTQtOTguOTMtNjAuNzg5IDAuMjU3NjctMS4xOTc4IDEyMC4xNy03My43MDkgMTIwLjgtNzMuMDQ4IDAuODg3MzEgMC45Mjg3MyA3Ny44ODQgMTkzLjI2IDc3LjUxNSAxOTMuNjMtMC4xNzE2MSAwLjE3MTM5LTQ0Ljg5Ni0yNi43MzYtOTkuMzg4LTU5Ljc5NXoiIHN0cm9rZS13aWR0aD0iMTEuMzcxIi8+PC9nPjxwYXRoIGQ9Im05OS45MzIgNzUuNDM1Yy0yLjc1NTMtMC4wMzkxOS0zLjU2NTYtMC4xMDA5My0zLjUwNDEtMC4yNjcwMiAxLjgzNDQtNC45NTcgMy40NTExLTkuMjAyOCAzLjU0MzEtOS4zMDUzIDAuMDY1OTMtMC4wNzMyOCAwLjg0Nzk5IDEuODIzMyAxLjczODIgNC4yMTQ2IDAuODkwMiAyLjM5MTMgMS43MTczIDQuNjA0NyAxLjgzNzkgNC45MTg2IDAuMTIwNzEgMC4zMTM5IDAuMTYzMDMgMC41NTI1OSAwLjA5NDEgMC41MzA0NC0wLjA2ODgtMC4wMjIxNy0xLjczODEtMC4wNjMyMy0zLjcwOTMtMC4wOTEyOHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIxLjg2MDMiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNDkuODkgNTE2Ljk4LTg2LjY5NC01Mi42MTQgMTA4LjI3LTAuMTg1ODNjNTkuNTQ5LTAuMTAyMiAxMDguMzgtMC4wNzU1IDEwOC41MiAwLjA1OTIgMC41MDI3MyAwLjUwMjczLTQxLjk2MiAxMDUuMzctNDIuNjY2IDEwNS4zNi0wLjQwMzQ3LTNlLTMgLTM5Ljc0Ni0yMy42ODItODcuNDI4LTUyLjYyeiIgc3Ryb2tlLXdpZHRoPSI4LjA0MDYiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNjcuNDYgNzgxLjE4YzAuMjg5OS0xLjE1OTMgMTcuNjUyLTQ0Ljg0NCAzOC41ODEtOTcuMDc3bDM4LjA1NC05NC45NyA0LjQ5MzcgMi44NTI5YzIuNDcxNSAxLjU2OTEgMjkuMzk3IDE3Ljg5NiA1OS44MzQgMzYuMjgzczU1LjM2MSAzMy44NjIgNTUuMzg2IDM0LjM5MWMwLjAyNTIgMC41MjgzOC00Mi43MDQgMjYuODgtOTQuOTU0IDU4LjU2LTUyLjI1IDMxLjY4LTk2LjU1NyA1OC42MDUtOTguNDYxIDU5LjgzNC0yLjkyMSAxLjg4NTktMy4zNzkyIDEuOTA1OC0yLjkzNDQgMC4xMjcwNnoiIHN0cm9rZS13aWR0aD0iMTYuMDgxIi8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTc0LjAzbW0iIGhlaWdodD0iMjgyLjgzbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NC4wMyAyODIuODMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjAuODk4IC02LjgzOSkiPgogIDxwYXRoIGQ9Im00OS43NDYgMjc4LjkyYy01LjYxMjctNS44NTQtMTQuNC0xNC45ODMtMTkuNTI3LTIwLjI4Ni01LjEyNy01LjMwMzUtOS4zMjE4LTkuNzY0NS05LjMyMTgtOS45MTMzIDAtMC4xNDg4MyAxLjMwNDUtMi4yNzc2IDIuODk4OC00LjczMDUgMS41OTQzLTIuNDUzIDUuNjg0NS04Ljg3NTUgOS4wODk0LTE0LjI3MiA4LjkxNjQtMTQuMTMzIDI1Ljg0LTQwLjU0OSAzMi42MjUtNTAuOTI0IDEuNzk5Mi0yLjc1MTEgMy4yNzEyLTUuMTY1IDMuMjcxMi01LjM2NDFzMC4xNDEwNy0wLjQyMDk2IDAuMzEzNDktMC40OTI5MmMwLjE3MjQyLTAuMDcyIDIuOTg5NS00LjIyODkgNi4yNjAxLTkuMjM3N2w1Ljk0NjYtOS4xMDY5LTMuNjUxOC02LjM5NjhjLTIuMDA4NS0zLjUxODItNS43ODE4LTEwLjAzMS04LjM4NTEtMTQuNDcyLTExLjMxNy0xOS4zMDctMTQuMTk2LTI3LjE4Mi0xMy42OTYtMzcuNDU0IDAuODc5MTMtMTguMDU4IDExLjg4Mi01Ny44MyAyMC4xMjQtNzIuNzQ1IDEuOTk3Ny0zLjYxNDggOC4wMzQ1LTkuNTc3NiAxMi4xMTUtMTEuOTY2IDYuMTc0OC0zLjYxNDYgMTEuMjg5LTQuNzQxOCAyMS40MDEtNC43MTY5IDYuMTU4IDAuMDE1MTU4IDcuNzU4MyAwLjE0Nzc5IDEwLjUzMyAwLjg3Mjk3IDQuMTU3NyAxLjA4NjUgNy43MyAyLjcwNjUgMTAuNzk4IDQuODk2NSAyLjk2MjMgMi4xMTQ5IDcuODM4NCA3LjE2NDQgOS45Mzg3IDEwLjI5MiA4LjgzNSAxMy4xNTcgMTguNTI5IDM3Ljk4MSAyMi45MDIgNTguNjQ4IDEuMDgxOCA1LjExMjMgMS40NjY1IDEzLjE0MSAwLjc5NDM2IDE2LjU3OS0xLjU5NTIgOC4xNTg2LTYuNTEwNyAxOC40MTMtMTcuMDc2IDM1LjYyNC0yLjMzNSAzLjgwMzYtOS45MDY0IDE3LjA1LTExLjEyNyAxOS40NjdsLTAuODEyMzYgMS42MDg1IDEuNDMxIDIuMTIwMmMxMC43OTggMTUuOTk5IDU4LjI0MyA5MC4xOTYgNTguMzM5IDkxLjIzNSAwLjAyMjMgMC4yNDE1Ny03Ljk5NTggOC44OTE2LTE3LjgxOCAxOS4yMjJzLTE4LjU3IDE5LjU2Ny0xOS40MzggMjAuNTI1bC0xLjU3OTggMS43NDE4LTEzLjc5MS0yNS4wNzFjLTMxLjM3LTU3LjAyOS0zNC4wMjYtNjEuNzc5LTM0LjM2LTYxLjQ0NS0wLjE1OTM2IDAuMTU5MzYtMC43ODkyNSAxLjI1NTUtMS4zOTk4IDIuNDM1OC0wLjk1NTE5IDEuODQ2OC0xMC4yNzQgMTguNzU4LTI2LjkzMSA0OC44NzUtMi4zOTQ2IDQuMzI5Ni03LjcwOTcgMTMuOTk3LTExLjgxMSAyMS40ODRzLTcuNTQ1OCAxMy42MTItNy42NTM3IDEzLjYxMmMtMC4xMDc5NCAyLjhlLTQgLTQuNzg4NS00Ljc4OTEtMTAuNDAxLTEwLjY0M3ptNjguNjY1LTE4MS40N2M5LjA5NTYtMTUuMjUxIDE0LjA4OS0yNS4zMDQgMTguMzExLTM2Ljg2OCAxLjA2MTEtMi45MDU5IDEuMDk1Ni0zLjE3NTcgMC41MTkxNy00LjA1NTQtMS4yMjg1LTEuODc1LTMuNTEwNi00LjEyNTEtNS45NDYzLTUuODYzMi01LjUwMjUtMy45MjY1LTEyLjA1Ny01LjYxMy0yMS44MDUtNS42MTA0LTEwLjk3NCAwLjAwMjktMTkuMTkgMi4xNTEzLTI2LjE0MSA2LjgzNTUtNS4yODk5IDMuNTY0Ny01LjcwMzggNC4xNjM2LTQuNTkyNSA2LjY0NDcgMC4zMDQ2OCAwLjY4MDI0IDEuNTYzMyAzLjc5NzkgMi43OTY4IDYuOTI4IDQuNzI4NyAxMS45OTkgMTMuNTAyIDI4LjI1NSAyNC4wMjggNDQuNTI1bDIuNTI0NCAzLjkwMTcgMi45Mjg3LTQuNDkwNGMxLjYxMDgtMi40Njk3IDQuOTMwMi03Ljg0NjMgNy4zNzY0LTExLjk0OHoiIHN0cm9rZS13aWR0aD0iLjM5MjUiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.19965" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTcyLjdtbSIgaGVpZ2h0PSIyMjEuMzhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgMTcyLjcgMjIxLjM4IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KIDxtZXRhZGF0YT4KICA8cmRmOlJERj4KICAgPGNjOldvcmsgcmRmOmFib3V0PSIiPgogICAgPGRjOmZvcm1hdD5pbWFnZS9zdmcreG1sPC9kYzpmb3JtYXQ+CiAgICA8ZGM6dHlwZSByZGY6cmVzb3VyY2U9Imh0dHA6Ly9wdXJsLm9yZy9kYy9kY21pdHlwZS9TdGlsbEltYWdlIi8+CiAgIDwvY2M6V29yaz4KICA8L3JkZjpSREY+CiA8L21ldGFkYXRhPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTE1Ljk0OSAtMzEuODY0KSI+CiAgPHBhdGggZD0ibTE2Ljc4NyAyNTIuMjdjLTAuNDYwOTMtMC40NjA5MS0wLjgzODA2LTIuNzMxMi0wLjgzODA2LTUuMDQ1IDAtMy44NzkyIDAuNzU5MDEtNC42ODcxIDkuNzQyNS0xMC4zNyAxOS43NDEtMTIuNDg3IDIzLjIwNC0xNS40MTQgMjIuMzgxLTE4LjkxOC0wLjQwOTYyLTEuNzQzOS0xLjA4OTQtNy43MjU1LTEuNTEwNi0xMy4yOTItMC44Nzg2NS0xMS42MTQgMS4yNzgxLTIxLjIxIDYuMzU5OS0yOC4yOTkgOC4xMi0xMS4zMjYgMTQuNTgxLTIzLjAzOCAxNy4yMDctMzEuMTkyIDEuNTg3NS00LjkyOTEgMy4zNDgzLTguNTAwMiAzLjkxMjctNy45MzU3IDEuMzIzMiAxLjMyMzIgNC43NTg0IDIwLjc5NyA0Ljc2MDYgMjYuOTg4IDkuNDdlLTQgMi42MTM2LTEuNDEyNSA4LjExMi0zLjE0MSAxMi4yMTktMy40MTI4IDguMTA4My00LjM2NzMgMjAuMTEzLTEuNTk5MiAyMC4xMTMgMC44NDg5NSAwIDUuODU2My00LjI4NzUgMTEuMTI4LTkuNTI3N2w5LjU4NC05LjUyNzctMy4xMjQ3LTcuNzM1OWMtMS43MTg2LTQuMjU0OC0zLjQwMTQtMTEuMTg0LTMuNzM5Ny0xNS4zOTctMC43NDM1My05LjI2MjggMS4xMjA0LTE0LjA0IDEyLjA5Ny0zMS4wMDcgNy4zOTAyLTExLjQyMyA3LjU4Ny0xMS45NTYgOS43NDM1LTI2LjQyOSAxLjIxMDYtOC4xMjQgMi42NDQzLTE0Ljc3MSAzLjE4NjItMTQuNzcxIDAuNTQxODIgMCAyLjk1NTQgNC43MzQxIDQuMzUwNiAxMC43OTRsMi4wMDEyIDguNjkxOGMxLjYyMjMgMi42OTU4LTEuNTg3OSAxNi43NjQtMS41ODc5IDE2Ljc2NC0xLjYyMzggOC4wNjQtMi45MjcgMTcuNzczLTIuODk2MiAyMS41NzYgMC4wNTgzIDcuMTk0MyAzLjEyMiAxNS4xMDYgNS44MzA3IDE1LjA1OCAzLjQ2NDctMC4wNjIyIDEyLjE2Ni01LjAyMyAxOC4xODItMTAuMzY3IDMuNTIzNS0zLjEyOTQgOS41OTAzLTYuODgxIDEzLjQ4Mi04LjMzNyA5LjQyMjUtMy41MjU0IDE2LjE5MS03LjA0NDcgMTguMTk3LTkuNDYxMiAwLjkwMjY2LTEuMDg3NiAyLjEzNzYtMS45Nzc1IDIuNzQ0NC0xLjk3NzUgMi4wNzU0IDAgMS4wOTI2IDMuMTQyNC0yLjc1MTkgOC43OTk3LTIuMTE0NCAzLjExMTMtNS45NzQgMTAuMTkxLTguNTc2OCAxNS43MzMtNS42NTA3IDEyLjAzMS0xNC42ODEgMjAuODI0LTI4LjQ4MSAyNy43MzItMTAuNTI5IDUuMjcwNi0xOS42NDMgNi41MDk1LTI5LjEwMyAzLjk1NjVsLTYuNTMzMy0xLjc2My05LjYyNTkgMTEuODE5Yy01LjI5NDIgNi41MDA2LTkuMzMwNyAxMi4xMTQtOC45Njk5IDEyLjQ3NSAwLjM2MDc5IDAuMzYwOCAyLjgyNCAwLjk0MyA1LjQ3MzkgMS4yOTM4IDQuMTIwNiAwLjU0NTUyIDUuNjc5LTAuMDIxNiAxMC43NjctMy45MTc5IDExLjYtOC44ODMgMTcuOTYtMTEuMjY2IDI5LjkzNS0xMS4yMTYgNS45MDg2IDAuMDI0NSAxMS43OTEgMC42MzEyNCAxMy4wNzIgMS4zNDgzIDIuMDQ0MiAxLjE0NCAxLjExMzIgMi4xNTc4LTcuNjAwMSA4LjI3NTItNS40NjE0IDMuODM0My0xNC4wMzMgMTEuNTAzLTE5LjA0OSAxNy4wNDItNy40OTk4IDguMjgyMi0xMC40MDIgMTAuNTU2LTE2LjM0MiAxMi44MDQtMTAuMTA0IDMuODI0Mi0yNS44MjggNC43MTY5LTM0LjI5NyAxLjk0N2wtNi40OTg0LTIuMTI1NS03LjA5ODggNi43NDMxYy0xMy42NTUgMTIuOTcxLTI3LjA3NCAyMC4xMzktMzAuNzc0IDE2LjQzOXptMTE0LjI5LTEyMC45M2MtMS4wNzY0LTEuNzQxNiA3LjQwNDYtMzAuMzg3IDExLjIzNC0zNy45NDMgNy44Mjg3LTE1LjQ0OSA0MS4yNTctNjEuNTQyIDQ0LjYzMy02MS41NDIgMi4zMDgxIDAgMi4yNzcyIDIuNDE0NS0wLjEzMDE0IDEwLjE2NS0xLjM3NzMgNC40MzQ0LTQuNDg5OCAxNS45MDktNi45MTY4IDI1LjQ5OS0yLjQyNjkgOS41OTAyLTUuNzQzOCAyMC4wNjQtNy4zNzA5IDIzLjI3NS02LjgyNDEgMTMuNDY3LTE3LjU3NSAyNC42MDgtMzkuMjQ1IDQwLjY2OS0wLjgzNTYzIDAuNjE5MzMtMS43Nzc2IDAuNTY2OTItMi4yMDM4LTAuMTIyNjJ6IiBzdHJva2Utd2lkdGg9IjEuMjU3MSIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.21258" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yMW1tIiBoZWlnaHQ9IjE1Mi4xbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE4Mi4yMSAxNTIuMSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtOS4wMzA5IC02MS4xMDMpIj48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE1OS44NCAyMTEuNjQtMTQ5LjI0LTkwLjU0MSAxNzkuMDktMC4xMTEwNW0tMTQ5LjM2IDkwLjY1MiAxNDkuMzYtOTAuNjUybS04OS42LTU4LjMyMyA1OS43NTYgMTQ4Ljk4bS01OS43NTYtMTQ4Ljk4LTU5Ljc1NiAxNDguOTgiIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMy4xMjIxIi8+PGc+PGc+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtMzEzLjk4IDYxNS45OGMtNDIuMTcyLTI1LjYyMy02My43NDctMzkuNTQtNjMuNi00MS4wMjYgMC4xMjIyOC0xLjIzNyAxMC4wMjYtMjYuNjIxIDIyLjAwOC01Ni40MDlsMjEuNzg1LTU0LjE2IDE2OC41NyAwLjcwNTQ4IDQ0LjU3OCAxMTEuNDQtNC42MDc4IDIuODEyYy0zMC42NDUgMTguNzAyLTEyMC40NSA3My4wNjUtMTIyLjM4IDc0LjA4LTEuOTc4IDEuMDQxNi0xNi41NjgtNy4xOTA3LTY2LjM1OC0zNy40NDJ6IiBzdHJva2Utd2lkdGg9IjE2LjA4MSIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTUxOC4yMyA1NjkuMTVjLTAuMjQ5MDEtMC42MjgyNi05LjgwNzctMjQuNDY3LTIxLjI0Mi01Mi45NzUtMTEuNDM0LTI4LjUwOC0yMC43MTItNTEuOTEtMjAuNjE5LTUyLjAwMyAwLjA5MzctMC4wOTM3IDQ4Ljk4LTAuMTExNDMgMTA4LjY0LTAuMDM5NGwxMDguNDcgMC4xMzA5LTc3LjM3NyA0Ni45NDVjLTQyLjU1NyAyNS44Mi04MS44ODUgNDkuNjc2LTg3LjM5NiA1My4wMTUtOS41OTk0IDUuODE1OS0xMC4wMzggNi4wMjIzLTEwLjQ3MiA0LjkyNzl6IiBzdHJva2Utd2lkdGg9IjUuNjg1NiIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTI5OS40NyA0NDkuODZjMC4zODE4LTAuOTI3MjIgMTUuMzczLTM4LjI3OSAzMy4zMTMtODMuMDA1bDMyLjYxOS04MS4zMTkgMjUuODQ2IDAuMjc2NzMgMzIuODc4IDgxLjk0NWMxOC4wODMgNDUuMDcgMzMuMDEgODIuMzYgMzMuMTcxIDgyLjg2NiAwLjI3OTA3IDAuODc5MjgtMy4yOTQ3IDAuOTIwODctNzkuMTE0IDAuOTIwODdoLTc5LjQwN3oiIHN0cm9rZS13aWR0aD0iNS42ODU2Ii8+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtNDkwLjcxIDcyMy41MWMtNTQuNDkyLTMzLjA1OS05OS4wMS02MC40MTQtOTguOTMtNjAuNzg5IDAuMjU3NjctMS4xOTc4IDEyMC4xNy03My43MDkgMTIwLjgtNzMuMDQ4IDAuODg3MzEgMC45Mjg3MyA3Ny44ODQgMTkzLjI2IDc3LjUxNSAxOTMuNjMtMC4xNzE2MSAwLjE3MTM5LTQ0Ljg5Ni0yNi43MzYtOTkuMzg4LTU5Ljc5NXoiIHN0cm9rZS13aWR0aD0iMTEuMzcxIi8+PC9nPjxwYXRoIGQ9Im05OS45MzIgNzUuNDM1Yy0yLjc1NTMtMC4wMzkxOS0zLjU2NTYtMC4xMDA5My0zLjUwNDEtMC4yNjcwMiAxLjgzNDQtNC45NTcgMy40NTExLTkuMjAyOCAzLjU0MzEtOS4zMDUzIDAuMDY1OTMtMC4wNzMyOCAwLjg0Nzk5IDEuODIzMyAxLjczODIgNC4yMTQ2IDAuODkwMiAyLjM5MTMgMS43MTczIDQuNjA0NyAxLjgzNzkgNC45MTg2IDAuMTIwNzEgMC4zMTM5IDAuMTYzMDMgMC41NTI1OSAwLjA5NDEgMC41MzA0NC0wLjA2ODgtMC4wMjIxNy0xLjczODEtMC4wNjMyMy0zLjcwOTMtMC4wOTEyOHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIxLjg2MDMiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNDkuODkgNTE2Ljk4LTg2LjY5NC01Mi42MTQgMTA4LjI3LTAuMTg1ODNjNTkuNTQ5LTAuMTAyMiAxMDguMzgtMC4wNzU1IDEwOC41MiAwLjA1OTIgMC41MDI3MyAwLjUwMjczLTQxLjk2MiAxMDUuMzctNDIuNjY2IDEwNS4zNi0wLjQwMzQ3LTNlLTMgLTM5Ljc0Ni0yMy42ODItODcuNDI4LTUyLjYyeiIgc3Ryb2tlLXdpZHRoPSI4LjA0MDYiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNjcuNDYgNzgxLjE4YzAuMjg5OS0xLjE1OTMgMTcuNjUyLTQ0Ljg0NCAzOC41ODEtOTcuMDc3bDM4LjA1NC05NC45NyA0LjQ5MzcgMi44NTI5YzIuNDcxNSAxLjU2OTEgMjkuMzk3IDE3Ljg5NiA1OS44MzQgMzYuMjgzczU1LjM2MSAzMy44NjIgNTUuMzg2IDM0LjM5MWMwLjAyNTIgMC41MjgzOC00Mi43MDQgMjYuODgtOTQuOTU0IDU4LjU2LTUyLjI1IDMxLjY4LTk2LjU1NyA1OC42MDUtOTguNDYxIDU5LjgzNC0yLjkyMSAxLjg4NTktMy4zNzkyIDEuOTA1OC0yLjkzNDQgMC4xMjcwNnoiIHN0cm9rZS13aWR0aD0iMTYuMDgxIi8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTk4LjUzbW0iIGhlaWdodD0iMTc2LjAybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE5OC41MyAxNzYuMDIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMi4zMjQ1IC01Mi4wMjUpIj4KICA8cGF0aCBkPSJtMi4zMjQ1IDIxNC44MnYtMTMuMjIyaDI2LjgyM2wyZS0zIC01MC43NjVjOS40ZS00IC0zMi4zNTYgMC4wNzAyLTUxLjU1MiAwLjE5MDk2LTUyLjkzNyAyLjEzOC0yNC41MTYgMjEuNDI0LTQzLjcxIDQ1LjkzOC00NS43MTcgMS43MDM0LTAuMTM5NTEgMTAuNy0wLjE4MzI0IDI4LjAxLTAuMTM2MTMgMjcuODUzIDAuMDc1OCAyNi4zNDcgMC4wMTg3OSAzMS41OTQgMS4xOTU4IDE4Ljg4MSA0LjIzNDYgMzMuNTM0IDE4LjgyNyAzNy45MTkgMzcuNzYzIDAuMTY4NDMgMC43MjcyMyAwLjQ4NjY2IDIuMzg0OCAwLjcwNzE2IDMuNjgzNCAwLjQwMDg3IDIuMzYwOSAwLjQwMDkyIDIuMzY2NyAwLjQ2Mzg5IDU0LjYzN2wwLjA2MyA1Mi4yNzZoMjYuODE1djI2LjQ0NWgtMTk4LjUzem0xMzQuODctNjQuMTE5YzAtNTUuODAyIDAuMDU5OC01Mi43NC0xLjEyMTUtNTcuNDE3LTEuNTE5OC02LjAxNzYtNC41NDcxLTExLjI2LTkuMTcxOS0xNS44ODItNS4zNzg0LTUuMzc1OS0xMS40NDMtOC41MjI0LTE4Ljk4NS05Ljg1MDgtMS44MTkyLTAuMzIwNDEtMy4yMzQ1LTAuMzQ5MzMtMTcuMDk1LTAuMzQ5MzMtMTYuMzI2IDAtMTYuMzY5IDAuMDAyMi0yMC40MzIgMS4wNDgtNi4wNzA0IDEuNTYyNi0xMS4yMjkgNC41NDMzLTE1LjgzNiA5LjE1MS01LjI4NzUgNS4yODc1LTguMjU3NSAxMC45NTMtOS44NTM2IDE4Ljc5Ni0wLjMwNDE2IDEuNDk0Ni0wLjMzMDg5IDUuMTkzOC0wLjM4NjYgNTMuNTA0bC0wLjA1OTggNTEuODk4aDkyLjk0MXoiIHN0cm9rZS13aWR0aD0iLjE4ODg5Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.96269" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yMW1tIiBoZWlnaHQ9IjE1Mi4xbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE4Mi4yMSAxNTIuMSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtOS4wMzA5IC02MS4xMDMpIj48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE1OS44NCAyMTEuNjQtMTQ5LjI0LTkwLjU0MSAxNzkuMDktMC4xMTEwNW0tMTQ5LjM2IDkwLjY1MiAxNDkuMzYtOTAuNjUybS04OS42LTU4LjMyMyA1OS43NTYgMTQ4Ljk4bS01OS43NTYtMTQ4Ljk4LTU5Ljc1NiAxNDguOTgiIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMy4xMjIxIi8+PGc+PGc+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtMzEzLjk4IDYxNS45OGMtNDIuMTcyLTI1LjYyMy02My43NDctMzkuNTQtNjMuNi00MS4wMjYgMC4xMjIyOC0xLjIzNyAxMC4wMjYtMjYuNjIxIDIyLjAwOC01Ni40MDlsMjEuNzg1LTU0LjE2IDE2OC41NyAwLjcwNTQ4IDQ0LjU3OCAxMTEuNDQtNC42MDc4IDIuODEyYy0zMC42NDUgMTguNzAyLTEyMC40NSA3My4wNjUtMTIyLjM4IDc0LjA4LTEuOTc4IDEuMDQxNi0xNi41NjgtNy4xOTA3LTY2LjM1OC0zNy40NDJ6IiBzdHJva2Utd2lkdGg9IjE2LjA4MSIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTUxOC4yMyA1NjkuMTVjLTAuMjQ5MDEtMC42MjgyNi05LjgwNzctMjQuNDY3LTIxLjI0Mi01Mi45NzUtMTEuNDM0LTI4LjUwOC0yMC43MTItNTEuOTEtMjAuNjE5LTUyLjAwMyAwLjA5MzctMC4wOTM3IDQ4Ljk4LTAuMTExNDMgMTA4LjY0LTAuMDM5NGwxMDguNDcgMC4xMzA5LTc3LjM3NyA0Ni45NDVjLTQyLjU1NyAyNS44Mi04MS44ODUgNDkuNjc2LTg3LjM5NiA1My4wMTUtOS41OTk0IDUuODE1OS0xMC4wMzggNi4wMjIzLTEwLjQ3MiA0LjkyNzl6IiBzdHJva2Utd2lkdGg9IjUuNjg1NiIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTI5OS40NyA0NDkuODZjMC4zODE4LTAuOTI3MjIgMTUuMzczLTM4LjI3OSAzMy4zMTMtODMuMDA1bDMyLjYxOS04MS4zMTkgMjUuODQ2IDAuMjc2NzMgMzIuODc4IDgxLjk0NWMxOC4wODMgNDUuMDcgMzMuMDEgODIuMzYgMzMuMTcxIDgyLjg2NiAwLjI3OTA3IDAuODc5MjgtMy4yOTQ3IDAuOTIwODctNzkuMTE0IDAuOTIwODdoLTc5LjQwN3oiIHN0cm9rZS13aWR0aD0iNS42ODU2Ii8+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtNDkwLjcxIDcyMy41MWMtNTQuNDkyLTMzLjA1OS05OS4wMS02MC40MTQtOTguOTMtNjAuNzg5IDAuMjU3NjctMS4xOTc4IDEyMC4xNy03My43MDkgMTIwLjgtNzMuMDQ4IDAuODg3MzEgMC45Mjg3MyA3Ny44ODQgMTkzLjI2IDc3LjUxNSAxOTMuNjMtMC4xNzE2MSAwLjE3MTM5LTQ0Ljg5Ni0yNi43MzYtOTkuMzg4LTU5Ljc5NXoiIHN0cm9rZS13aWR0aD0iMTEuMzcxIi8+PC9nPjxwYXRoIGQ9Im05OS45MzIgNzUuNDM1Yy0yLjc1NTMtMC4wMzkxOS0zLjU2NTYtMC4xMDA5My0zLjUwNDEtMC4yNjcwMiAxLjgzNDQtNC45NTcgMy40NTExLTkuMjAyOCAzLjU0MzEtOS4zMDUzIDAuMDY1OTMtMC4wNzMyOCAwLjg0Nzk5IDEuODIzMyAxLjczODIgNC4yMTQ2IDAuODkwMiAyLjM5MTMgMS43MTczIDQuNjA0NyAxLjgzNzkgNC45MTg2IDAuMTIwNzEgMC4zMTM5IDAuMTYzMDMgMC41NTI1OSAwLjA5NDEgMC41MzA0NC0wLjA2ODgtMC4wMjIxNy0xLjczODEtMC4wNjMyMy0zLjcwOTMtMC4wOTEyOHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIxLjg2MDMiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNDkuODkgNTE2Ljk4LTg2LjY5NC01Mi42MTQgMTA4LjI3LTAuMTg1ODNjNTkuNTQ5LTAuMTAyMiAxMDguMzgtMC4wNzU1IDEwOC41MiAwLjA1OTIgMC41MDI3MyAwLjUwMjczLTQxLjk2MiAxMDUuMzctNDIuNjY2IDEwNS4zNi0wLjQwMzQ3LTNlLTMgLTM5Ljc0Ni0yMy42ODItODcuNDI4LTUyLjYyeiIgc3Ryb2tlLXdpZHRoPSI4LjA0MDYiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNjcuNDYgNzgxLjE4YzAuMjg5OS0xLjE1OTMgMTcuNjUyLTQ0Ljg0NCAzOC41ODEtOTcuMDc3bDM4LjA1NC05NC45NyA0LjQ5MzcgMi44NTI5YzIuNDcxNSAxLjU2OTEgMjkuMzk3IDE3Ljg5NiA1OS44MzQgMzYuMjgzczU1LjM2MSAzMy44NjIgNTUuMzg2IDM0LjM5MWMwLjAyNTIgMC41MjgzOC00Mi43MDQgMjYuODgtOTQuOTU0IDU4LjU2LTUyLjI1IDMxLjY4LTk2LjU1NyA1OC42MDUtOTguNDYxIDU5LjgzNC0yLjkyMSAxLjg4NTktMy4zNzkyIDEuOTA1OC0yLjkzNDQgMC4xMjcwNnoiIHN0cm9rZS13aWR0aD0iMTYuMDgxIi8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTc0LjAzbW0iIGhlaWdodD0iMjgyLjgzbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NC4wMyAyODIuODMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjAuODk4IC02LjgzOSkiPgogIDxwYXRoIGQ9Im00OS43NDYgMjc4LjkyYy01LjYxMjctNS44NTQtMTQuNC0xNC45ODMtMTkuNTI3LTIwLjI4Ni01LjEyNy01LjMwMzUtOS4zMjE4LTkuNzY0NS05LjMyMTgtOS45MTMzIDAtMC4xNDg4MyAxLjMwNDUtMi4yNzc2IDIuODk4OC00LjczMDUgMS41OTQzLTIuNDUzIDUuNjg0NS04Ljg3NTUgOS4wODk0LTE0LjI3MiA4LjkxNjQtMTQuMTMzIDI1Ljg0LTQwLjU0OSAzMi42MjUtNTAuOTI0IDEuNzk5Mi0yLjc1MTEgMy4yNzEyLTUuMTY1IDMuMjcxMi01LjM2NDFzMC4xNDEwNy0wLjQyMDk2IDAuMzEzNDktMC40OTI5MmMwLjE3MjQyLTAuMDcyIDIuOTg5NS00LjIyODkgNi4yNjAxLTkuMjM3N2w1Ljk0NjYtOS4xMDY5LTMuNjUxOC02LjM5NjhjLTIuMDA4NS0zLjUxODItNS43ODE4LTEwLjAzMS04LjM4NTEtMTQuNDcyLTExLjMxNy0xOS4zMDctMTQuMTk2LTI3LjE4Mi0xMy42OTYtMzcuNDU0IDAuODc5MTMtMTguMDU4IDExLjg4Mi01Ny44MyAyMC4xMjQtNzIuNzQ1IDEuOTk3Ny0zLjYxNDggOC4wMzQ1LTkuNTc3NiAxMi4xMTUtMTEuOTY2IDYuMTc0OC0zLjYxNDYgMTEuMjg5LTQuNzQxOCAyMS40MDEtNC43MTY5IDYuMTU4IDAuMDE1MTU4IDcuNzU4MyAwLjE0Nzc5IDEwLjUzMyAwLjg3Mjk3IDQuMTU3NyAxLjA4NjUgNy43MyAyLjcwNjUgMTAuNzk4IDQuODk2NSAyLjk2MjMgMi4xMTQ5IDcuODM4NCA3LjE2NDQgOS45Mzg3IDEwLjI5MiA4LjgzNSAxMy4xNTcgMTguNTI5IDM3Ljk4MSAyMi45MDIgNTguNjQ4IDEuMDgxOCA1LjExMjMgMS40NjY1IDEzLjE0MSAwLjc5NDM2IDE2LjU3OS0xLjU5NTIgOC4xNTg2LTYuNTEwNyAxOC40MTMtMTcuMDc2IDM1LjYyNC0yLjMzNSAzLjgwMzYtOS45MDY0IDE3LjA1LTExLjEyNyAxOS40NjdsLTAuODEyMzYgMS42MDg1IDEuNDMxIDIuMTIwMmMxMC43OTggMTUuOTk5IDU4LjI0MyA5MC4xOTYgNTguMzM5IDkxLjIzNSAwLjAyMjMgMC4yNDE1Ny03Ljk5NTggOC44OTE2LTE3LjgxOCAxOS4yMjJzLTE4LjU3IDE5LjU2Ny0xOS40MzggMjAuNTI1bC0xLjU3OTggMS43NDE4LTEzLjc5MS0yNS4wNzFjLTMxLjM3LTU3LjAyOS0zNC4wMjYtNjEuNzc5LTM0LjM2LTYxLjQ0NS0wLjE1OTM2IDAuMTU5MzYtMC43ODkyNSAxLjI1NTUtMS4zOTk4IDIuNDM1OC0wLjk1NTE5IDEuODQ2OC0xMC4yNzQgMTguNzU4LTI2LjkzMSA0OC44NzUtMi4zOTQ2IDQuMzI5Ni03LjcwOTcgMTMuOTk3LTExLjgxMSAyMS40ODRzLTcuNTQ1OCAxMy42MTItNy42NTM3IDEzLjYxMmMtMC4xMDc5NCAyLjhlLTQgLTQuNzg4NS00Ljc4OTEtMTAuNDAxLTEwLjY0M3ptNjguNjY1LTE4MS40N2M5LjA5NTYtMTUuMjUxIDE0LjA4OS0yNS4zMDQgMTguMzExLTM2Ljg2OCAxLjA2MTEtMi45MDU5IDEuMDk1Ni0zLjE3NTcgMC41MTkxNy00LjA1NTQtMS4yMjg1LTEuODc1LTMuNTEwNi00LjEyNTEtNS45NDYzLTUuODYzMi01LjUwMjUtMy45MjY1LTEyLjA1Ny01LjYxMy0yMS44MDUtNS42MTA0LTEwLjk3NCAwLjAwMjktMTkuMTkgMi4xNTEzLTI2LjE0MSA2LjgzNTUtNS4yODk5IDMuNTY0Ny01LjcwMzggNC4xNjM2LTQuNTkyNSA2LjY0NDcgMC4zMDQ2OCAwLjY4MDI0IDEuNTYzMyAzLjc5NzkgMi43OTY4IDYuOTI4IDQuNzI4NyAxMS45OTkgMTMuNTAyIDI4LjI1NSAyNC4wMjggNDQuNTI1bDIuNTI0NCAzLjkwMTcgMi45Mjg3LTQuNDkwNGMxLjYxMDgtMi40Njk3IDQuOTMwMi03Ljg0NjMgNy4zNzY0LTExLjk0OHoiIHN0cm9rZS13aWR0aD0iLjM5MjUiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.19965" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTk4LjUzbW0iIGhlaWdodD0iMTc2LjAybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE5OC41MyAxNzYuMDIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMi4zMjQ1IC01Mi4wMjUpIj4KICA8cGF0aCBkPSJtMi4zMjQ1IDIxNC44MnYtMTMuMjIyaDI2LjgyM2wyZS0zIC01MC43NjVjOS40ZS00IC0zMi4zNTYgMC4wNzAyLTUxLjU1MiAwLjE5MDk2LTUyLjkzNyAyLjEzOC0yNC41MTYgMjEuNDI0LTQzLjcxIDQ1LjkzOC00NS43MTcgMS43MDM0LTAuMTM5NTEgMTAuNy0wLjE4MzI0IDI4LjAxLTAuMTM2MTMgMjcuODUzIDAuMDc1OCAyNi4zNDcgMC4wMTg3OSAzMS41OTQgMS4xOTU4IDE4Ljg4MSA0LjIzNDYgMzMuNTM0IDE4LjgyNyAzNy45MTkgMzcuNzYzIDAuMTY4NDMgMC43MjcyMyAwLjQ4NjY2IDIuMzg0OCAwLjcwNzE2IDMuNjgzNCAwLjQwMDg3IDIuMzYwOSAwLjQwMDkyIDIuMzY2NyAwLjQ2Mzg5IDU0LjYzN2wwLjA2MyA1Mi4yNzZoMjYuODE1djI2LjQ0NWgtMTk4LjUzem0xMzQuODctNjQuMTE5YzAtNTUuODAyIDAuMDU5OC01Mi43NC0xLjEyMTUtNTcuNDE3LTEuNTE5OC02LjAxNzYtNC41NDcxLTExLjI2LTkuMTcxOS0xNS44ODItNS4zNzg0LTUuMzc1OS0xMS40NDMtOC41MjI0LTE4Ljk4NS05Ljg1MDgtMS44MTkyLTAuMzIwNDEtMy4yMzQ1LTAuMzQ5MzMtMTcuMDk1LTAuMzQ5MzMtMTYuMzI2IDAtMTYuMzY5IDAuMDAyMi0yMC40MzIgMS4wNDgtNi4wNzA0IDEuNTYyNi0xMS4yMjkgNC41NDMzLTE1LjgzNiA5LjE1MS01LjI4NzUgNS4yODc1LTguMjU3NSAxMC45NTMtOS44NTM2IDE4Ljc5Ni0wLjMwNDE2IDEuNDk0Ni0wLjMzMDg5IDUuMTkzOC0wLjM4NjYgNTMuNTA0bC0wLjA1OTggNTEuODk4aDkyLjk0MXoiIHN0cm9rZS13aWR0aD0iLjE4ODg5Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.96269" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yMW1tIiBoZWlnaHQ9IjE1Mi4xbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE4Mi4yMSAxNTIuMSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtOS4wMzA5IC02MS4xMDMpIj48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE1OS44NCAyMTEuNjQtMTQ5LjI0LTkwLjU0MSAxNzkuMDktMC4xMTEwNW0tMTQ5LjM2IDkwLjY1MiAxNDkuMzYtOTAuNjUybS04OS42LTU4LjMyMyA1OS43NTYgMTQ4Ljk4bS01OS43NTYtMTQ4Ljk4LTU5Ljc1NiAxNDguOTgiIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMy4xMjIxIi8+PGc+PGc+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtMzEzLjk4IDYxNS45OGMtNDIuMTcyLTI1LjYyMy02My43NDctMzkuNTQtNjMuNi00MS4wMjYgMC4xMjIyOC0xLjIzNyAxMC4wMjYtMjYuNjIxIDIyLjAwOC01Ni40MDlsMjEuNzg1LTU0LjE2IDE2OC41NyAwLjcwNTQ4IDQ0LjU3OCAxMTEuNDQtNC42MDc4IDIuODEyYy0zMC42NDUgMTguNzAyLTEyMC40NSA3My4wNjUtMTIyLjM4IDc0LjA4LTEuOTc4IDEuMDQxNi0xNi41NjgtNy4xOTA3LTY2LjM1OC0zNy40NDJ6IiBzdHJva2Utd2lkdGg9IjE2LjA4MSIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTUxOC4yMyA1NjkuMTVjLTAuMjQ5MDEtMC42MjgyNi05LjgwNzctMjQuNDY3LTIxLjI0Mi01Mi45NzUtMTEuNDM0LTI4LjUwOC0yMC43MTItNTEuOTEtMjAuNjE5LTUyLjAwMyAwLjA5MzctMC4wOTM3IDQ4Ljk4LTAuMTExNDMgMTA4LjY0LTAuMDM5NGwxMDguNDcgMC4xMzA5LTc3LjM3NyA0Ni45NDVjLTQyLjU1NyAyNS44Mi04MS44ODUgNDkuNjc2LTg3LjM5NiA1My4wMTUtOS41OTk0IDUuODE1OS0xMC4wMzggNi4wMjIzLTEwLjQ3MiA0LjkyNzl6IiBzdHJva2Utd2lkdGg9IjUuNjg1NiIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTI5OS40NyA0NDkuODZjMC4zODE4LTAuOTI3MjIgMTUuMzczLTM4LjI3OSAzMy4zMTMtODMuMDA1bDMyLjYxOS04MS4zMTkgMjUuODQ2IDAuMjc2NzMgMzIuODc4IDgxLjk0NWMxOC4wODMgNDUuMDcgMzMuMDEgODIuMzYgMzMuMTcxIDgyLjg2NiAwLjI3OTA3IDAuODc5MjgtMy4yOTQ3IDAuOTIwODctNzkuMTE0IDAuOTIwODdoLTc5LjQwN3oiIHN0cm9rZS13aWR0aD0iNS42ODU2Ii8+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtNDkwLjcxIDcyMy41MWMtNTQuNDkyLTMzLjA1OS05OS4wMS02MC40MTQtOTguOTMtNjAuNzg5IDAuMjU3NjctMS4xOTc4IDEyMC4xNy03My43MDkgMTIwLjgtNzMuMDQ4IDAuODg3MzEgMC45Mjg3MyA3Ny44ODQgMTkzLjI2IDc3LjUxNSAxOTMuNjMtMC4xNzE2MSAwLjE3MTM5LTQ0Ljg5Ni0yNi43MzYtOTkuMzg4LTU5Ljc5NXoiIHN0cm9rZS13aWR0aD0iMTEuMzcxIi8+PC9nPjxwYXRoIGQ9Im05OS45MzIgNzUuNDM1Yy0yLjc1NTMtMC4wMzkxOS0zLjU2NTYtMC4xMDA5My0zLjUwNDEtMC4yNjcwMiAxLjgzNDQtNC45NTcgMy40NTExLTkuMjAyOCAzLjU0MzEtOS4zMDUzIDAuMDY1OTMtMC4wNzMyOCAwLjg0Nzk5IDEuODIzMyAxLjczODIgNC4yMTQ2IDAuODkwMiAyLjM5MTMgMS43MTczIDQuNjA0NyAxLjgzNzkgNC45MTg2IDAuMTIwNzEgMC4zMTM5IDAuMTYzMDMgMC41NTI1OSAwLjA5NDEgMC41MzA0NC0wLjA2ODgtMC4wMjIxNy0xLjczODEtMC4wNjMyMy0zLjcwOTMtMC4wOTEyOHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIxLjg2MDMiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNDkuODkgNTE2Ljk4LTg2LjY5NC01Mi42MTQgMTA4LjI3LTAuMTg1ODNjNTkuNTQ5LTAuMTAyMiAxMDguMzgtMC4wNzU1IDEwOC41MiAwLjA1OTIgMC41MDI3MyAwLjUwMjczLTQxLjk2MiAxMDUuMzctNDIuNjY2IDEwNS4zNi0wLjQwMzQ3LTNlLTMgLTM5Ljc0Ni0yMy42ODItODcuNDI4LTUyLjYyeiIgc3Ryb2tlLXdpZHRoPSI4LjA0MDYiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNjcuNDYgNzgxLjE4YzAuMjg5OS0xLjE1OTMgMTcuNjUyLTQ0Ljg0NCAzOC41ODEtOTcuMDc3bDM4LjA1NC05NC45NyA0LjQ5MzcgMi44NTI5YzIuNDcxNSAxLjU2OTEgMjkuMzk3IDE3Ljg5NiA1OS44MzQgMzYuMjgzczU1LjM2MSAzMy44NjIgNTUuMzg2IDM0LjM5MWMwLjAyNTIgMC41MjgzOC00Mi43MDQgMjYuODgtOTQuOTU0IDU4LjU2LTUyLjI1IDMxLjY4LTk2LjU1NyA1OC42MDUtOTguNDYxIDU5LjgzNC0yLjkyMSAxLjg4NTktMy4zNzkyIDEuOTA1OC0yLjkzNDQgMC4xMjcwNnoiIHN0cm9rZS13aWR0aD0iMTYuMDgxIi8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTc0LjAzbW0iIGhlaWdodD0iMjgyLjgzbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NC4wMyAyODIuODMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjAuODk4IC02LjgzOSkiPgogIDxwYXRoIGQ9Im00OS43NDYgMjc4LjkyYy01LjYxMjctNS44NTQtMTQuNC0xNC45ODMtMTkuNTI3LTIwLjI4Ni01LjEyNy01LjMwMzUtOS4zMjE4LTkuNzY0NS05LjMyMTgtOS45MTMzIDAtMC4xNDg4MyAxLjMwNDUtMi4yNzc2IDIuODk4OC00LjczMDUgMS41OTQzLTIuNDUzIDUuNjg0NS04Ljg3NTUgOS4wODk0LTE0LjI3MiA4LjkxNjQtMTQuMTMzIDI1Ljg0LTQwLjU0OSAzMi42MjUtNTAuOTI0IDEuNzk5Mi0yLjc1MTEgMy4yNzEyLTUuMTY1IDMuMjcxMi01LjM2NDFzMC4xNDEwNy0wLjQyMDk2IDAuMzEzNDktMC40OTI5MmMwLjE3MjQyLTAuMDcyIDIuOTg5NS00LjIyODkgNi4yNjAxLTkuMjM3N2w1Ljk0NjYtOS4xMDY5LTMuNjUxOC02LjM5NjhjLTIuMDA4NS0zLjUxODItNS43ODE4LTEwLjAzMS04LjM4NTEtMTQuNDcyLTExLjMxNy0xOS4zMDctMTQuMTk2LTI3LjE4Mi0xMy42OTYtMzcuNDU0IDAuODc5MTMtMTguMDU4IDExLjg4Mi01Ny44MyAyMC4xMjQtNzIuNzQ1IDEuOTk3Ny0zLjYxNDggOC4wMzQ1LTkuNTc3NiAxMi4xMTUtMTEuOTY2IDYuMTc0OC0zLjYxNDYgMTEuMjg5LTQuNzQxOCAyMS40MDEtNC43MTY5IDYuMTU4IDAuMDE1MTU4IDcuNzU4MyAwLjE0Nzc5IDEwLjUzMyAwLjg3Mjk3IDQuMTU3NyAxLjA4NjUgNy43MyAyLjcwNjUgMTAuNzk4IDQuODk2NSAyLjk2MjMgMi4xMTQ5IDcuODM4NCA3LjE2NDQgOS45Mzg3IDEwLjI5MiA4LjgzNSAxMy4xNTcgMTguNTI5IDM3Ljk4MSAyMi45MDIgNTguNjQ4IDEuMDgxOCA1LjExMjMgMS40NjY1IDEzLjE0MSAwLjc5NDM2IDE2LjU3OS0xLjU5NTIgOC4xNTg2LTYuNTEwNyAxOC40MTMtMTcuMDc2IDM1LjYyNC0yLjMzNSAzLjgwMzYtOS45MDY0IDE3LjA1LTExLjEyNyAxOS40NjdsLTAuODEyMzYgMS42MDg1IDEuNDMxIDIuMTIwMmMxMC43OTggMTUuOTk5IDU4LjI0MyA5MC4xOTYgNTguMzM5IDkxLjIzNSAwLjAyMjMgMC4yNDE1Ny03Ljk5NTggOC44OTE2LTE3LjgxOCAxOS4yMjJzLTE4LjU3IDE5LjU2Ny0xOS40MzggMjAuNTI1bC0xLjU3OTggMS43NDE4LTEzLjc5MS0yNS4wNzFjLTMxLjM3LTU3LjAyOS0zNC4wMjYtNjEuNzc5LTM0LjM2LTYxLjQ0NS0wLjE1OTM2IDAuMTU5MzYtMC43ODkyNSAxLjI1NTUtMS4zOTk4IDIuNDM1OC0wLjk1NTE5IDEuODQ2OC0xMC4yNzQgMTguNzU4LTI2LjkzMSA0OC44NzUtMi4zOTQ2IDQuMzI5Ni03LjcwOTcgMTMuOTk3LTExLjgxMSAyMS40ODRzLTcuNTQ1OCAxMy42MTItNy42NTM3IDEzLjYxMmMtMC4xMDc5NCAyLjhlLTQgLTQuNzg4NS00Ljc4OTEtMTAuNDAxLTEwLjY0M3ptNjguNjY1LTE4MS40N2M5LjA5NTYtMTUuMjUxIDE0LjA4OS0yNS4zMDQgMTguMzExLTM2Ljg2OCAxLjA2MTEtMi45MDU5IDEuMDk1Ni0zLjE3NTcgMC41MTkxNy00LjA1NTQtMS4yMjg1LTEuODc1LTMuNTEwNi00LjEyNTEtNS45NDYzLTUuODYzMi01LjUwMjUtMy45MjY1LTEyLjA1Ny01LjYxMy0yMS44MDUtNS42MTA0LTEwLjk3NCAwLjAwMjktMTkuMTkgMi4xNTEzLTI2LjE0MSA2LjgzNTUtNS4yODk5IDMuNTY0Ny01LjcwMzggNC4xNjM2LTQuNTkyNSA2LjY0NDcgMC4zMDQ2OCAwLjY4MDI0IDEuNTYzMyAzLjc5NzkgMi43OTY4IDYuOTI4IDQuNzI4NyAxMS45OTkgMTMuNTAyIDI4LjI1NSAyNC4wMjggNDQuNTI1bDIuNTI0NCAzLjkwMTcgMi45Mjg3LTQuNDkwNGMxLjYxMDgtMi40Njk3IDQuOTMwMi03Ljg0NjMgNy4zNzY0LTExLjk0OHoiIHN0cm9rZS13aWR0aD0iLjM5MjUiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.19965" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTcyLjdtbSIgaGVpZ2h0PSIyMjEuMzhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgMTcyLjcgMjIxLjM4IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KIDxtZXRhZGF0YT4KICA8cmRmOlJERj4KICAgPGNjOldvcmsgcmRmOmFib3V0PSIiPgogICAgPGRjOmZvcm1hdD5pbWFnZS9zdmcreG1sPC9kYzpmb3JtYXQ+CiAgICA8ZGM6dHlwZSByZGY6cmVzb3VyY2U9Imh0dHA6Ly9wdXJsLm9yZy9kYy9kY21pdHlwZS9TdGlsbEltYWdlIi8+CiAgIDwvY2M6V29yaz4KICA8L3JkZjpSREY+CiA8L21ldGFkYXRhPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTE1Ljk0OSAtMzEuODY0KSI+CiAgPHBhdGggZD0ibTE2Ljc4NyAyNTIuMjdjLTAuNDYwOTMtMC40NjA5MS0wLjgzODA2LTIuNzMxMi0wLjgzODA2LTUuMDQ1IDAtMy44NzkyIDAuNzU5MDEtNC42ODcxIDkuNzQyNS0xMC4zNyAxOS43NDEtMTIuNDg3IDIzLjIwNC0xNS40MTQgMjIuMzgxLTE4LjkxOC0wLjQwOTYyLTEuNzQzOS0xLjA4OTQtNy43MjU1LTEuNTEwNi0xMy4yOTItMC44Nzg2NS0xMS42MTQgMS4yNzgxLTIxLjIxIDYuMzU5OS0yOC4yOTkgOC4xMi0xMS4zMjYgMTQuNTgxLTIzLjAzOCAxNy4yMDctMzEuMTkyIDEuNTg3NS00LjkyOTEgMy4zNDgzLTguNTAwMiAzLjkxMjctNy45MzU3IDEuMzIzMiAxLjMyMzIgNC43NTg0IDIwLjc5NyA0Ljc2MDYgMjYuOTg4IDkuNDdlLTQgMi42MTM2LTEuNDEyNSA4LjExMi0zLjE0MSAxMi4yMTktMy40MTI4IDguMTA4My00LjM2NzMgMjAuMTEzLTEuNTk5MiAyMC4xMTMgMC44NDg5NSAwIDUuODU2My00LjI4NzUgMTEuMTI4LTkuNTI3N2w5LjU4NC05LjUyNzctMy4xMjQ3LTcuNzM1OWMtMS43MTg2LTQuMjU0OC0zLjQwMTQtMTEuMTg0LTMuNzM5Ny0xNS4zOTctMC43NDM1My05LjI2MjggMS4xMjA0LTE0LjA0IDEyLjA5Ny0zMS4wMDcgNy4zOTAyLTExLjQyMyA3LjU4Ny0xMS45NTYgOS43NDM1LTI2LjQyOSAxLjIxMDYtOC4xMjQgMi42NDQzLTE0Ljc3MSAzLjE4NjItMTQuNzcxIDAuNTQxODIgMCAyLjk1NTQgNC43MzQxIDQuMzUwNiAxMC43OTRsMi4wMDEyIDguNjkxOGMxLjYyMjMgMi42OTU4LTEuNTg3OSAxNi43NjQtMS41ODc5IDE2Ljc2NC0xLjYyMzggOC4wNjQtMi45MjcgMTcuNzczLTIuODk2MiAyMS41NzYgMC4wNTgzIDcuMTk0MyAzLjEyMiAxNS4xMDYgNS44MzA3IDE1LjA1OCAzLjQ2NDctMC4wNjIyIDEyLjE2Ni01LjAyMyAxOC4xODItMTAuMzY3IDMuNTIzNS0zLjEyOTQgOS41OTAzLTYuODgxIDEzLjQ4Mi04LjMzNyA5LjQyMjUtMy41MjU0IDE2LjE5MS03LjA0NDcgMTguMTk3LTkuNDYxMiAwLjkwMjY2LTEuMDg3NiAyLjEzNzYtMS45Nzc1IDIuNzQ0NC0xLjk3NzUgMi4wNzU0IDAgMS4wOTI2IDMuMTQyNC0yLjc1MTkgOC43OTk3LTIuMTE0NCAzLjExMTMtNS45NzQgMTAuMTkxLTguNTc2OCAxNS43MzMtNS42NTA3IDEyLjAzMS0xNC42ODEgMjAuODI0LTI4LjQ4MSAyNy43MzItMTAuNTI5IDUuMjcwNi0xOS42NDMgNi41MDk1LTI5LjEwMyAzLjk1NjVsLTYuNTMzMy0xLjc2My05LjYyNTkgMTEuODE5Yy01LjI5NDIgNi41MDA2LTkuMzMwNyAxMi4xMTQtOC45Njk5IDEyLjQ3NSAwLjM2MDc5IDAuMzYwOCAyLjgyNCAwLjk0MyA1LjQ3MzkgMS4yOTM4IDQuMTIwNiAwLjU0NTUyIDUuNjc5LTAuMDIxNiAxMC43NjctMy45MTc5IDExLjYtOC44ODMgMTcuOTYtMTEuMjY2IDI5LjkzNS0xMS4yMTYgNS45MDg2IDAuMDI0NSAxMS43OTEgMC42MzEyNCAxMy4wNzIgMS4zNDgzIDIuMDQ0MiAxLjE0NCAxLjExMzIgMi4xNTc4LTcuNjAwMSA4LjI3NTItNS40NjE0IDMuODM0My0xNC4wMzMgMTEuNTAzLTE5LjA0OSAxNy4wNDItNy40OTk4IDguMjgyMi0xMC40MDIgMTAuNTU2LTE2LjM0MiAxMi44MDQtMTAuMTA0IDMuODI0Mi0yNS44MjggNC43MTY5LTM0LjI5NyAxLjk0N2wtNi40OTg0LTIuMTI1NS03LjA5ODggNi43NDMxYy0xMy42NTUgMTIuOTcxLTI3LjA3NCAyMC4xMzktMzAuNzc0IDE2LjQzOXptMTE0LjI5LTEyMC45M2MtMS4wNzY0LTEuNzQxNiA3LjQwNDYtMzAuMzg3IDExLjIzNC0zNy45NDMgNy44Mjg3LTE1LjQ0OSA0MS4yNTctNjEuNTQyIDQ0LjYzMy02MS41NDIgMi4zMDgxIDAgMi4yNzcyIDIuNDE0NS0wLjEzMDE0IDEwLjE2NS0xLjM3NzMgNC40MzQ0LTQuNDg5OCAxNS45MDktNi45MTY4IDI1LjQ5OS0yLjQyNjkgOS41OTAyLTUuNzQzOCAyMC4wNjQtNy4zNzA5IDIzLjI3NS02LjgyNDEgMTMuNDY3LTE3LjU3NSAyNC42MDgtMzkuMjQ1IDQwLjY2OS0wLjgzNTYzIDAuNjE5MzMtMS43Nzc2IDAuNTY2OTItMi4yMDM4LTAuMTIyNjJ6IiBzdHJva2Utd2lkdGg9IjEuMjU3MSIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.21258" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTk4LjUzbW0iIGhlaWdodD0iMTc2LjAybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE5OC41MyAxNzYuMDIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMi4zMjQ1IC01Mi4wMjUpIj4KICA8cGF0aCBkPSJtMi4zMjQ1IDIxNC44MnYtMTMuMjIyaDI2LjgyM2wyZS0zIC01MC43NjVjOS40ZS00IC0zMi4zNTYgMC4wNzAyLTUxLjU1MiAwLjE5MDk2LTUyLjkzNyAyLjEzOC0yNC41MTYgMjEuNDI0LTQzLjcxIDQ1LjkzOC00NS43MTcgMS43MDM0LTAuMTM5NTEgMTAuNy0wLjE4MzI0IDI4LjAxLTAuMTM2MTMgMjcuODUzIDAuMDc1OCAyNi4zNDcgMC4wMTg3OSAzMS41OTQgMS4xOTU4IDE4Ljg4MSA0LjIzNDYgMzMuNTM0IDE4LjgyNyAzNy45MTkgMzcuNzYzIDAuMTY4NDMgMC43MjcyMyAwLjQ4NjY2IDIuMzg0OCAwLjcwNzE2IDMuNjgzNCAwLjQwMDg3IDIuMzYwOSAwLjQwMDkyIDIuMzY2NyAwLjQ2Mzg5IDU0LjYzN2wwLjA2MyA1Mi4yNzZoMjYuODE1djI2LjQ0NWgtMTk4LjUzem0xMzQuODctNjQuMTE5YzAtNTUuODAyIDAuMDU5OC01Mi43NC0xLjEyMTUtNTcuNDE3LTEuNTE5OC02LjAxNzYtNC41NDcxLTExLjI2LTkuMTcxOS0xNS44ODItNS4zNzg0LTUuMzc1OS0xMS40NDMtOC41MjI0LTE4Ljk4NS05Ljg1MDgtMS44MTkyLTAuMzIwNDEtMy4yMzQ1LTAuMzQ5MzMtMTcuMDk1LTAuMzQ5MzMtMTYuMzI2IDAtMTYuMzY5IDAuMDAyMi0yMC40MzIgMS4wNDgtNi4wNzA0IDEuNTYyNi0xMS4yMjkgNC41NDMzLTE1LjgzNiA5LjE1MS01LjI4NzUgNS4yODc1LTguMjU3NSAxMC45NTMtOS44NTM2IDE4Ljc5Ni0wLjMwNDE2IDEuNDk0Ni0wLjMzMDg5IDUuMTkzOC0wLjM4NjYgNTMuNTA0bC0wLjA1OTggNTEuODk4aDkyLjk0MXoiIHN0cm9rZS13aWR0aD0iLjE4ODg5Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.96269" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTc0LjAzbW0iIGhlaWdodD0iMjgyLjgzbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NC4wMyAyODIuODMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjAuODk4IC02LjgzOSkiPgogIDxwYXRoIGQ9Im00OS43NDYgMjc4LjkyYy01LjYxMjctNS44NTQtMTQuNC0xNC45ODMtMTkuNTI3LTIwLjI4Ni01LjEyNy01LjMwMzUtOS4zMjE4LTkuNzY0NS05LjMyMTgtOS45MTMzIDAtMC4xNDg4MyAxLjMwNDUtMi4yNzc2IDIuODk4OC00LjczMDUgMS41OTQzLTIuNDUzIDUuNjg0NS04Ljg3NTUgOS4wODk0LTE0LjI3MiA4LjkxNjQtMTQuMTMzIDI1Ljg0LTQwLjU0OSAzMi42MjUtNTAuOTI0IDEuNzk5Mi0yLjc1MTEgMy4yNzEyLTUuMTY1IDMuMjcxMi01LjM2NDFzMC4xNDEwNy0wLjQyMDk2IDAuMzEzNDktMC40OTI5MmMwLjE3MjQyLTAuMDcyIDIuOTg5NS00LjIyODkgNi4yNjAxLTkuMjM3N2w1Ljk0NjYtOS4xMDY5LTMuNjUxOC02LjM5NjhjLTIuMDA4NS0zLjUxODItNS43ODE4LTEwLjAzMS04LjM4NTEtMTQuNDcyLTExLjMxNy0xOS4zMDctMTQuMTk2LTI3LjE4Mi0xMy42OTYtMzcuNDU0IDAuODc5MTMtMTguMDU4IDExLjg4Mi01Ny44MyAyMC4xMjQtNzIuNzQ1IDEuOTk3Ny0zLjYxNDggOC4wMzQ1LTkuNTc3NiAxMi4xMTUtMTEuOTY2IDYuMTc0OC0zLjYxNDYgMTEuMjg5LTQuNzQxOCAyMS40MDEtNC43MTY5IDYuMTU4IDAuMDE1MTU4IDcuNzU4MyAwLjE0Nzc5IDEwLjUzMyAwLjg3Mjk3IDQuMTU3NyAxLjA4NjUgNy43MyAyLjcwNjUgMTAuNzk4IDQuODk2NSAyLjk2MjMgMi4xMTQ5IDcuODM4NCA3LjE2NDQgOS45Mzg3IDEwLjI5MiA4LjgzNSAxMy4xNTcgMTguNTI5IDM3Ljk4MSAyMi45MDIgNTguNjQ4IDEuMDgxOCA1LjExMjMgMS40NjY1IDEzLjE0MSAwLjc5NDM2IDE2LjU3OS0xLjU5NTIgOC4xNTg2LTYuNTEwNyAxOC40MTMtMTcuMDc2IDM1LjYyNC0yLjMzNSAzLjgwMzYtOS45MDY0IDE3LjA1LTExLjEyNyAxOS40NjdsLTAuODEyMzYgMS42MDg1IDEuNDMxIDIuMTIwMmMxMC43OTggMTUuOTk5IDU4LjI0MyA5MC4xOTYgNTguMzM5IDkxLjIzNSAwLjAyMjMgMC4yNDE1Ny03Ljk5NTggOC44OTE2LTE3LjgxOCAxOS4yMjJzLTE4LjU3IDE5LjU2Ny0xOS40MzggMjAuNTI1bC0xLjU3OTggMS43NDE4LTEzLjc5MS0yNS4wNzFjLTMxLjM3LTU3LjAyOS0zNC4wMjYtNjEuNzc5LTM0LjM2LTYxLjQ0NS0wLjE1OTM2IDAuMTU5MzYtMC43ODkyNSAxLjI1NTUtMS4zOTk4IDIuNDM1OC0wLjk1NTE5IDEuODQ2OC0xMC4yNzQgMTguNzU4LTI2LjkzMSA0OC44NzUtMi4zOTQ2IDQuMzI5Ni03LjcwOTcgMTMuOTk3LTExLjgxMSAyMS40ODRzLTcuNTQ1OCAxMy42MTItNy42NTM3IDEzLjYxMmMtMC4xMDc5NCAyLjhlLTQgLTQuNzg4NS00Ljc4OTEtMTAuNDAxLTEwLjY0M3ptNjguNjY1LTE4MS40N2M5LjA5NTYtMTUuMjUxIDE0LjA4OS0yNS4zMDQgMTguMzExLTM2Ljg2OCAxLjA2MTEtMi45MDU5IDEuMDk1Ni0zLjE3NTcgMC41MTkxNy00LjA1NTQtMS4yMjg1LTEuODc1LTMuNTEwNi00LjEyNTEtNS45NDYzLTUuODYzMi01LjUwMjUtMy45MjY1LTEyLjA1Ny01LjYxMy0yMS44MDUtNS42MTA0LTEwLjk3NCAwLjAwMjktMTkuMTkgMi4xNTEzLTI2LjE0MSA2LjgzNTUtNS4yODk5IDMuNTY0Ny01LjcwMzggNC4xNjM2LTQuNTkyNSA2LjY0NDcgMC4zMDQ2OCAwLjY4MDI0IDEuNTYzMyAzLjc5NzkgMi43OTY4IDYuOTI4IDQuNzI4NyAxMS45OTkgMTMuNTAyIDI4LjI1NSAyNC4wMjggNDQuNTI1bDIuNTI0NCAzLjkwMTcgMi45Mjg3LTQuNDkwNGMxLjYxMDgtMi40Njk3IDQuOTMwMi03Ljg0NjMgNy4zNzY0LTExLjk0OHoiIHN0cm9rZS13aWR0aD0iLjM5MjUiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.19965" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yMW1tIiBoZWlnaHQ9IjE1Mi4xbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE4Mi4yMSAxNTIuMSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtOS4wMzA5IC02MS4xMDMpIj48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE1OS44NCAyMTEuNjQtMTQ5LjI0LTkwLjU0MSAxNzkuMDktMC4xMTEwNW0tMTQ5LjM2IDkwLjY1MiAxNDkuMzYtOTAuNjUybS04OS42LTU4LjMyMyA1OS43NTYgMTQ4Ljk4bS01OS43NTYtMTQ4Ljk4LTU5Ljc1NiAxNDguOTgiIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMy4xMjIxIi8+PGc+PGc+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtMzEzLjk4IDYxNS45OGMtNDIuMTcyLTI1LjYyMy02My43NDctMzkuNTQtNjMuNi00MS4wMjYgMC4xMjIyOC0xLjIzNyAxMC4wMjYtMjYuNjIxIDIyLjAwOC01Ni40MDlsMjEuNzg1LTU0LjE2IDE2OC41NyAwLjcwNTQ4IDQ0LjU3OCAxMTEuNDQtNC42MDc4IDIuODEyYy0zMC42NDUgMTguNzAyLTEyMC40NSA3My4wNjUtMTIyLjM4IDc0LjA4LTEuOTc4IDEuMDQxNi0xNi41NjgtNy4xOTA3LTY2LjM1OC0zNy40NDJ6IiBzdHJva2Utd2lkdGg9IjE2LjA4MSIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTUxOC4yMyA1NjkuMTVjLTAuMjQ5MDEtMC42MjgyNi05LjgwNzctMjQuNDY3LTIxLjI0Mi01Mi45NzUtMTEuNDM0LTI4LjUwOC0yMC43MTItNTEuOTEtMjAuNjE5LTUyLjAwMyAwLjA5MzctMC4wOTM3IDQ4Ljk4LTAuMTExNDMgMTA4LjY0LTAuMDM5NGwxMDguNDcgMC4xMzA5LTc3LjM3NyA0Ni45NDVjLTQyLjU1NyAyNS44Mi04MS44ODUgNDkuNjc2LTg3LjM5NiA1My4wMTUtOS41OTk0IDUuODE1OS0xMC4wMzggNi4wMjIzLTEwLjQ3MiA0LjkyNzl6IiBzdHJva2Utd2lkdGg9IjUuNjg1NiIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTI5OS40NyA0NDkuODZjMC4zODE4LTAuOTI3MjIgMTUuMzczLTM4LjI3OSAzMy4zMTMtODMuMDA1bDMyLjYxOS04MS4zMTkgMjUuODQ2IDAuMjc2NzMgMzIuODc4IDgxLjk0NWMxOC4wODMgNDUuMDcgMzMuMDEgODIuMzYgMzMuMTcxIDgyLjg2NiAwLjI3OTA3IDAuODc5MjgtMy4yOTQ3IDAuOTIwODctNzkuMTE0IDAuOTIwODdoLTc5LjQwN3oiIHN0cm9rZS13aWR0aD0iNS42ODU2Ii8+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtNDkwLjcxIDcyMy41MWMtNTQuNDkyLTMzLjA1OS05OS4wMS02MC40MTQtOTguOTMtNjAuNzg5IDAuMjU3NjctMS4xOTc4IDEyMC4xNy03My43MDkgMTIwLjgtNzMuMDQ4IDAuODg3MzEgMC45Mjg3MyA3Ny44ODQgMTkzLjI2IDc3LjUxNSAxOTMuNjMtMC4xNzE2MSAwLjE3MTM5LTQ0Ljg5Ni0yNi43MzYtOTkuMzg4LTU5Ljc5NXoiIHN0cm9rZS13aWR0aD0iMTEuMzcxIi8+PC9nPjxwYXRoIGQ9Im05OS45MzIgNzUuNDM1Yy0yLjc1NTMtMC4wMzkxOS0zLjU2NTYtMC4xMDA5My0zLjUwNDEtMC4yNjcwMiAxLjgzNDQtNC45NTcgMy40NTExLTkuMjAyOCAzLjU0MzEtOS4zMDUzIDAuMDY1OTMtMC4wNzMyOCAwLjg0Nzk5IDEuODIzMyAxLjczODIgNC4yMTQ2IDAuODkwMiAyLjM5MTMgMS43MTczIDQuNjA0NyAxLjgzNzkgNC45MTg2IDAuMTIwNzEgMC4zMTM5IDAuMTYzMDMgMC41NTI1OSAwLjA5NDEgMC41MzA0NC0wLjA2ODgtMC4wMjIxNy0xLjczODEtMC4wNjMyMy0zLjcwOTMtMC4wOTEyOHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIxLjg2MDMiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNDkuODkgNTE2Ljk4LTg2LjY5NC01Mi42MTQgMTA4LjI3LTAuMTg1ODNjNTkuNTQ5LTAuMTAyMiAxMDguMzgtMC4wNzU1IDEwOC41MiAwLjA1OTIgMC41MDI3MyAwLjUwMjczLTQxLjk2MiAxMDUuMzctNDIuNjY2IDEwNS4zNi0wLjQwMzQ3LTNlLTMgLTM5Ljc0Ni0yMy42ODItODcuNDI4LTUyLjYyeiIgc3Ryb2tlLXdpZHRoPSI4LjA0MDYiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNjcuNDYgNzgxLjE4YzAuMjg5OS0xLjE1OTMgMTcuNjUyLTQ0Ljg0NCAzOC41ODEtOTcuMDc3bDM4LjA1NC05NC45NyA0LjQ5MzcgMi44NTI5YzIuNDcxNSAxLjU2OTEgMjkuMzk3IDE3Ljg5NiA1OS44MzQgMzYuMjgzczU1LjM2MSAzMy44NjIgNTUuMzg2IDM0LjM5MWMwLjAyNTIgMC41MjgzOC00Mi43MDQgMjYuODgtOTQuOTU0IDU4LjU2LTUyLjI1IDMxLjY4LTk2LjU1NyA1OC42MDUtOTguNDYxIDU5LjgzNC0yLjkyMSAxLjg4NTktMy4zNzkyIDEuOTA1OC0yLjkzNDQgMC4xMjcwNnoiIHN0cm9rZS13aWR0aD0iMTYuMDgxIi8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTc0LjAzbW0iIGhlaWdodD0iMjgyLjgzbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NC4wMyAyODIuODMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjAuODk4IC02LjgzOSkiPgogIDxwYXRoIGQ9Im00OS43NDYgMjc4LjkyYy01LjYxMjctNS44NTQtMTQuNC0xNC45ODMtMTkuNTI3LTIwLjI4Ni01LjEyNy01LjMwMzUtOS4zMjE4LTkuNzY0NS05LjMyMTgtOS45MTMzIDAtMC4xNDg4MyAxLjMwNDUtMi4yNzc2IDIuODk4OC00LjczMDUgMS41OTQzLTIuNDUzIDUuNjg0NS04Ljg3NTUgOS4wODk0LTE0LjI3MiA4LjkxNjQtMTQuMTMzIDI1Ljg0LTQwLjU0OSAzMi42MjUtNTAuOTI0IDEuNzk5Mi0yLjc1MTEgMy4yNzEyLTUuMTY1IDMuMjcxMi01LjM2NDFzMC4xNDEwNy0wLjQyMDk2IDAuMzEzNDktMC40OTI5MmMwLjE3MjQyLTAuMDcyIDIuOTg5NS00LjIyODkgNi4yNjAxLTkuMjM3N2w1Ljk0NjYtOS4xMDY5LTMuNjUxOC02LjM5NjhjLTIuMDA4NS0zLjUxODItNS43ODE4LTEwLjAzMS04LjM4NTEtMTQuNDcyLTExLjMxNy0xOS4zMDctMTQuMTk2LTI3LjE4Mi0xMy42OTYtMzcuNDU0IDAuODc5MTMtMTguMDU4IDExLjg4Mi01Ny44MyAyMC4xMjQtNzIuNzQ1IDEuOTk3Ny0zLjYxNDggOC4wMzQ1LTkuNTc3NiAxMi4xMTUtMTEuOTY2IDYuMTc0OC0zLjYxNDYgMTEuMjg5LTQuNzQxOCAyMS40MDEtNC43MTY5IDYuMTU4IDAuMDE1MTU4IDcuNzU4MyAwLjE0Nzc5IDEwLjUzMyAwLjg3Mjk3IDQuMTU3NyAxLjA4NjUgNy43MyAyLjcwNjUgMTAuNzk4IDQuODk2NSAyLjk2MjMgMi4xMTQ5IDcuODM4NCA3LjE2NDQgOS45Mzg3IDEwLjI5MiA4LjgzNSAxMy4xNTcgMTguNTI5IDM3Ljk4MSAyMi45MDIgNTguNjQ4IDEuMDgxOCA1LjExMjMgMS40NjY1IDEzLjE0MSAwLjc5NDM2IDE2LjU3OS0xLjU5NTIgOC4xNTg2LTYuNTEwNyAxOC40MTMtMTcuMDc2IDM1LjYyNC0yLjMzNSAzLjgwMzYtOS45MDY0IDE3LjA1LTExLjEyNyAxOS40NjdsLTAuODEyMzYgMS42MDg1IDEuNDMxIDIuMTIwMmMxMC43OTggMTUuOTk5IDU4LjI0MyA5MC4xOTYgNTguMzM5IDkxLjIzNSAwLjAyMjMgMC4yNDE1Ny03Ljk5NTggOC44OTE2LTE3LjgxOCAxOS4yMjJzLTE4LjU3IDE5LjU2Ny0xOS40MzggMjAuNTI1bC0xLjU3OTggMS43NDE4LTEzLjc5MS0yNS4wNzFjLTMxLjM3LTU3LjAyOS0zNC4wMjYtNjEuNzc5LTM0LjM2LTYxLjQ0NS0wLjE1OTM2IDAuMTU5MzYtMC43ODkyNSAxLjI1NTUtMS4zOTk4IDIuNDM1OC0wLjk1NTE5IDEuODQ2OC0xMC4yNzQgMTguNzU4LTI2LjkzMSA0OC44NzUtMi4zOTQ2IDQuMzI5Ni03LjcwOTcgMTMuOTk3LTExLjgxMSAyMS40ODRzLTcuNTQ1OCAxMy42MTItNy42NTM3IDEzLjYxMmMtMC4xMDc5NCAyLjhlLTQgLTQuNzg4NS00Ljc4OTEtMTAuNDAxLTEwLjY0M3ptNjguNjY1LTE4MS40N2M5LjA5NTYtMTUuMjUxIDE0LjA4OS0yNS4zMDQgMTguMzExLTM2Ljg2OCAxLjA2MTEtMi45MDU5IDEuMDk1Ni0zLjE3NTcgMC41MTkxNy00LjA1NTQtMS4yMjg1LTEuODc1LTMuNTEwNi00LjEyNTEtNS45NDYzLTUuODYzMi01LjUwMjUtMy45MjY1LTEyLjA1Ny01LjYxMy0yMS44MDUtNS42MTA0LTEwLjk3NCAwLjAwMjktMTkuMTkgMi4xNTEzLTI2LjE0MSA2LjgzNTUtNS4yODk5IDMuNTY0Ny01LjcwMzggNC4xNjM2LTQuNTkyNSA2LjY0NDcgMC4zMDQ2OCAwLjY4MDI0IDEuNTYzMyAzLjc5NzkgMi43OTY4IDYuOTI4IDQuNzI4NyAxMS45OTkgMTMuNTAyIDI4LjI1NSAyNC4wMjggNDQuNTI1bDIuNTI0NCAzLjkwMTcgMi45Mjg3LTQuNDkwNGMxLjYxMDgtMi40Njk3IDQuOTMwMi03Ljg0NjMgNy4zNzY0LTExLjk0OHoiIHN0cm9rZS13aWR0aD0iLjM5MjUiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.19965" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTcyLjdtbSIgaGVpZ2h0PSIyMjEuMzhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgMTcyLjcgMjIxLjM4IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KIDxtZXRhZGF0YT4KICA8cmRmOlJERj4KICAgPGNjOldvcmsgcmRmOmFib3V0PSIiPgogICAgPGRjOmZvcm1hdD5pbWFnZS9zdmcreG1sPC9kYzpmb3JtYXQ+CiAgICA8ZGM6dHlwZSByZGY6cmVzb3VyY2U9Imh0dHA6Ly9wdXJsLm9yZy9kYy9kY21pdHlwZS9TdGlsbEltYWdlIi8+CiAgIDwvY2M6V29yaz4KICA8L3JkZjpSREY+CiA8L21ldGFkYXRhPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTE1Ljk0OSAtMzEuODY0KSI+CiAgPHBhdGggZD0ibTE2Ljc4NyAyNTIuMjdjLTAuNDYwOTMtMC40NjA5MS0wLjgzODA2LTIuNzMxMi0wLjgzODA2LTUuMDQ1IDAtMy44NzkyIDAuNzU5MDEtNC42ODcxIDkuNzQyNS0xMC4zNyAxOS43NDEtMTIuNDg3IDIzLjIwNC0xNS40MTQgMjIuMzgxLTE4LjkxOC0wLjQwOTYyLTEuNzQzOS0xLjA4OTQtNy43MjU1LTEuNTEwNi0xMy4yOTItMC44Nzg2NS0xMS42MTQgMS4yNzgxLTIxLjIxIDYuMzU5OS0yOC4yOTkgOC4xMi0xMS4zMjYgMTQuNTgxLTIzLjAzOCAxNy4yMDctMzEuMTkyIDEuNTg3NS00LjkyOTEgMy4zNDgzLTguNTAwMiAzLjkxMjctNy45MzU3IDEuMzIzMiAxLjMyMzIgNC43NTg0IDIwLjc5NyA0Ljc2MDYgMjYuOTg4IDkuNDdlLTQgMi42MTM2LTEuNDEyNSA4LjExMi0zLjE0MSAxMi4yMTktMy40MTI4IDguMTA4My00LjM2NzMgMjAuMTEzLTEuNTk5MiAyMC4xMTMgMC44NDg5NSAwIDUuODU2My00LjI4NzUgMTEuMTI4LTkuNTI3N2w5LjU4NC05LjUyNzctMy4xMjQ3LTcuNzM1OWMtMS43MTg2LTQuMjU0OC0zLjQwMTQtMTEuMTg0LTMuNzM5Ny0xNS4zOTctMC43NDM1My05LjI2MjggMS4xMjA0LTE0LjA0IDEyLjA5Ny0zMS4wMDcgNy4zOTAyLTExLjQyMyA3LjU4Ny0xMS45NTYgOS43NDM1LTI2LjQyOSAxLjIxMDYtOC4xMjQgMi42NDQzLTE0Ljc3MSAzLjE4NjItMTQuNzcxIDAuNTQxODIgMCAyLjk1NTQgNC43MzQxIDQuMzUwNiAxMC43OTRsMi4wMDEyIDguNjkxOGMxLjYyMjMgMi42OTU4LTEuNTg3OSAxNi43NjQtMS41ODc5IDE2Ljc2NC0xLjYyMzggOC4wNjQtMi45MjcgMTcuNzczLTIuODk2MiAyMS41NzYgMC4wNTgzIDcuMTk0MyAzLjEyMiAxNS4xMDYgNS44MzA3IDE1LjA1OCAzLjQ2NDctMC4wNjIyIDEyLjE2Ni01LjAyMyAxOC4xODItMTAuMzY3IDMuNTIzNS0zLjEyOTQgOS41OTAzLTYuODgxIDEzLjQ4Mi04LjMzNyA5LjQyMjUtMy41MjU0IDE2LjE5MS03LjA0NDcgMTguMTk3LTkuNDYxMiAwLjkwMjY2LTEuMDg3NiAyLjEzNzYtMS45Nzc1IDIuNzQ0NC0xLjk3NzUgMi4wNzU0IDAgMS4wOTI2IDMuMTQyNC0yLjc1MTkgOC43OTk3LTIuMTE0NCAzLjExMTMtNS45NzQgMTAuMTkxLTguNTc2OCAxNS43MzMtNS42NTA3IDEyLjAzMS0xNC42ODEgMjAuODI0LTI4LjQ4MSAyNy43MzItMTAuNTI5IDUuMjcwNi0xOS42NDMgNi41MDk1LTI5LjEwMyAzLjk1NjVsLTYuNTMzMy0xLjc2My05LjYyNTkgMTEuODE5Yy01LjI5NDIgNi41MDA2LTkuMzMwNyAxMi4xMTQtOC45Njk5IDEyLjQ3NSAwLjM2MDc5IDAuMzYwOCAyLjgyNCAwLjk0MyA1LjQ3MzkgMS4yOTM4IDQuMTIwNiAwLjU0NTUyIDUuNjc5LTAuMDIxNiAxMC43NjctMy45MTc5IDExLjYtOC44ODMgMTcuOTYtMTEuMjY2IDI5LjkzNS0xMS4yMTYgNS45MDg2IDAuMDI0NSAxMS43OTEgMC42MzEyNCAxMy4wNzIgMS4zNDgzIDIuMDQ0MiAxLjE0NCAxLjExMzIgMi4xNTc4LTcuNjAwMSA4LjI3NTItNS40NjE0IDMuODM0My0xNC4wMzMgMTEuNTAzLTE5LjA0OSAxNy4wNDItNy40OTk4IDguMjgyMi0xMC40MDIgMTAuNTU2LTE2LjM0MiAxMi44MDQtMTAuMTA0IDMuODI0Mi0yNS44MjggNC43MTY5LTM0LjI5NyAxLjk0N2wtNi40OTg0LTIuMTI1NS03LjA5ODggNi43NDMxYy0xMy42NTUgMTIuOTcxLTI3LjA3NCAyMC4xMzktMzAuNzc0IDE2LjQzOXptMTE0LjI5LTEyMC45M2MtMS4wNzY0LTEuNzQxNiA3LjQwNDYtMzAuMzg3IDExLjIzNC0zNy45NDMgNy44Mjg3LTE1LjQ0OSA0MS4yNTctNjEuNTQyIDQ0LjYzMy02MS41NDIgMi4zMDgxIDAgMi4yNzcyIDIuNDE0NS0wLjEzMDE0IDEwLjE2NS0xLjM3NzMgNC40MzQ0LTQuNDg5OCAxNS45MDktNi45MTY4IDI1LjQ5OS0yLjQyNjkgOS41OTAyLTUuNzQzOCAyMC4wNjQtNy4zNzA5IDIzLjI3NS02LjgyNDEgMTMuNDY3LTE3LjU3NSAyNC42MDgtMzkuMjQ1IDQwLjY2OS0wLjgzNTYzIDAuNjE5MzMtMS43Nzc2IDAuNTY2OTItMi4yMDM4LTAuMTIyNjJ6IiBzdHJva2Utd2lkdGg9IjEuMjU3MSIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.21258" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTk4LjUzbW0iIGhlaWdodD0iMTc2LjAybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE5OC41MyAxNzYuMDIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMi4zMjQ1IC01Mi4wMjUpIj4KICA8cGF0aCBkPSJtMi4zMjQ1IDIxNC44MnYtMTMuMjIyaDI2LjgyM2wyZS0zIC01MC43NjVjOS40ZS00IC0zMi4zNTYgMC4wNzAyLTUxLjU1MiAwLjE5MDk2LTUyLjkzNyAyLjEzOC0yNC41MTYgMjEuNDI0LTQzLjcxIDQ1LjkzOC00NS43MTcgMS43MDM0LTAuMTM5NTEgMTAuNy0wLjE4MzI0IDI4LjAxLTAuMTM2MTMgMjcuODUzIDAuMDc1OCAyNi4zNDcgMC4wMTg3OSAzMS41OTQgMS4xOTU4IDE4Ljg4MSA0LjIzNDYgMzMuNTM0IDE4LjgyNyAzNy45MTkgMzcuNzYzIDAuMTY4NDMgMC43MjcyMyAwLjQ4NjY2IDIuMzg0OCAwLjcwNzE2IDMuNjgzNCAwLjQwMDg3IDIuMzYwOSAwLjQwMDkyIDIuMzY2NyAwLjQ2Mzg5IDU0LjYzN2wwLjA2MyA1Mi4yNzZoMjYuODE1djI2LjQ0NWgtMTk4LjUzem0xMzQuODctNjQuMTE5YzAtNTUuODAyIDAuMDU5OC01Mi43NC0xLjEyMTUtNTcuNDE3LTEuNTE5OC02LjAxNzYtNC41NDcxLTExLjI2LTkuMTcxOS0xNS44ODItNS4zNzg0LTUuMzc1OS0xMS40NDMtOC41MjI0LTE4Ljk4NS05Ljg1MDgtMS44MTkyLTAuMzIwNDEtMy4yMzQ1LTAuMzQ5MzMtMTcuMDk1LTAuMzQ5MzMtMTYuMzI2IDAtMTYuMzY5IDAuMDAyMi0yMC40MzIgMS4wNDgtNi4wNzA0IDEuNTYyNi0xMS4yMjkgNC41NDMzLTE1LjgzNiA5LjE1MS01LjI4NzUgNS4yODc1LTguMjU3NSAxMC45NTMtOS44NTM2IDE4Ljc5Ni0wLjMwNDE2IDEuNDk0Ni0wLjMzMDg5IDUuMTkzOC0wLjM4NjYgNTMuNTA0bC0wLjA1OTggNTEuODk4aDkyLjk0MXoiIHN0cm9rZS13aWR0aD0iLjE4ODg5Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.96269" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yMW1tIiBoZWlnaHQ9IjE1Mi4xbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE4Mi4yMSAxNTIuMSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtOS4wMzA5IC02MS4xMDMpIj48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE1OS44NCAyMTEuNjQtMTQ5LjI0LTkwLjU0MSAxNzkuMDktMC4xMTEwNW0tMTQ5LjM2IDkwLjY1MiAxNDkuMzYtOTAuNjUybS04OS42LTU4LjMyMyA1OS43NTYgMTQ4Ljk4bS01OS43NTYtMTQ4Ljk4LTU5Ljc1NiAxNDguOTgiIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMy4xMjIxIi8+PGc+PGc+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtMzEzLjk4IDYxNS45OGMtNDIuMTcyLTI1LjYyMy02My43NDctMzkuNTQtNjMuNi00MS4wMjYgMC4xMjIyOC0xLjIzNyAxMC4wMjYtMjYuNjIxIDIyLjAwOC01Ni40MDlsMjEuNzg1LTU0LjE2IDE2OC41NyAwLjcwNTQ4IDQ0LjU3OCAxMTEuNDQtNC42MDc4IDIuODEyYy0zMC42NDUgMTguNzAyLTEyMC40NSA3My4wNjUtMTIyLjM4IDc0LjA4LTEuOTc4IDEuMDQxNi0xNi41NjgtNy4xOTA3LTY2LjM1OC0zNy40NDJ6IiBzdHJva2Utd2lkdGg9IjE2LjA4MSIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTUxOC4yMyA1NjkuMTVjLTAuMjQ5MDEtMC42MjgyNi05LjgwNzctMjQuNDY3LTIxLjI0Mi01Mi45NzUtMTEuNDM0LTI4LjUwOC0yMC43MTItNTEuOTEtMjAuNjE5LTUyLjAwMyAwLjA5MzctMC4wOTM3IDQ4Ljk4LTAuMTExNDMgMTA4LjY0LTAuMDM5NGwxMDguNDcgMC4xMzA5LTc3LjM3NyA0Ni45NDVjLTQyLjU1NyAyNS44Mi04MS44ODUgNDkuNjc2LTg3LjM5NiA1My4wMTUtOS41OTk0IDUuODE1OS0xMC4wMzggNi4wMjIzLTEwLjQ3MiA0LjkyNzl6IiBzdHJva2Utd2lkdGg9IjUuNjg1NiIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTI5OS40NyA0NDkuODZjMC4zODE4LTAuOTI3MjIgMTUuMzczLTM4LjI3OSAzMy4zMTMtODMuMDA1bDMyLjYxOS04MS4zMTkgMjUuODQ2IDAuMjc2NzMgMzIuODc4IDgxLjk0NWMxOC4wODMgNDUuMDcgMzMuMDEgODIuMzYgMzMuMTcxIDgyLjg2NiAwLjI3OTA3IDAuODc5MjgtMy4yOTQ3IDAuOTIwODctNzkuMTE0IDAuOTIwODdoLTc5LjQwN3oiIHN0cm9rZS13aWR0aD0iNS42ODU2Ii8+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtNDkwLjcxIDcyMy41MWMtNTQuNDkyLTMzLjA1OS05OS4wMS02MC40MTQtOTguOTMtNjAuNzg5IDAuMjU3NjctMS4xOTc4IDEyMC4xNy03My43MDkgMTIwLjgtNzMuMDQ4IDAuODg3MzEgMC45Mjg3MyA3Ny44ODQgMTkzLjI2IDc3LjUxNSAxOTMuNjMtMC4xNzE2MSAwLjE3MTM5LTQ0Ljg5Ni0yNi43MzYtOTkuMzg4LTU5Ljc5NXoiIHN0cm9rZS13aWR0aD0iMTEuMzcxIi8+PC9nPjxwYXRoIGQ9Im05OS45MzIgNzUuNDM1Yy0yLjc1NTMtMC4wMzkxOS0zLjU2NTYtMC4xMDA5My0zLjUwNDEtMC4yNjcwMiAxLjgzNDQtNC45NTcgMy40NTExLTkuMjAyOCAzLjU0MzEtOS4zMDUzIDAuMDY1OTMtMC4wNzMyOCAwLjg0Nzk5IDEuODIzMyAxLjczODIgNC4yMTQ2IDAuODkwMiAyLjM5MTMgMS43MTczIDQuNjA0NyAxLjgzNzkgNC45MTg2IDAuMTIwNzEgMC4zMTM5IDAuMTYzMDMgMC41NTI1OSAwLjA5NDEgMC41MzA0NC0wLjA2ODgtMC4wMjIxNy0xLjczODEtMC4wNjMyMy0zLjcwOTMtMC4wOTEyOHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIxLjg2MDMiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNDkuODkgNTE2Ljk4LTg2LjY5NC01Mi42MTQgMTA4LjI3LTAuMTg1ODNjNTkuNTQ5LTAuMTAyMiAxMDguMzgtMC4wNzU1IDEwOC41MiAwLjA1OTIgMC41MDI3MyAwLjUwMjczLTQxLjk2MiAxMDUuMzctNDIuNjY2IDEwNS4zNi0wLjQwMzQ3LTNlLTMgLTM5Ljc0Ni0yMy42ODItODcuNDI4LTUyLjYyeiIgc3Ryb2tlLXdpZHRoPSI4LjA0MDYiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNjcuNDYgNzgxLjE4YzAuMjg5OS0xLjE1OTMgMTcuNjUyLTQ0Ljg0NCAzOC41ODEtOTcuMDc3bDM4LjA1NC05NC45NyA0LjQ5MzcgMi44NTI5YzIuNDcxNSAxLjU2OTEgMjkuMzk3IDE3Ljg5NiA1OS44MzQgMzYuMjgzczU1LjM2MSAzMy44NjIgNTUuMzg2IDM0LjM5MWMwLjAyNTIgMC41MjgzOC00Mi43MDQgMjYuODgtOTQuOTU0IDU4LjU2LTUyLjI1IDMxLjY4LTk2LjU1NyA1OC42MDUtOTguNDYxIDU5LjgzNC0yLjkyMSAxLjg4NTktMy4zNzkyIDEuOTA1OC0yLjkzNDQgMC4xMjcwNnoiIHN0cm9rZS13aWR0aD0iMTYuMDgxIi8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="36" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTc0LjAzbW0iIGhlaWdodD0iMjgyLjgzbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NC4wMyAyODIuODMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjAuODk4IC02LjgzOSkiPgogIDxwYXRoIGQ9Im00OS43NDYgMjc4LjkyYy01LjYxMjctNS44NTQtMTQuNC0xNC45ODMtMTkuNTI3LTIwLjI4Ni01LjEyNy01LjMwMzUtOS4zMjE4LTkuNzY0NS05LjMyMTgtOS45MTMzIDAtMC4xNDg4MyAxLjMwNDUtMi4yNzc2IDIuODk4OC00LjczMDUgMS41OTQzLTIuNDUzIDUuNjg0NS04Ljg3NTUgOS4wODk0LTE0LjI3MiA4LjkxNjQtMTQuMTMzIDI1Ljg0LTQwLjU0OSAzMi42MjUtNTAuOTI0IDEuNzk5Mi0yLjc1MTEgMy4yNzEyLTUuMTY1IDMuMjcxMi01LjM2NDFzMC4xNDEwNy0wLjQyMDk2IDAuMzEzNDktMC40OTI5MmMwLjE3MjQyLTAuMDcyIDIuOTg5NS00LjIyODkgNi4yNjAxLTkuMjM3N2w1Ljk0NjYtOS4xMDY5LTMuNjUxOC02LjM5NjhjLTIuMDA4NS0zLjUxODItNS43ODE4LTEwLjAzMS04LjM4NTEtMTQuNDcyLTExLjMxNy0xOS4zMDctMTQuMTk2LTI3LjE4Mi0xMy42OTYtMzcuNDU0IDAuODc5MTMtMTguMDU4IDExLjg4Mi01Ny44MyAyMC4xMjQtNzIuNzQ1IDEuOTk3Ny0zLjYxNDggOC4wMzQ1LTkuNTc3NiAxMi4xMTUtMTEuOTY2IDYuMTc0OC0zLjYxNDYgMTEuMjg5LTQuNzQxOCAyMS40MDEtNC43MTY5IDYuMTU4IDAuMDE1MTU4IDcuNzU4MyAwLjE0Nzc5IDEwLjUzMyAwLjg3Mjk3IDQuMTU3NyAxLjA4NjUgNy43MyAyLjcwNjUgMTAuNzk4IDQuODk2NSAyLjk2MjMgMi4xMTQ5IDcuODM4NCA3LjE2NDQgOS45Mzg3IDEwLjI5MiA4LjgzNSAxMy4xNTcgMTguNTI5IDM3Ljk4MSAyMi45MDIgNTguNjQ4IDEuMDgxOCA1LjExMjMgMS40NjY1IDEzLjE0MSAwLjc5NDM2IDE2LjU3OS0xLjU5NTIgOC4xNTg2LTYuNTEwNyAxOC40MTMtMTcuMDc2IDM1LjYyNC0yLjMzNSAzLjgwMzYtOS45MDY0IDE3LjA1LTExLjEyNyAxOS40NjdsLTAuODEyMzYgMS42MDg1IDEuNDMxIDIuMTIwMmMxMC43OTggMTUuOTk5IDU4LjI0MyA5MC4xOTYgNTguMzM5IDkxLjIzNSAwLjAyMjMgMC4yNDE1Ny03Ljk5NTggOC44OTE2LTE3LjgxOCAxOS4yMjJzLTE4LjU3IDE5LjU2Ny0xOS40MzggMjAuNTI1bC0xLjU3OTggMS43NDE4LTEzLjc5MS0yNS4wNzFjLTMxLjM3LTU3LjAyOS0zNC4wMjYtNjEuNzc5LTM0LjM2LTYxLjQ0NS0wLjE1OTM2IDAuMTU5MzYtMC43ODkyNSAxLjI1NTUtMS4zOTk4IDIuNDM1OC0wLjk1NTE5IDEuODQ2OC0xMC4yNzQgMTguNzU4LTI2LjkzMSA0OC44NzUtMi4zOTQ2IDQuMzI5Ni03LjcwOTcgMTMuOTk3LTExLjgxMSAyMS40ODRzLTcuNTQ1OCAxMy42MTItNy42NTM3IDEzLjYxMmMtMC4xMDc5NCAyLjhlLTQgLTQuNzg4NS00Ljc4OTEtMTAuNDAxLTEwLjY0M3ptNjguNjY1LTE4MS40N2M5LjA5NTYtMTUuMjUxIDE0LjA4OS0yNS4zMDQgMTguMzExLTM2Ljg2OCAxLjA2MTEtMi45MDU5IDEuMDk1Ni0zLjE3NTcgMC41MTkxNy00LjA1NTQtMS4yMjg1LTEuODc1LTMuNTEwNi00LjEyNTEtNS45NDYzLTUuODYzMi01LjUwMjUtMy45MjY1LTEyLjA1Ny01LjYxMy0yMS44MDUtNS42MTA0LTEwLjk3NCAwLjAwMjktMTkuMTkgMi4xNTEzLTI2LjE0MSA2LjgzNTUtNS4yODk5IDMuNTY0Ny01LjcwMzggNC4xNjM2LTQuNTkyNSA2LjY0NDcgMC4zMDQ2OCAwLjY4MDI0IDEuNTYzMyAzLjc5NzkgMi43OTY4IDYuOTI4IDQuNzI4NyAxMS45OTkgMTMuNTAyIDI4LjI1NSAyNC4wMjggNDQuNTI1bDIuNTI0NCAzLjkwMTcgMi45Mjg3LTQuNDkwNGMxLjYxMDgtMi40Njk3IDQuOTMwMi03Ljg0NjMgNy4zNzY0LTExLjk0OHoiIHN0cm9rZS13aWR0aD0iLjM5MjUiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.19965" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="37" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="38" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTk4LjUzbW0iIGhlaWdodD0iMTc2LjAybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE5OC41MyAxNzYuMDIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMi4zMjQ1IC01Mi4wMjUpIj4KICA8cGF0aCBkPSJtMi4zMjQ1IDIxNC44MnYtMTMuMjIyaDI2LjgyM2wyZS0zIC01MC43NjVjOS40ZS00IC0zMi4zNTYgMC4wNzAyLTUxLjU1MiAwLjE5MDk2LTUyLjkzNyAyLjEzOC0yNC41MTYgMjEuNDI0LTQzLjcxIDQ1LjkzOC00NS43MTcgMS43MDM0LTAuMTM5NTEgMTAuNy0wLjE4MzI0IDI4LjAxLTAuMTM2MTMgMjcuODUzIDAuMDc1OCAyNi4zNDcgMC4wMTg3OSAzMS41OTQgMS4xOTU4IDE4Ljg4MSA0LjIzNDYgMzMuNTM0IDE4LjgyNyAzNy45MTkgMzcuNzYzIDAuMTY4NDMgMC43MjcyMyAwLjQ4NjY2IDIuMzg0OCAwLjcwNzE2IDMuNjgzNCAwLjQwMDg3IDIuMzYwOSAwLjQwMDkyIDIuMzY2NyAwLjQ2Mzg5IDU0LjYzN2wwLjA2MyA1Mi4yNzZoMjYuODE1djI2LjQ0NWgtMTk4LjUzem0xMzQuODctNjQuMTE5YzAtNTUuODAyIDAuMDU5OC01Mi43NC0xLjEyMTUtNTcuNDE3LTEuNTE5OC02LjAxNzYtNC41NDcxLTExLjI2LTkuMTcxOS0xNS44ODItNS4zNzg0LTUuMzc1OS0xMS40NDMtOC41MjI0LTE4Ljk4NS05Ljg1MDgtMS44MTkyLTAuMzIwNDEtMy4yMzQ1LTAuMzQ5MzMtMTcuMDk1LTAuMzQ5MzMtMTYuMzI2IDAtMTYuMzY5IDAuMDAyMi0yMC40MzIgMS4wNDgtNi4wNzA0IDEuNTYyNi0xMS4yMjkgNC41NDMzLTE1LjgzNiA5LjE1MS01LjI4NzUgNS4yODc1LTguMjU3NSAxMC45NTMtOS44NTM2IDE4Ljc5Ni0wLjMwNDE2IDEuNDk0Ni0wLjMzMDg5IDUuMTkzOC0wLjM4NjYgNTMuNTA0bC0wLjA1OTggNTEuODk4aDkyLjk0MXoiIHN0cm9rZS13aWR0aD0iLjE4ODg5Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.96269" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="39" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yMW1tIiBoZWlnaHQ9IjE1Mi4xbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE4Mi4yMSAxNTIuMSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtOS4wMzA5IC02MS4xMDMpIj48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE1OS44NCAyMTEuNjQtMTQ5LjI0LTkwLjU0MSAxNzkuMDktMC4xMTEwNW0tMTQ5LjM2IDkwLjY1MiAxNDkuMzYtOTAuNjUybS04OS42LTU4LjMyMyA1OS43NTYgMTQ4Ljk4bS01OS43NTYtMTQ4Ljk4LTU5Ljc1NiAxNDguOTgiIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMy4xMjIxIi8+PGc+PGc+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtMzEzLjk4IDYxNS45OGMtNDIuMTcyLTI1LjYyMy02My43NDctMzkuNTQtNjMuNi00MS4wMjYgMC4xMjIyOC0xLjIzNyAxMC4wMjYtMjYuNjIxIDIyLjAwOC01Ni40MDlsMjEuNzg1LTU0LjE2IDE2OC41NyAwLjcwNTQ4IDQ0LjU3OCAxMTEuNDQtNC42MDc4IDIuODEyYy0zMC42NDUgMTguNzAyLTEyMC40NSA3My4wNjUtMTIyLjM4IDc0LjA4LTEuOTc4IDEuMDQxNi0xNi41NjgtNy4xOTA3LTY2LjM1OC0zNy40NDJ6IiBzdHJva2Utd2lkdGg9IjE2LjA4MSIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTUxOC4yMyA1NjkuMTVjLTAuMjQ5MDEtMC42MjgyNi05LjgwNzctMjQuNDY3LTIxLjI0Mi01Mi45NzUtMTEuNDM0LTI4LjUwOC0yMC43MTItNTEuOTEtMjAuNjE5LTUyLjAwMyAwLjA5MzctMC4wOTM3IDQ4Ljk4LTAuMTExNDMgMTA4LjY0LTAuMDM5NGwxMDguNDcgMC4xMzA5LTc3LjM3NyA0Ni45NDVjLTQyLjU1NyAyNS44Mi04MS44ODUgNDkuNjc2LTg3LjM5NiA1My4wMTUtOS41OTk0IDUuODE1OS0xMC4wMzggNi4wMjIzLTEwLjQ3MiA0LjkyNzl6IiBzdHJva2Utd2lkdGg9IjUuNjg1NiIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTI5OS40NyA0NDkuODZjMC4zODE4LTAuOTI3MjIgMTUuMzczLTM4LjI3OSAzMy4zMTMtODMuMDA1bDMyLjYxOS04MS4zMTkgMjUuODQ2IDAuMjc2NzMgMzIuODc4IDgxLjk0NWMxOC4wODMgNDUuMDcgMzMuMDEgODIuMzYgMzMuMTcxIDgyLjg2NiAwLjI3OTA3IDAuODc5MjgtMy4yOTQ3IDAuOTIwODctNzkuMTE0IDAuOTIwODdoLTc5LjQwN3oiIHN0cm9rZS13aWR0aD0iNS42ODU2Ii8+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtNDkwLjcxIDcyMy41MWMtNTQuNDkyLTMzLjA1OS05OS4wMS02MC40MTQtOTguOTMtNjAuNzg5IDAuMjU3NjctMS4xOTc4IDEyMC4xNy03My43MDkgMTIwLjgtNzMuMDQ4IDAuODg3MzEgMC45Mjg3MyA3Ny44ODQgMTkzLjI2IDc3LjUxNSAxOTMuNjMtMC4xNzE2MSAwLjE3MTM5LTQ0Ljg5Ni0yNi43MzYtOTkuMzg4LTU5Ljc5NXoiIHN0cm9rZS13aWR0aD0iMTEuMzcxIi8+PC9nPjxwYXRoIGQ9Im05OS45MzIgNzUuNDM1Yy0yLjc1NTMtMC4wMzkxOS0zLjU2NTYtMC4xMDA5My0zLjUwNDEtMC4yNjcwMiAxLjgzNDQtNC45NTcgMy40NTExLTkuMjAyOCAzLjU0MzEtOS4zMDUzIDAuMDY1OTMtMC4wNzMyOCAwLjg0Nzk5IDEuODIzMyAxLjczODIgNC4yMTQ2IDAuODkwMiAyLjM5MTMgMS43MTczIDQuNjA0NyAxLjgzNzkgNC45MTg2IDAuMTIwNzEgMC4zMTM5IDAuMTYzMDMgMC41NTI1OSAwLjA5NDEgMC41MzA0NC0wLjA2ODgtMC4wMjIxNy0xLjczODEtMC4wNjMyMy0zLjcwOTMtMC4wOTEyOHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIxLjg2MDMiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNDkuODkgNTE2Ljk4LTg2LjY5NC01Mi42MTQgMTA4LjI3LTAuMTg1ODNjNTkuNTQ5LTAuMTAyMiAxMDguMzgtMC4wNzU1IDEwOC41MiAwLjA1OTIgMC41MDI3MyAwLjUwMjczLTQxLjk2MiAxMDUuMzctNDIuNjY2IDEwNS4zNi0wLjQwMzQ3LTNlLTMgLTM5Ljc0Ni0yMy42ODItODcuNDI4LTUyLjYyeiIgc3Ryb2tlLXdpZHRoPSI4LjA0MDYiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNjcuNDYgNzgxLjE4YzAuMjg5OS0xLjE1OTMgMTcuNjUyLTQ0Ljg0NCAzOC41ODEtOTcuMDc3bDM4LjA1NC05NC45NyA0LjQ5MzcgMi44NTI5YzIuNDcxNSAxLjU2OTEgMjkuMzk3IDE3Ljg5NiA1OS44MzQgMzYuMjgzczU1LjM2MSAzMy44NjIgNTUuMzg2IDM0LjM5MWMwLjAyNTIgMC41MjgzOC00Mi43MDQgMjYuODgtOTQuOTU0IDU4LjU2LTUyLjI1IDMxLjY4LTk2LjU1NyA1OC42MDUtOTguNDYxIDU5LjgzNC0yLjkyMSAxLjg4NTktMy4zNzkyIDEuOTA1OC0yLjkzNDQgMC4xMjcwNnoiIHN0cm9rZS13aWR0aD0iMTYuMDgxIi8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTcyLjdtbSIgaGVpZ2h0PSIyMjEuMzhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgMTcyLjcgMjIxLjM4IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KIDxtZXRhZGF0YT4KICA8cmRmOlJERj4KICAgPGNjOldvcmsgcmRmOmFib3V0PSIiPgogICAgPGRjOmZvcm1hdD5pbWFnZS9zdmcreG1sPC9kYzpmb3JtYXQ+CiAgICA8ZGM6dHlwZSByZGY6cmVzb3VyY2U9Imh0dHA6Ly9wdXJsLm9yZy9kYy9kY21pdHlwZS9TdGlsbEltYWdlIi8+CiAgIDwvY2M6V29yaz4KICA8L3JkZjpSREY+CiA8L21ldGFkYXRhPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTE1Ljk0OSAtMzEuODY0KSI+CiAgPHBhdGggZD0ibTE2Ljc4NyAyNTIuMjdjLTAuNDYwOTMtMC40NjA5MS0wLjgzODA2LTIuNzMxMi0wLjgzODA2LTUuMDQ1IDAtMy44NzkyIDAuNzU5MDEtNC42ODcxIDkuNzQyNS0xMC4zNyAxOS43NDEtMTIuNDg3IDIzLjIwNC0xNS40MTQgMjIuMzgxLTE4LjkxOC0wLjQwOTYyLTEuNzQzOS0xLjA4OTQtNy43MjU1LTEuNTEwNi0xMy4yOTItMC44Nzg2NS0xMS42MTQgMS4yNzgxLTIxLjIxIDYuMzU5OS0yOC4yOTkgOC4xMi0xMS4zMjYgMTQuNTgxLTIzLjAzOCAxNy4yMDctMzEuMTkyIDEuNTg3NS00LjkyOTEgMy4zNDgzLTguNTAwMiAzLjkxMjctNy45MzU3IDEuMzIzMiAxLjMyMzIgNC43NTg0IDIwLjc5NyA0Ljc2MDYgMjYuOTg4IDkuNDdlLTQgMi42MTM2LTEuNDEyNSA4LjExMi0zLjE0MSAxMi4yMTktMy40MTI4IDguMTA4My00LjM2NzMgMjAuMTEzLTEuNTk5MiAyMC4xMTMgMC44NDg5NSAwIDUuODU2My00LjI4NzUgMTEuMTI4LTkuNTI3N2w5LjU4NC05LjUyNzctMy4xMjQ3LTcuNzM1OWMtMS43MTg2LTQuMjU0OC0zLjQwMTQtMTEuMTg0LTMuNzM5Ny0xNS4zOTctMC43NDM1My05LjI2MjggMS4xMjA0LTE0LjA0IDEyLjA5Ny0zMS4wMDcgNy4zOTAyLTExLjQyMyA3LjU4Ny0xMS45NTYgOS43NDM1LTI2LjQyOSAxLjIxMDYtOC4xMjQgMi42NDQzLTE0Ljc3MSAzLjE4NjItMTQuNzcxIDAuNTQxODIgMCAyLjk1NTQgNC43MzQxIDQuMzUwNiAxMC43OTRsMi4wMDEyIDguNjkxOGMxLjYyMjMgMi42OTU4LTEuNTg3OSAxNi43NjQtMS41ODc5IDE2Ljc2NC0xLjYyMzggOC4wNjQtMi45MjcgMTcuNzczLTIuODk2MiAyMS41NzYgMC4wNTgzIDcuMTk0MyAzLjEyMiAxNS4xMDYgNS44MzA3IDE1LjA1OCAzLjQ2NDctMC4wNjIyIDEyLjE2Ni01LjAyMyAxOC4xODItMTAuMzY3IDMuNTIzNS0zLjEyOTQgOS41OTAzLTYuODgxIDEzLjQ4Mi04LjMzNyA5LjQyMjUtMy41MjU0IDE2LjE5MS03LjA0NDcgMTguMTk3LTkuNDYxMiAwLjkwMjY2LTEuMDg3NiAyLjEzNzYtMS45Nzc1IDIuNzQ0NC0xLjk3NzUgMi4wNzU0IDAgMS4wOTI2IDMuMTQyNC0yLjc1MTkgOC43OTk3LTIuMTE0NCAzLjExMTMtNS45NzQgMTAuMTkxLTguNTc2OCAxNS43MzMtNS42NTA3IDEyLjAzMS0xNC42ODEgMjAuODI0LTI4LjQ4MSAyNy43MzItMTAuNTI5IDUuMjcwNi0xOS42NDMgNi41MDk1LTI5LjEwMyAzLjk1NjVsLTYuNTMzMy0xLjc2My05LjYyNTkgMTEuODE5Yy01LjI5NDIgNi41MDA2LTkuMzMwNyAxMi4xMTQtOC45Njk5IDEyLjQ3NSAwLjM2MDc5IDAuMzYwOCAyLjgyNCAwLjk0MyA1LjQ3MzkgMS4yOTM4IDQuMTIwNiAwLjU0NTUyIDUuNjc5LTAuMDIxNiAxMC43NjctMy45MTc5IDExLjYtOC44ODMgMTcuOTYtMTEuMjY2IDI5LjkzNS0xMS4yMTYgNS45MDg2IDAuMDI0NSAxMS43OTEgMC42MzEyNCAxMy4wNzIgMS4zNDgzIDIuMDQ0MiAxLjE0NCAxLjExMzIgMi4xNTc4LTcuNjAwMSA4LjI3NTItNS40NjE0IDMuODM0My0xNC4wMzMgMTEuNTAzLTE5LjA0OSAxNy4wNDItNy40OTk4IDguMjgyMi0xMC40MDIgMTAuNTU2LTE2LjM0MiAxMi44MDQtMTAuMTA0IDMuODI0Mi0yNS44MjggNC43MTY5LTM0LjI5NyAxLjk0N2wtNi40OTg0LTIuMTI1NS03LjA5ODggNi43NDMxYy0xMy42NTUgMTIuOTcxLTI3LjA3NCAyMC4xMzktMzAuNzc0IDE2LjQzOXptMTE0LjI5LTEyMC45M2MtMS4wNzY0LTEuNzQxNiA3LjQwNDYtMzAuMzg3IDExLjIzNC0zNy45NDMgNy44Mjg3LTE1LjQ0OSA0MS4yNTctNjEuNTQyIDQ0LjYzMy02MS41NDIgMi4zMDgxIDAgMi4yNzcyIDIuNDE0NS0wLjEzMDE0IDEwLjE2NS0xLjM3NzMgNC40MzQ0LTQuNDg5OCAxNS45MDktNi45MTY4IDI1LjQ5OS0yLjQyNjkgOS41OTAyLTUuNzQzOCAyMC4wNjQtNy4zNzA5IDIzLjI3NS02LjgyNDEgMTMuNDY3LTE3LjU3NSAyNC42MDgtMzkuMjQ1IDQwLjY2OS0wLjgzNTYzIDAuNjE5MzMtMS43Nzc2IDAuNTY2OTItMi4yMDM4LTAuMTIyNjJ6IiBzdHJva2Utd2lkdGg9IjEuMjU3MSIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.21258" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="40" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTc0LjAzbW0iIGhlaWdodD0iMjgyLjgzbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NC4wMyAyODIuODMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjAuODk4IC02LjgzOSkiPgogIDxwYXRoIGQ9Im00OS43NDYgMjc4LjkyYy01LjYxMjctNS44NTQtMTQuNC0xNC45ODMtMTkuNTI3LTIwLjI4Ni01LjEyNy01LjMwMzUtOS4zMjE4LTkuNzY0NS05LjMyMTgtOS45MTMzIDAtMC4xNDg4MyAxLjMwNDUtMi4yNzc2IDIuODk4OC00LjczMDUgMS41OTQzLTIuNDUzIDUuNjg0NS04Ljg3NTUgOS4wODk0LTE0LjI3MiA4LjkxNjQtMTQuMTMzIDI1Ljg0LTQwLjU0OSAzMi42MjUtNTAuOTI0IDEuNzk5Mi0yLjc1MTEgMy4yNzEyLTUuMTY1IDMuMjcxMi01LjM2NDFzMC4xNDEwNy0wLjQyMDk2IDAuMzEzNDktMC40OTI5MmMwLjE3MjQyLTAuMDcyIDIuOTg5NS00LjIyODkgNi4yNjAxLTkuMjM3N2w1Ljk0NjYtOS4xMDY5LTMuNjUxOC02LjM5NjhjLTIuMDA4NS0zLjUxODItNS43ODE4LTEwLjAzMS04LjM4NTEtMTQuNDcyLTExLjMxNy0xOS4zMDctMTQuMTk2LTI3LjE4Mi0xMy42OTYtMzcuNDU0IDAuODc5MTMtMTguMDU4IDExLjg4Mi01Ny44MyAyMC4xMjQtNzIuNzQ1IDEuOTk3Ny0zLjYxNDggOC4wMzQ1LTkuNTc3NiAxMi4xMTUtMTEuOTY2IDYuMTc0OC0zLjYxNDYgMTEuMjg5LTQuNzQxOCAyMS40MDEtNC43MTY5IDYuMTU4IDAuMDE1MTU4IDcuNzU4MyAwLjE0Nzc5IDEwLjUzMyAwLjg3Mjk3IDQuMTU3NyAxLjA4NjUgNy43MyAyLjcwNjUgMTAuNzk4IDQuODk2NSAyLjk2MjMgMi4xMTQ5IDcuODM4NCA3LjE2NDQgOS45Mzg3IDEwLjI5MiA4LjgzNSAxMy4xNTcgMTguNTI5IDM3Ljk4MSAyMi45MDIgNTguNjQ4IDEuMDgxOCA1LjExMjMgMS40NjY1IDEzLjE0MSAwLjc5NDM2IDE2LjU3OS0xLjU5NTIgOC4xNTg2LTYuNTEwNyAxOC40MTMtMTcuMDc2IDM1LjYyNC0yLjMzNSAzLjgwMzYtOS45MDY0IDE3LjA1LTExLjEyNyAxOS40NjdsLTAuODEyMzYgMS42MDg1IDEuNDMxIDIuMTIwMmMxMC43OTggMTUuOTk5IDU4LjI0MyA5MC4xOTYgNTguMzM5IDkxLjIzNSAwLjAyMjMgMC4yNDE1Ny03Ljk5NTggOC44OTE2LTE3LjgxOCAxOS4yMjJzLTE4LjU3IDE5LjU2Ny0xOS40MzggMjAuNTI1bC0xLjU3OTggMS43NDE4LTEzLjc5MS0yNS4wNzFjLTMxLjM3LTU3LjAyOS0zNC4wMjYtNjEuNzc5LTM0LjM2LTYxLjQ0NS0wLjE1OTM2IDAuMTU5MzYtMC43ODkyNSAxLjI1NTUtMS4zOTk4IDIuNDM1OC0wLjk1NTE5IDEuODQ2OC0xMC4yNzQgMTguNzU4LTI2LjkzMSA0OC44NzUtMi4zOTQ2IDQuMzI5Ni03LjcwOTcgMTMuOTk3LTExLjgxMSAyMS40ODRzLTcuNTQ1OCAxMy42MTItNy42NTM3IDEzLjYxMmMtMC4xMDc5NCAyLjhlLTQgLTQuNzg4NS00Ljc4OTEtMTAuNDAxLTEwLjY0M3ptNjguNjY1LTE4MS40N2M5LjA5NTYtMTUuMjUxIDE0LjA4OS0yNS4zMDQgMTguMzExLTM2Ljg2OCAxLjA2MTEtMi45MDU5IDEuMDk1Ni0zLjE3NTcgMC41MTkxNy00LjA1NTQtMS4yMjg1LTEuODc1LTMuNTEwNi00LjEyNTEtNS45NDYzLTUuODYzMi01LjUwMjUtMy45MjY1LTEyLjA1Ny01LjYxMy0yMS44MDUtNS42MTA0LTEwLjk3NCAwLjAwMjktMTkuMTkgMi4xNTEzLTI2LjE0MSA2LjgzNTUtNS4yODk5IDMuNTY0Ny01LjcwMzggNC4xNjM2LTQuNTkyNSA2LjY0NDcgMC4zMDQ2OCAwLjY4MDI0IDEuNTYzMyAzLjc5NzkgMi43OTY4IDYuOTI4IDQuNzI4NyAxMS45OTkgMTMuNTAyIDI4LjI1NSAyNC4wMjggNDQuNTI1bDIuNTI0NCAzLjkwMTcgMi45Mjg3LTQuNDkwNGMxLjYxMDgtMi40Njk3IDQuOTMwMi03Ljg0NjMgNy4zNzY0LTExLjk0OHoiIHN0cm9rZS13aWR0aD0iLjM5MjUiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.19965" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="41" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTcyLjdtbSIgaGVpZ2h0PSIyMjEuMzhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgMTcyLjcgMjIxLjM4IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KIDxtZXRhZGF0YT4KICA8cmRmOlJERj4KICAgPGNjOldvcmsgcmRmOmFib3V0PSIiPgogICAgPGRjOmZvcm1hdD5pbWFnZS9zdmcreG1sPC9kYzpmb3JtYXQ+CiAgICA8ZGM6dHlwZSByZGY6cmVzb3VyY2U9Imh0dHA6Ly9wdXJsLm9yZy9kYy9kY21pdHlwZS9TdGlsbEltYWdlIi8+CiAgIDwvY2M6V29yaz4KICA8L3JkZjpSREY+CiA8L21ldGFkYXRhPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTE1Ljk0OSAtMzEuODY0KSI+CiAgPHBhdGggZD0ibTE2Ljc4NyAyNTIuMjdjLTAuNDYwOTMtMC40NjA5MS0wLjgzODA2LTIuNzMxMi0wLjgzODA2LTUuMDQ1IDAtMy44NzkyIDAuNzU5MDEtNC42ODcxIDkuNzQyNS0xMC4zNyAxOS43NDEtMTIuNDg3IDIzLjIwNC0xNS40MTQgMjIuMzgxLTE4LjkxOC0wLjQwOTYyLTEuNzQzOS0xLjA4OTQtNy43MjU1LTEuNTEwNi0xMy4yOTItMC44Nzg2NS0xMS42MTQgMS4yNzgxLTIxLjIxIDYuMzU5OS0yOC4yOTkgOC4xMi0xMS4zMjYgMTQuNTgxLTIzLjAzOCAxNy4yMDctMzEuMTkyIDEuNTg3NS00LjkyOTEgMy4zNDgzLTguNTAwMiAzLjkxMjctNy45MzU3IDEuMzIzMiAxLjMyMzIgNC43NTg0IDIwLjc5NyA0Ljc2MDYgMjYuOTg4IDkuNDdlLTQgMi42MTM2LTEuNDEyNSA4LjExMi0zLjE0MSAxMi4yMTktMy40MTI4IDguMTA4My00LjM2NzMgMjAuMTEzLTEuNTk5MiAyMC4xMTMgMC44NDg5NSAwIDUuODU2My00LjI4NzUgMTEuMTI4LTkuNTI3N2w5LjU4NC05LjUyNzctMy4xMjQ3LTcuNzM1OWMtMS43MTg2LTQuMjU0OC0zLjQwMTQtMTEuMTg0LTMuNzM5Ny0xNS4zOTctMC43NDM1My05LjI2MjggMS4xMjA0LTE0LjA0IDEyLjA5Ny0zMS4wMDcgNy4zOTAyLTExLjQyMyA3LjU4Ny0xMS45NTYgOS43NDM1LTI2LjQyOSAxLjIxMDYtOC4xMjQgMi42NDQzLTE0Ljc3MSAzLjE4NjItMTQuNzcxIDAuNTQxODIgMCAyLjk1NTQgNC43MzQxIDQuMzUwNiAxMC43OTRsMi4wMDEyIDguNjkxOGMxLjYyMjMgMi42OTU4LTEuNTg3OSAxNi43NjQtMS41ODc5IDE2Ljc2NC0xLjYyMzggOC4wNjQtMi45MjcgMTcuNzczLTIuODk2MiAyMS41NzYgMC4wNTgzIDcuMTk0MyAzLjEyMiAxNS4xMDYgNS44MzA3IDE1LjA1OCAzLjQ2NDctMC4wNjIyIDEyLjE2Ni01LjAyMyAxOC4xODItMTAuMzY3IDMuNTIzNS0zLjEyOTQgOS41OTAzLTYuODgxIDEzLjQ4Mi04LjMzNyA5LjQyMjUtMy41MjU0IDE2LjE5MS03LjA0NDcgMTguMTk3LTkuNDYxMiAwLjkwMjY2LTEuMDg3NiAyLjEzNzYtMS45Nzc1IDIuNzQ0NC0xLjk3NzUgMi4wNzU0IDAgMS4wOTI2IDMuMTQyNC0yLjc1MTkgOC43OTk3LTIuMTE0NCAzLjExMTMtNS45NzQgMTAuMTkxLTguNTc2OCAxNS43MzMtNS42NTA3IDEyLjAzMS0xNC42ODEgMjAuODI0LTI4LjQ4MSAyNy43MzItMTAuNTI5IDUuMjcwNi0xOS42NDMgNi41MDk1LTI5LjEwMyAzLjk1NjVsLTYuNTMzMy0xLjc2My05LjYyNTkgMTEuODE5Yy01LjI5NDIgNi41MDA2LTkuMzMwNyAxMi4xMTQtOC45Njk5IDEyLjQ3NSAwLjM2MDc5IDAuMzYwOCAyLjgyNCAwLjk0MyA1LjQ3MzkgMS4yOTM4IDQuMTIwNiAwLjU0NTUyIDUuNjc5LTAuMDIxNiAxMC43NjctMy45MTc5IDExLjYtOC44ODMgMTcuOTYtMTEuMjY2IDI5LjkzNS0xMS4yMTYgNS45MDg2IDAuMDI0NSAxMS43OTEgMC42MzEyNCAxMy4wNzIgMS4zNDgzIDIuMDQ0MiAxLjE0NCAxLjExMzIgMi4xNTc4LTcuNjAwMSA4LjI3NTItNS40NjE0IDMuODM0My0xNC4wMzMgMTEuNTAzLTE5LjA0OSAxNy4wNDItNy40OTk4IDguMjgyMi0xMC40MDIgMTAuNTU2LTE2LjM0MiAxMi44MDQtMTAuMTA0IDMuODI0Mi0yNS44MjggNC43MTY5LTM0LjI5NyAxLjk0N2wtNi40OTg0LTIuMTI1NS03LjA5ODggNi43NDMxYy0xMy42NTUgMTIuOTcxLTI3LjA3NCAyMC4xMzktMzAuNzc0IDE2LjQzOXptMTE0LjI5LTEyMC45M2MtMS4wNzY0LTEuNzQxNiA3LjQwNDYtMzAuMzg3IDExLjIzNC0zNy45NDMgNy44Mjg3LTE1LjQ0OSA0MS4yNTctNjEuNTQyIDQ0LjYzMy02MS41NDIgMi4zMDgxIDAgMi4yNzcyIDIuNDE0NS0wLjEzMDE0IDEwLjE2NS0xLjM3NzMgNC40MzQ0LTQuNDg5OCAxNS45MDktNi45MTY4IDI1LjQ5OS0yLjQyNjkgOS41OTAyLTUuNzQzOCAyMC4wNjQtNy4zNzA5IDIzLjI3NS02LjgyNDEgMTMuNDY3LTE3LjU3NSAyNC42MDgtMzkuMjQ1IDQwLjY2OS0wLjgzNTYzIDAuNjE5MzMtMS43Nzc2IDAuNTY2OTItMi4yMDM4LTAuMTIyNjJ6IiBzdHJva2Utd2lkdGg9IjEuMjU3MSIvPgogPC9nPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.21258" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTk4LjUzbW0iIGhlaWdodD0iMTc2LjAybW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE5OC41MyAxNzYuMDIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMi4zMjQ1IC01Mi4wMjUpIj4KICA8cGF0aCBkPSJtMi4zMjQ1IDIxNC44MnYtMTMuMjIyaDI2LjgyM2wyZS0zIC01MC43NjVjOS40ZS00IC0zMi4zNTYgMC4wNzAyLTUxLjU1MiAwLjE5MDk2LTUyLjkzNyAyLjEzOC0yNC41MTYgMjEuNDI0LTQzLjcxIDQ1LjkzOC00NS43MTcgMS43MDM0LTAuMTM5NTEgMTAuNy0wLjE4MzI0IDI4LjAxLTAuMTM2MTMgMjcuODUzIDAuMDc1OCAyNi4zNDcgMC4wMTg3OSAzMS41OTQgMS4xOTU4IDE4Ljg4MSA0LjIzNDYgMzMuNTM0IDE4LjgyNyAzNy45MTkgMzcuNzYzIDAuMTY4NDMgMC43MjcyMyAwLjQ4NjY2IDIuMzg0OCAwLjcwNzE2IDMuNjgzNCAwLjQwMDg3IDIuMzYwOSAwLjQwMDkyIDIuMzY2NyAwLjQ2Mzg5IDU0LjYzN2wwLjA2MyA1Mi4yNzZoMjYuODE1djI2LjQ0NWgtMTk4LjUzem0xMzQuODctNjQuMTE5YzAtNTUuODAyIDAuMDU5OC01Mi43NC0xLjEyMTUtNTcuNDE3LTEuNTE5OC02LjAxNzYtNC41NDcxLTExLjI2LTkuMTcxOS0xNS44ODItNS4zNzg0LTUuMzc1OS0xMS40NDMtOC41MjI0LTE4Ljk4NS05Ljg1MDgtMS44MTkyLTAuMzIwNDEtMy4yMzQ1LTAuMzQ5MzMtMTcuMDk1LTAuMzQ5MzMtMTYuMzI2IDAtMTYuMzY5IDAuMDAyMi0yMC40MzIgMS4wNDgtNi4wNzA0IDEuNTYyNi0xMS4yMjkgNC41NDMzLTE1LjgzNiA5LjE1MS01LjI4NzUgNS4yODc1LTguMjU3NSAxMC45NTMtOS44NTM2IDE4Ljc5Ni0wLjMwNDE2IDEuNDk0Ni0wLjMzMDg5IDUuMTkzOC0wLjM4NjYgNTMuNTA0bC0wLjA1OTggNTEuODk4aDkyLjk0MXoiIHN0cm9rZS13aWR0aD0iLjE4ODg5Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.96269" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yMW1tIiBoZWlnaHQ9IjE1Mi4xbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE4Mi4yMSAxNTIuMSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtOS4wMzA5IC02MS4xMDMpIj48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCI+PHBhdGggZD0ibTE1OS44NCAyMTEuNjQtMTQ5LjI0LTkwLjU0MSAxNzkuMDktMC4xMTEwNW0tMTQ5LjM2IDkwLjY1MiAxNDkuMzYtOTAuNjUybS04OS42LTU4LjMyMyA1OS43NTYgMTQ4Ljk4bS01OS43NTYtMTQ4Ljk4LTU5Ljc1NiAxNDguOTgiIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMy4xMjIxIi8+PGc+PGc+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtMzEzLjk4IDYxNS45OGMtNDIuMTcyLTI1LjYyMy02My43NDctMzkuNTQtNjMuNi00MS4wMjYgMC4xMjIyOC0xLjIzNyAxMC4wMjYtMjYuNjIxIDIyLjAwOC01Ni40MDlsMjEuNzg1LTU0LjE2IDE2OC41NyAwLjcwNTQ4IDQ0LjU3OCAxMTEuNDQtNC42MDc4IDIuODEyYy0zMC42NDUgMTguNzAyLTEyMC40NSA3My4wNjUtMTIyLjM4IDc0LjA4LTEuOTc4IDEuMDQxNi0xNi41NjgtNy4xOTA3LTY2LjM1OC0zNy40NDJ6IiBzdHJva2Utd2lkdGg9IjE2LjA4MSIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTUxOC4yMyA1NjkuMTVjLTAuMjQ5MDEtMC42MjgyNi05LjgwNzctMjQuNDY3LTIxLjI0Mi01Mi45NzUtMTEuNDM0LTI4LjUwOC0yMC43MTItNTEuOTEtMjAuNjE5LTUyLjAwMyAwLjA5MzctMC4wOTM3IDQ4Ljk4LTAuMTExNDMgMTA4LjY0LTAuMDM5NGwxMDguNDcgMC4xMzA5LTc3LjM3NyA0Ni45NDVjLTQyLjU1NyAyNS44Mi04MS44ODUgNDkuNjc2LTg3LjM5NiA1My4wMTUtOS41OTk0IDUuODE1OS0xMC4wMzggNi4wMjIzLTEwLjQ3MiA0LjkyNzl6IiBzdHJva2Utd2lkdGg9IjUuNjg1NiIvPjxwYXRoIHRyYW5zZm9ybT0ic2NhbGUoLjI2NDU4KSIgZD0ibTI5OS40NyA0NDkuODZjMC4zODE4LTAuOTI3MjIgMTUuMzczLTM4LjI3OSAzMy4zMTMtODMuMDA1bDMyLjYxOS04MS4zMTkgMjUuODQ2IDAuMjc2NzMgMzIuODc4IDgxLjk0NWMxOC4wODMgNDUuMDcgMzMuMDEgODIuMzYgMzMuMTcxIDgyLjg2NiAwLjI3OTA3IDAuODc5MjgtMy4yOTQ3IDAuOTIwODctNzkuMTE0IDAuOTIwODdoLTc5LjQwN3oiIHN0cm9rZS13aWR0aD0iNS42ODU2Ii8+PHBhdGggdHJhbnNmb3JtPSJzY2FsZSguMjY0NTgpIiBkPSJtNDkwLjcxIDcyMy41MWMtNTQuNDkyLTMzLjA1OS05OS4wMS02MC40MTQtOTguOTMtNjAuNzg5IDAuMjU3NjctMS4xOTc4IDEyMC4xNy03My43MDkgMTIwLjgtNzMuMDQ4IDAuODg3MzEgMC45Mjg3MyA3Ny44ODQgMTkzLjI2IDc3LjUxNSAxOTMuNjMtMC4xNzE2MSAwLjE3MTM5LTQ0Ljg5Ni0yNi43MzYtOTkuMzg4LTU5Ljc5NXoiIHN0cm9rZS13aWR0aD0iMTEuMzcxIi8+PC9nPjxwYXRoIGQ9Im05OS45MzIgNzUuNDM1Yy0yLjc1NTMtMC4wMzkxOS0zLjU2NTYtMC4xMDA5My0zLjUwNDEtMC4yNjcwMiAxLjgzNDQtNC45NTcgMy40NTExLTkuMjAyOCAzLjU0MzEtOS4zMDUzIDAuMDY1OTMtMC4wNzMyOCAwLjg0Nzk5IDEuODIzMyAxLjczODIgNC4yMTQ2IDAuODkwMiAyLjM5MTMgMS43MTczIDQuNjA0NyAxLjgzNzkgNC45MTg2IDAuMTIwNzEgMC4zMTM5IDAuMTYzMDMgMC41NTI1OSAwLjA5NDEgMC41MzA0NC0wLjA2ODgtMC4wMjIxNy0xLjczODEtMC4wNjMyMy0zLjcwOTMtMC4wOTEyOHoiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIxLjg2MDMiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNDkuODkgNTE2Ljk4LTg2LjY5NC01Mi42MTQgMTA4LjI3LTAuMTg1ODNjNTkuNTQ5LTAuMTAyMiAxMDguMzgtMC4wNzU1IDEwOC41MiAwLjA1OTIgMC41MDI3MyAwLjUwMjczLTQxLjk2MiAxMDUuMzctNDIuNjY2IDEwNS4zNi0wLjQwMzQ3LTNlLTMgLTM5Ljc0Ni0yMy42ODItODcuNDI4LTUyLjYyeiIgc3Ryb2tlLXdpZHRoPSI4LjA0MDYiLz48cGF0aCB0cmFuc2Zvcm09InNjYWxlKC4yNjQ1OCkiIGQ9Im0xNjcuNDYgNzgxLjE4YzAuMjg5OS0xLjE1OTMgMTcuNjUyLTQ0Ljg0NCAzOC41ODEtOTcuMDc3bDM4LjA1NC05NC45NyA0LjQ5MzcgMi44NTI5YzIuNDcxNSAxLjU2OTEgMjkuMzk3IDE3Ljg5NiA1OS44MzQgMzYuMjgzczU1LjM2MSAzMy44NjIgNTUuMzg2IDM0LjM5MWMwLjAyNTIgMC41MjgzOC00Mi43MDQgMjYuODgtOTQuOTU0IDU4LjU2LTUyLjI1IDMxLjY4LTk2LjU1NyA1OC42MDUtOTguNDYxIDU5LjgzNC0yLjkyMSAxLjg4NTktMy4zNzkyIDEuOTA1OC0yLjkzNDQgMC4xMjcwNnoiIHN0cm9rZS13aWR0aD0iMTYuMDgxIi8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTc0LjAzbW0iIGhlaWdodD0iMjgyLjgzbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NC4wMyAyODIuODMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6Y2M9Imh0dHA6Ly9jcmVhdGl2ZWNvbW1vbnMub3JnL25zIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogPG1ldGFkYXRhPgogIDxyZGY6UkRGPgogICA8Y2M6V29yayByZGY6YWJvdXQ9IiI+CiAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgPC9jYzpXb3JrPgogIDwvcmRmOlJERj4KIDwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjAuODk4IC02LjgzOSkiPgogIDxwYXRoIGQ9Im00OS43NDYgMjc4LjkyYy01LjYxMjctNS44NTQtMTQuNC0xNC45ODMtMTkuNTI3LTIwLjI4Ni01LjEyNy01LjMwMzUtOS4zMjE4LTkuNzY0NS05LjMyMTgtOS45MTMzIDAtMC4xNDg4MyAxLjMwNDUtMi4yNzc2IDIuODk4OC00LjczMDUgMS41OTQzLTIuNDUzIDUuNjg0NS04Ljg3NTUgOS4wODk0LTE0LjI3MiA4LjkxNjQtMTQuMTMzIDI1Ljg0LTQwLjU0OSAzMi42MjUtNTAuOTI0IDEuNzk5Mi0yLjc1MTEgMy4yNzEyLTUuMTY1IDMuMjcxMi01LjM2NDFzMC4xNDEwNy0wLjQyMDk2IDAuMzEzNDktMC40OTI5MmMwLjE3MjQyLTAuMDcyIDIuOTg5NS00LjIyODkgNi4yNjAxLTkuMjM3N2w1Ljk0NjYtOS4xMDY5LTMuNjUxOC02LjM5NjhjLTIuMDA4NS0zLjUxODItNS43ODE4LTEwLjAzMS04LjM4NTEtMTQuNDcyLTExLjMxNy0xOS4zMDctMTQuMTk2LTI3LjE4Mi0xMy42OTYtMzcuNDU0IDAuODc5MTMtMTguMDU4IDExLjg4Mi01Ny44MyAyMC4xMjQtNzIuNzQ1IDEuOTk3Ny0zLjYxNDggOC4wMzQ1LTkuNTc3NiAxMi4xMTUtMTEuOTY2IDYuMTc0OC0zLjYxNDYgMTEuMjg5LTQuNzQxOCAyMS40MDEtNC43MTY5IDYuMTU4IDAuMDE1MTU4IDcuNzU4MyAwLjE0Nzc5IDEwLjUzMyAwLjg3Mjk3IDQuMTU3NyAxLjA4NjUgNy43MyAyLjcwNjUgMTAuNzk4IDQuODk2NSAyLjk2MjMgMi4xMTQ5IDcuODM4NCA3LjE2NDQgOS45Mzg3IDEwLjI5MiA4LjgzNSAxMy4xNTcgMTguNTI5IDM3Ljk4MSAyMi45MDIgNTguNjQ4IDEuMDgxOCA1LjExMjMgMS40NjY1IDEzLjE0MSAwLjc5NDM2IDE2LjU3OS0xLjU5NTIgOC4xNTg2LTYuNTEwNyAxOC40MTMtMTcuMDc2IDM1LjYyNC0yLjMzNSAzLjgwMzYtOS45MDY0IDE3LjA1LTExLjEyNyAxOS40NjdsLTAuODEyMzYgMS42MDg1IDEuNDMxIDIuMTIwMmMxMC43OTggMTUuOTk5IDU4LjI0MyA5MC4xOTYgNTguMzM5IDkxLjIzNSAwLjAyMjMgMC4yNDE1Ny03Ljk5NTggOC44OTE2LTE3LjgxOCAxOS4yMjJzLTE4LjU3IDE5LjU2Ny0xOS40MzggMjAuNTI1bC0xLjU3OTggMS43NDE4LTEzLjc5MS0yNS4wNzFjLTMxLjM3LTU3LjAyOS0zNC4wMjYtNjEuNzc5LTM0LjM2LTYxLjQ0NS0wLjE1OTM2IDAuMTU5MzYtMC43ODkyNSAxLjI1NTUtMS4zOTk4IDIuNDM1OC0wLjk1NTE5IDEuODQ2OC0xMC4yNzQgMTguNzU4LTI2LjkzMSA0OC44NzUtMi4zOTQ2IDQuMzI5Ni03LjcwOTcgMTMuOTk3LTExLjgxMSAyMS40ODRzLTcuNTQ1OCAxMy42MTItNy42NTM3IDEzLjYxMmMtMC4xMDc5NCAyLjhlLTQgLTQuNzg4NS00Ljc4OTEtMTAuNDAxLTEwLjY0M3ptNjguNjY1LTE4MS40N2M5LjA5NTYtMTUuMjUxIDE0LjA4OS0yNS4zMDQgMTguMzExLTM2Ljg2OCAxLjA2MTEtMi45MDU5IDEuMDk1Ni0zLjE3NTcgMC41MTkxNy00LjA1NTQtMS4yMjg1LTEuODc1LTMuNTEwNi00LjEyNTEtNS45NDYzLTUuODYzMi01LjUwMjUtMy45MjY1LTEyLjA1Ny01LjYxMy0yMS44MDUtNS42MTA0LTEwLjk3NCAwLjAwMjktMTkuMTkgMi4xNTEzLTI2LjE0MSA2LjgzNTUtNS4yODk5IDMuNTY0Ny01LjcwMzggNC4xNjM2LTQuNTkyNSA2LjY0NDcgMC4zMDQ2OCAwLjY4MDI0IDEuNTYzMyAzLjc5NzkgMi43OTY4IDYuOTI4IDQuNzI4NyAxMS45OTkgMTMuNTAyIDI4LjI1NSAyNC4wMjggNDQuNTI1bDIuNTI0NCAzLjkwMTcgMi45Mjg3LTQuNDkwNGMxLjYxMDgtMi40Njk3IDQuOTMwMi03Ljg0NjMgNy4zNzY0LTExLjk0OHoiIHN0cm9rZS13aWR0aD0iLjM5MjUiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.19965" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Кладбище" value="602050301" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Воинское кладбище, военное мемориальное кладбище" value="602050302" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Крематорий" value="602050303" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Историческое кладбище" value="602050304" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CEMET_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Общественное" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Вероисповедальное" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CEMET_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Кладбища смешанного и традиционного захоронения площадью от 20 до 40 га" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Кладбища смешанного и традиционного захоронения площадью от 10 до 20 га" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Кладбища смешанного и традиционного захоронения площадью 10 и менее га" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Сельское кладбище" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CEMET_WTYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное военное мемориальное кладбище" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Воинское кладбище" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Военное мемориальное кладбище" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CEMET_STAT" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Действующее" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Закрытое" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="HZRD_CLASS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="I класс опасности объекта" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="II класс опасности объекта" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="III класс опасности объекта" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="IV класс опасности объекта" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="V класс опасности объекта" value="5" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="AREA" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="CEMET_TYPE" index="6" name=""/>
    <alias field="CEMET_STYPE" index="7" name=""/>
    <alias field="CEMET_WTYPE" index="8" name=""/>
    <alias field="CEMET_STAT" index="9" name=""/>
    <alias field="HZRD_CLASS" index="10" name="Класс опасности объекта в соответствии с санитарной классификацией"/>
    <alias field="AREA" index="11" name="Площадь объекта, га"/>
    <alias field="EVENT_TIME" index="12" name=""/>
    <alias field="SOURCE" index="13" name="Источник данных"/>
    <alias field="NOTE" index="14" name="Примечание"/>
    <alias field="STATUS" index="15" name="Статус объекта"/>
    <alias field="REG_STATUS" index="16" name="Значение объекта"/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602050301'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="CEMET_TYPE" expression="if(&quot;CLASSID&quot; = '602050301', attribute('CEMET_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="CEMET_STYPE" expression="if(&quot;CLASSID&quot; = '602050301', attribute('CEMET_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="CEMET_WTYPE" expression="if(&quot;CLASSID&quot; = '602050302', attribute('CEMET_WTYPE'), NULL)" applyOnUpdate="1"/>
    <default field="CEMET_STAT" expression="if(&quot;CLASSID&quot; = '602050301' OR &quot;CLASSID&quot; = '602050302', attribute('CEMET_STAT'), NULL)" applyOnUpdate="1"/>
    <default field="HZRD_CLASS" expression="1" applyOnUpdate="0"/>
    <default field="AREA" expression="0" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="CEMET_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="CEMET_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="CEMET_WTYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="CEMET_STAT" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="HZRD_CLASS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="AREA" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="CEMET_TYPE" desc="Заполняется для объекта 602050301" exp="if(&quot;CLASSID&quot; = '602050301', &quot;CEMET_TYPE&quot; IS NOT NULL, &quot;CEMET_TYPE&quot; IS NULL)"/>
    <constraint field="CEMET_STYPE" desc="Заполняется для объекта 602050301" exp="if(&quot;CLASSID&quot; = '602050301', &quot;CEMET_STYPE&quot; IS NOT NULL, &quot;CEMET_STYPE&quot; IS NULL)"/>
    <constraint field="CEMET_WTYPE" desc="Заполняется для объекта 602050302" exp="if(&quot;CLASSID&quot; = '602050302', &quot;CEMET_WTYPE&quot; IS NOT NULL, &quot;CEMET_WTYPE&quot; IS NULL)"/>
    <constraint field="CEMET_STAT" desc="Заполняется для объектов 602050301, 602050302" exp="if(&quot;CLASSID&quot; = '602050301' OR &quot;CLASSID&quot; = '602050302', &quot;CEMET_STAT&quot; IS NOT NULL, &quot;CEMET_STAT&quot; IS NULL)"/>
    <constraint field="HZRD_CLASS" desc="" exp=""/>
    <constraint field="AREA" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="10" name="HZRD_CLASS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="11" name="AREA">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="15" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="16" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="14" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Условные атибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="&quot;CLASSID&quot; IN ('602050301', '602050302') OR &quot;STATUS&quot; IN (2, 3)">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Тип кладбища" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602050301'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="6" name="CEMET_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Классификация кладбища в соответствии с санитарной классификацией" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602050301'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="7" name="CEMET_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Тип воинского кладбища, военного мемориального кладбища" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602050302'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="8" name="CEMET_WTYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Статус кладбища" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; IN ('602050301', '602050302')">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="9" name="CEMET_STAT">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="12" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="AREA" editable="1"/>
    <field name="CEMET_STAT" editable="1"/>
    <field name="CEMET_STYPE" editable="1"/>
    <field name="CEMET_TYPE" editable="1"/>
    <field name="CEMET_WTYPE" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="HZRD_CLASS" editable="1"/>
    <field name="NAME" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="AREA"/>
    <field labelOnTop="1" name="CEMET_STAT"/>
    <field labelOnTop="1" name="CEMET_STYPE"/>
    <field labelOnTop="1" name="CEMET_TYPE"/>
    <field labelOnTop="1" name="CEMET_WTYPE"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="HZRD_CLASS"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="AREA" reuseLastValue="0"/>
    <field name="CEMET_STAT" reuseLastValue="0"/>
    <field name="CEMET_STYPE" reuseLastValue="0"/>
    <field name="CEMET_TYPE" reuseLastValue="0"/>
    <field name="CEMET_WTYPE" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="HZRD_CLASS" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
