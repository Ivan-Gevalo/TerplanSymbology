<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{8198accc-d366-480b-92bf-cb9f2128f5b5}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{3f505e28-8a73-4850-91f6-dcc0bf582b6e}">
        <rule label="Тематический парк" filter="&quot;CLASSID&quot; = '602010901'" symbol="1" key="{4ae8e57a-419a-4613-a209-f479a6a81da8}"/>
        <rule label="Парк культуры и отдыха" filter="&quot;CLASSID&quot; = '602010902'" symbol="2" key="{d60a1ba0-ed56-4404-b7ab-5fc83bbc7d28}"/>
        <rule label="Пешеходная зона" filter="&quot;CLASSID&quot; = '602010903'" symbol="3" key="{a71768e5-9399-450b-96f6-06c1db4be225}"/>
        <rule label="Благоустроенный пляж, место массовой околоводной рекреации" filter="&quot;CLASSID&quot; = '602010904'" symbol="4" key="{4b78ddf2-27a5-4d87-bdf5-578dacb22c01}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="5" key="{9bcbd357-a913-4d3e-a84f-f46954438ba9}">
        <rule label="Тематический парк" filter="&quot;CLASSID&quot; = '602010901'" symbol="6" key="{b50a2f75-146c-401e-906b-0d9a2205d406}"/>
        <rule label="Парк культуры и отдыха" filter="&quot;CLASSID&quot; = '602010902'" symbol="7" key="{b773fe67-7911-417c-83a3-592dfb8447b2}"/>
        <rule label="Пешеходная зона" filter="&quot;CLASSID&quot; = '602010903'" symbol="8" key="{f85a6b53-7700-4913-bdaa-45ea9cf804d1}"/>
        <rule label="Благоустроенный пляж, место массовой околоводной рекреации" filter="&quot;CLASSID&quot; = '602010904'" symbol="9" key="{872688cf-dce1-481c-962a-2eec11dabd1f}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="10" key="{bad5d794-d82b-403b-97bd-cb59f1501f9a}">
        <rule label="Тематический парк" filter="&quot;CLASSID&quot; = '602010901'" symbol="11" key="{b52697c6-a700-402f-9f8a-3c5d4b14830d}"/>
        <rule label="Парк культуры и отдыха" filter="&quot;CLASSID&quot; = '602010902'" symbol="12" key="{46103368-a3d6-4cda-9bca-dc5150a1f020}"/>
        <rule label="Пешеходная зона" filter="&quot;CLASSID&quot; = '602010903'" symbol="13" key="{78ec76f4-008a-4cf4-bd84-f2523908dd8a}"/>
        <rule label="Благоустроенный пляж, место массовой околоводной рекреации" filter="&quot;CLASSID&quot; = '602010904'" symbol="14" key="{0788f5a4-62c3-42c7-8f5f-1494ac65fcdb}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="15" key="{57074b1f-6516-4bbf-8d39-2d344fd0a1b7}">
        <rule label="Тематический парк" filter="&quot;CLASSID&quot; = '602010901'" symbol="16" key="{de663164-d602-4a8a-a884-e2f2a5bb9d57}"/>
        <rule label="Парк культуры и отдыха" filter="&quot;CLASSID&quot; = '602010902'" symbol="17" key="{b43d666f-ad8f-4873-9c49-8f3be567ad9e}"/>
        <rule label="Пешеходная зона" filter="&quot;CLASSID&quot; = '602010903'" symbol="18" key="{f66a1f8c-c9bb-4bc0-9cf4-7dbcd62a9887}"/>
        <rule label="Благоустроенный пляж, место массовой околоводной рекреации" filter="&quot;CLASSID&quot; = '602010904'" symbol="19" key="{c14da121-684d-4c40-89b0-43a3f4ac59cb}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="20" key="{84a1d6a2-13a2-4f89-80ad-3fe1ce03540d}">
        <rule label="Тематический парк" filter="&quot;CLASSID&quot; = '602010901'" symbol="21" key="{194ea329-5881-45ac-88e4-475cd1cd89b7}"/>
        <rule label="Парк культуры и отдыха" filter="&quot;CLASSID&quot; = '602010902'" symbol="22" key="{220aa695-6844-4e50-a22d-8e9f3786d7b2}"/>
        <rule label="Пешеходная зона" filter="&quot;CLASSID&quot; = '602010903'" symbol="23" key="{875c9643-e8be-4f0c-8e13-99e1b9372d4d}"/>
        <rule label="Благоустроенный пляж, место массовой околоводной рекреации" filter="&quot;CLASSID&quot; = '602010904'" symbol="24" key="{990fbfe3-0116-4b59-8153-ff6623daa618}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="25" key="{2fc165a7-5cb4-4c61-8e1c-c2f3d94089b5}">
        <rule label="Тематический парк" filter="&quot;CLASSID&quot; = '602010901'" symbol="26" key="{e1ea18e7-a1dd-40b2-ba96-c25825cf7543}"/>
        <rule label="Парк культуры и отдыха" filter="&quot;CLASSID&quot; = '602010902'" symbol="27" key="{3e4c8557-01d1-4a84-a1e1-156152923980}"/>
        <rule label="Пешеходная зона" filter="&quot;CLASSID&quot; = '602010903'" symbol="28" key="{6efcea77-0101-4003-b8f3-66e33b12dbaa}"/>
        <rule label="Благоустроенный пляж, место массовой околоводной рекреации" filter="&quot;CLASSID&quot; = '602010904'" symbol="29" key="{ef5be8ee-dd8b-43a9-8665-b264ccd172b6}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="30" key="{95bb7e66-d91d-4dce-924a-7e9c7ab23572}">
        <rule label="Тематический парк" filter="&quot;CLASSID&quot; = '602010901'" symbol="31" key="{e4fb1321-6afc-4e20-a9b7-3b5904ad4742}"/>
        <rule label="Парк культуры и отдыха" filter="&quot;CLASSID&quot; = '602010902'" symbol="32" key="{ada6d920-61d7-4bd8-a6d6-ccca0d517b6c}"/>
        <rule label="Пешеходная зона" filter="&quot;CLASSID&quot; = '602010903'" symbol="33" key="{98357499-00df-4b3d-873f-a3c34960af97}"/>
        <rule label="Благоустроенный пляж, место массовой околоводной рекреации" filter="&quot;CLASSID&quot; = '602010904'" symbol="34" key="{1dba5dc1-2760-4963-9456-4f865300f8e7}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты регионального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 2" symbol="35" key="{980dc243-b361-4517-8daf-08d32ac7cf03}">
        <rule label="Тематический парк" filter="&quot;CLASSID&quot; = '602010901'" symbol="36" key="{312f4158-8a97-4629-9f2b-b12eeec89282}"/>
        <rule label="Парк культуры и отдыха" filter="&quot;CLASSID&quot; = '602010902'" symbol="37" key="{f67ecaa3-b734-4edd-8aa9-513201964d17}"/>
        <rule label="Пешеходная зона" filter="&quot;CLASSID&quot; = '602010903'" symbol="38" key="{b92bf9ea-fe71-4d09-90c3-f10314c79d0c}"/>
        <rule label="Благоустроенный пляж, место массовой околоводной рекреации" filter="&quot;CLASSID&quot; = '602010904'" symbol="39" key="{5ae3b033-1247-4f56-a0c6-2d2ffb98ce44}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="40" key="{0d315591-8dd5-4933-98b0-958ae4a4f81e}">
        <rule label="Тематический парк" filter="&quot;CLASSID&quot; = '602010901'" symbol="41" key="{06243d1e-ae0a-4bd1-8149-1a96e4a2cc37}"/>
        <rule label="Парк культуры и отдыха" filter="&quot;CLASSID&quot; = '602010902'" symbol="42" key="{777abda1-ba25-4f01-b930-0583fd9a68b0}"/>
        <rule label="Пешеходная зона" filter="&quot;CLASSID&quot; = '602010903'" symbol="43" key="{85494c16-ef61-48ea-8f60-f61fdedf5335}"/>
        <rule label="Благоустроенный пляж, место массовой околоводной рекреации" filter="&quot;CLASSID&quot; = '602010904'" symbol="44" key="{138a6488-9158-4e2d-8814-412542ce5197}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="45" key="{84d7f2bc-d128-4004-958c-16254631a070}">
        <rule label="Тематический парк" filter="&quot;CLASSID&quot; = '602010901'" symbol="46" key="{4e647089-bf56-4a52-92db-1082d6a119f2}"/>
        <rule label="Парк культуры и отдыха" filter="&quot;CLASSID&quot; = '602010902'" symbol="47" key="{e8ad2eb8-e9c9-45a5-8f72-cfe049b4fb9e}"/>
        <rule label="Пешеходная зона" filter="&quot;CLASSID&quot; = '602010903'" symbol="48" key="{3a0a8c96-1808-44ae-9194-c311198f4fed}"/>
        <rule label="Благоустроенный пляж, место массовой околоводной рекреации" filter="&quot;CLASSID&quot; = '602010904'" symbol="49" key="{9c90cfc4-75a4-4063-9cd7-40b4832b50ea}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="50" key="{e1e8a607-0374-44e4-abfa-f8214a96b88f}">
        <rule label="Тематический парк" filter="&quot;CLASSID&quot; = '602010901'" symbol="51" key="{0521ceae-69b5-4881-88cf-8ef28db63f9a}"/>
        <rule label="Парк культуры и отдыха" filter="&quot;CLASSID&quot; = '602010902'" symbol="52" key="{50366af8-eb21-4756-bdad-05d5ae12074a}"/>
        <rule label="Пешеходная зона" filter="&quot;CLASSID&quot; = '602010903'" symbol="53" key="{64561bfb-2b02-4902-8922-c4fed84e566e}"/>
        <rule label="Благоустроенный пляж, место массовой околоводной рекреации" filter="&quot;CLASSID&quot; = '602010904'" symbol="54" key="{833ba072-ed9a-403d-924b-f82d71baec0e}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты федерального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 1" symbol="55" key="{a02efd10-cd53-4097-ae62-2394cabb6223}">
        <rule label="Тематический парк" filter="&quot;CLASSID&quot; = '602010901'" symbol="56" key="{2156d341-7663-48ce-9036-b8dbd9e71d70}"/>
        <rule label="Парк культуры и отдыха" filter="&quot;CLASSID&quot; = '602010902'" symbol="57" key="{45e29162-7f4e-4c80-9a60-6ef1415cb088}"/>
        <rule label="Пешеходная зона" filter="&quot;CLASSID&quot; = '602010903'" symbol="58" key="{318b6ae2-cd39-4148-a732-35c090859d68}"/>
        <rule label="Благоустроенный пляж, место массовой околоводной рекреации" filter="&quot;CLASSID&quot; = '602010904'" symbol="59" key="{28e93961-09ec-49c1-891e-7d1a472bbd4f}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,178,151,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk5LjA0OW1tIiBoZWlnaHQ9IjE2MC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5OS4wNDkgMTYwLjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0zOC4xNjkgMTcuNzk3YTI1LjYxNiAyNS42MTYgMCAwIDAtMjUuNjE3IDI1LjYxNyAyNS42MTYgMjUuNjE2IDAgMCAwIDI1LjYxNyAyNS42MTYgMjUuNjE2IDI1LjYxNiAwIDAgMCAyNS42MTYtMjUuNjE2IDI1LjYxNiAyNS42MTYgMCAwIDAtMC4wNTYzLTEuNjYyOWMtMi42NTQyIDEuMjg1Ny00LjgzNTQgMy40NzYzLTYuNzUgNS43MTk1LTEuMzc0NyAxLjYxMDYtMy4yOTM5IDUuNDMxNy0zLjI5MzkgNS40MzE3cy0zLjg0NDMgMi45ODEzLTUuNjYxNyAyLjExMjVjLTEuOTk1NS0wLjk1Mzk4LTIuMzk3Mi00LjEwMzItMi4wOTg2LTYuMjk0NyAwLjQ2Njg0LTMuNDI2MyAzLjE3NjMtNi4zNDU4IDUuNzk0LTguNjA1MiAyLjk3OS0yLjU3MTMgMTAuNjUtNS4wOTE4IDEwLjY1My01LjA5MjdhMjUuNjE2IDI1LjYxNiAwIDAgMC0xZS0zIC0zZS0zYy05ZS0zIC0wLjAxNzQtMy45MjUtNy40MTI2LTYuODgxMi0xMC4yODMtMS4yMDI1LTEuMTY3Ny0yLjY1MjYtMi4zMzQ0LTQuMjY4LTMuMzYyMWEyNS42MTYgMjUuNjE2IDAgMCAwLTEzLjA1Mi0zLjU3NjZ6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTc1LjM4NCAzOC42OGEyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NiAyMy42NjUgMjMuNjY1IDIzLjY2NSAwIDAgMCAyMy42NjYgMjMuNjY2IDIzLjY2NSAyMy42NjUgMCAwIDAgMjMuNjY1LTIzLjY2NiAyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NS0yMy42NjV6bTIuNTkxNiAxMS44ODdjMy41MTI2IDAuMDU3OSA4LjIwODIgMy43Njk0IDkuNDYyNSA2LjgxNjEgMS44NDkgNC40OTEyLTAuMzE2MDQgMTQuMTg0LTUuNTAzIDEzLjQ4OS0zLjYwNDYtMC40ODM0IDAuMzE1MzItNi43ODg0LTAuNzI3MDgtOS45ODQ0LTEuMTI2Mi0zLjQ1MjktOC41NTY1LTYuODM5Ny01LjgwMzMtOS40MTQ5IDAuNjk2NTMtMC42NTE0OSAxLjU4NzQtMC45MjE1NyAyLjU3MDktMC45MDUzN3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48cGF0aCBkPSJtNTMuNjg1IDUyLjkwMS01LjJlLTQgMWUtM3MtMy44NDQzIDIuOTgxMy01LjY2MTcgMi4xMTI1bC0yNC4wMzUgOS43MzIyIDQzLjg3MyAyMC4wMDN6Ii8+PHBhdGggZD0ibTcxLjEzNyAwYy0xMC4wNDMgMC4wMTIwMi0xOS4wODIgNi4wOTU0LTIyLjg3NSAxNS4zOTUgMi43OTkxIDAuNDYwNjcgNS41MDIyIDEuMzgzMSA3Ljk5OSAyLjcyOTUgMC4yMjgwOSAwLjExNzI2IDAuNDUzNjIgMC4yMzk0MSAwLjY3NjQ0IDAuMzY2MzkgMC4wODUzNSAwLjA0NTY4IDAuMTcwNDUgMC4wOTE4NSAwLjI1NTI4IDAuMTM4NDkgMC4xMzMxNyAwLjA4NDcyIDAuMjYzNDEgMC4xNzE4NSAwLjM5NDI5IDAuMjU4MzggMC42MDg2MiAwLjM4NDEgMS4xOTM1IDAuODA0NjUgMS43NTEzIDEuMjU5NCAwLjc2ODg2IDAuNjAwNzUgMS40ODE2IDEuMjIyMiAyLjEyMjQgMS44NDQzIDIuNzk3OCAyLjcxNjcgNi40MTM2IDkuNDA5MyA2LjgwNTMgMTAuMTQyIDIuMTk3Ni0wLjY2NTI0IDQuNDgwMy0xLjAwNzEgNi43NzYzLTEuMDE0OSA2LjMyNzMgMC4wMDYxIDEyLjM4OSAyLjU0NTggMTYuODMgNy4wNTE4IDIuNjAwNi0zLjk5OSAzLjk4OTUtOC42NjQ2IDMuOTk5Mi0xMy40MzUtNy42ZS01IC0xMy42NjEtMTEuMDc0LTI0LjczNS0yNC43MzUtMjQuNzM1em00Ljc5NjEgOC41NzA1YzQuMDgyNi0wLjA1NzEyIDguMTg0NyA0Ljk5OSA4Ljg5ODcgOS4wNzMzIDAuNzYxOTIgNC4zNDc4LTAuODU4NDcgMTEuNzY4LTUuMTc5NiAxMC44NjctMy4xNjM5LTAuNjU5OS0wLjYxMzY4LTUuNjgwNC0xLjUzNjgtOC43Nzc4LTAuODcyMi0yLjkyNjYtNC40MDYxLTQuOTI3MS00LjUwMS03Ljk3OTQtMC4wMzU3LTEuMTQ4NCAwLjM3NDY4LTIuODg4OSAxLjUwMzgtMy4xMDE2IDAuMjcwOTktMC4wNTEwNyAwLjU0Mjc3LTAuMDc3ODM5IDAuODE0OTQtMC4wODE2NDl6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTEyLjk3MSA2Mi41NzctMTIuOTcxIDk3LjUxOCA3MS4wOTItNjcuNDg5cy00Ljc4MDggMS40NDQtNi45MDk3IDAuNTQ2MjJjLTE2LjEwOS02Ljc5MzQtMzEuNDMtMTMuNzY4LTQ1Ljk1Mi0yMi45NzEtMi42MDM0LTEuNjQ5OC01LjI1OTYtNy42MDQyLTUuMjU5Ni03LjYwNDJ6bTM2LjIyMSAyOS4zMDVjMS42ODYgMC4wNDE5IDMuMDUxOSAxLjM5MTggMy4wOTU0IDMuMDk3NWwwLjAxNyAwLjY3OTU1YzAuMDQ0OSAxLjc2MDctMS4zMzYzIDMuMjE0My0zLjA5NyAzLjI1OTJsLTI2LjIxNiAwLjY2ODY5Yy0xLjc2MDcgMC4wNDQ5LTMuMjE0My0xLjMzNjMtMy4yNTkyLTMuMDk3bC0wLjAxNzUyLTAuNjgwMDZjLTAuMDQ0OS0xLjc2MDcgMS4zMzY4LTMuMjE0MyAzLjA5NzUtMy4yNTkybDI2LjIxNi0wLjY2ODE4YzAuMDU1LTFlLTMgMC4xMDk0My0yZS0zIDAuMTYzODItNS4xZS00em0tMTEuMjU3IDE1LjI5N2MxLjY4NDkgMC4wMjc4IDMuMDQxNSAxLjM2NiAzLjA3NDIgMy4wNzE2bDAuMDEyOSAwLjY4MDA2YzAuMDMzOCAxLjc2MDctMS4zNTYxIDMuMjI2LTMuMTE2MSAzLjI4NTZsLTE4LjE1OCAwLjYxNTQ3Yy0xLjc2IDAuMDU5Ni0zLjIwNDMtMS4zMDk5LTMuMjM4LTMuMDcwNmwtMC4wMTI5Mi0wLjY3OTU0Yy0wLjAzMzc5LTEuNzYwNyAxLjM1NjEtMy4yMjY1IDMuMTE2MS0zLjI4NjFsMTguMTU4LTAuNjE1NDZjMC4wNTUtMmUtMyAwLjEwOTQ2LTJlLTMgMC4xNjM4MS0xZS0zem0tMTUuNjIgMTQuMTk0YzEuNjQyNCA5ZS0zIDIuOTM5NCAxLjI4NDQgMi45NTQ5IDIuOTYyNmwwLjAwNjIgMC42Nzk1NGMwLjAxNjIyIDEuNzYwNy0xLjM4NDUgMy4yNzc5LTMuMTQwOSAzLjQwMTlsLTUuNDI5MSAwLjM4MzQ0Yy0xLjc1NjQgMC4xMjM5Ni0zLjE4MzYtMS4xOTM2LTMuMTk5OC0yLjk1NDNsLTAuMDA2Mi0wLjY4MDA2Yy0wLjAxNjIyLTEuNzYwNyAxLjM4NDUtMy4yNzc5IDMuMTQwOS0zLjQwMTlsNS40MjkxLTAuMzgyOTNjMC4wODIzMy02ZS0zIDAuMTY0MTctOWUtMyAwLjI0NDk1LThlLTN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.34102" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="229,182,54,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk5LjA0OW1tIiBoZWlnaHQ9IjE2MC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5OS4wNDkgMTYwLjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0zOC4xNjkgMTcuNzk3YTI1LjYxNiAyNS42MTYgMCAwIDAtMjUuNjE3IDI1LjYxNyAyNS42MTYgMjUuNjE2IDAgMCAwIDI1LjYxNyAyNS42MTYgMjUuNjE2IDI1LjYxNiAwIDAgMCAyNS42MTYtMjUuNjE2IDI1LjYxNiAyNS42MTYgMCAwIDAtMC4wNTYzLTEuNjYyOWMtMi42NTQyIDEuMjg1Ny00LjgzNTQgMy40NzYzLTYuNzUgNS43MTk1LTEuMzc0NyAxLjYxMDYtMy4yOTM5IDUuNDMxNy0zLjI5MzkgNS40MzE3cy0zLjg0NDMgMi45ODEzLTUuNjYxNyAyLjExMjVjLTEuOTk1NS0wLjk1Mzk4LTIuMzk3Mi00LjEwMzItMi4wOTg2LTYuMjk0NyAwLjQ2Njg0LTMuNDI2MyAzLjE3NjMtNi4zNDU4IDUuNzk0LTguNjA1MiAyLjk3OS0yLjU3MTMgMTAuNjUtNS4wOTE4IDEwLjY1My01LjA5MjdhMjUuNjE2IDI1LjYxNiAwIDAgMC0xZS0zIC0zZS0zYy05ZS0zIC0wLjAxNzQtMy45MjUtNy40MTI2LTYuODgxMi0xMC4yODMtMS4yMDI1LTEuMTY3Ny0yLjY1MjYtMi4zMzQ0LTQuMjY4LTMuMzYyMWEyNS42MTYgMjUuNjE2IDAgMCAwLTEzLjA1Mi0zLjU3NjZ6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTc1LjM4NCAzOC42OGEyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NiAyMy42NjUgMjMuNjY1IDIzLjY2NSAwIDAgMCAyMy42NjYgMjMuNjY2IDIzLjY2NSAyMy42NjUgMCAwIDAgMjMuNjY1LTIzLjY2NiAyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NS0yMy42NjV6bTIuNTkxNiAxMS44ODdjMy41MTI2IDAuMDU3OSA4LjIwODIgMy43Njk0IDkuNDYyNSA2LjgxNjEgMS44NDkgNC40OTEyLTAuMzE2MDQgMTQuMTg0LTUuNTAzIDEzLjQ4OS0zLjYwNDYtMC40ODM0IDAuMzE1MzItNi43ODg0LTAuNzI3MDgtOS45ODQ0LTEuMTI2Mi0zLjQ1MjktOC41NTY1LTYuODM5Ny01LjgwMzMtOS40MTQ5IDAuNjk2NTMtMC42NTE0OSAxLjU4NzQtMC45MjE1NyAyLjU3MDktMC45MDUzN3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48cGF0aCBkPSJtNTMuNjg1IDUyLjkwMS01LjJlLTQgMWUtM3MtMy44NDQzIDIuOTgxMy01LjY2MTcgMi4xMTI1bC0yNC4wMzUgOS43MzIyIDQzLjg3MyAyMC4wMDN6Ii8+PHBhdGggZD0ibTcxLjEzNyAwYy0xMC4wNDMgMC4wMTIwMi0xOS4wODIgNi4wOTU0LTIyLjg3NSAxNS4zOTUgMi43OTkxIDAuNDYwNjcgNS41MDIyIDEuMzgzMSA3Ljk5OSAyLjcyOTUgMC4yMjgwOSAwLjExNzI2IDAuNDUzNjIgMC4yMzk0MSAwLjY3NjQ0IDAuMzY2MzkgMC4wODUzNSAwLjA0NTY4IDAuMTcwNDUgMC4wOTE4NSAwLjI1NTI4IDAuMTM4NDkgMC4xMzMxNyAwLjA4NDcyIDAuMjYzNDEgMC4xNzE4NSAwLjM5NDI5IDAuMjU4MzggMC42MDg2MiAwLjM4NDEgMS4xOTM1IDAuODA0NjUgMS43NTEzIDEuMjU5NCAwLjc2ODg2IDAuNjAwNzUgMS40ODE2IDEuMjIyMiAyLjEyMjQgMS44NDQzIDIuNzk3OCAyLjcxNjcgNi40MTM2IDkuNDA5MyA2LjgwNTMgMTAuMTQyIDIuMTk3Ni0wLjY2NTI0IDQuNDgwMy0xLjAwNzEgNi43NzYzLTEuMDE0OSA2LjMyNzMgMC4wMDYxIDEyLjM4OSAyLjU0NTggMTYuODMgNy4wNTE4IDIuNjAwNi0zLjk5OSAzLjk4OTUtOC42NjQ2IDMuOTk5Mi0xMy40MzUtNy42ZS01IC0xMy42NjEtMTEuMDc0LTI0LjczNS0yNC43MzUtMjQuNzM1em00Ljc5NjEgOC41NzA1YzQuMDgyNi0wLjA1NzEyIDguMTg0NyA0Ljk5OSA4Ljg5ODcgOS4wNzMzIDAuNzYxOTIgNC4zNDc4LTAuODU4NDcgMTEuNzY4LTUuMTc5NiAxMC44NjctMy4xNjM5LTAuNjU5OS0wLjYxMzY4LTUuNjgwNC0xLjUzNjgtOC43Nzc4LTAuODcyMi0yLjkyNjYtNC40MDYxLTQuOTI3MS00LjUwMS03Ljk3OTQtMC4wMzU3LTEuMTQ4NCAwLjM3NDY4LTIuODg4OSAxLjUwMzgtMy4xMDE2IDAuMjcwOTktMC4wNTEwNyAwLjU0Mjc3LTAuMDc3ODM5IDAuODE0OTQtMC4wODE2NDl6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTEyLjk3MSA2Mi41NzctMTIuOTcxIDk3LjUxOCA3MS4wOTItNjcuNDg5cy00Ljc4MDggMS40NDQtNi45MDk3IDAuNTQ2MjJjLTE2LjEwOS02Ljc5MzQtMzEuNDMtMTMuNzY4LTQ1Ljk1Mi0yMi45NzEtMi42MDM0LTEuNjQ5OC01LjI1OTYtNy42MDQyLTUuMjU5Ni03LjYwNDJ6bTM2LjIyMSAyOS4zMDVjMS42ODYgMC4wNDE5IDMuMDUxOSAxLjM5MTggMy4wOTU0IDMuMDk3NWwwLjAxNyAwLjY3OTU1YzAuMDQ0OSAxLjc2MDctMS4zMzYzIDMuMjE0My0zLjA5NyAzLjI1OTJsLTI2LjIxNiAwLjY2ODY5Yy0xLjc2MDcgMC4wNDQ5LTMuMjE0My0xLjMzNjMtMy4yNTkyLTMuMDk3bC0wLjAxNzUyLTAuNjgwMDZjLTAuMDQ0OS0xLjc2MDcgMS4zMzY4LTMuMjE0MyAzLjA5NzUtMy4yNTkybDI2LjIxNi0wLjY2ODE4YzAuMDU1LTFlLTMgMC4xMDk0My0yZS0zIDAuMTYzODItNS4xZS00em0tMTEuMjU3IDE1LjI5N2MxLjY4NDkgMC4wMjc4IDMuMDQxNSAxLjM2NiAzLjA3NDIgMy4wNzE2bDAuMDEyOSAwLjY4MDA2YzAuMDMzOCAxLjc2MDctMS4zNTYxIDMuMjI2LTMuMTE2MSAzLjI4NTZsLTE4LjE1OCAwLjYxNTQ3Yy0xLjc2IDAuMDU5Ni0zLjIwNDMtMS4zMDk5LTMuMjM4LTMuMDcwNmwtMC4wMTI5Mi0wLjY3OTU0Yy0wLjAzMzc5LTEuNzYwNyAxLjM1NjEtMy4yMjY1IDMuMTE2MS0zLjI4NjFsMTguMTU4LTAuNjE1NDZjMC4wNTUtMmUtMyAwLjEwOTQ2LTJlLTMgMC4xNjM4MS0xZS0zem0tMTUuNjIgMTQuMTk0YzEuNjQyNCA5ZS0zIDIuOTM5NCAxLjI4NDQgMi45NTQ5IDIuOTYyNmwwLjAwNjIgMC42Nzk1NGMwLjAxNjIyIDEuNzYwNy0xLjM4NDUgMy4yNzc5LTMuMTQwOSAzLjQwMTlsLTUuNDI5MSAwLjM4MzQ0Yy0xLjc1NjQgMC4xMjM5Ni0zLjE4MzYtMS4xOTM2LTMuMTk5OC0yLjk1NDNsLTAuMDA2Mi0wLjY4MDA2Yy0wLjAxNjIyLTEuNzYwNyAxLjM4NDUtMy4yNzc5IDMuMTQwOS0zLjQwMTlsNS40MjkxLTAuMzgyOTNjMC4wODIzMy02ZS0zIDAuMTY0MTctOWUtMyAwLjI0NDk1LThlLTN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.34102" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS42Mm1tIiBoZWlnaHQ9IjE0OS41Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDkuNjIgMTQ5LjU2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxjaXJjbGUgY3g9IjE0MS44MSIgY3k9Ijc1LjYyIiByPSI2LjI1MzkiLz48Y2lyY2xlIGN4PSI3LjgwMzkiIGN5PSI3NS42MiIgcj0iNi4yNTM5Ii8+PHJlY3QgeD0iMy4xNzAyZS03IiB5PSIxMzcuNDkiIHdpZHRoPSIxNDkuNjIiIGhlaWdodD0iMTIuMDY5IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjIuNTc1MiIvPjwvZz48Y2lyY2xlIGN4PSI3NC44MDkiIGN5PSIxMy45NjEiIHI9IjEwLjUxMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjYuOSIvPjxwYXRoIGQ9Im02OS4xNDggMjIuNDY3LTU3LjQ3NCA0OS4xOTIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI0LjUiLz48Zz48cGF0aCBkPSJtNjYuNTk3IDIwLjg4LTQ3LjkyIDEwOC44OSA5LjY4NDctMWUtNSA0Ni4zNDktMTA1LjMyeiIvPjxwYXRoIGQ9Im0xNy43NDcgNzUuMzI2YzAuMDA3MyAwLjA5NzkgMC4wMTMxNiAwLjE5NTk1IDAuMDE3NTcgMC4yOTQwNCA0ZS01IDUuNTAwOC00LjQ1OTMgOS45NjAyLTkuOTYwMSA5Ljk2MDEtMC42NTQ4OS0yZS0zIC0xLjMwOC0wLjA2OS0xLjk0OTgtMC4xOTk0NyAyLjE0NDggNC42Mzk3IDUuNTM4OCAxMS42MzEgOC4yMzgzIDE1LjU2MSAyLjM1NzcgMy40MzI5IDguMzQxMSA5LjMwMTIgOC4zNDExIDkuMzAxMmwwLjM1MTQgMC4xMTYyNyAxNS40MTgtMzUuMDM0em0zNi41NDggOC4xNDI3LTE0LjMzNiAzMi41NzdzMi40MDIyIDEuMjI1OCAzLjcwMjEgMS4yMjU4aDMxLjE0OHYtMjkuMjc5Yy04LjEyNzItMmUtMyAtMTUuNzU4LTEuNjg1LTIwLjUxNS00LjUyMzh6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iLjIiLz48cGF0aCBkPSJtMTMuMzQ5IDY3LjUxM3Y1LjQ0NjJoMjUuODk2bDIuMzk2OC01LjQ0NjJ6Ii8+PHBhdGggZD0ibTU3LjgwNCA3NS4zMjYtMi41NzMxIDUuMzkxNGM1LjE2MDcgMi4wODY1IDEyLjIxNSAzLjI2MjEgMTkuNTc4IDMuMjYyOHYtNi4zMDM1Yy02LjE3MjItMmUtMyAtMTQuMzQ2LTEuNjM4My0xNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTgwLjQ3IDIyLjQ2NyA1Ny40NzQgNDkuMTkyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNC41Ii8+PGc+PHBhdGggZD0ibTgzLjAyMSAyMC44OCA0Ny45MiAxMDguODktOS42ODQ3LTFlLTUgLTQ2LjM0OS0xMDUuMzJ6Ii8+PHBhdGggZD0ibTExMS40MiA3NS4zMjYgMTUuNDE4IDM1LjAzNCAwLjM1MTM5LTAuMTE2MjdzNS45ODM0LTUuODY4NCA4LjM0MTEtOS4zMDEyYzIuNjk5NC0zLjkzMDQgNi4wOTM1LTEwLjkyMiA4LjIzODItMTUuNTYxLTAuNjQxNzcgMC4xMzA0Ny0xLjI5NDkgMC4xOTc0Ny0xLjk0OTggMC4xOTk0Ny01LjUwMDggM2UtNSAtOS45NjAyLTQuNDU5My05Ljk2MDEtOS45NjAxIDRlLTMgLTAuMDk4MDkgMC4wMTA2LTAuMTk2MTQgMC4wMTc2LTAuMjk0MDR6bS0xNi4wOTIgOC4xNDI3Yy00Ljc1NjYgMi44Mzg3LTEyLjM4NyA0LjUyMTgtMjAuNTE1IDQuNTIzOHYyOS4yNzloMzEuMTQ4YzEuMjk5OSAwIDMuNzAyMS0xLjIyNTggMy43MDIxLTEuMjI1OHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMiIvPjxwYXRoIGQ9Im0xMzYuMjcgNjcuNTEzdjUuNDQ2MmgtMjUuODk2bC0yLjM5NjgtNS40NDYyeiIvPjxwYXRoIGQ9Im05MS44MTQgNzUuMzI2IDIuNTczMSA1LjM5MTRjLTUuMTYwNyAyLjA4NjUtMTIuMjE1IDMuMjYyMS0xOS41NzggMy4yNjI4di02LjMwMzVjNi4xNzIyLTJlLTMgMTQuMzQ2LTEuNjM4MyAxNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTc0LjgwOSAxMTcuMzd2LTI5LjQ4MiIgZmlsbD0iIzAwZiIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEuNDciLz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg1LjAyM21tIiBoZWlnaHQ9IjE1Mi43M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4NS4wMjMgMTUyLjczIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im01OCA1OS44ODJ2MTYuMzc0bDguOTcyMSA5LjAyNjNjMy4zNjI3IDMuMzgzMSA3Ljg5NTUgNC4yOTIyIDEwLjE2MyAyLjAzODEgMi4yNjc3LTIuMjU0MSAxLjM4NjEtNi43OTI1LTEuOTc2Ni0xMC4xNzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjQ2NSIvPjxwYXRoIGQ9Im0zNi4zNTUgOTIuNTdjLTIuNjIyNSA0LjUyNjctNS42NDA2IDkuNzQyNC05LjIwNjcgMTUuOTIyLTguMzM2MiAxNC40NDUtMTUuNDA4IDI2LjYzNS0xNS43MTYgMjcuMDktMC45MDA0IDEuMzMyOS0xLjI2MjUgMi41MzU4LTEuMjYwNCA0LjE4NzggMC4wMDE2IDEuMDc5OCAwLjA3MjAxIDEuNTkzNCAwLjMxMzE2IDIuMjgzMSAxLjA3NzkgMy4wODI2IDMuODYyNSA1LjA1NDIgNy4wOTQxIDUuMDIyNCAwLjUxMzQ3LTVlLTMgMS4yNzgyLTAuMTAwNTIgMS42OTk2LTAuMjEyMzkgMS43MDc4LTAuNDUzMzEgMy4xMTE3LTEuNDUxOCA0LjM3MTgtMy4xMDk0IDAuNDMzMzctMC41NzAwNiAxNC45MTktMjUuNTU5IDIzLjQyNS00MC4zMzV6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zOC4wMjQgMjguMzUxYy0wLjU2MjQzLTAuMDA4NS0xLjA5MzQgMC4wMjQ2Ni0xLjQ4MjEgMC4xMDY0NS0wLjQyMTQ2IDAuMDg4NjgtMS4xMTA3IDAuMzAzMjYtMS41MzIyIDAuNDc2OTctMC40MjE0NiAwLjE3MzcxLTYuNDk1OSAzLjYzNTctMTMuNDk4IDcuNjkzMS0xMC40NDQgNi4wNTE1LTEyLjk3NSA3LjUxNTItMTQuMDE3IDguNjcyM2wxNi4wNDQgMC4wMDE2djMuNTYzNmMzLjAwMS0xLjcyODYgNS40Njk5LTMuMDk4OSA1LjU0NTQtMy4wNzM3IDAuMDk2NjEgMC4wMzIyIDAuMTY1OTQgNS40Njk2IDAuMjEyOTEgMTYuNjg1bDAuMDY5NzYgMTYuNjM4IDAuMzI3MTEgMC42MjY4NGMwLjA2NjMzIDAuMTI3MTIgMC42NzQ2MSAwLjc4NDA3IDEuNTg0NCAxLjczNjNsMC4wNjU2My0wLjA2NTExIDI1Ljg5OCAyNi4yMDUgMC4wMjQ4MSAwLjAyNTMgNC42MjYxIDQuNjMwNyA0LjM5MyAxNy42OTVjMy41NjM4IDE0LjM1NSA0LjQ4MzQgMTcuODc5IDQuODczMSAxOC42NzUgMC45NjU3NiAxLjk3MjUgMy4yMDcyIDMuNjI1OCA1LjM3MDIgMy45NjE1IDEuMTQ1OCAwLjE3Nzc4IDEuNTI3NCAwLjE2Njk4IDIuNjQ3NC0wLjA3NTQgMS40NDM4LTAuMzEyNjggMi41OTAyLTAuOTU0OTMgMy42OTQzLTIuMDY5MSAxLjA0OTctMS4wNTkzIDEuNTk3Ni0yLjAwMzMgMS45NDM2LTMuMzQ5NyAwLjQ3MjYxLTEuODM5IDAuNjQ4MzgtMS4wMTY3LTUuMjM3NC0yNC41MDctMi45OTgtMTEuOTY1LTUuNTc1Ni0yMi4xLTUuNzI4My0yMi41MjEtMC4yNTg4Ny0wLjcxNDQtMC45NDY5NS0xLjQzNjItMTAuMTU0LTEwLjY2bC02LjYwOTQtNi42MjE5LTMuMjY2NS0zLjI3MjctMC4yMTcwNC0wLjIxNzA0di0yMi40NTFjLTcuOGUtNCAtMC43ODAyLTAuMDAyNS00LjM3MTMgMC04LjQwODN2LTExLjIyN2MtMC4wODMxNy0xLjM2ODctMS4wMzc1LTEuNzcyMS02Ljg4NDMtNS4xNDctMi45NDgtMS43MDE2LTUuNzA2Ny0zLjIxNzEtNi4xMzA0LTMuMzY4My0wLjYwMDAyLTAuMjE0MDgtMS42MjUyLTAuMzQ0MzktMi41NjI2LTAuMzU4NjN6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zMS4wNjEgOC45MjM5Yy0wLjQyMTk0IDQuMDMyMyAxLjA1OTUgOC4zMjA2IDMuMzI4NCAxMS42OTkgMS4zNDk2IDIuMDA5MyAzLjMxMDIgMy41OTUzIDUuMzI0NCA0LjkzNzUgMi42NDQ4IDEuNzYyNSA1LjU2NzIgMy4yOTE1IDguNjc1MiAzLjk1NjcgMS4xODk2IDAuMjU0NTggMi41MDE2IDAuMzgwMjIgMy42NDk0LTAuMDIyOCAxLjQzNDQtMC41MDM2NSAyLjcyNjEtMS41Njk0IDMuNTc3NC0yLjgyOSAxLjI5NzQtMS45MTk1IDEuNjg4OC00LjM2NjEgMS45Njc3LTYuNjY2IDAuMjg4NjYtMi4zNzk5IDAuMzUxOS00Ljg4NTctMC4zMjgxMi03LjE4NDctMC44MjI3NS0yLjc4MTUtMi40Mjk0LTUuMzc3NS00LjM5NTctNy41MDk5LTEuODEyMi0xLjk2NTMtNC4wNDAyLTMuNzM2My02LjU3MDctNC41OTgzLTIuMzY2Ny0wLjgwNjItNS4wNjA0LTAuOTIzMDQtNy40OTI5LTAuMzQ1LTEuNzAyIDAuNDA0NDMtMy4zNTMzIDEuMzIwNC00LjU3MzUgMi41NzM5LTEuNTc0NiAxLjYxNzYtMi45MjY2IDMuNzQzOC0zLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTE5Ljc4OCA0MC4xOGMtMTAuNzY4IDMuNjUwOC0xMS4zNSAzLjk0OTYtMTIuNTggNS40NjEyLTEuMzI1OCAxLjYyOTUtMS4zNjcgMC45NTI4Mi00LjU1NDYgMTYuOTU3IDAgMC0yLjIyNTcgOS4yMzYtMi42NTA2IDE0LjM4NC0wLjAyMzk1NSAwLjI5MDI0IDAuMTYwMiAwLjg1ODg2IDAuMTYwMiAwLjg1ODg2IDAuMjA5NDIgMS4xMjMzIDEuMTgxNSAyLjcwOTIgMi4wODYyIDMuNDAzNCAyLjc5MzggMi4xNDM3IDYuNTU4NyAxLjQ4MzMgOC41NTM1LTEuNTAwNyAwLjQxOTg1LTAuNjI4MDUgMC40NjgyNS0wLjgzNjk1IDMuMDgwOS0xMy40MzZsMi42NTM2LTEyLjc5OCAwLjE5MTItMC43MTI2MiA5Ljg1MzktNS42NjQ0IDEuMDk0My01LjM2MDJ6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.00612" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwNC42Mm1tIiBoZWlnaHQ9IjE4My44N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDQuNjIgMTgzLjg3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC43NjIyMyAtNTUuOTg0KSI+PHBhdGggZD0ibTE1NC45NyA3NS45OWExMTMuMjIgMTEzLjIyIDAgMCAwLTE1NS43MyAyNi40OTIgMzkuMjYzIDM5LjI2MyAwIDAgMSA1Mi44NTctNy42NDg3IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MiAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NTY0IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MSAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NDkyIDM5LjI2MyAzOS4yNjMgMCAwIDEgMTAuNTcxIDUzLjc3MyAxMTMuMjIgMTEzLjIyIDAgMCAwLTI5LjQxNS0xNTYuNjV6Ii8+PHBhdGggZD0ibTE2LjM5NCAyMDUuOTRzLTIuMjQyNyA1LjczNTctMi4yODM3IDguNzQ5N2MtMC4wNjY3MiA0LjkwNzYgMC4yMDA2NiAxMC41NjIgMy4zMjk4IDE0LjM0MyAzLjEzMjEgMy43ODQ4IDguNTcgNi4xMzc3IDEzLjQ3OSA1Ljk1OTUgNC41MTkzLTAuMTY0MDYgOS4yMDgtMi43OTY0IDExLjk3OC02LjM3MTIgNDYuMjYyLTU5LjcwNiAxMjMuNzItMTY3LjI2IDEyMy43Mi0xNjcuMjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="225,89,137,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk5LjA0OW1tIiBoZWlnaHQ9IjE2MC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5OS4wNDkgMTYwLjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0zOC4xNjkgMTcuNzk3YTI1LjYxNiAyNS42MTYgMCAwIDAtMjUuNjE3IDI1LjYxNyAyNS42MTYgMjUuNjE2IDAgMCAwIDI1LjYxNyAyNS42MTYgMjUuNjE2IDI1LjYxNiAwIDAgMCAyNS42MTYtMjUuNjE2IDI1LjYxNiAyNS42MTYgMCAwIDAtMC4wNTYzLTEuNjYyOWMtMi42NTQyIDEuMjg1Ny00LjgzNTQgMy40NzYzLTYuNzUgNS43MTk1LTEuMzc0NyAxLjYxMDYtMy4yOTM5IDUuNDMxNy0zLjI5MzkgNS40MzE3cy0zLjg0NDMgMi45ODEzLTUuNjYxNyAyLjExMjVjLTEuOTk1NS0wLjk1Mzk4LTIuMzk3Mi00LjEwMzItMi4wOTg2LTYuMjk0NyAwLjQ2Njg0LTMuNDI2MyAzLjE3NjMtNi4zNDU4IDUuNzk0LTguNjA1MiAyLjk3OS0yLjU3MTMgMTAuNjUtNS4wOTE4IDEwLjY1My01LjA5MjdhMjUuNjE2IDI1LjYxNiAwIDAgMC0xZS0zIC0zZS0zYy05ZS0zIC0wLjAxNzQtMy45MjUtNy40MTI2LTYuODgxMi0xMC4yODMtMS4yMDI1LTEuMTY3Ny0yLjY1MjYtMi4zMzQ0LTQuMjY4LTMuMzYyMWEyNS42MTYgMjUuNjE2IDAgMCAwLTEzLjA1Mi0zLjU3NjZ6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTc1LjM4NCAzOC42OGEyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NiAyMy42NjUgMjMuNjY1IDIzLjY2NSAwIDAgMCAyMy42NjYgMjMuNjY2IDIzLjY2NSAyMy42NjUgMCAwIDAgMjMuNjY1LTIzLjY2NiAyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NS0yMy42NjV6bTIuNTkxNiAxMS44ODdjMy41MTI2IDAuMDU3OSA4LjIwODIgMy43Njk0IDkuNDYyNSA2LjgxNjEgMS44NDkgNC40OTEyLTAuMzE2MDQgMTQuMTg0LTUuNTAzIDEzLjQ4OS0zLjYwNDYtMC40ODM0IDAuMzE1MzItNi43ODg0LTAuNzI3MDgtOS45ODQ0LTEuMTI2Mi0zLjQ1MjktOC41NTY1LTYuODM5Ny01LjgwMzMtOS40MTQ5IDAuNjk2NTMtMC42NTE0OSAxLjU4NzQtMC45MjE1NyAyLjU3MDktMC45MDUzN3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48cGF0aCBkPSJtNTMuNjg1IDUyLjkwMS01LjJlLTQgMWUtM3MtMy44NDQzIDIuOTgxMy01LjY2MTcgMi4xMTI1bC0yNC4wMzUgOS43MzIyIDQzLjg3MyAyMC4wMDN6Ii8+PHBhdGggZD0ibTcxLjEzNyAwYy0xMC4wNDMgMC4wMTIwMi0xOS4wODIgNi4wOTU0LTIyLjg3NSAxNS4zOTUgMi43OTkxIDAuNDYwNjcgNS41MDIyIDEuMzgzMSA3Ljk5OSAyLjcyOTUgMC4yMjgwOSAwLjExNzI2IDAuNDUzNjIgMC4yMzk0MSAwLjY3NjQ0IDAuMzY2MzkgMC4wODUzNSAwLjA0NTY4IDAuMTcwNDUgMC4wOTE4NSAwLjI1NTI4IDAuMTM4NDkgMC4xMzMxNyAwLjA4NDcyIDAuMjYzNDEgMC4xNzE4NSAwLjM5NDI5IDAuMjU4MzggMC42MDg2MiAwLjM4NDEgMS4xOTM1IDAuODA0NjUgMS43NTEzIDEuMjU5NCAwLjc2ODg2IDAuNjAwNzUgMS40ODE2IDEuMjIyMiAyLjEyMjQgMS44NDQzIDIuNzk3OCAyLjcxNjcgNi40MTM2IDkuNDA5MyA2LjgwNTMgMTAuMTQyIDIuMTk3Ni0wLjY2NTI0IDQuNDgwMy0xLjAwNzEgNi43NzYzLTEuMDE0OSA2LjMyNzMgMC4wMDYxIDEyLjM4OSAyLjU0NTggMTYuODMgNy4wNTE4IDIuNjAwNi0zLjk5OSAzLjk4OTUtOC42NjQ2IDMuOTk5Mi0xMy40MzUtNy42ZS01IC0xMy42NjEtMTEuMDc0LTI0LjczNS0yNC43MzUtMjQuNzM1em00Ljc5NjEgOC41NzA1YzQuMDgyNi0wLjA1NzEyIDguMTg0NyA0Ljk5OSA4Ljg5ODcgOS4wNzMzIDAuNzYxOTIgNC4zNDc4LTAuODU4NDcgMTEuNzY4LTUuMTc5NiAxMC44NjctMy4xNjM5LTAuNjU5OS0wLjYxMzY4LTUuNjgwNC0xLjUzNjgtOC43Nzc4LTAuODcyMi0yLjkyNjYtNC40MDYxLTQuOTI3MS00LjUwMS03Ljk3OTQtMC4wMzU3LTEuMTQ4NCAwLjM3NDY4LTIuODg4OSAxLjUwMzgtMy4xMDE2IDAuMjcwOTktMC4wNTEwNyAwLjU0Mjc3LTAuMDc3ODM5IDAuODE0OTQtMC4wODE2NDl6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTEyLjk3MSA2Mi41NzctMTIuOTcxIDk3LjUxOCA3MS4wOTItNjcuNDg5cy00Ljc4MDggMS40NDQtNi45MDk3IDAuNTQ2MjJjLTE2LjEwOS02Ljc5MzQtMzEuNDMtMTMuNzY4LTQ1Ljk1Mi0yMi45NzEtMi42MDM0LTEuNjQ5OC01LjI1OTYtNy42MDQyLTUuMjU5Ni03LjYwNDJ6bTM2LjIyMSAyOS4zMDVjMS42ODYgMC4wNDE5IDMuMDUxOSAxLjM5MTggMy4wOTU0IDMuMDk3NWwwLjAxNyAwLjY3OTU1YzAuMDQ0OSAxLjc2MDctMS4zMzYzIDMuMjE0My0zLjA5NyAzLjI1OTJsLTI2LjIxNiAwLjY2ODY5Yy0xLjc2MDcgMC4wNDQ5LTMuMjE0My0xLjMzNjMtMy4yNTkyLTMuMDk3bC0wLjAxNzUyLTAuNjgwMDZjLTAuMDQ0OS0xLjc2MDcgMS4zMzY4LTMuMjE0MyAzLjA5NzUtMy4yNTkybDI2LjIxNi0wLjY2ODE4YzAuMDU1LTFlLTMgMC4xMDk0My0yZS0zIDAuMTYzODItNS4xZS00em0tMTEuMjU3IDE1LjI5N2MxLjY4NDkgMC4wMjc4IDMuMDQxNSAxLjM2NiAzLjA3NDIgMy4wNzE2bDAuMDEyOSAwLjY4MDA2YzAuMDMzOCAxLjc2MDctMS4zNTYxIDMuMjI2LTMuMTE2MSAzLjI4NTZsLTE4LjE1OCAwLjYxNTQ3Yy0xLjc2IDAuMDU5Ni0zLjIwNDMtMS4zMDk5LTMuMjM4LTMuMDcwNmwtMC4wMTI5Mi0wLjY3OTU0Yy0wLjAzMzc5LTEuNzYwNyAxLjM1NjEtMy4yMjY1IDMuMTE2MS0zLjI4NjFsMTguMTU4LTAuNjE1NDZjMC4wNTUtMmUtMyAwLjEwOTQ2LTJlLTMgMC4xNjM4MS0xZS0zem0tMTUuNjIgMTQuMTk0YzEuNjQyNCA5ZS0zIDIuOTM5NCAxLjI4NDQgMi45NTQ5IDIuOTYyNmwwLjAwNjIgMC42Nzk1NGMwLjAxNjIyIDEuNzYwNy0xLjM4NDUgMy4yNzc5LTMuMTQwOSAzLjQwMTlsLTUuNDI5MSAwLjM4MzQ0Yy0xLjc1NjQgMC4xMjM5Ni0zLjE4MzYtMS4xOTM2LTMuMTk5OC0yLjk1NDNsLTAuMDA2Mi0wLjY4MDA2Yy0wLjAxNjIyLTEuNzYwNyAxLjM4NDUtMy4yNzc5IDMuMTQwOS0zLjQwMTlsNS40MjkxLTAuMzgyOTNjMC4wODIzMy02ZS0zIDAuMTY0MTctOWUtMyAwLjI0NDk1LThlLTN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.34102" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS42Mm1tIiBoZWlnaHQ9IjE0OS41Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDkuNjIgMTQ5LjU2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxjaXJjbGUgY3g9IjE0MS44MSIgY3k9Ijc1LjYyIiByPSI2LjI1MzkiLz48Y2lyY2xlIGN4PSI3LjgwMzkiIGN5PSI3NS42MiIgcj0iNi4yNTM5Ii8+PHJlY3QgeD0iMy4xNzAyZS03IiB5PSIxMzcuNDkiIHdpZHRoPSIxNDkuNjIiIGhlaWdodD0iMTIuMDY5IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjIuNTc1MiIvPjwvZz48Y2lyY2xlIGN4PSI3NC44MDkiIGN5PSIxMy45NjEiIHI9IjEwLjUxMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjYuOSIvPjxwYXRoIGQ9Im02OS4xNDggMjIuNDY3LTU3LjQ3NCA0OS4xOTIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI0LjUiLz48Zz48cGF0aCBkPSJtNjYuNTk3IDIwLjg4LTQ3LjkyIDEwOC44OSA5LjY4NDctMWUtNSA0Ni4zNDktMTA1LjMyeiIvPjxwYXRoIGQ9Im0xNy43NDcgNzUuMzI2YzAuMDA3MyAwLjA5NzkgMC4wMTMxNiAwLjE5NTk1IDAuMDE3NTcgMC4yOTQwNCA0ZS01IDUuNTAwOC00LjQ1OTMgOS45NjAyLTkuOTYwMSA5Ljk2MDEtMC42NTQ4OS0yZS0zIC0xLjMwOC0wLjA2OS0xLjk0OTgtMC4xOTk0NyAyLjE0NDggNC42Mzk3IDUuNTM4OCAxMS42MzEgOC4yMzgzIDE1LjU2MSAyLjM1NzcgMy40MzI5IDguMzQxMSA5LjMwMTIgOC4zNDExIDkuMzAxMmwwLjM1MTQgMC4xMTYyNyAxNS40MTgtMzUuMDM0em0zNi41NDggOC4xNDI3LTE0LjMzNiAzMi41NzdzMi40MDIyIDEuMjI1OCAzLjcwMjEgMS4yMjU4aDMxLjE0OHYtMjkuMjc5Yy04LjEyNzItMmUtMyAtMTUuNzU4LTEuNjg1LTIwLjUxNS00LjUyMzh6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iLjIiLz48cGF0aCBkPSJtMTMuMzQ5IDY3LjUxM3Y1LjQ0NjJoMjUuODk2bDIuMzk2OC01LjQ0NjJ6Ii8+PHBhdGggZD0ibTU3LjgwNCA3NS4zMjYtMi41NzMxIDUuMzkxNGM1LjE2MDcgMi4wODY1IDEyLjIxNSAzLjI2MjEgMTkuNTc4IDMuMjYyOHYtNi4zMDM1Yy02LjE3MjItMmUtMyAtMTQuMzQ2LTEuNjM4My0xNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTgwLjQ3IDIyLjQ2NyA1Ny40NzQgNDkuMTkyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNC41Ii8+PGc+PHBhdGggZD0ibTgzLjAyMSAyMC44OCA0Ny45MiAxMDguODktOS42ODQ3LTFlLTUgLTQ2LjM0OS0xMDUuMzJ6Ii8+PHBhdGggZD0ibTExMS40MiA3NS4zMjYgMTUuNDE4IDM1LjAzNCAwLjM1MTM5LTAuMTE2MjdzNS45ODM0LTUuODY4NCA4LjM0MTEtOS4zMDEyYzIuNjk5NC0zLjkzMDQgNi4wOTM1LTEwLjkyMiA4LjIzODItMTUuNTYxLTAuNjQxNzcgMC4xMzA0Ny0xLjI5NDkgMC4xOTc0Ny0xLjk0OTggMC4xOTk0Ny01LjUwMDggM2UtNSAtOS45NjAyLTQuNDU5My05Ljk2MDEtOS45NjAxIDRlLTMgLTAuMDk4MDkgMC4wMTA2LTAuMTk2MTQgMC4wMTc2LTAuMjk0MDR6bS0xNi4wOTIgOC4xNDI3Yy00Ljc1NjYgMi44Mzg3LTEyLjM4NyA0LjUyMTgtMjAuNTE1IDQuNTIzOHYyOS4yNzloMzEuMTQ4YzEuMjk5OSAwIDMuNzAyMS0xLjIyNTggMy43MDIxLTEuMjI1OHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMiIvPjxwYXRoIGQ9Im0xMzYuMjcgNjcuNTEzdjUuNDQ2MmgtMjUuODk2bC0yLjM5NjgtNS40NDYyeiIvPjxwYXRoIGQ9Im05MS44MTQgNzUuMzI2IDIuNTczMSA1LjM5MTRjLTUuMTYwNyAyLjA4NjUtMTIuMjE1IDMuMjYyMS0xOS41NzggMy4yNjI4di02LjMwMzVjNi4xNzIyLTJlLTMgMTQuMzQ2LTEuNjM4MyAxNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTc0LjgwOSAxMTcuMzd2LTI5LjQ4MiIgZmlsbD0iIzAwZiIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEuNDciLz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg1LjAyM21tIiBoZWlnaHQ9IjE1Mi43M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4NS4wMjMgMTUyLjczIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im01OCA1OS44ODJ2MTYuMzc0bDguOTcyMSA5LjAyNjNjMy4zNjI3IDMuMzgzMSA3Ljg5NTUgNC4yOTIyIDEwLjE2MyAyLjAzODEgMi4yNjc3LTIuMjU0MSAxLjM4NjEtNi43OTI1LTEuOTc2Ni0xMC4xNzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjQ2NSIvPjxwYXRoIGQ9Im0zNi4zNTUgOTIuNTdjLTIuNjIyNSA0LjUyNjctNS42NDA2IDkuNzQyNC05LjIwNjcgMTUuOTIyLTguMzM2MiAxNC40NDUtMTUuNDA4IDI2LjYzNS0xNS43MTYgMjcuMDktMC45MDA0IDEuMzMyOS0xLjI2MjUgMi41MzU4LTEuMjYwNCA0LjE4NzggMC4wMDE2IDEuMDc5OCAwLjA3MjAxIDEuNTkzNCAwLjMxMzE2IDIuMjgzMSAxLjA3NzkgMy4wODI2IDMuODYyNSA1LjA1NDIgNy4wOTQxIDUuMDIyNCAwLjUxMzQ3LTVlLTMgMS4yNzgyLTAuMTAwNTIgMS42OTk2LTAuMjEyMzkgMS43MDc4LTAuNDUzMzEgMy4xMTE3LTEuNDUxOCA0LjM3MTgtMy4xMDk0IDAuNDMzMzctMC41NzAwNiAxNC45MTktMjUuNTU5IDIzLjQyNS00MC4zMzV6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zOC4wMjQgMjguMzUxYy0wLjU2MjQzLTAuMDA4NS0xLjA5MzQgMC4wMjQ2Ni0xLjQ4MjEgMC4xMDY0NS0wLjQyMTQ2IDAuMDg4NjgtMS4xMTA3IDAuMzAzMjYtMS41MzIyIDAuNDc2OTctMC40MjE0NiAwLjE3MzcxLTYuNDk1OSAzLjYzNTctMTMuNDk4IDcuNjkzMS0xMC40NDQgNi4wNTE1LTEyLjk3NSA3LjUxNTItMTQuMDE3IDguNjcyM2wxNi4wNDQgMC4wMDE2djMuNTYzNmMzLjAwMS0xLjcyODYgNS40Njk5LTMuMDk4OSA1LjU0NTQtMy4wNzM3IDAuMDk2NjEgMC4wMzIyIDAuMTY1OTQgNS40Njk2IDAuMjEyOTEgMTYuNjg1bDAuMDY5NzYgMTYuNjM4IDAuMzI3MTEgMC42MjY4NGMwLjA2NjMzIDAuMTI3MTIgMC42NzQ2MSAwLjc4NDA3IDEuNTg0NCAxLjczNjNsMC4wNjU2My0wLjA2NTExIDI1Ljg5OCAyNi4yMDUgMC4wMjQ4MSAwLjAyNTMgNC42MjYxIDQuNjMwNyA0LjM5MyAxNy42OTVjMy41NjM4IDE0LjM1NSA0LjQ4MzQgMTcuODc5IDQuODczMSAxOC42NzUgMC45NjU3NiAxLjk3MjUgMy4yMDcyIDMuNjI1OCA1LjM3MDIgMy45NjE1IDEuMTQ1OCAwLjE3Nzc4IDEuNTI3NCAwLjE2Njk4IDIuNjQ3NC0wLjA3NTQgMS40NDM4LTAuMzEyNjggMi41OTAyLTAuOTU0OTMgMy42OTQzLTIuMDY5MSAxLjA0OTctMS4wNTkzIDEuNTk3Ni0yLjAwMzMgMS45NDM2LTMuMzQ5NyAwLjQ3MjYxLTEuODM5IDAuNjQ4MzgtMS4wMTY3LTUuMjM3NC0yNC41MDctMi45OTgtMTEuOTY1LTUuNTc1Ni0yMi4xLTUuNzI4My0yMi41MjEtMC4yNTg4Ny0wLjcxNDQtMC45NDY5NS0xLjQzNjItMTAuMTU0LTEwLjY2bC02LjYwOTQtNi42MjE5LTMuMjY2NS0zLjI3MjctMC4yMTcwNC0wLjIxNzA0di0yMi40NTFjLTcuOGUtNCAtMC43ODAyLTAuMDAyNS00LjM3MTMgMC04LjQwODN2LTExLjIyN2MtMC4wODMxNy0xLjM2ODctMS4wMzc1LTEuNzcyMS02Ljg4NDMtNS4xNDctMi45NDgtMS43MDE2LTUuNzA2Ny0zLjIxNzEtNi4xMzA0LTMuMzY4My0wLjYwMDAyLTAuMjE0MDgtMS42MjUyLTAuMzQ0MzktMi41NjI2LTAuMzU4NjN6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zMS4wNjEgOC45MjM5Yy0wLjQyMTk0IDQuMDMyMyAxLjA1OTUgOC4zMjA2IDMuMzI4NCAxMS42OTkgMS4zNDk2IDIuMDA5MyAzLjMxMDIgMy41OTUzIDUuMzI0NCA0LjkzNzUgMi42NDQ4IDEuNzYyNSA1LjU2NzIgMy4yOTE1IDguNjc1MiAzLjk1NjcgMS4xODk2IDAuMjU0NTggMi41MDE2IDAuMzgwMjIgMy42NDk0LTAuMDIyOCAxLjQzNDQtMC41MDM2NSAyLjcyNjEtMS41Njk0IDMuNTc3NC0yLjgyOSAxLjI5NzQtMS45MTk1IDEuNjg4OC00LjM2NjEgMS45Njc3LTYuNjY2IDAuMjg4NjYtMi4zNzk5IDAuMzUxOS00Ljg4NTctMC4zMjgxMi03LjE4NDctMC44MjI3NS0yLjc4MTUtMi40Mjk0LTUuMzc3NS00LjM5NTctNy41MDk5LTEuODEyMi0xLjk2NTMtNC4wNDAyLTMuNzM2My02LjU3MDctNC41OTgzLTIuMzY2Ny0wLjgwNjItNS4wNjA0LTAuOTIzMDQtNy40OTI5LTAuMzQ1LTEuNzAyIDAuNDA0NDMtMy4zNTMzIDEuMzIwNC00LjU3MzUgMi41NzM5LTEuNTc0NiAxLjYxNzYtMi45MjY2IDMuNzQzOC0zLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTE5Ljc4OCA0MC4xOGMtMTAuNzY4IDMuNjUwOC0xMS4zNSAzLjk0OTYtMTIuNTggNS40NjEyLTEuMzI1OCAxLjYyOTUtMS4zNjcgMC45NTI4Mi00LjU1NDYgMTYuOTU3IDAgMC0yLjIyNTcgOS4yMzYtMi42NTA2IDE0LjM4NC0wLjAyMzk1NSAwLjI5MDI0IDAuMTYwMiAwLjg1ODg2IDAuMTYwMiAwLjg1ODg2IDAuMjA5NDIgMS4xMjMzIDEuMTgxNSAyLjcwOTIgMi4wODYyIDMuNDAzNCAyLjc5MzggMi4xNDM3IDYuNTU4NyAxLjQ4MzMgOC41NTM1LTEuNTAwNyAwLjQxOTg1LTAuNjI4MDUgMC40NjgyNS0wLjgzNjk1IDMuMDgwOS0xMy40MzZsMi42NTM2LTEyLjc5OCAwLjE5MTItMC43MTI2MiA5Ljg1MzktNS42NjQ0IDEuMDk0My01LjM2MDJ6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.00612" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwNC42Mm1tIiBoZWlnaHQ9IjE4My44N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDQuNjIgMTgzLjg3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC43NjIyMyAtNTUuOTg0KSI+PHBhdGggZD0ibTE1NC45NyA3NS45OWExMTMuMjIgMTEzLjIyIDAgMCAwLTE1NS43MyAyNi40OTIgMzkuMjYzIDM5LjI2MyAwIDAgMSA1Mi44NTctNy42NDg3IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MiAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NTY0IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MSAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NDkyIDM5LjI2MyAzOS4yNjMgMCAwIDEgMTAuNTcxIDUzLjc3MyAxMTMuMjIgMTEzLjIyIDAgMCAwLTI5LjQxNS0xNTYuNjV6Ii8+PHBhdGggZD0ibTE2LjM5NCAyMDUuOTRzLTIuMjQyNyA1LjczNTctMi4yODM3IDguNzQ5N2MtMC4wNjY3MiA0LjkwNzYgMC4yMDA2NiAxMC41NjIgMy4zMjk4IDE0LjM0MyAzLjEzMjEgMy43ODQ4IDguNTcgNi4xMzc3IDEzLjQ3OSA1Ljk1OTUgNC41MTkzLTAuMTY0MDYgOS4yMDgtMi43OTY0IDExLjk3OC02LjM3MTIgNDYuMjYyLTU5LjcwNiAxMjMuNzItMTY3LjI2IDEyMy43Mi0xNjcuMjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS42Mm1tIiBoZWlnaHQ9IjE0OS41Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDkuNjIgMTQ5LjU2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxjaXJjbGUgY3g9IjE0MS44MSIgY3k9Ijc1LjYyIiByPSI2LjI1MzkiLz48Y2lyY2xlIGN4PSI3LjgwMzkiIGN5PSI3NS42MiIgcj0iNi4yNTM5Ii8+PHJlY3QgeD0iMy4xNzAyZS03IiB5PSIxMzcuNDkiIHdpZHRoPSIxNDkuNjIiIGhlaWdodD0iMTIuMDY5IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjIuNTc1MiIvPjwvZz48Y2lyY2xlIGN4PSI3NC44MDkiIGN5PSIxMy45NjEiIHI9IjEwLjUxMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjYuOSIvPjxwYXRoIGQ9Im02OS4xNDggMjIuNDY3LTU3LjQ3NCA0OS4xOTIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI0LjUiLz48Zz48cGF0aCBkPSJtNjYuNTk3IDIwLjg4LTQ3LjkyIDEwOC44OSA5LjY4NDctMWUtNSA0Ni4zNDktMTA1LjMyeiIvPjxwYXRoIGQ9Im0xNy43NDcgNzUuMzI2YzAuMDA3MyAwLjA5NzkgMC4wMTMxNiAwLjE5NTk1IDAuMDE3NTcgMC4yOTQwNCA0ZS01IDUuNTAwOC00LjQ1OTMgOS45NjAyLTkuOTYwMSA5Ljk2MDEtMC42NTQ4OS0yZS0zIC0xLjMwOC0wLjA2OS0xLjk0OTgtMC4xOTk0NyAyLjE0NDggNC42Mzk3IDUuNTM4OCAxMS42MzEgOC4yMzgzIDE1LjU2MSAyLjM1NzcgMy40MzI5IDguMzQxMSA5LjMwMTIgOC4zNDExIDkuMzAxMmwwLjM1MTQgMC4xMTYyNyAxNS40MTgtMzUuMDM0em0zNi41NDggOC4xNDI3LTE0LjMzNiAzMi41NzdzMi40MDIyIDEuMjI1OCAzLjcwMjEgMS4yMjU4aDMxLjE0OHYtMjkuMjc5Yy04LjEyNzItMmUtMyAtMTUuNzU4LTEuNjg1LTIwLjUxNS00LjUyMzh6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iLjIiLz48cGF0aCBkPSJtMTMuMzQ5IDY3LjUxM3Y1LjQ0NjJoMjUuODk2bDIuMzk2OC01LjQ0NjJ6Ii8+PHBhdGggZD0ibTU3LjgwNCA3NS4zMjYtMi41NzMxIDUuMzkxNGM1LjE2MDcgMi4wODY1IDEyLjIxNSAzLjI2MjEgMTkuNTc4IDMuMjYyOHYtNi4zMDM1Yy02LjE3MjItMmUtMyAtMTQuMzQ2LTEuNjM4My0xNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTgwLjQ3IDIyLjQ2NyA1Ny40NzQgNDkuMTkyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNC41Ii8+PGc+PHBhdGggZD0ibTgzLjAyMSAyMC44OCA0Ny45MiAxMDguODktOS42ODQ3LTFlLTUgLTQ2LjM0OS0xMDUuMzJ6Ii8+PHBhdGggZD0ibTExMS40MiA3NS4zMjYgMTUuNDE4IDM1LjAzNCAwLjM1MTM5LTAuMTE2MjdzNS45ODM0LTUuODY4NCA4LjM0MTEtOS4zMDEyYzIuNjk5NC0zLjkzMDQgNi4wOTM1LTEwLjkyMiA4LjIzODItMTUuNTYxLTAuNjQxNzcgMC4xMzA0Ny0xLjI5NDkgMC4xOTc0Ny0xLjk0OTggMC4xOTk0Ny01LjUwMDggM2UtNSAtOS45NjAyLTQuNDU5My05Ljk2MDEtOS45NjAxIDRlLTMgLTAuMDk4MDkgMC4wMTA2LTAuMTk2MTQgMC4wMTc2LTAuMjk0MDR6bS0xNi4wOTIgOC4xNDI3Yy00Ljc1NjYgMi44Mzg3LTEyLjM4NyA0LjUyMTgtMjAuNTE1IDQuNTIzOHYyOS4yNzloMzEuMTQ4YzEuMjk5OSAwIDMuNzAyMS0xLjIyNTggMy43MDIxLTEuMjI1OHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMiIvPjxwYXRoIGQ9Im0xMzYuMjcgNjcuNTEzdjUuNDQ2MmgtMjUuODk2bC0yLjM5NjgtNS40NDYyeiIvPjxwYXRoIGQ9Im05MS44MTQgNzUuMzI2IDIuNTczMSA1LjM5MTRjLTUuMTYwNyAyLjA4NjUtMTIuMjE1IDMuMjYyMS0xOS41NzggMy4yNjI4di02LjMwMzVjNi4xNzIyLTJlLTMgMTQuMzQ2LTEuNjM4MyAxNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTc0LjgwOSAxMTcuMzd2LTI5LjQ4MiIgZmlsbD0iIzAwZiIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEuNDciLz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,178,151,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk5LjA0OW1tIiBoZWlnaHQ9IjE2MC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5OS4wNDkgMTYwLjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0zOC4xNjkgMTcuNzk3YTI1LjYxNiAyNS42MTYgMCAwIDAtMjUuNjE3IDI1LjYxNyAyNS42MTYgMjUuNjE2IDAgMCAwIDI1LjYxNyAyNS42MTYgMjUuNjE2IDI1LjYxNiAwIDAgMCAyNS42MTYtMjUuNjE2IDI1LjYxNiAyNS42MTYgMCAwIDAtMC4wNTYzLTEuNjYyOWMtMi42NTQyIDEuMjg1Ny00LjgzNTQgMy40NzYzLTYuNzUgNS43MTk1LTEuMzc0NyAxLjYxMDYtMy4yOTM5IDUuNDMxNy0zLjI5MzkgNS40MzE3cy0zLjg0NDMgMi45ODEzLTUuNjYxNyAyLjExMjVjLTEuOTk1NS0wLjk1Mzk4LTIuMzk3Mi00LjEwMzItMi4wOTg2LTYuMjk0NyAwLjQ2Njg0LTMuNDI2MyAzLjE3NjMtNi4zNDU4IDUuNzk0LTguNjA1MiAyLjk3OS0yLjU3MTMgMTAuNjUtNS4wOTE4IDEwLjY1My01LjA5MjdhMjUuNjE2IDI1LjYxNiAwIDAgMC0xZS0zIC0zZS0zYy05ZS0zIC0wLjAxNzQtMy45MjUtNy40MTI2LTYuODgxMi0xMC4yODMtMS4yMDI1LTEuMTY3Ny0yLjY1MjYtMi4zMzQ0LTQuMjY4LTMuMzYyMWEyNS42MTYgMjUuNjE2IDAgMCAwLTEzLjA1Mi0zLjU3NjZ6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTc1LjM4NCAzOC42OGEyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NiAyMy42NjUgMjMuNjY1IDIzLjY2NSAwIDAgMCAyMy42NjYgMjMuNjY2IDIzLjY2NSAyMy42NjUgMCAwIDAgMjMuNjY1LTIzLjY2NiAyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NS0yMy42NjV6bTIuNTkxNiAxMS44ODdjMy41MTI2IDAuMDU3OSA4LjIwODIgMy43Njk0IDkuNDYyNSA2LjgxNjEgMS44NDkgNC40OTEyLTAuMzE2MDQgMTQuMTg0LTUuNTAzIDEzLjQ4OS0zLjYwNDYtMC40ODM0IDAuMzE1MzItNi43ODg0LTAuNzI3MDgtOS45ODQ0LTEuMTI2Mi0zLjQ1MjktOC41NTY1LTYuODM5Ny01LjgwMzMtOS40MTQ5IDAuNjk2NTMtMC42NTE0OSAxLjU4NzQtMC45MjE1NyAyLjU3MDktMC45MDUzN3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48cGF0aCBkPSJtNTMuNjg1IDUyLjkwMS01LjJlLTQgMWUtM3MtMy44NDQzIDIuOTgxMy01LjY2MTcgMi4xMTI1bC0yNC4wMzUgOS43MzIyIDQzLjg3MyAyMC4wMDN6Ii8+PHBhdGggZD0ibTcxLjEzNyAwYy0xMC4wNDMgMC4wMTIwMi0xOS4wODIgNi4wOTU0LTIyLjg3NSAxNS4zOTUgMi43OTkxIDAuNDYwNjcgNS41MDIyIDEuMzgzMSA3Ljk5OSAyLjcyOTUgMC4yMjgwOSAwLjExNzI2IDAuNDUzNjIgMC4yMzk0MSAwLjY3NjQ0IDAuMzY2MzkgMC4wODUzNSAwLjA0NTY4IDAuMTcwNDUgMC4wOTE4NSAwLjI1NTI4IDAuMTM4NDkgMC4xMzMxNyAwLjA4NDcyIDAuMjYzNDEgMC4xNzE4NSAwLjM5NDI5IDAuMjU4MzggMC42MDg2MiAwLjM4NDEgMS4xOTM1IDAuODA0NjUgMS43NTEzIDEuMjU5NCAwLjc2ODg2IDAuNjAwNzUgMS40ODE2IDEuMjIyMiAyLjEyMjQgMS44NDQzIDIuNzk3OCAyLjcxNjcgNi40MTM2IDkuNDA5MyA2LjgwNTMgMTAuMTQyIDIuMTk3Ni0wLjY2NTI0IDQuNDgwMy0xLjAwNzEgNi43NzYzLTEuMDE0OSA2LjMyNzMgMC4wMDYxIDEyLjM4OSAyLjU0NTggMTYuODMgNy4wNTE4IDIuNjAwNi0zLjk5OSAzLjk4OTUtOC42NjQ2IDMuOTk5Mi0xMy40MzUtNy42ZS01IC0xMy42NjEtMTEuMDc0LTI0LjczNS0yNC43MzUtMjQuNzM1em00Ljc5NjEgOC41NzA1YzQuMDgyNi0wLjA1NzEyIDguMTg0NyA0Ljk5OSA4Ljg5ODcgOS4wNzMzIDAuNzYxOTIgNC4zNDc4LTAuODU4NDcgMTEuNzY4LTUuMTc5NiAxMC44NjctMy4xNjM5LTAuNjU5OS0wLjYxMzY4LTUuNjgwNC0xLjUzNjgtOC43Nzc4LTAuODcyMi0yLjkyNjYtNC40MDYxLTQuOTI3MS00LjUwMS03Ljk3OTQtMC4wMzU3LTEuMTQ4NCAwLjM3NDY4LTIuODg4OSAxLjUwMzgtMy4xMDE2IDAuMjcwOTktMC4wNTEwNyAwLjU0Mjc3LTAuMDc3ODM5IDAuODE0OTQtMC4wODE2NDl6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTEyLjk3MSA2Mi41NzctMTIuOTcxIDk3LjUxOCA3MS4wOTItNjcuNDg5cy00Ljc4MDggMS40NDQtNi45MDk3IDAuNTQ2MjJjLTE2LjEwOS02Ljc5MzQtMzEuNDMtMTMuNzY4LTQ1Ljk1Mi0yMi45NzEtMi42MDM0LTEuNjQ5OC01LjI1OTYtNy42MDQyLTUuMjU5Ni03LjYwNDJ6bTM2LjIyMSAyOS4zMDVjMS42ODYgMC4wNDE5IDMuMDUxOSAxLjM5MTggMy4wOTU0IDMuMDk3NWwwLjAxNyAwLjY3OTU1YzAuMDQ0OSAxLjc2MDctMS4zMzYzIDMuMjE0My0zLjA5NyAzLjI1OTJsLTI2LjIxNiAwLjY2ODY5Yy0xLjc2MDcgMC4wNDQ5LTMuMjE0My0xLjMzNjMtMy4yNTkyLTMuMDk3bC0wLjAxNzUyLTAuNjgwMDZjLTAuMDQ0OS0xLjc2MDcgMS4zMzY4LTMuMjE0MyAzLjA5NzUtMy4yNTkybDI2LjIxNi0wLjY2ODE4YzAuMDU1LTFlLTMgMC4xMDk0My0yZS0zIDAuMTYzODItNS4xZS00em0tMTEuMjU3IDE1LjI5N2MxLjY4NDkgMC4wMjc4IDMuMDQxNSAxLjM2NiAzLjA3NDIgMy4wNzE2bDAuMDEyOSAwLjY4MDA2YzAuMDMzOCAxLjc2MDctMS4zNTYxIDMuMjI2LTMuMTE2MSAzLjI4NTZsLTE4LjE1OCAwLjYxNTQ3Yy0xLjc2IDAuMDU5Ni0zLjIwNDMtMS4zMDk5LTMuMjM4LTMuMDcwNmwtMC4wMTI5Mi0wLjY3OTU0Yy0wLjAzMzc5LTEuNzYwNyAxLjM1NjEtMy4yMjY1IDMuMTE2MS0zLjI4NjFsMTguMTU4LTAuNjE1NDZjMC4wNTUtMmUtMyAwLjEwOTQ2LTJlLTMgMC4xNjM4MS0xZS0zem0tMTUuNjIgMTQuMTk0YzEuNjQyNCA5ZS0zIDIuOTM5NCAxLjI4NDQgMi45NTQ5IDIuOTYyNmwwLjAwNjIgMC42Nzk1NGMwLjAxNjIyIDEuNzYwNy0xLjM4NDUgMy4yNzc5LTMuMTQwOSAzLjQwMTlsLTUuNDI5MSAwLjM4MzQ0Yy0xLjc1NjQgMC4xMjM5Ni0zLjE4MzYtMS4xOTM2LTMuMTk5OC0yLjk1NDNsLTAuMDA2Mi0wLjY4MDA2Yy0wLjAxNjIyLTEuNzYwNyAxLjM4NDUtMy4yNzc5IDMuMTQwOS0zLjQwMTlsNS40MjkxLTAuMzgyOTNjMC4wODIzMy02ZS0zIDAuMTY0MTctOWUtMyAwLjI0NDk1LThlLTN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.34102" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS42Mm1tIiBoZWlnaHQ9IjE0OS41Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDkuNjIgMTQ5LjU2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxjaXJjbGUgY3g9IjE0MS44MSIgY3k9Ijc1LjYyIiByPSI2LjI1MzkiLz48Y2lyY2xlIGN4PSI3LjgwMzkiIGN5PSI3NS42MiIgcj0iNi4yNTM5Ii8+PHJlY3QgeD0iMy4xNzAyZS03IiB5PSIxMzcuNDkiIHdpZHRoPSIxNDkuNjIiIGhlaWdodD0iMTIuMDY5IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjIuNTc1MiIvPjwvZz48Y2lyY2xlIGN4PSI3NC44MDkiIGN5PSIxMy45NjEiIHI9IjEwLjUxMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjYuOSIvPjxwYXRoIGQ9Im02OS4xNDggMjIuNDY3LTU3LjQ3NCA0OS4xOTIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI0LjUiLz48Zz48cGF0aCBkPSJtNjYuNTk3IDIwLjg4LTQ3LjkyIDEwOC44OSA5LjY4NDctMWUtNSA0Ni4zNDktMTA1LjMyeiIvPjxwYXRoIGQ9Im0xNy43NDcgNzUuMzI2YzAuMDA3MyAwLjA5NzkgMC4wMTMxNiAwLjE5NTk1IDAuMDE3NTcgMC4yOTQwNCA0ZS01IDUuNTAwOC00LjQ1OTMgOS45NjAyLTkuOTYwMSA5Ljk2MDEtMC42NTQ4OS0yZS0zIC0xLjMwOC0wLjA2OS0xLjk0OTgtMC4xOTk0NyAyLjE0NDggNC42Mzk3IDUuNTM4OCAxMS42MzEgOC4yMzgzIDE1LjU2MSAyLjM1NzcgMy40MzI5IDguMzQxMSA5LjMwMTIgOC4zNDExIDkuMzAxMmwwLjM1MTQgMC4xMTYyNyAxNS40MTgtMzUuMDM0em0zNi41NDggOC4xNDI3LTE0LjMzNiAzMi41NzdzMi40MDIyIDEuMjI1OCAzLjcwMjEgMS4yMjU4aDMxLjE0OHYtMjkuMjc5Yy04LjEyNzItMmUtMyAtMTUuNzU4LTEuNjg1LTIwLjUxNS00LjUyMzh6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iLjIiLz48cGF0aCBkPSJtMTMuMzQ5IDY3LjUxM3Y1LjQ0NjJoMjUuODk2bDIuMzk2OC01LjQ0NjJ6Ii8+PHBhdGggZD0ibTU3LjgwNCA3NS4zMjYtMi41NzMxIDUuMzkxNGM1LjE2MDcgMi4wODY1IDEyLjIxNSAzLjI2MjEgMTkuNTc4IDMuMjYyOHYtNi4zMDM1Yy02LjE3MjItMmUtMyAtMTQuMzQ2LTEuNjM4My0xNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTgwLjQ3IDIyLjQ2NyA1Ny40NzQgNDkuMTkyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNC41Ii8+PGc+PHBhdGggZD0ibTgzLjAyMSAyMC44OCA0Ny45MiAxMDguODktOS42ODQ3LTFlLTUgLTQ2LjM0OS0xMDUuMzJ6Ii8+PHBhdGggZD0ibTExMS40MiA3NS4zMjYgMTUuNDE4IDM1LjAzNCAwLjM1MTM5LTAuMTE2MjdzNS45ODM0LTUuODY4NCA4LjM0MTEtOS4zMDEyYzIuNjk5NC0zLjkzMDQgNi4wOTM1LTEwLjkyMiA4LjIzODItMTUuNTYxLTAuNjQxNzcgMC4xMzA0Ny0xLjI5NDkgMC4xOTc0Ny0xLjk0OTggMC4xOTk0Ny01LjUwMDggM2UtNSAtOS45NjAyLTQuNDU5My05Ljk2MDEtOS45NjAxIDRlLTMgLTAuMDk4MDkgMC4wMTA2LTAuMTk2MTQgMC4wMTc2LTAuMjk0MDR6bS0xNi4wOTIgOC4xNDI3Yy00Ljc1NjYgMi44Mzg3LTEyLjM4NyA0LjUyMTgtMjAuNTE1IDQuNTIzOHYyOS4yNzloMzEuMTQ4YzEuMjk5OSAwIDMuNzAyMS0xLjIyNTggMy43MDIxLTEuMjI1OHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMiIvPjxwYXRoIGQ9Im0xMzYuMjcgNjcuNTEzdjUuNDQ2MmgtMjUuODk2bC0yLjM5NjgtNS40NDYyeiIvPjxwYXRoIGQ9Im05MS44MTQgNzUuMzI2IDIuNTczMSA1LjM5MTRjLTUuMTYwNyAyLjA4NjUtMTIuMjE1IDMuMjYyMS0xOS41NzggMy4yNjI4di02LjMwMzVjNi4xNzIyLTJlLTMgMTQuMzQ2LTEuNjM4MyAxNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTc0LjgwOSAxMTcuMzd2LTI5LjQ4MiIgZmlsbD0iIzAwZiIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEuNDciLz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg1LjAyM21tIiBoZWlnaHQ9IjE1Mi43M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4NS4wMjMgMTUyLjczIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im01OCA1OS44ODJ2MTYuMzc0bDguOTcyMSA5LjAyNjNjMy4zNjI3IDMuMzgzMSA3Ljg5NTUgNC4yOTIyIDEwLjE2MyAyLjAzODEgMi4yNjc3LTIuMjU0MSAxLjM4NjEtNi43OTI1LTEuOTc2Ni0xMC4xNzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjQ2NSIvPjxwYXRoIGQ9Im0zNi4zNTUgOTIuNTdjLTIuNjIyNSA0LjUyNjctNS42NDA2IDkuNzQyNC05LjIwNjcgMTUuOTIyLTguMzM2MiAxNC40NDUtMTUuNDA4IDI2LjYzNS0xNS43MTYgMjcuMDktMC45MDA0IDEuMzMyOS0xLjI2MjUgMi41MzU4LTEuMjYwNCA0LjE4NzggMC4wMDE2IDEuMDc5OCAwLjA3MjAxIDEuNTkzNCAwLjMxMzE2IDIuMjgzMSAxLjA3NzkgMy4wODI2IDMuODYyNSA1LjA1NDIgNy4wOTQxIDUuMDIyNCAwLjUxMzQ3LTVlLTMgMS4yNzgyLTAuMTAwNTIgMS42OTk2LTAuMjEyMzkgMS43MDc4LTAuNDUzMzEgMy4xMTE3LTEuNDUxOCA0LjM3MTgtMy4xMDk0IDAuNDMzMzctMC41NzAwNiAxNC45MTktMjUuNTU5IDIzLjQyNS00MC4zMzV6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zOC4wMjQgMjguMzUxYy0wLjU2MjQzLTAuMDA4NS0xLjA5MzQgMC4wMjQ2Ni0xLjQ4MjEgMC4xMDY0NS0wLjQyMTQ2IDAuMDg4NjgtMS4xMTA3IDAuMzAzMjYtMS41MzIyIDAuNDc2OTctMC40MjE0NiAwLjE3MzcxLTYuNDk1OSAzLjYzNTctMTMuNDk4IDcuNjkzMS0xMC40NDQgNi4wNTE1LTEyLjk3NSA3LjUxNTItMTQuMDE3IDguNjcyM2wxNi4wNDQgMC4wMDE2djMuNTYzNmMzLjAwMS0xLjcyODYgNS40Njk5LTMuMDk4OSA1LjU0NTQtMy4wNzM3IDAuMDk2NjEgMC4wMzIyIDAuMTY1OTQgNS40Njk2IDAuMjEyOTEgMTYuNjg1bDAuMDY5NzYgMTYuNjM4IDAuMzI3MTEgMC42MjY4NGMwLjA2NjMzIDAuMTI3MTIgMC42NzQ2MSAwLjc4NDA3IDEuNTg0NCAxLjczNjNsMC4wNjU2My0wLjA2NTExIDI1Ljg5OCAyNi4yMDUgMC4wMjQ4MSAwLjAyNTMgNC42MjYxIDQuNjMwNyA0LjM5MyAxNy42OTVjMy41NjM4IDE0LjM1NSA0LjQ4MzQgMTcuODc5IDQuODczMSAxOC42NzUgMC45NjU3NiAxLjk3MjUgMy4yMDcyIDMuNjI1OCA1LjM3MDIgMy45NjE1IDEuMTQ1OCAwLjE3Nzc4IDEuNTI3NCAwLjE2Njk4IDIuNjQ3NC0wLjA3NTQgMS40NDM4LTAuMzEyNjggMi41OTAyLTAuOTU0OTMgMy42OTQzLTIuMDY5MSAxLjA0OTctMS4wNTkzIDEuNTk3Ni0yLjAwMzMgMS45NDM2LTMuMzQ5NyAwLjQ3MjYxLTEuODM5IDAuNjQ4MzgtMS4wMTY3LTUuMjM3NC0yNC41MDctMi45OTgtMTEuOTY1LTUuNTc1Ni0yMi4xLTUuNzI4My0yMi41MjEtMC4yNTg4Ny0wLjcxNDQtMC45NDY5NS0xLjQzNjItMTAuMTU0LTEwLjY2bC02LjYwOTQtNi42MjE5LTMuMjY2NS0zLjI3MjctMC4yMTcwNC0wLjIxNzA0di0yMi40NTFjLTcuOGUtNCAtMC43ODAyLTAuMDAyNS00LjM3MTMgMC04LjQwODN2LTExLjIyN2MtMC4wODMxNy0xLjM2ODctMS4wMzc1LTEuNzcyMS02Ljg4NDMtNS4xNDctMi45NDgtMS43MDE2LTUuNzA2Ny0zLjIxNzEtNi4xMzA0LTMuMzY4My0wLjYwMDAyLTAuMjE0MDgtMS42MjUyLTAuMzQ0MzktMi41NjI2LTAuMzU4NjN6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zMS4wNjEgOC45MjM5Yy0wLjQyMTk0IDQuMDMyMyAxLjA1OTUgOC4zMjA2IDMuMzI4NCAxMS42OTkgMS4zNDk2IDIuMDA5MyAzLjMxMDIgMy41OTUzIDUuMzI0NCA0LjkzNzUgMi42NDQ4IDEuNzYyNSA1LjU2NzIgMy4yOTE1IDguNjc1MiAzLjk1NjcgMS4xODk2IDAuMjU0NTggMi41MDE2IDAuMzgwMjIgMy42NDk0LTAuMDIyOCAxLjQzNDQtMC41MDM2NSAyLjcyNjEtMS41Njk0IDMuNTc3NC0yLjgyOSAxLjI5NzQtMS45MTk1IDEuNjg4OC00LjM2NjEgMS45Njc3LTYuNjY2IDAuMjg4NjYtMi4zNzk5IDAuMzUxOS00Ljg4NTctMC4zMjgxMi03LjE4NDctMC44MjI3NS0yLjc4MTUtMi40Mjk0LTUuMzc3NS00LjM5NTctNy41MDk5LTEuODEyMi0xLjk2NTMtNC4wNDAyLTMuNzM2My02LjU3MDctNC41OTgzLTIuMzY2Ny0wLjgwNjItNS4wNjA0LTAuOTIzMDQtNy40OTI5LTAuMzQ1LTEuNzAyIDAuNDA0NDMtMy4zNTMzIDEuMzIwNC00LjU3MzUgMi41NzM5LTEuNTc0NiAxLjYxNzYtMi45MjY2IDMuNzQzOC0zLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTE5Ljc4OCA0MC4xOGMtMTAuNzY4IDMuNjUwOC0xMS4zNSAzLjk0OTYtMTIuNTggNS40NjEyLTEuMzI1OCAxLjYyOTUtMS4zNjcgMC45NTI4Mi00LjU1NDYgMTYuOTU3IDAgMC0yLjIyNTcgOS4yMzYtMi42NTA2IDE0LjM4NC0wLjAyMzk1NSAwLjI5MDI0IDAuMTYwMiAwLjg1ODg2IDAuMTYwMiAwLjg1ODg2IDAuMjA5NDIgMS4xMjMzIDEuMTgxNSAyLjcwOTIgMi4wODYyIDMuNDAzNCAyLjc5MzggMi4xNDM3IDYuNTU4NyAxLjQ4MzMgOC41NTM1LTEuNTAwNyAwLjQxOTg1LTAuNjI4MDUgMC40NjgyNS0wLjgzNjk1IDMuMDgwOS0xMy40MzZsMi42NTM2LTEyLjc5OCAwLjE5MTItMC43MTI2MiA5Ljg1MzktNS42NjQ0IDEuMDk0My01LjM2MDJ6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.00612" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwNC42Mm1tIiBoZWlnaHQ9IjE4My44N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDQuNjIgMTgzLjg3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC43NjIyMyAtNTUuOTg0KSI+PHBhdGggZD0ibTE1NC45NyA3NS45OWExMTMuMjIgMTEzLjIyIDAgMCAwLTE1NS43MyAyNi40OTIgMzkuMjYzIDM5LjI2MyAwIDAgMSA1Mi44NTctNy42NDg3IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MiAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NTY0IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MSAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NDkyIDM5LjI2MyAzOS4yNjMgMCAwIDEgMTAuNTcxIDUzLjc3MyAxMTMuMjIgMTEzLjIyIDAgMCAwLTI5LjQxNS0xNTYuNjV6Ii8+PHBhdGggZD0ibTE2LjM5NCAyMDUuOTRzLTIuMjQyNyA1LjczNTctMi4yODM3IDguNzQ5N2MtMC4wNjY3MiA0LjkwNzYgMC4yMDA2NiAxMC41NjIgMy4zMjk4IDE0LjM0MyAzLjEzMjEgMy43ODQ4IDguNTcgNi4xMzc3IDEzLjQ3OSA1Ljk1OTUgNC41MTkzLTAuMTY0MDYgOS4yMDgtMi43OTY0IDExLjk3OC02LjM3MTIgNDYuMjYyLTU5LjcwNiAxMjMuNzItMTY3LjI2IDEyMy43Mi0xNjcuMjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="196,60,57,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk5LjA0OW1tIiBoZWlnaHQ9IjE2MC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5OS4wNDkgMTYwLjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0zOC4xNjkgMTcuNzk3YTI1LjYxNiAyNS42MTYgMCAwIDAtMjUuNjE3IDI1LjYxNyAyNS42MTYgMjUuNjE2IDAgMCAwIDI1LjYxNyAyNS42MTYgMjUuNjE2IDI1LjYxNiAwIDAgMCAyNS42MTYtMjUuNjE2IDI1LjYxNiAyNS42MTYgMCAwIDAtMC4wNTYzLTEuNjYyOWMtMi42NTQyIDEuMjg1Ny00LjgzNTQgMy40NzYzLTYuNzUgNS43MTk1LTEuMzc0NyAxLjYxMDYtMy4yOTM5IDUuNDMxNy0zLjI5MzkgNS40MzE3cy0zLjg0NDMgMi45ODEzLTUuNjYxNyAyLjExMjVjLTEuOTk1NS0wLjk1Mzk4LTIuMzk3Mi00LjEwMzItMi4wOTg2LTYuMjk0NyAwLjQ2Njg0LTMuNDI2MyAzLjE3NjMtNi4zNDU4IDUuNzk0LTguNjA1MiAyLjk3OS0yLjU3MTMgMTAuNjUtNS4wOTE4IDEwLjY1My01LjA5MjdhMjUuNjE2IDI1LjYxNiAwIDAgMC0xZS0zIC0zZS0zYy05ZS0zIC0wLjAxNzQtMy45MjUtNy40MTI2LTYuODgxMi0xMC4yODMtMS4yMDI1LTEuMTY3Ny0yLjY1MjYtMi4zMzQ0LTQuMjY4LTMuMzYyMWEyNS42MTYgMjUuNjE2IDAgMCAwLTEzLjA1Mi0zLjU3NjZ6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTc1LjM4NCAzOC42OGEyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NiAyMy42NjUgMjMuNjY1IDIzLjY2NSAwIDAgMCAyMy42NjYgMjMuNjY2IDIzLjY2NSAyMy42NjUgMCAwIDAgMjMuNjY1LTIzLjY2NiAyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NS0yMy42NjV6bTIuNTkxNiAxMS44ODdjMy41MTI2IDAuMDU3OSA4LjIwODIgMy43Njk0IDkuNDYyNSA2LjgxNjEgMS44NDkgNC40OTEyLTAuMzE2MDQgMTQuMTg0LTUuNTAzIDEzLjQ4OS0zLjYwNDYtMC40ODM0IDAuMzE1MzItNi43ODg0LTAuNzI3MDgtOS45ODQ0LTEuMTI2Mi0zLjQ1MjktOC41NTY1LTYuODM5Ny01LjgwMzMtOS40MTQ5IDAuNjk2NTMtMC42NTE0OSAxLjU4NzQtMC45MjE1NyAyLjU3MDktMC45MDUzN3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48cGF0aCBkPSJtNTMuNjg1IDUyLjkwMS01LjJlLTQgMWUtM3MtMy44NDQzIDIuOTgxMy01LjY2MTcgMi4xMTI1bC0yNC4wMzUgOS43MzIyIDQzLjg3MyAyMC4wMDN6Ii8+PHBhdGggZD0ibTcxLjEzNyAwYy0xMC4wNDMgMC4wMTIwMi0xOS4wODIgNi4wOTU0LTIyLjg3NSAxNS4zOTUgMi43OTkxIDAuNDYwNjcgNS41MDIyIDEuMzgzMSA3Ljk5OSAyLjcyOTUgMC4yMjgwOSAwLjExNzI2IDAuNDUzNjIgMC4yMzk0MSAwLjY3NjQ0IDAuMzY2MzkgMC4wODUzNSAwLjA0NTY4IDAuMTcwNDUgMC4wOTE4NSAwLjI1NTI4IDAuMTM4NDkgMC4xMzMxNyAwLjA4NDcyIDAuMjYzNDEgMC4xNzE4NSAwLjM5NDI5IDAuMjU4MzggMC42MDg2MiAwLjM4NDEgMS4xOTM1IDAuODA0NjUgMS43NTEzIDEuMjU5NCAwLjc2ODg2IDAuNjAwNzUgMS40ODE2IDEuMjIyMiAyLjEyMjQgMS44NDQzIDIuNzk3OCAyLjcxNjcgNi40MTM2IDkuNDA5MyA2LjgwNTMgMTAuMTQyIDIuMTk3Ni0wLjY2NTI0IDQuNDgwMy0xLjAwNzEgNi43NzYzLTEuMDE0OSA2LjMyNzMgMC4wMDYxIDEyLjM4OSAyLjU0NTggMTYuODMgNy4wNTE4IDIuNjAwNi0zLjk5OSAzLjk4OTUtOC42NjQ2IDMuOTk5Mi0xMy40MzUtNy42ZS01IC0xMy42NjEtMTEuMDc0LTI0LjczNS0yNC43MzUtMjQuNzM1em00Ljc5NjEgOC41NzA1YzQuMDgyNi0wLjA1NzEyIDguMTg0NyA0Ljk5OSA4Ljg5ODcgOS4wNzMzIDAuNzYxOTIgNC4zNDc4LTAuODU4NDcgMTEuNzY4LTUuMTc5NiAxMC44NjctMy4xNjM5LTAuNjU5OS0wLjYxMzY4LTUuNjgwNC0xLjUzNjgtOC43Nzc4LTAuODcyMi0yLjkyNjYtNC40MDYxLTQuOTI3MS00LjUwMS03Ljk3OTQtMC4wMzU3LTEuMTQ4NCAwLjM3NDY4LTIuODg4OSAxLjUwMzgtMy4xMDE2IDAuMjcwOTktMC4wNTEwNyAwLjU0Mjc3LTAuMDc3ODM5IDAuODE0OTQtMC4wODE2NDl6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTEyLjk3MSA2Mi41NzctMTIuOTcxIDk3LjUxOCA3MS4wOTItNjcuNDg5cy00Ljc4MDggMS40NDQtNi45MDk3IDAuNTQ2MjJjLTE2LjEwOS02Ljc5MzQtMzEuNDMtMTMuNzY4LTQ1Ljk1Mi0yMi45NzEtMi42MDM0LTEuNjQ5OC01LjI1OTYtNy42MDQyLTUuMjU5Ni03LjYwNDJ6bTM2LjIyMSAyOS4zMDVjMS42ODYgMC4wNDE5IDMuMDUxOSAxLjM5MTggMy4wOTU0IDMuMDk3NWwwLjAxNyAwLjY3OTU1YzAuMDQ0OSAxLjc2MDctMS4zMzYzIDMuMjE0My0zLjA5NyAzLjI1OTJsLTI2LjIxNiAwLjY2ODY5Yy0xLjc2MDcgMC4wNDQ5LTMuMjE0My0xLjMzNjMtMy4yNTkyLTMuMDk3bC0wLjAxNzUyLTAuNjgwMDZjLTAuMDQ0OS0xLjc2MDcgMS4zMzY4LTMuMjE0MyAzLjA5NzUtMy4yNTkybDI2LjIxNi0wLjY2ODE4YzAuMDU1LTFlLTMgMC4xMDk0My0yZS0zIDAuMTYzODItNS4xZS00em0tMTEuMjU3IDE1LjI5N2MxLjY4NDkgMC4wMjc4IDMuMDQxNSAxLjM2NiAzLjA3NDIgMy4wNzE2bDAuMDEyOSAwLjY4MDA2YzAuMDMzOCAxLjc2MDctMS4zNTYxIDMuMjI2LTMuMTE2MSAzLjI4NTZsLTE4LjE1OCAwLjYxNTQ3Yy0xLjc2IDAuMDU5Ni0zLjIwNDMtMS4zMDk5LTMuMjM4LTMuMDcwNmwtMC4wMTI5Mi0wLjY3OTU0Yy0wLjAzMzc5LTEuNzYwNyAxLjM1NjEtMy4yMjY1IDMuMTE2MS0zLjI4NjFsMTguMTU4LTAuNjE1NDZjMC4wNTUtMmUtMyAwLjEwOTQ2LTJlLTMgMC4xNjM4MS0xZS0zem0tMTUuNjIgMTQuMTk0YzEuNjQyNCA5ZS0zIDIuOTM5NCAxLjI4NDQgMi45NTQ5IDIuOTYyNmwwLjAwNjIgMC42Nzk1NGMwLjAxNjIyIDEuNzYwNy0xLjM4NDUgMy4yNzc5LTMuMTQwOSAzLjQwMTlsLTUuNDI5MSAwLjM4MzQ0Yy0xLjc1NjQgMC4xMjM5Ni0zLjE4MzYtMS4xOTM2LTMuMTk5OC0yLjk1NDNsLTAuMDA2Mi0wLjY4MDA2Yy0wLjAxNjIyLTEuNzYwNyAxLjM4NDUtMy4yNzc5IDMuMTQwOS0zLjQwMTlsNS40MjkxLTAuMzgyOTNjMC4wODIzMy02ZS0zIDAuMTY0MTctOWUtMyAwLjI0NDk1LThlLTN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.34102" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS42Mm1tIiBoZWlnaHQ9IjE0OS41Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDkuNjIgMTQ5LjU2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxjaXJjbGUgY3g9IjE0MS44MSIgY3k9Ijc1LjYyIiByPSI2LjI1MzkiLz48Y2lyY2xlIGN4PSI3LjgwMzkiIGN5PSI3NS42MiIgcj0iNi4yNTM5Ii8+PHJlY3QgeD0iMy4xNzAyZS03IiB5PSIxMzcuNDkiIHdpZHRoPSIxNDkuNjIiIGhlaWdodD0iMTIuMDY5IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjIuNTc1MiIvPjwvZz48Y2lyY2xlIGN4PSI3NC44MDkiIGN5PSIxMy45NjEiIHI9IjEwLjUxMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjYuOSIvPjxwYXRoIGQ9Im02OS4xNDggMjIuNDY3LTU3LjQ3NCA0OS4xOTIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI0LjUiLz48Zz48cGF0aCBkPSJtNjYuNTk3IDIwLjg4LTQ3LjkyIDEwOC44OSA5LjY4NDctMWUtNSA0Ni4zNDktMTA1LjMyeiIvPjxwYXRoIGQ9Im0xNy43NDcgNzUuMzI2YzAuMDA3MyAwLjA5NzkgMC4wMTMxNiAwLjE5NTk1IDAuMDE3NTcgMC4yOTQwNCA0ZS01IDUuNTAwOC00LjQ1OTMgOS45NjAyLTkuOTYwMSA5Ljk2MDEtMC42NTQ4OS0yZS0zIC0xLjMwOC0wLjA2OS0xLjk0OTgtMC4xOTk0NyAyLjE0NDggNC42Mzk3IDUuNTM4OCAxMS42MzEgOC4yMzgzIDE1LjU2MSAyLjM1NzcgMy40MzI5IDguMzQxMSA5LjMwMTIgOC4zNDExIDkuMzAxMmwwLjM1MTQgMC4xMTYyNyAxNS40MTgtMzUuMDM0em0zNi41NDggOC4xNDI3LTE0LjMzNiAzMi41NzdzMi40MDIyIDEuMjI1OCAzLjcwMjEgMS4yMjU4aDMxLjE0OHYtMjkuMjc5Yy04LjEyNzItMmUtMyAtMTUuNzU4LTEuNjg1LTIwLjUxNS00LjUyMzh6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iLjIiLz48cGF0aCBkPSJtMTMuMzQ5IDY3LjUxM3Y1LjQ0NjJoMjUuODk2bDIuMzk2OC01LjQ0NjJ6Ii8+PHBhdGggZD0ibTU3LjgwNCA3NS4zMjYtMi41NzMxIDUuMzkxNGM1LjE2MDcgMi4wODY1IDEyLjIxNSAzLjI2MjEgMTkuNTc4IDMuMjYyOHYtNi4zMDM1Yy02LjE3MjItMmUtMyAtMTQuMzQ2LTEuNjM4My0xNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTgwLjQ3IDIyLjQ2NyA1Ny40NzQgNDkuMTkyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNC41Ii8+PGc+PHBhdGggZD0ibTgzLjAyMSAyMC44OCA0Ny45MiAxMDguODktOS42ODQ3LTFlLTUgLTQ2LjM0OS0xMDUuMzJ6Ii8+PHBhdGggZD0ibTExMS40MiA3NS4zMjYgMTUuNDE4IDM1LjAzNCAwLjM1MTM5LTAuMTE2MjdzNS45ODM0LTUuODY4NCA4LjM0MTEtOS4zMDEyYzIuNjk5NC0zLjkzMDQgNi4wOTM1LTEwLjkyMiA4LjIzODItMTUuNTYxLTAuNjQxNzcgMC4xMzA0Ny0xLjI5NDkgMC4xOTc0Ny0xLjk0OTggMC4xOTk0Ny01LjUwMDggM2UtNSAtOS45NjAyLTQuNDU5My05Ljk2MDEtOS45NjAxIDRlLTMgLTAuMDk4MDkgMC4wMTA2LTAuMTk2MTQgMC4wMTc2LTAuMjk0MDR6bS0xNi4wOTIgOC4xNDI3Yy00Ljc1NjYgMi44Mzg3LTEyLjM4NyA0LjUyMTgtMjAuNTE1IDQuNTIzOHYyOS4yNzloMzEuMTQ4YzEuMjk5OSAwIDMuNzAyMS0xLjIyNTggMy43MDIxLTEuMjI1OHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMiIvPjxwYXRoIGQ9Im0xMzYuMjcgNjcuNTEzdjUuNDQ2MmgtMjUuODk2bC0yLjM5NjgtNS40NDYyeiIvPjxwYXRoIGQ9Im05MS44MTQgNzUuMzI2IDIuNTczMSA1LjM5MTRjLTUuMTYwNyAyLjA4NjUtMTIuMjE1IDMuMjYyMS0xOS41NzggMy4yNjI4di02LjMwMzVjNi4xNzIyLTJlLTMgMTQuMzQ2LTEuNjM4MyAxNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTc0LjgwOSAxMTcuMzd2LTI5LjQ4MiIgZmlsbD0iIzAwZiIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEuNDciLz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg1LjAyM21tIiBoZWlnaHQ9IjE1Mi43M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4NS4wMjMgMTUyLjczIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im01OCA1OS44ODJ2MTYuMzc0bDguOTcyMSA5LjAyNjNjMy4zNjI3IDMuMzgzMSA3Ljg5NTUgNC4yOTIyIDEwLjE2MyAyLjAzODEgMi4yNjc3LTIuMjU0MSAxLjM4NjEtNi43OTI1LTEuOTc2Ni0xMC4xNzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjQ2NSIvPjxwYXRoIGQ9Im0zNi4zNTUgOTIuNTdjLTIuNjIyNSA0LjUyNjctNS42NDA2IDkuNzQyNC05LjIwNjcgMTUuOTIyLTguMzM2MiAxNC40NDUtMTUuNDA4IDI2LjYzNS0xNS43MTYgMjcuMDktMC45MDA0IDEuMzMyOS0xLjI2MjUgMi41MzU4LTEuMjYwNCA0LjE4NzggMC4wMDE2IDEuMDc5OCAwLjA3MjAxIDEuNTkzNCAwLjMxMzE2IDIuMjgzMSAxLjA3NzkgMy4wODI2IDMuODYyNSA1LjA1NDIgNy4wOTQxIDUuMDIyNCAwLjUxMzQ3LTVlLTMgMS4yNzgyLTAuMTAwNTIgMS42OTk2LTAuMjEyMzkgMS43MDc4LTAuNDUzMzEgMy4xMTE3LTEuNDUxOCA0LjM3MTgtMy4xMDk0IDAuNDMzMzctMC41NzAwNiAxNC45MTktMjUuNTU5IDIzLjQyNS00MC4zMzV6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zOC4wMjQgMjguMzUxYy0wLjU2MjQzLTAuMDA4NS0xLjA5MzQgMC4wMjQ2Ni0xLjQ4MjEgMC4xMDY0NS0wLjQyMTQ2IDAuMDg4NjgtMS4xMTA3IDAuMzAzMjYtMS41MzIyIDAuNDc2OTctMC40MjE0NiAwLjE3MzcxLTYuNDk1OSAzLjYzNTctMTMuNDk4IDcuNjkzMS0xMC40NDQgNi4wNTE1LTEyLjk3NSA3LjUxNTItMTQuMDE3IDguNjcyM2wxNi4wNDQgMC4wMDE2djMuNTYzNmMzLjAwMS0xLjcyODYgNS40Njk5LTMuMDk4OSA1LjU0NTQtMy4wNzM3IDAuMDk2NjEgMC4wMzIyIDAuMTY1OTQgNS40Njk2IDAuMjEyOTEgMTYuNjg1bDAuMDY5NzYgMTYuNjM4IDAuMzI3MTEgMC42MjY4NGMwLjA2NjMzIDAuMTI3MTIgMC42NzQ2MSAwLjc4NDA3IDEuNTg0NCAxLjczNjNsMC4wNjU2My0wLjA2NTExIDI1Ljg5OCAyNi4yMDUgMC4wMjQ4MSAwLjAyNTMgNC42MjYxIDQuNjMwNyA0LjM5MyAxNy42OTVjMy41NjM4IDE0LjM1NSA0LjQ4MzQgMTcuODc5IDQuODczMSAxOC42NzUgMC45NjU3NiAxLjk3MjUgMy4yMDcyIDMuNjI1OCA1LjM3MDIgMy45NjE1IDEuMTQ1OCAwLjE3Nzc4IDEuNTI3NCAwLjE2Njk4IDIuNjQ3NC0wLjA3NTQgMS40NDM4LTAuMzEyNjggMi41OTAyLTAuOTU0OTMgMy42OTQzLTIuMDY5MSAxLjA0OTctMS4wNTkzIDEuNTk3Ni0yLjAwMzMgMS45NDM2LTMuMzQ5NyAwLjQ3MjYxLTEuODM5IDAuNjQ4MzgtMS4wMTY3LTUuMjM3NC0yNC41MDctMi45OTgtMTEuOTY1LTUuNTc1Ni0yMi4xLTUuNzI4My0yMi41MjEtMC4yNTg4Ny0wLjcxNDQtMC45NDY5NS0xLjQzNjItMTAuMTU0LTEwLjY2bC02LjYwOTQtNi42MjE5LTMuMjY2NS0zLjI3MjctMC4yMTcwNC0wLjIxNzA0di0yMi40NTFjLTcuOGUtNCAtMC43ODAyLTAuMDAyNS00LjM3MTMgMC04LjQwODN2LTExLjIyN2MtMC4wODMxNy0xLjM2ODctMS4wMzc1LTEuNzcyMS02Ljg4NDMtNS4xNDctMi45NDgtMS43MDE2LTUuNzA2Ny0zLjIxNzEtNi4xMzA0LTMuMzY4My0wLjYwMDAyLTAuMjE0MDgtMS42MjUyLTAuMzQ0MzktMi41NjI2LTAuMzU4NjN6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zMS4wNjEgOC45MjM5Yy0wLjQyMTk0IDQuMDMyMyAxLjA1OTUgOC4zMjA2IDMuMzI4NCAxMS42OTkgMS4zNDk2IDIuMDA5MyAzLjMxMDIgMy41OTUzIDUuMzI0NCA0LjkzNzUgMi42NDQ4IDEuNzYyNSA1LjU2NzIgMy4yOTE1IDguNjc1MiAzLjk1NjcgMS4xODk2IDAuMjU0NTggMi41MDE2IDAuMzgwMjIgMy42NDk0LTAuMDIyOCAxLjQzNDQtMC41MDM2NSAyLjcyNjEtMS41Njk0IDMuNTc3NC0yLjgyOSAxLjI5NzQtMS45MTk1IDEuNjg4OC00LjM2NjEgMS45Njc3LTYuNjY2IDAuMjg4NjYtMi4zNzk5IDAuMzUxOS00Ljg4NTctMC4zMjgxMi03LjE4NDctMC44MjI3NS0yLjc4MTUtMi40Mjk0LTUuMzc3NS00LjM5NTctNy41MDk5LTEuODEyMi0xLjk2NTMtNC4wNDAyLTMuNzM2My02LjU3MDctNC41OTgzLTIuMzY2Ny0wLjgwNjItNS4wNjA0LTAuOTIzMDQtNy40OTI5LTAuMzQ1LTEuNzAyIDAuNDA0NDMtMy4zNTMzIDEuMzIwNC00LjU3MzUgMi41NzM5LTEuNTc0NiAxLjYxNzYtMi45MjY2IDMuNzQzOC0zLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTE5Ljc4OCA0MC4xOGMtMTAuNzY4IDMuNjUwOC0xMS4zNSAzLjk0OTYtMTIuNTggNS40NjEyLTEuMzI1OCAxLjYyOTUtMS4zNjcgMC45NTI4Mi00LjU1NDYgMTYuOTU3IDAgMC0yLjIyNTcgOS4yMzYtMi42NTA2IDE0LjM4NC0wLjAyMzk1NSAwLjI5MDI0IDAuMTYwMiAwLjg1ODg2IDAuMTYwMiAwLjg1ODg2IDAuMjA5NDIgMS4xMjMzIDEuMTgxNSAyLjcwOTIgMi4wODYyIDMuNDAzNCAyLjc5MzggMi4xNDM3IDYuNTU4NyAxLjQ4MzMgOC41NTM1LTEuNTAwNyAwLjQxOTg1LTAuNjI4MDUgMC40NjgyNS0wLjgzNjk1IDMuMDgwOS0xMy40MzZsMi42NTM2LTEyLjc5OCAwLjE5MTItMC43MTI2MiA5Ljg1MzktNS42NjQ0IDEuMDk0My01LjM2MDJ6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.00612" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwNC42Mm1tIiBoZWlnaHQ9IjE4My44N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDQuNjIgMTgzLjg3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC43NjIyMyAtNTUuOTg0KSI+PHBhdGggZD0ibTE1NC45NyA3NS45OWExMTMuMjIgMTEzLjIyIDAgMCAwLTE1NS43MyAyNi40OTIgMzkuMjYzIDM5LjI2MyAwIDAgMSA1Mi44NTctNy42NDg3IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MiAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NTY0IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MSAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NDkyIDM5LjI2MyAzOS4yNjMgMCAwIDEgMTAuNTcxIDUzLjc3MyAxMTMuMjIgMTEzLjIyIDAgMCAwLTI5LjQxNS0xNTYuNjV6Ii8+PHBhdGggZD0ibTE2LjM5NCAyMDUuOTRzLTIuMjQyNyA1LjczNTctMi4yODM3IDguNzQ5N2MtMC4wNjY3MiA0LjkwNzYgMC4yMDA2NiAxMC41NjIgMy4zMjk4IDE0LjM0MyAzLjEzMjEgMy43ODQ4IDguNTcgNi4xMzc3IDEzLjQ3OSA1Ljk1OTUgNC41MTkzLTAuMTY0MDYgOS4yMDgtMi43OTY0IDExLjk3OC02LjM3MTIgNDYuMjYyLTU5LjcwNiAxMjMuNzItMTY3LjI2IDEyMy43Mi0xNjcuMjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg1LjAyM21tIiBoZWlnaHQ9IjE1Mi43M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4NS4wMjMgMTUyLjczIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im01OCA1OS44ODJ2MTYuMzc0bDguOTcyMSA5LjAyNjNjMy4zNjI3IDMuMzgzMSA3Ljg5NTUgNC4yOTIyIDEwLjE2MyAyLjAzODEgMi4yNjc3LTIuMjU0MSAxLjM4NjEtNi43OTI1LTEuOTc2Ni0xMC4xNzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjQ2NSIvPjxwYXRoIGQ9Im0zNi4zNTUgOTIuNTdjLTIuNjIyNSA0LjUyNjctNS42NDA2IDkuNzQyNC05LjIwNjcgMTUuOTIyLTguMzM2MiAxNC40NDUtMTUuNDA4IDI2LjYzNS0xNS43MTYgMjcuMDktMC45MDA0IDEuMzMyOS0xLjI2MjUgMi41MzU4LTEuMjYwNCA0LjE4NzggMC4wMDE2IDEuMDc5OCAwLjA3MjAxIDEuNTkzNCAwLjMxMzE2IDIuMjgzMSAxLjA3NzkgMy4wODI2IDMuODYyNSA1LjA1NDIgNy4wOTQxIDUuMDIyNCAwLjUxMzQ3LTVlLTMgMS4yNzgyLTAuMTAwNTIgMS42OTk2LTAuMjEyMzkgMS43MDc4LTAuNDUzMzEgMy4xMTE3LTEuNDUxOCA0LjM3MTgtMy4xMDk0IDAuNDMzMzctMC41NzAwNiAxNC45MTktMjUuNTU5IDIzLjQyNS00MC4zMzV6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zOC4wMjQgMjguMzUxYy0wLjU2MjQzLTAuMDA4NS0xLjA5MzQgMC4wMjQ2Ni0xLjQ4MjEgMC4xMDY0NS0wLjQyMTQ2IDAuMDg4NjgtMS4xMTA3IDAuMzAzMjYtMS41MzIyIDAuNDc2OTctMC40MjE0NiAwLjE3MzcxLTYuNDk1OSAzLjYzNTctMTMuNDk4IDcuNjkzMS0xMC40NDQgNi4wNTE1LTEyLjk3NSA3LjUxNTItMTQuMDE3IDguNjcyM2wxNi4wNDQgMC4wMDE2djMuNTYzNmMzLjAwMS0xLjcyODYgNS40Njk5LTMuMDk4OSA1LjU0NTQtMy4wNzM3IDAuMDk2NjEgMC4wMzIyIDAuMTY1OTQgNS40Njk2IDAuMjEyOTEgMTYuNjg1bDAuMDY5NzYgMTYuNjM4IDAuMzI3MTEgMC42MjY4NGMwLjA2NjMzIDAuMTI3MTIgMC42NzQ2MSAwLjc4NDA3IDEuNTg0NCAxLjczNjNsMC4wNjU2My0wLjA2NTExIDI1Ljg5OCAyNi4yMDUgMC4wMjQ4MSAwLjAyNTMgNC42MjYxIDQuNjMwNyA0LjM5MyAxNy42OTVjMy41NjM4IDE0LjM1NSA0LjQ4MzQgMTcuODc5IDQuODczMSAxOC42NzUgMC45NjU3NiAxLjk3MjUgMy4yMDcyIDMuNjI1OCA1LjM3MDIgMy45NjE1IDEuMTQ1OCAwLjE3Nzc4IDEuNTI3NCAwLjE2Njk4IDIuNjQ3NC0wLjA3NTQgMS40NDM4LTAuMzEyNjggMi41OTAyLTAuOTU0OTMgMy42OTQzLTIuMDY5MSAxLjA0OTctMS4wNTkzIDEuNTk3Ni0yLjAwMzMgMS45NDM2LTMuMzQ5NyAwLjQ3MjYxLTEuODM5IDAuNjQ4MzgtMS4wMTY3LTUuMjM3NC0yNC41MDctMi45OTgtMTEuOTY1LTUuNTc1Ni0yMi4xLTUuNzI4My0yMi41MjEtMC4yNTg4Ny0wLjcxNDQtMC45NDY5NS0xLjQzNjItMTAuMTU0LTEwLjY2bC02LjYwOTQtNi42MjE5LTMuMjY2NS0zLjI3MjctMC4yMTcwNC0wLjIxNzA0di0yMi40NTFjLTcuOGUtNCAtMC43ODAyLTAuMDAyNS00LjM3MTMgMC04LjQwODN2LTExLjIyN2MtMC4wODMxNy0xLjM2ODctMS4wMzc1LTEuNzcyMS02Ljg4NDMtNS4xNDctMi45NDgtMS43MDE2LTUuNzA2Ny0zLjIxNzEtNi4xMzA0LTMuMzY4My0wLjYwMDAyLTAuMjE0MDgtMS42MjUyLTAuMzQ0MzktMi41NjI2LTAuMzU4NjN6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zMS4wNjEgOC45MjM5Yy0wLjQyMTk0IDQuMDMyMyAxLjA1OTUgOC4zMjA2IDMuMzI4NCAxMS42OTkgMS4zNDk2IDIuMDA5MyAzLjMxMDIgMy41OTUzIDUuMzI0NCA0LjkzNzUgMi42NDQ4IDEuNzYyNSA1LjU2NzIgMy4yOTE1IDguNjc1MiAzLjk1NjcgMS4xODk2IDAuMjU0NTggMi41MDE2IDAuMzgwMjIgMy42NDk0LTAuMDIyOCAxLjQzNDQtMC41MDM2NSAyLjcyNjEtMS41Njk0IDMuNTc3NC0yLjgyOSAxLjI5NzQtMS45MTk1IDEuNjg4OC00LjM2NjEgMS45Njc3LTYuNjY2IDAuMjg4NjYtMi4zNzk5IDAuMzUxOS00Ljg4NTctMC4zMjgxMi03LjE4NDctMC44MjI3NS0yLjc4MTUtMi40Mjk0LTUuMzc3NS00LjM5NTctNy41MDk5LTEuODEyMi0xLjk2NTMtNC4wNDAyLTMuNzM2My02LjU3MDctNC41OTgzLTIuMzY2Ny0wLjgwNjItNS4wNjA0LTAuOTIzMDQtNy40OTI5LTAuMzQ1LTEuNzAyIDAuNDA0NDMtMy4zNTMzIDEuMzIwNC00LjU3MzUgMi41NzM5LTEuNTc0NiAxLjYxNzYtMi45MjY2IDMuNzQzOC0zLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTE5Ljc4OCA0MC4xOGMtMTAuNzY4IDMuNjUwOC0xMS4zNSAzLjk0OTYtMTIuNTggNS40NjEyLTEuMzI1OCAxLjYyOTUtMS4zNjcgMC45NTI4Mi00LjU1NDYgMTYuOTU3IDAgMC0yLjIyNTcgOS4yMzYtMi42NTA2IDE0LjM4NC0wLjAyMzk1NSAwLjI5MDI0IDAuMTYwMiAwLjg1ODg2IDAuMTYwMiAwLjg1ODg2IDAuMjA5NDIgMS4xMjMzIDEuMTgxNSAyLjcwOTIgMi4wODYyIDMuNDAzNCAyLjc5MzggMi4xNDM3IDYuNTU4NyAxLjQ4MzMgOC41NTM1LTEuNTAwNyAwLjQxOTg1LTAuNjI4MDUgMC40NjgyNS0wLjgzNjk1IDMuMDgwOS0xMy40MzZsMi42NTM2LTEyLjc5OCAwLjE5MTItMC43MTI2MiA5Ljg1MzktNS42NjQ0IDEuMDk0My01LjM2MDJ6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.00612" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="229,182,54,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk5LjA0OW1tIiBoZWlnaHQ9IjE2MC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5OS4wNDkgMTYwLjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0zOC4xNjkgMTcuNzk3YTI1LjYxNiAyNS42MTYgMCAwIDAtMjUuNjE3IDI1LjYxNyAyNS42MTYgMjUuNjE2IDAgMCAwIDI1LjYxNyAyNS42MTYgMjUuNjE2IDI1LjYxNiAwIDAgMCAyNS42MTYtMjUuNjE2IDI1LjYxNiAyNS42MTYgMCAwIDAtMC4wNTYzLTEuNjYyOWMtMi42NTQyIDEuMjg1Ny00LjgzNTQgMy40NzYzLTYuNzUgNS43MTk1LTEuMzc0NyAxLjYxMDYtMy4yOTM5IDUuNDMxNy0zLjI5MzkgNS40MzE3cy0zLjg0NDMgMi45ODEzLTUuNjYxNyAyLjExMjVjLTEuOTk1NS0wLjk1Mzk4LTIuMzk3Mi00LjEwMzItMi4wOTg2LTYuMjk0NyAwLjQ2Njg0LTMuNDI2MyAzLjE3NjMtNi4zNDU4IDUuNzk0LTguNjA1MiAyLjk3OS0yLjU3MTMgMTAuNjUtNS4wOTE4IDEwLjY1My01LjA5MjdhMjUuNjE2IDI1LjYxNiAwIDAgMC0xZS0zIC0zZS0zYy05ZS0zIC0wLjAxNzQtMy45MjUtNy40MTI2LTYuODgxMi0xMC4yODMtMS4yMDI1LTEuMTY3Ny0yLjY1MjYtMi4zMzQ0LTQuMjY4LTMuMzYyMWEyNS42MTYgMjUuNjE2IDAgMCAwLTEzLjA1Mi0zLjU3NjZ6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTc1LjM4NCAzOC42OGEyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NiAyMy42NjUgMjMuNjY1IDIzLjY2NSAwIDAgMCAyMy42NjYgMjMuNjY2IDIzLjY2NSAyMy42NjUgMCAwIDAgMjMuNjY1LTIzLjY2NiAyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NS0yMy42NjV6bTIuNTkxNiAxMS44ODdjMy41MTI2IDAuMDU3OSA4LjIwODIgMy43Njk0IDkuNDYyNSA2LjgxNjEgMS44NDkgNC40OTEyLTAuMzE2MDQgMTQuMTg0LTUuNTAzIDEzLjQ4OS0zLjYwNDYtMC40ODM0IDAuMzE1MzItNi43ODg0LTAuNzI3MDgtOS45ODQ0LTEuMTI2Mi0zLjQ1MjktOC41NTY1LTYuODM5Ny01LjgwMzMtOS40MTQ5IDAuNjk2NTMtMC42NTE0OSAxLjU4NzQtMC45MjE1NyAyLjU3MDktMC45MDUzN3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48cGF0aCBkPSJtNTMuNjg1IDUyLjkwMS01LjJlLTQgMWUtM3MtMy44NDQzIDIuOTgxMy01LjY2MTcgMi4xMTI1bC0yNC4wMzUgOS43MzIyIDQzLjg3MyAyMC4wMDN6Ii8+PHBhdGggZD0ibTcxLjEzNyAwYy0xMC4wNDMgMC4wMTIwMi0xOS4wODIgNi4wOTU0LTIyLjg3NSAxNS4zOTUgMi43OTkxIDAuNDYwNjcgNS41MDIyIDEuMzgzMSA3Ljk5OSAyLjcyOTUgMC4yMjgwOSAwLjExNzI2IDAuNDUzNjIgMC4yMzk0MSAwLjY3NjQ0IDAuMzY2MzkgMC4wODUzNSAwLjA0NTY4IDAuMTcwNDUgMC4wOTE4NSAwLjI1NTI4IDAuMTM4NDkgMC4xMzMxNyAwLjA4NDcyIDAuMjYzNDEgMC4xNzE4NSAwLjM5NDI5IDAuMjU4MzggMC42MDg2MiAwLjM4NDEgMS4xOTM1IDAuODA0NjUgMS43NTEzIDEuMjU5NCAwLjc2ODg2IDAuNjAwNzUgMS40ODE2IDEuMjIyMiAyLjEyMjQgMS44NDQzIDIuNzk3OCAyLjcxNjcgNi40MTM2IDkuNDA5MyA2LjgwNTMgMTAuMTQyIDIuMTk3Ni0wLjY2NTI0IDQuNDgwMy0xLjAwNzEgNi43NzYzLTEuMDE0OSA2LjMyNzMgMC4wMDYxIDEyLjM4OSAyLjU0NTggMTYuODMgNy4wNTE4IDIuNjAwNi0zLjk5OSAzLjk4OTUtOC42NjQ2IDMuOTk5Mi0xMy40MzUtNy42ZS01IC0xMy42NjEtMTEuMDc0LTI0LjczNS0yNC43MzUtMjQuNzM1em00Ljc5NjEgOC41NzA1YzQuMDgyNi0wLjA1NzEyIDguMTg0NyA0Ljk5OSA4Ljg5ODcgOS4wNzMzIDAuNzYxOTIgNC4zNDc4LTAuODU4NDcgMTEuNzY4LTUuMTc5NiAxMC44NjctMy4xNjM5LTAuNjU5OS0wLjYxMzY4LTUuNjgwNC0xLjUzNjgtOC43Nzc4LTAuODcyMi0yLjkyNjYtNC40MDYxLTQuOTI3MS00LjUwMS03Ljk3OTQtMC4wMzU3LTEuMTQ4NCAwLjM3NDY4LTIuODg4OSAxLjUwMzgtMy4xMDE2IDAuMjcwOTktMC4wNTEwNyAwLjU0Mjc3LTAuMDc3ODM5IDAuODE0OTQtMC4wODE2NDl6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTEyLjk3MSA2Mi41NzctMTIuOTcxIDk3LjUxOCA3MS4wOTItNjcuNDg5cy00Ljc4MDggMS40NDQtNi45MDk3IDAuNTQ2MjJjLTE2LjEwOS02Ljc5MzQtMzEuNDMtMTMuNzY4LTQ1Ljk1Mi0yMi45NzEtMi42MDM0LTEuNjQ5OC01LjI1OTYtNy42MDQyLTUuMjU5Ni03LjYwNDJ6bTM2LjIyMSAyOS4zMDVjMS42ODYgMC4wNDE5IDMuMDUxOSAxLjM5MTggMy4wOTU0IDMuMDk3NWwwLjAxNyAwLjY3OTU1YzAuMDQ0OSAxLjc2MDctMS4zMzYzIDMuMjE0My0zLjA5NyAzLjI1OTJsLTI2LjIxNiAwLjY2ODY5Yy0xLjc2MDcgMC4wNDQ5LTMuMjE0My0xLjMzNjMtMy4yNTkyLTMuMDk3bC0wLjAxNzUyLTAuNjgwMDZjLTAuMDQ0OS0xLjc2MDcgMS4zMzY4LTMuMjE0MyAzLjA5NzUtMy4yNTkybDI2LjIxNi0wLjY2ODE4YzAuMDU1LTFlLTMgMC4xMDk0My0yZS0zIDAuMTYzODItNS4xZS00em0tMTEuMjU3IDE1LjI5N2MxLjY4NDkgMC4wMjc4IDMuMDQxNSAxLjM2NiAzLjA3NDIgMy4wNzE2bDAuMDEyOSAwLjY4MDA2YzAuMDMzOCAxLjc2MDctMS4zNTYxIDMuMjI2LTMuMTE2MSAzLjI4NTZsLTE4LjE1OCAwLjYxNTQ3Yy0xLjc2IDAuMDU5Ni0zLjIwNDMtMS4zMDk5LTMuMjM4LTMuMDcwNmwtMC4wMTI5Mi0wLjY3OTU0Yy0wLjAzMzc5LTEuNzYwNyAxLjM1NjEtMy4yMjY1IDMuMTE2MS0zLjI4NjFsMTguMTU4LTAuNjE1NDZjMC4wNTUtMmUtMyAwLjEwOTQ2LTJlLTMgMC4xNjM4MS0xZS0zem0tMTUuNjIgMTQuMTk0YzEuNjQyNCA5ZS0zIDIuOTM5NCAxLjI4NDQgMi45NTQ5IDIuOTYyNmwwLjAwNjIgMC42Nzk1NGMwLjAxNjIyIDEuNzYwNy0xLjM4NDUgMy4yNzc5LTMuMTQwOSAzLjQwMTlsLTUuNDI5MSAwLjM4MzQ0Yy0xLjc1NjQgMC4xMjM5Ni0zLjE4MzYtMS4xOTM2LTMuMTk5OC0yLjk1NDNsLTAuMDA2Mi0wLjY4MDA2Yy0wLjAxNjIyLTEuNzYwNyAxLjM4NDUtMy4yNzc5IDMuMTQwOS0zLjQwMTlsNS40MjkxLTAuMzgyOTNjMC4wODIzMy02ZS0zIDAuMTY0MTctOWUtMyAwLjI0NDk1LThlLTN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.34102" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS42Mm1tIiBoZWlnaHQ9IjE0OS41Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDkuNjIgMTQ5LjU2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxjaXJjbGUgY3g9IjE0MS44MSIgY3k9Ijc1LjYyIiByPSI2LjI1MzkiLz48Y2lyY2xlIGN4PSI3LjgwMzkiIGN5PSI3NS42MiIgcj0iNi4yNTM5Ii8+PHJlY3QgeD0iMy4xNzAyZS03IiB5PSIxMzcuNDkiIHdpZHRoPSIxNDkuNjIiIGhlaWdodD0iMTIuMDY5IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjIuNTc1MiIvPjwvZz48Y2lyY2xlIGN4PSI3NC44MDkiIGN5PSIxMy45NjEiIHI9IjEwLjUxMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjYuOSIvPjxwYXRoIGQ9Im02OS4xNDggMjIuNDY3LTU3LjQ3NCA0OS4xOTIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI0LjUiLz48Zz48cGF0aCBkPSJtNjYuNTk3IDIwLjg4LTQ3LjkyIDEwOC44OSA5LjY4NDctMWUtNSA0Ni4zNDktMTA1LjMyeiIvPjxwYXRoIGQ9Im0xNy43NDcgNzUuMzI2YzAuMDA3MyAwLjA5NzkgMC4wMTMxNiAwLjE5NTk1IDAuMDE3NTcgMC4yOTQwNCA0ZS01IDUuNTAwOC00LjQ1OTMgOS45NjAyLTkuOTYwMSA5Ljk2MDEtMC42NTQ4OS0yZS0zIC0xLjMwOC0wLjA2OS0xLjk0OTgtMC4xOTk0NyAyLjE0NDggNC42Mzk3IDUuNTM4OCAxMS42MzEgOC4yMzgzIDE1LjU2MSAyLjM1NzcgMy40MzI5IDguMzQxMSA5LjMwMTIgOC4zNDExIDkuMzAxMmwwLjM1MTQgMC4xMTYyNyAxNS40MTgtMzUuMDM0em0zNi41NDggOC4xNDI3LTE0LjMzNiAzMi41NzdzMi40MDIyIDEuMjI1OCAzLjcwMjEgMS4yMjU4aDMxLjE0OHYtMjkuMjc5Yy04LjEyNzItMmUtMyAtMTUuNzU4LTEuNjg1LTIwLjUxNS00LjUyMzh6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iLjIiLz48cGF0aCBkPSJtMTMuMzQ5IDY3LjUxM3Y1LjQ0NjJoMjUuODk2bDIuMzk2OC01LjQ0NjJ6Ii8+PHBhdGggZD0ibTU3LjgwNCA3NS4zMjYtMi41NzMxIDUuMzkxNGM1LjE2MDcgMi4wODY1IDEyLjIxNSAzLjI2MjEgMTkuNTc4IDMuMjYyOHYtNi4zMDM1Yy02LjE3MjItMmUtMyAtMTQuMzQ2LTEuNjM4My0xNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTgwLjQ3IDIyLjQ2NyA1Ny40NzQgNDkuMTkyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNC41Ii8+PGc+PHBhdGggZD0ibTgzLjAyMSAyMC44OCA0Ny45MiAxMDguODktOS42ODQ3LTFlLTUgLTQ2LjM0OS0xMDUuMzJ6Ii8+PHBhdGggZD0ibTExMS40MiA3NS4zMjYgMTUuNDE4IDM1LjAzNCAwLjM1MTM5LTAuMTE2MjdzNS45ODM0LTUuODY4NCA4LjM0MTEtOS4zMDEyYzIuNjk5NC0zLjkzMDQgNi4wOTM1LTEwLjkyMiA4LjIzODItMTUuNTYxLTAuNjQxNzcgMC4xMzA0Ny0xLjI5NDkgMC4xOTc0Ny0xLjk0OTggMC4xOTk0Ny01LjUwMDggM2UtNSAtOS45NjAyLTQuNDU5My05Ljk2MDEtOS45NjAxIDRlLTMgLTAuMDk4MDkgMC4wMTA2LTAuMTk2MTQgMC4wMTc2LTAuMjk0MDR6bS0xNi4wOTIgOC4xNDI3Yy00Ljc1NjYgMi44Mzg3LTEyLjM4NyA0LjUyMTgtMjAuNTE1IDQuNTIzOHYyOS4yNzloMzEuMTQ4YzEuMjk5OSAwIDMuNzAyMS0xLjIyNTggMy43MDIxLTEuMjI1OHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMiIvPjxwYXRoIGQ9Im0xMzYuMjcgNjcuNTEzdjUuNDQ2MmgtMjUuODk2bC0yLjM5NjgtNS40NDYyeiIvPjxwYXRoIGQ9Im05MS44MTQgNzUuMzI2IDIuNTczMSA1LjM5MTRjLTUuMTYwNyAyLjA4NjUtMTIuMjE1IDMuMjYyMS0xOS41NzggMy4yNjI4di02LjMwMzVjNi4xNzIyLTJlLTMgMTQuMzQ2LTEuNjM4MyAxNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTc0LjgwOSAxMTcuMzd2LTI5LjQ4MiIgZmlsbD0iIzAwZiIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEuNDciLz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg1LjAyM21tIiBoZWlnaHQ9IjE1Mi43M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4NS4wMjMgMTUyLjczIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im01OCA1OS44ODJ2MTYuMzc0bDguOTcyMSA5LjAyNjNjMy4zNjI3IDMuMzgzMSA3Ljg5NTUgNC4yOTIyIDEwLjE2MyAyLjAzODEgMi4yNjc3LTIuMjU0MSAxLjM4NjEtNi43OTI1LTEuOTc2Ni0xMC4xNzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjQ2NSIvPjxwYXRoIGQ9Im0zNi4zNTUgOTIuNTdjLTIuNjIyNSA0LjUyNjctNS42NDA2IDkuNzQyNC05LjIwNjcgMTUuOTIyLTguMzM2MiAxNC40NDUtMTUuNDA4IDI2LjYzNS0xNS43MTYgMjcuMDktMC45MDA0IDEuMzMyOS0xLjI2MjUgMi41MzU4LTEuMjYwNCA0LjE4NzggMC4wMDE2IDEuMDc5OCAwLjA3MjAxIDEuNTkzNCAwLjMxMzE2IDIuMjgzMSAxLjA3NzkgMy4wODI2IDMuODYyNSA1LjA1NDIgNy4wOTQxIDUuMDIyNCAwLjUxMzQ3LTVlLTMgMS4yNzgyLTAuMTAwNTIgMS42OTk2LTAuMjEyMzkgMS43MDc4LTAuNDUzMzEgMy4xMTE3LTEuNDUxOCA0LjM3MTgtMy4xMDk0IDAuNDMzMzctMC41NzAwNiAxNC45MTktMjUuNTU5IDIzLjQyNS00MC4zMzV6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zOC4wMjQgMjguMzUxYy0wLjU2MjQzLTAuMDA4NS0xLjA5MzQgMC4wMjQ2Ni0xLjQ4MjEgMC4xMDY0NS0wLjQyMTQ2IDAuMDg4NjgtMS4xMTA3IDAuMzAzMjYtMS41MzIyIDAuNDc2OTctMC40MjE0NiAwLjE3MzcxLTYuNDk1OSAzLjYzNTctMTMuNDk4IDcuNjkzMS0xMC40NDQgNi4wNTE1LTEyLjk3NSA3LjUxNTItMTQuMDE3IDguNjcyM2wxNi4wNDQgMC4wMDE2djMuNTYzNmMzLjAwMS0xLjcyODYgNS40Njk5LTMuMDk4OSA1LjU0NTQtMy4wNzM3IDAuMDk2NjEgMC4wMzIyIDAuMTY1OTQgNS40Njk2IDAuMjEyOTEgMTYuNjg1bDAuMDY5NzYgMTYuNjM4IDAuMzI3MTEgMC42MjY4NGMwLjA2NjMzIDAuMTI3MTIgMC42NzQ2MSAwLjc4NDA3IDEuNTg0NCAxLjczNjNsMC4wNjU2My0wLjA2NTExIDI1Ljg5OCAyNi4yMDUgMC4wMjQ4MSAwLjAyNTMgNC42MjYxIDQuNjMwNyA0LjM5MyAxNy42OTVjMy41NjM4IDE0LjM1NSA0LjQ4MzQgMTcuODc5IDQuODczMSAxOC42NzUgMC45NjU3NiAxLjk3MjUgMy4yMDcyIDMuNjI1OCA1LjM3MDIgMy45NjE1IDEuMTQ1OCAwLjE3Nzc4IDEuNTI3NCAwLjE2Njk4IDIuNjQ3NC0wLjA3NTQgMS40NDM4LTAuMzEyNjggMi41OTAyLTAuOTU0OTMgMy42OTQzLTIuMDY5MSAxLjA0OTctMS4wNTkzIDEuNTk3Ni0yLjAwMzMgMS45NDM2LTMuMzQ5NyAwLjQ3MjYxLTEuODM5IDAuNjQ4MzgtMS4wMTY3LTUuMjM3NC0yNC41MDctMi45OTgtMTEuOTY1LTUuNTc1Ni0yMi4xLTUuNzI4My0yMi41MjEtMC4yNTg4Ny0wLjcxNDQtMC45NDY5NS0xLjQzNjItMTAuMTU0LTEwLjY2bC02LjYwOTQtNi42MjE5LTMuMjY2NS0zLjI3MjctMC4yMTcwNC0wLjIxNzA0di0yMi40NTFjLTcuOGUtNCAtMC43ODAyLTAuMDAyNS00LjM3MTMgMC04LjQwODN2LTExLjIyN2MtMC4wODMxNy0xLjM2ODctMS4wMzc1LTEuNzcyMS02Ljg4NDMtNS4xNDctMi45NDgtMS43MDE2LTUuNzA2Ny0zLjIxNzEtNi4xMzA0LTMuMzY4My0wLjYwMDAyLTAuMjE0MDgtMS42MjUyLTAuMzQ0MzktMi41NjI2LTAuMzU4NjN6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zMS4wNjEgOC45MjM5Yy0wLjQyMTk0IDQuMDMyMyAxLjA1OTUgOC4zMjA2IDMuMzI4NCAxMS42OTkgMS4zNDk2IDIuMDA5MyAzLjMxMDIgMy41OTUzIDUuMzI0NCA0LjkzNzUgMi42NDQ4IDEuNzYyNSA1LjU2NzIgMy4yOTE1IDguNjc1MiAzLjk1NjcgMS4xODk2IDAuMjU0NTggMi41MDE2IDAuMzgwMjIgMy42NDk0LTAuMDIyOCAxLjQzNDQtMC41MDM2NSAyLjcyNjEtMS41Njk0IDMuNTc3NC0yLjgyOSAxLjI5NzQtMS45MTk1IDEuNjg4OC00LjM2NjEgMS45Njc3LTYuNjY2IDAuMjg4NjYtMi4zNzk5IDAuMzUxOS00Ljg4NTctMC4zMjgxMi03LjE4NDctMC44MjI3NS0yLjc4MTUtMi40Mjk0LTUuMzc3NS00LjM5NTctNy41MDk5LTEuODEyMi0xLjk2NTMtNC4wNDAyLTMuNzM2My02LjU3MDctNC41OTgzLTIuMzY2Ny0wLjgwNjItNS4wNjA0LTAuOTIzMDQtNy40OTI5LTAuMzQ1LTEuNzAyIDAuNDA0NDMtMy4zNTMzIDEuMzIwNC00LjU3MzUgMi41NzM5LTEuNTc0NiAxLjYxNzYtMi45MjY2IDMuNzQzOC0zLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTE5Ljc4OCA0MC4xOGMtMTAuNzY4IDMuNjUwOC0xMS4zNSAzLjk0OTYtMTIuNTggNS40NjEyLTEuMzI1OCAxLjYyOTUtMS4zNjcgMC45NTI4Mi00LjU1NDYgMTYuOTU3IDAgMC0yLjIyNTcgOS4yMzYtMi42NTA2IDE0LjM4NC0wLjAyMzk1NSAwLjI5MDI0IDAuMTYwMiAwLjg1ODg2IDAuMTYwMiAwLjg1ODg2IDAuMjA5NDIgMS4xMjMzIDEuMTgxNSAyLjcwOTIgMi4wODYyIDMuNDAzNCAyLjc5MzggMi4xNDM3IDYuNTU4NyAxLjQ4MzMgOC41NTM1LTEuNTAwNyAwLjQxOTg1LTAuNjI4MDUgMC40NjgyNS0wLjgzNjk1IDMuMDgwOS0xMy40MzZsMi42NTM2LTEyLjc5OCAwLjE5MTItMC43MTI2MiA5Ljg1MzktNS42NjQ0IDEuMDk0My01LjM2MDJ6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.00612" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwNC42Mm1tIiBoZWlnaHQ9IjE4My44N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDQuNjIgMTgzLjg3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC43NjIyMyAtNTUuOTg0KSI+PHBhdGggZD0ibTE1NC45NyA3NS45OWExMTMuMjIgMTEzLjIyIDAgMCAwLTE1NS43MyAyNi40OTIgMzkuMjYzIDM5LjI2MyAwIDAgMSA1Mi44NTctNy42NDg3IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MiAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NTY0IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MSAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NDkyIDM5LjI2MyAzOS4yNjMgMCAwIDEgMTAuNTcxIDUzLjc3MyAxMTMuMjIgMTEzLjIyIDAgMCAwLTI5LjQxNS0xNTYuNjV6Ii8+PHBhdGggZD0ibTE2LjM5NCAyMDUuOTRzLTIuMjQyNyA1LjczNTctMi4yODM3IDguNzQ5N2MtMC4wNjY3MiA0LjkwNzYgMC4yMDA2NiAxMC41NjIgMy4zMjk4IDE0LjM0MyAzLjEzMjEgMy43ODQ4IDguNTcgNi4xMzc3IDEzLjQ3OSA1Ljk1OTUgNC41MTkzLTAuMTY0MDYgOS4yMDgtMi43OTY0IDExLjk3OC02LjM3MTIgNDYuMjYyLTU5LjcwNiAxMjMuNzItMTY3LjI2IDEyMy43Mi0xNjcuMjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="225,89,137,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="36" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk5LjA0OW1tIiBoZWlnaHQ9IjE2MC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5OS4wNDkgMTYwLjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0zOC4xNjkgMTcuNzk3YTI1LjYxNiAyNS42MTYgMCAwIDAtMjUuNjE3IDI1LjYxNyAyNS42MTYgMjUuNjE2IDAgMCAwIDI1LjYxNyAyNS42MTYgMjUuNjE2IDI1LjYxNiAwIDAgMCAyNS42MTYtMjUuNjE2IDI1LjYxNiAyNS42MTYgMCAwIDAtMC4wNTYzLTEuNjYyOWMtMi42NTQyIDEuMjg1Ny00LjgzNTQgMy40NzYzLTYuNzUgNS43MTk1LTEuMzc0NyAxLjYxMDYtMy4yOTM5IDUuNDMxNy0zLjI5MzkgNS40MzE3cy0zLjg0NDMgMi45ODEzLTUuNjYxNyAyLjExMjVjLTEuOTk1NS0wLjk1Mzk4LTIuMzk3Mi00LjEwMzItMi4wOTg2LTYuMjk0NyAwLjQ2Njg0LTMuNDI2MyAzLjE3NjMtNi4zNDU4IDUuNzk0LTguNjA1MiAyLjk3OS0yLjU3MTMgMTAuNjUtNS4wOTE4IDEwLjY1My01LjA5MjdhMjUuNjE2IDI1LjYxNiAwIDAgMC0xZS0zIC0zZS0zYy05ZS0zIC0wLjAxNzQtMy45MjUtNy40MTI2LTYuODgxMi0xMC4yODMtMS4yMDI1LTEuMTY3Ny0yLjY1MjYtMi4zMzQ0LTQuMjY4LTMuMzYyMWEyNS42MTYgMjUuNjE2IDAgMCAwLTEzLjA1Mi0zLjU3NjZ6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTc1LjM4NCAzOC42OGEyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NiAyMy42NjUgMjMuNjY1IDIzLjY2NSAwIDAgMCAyMy42NjYgMjMuNjY2IDIzLjY2NSAyMy42NjUgMCAwIDAgMjMuNjY1LTIzLjY2NiAyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NS0yMy42NjV6bTIuNTkxNiAxMS44ODdjMy41MTI2IDAuMDU3OSA4LjIwODIgMy43Njk0IDkuNDYyNSA2LjgxNjEgMS44NDkgNC40OTEyLTAuMzE2MDQgMTQuMTg0LTUuNTAzIDEzLjQ4OS0zLjYwNDYtMC40ODM0IDAuMzE1MzItNi43ODg0LTAuNzI3MDgtOS45ODQ0LTEuMTI2Mi0zLjQ1MjktOC41NTY1LTYuODM5Ny01LjgwMzMtOS40MTQ5IDAuNjk2NTMtMC42NTE0OSAxLjU4NzQtMC45MjE1NyAyLjU3MDktMC45MDUzN3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48cGF0aCBkPSJtNTMuNjg1IDUyLjkwMS01LjJlLTQgMWUtM3MtMy44NDQzIDIuOTgxMy01LjY2MTcgMi4xMTI1bC0yNC4wMzUgOS43MzIyIDQzLjg3MyAyMC4wMDN6Ii8+PHBhdGggZD0ibTcxLjEzNyAwYy0xMC4wNDMgMC4wMTIwMi0xOS4wODIgNi4wOTU0LTIyLjg3NSAxNS4zOTUgMi43OTkxIDAuNDYwNjcgNS41MDIyIDEuMzgzMSA3Ljk5OSAyLjcyOTUgMC4yMjgwOSAwLjExNzI2IDAuNDUzNjIgMC4yMzk0MSAwLjY3NjQ0IDAuMzY2MzkgMC4wODUzNSAwLjA0NTY4IDAuMTcwNDUgMC4wOTE4NSAwLjI1NTI4IDAuMTM4NDkgMC4xMzMxNyAwLjA4NDcyIDAuMjYzNDEgMC4xNzE4NSAwLjM5NDI5IDAuMjU4MzggMC42MDg2MiAwLjM4NDEgMS4xOTM1IDAuODA0NjUgMS43NTEzIDEuMjU5NCAwLjc2ODg2IDAuNjAwNzUgMS40ODE2IDEuMjIyMiAyLjEyMjQgMS44NDQzIDIuNzk3OCAyLjcxNjcgNi40MTM2IDkuNDA5MyA2LjgwNTMgMTAuMTQyIDIuMTk3Ni0wLjY2NTI0IDQuNDgwMy0xLjAwNzEgNi43NzYzLTEuMDE0OSA2LjMyNzMgMC4wMDYxIDEyLjM4OSAyLjU0NTggMTYuODMgNy4wNTE4IDIuNjAwNi0zLjk5OSAzLjk4OTUtOC42NjQ2IDMuOTk5Mi0xMy40MzUtNy42ZS01IC0xMy42NjEtMTEuMDc0LTI0LjczNS0yNC43MzUtMjQuNzM1em00Ljc5NjEgOC41NzA1YzQuMDgyNi0wLjA1NzEyIDguMTg0NyA0Ljk5OSA4Ljg5ODcgOS4wNzMzIDAuNzYxOTIgNC4zNDc4LTAuODU4NDcgMTEuNzY4LTUuMTc5NiAxMC44NjctMy4xNjM5LTAuNjU5OS0wLjYxMzY4LTUuNjgwNC0xLjUzNjgtOC43Nzc4LTAuODcyMi0yLjkyNjYtNC40MDYxLTQuOTI3MS00LjUwMS03Ljk3OTQtMC4wMzU3LTEuMTQ4NCAwLjM3NDY4LTIuODg4OSAxLjUwMzgtMy4xMDE2IDAuMjcwOTktMC4wNTEwNyAwLjU0Mjc3LTAuMDc3ODM5IDAuODE0OTQtMC4wODE2NDl6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTEyLjk3MSA2Mi41NzctMTIuOTcxIDk3LjUxOCA3MS4wOTItNjcuNDg5cy00Ljc4MDggMS40NDQtNi45MDk3IDAuNTQ2MjJjLTE2LjEwOS02Ljc5MzQtMzEuNDMtMTMuNzY4LTQ1Ljk1Mi0yMi45NzEtMi42MDM0LTEuNjQ5OC01LjI1OTYtNy42MDQyLTUuMjU5Ni03LjYwNDJ6bTM2LjIyMSAyOS4zMDVjMS42ODYgMC4wNDE5IDMuMDUxOSAxLjM5MTggMy4wOTU0IDMuMDk3NWwwLjAxNyAwLjY3OTU1YzAuMDQ0OSAxLjc2MDctMS4zMzYzIDMuMjE0My0zLjA5NyAzLjI1OTJsLTI2LjIxNiAwLjY2ODY5Yy0xLjc2MDcgMC4wNDQ5LTMuMjE0My0xLjMzNjMtMy4yNTkyLTMuMDk3bC0wLjAxNzUyLTAuNjgwMDZjLTAuMDQ0OS0xLjc2MDcgMS4zMzY4LTMuMjE0MyAzLjA5NzUtMy4yNTkybDI2LjIxNi0wLjY2ODE4YzAuMDU1LTFlLTMgMC4xMDk0My0yZS0zIDAuMTYzODItNS4xZS00em0tMTEuMjU3IDE1LjI5N2MxLjY4NDkgMC4wMjc4IDMuMDQxNSAxLjM2NiAzLjA3NDIgMy4wNzE2bDAuMDEyOSAwLjY4MDA2YzAuMDMzOCAxLjc2MDctMS4zNTYxIDMuMjI2LTMuMTE2MSAzLjI4NTZsLTE4LjE1OCAwLjYxNTQ3Yy0xLjc2IDAuMDU5Ni0zLjIwNDMtMS4zMDk5LTMuMjM4LTMuMDcwNmwtMC4wMTI5Mi0wLjY3OTU0Yy0wLjAzMzc5LTEuNzYwNyAxLjM1NjEtMy4yMjY1IDMuMTE2MS0zLjI4NjFsMTguMTU4LTAuNjE1NDZjMC4wNTUtMmUtMyAwLjEwOTQ2LTJlLTMgMC4xNjM4MS0xZS0zem0tMTUuNjIgMTQuMTk0YzEuNjQyNCA5ZS0zIDIuOTM5NCAxLjI4NDQgMi45NTQ5IDIuOTYyNmwwLjAwNjIgMC42Nzk1NGMwLjAxNjIyIDEuNzYwNy0xLjM4NDUgMy4yNzc5LTMuMTQwOSAzLjQwMTlsLTUuNDI5MSAwLjM4MzQ0Yy0xLjc1NjQgMC4xMjM5Ni0zLjE4MzYtMS4xOTM2LTMuMTk5OC0yLjk1NDNsLTAuMDA2Mi0wLjY4MDA2Yy0wLjAxNjIyLTEuNzYwNyAxLjM4NDUtMy4yNzc5IDMuMTQwOS0zLjQwMTlsNS40MjkxLTAuMzgyOTNjMC4wODIzMy02ZS0zIDAuMTY0MTctOWUtMyAwLjI0NDk1LThlLTN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.34102" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="37" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS42Mm1tIiBoZWlnaHQ9IjE0OS41Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDkuNjIgMTQ5LjU2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxjaXJjbGUgY3g9IjE0MS44MSIgY3k9Ijc1LjYyIiByPSI2LjI1MzkiLz48Y2lyY2xlIGN4PSI3LjgwMzkiIGN5PSI3NS42MiIgcj0iNi4yNTM5Ii8+PHJlY3QgeD0iMy4xNzAyZS03IiB5PSIxMzcuNDkiIHdpZHRoPSIxNDkuNjIiIGhlaWdodD0iMTIuMDY5IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjIuNTc1MiIvPjwvZz48Y2lyY2xlIGN4PSI3NC44MDkiIGN5PSIxMy45NjEiIHI9IjEwLjUxMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjYuOSIvPjxwYXRoIGQ9Im02OS4xNDggMjIuNDY3LTU3LjQ3NCA0OS4xOTIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI0LjUiLz48Zz48cGF0aCBkPSJtNjYuNTk3IDIwLjg4LTQ3LjkyIDEwOC44OSA5LjY4NDctMWUtNSA0Ni4zNDktMTA1LjMyeiIvPjxwYXRoIGQ9Im0xNy43NDcgNzUuMzI2YzAuMDA3MyAwLjA5NzkgMC4wMTMxNiAwLjE5NTk1IDAuMDE3NTcgMC4yOTQwNCA0ZS01IDUuNTAwOC00LjQ1OTMgOS45NjAyLTkuOTYwMSA5Ljk2MDEtMC42NTQ4OS0yZS0zIC0xLjMwOC0wLjA2OS0xLjk0OTgtMC4xOTk0NyAyLjE0NDggNC42Mzk3IDUuNTM4OCAxMS42MzEgOC4yMzgzIDE1LjU2MSAyLjM1NzcgMy40MzI5IDguMzQxMSA5LjMwMTIgOC4zNDExIDkuMzAxMmwwLjM1MTQgMC4xMTYyNyAxNS40MTgtMzUuMDM0em0zNi41NDggOC4xNDI3LTE0LjMzNiAzMi41NzdzMi40MDIyIDEuMjI1OCAzLjcwMjEgMS4yMjU4aDMxLjE0OHYtMjkuMjc5Yy04LjEyNzItMmUtMyAtMTUuNzU4LTEuNjg1LTIwLjUxNS00LjUyMzh6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iLjIiLz48cGF0aCBkPSJtMTMuMzQ5IDY3LjUxM3Y1LjQ0NjJoMjUuODk2bDIuMzk2OC01LjQ0NjJ6Ii8+PHBhdGggZD0ibTU3LjgwNCA3NS4zMjYtMi41NzMxIDUuMzkxNGM1LjE2MDcgMi4wODY1IDEyLjIxNSAzLjI2MjEgMTkuNTc4IDMuMjYyOHYtNi4zMDM1Yy02LjE3MjItMmUtMyAtMTQuMzQ2LTEuNjM4My0xNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTgwLjQ3IDIyLjQ2NyA1Ny40NzQgNDkuMTkyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNC41Ii8+PGc+PHBhdGggZD0ibTgzLjAyMSAyMC44OCA0Ny45MiAxMDguODktOS42ODQ3LTFlLTUgLTQ2LjM0OS0xMDUuMzJ6Ii8+PHBhdGggZD0ibTExMS40MiA3NS4zMjYgMTUuNDE4IDM1LjAzNCAwLjM1MTM5LTAuMTE2MjdzNS45ODM0LTUuODY4NCA4LjM0MTEtOS4zMDEyYzIuNjk5NC0zLjkzMDQgNi4wOTM1LTEwLjkyMiA4LjIzODItMTUuNTYxLTAuNjQxNzcgMC4xMzA0Ny0xLjI5NDkgMC4xOTc0Ny0xLjk0OTggMC4xOTk0Ny01LjUwMDggM2UtNSAtOS45NjAyLTQuNDU5My05Ljk2MDEtOS45NjAxIDRlLTMgLTAuMDk4MDkgMC4wMTA2LTAuMTk2MTQgMC4wMTc2LTAuMjk0MDR6bS0xNi4wOTIgOC4xNDI3Yy00Ljc1NjYgMi44Mzg3LTEyLjM4NyA0LjUyMTgtMjAuNTE1IDQuNTIzOHYyOS4yNzloMzEuMTQ4YzEuMjk5OSAwIDMuNzAyMS0xLjIyNTggMy43MDIxLTEuMjI1OHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMiIvPjxwYXRoIGQ9Im0xMzYuMjcgNjcuNTEzdjUuNDQ2MmgtMjUuODk2bC0yLjM5NjgtNS40NDYyeiIvPjxwYXRoIGQ9Im05MS44MTQgNzUuMzI2IDIuNTczMSA1LjM5MTRjLTUuMTYwNyAyLjA4NjUtMTIuMjE1IDMuMjYyMS0xOS41NzggMy4yNjI4di02LjMwMzVjNi4xNzIyLTJlLTMgMTQuMzQ2LTEuNjM4MyAxNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTc0LjgwOSAxMTcuMzd2LTI5LjQ4MiIgZmlsbD0iIzAwZiIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEuNDciLz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="38" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg1LjAyM21tIiBoZWlnaHQ9IjE1Mi43M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4NS4wMjMgMTUyLjczIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im01OCA1OS44ODJ2MTYuMzc0bDguOTcyMSA5LjAyNjNjMy4zNjI3IDMuMzgzMSA3Ljg5NTUgNC4yOTIyIDEwLjE2MyAyLjAzODEgMi4yNjc3LTIuMjU0MSAxLjM4NjEtNi43OTI1LTEuOTc2Ni0xMC4xNzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjQ2NSIvPjxwYXRoIGQ9Im0zNi4zNTUgOTIuNTdjLTIuNjIyNSA0LjUyNjctNS42NDA2IDkuNzQyNC05LjIwNjcgMTUuOTIyLTguMzM2MiAxNC40NDUtMTUuNDA4IDI2LjYzNS0xNS43MTYgMjcuMDktMC45MDA0IDEuMzMyOS0xLjI2MjUgMi41MzU4LTEuMjYwNCA0LjE4NzggMC4wMDE2IDEuMDc5OCAwLjA3MjAxIDEuNTkzNCAwLjMxMzE2IDIuMjgzMSAxLjA3NzkgMy4wODI2IDMuODYyNSA1LjA1NDIgNy4wOTQxIDUuMDIyNCAwLjUxMzQ3LTVlLTMgMS4yNzgyLTAuMTAwNTIgMS42OTk2LTAuMjEyMzkgMS43MDc4LTAuNDUzMzEgMy4xMTE3LTEuNDUxOCA0LjM3MTgtMy4xMDk0IDAuNDMzMzctMC41NzAwNiAxNC45MTktMjUuNTU5IDIzLjQyNS00MC4zMzV6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zOC4wMjQgMjguMzUxYy0wLjU2MjQzLTAuMDA4NS0xLjA5MzQgMC4wMjQ2Ni0xLjQ4MjEgMC4xMDY0NS0wLjQyMTQ2IDAuMDg4NjgtMS4xMTA3IDAuMzAzMjYtMS41MzIyIDAuNDc2OTctMC40MjE0NiAwLjE3MzcxLTYuNDk1OSAzLjYzNTctMTMuNDk4IDcuNjkzMS0xMC40NDQgNi4wNTE1LTEyLjk3NSA3LjUxNTItMTQuMDE3IDguNjcyM2wxNi4wNDQgMC4wMDE2djMuNTYzNmMzLjAwMS0xLjcyODYgNS40Njk5LTMuMDk4OSA1LjU0NTQtMy4wNzM3IDAuMDk2NjEgMC4wMzIyIDAuMTY1OTQgNS40Njk2IDAuMjEyOTEgMTYuNjg1bDAuMDY5NzYgMTYuNjM4IDAuMzI3MTEgMC42MjY4NGMwLjA2NjMzIDAuMTI3MTIgMC42NzQ2MSAwLjc4NDA3IDEuNTg0NCAxLjczNjNsMC4wNjU2My0wLjA2NTExIDI1Ljg5OCAyNi4yMDUgMC4wMjQ4MSAwLjAyNTMgNC42MjYxIDQuNjMwNyA0LjM5MyAxNy42OTVjMy41NjM4IDE0LjM1NSA0LjQ4MzQgMTcuODc5IDQuODczMSAxOC42NzUgMC45NjU3NiAxLjk3MjUgMy4yMDcyIDMuNjI1OCA1LjM3MDIgMy45NjE1IDEuMTQ1OCAwLjE3Nzc4IDEuNTI3NCAwLjE2Njk4IDIuNjQ3NC0wLjA3NTQgMS40NDM4LTAuMzEyNjggMi41OTAyLTAuOTU0OTMgMy42OTQzLTIuMDY5MSAxLjA0OTctMS4wNTkzIDEuNTk3Ni0yLjAwMzMgMS45NDM2LTMuMzQ5NyAwLjQ3MjYxLTEuODM5IDAuNjQ4MzgtMS4wMTY3LTUuMjM3NC0yNC41MDctMi45OTgtMTEuOTY1LTUuNTc1Ni0yMi4xLTUuNzI4My0yMi41MjEtMC4yNTg4Ny0wLjcxNDQtMC45NDY5NS0xLjQzNjItMTAuMTU0LTEwLjY2bC02LjYwOTQtNi42MjE5LTMuMjY2NS0zLjI3MjctMC4yMTcwNC0wLjIxNzA0di0yMi40NTFjLTcuOGUtNCAtMC43ODAyLTAuMDAyNS00LjM3MTMgMC04LjQwODN2LTExLjIyN2MtMC4wODMxNy0xLjM2ODctMS4wMzc1LTEuNzcyMS02Ljg4NDMtNS4xNDctMi45NDgtMS43MDE2LTUuNzA2Ny0zLjIxNzEtNi4xMzA0LTMuMzY4My0wLjYwMDAyLTAuMjE0MDgtMS42MjUyLTAuMzQ0MzktMi41NjI2LTAuMzU4NjN6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zMS4wNjEgOC45MjM5Yy0wLjQyMTk0IDQuMDMyMyAxLjA1OTUgOC4zMjA2IDMuMzI4NCAxMS42OTkgMS4zNDk2IDIuMDA5MyAzLjMxMDIgMy41OTUzIDUuMzI0NCA0LjkzNzUgMi42NDQ4IDEuNzYyNSA1LjU2NzIgMy4yOTE1IDguNjc1MiAzLjk1NjcgMS4xODk2IDAuMjU0NTggMi41MDE2IDAuMzgwMjIgMy42NDk0LTAuMDIyOCAxLjQzNDQtMC41MDM2NSAyLjcyNjEtMS41Njk0IDMuNTc3NC0yLjgyOSAxLjI5NzQtMS45MTk1IDEuNjg4OC00LjM2NjEgMS45Njc3LTYuNjY2IDAuMjg4NjYtMi4zNzk5IDAuMzUxOS00Ljg4NTctMC4zMjgxMi03LjE4NDctMC44MjI3NS0yLjc4MTUtMi40Mjk0LTUuMzc3NS00LjM5NTctNy41MDk5LTEuODEyMi0xLjk2NTMtNC4wNDAyLTMuNzM2My02LjU3MDctNC41OTgzLTIuMzY2Ny0wLjgwNjItNS4wNjA0LTAuOTIzMDQtNy40OTI5LTAuMzQ1LTEuNzAyIDAuNDA0NDMtMy4zNTMzIDEuMzIwNC00LjU3MzUgMi41NzM5LTEuNTc0NiAxLjYxNzYtMi45MjY2IDMuNzQzOC0zLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTE5Ljc4OCA0MC4xOGMtMTAuNzY4IDMuNjUwOC0xMS4zNSAzLjk0OTYtMTIuNTggNS40NjEyLTEuMzI1OCAxLjYyOTUtMS4zNjcgMC45NTI4Mi00LjU1NDYgMTYuOTU3IDAgMC0yLjIyNTcgOS4yMzYtMi42NTA2IDE0LjM4NC0wLjAyMzk1NSAwLjI5MDI0IDAuMTYwMiAwLjg1ODg2IDAuMTYwMiAwLjg1ODg2IDAuMjA5NDIgMS4xMjMzIDEuMTgxNSAyLjcwOTIgMi4wODYyIDMuNDAzNCAyLjc5MzggMi4xNDM3IDYuNTU4NyAxLjQ4MzMgOC41NTM1LTEuNTAwNyAwLjQxOTg1LTAuNjI4MDUgMC40NjgyNS0wLjgzNjk1IDMuMDgwOS0xMy40MzZsMi42NTM2LTEyLjc5OCAwLjE5MTItMC43MTI2MiA5Ljg1MzktNS42NjQ0IDEuMDk0My01LjM2MDJ6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.00612" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="39" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwNC42Mm1tIiBoZWlnaHQ9IjE4My44N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDQuNjIgMTgzLjg3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC43NjIyMyAtNTUuOTg0KSI+PHBhdGggZD0ibTE1NC45NyA3NS45OWExMTMuMjIgMTEzLjIyIDAgMCAwLTE1NS43MyAyNi40OTIgMzkuMjYzIDM5LjI2MyAwIDAgMSA1Mi44NTctNy42NDg3IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MiAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NTY0IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MSAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NDkyIDM5LjI2MyAzOS4yNjMgMCAwIDEgMTAuNTcxIDUzLjc3MyAxMTMuMjIgMTEzLjIyIDAgMCAwLTI5LjQxNS0xNTYuNjV6Ii8+PHBhdGggZD0ibTE2LjM5NCAyMDUuOTRzLTIuMjQyNyA1LjczNTctMi4yODM3IDguNzQ5N2MtMC4wNjY3MiA0LjkwNzYgMC4yMDA2NiAxMC41NjIgMy4zMjk4IDE0LjM0MyAzLjEzMjEgMy43ODQ4IDguNTcgNi4xMzc3IDEzLjQ3OSA1Ljk1OTUgNC41MTkzLTAuMTY0MDYgOS4yMDgtMi43OTY0IDExLjk3OC02LjM3MTIgNDYuMjYyLTU5LjcwNiAxMjMuNzItMTY3LjI2IDEyMy43Mi0xNjcuMjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwNC42Mm1tIiBoZWlnaHQ9IjE4My44N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDQuNjIgMTgzLjg3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC43NjIyMyAtNTUuOTg0KSI+PHBhdGggZD0ibTE1NC45NyA3NS45OWExMTMuMjIgMTEzLjIyIDAgMCAwLTE1NS43MyAyNi40OTIgMzkuMjYzIDM5LjI2MyAwIDAgMSA1Mi44NTctNy42NDg3IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MiAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NTY0IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MSAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NDkyIDM5LjI2MyAzOS4yNjMgMCAwIDEgMTAuNTcxIDUzLjc3MyAxMTMuMjIgMTEzLjIyIDAgMCAwLTI5LjQxNS0xNTYuNjV6Ii8+PHBhdGggZD0ibTE2LjM5NCAyMDUuOTRzLTIuMjQyNyA1LjczNTctMi4yODM3IDguNzQ5N2MtMC4wNjY3MiA0LjkwNzYgMC4yMDA2NiAxMC41NjIgMy4zMjk4IDE0LjM0MyAzLjEzMjEgMy43ODQ4IDguNTcgNi4xMzc3IDEzLjQ3OSA1Ljk1OTUgNC41MTkzLTAuMTY0MDYgOS4yMDgtMi43OTY0IDExLjk3OC02LjM3MTIgNDYuMjYyLTU5LjcwNiAxMjMuNzItMTY3LjI2IDEyMy43Mi0xNjcuMjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="40" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,178,151,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="41" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk5LjA0OW1tIiBoZWlnaHQ9IjE2MC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5OS4wNDkgMTYwLjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0zOC4xNjkgMTcuNzk3YTI1LjYxNiAyNS42MTYgMCAwIDAtMjUuNjE3IDI1LjYxNyAyNS42MTYgMjUuNjE2IDAgMCAwIDI1LjYxNyAyNS42MTYgMjUuNjE2IDI1LjYxNiAwIDAgMCAyNS42MTYtMjUuNjE2IDI1LjYxNiAyNS42MTYgMCAwIDAtMC4wNTYzLTEuNjYyOWMtMi42NTQyIDEuMjg1Ny00LjgzNTQgMy40NzYzLTYuNzUgNS43MTk1LTEuMzc0NyAxLjYxMDYtMy4yOTM5IDUuNDMxNy0zLjI5MzkgNS40MzE3cy0zLjg0NDMgMi45ODEzLTUuNjYxNyAyLjExMjVjLTEuOTk1NS0wLjk1Mzk4LTIuMzk3Mi00LjEwMzItMi4wOTg2LTYuMjk0NyAwLjQ2Njg0LTMuNDI2MyAzLjE3NjMtNi4zNDU4IDUuNzk0LTguNjA1MiAyLjk3OS0yLjU3MTMgMTAuNjUtNS4wOTE4IDEwLjY1My01LjA5MjdhMjUuNjE2IDI1LjYxNiAwIDAgMC0xZS0zIC0zZS0zYy05ZS0zIC0wLjAxNzQtMy45MjUtNy40MTI2LTYuODgxMi0xMC4yODMtMS4yMDI1LTEuMTY3Ny0yLjY1MjYtMi4zMzQ0LTQuMjY4LTMuMzYyMWEyNS42MTYgMjUuNjE2IDAgMCAwLTEzLjA1Mi0zLjU3NjZ6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTc1LjM4NCAzOC42OGEyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NiAyMy42NjUgMjMuNjY1IDIzLjY2NSAwIDAgMCAyMy42NjYgMjMuNjY2IDIzLjY2NSAyMy42NjUgMCAwIDAgMjMuNjY1LTIzLjY2NiAyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NS0yMy42NjV6bTIuNTkxNiAxMS44ODdjMy41MTI2IDAuMDU3OSA4LjIwODIgMy43Njk0IDkuNDYyNSA2LjgxNjEgMS44NDkgNC40OTEyLTAuMzE2MDQgMTQuMTg0LTUuNTAzIDEzLjQ4OS0zLjYwNDYtMC40ODM0IDAuMzE1MzItNi43ODg0LTAuNzI3MDgtOS45ODQ0LTEuMTI2Mi0zLjQ1MjktOC41NTY1LTYuODM5Ny01LjgwMzMtOS40MTQ5IDAuNjk2NTMtMC42NTE0OSAxLjU4NzQtMC45MjE1NyAyLjU3MDktMC45MDUzN3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48cGF0aCBkPSJtNTMuNjg1IDUyLjkwMS01LjJlLTQgMWUtM3MtMy44NDQzIDIuOTgxMy01LjY2MTcgMi4xMTI1bC0yNC4wMzUgOS43MzIyIDQzLjg3MyAyMC4wMDN6Ii8+PHBhdGggZD0ibTcxLjEzNyAwYy0xMC4wNDMgMC4wMTIwMi0xOS4wODIgNi4wOTU0LTIyLjg3NSAxNS4zOTUgMi43OTkxIDAuNDYwNjcgNS41MDIyIDEuMzgzMSA3Ljk5OSAyLjcyOTUgMC4yMjgwOSAwLjExNzI2IDAuNDUzNjIgMC4yMzk0MSAwLjY3NjQ0IDAuMzY2MzkgMC4wODUzNSAwLjA0NTY4IDAuMTcwNDUgMC4wOTE4NSAwLjI1NTI4IDAuMTM4NDkgMC4xMzMxNyAwLjA4NDcyIDAuMjYzNDEgMC4xNzE4NSAwLjM5NDI5IDAuMjU4MzggMC42MDg2MiAwLjM4NDEgMS4xOTM1IDAuODA0NjUgMS43NTEzIDEuMjU5NCAwLjc2ODg2IDAuNjAwNzUgMS40ODE2IDEuMjIyMiAyLjEyMjQgMS44NDQzIDIuNzk3OCAyLjcxNjcgNi40MTM2IDkuNDA5MyA2LjgwNTMgMTAuMTQyIDIuMTk3Ni0wLjY2NTI0IDQuNDgwMy0xLjAwNzEgNi43NzYzLTEuMDE0OSA2LjMyNzMgMC4wMDYxIDEyLjM4OSAyLjU0NTggMTYuODMgNy4wNTE4IDIuNjAwNi0zLjk5OSAzLjk4OTUtOC42NjQ2IDMuOTk5Mi0xMy40MzUtNy42ZS01IC0xMy42NjEtMTEuMDc0LTI0LjczNS0yNC43MzUtMjQuNzM1em00Ljc5NjEgOC41NzA1YzQuMDgyNi0wLjA1NzEyIDguMTg0NyA0Ljk5OSA4Ljg5ODcgOS4wNzMzIDAuNzYxOTIgNC4zNDc4LTAuODU4NDcgMTEuNzY4LTUuMTc5NiAxMC44NjctMy4xNjM5LTAuNjU5OS0wLjYxMzY4LTUuNjgwNC0xLjUzNjgtOC43Nzc4LTAuODcyMi0yLjkyNjYtNC40MDYxLTQuOTI3MS00LjUwMS03Ljk3OTQtMC4wMzU3LTEuMTQ4NCAwLjM3NDY4LTIuODg4OSAxLjUwMzgtMy4xMDE2IDAuMjcwOTktMC4wNTEwNyAwLjU0Mjc3LTAuMDc3ODM5IDAuODE0OTQtMC4wODE2NDl6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTEyLjk3MSA2Mi41NzctMTIuOTcxIDk3LjUxOCA3MS4wOTItNjcuNDg5cy00Ljc4MDggMS40NDQtNi45MDk3IDAuNTQ2MjJjLTE2LjEwOS02Ljc5MzQtMzEuNDMtMTMuNzY4LTQ1Ljk1Mi0yMi45NzEtMi42MDM0LTEuNjQ5OC01LjI1OTYtNy42MDQyLTUuMjU5Ni03LjYwNDJ6bTM2LjIyMSAyOS4zMDVjMS42ODYgMC4wNDE5IDMuMDUxOSAxLjM5MTggMy4wOTU0IDMuMDk3NWwwLjAxNyAwLjY3OTU1YzAuMDQ0OSAxLjc2MDctMS4zMzYzIDMuMjE0My0zLjA5NyAzLjI1OTJsLTI2LjIxNiAwLjY2ODY5Yy0xLjc2MDcgMC4wNDQ5LTMuMjE0My0xLjMzNjMtMy4yNTkyLTMuMDk3bC0wLjAxNzUyLTAuNjgwMDZjLTAuMDQ0OS0xLjc2MDcgMS4zMzY4LTMuMjE0MyAzLjA5NzUtMy4yNTkybDI2LjIxNi0wLjY2ODE4YzAuMDU1LTFlLTMgMC4xMDk0My0yZS0zIDAuMTYzODItNS4xZS00em0tMTEuMjU3IDE1LjI5N2MxLjY4NDkgMC4wMjc4IDMuMDQxNSAxLjM2NiAzLjA3NDIgMy4wNzE2bDAuMDEyOSAwLjY4MDA2YzAuMDMzOCAxLjc2MDctMS4zNTYxIDMuMjI2LTMuMTE2MSAzLjI4NTZsLTE4LjE1OCAwLjYxNTQ3Yy0xLjc2IDAuMDU5Ni0zLjIwNDMtMS4zMDk5LTMuMjM4LTMuMDcwNmwtMC4wMTI5Mi0wLjY3OTU0Yy0wLjAzMzc5LTEuNzYwNyAxLjM1NjEtMy4yMjY1IDMuMTE2MS0zLjI4NjFsMTguMTU4LTAuNjE1NDZjMC4wNTUtMmUtMyAwLjEwOTQ2LTJlLTMgMC4xNjM4MS0xZS0zem0tMTUuNjIgMTQuMTk0YzEuNjQyNCA5ZS0zIDIuOTM5NCAxLjI4NDQgMi45NTQ5IDIuOTYyNmwwLjAwNjIgMC42Nzk1NGMwLjAxNjIyIDEuNzYwNy0xLjM4NDUgMy4yNzc5LTMuMTQwOSAzLjQwMTlsLTUuNDI5MSAwLjM4MzQ0Yy0xLjc1NjQgMC4xMjM5Ni0zLjE4MzYtMS4xOTM2LTMuMTk5OC0yLjk1NDNsLTAuMDA2Mi0wLjY4MDA2Yy0wLjAxNjIyLTEuNzYwNyAxLjM4NDUtMy4yNzc5IDMuMTQwOS0zLjQwMTlsNS40MjkxLTAuMzgyOTNjMC4wODIzMy02ZS0zIDAuMTY0MTctOWUtMyAwLjI0NDk1LThlLTN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.34102" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="42" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS42Mm1tIiBoZWlnaHQ9IjE0OS41Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDkuNjIgMTQ5LjU2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxjaXJjbGUgY3g9IjE0MS44MSIgY3k9Ijc1LjYyIiByPSI2LjI1MzkiLz48Y2lyY2xlIGN4PSI3LjgwMzkiIGN5PSI3NS42MiIgcj0iNi4yNTM5Ii8+PHJlY3QgeD0iMy4xNzAyZS03IiB5PSIxMzcuNDkiIHdpZHRoPSIxNDkuNjIiIGhlaWdodD0iMTIuMDY5IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjIuNTc1MiIvPjwvZz48Y2lyY2xlIGN4PSI3NC44MDkiIGN5PSIxMy45NjEiIHI9IjEwLjUxMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjYuOSIvPjxwYXRoIGQ9Im02OS4xNDggMjIuNDY3LTU3LjQ3NCA0OS4xOTIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI0LjUiLz48Zz48cGF0aCBkPSJtNjYuNTk3IDIwLjg4LTQ3LjkyIDEwOC44OSA5LjY4NDctMWUtNSA0Ni4zNDktMTA1LjMyeiIvPjxwYXRoIGQ9Im0xNy43NDcgNzUuMzI2YzAuMDA3MyAwLjA5NzkgMC4wMTMxNiAwLjE5NTk1IDAuMDE3NTcgMC4yOTQwNCA0ZS01IDUuNTAwOC00LjQ1OTMgOS45NjAyLTkuOTYwMSA5Ljk2MDEtMC42NTQ4OS0yZS0zIC0xLjMwOC0wLjA2OS0xLjk0OTgtMC4xOTk0NyAyLjE0NDggNC42Mzk3IDUuNTM4OCAxMS42MzEgOC4yMzgzIDE1LjU2MSAyLjM1NzcgMy40MzI5IDguMzQxMSA5LjMwMTIgOC4zNDExIDkuMzAxMmwwLjM1MTQgMC4xMTYyNyAxNS40MTgtMzUuMDM0em0zNi41NDggOC4xNDI3LTE0LjMzNiAzMi41NzdzMi40MDIyIDEuMjI1OCAzLjcwMjEgMS4yMjU4aDMxLjE0OHYtMjkuMjc5Yy04LjEyNzItMmUtMyAtMTUuNzU4LTEuNjg1LTIwLjUxNS00LjUyMzh6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iLjIiLz48cGF0aCBkPSJtMTMuMzQ5IDY3LjUxM3Y1LjQ0NjJoMjUuODk2bDIuMzk2OC01LjQ0NjJ6Ii8+PHBhdGggZD0ibTU3LjgwNCA3NS4zMjYtMi41NzMxIDUuMzkxNGM1LjE2MDcgMi4wODY1IDEyLjIxNSAzLjI2MjEgMTkuNTc4IDMuMjYyOHYtNi4zMDM1Yy02LjE3MjItMmUtMyAtMTQuMzQ2LTEuNjM4My0xNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTgwLjQ3IDIyLjQ2NyA1Ny40NzQgNDkuMTkyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNC41Ii8+PGc+PHBhdGggZD0ibTgzLjAyMSAyMC44OCA0Ny45MiAxMDguODktOS42ODQ3LTFlLTUgLTQ2LjM0OS0xMDUuMzJ6Ii8+PHBhdGggZD0ibTExMS40MiA3NS4zMjYgMTUuNDE4IDM1LjAzNCAwLjM1MTM5LTAuMTE2MjdzNS45ODM0LTUuODY4NCA4LjM0MTEtOS4zMDEyYzIuNjk5NC0zLjkzMDQgNi4wOTM1LTEwLjkyMiA4LjIzODItMTUuNTYxLTAuNjQxNzcgMC4xMzA0Ny0xLjI5NDkgMC4xOTc0Ny0xLjk0OTggMC4xOTk0Ny01LjUwMDggM2UtNSAtOS45NjAyLTQuNDU5My05Ljk2MDEtOS45NjAxIDRlLTMgLTAuMDk4MDkgMC4wMTA2LTAuMTk2MTQgMC4wMTc2LTAuMjk0MDR6bS0xNi4wOTIgOC4xNDI3Yy00Ljc1NjYgMi44Mzg3LTEyLjM4NyA0LjUyMTgtMjAuNTE1IDQuNTIzOHYyOS4yNzloMzEuMTQ4YzEuMjk5OSAwIDMuNzAyMS0xLjIyNTggMy43MDIxLTEuMjI1OHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMiIvPjxwYXRoIGQ9Im0xMzYuMjcgNjcuNTEzdjUuNDQ2MmgtMjUuODk2bC0yLjM5NjgtNS40NDYyeiIvPjxwYXRoIGQ9Im05MS44MTQgNzUuMzI2IDIuNTczMSA1LjM5MTRjLTUuMTYwNyAyLjA4NjUtMTIuMjE1IDMuMjYyMS0xOS41NzggMy4yNjI4di02LjMwMzVjNi4xNzIyLTJlLTMgMTQuMzQ2LTEuNjM4MyAxNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTc0LjgwOSAxMTcuMzd2LTI5LjQ4MiIgZmlsbD0iIzAwZiIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEuNDciLz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="43" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg1LjAyM21tIiBoZWlnaHQ9IjE1Mi43M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4NS4wMjMgMTUyLjczIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im01OCA1OS44ODJ2MTYuMzc0bDguOTcyMSA5LjAyNjNjMy4zNjI3IDMuMzgzMSA3Ljg5NTUgNC4yOTIyIDEwLjE2MyAyLjAzODEgMi4yNjc3LTIuMjU0MSAxLjM4NjEtNi43OTI1LTEuOTc2Ni0xMC4xNzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjQ2NSIvPjxwYXRoIGQ9Im0zNi4zNTUgOTIuNTdjLTIuNjIyNSA0LjUyNjctNS42NDA2IDkuNzQyNC05LjIwNjcgMTUuOTIyLTguMzM2MiAxNC40NDUtMTUuNDA4IDI2LjYzNS0xNS43MTYgMjcuMDktMC45MDA0IDEuMzMyOS0xLjI2MjUgMi41MzU4LTEuMjYwNCA0LjE4NzggMC4wMDE2IDEuMDc5OCAwLjA3MjAxIDEuNTkzNCAwLjMxMzE2IDIuMjgzMSAxLjA3NzkgMy4wODI2IDMuODYyNSA1LjA1NDIgNy4wOTQxIDUuMDIyNCAwLjUxMzQ3LTVlLTMgMS4yNzgyLTAuMTAwNTIgMS42OTk2LTAuMjEyMzkgMS43MDc4LTAuNDUzMzEgMy4xMTE3LTEuNDUxOCA0LjM3MTgtMy4xMDk0IDAuNDMzMzctMC41NzAwNiAxNC45MTktMjUuNTU5IDIzLjQyNS00MC4zMzV6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zOC4wMjQgMjguMzUxYy0wLjU2MjQzLTAuMDA4NS0xLjA5MzQgMC4wMjQ2Ni0xLjQ4MjEgMC4xMDY0NS0wLjQyMTQ2IDAuMDg4NjgtMS4xMTA3IDAuMzAzMjYtMS41MzIyIDAuNDc2OTctMC40MjE0NiAwLjE3MzcxLTYuNDk1OSAzLjYzNTctMTMuNDk4IDcuNjkzMS0xMC40NDQgNi4wNTE1LTEyLjk3NSA3LjUxNTItMTQuMDE3IDguNjcyM2wxNi4wNDQgMC4wMDE2djMuNTYzNmMzLjAwMS0xLjcyODYgNS40Njk5LTMuMDk4OSA1LjU0NTQtMy4wNzM3IDAuMDk2NjEgMC4wMzIyIDAuMTY1OTQgNS40Njk2IDAuMjEyOTEgMTYuNjg1bDAuMDY5NzYgMTYuNjM4IDAuMzI3MTEgMC42MjY4NGMwLjA2NjMzIDAuMTI3MTIgMC42NzQ2MSAwLjc4NDA3IDEuNTg0NCAxLjczNjNsMC4wNjU2My0wLjA2NTExIDI1Ljg5OCAyNi4yMDUgMC4wMjQ4MSAwLjAyNTMgNC42MjYxIDQuNjMwNyA0LjM5MyAxNy42OTVjMy41NjM4IDE0LjM1NSA0LjQ4MzQgMTcuODc5IDQuODczMSAxOC42NzUgMC45NjU3NiAxLjk3MjUgMy4yMDcyIDMuNjI1OCA1LjM3MDIgMy45NjE1IDEuMTQ1OCAwLjE3Nzc4IDEuNTI3NCAwLjE2Njk4IDIuNjQ3NC0wLjA3NTQgMS40NDM4LTAuMzEyNjggMi41OTAyLTAuOTU0OTMgMy42OTQzLTIuMDY5MSAxLjA0OTctMS4wNTkzIDEuNTk3Ni0yLjAwMzMgMS45NDM2LTMuMzQ5NyAwLjQ3MjYxLTEuODM5IDAuNjQ4MzgtMS4wMTY3LTUuMjM3NC0yNC41MDctMi45OTgtMTEuOTY1LTUuNTc1Ni0yMi4xLTUuNzI4My0yMi41MjEtMC4yNTg4Ny0wLjcxNDQtMC45NDY5NS0xLjQzNjItMTAuMTU0LTEwLjY2bC02LjYwOTQtNi42MjE5LTMuMjY2NS0zLjI3MjctMC4yMTcwNC0wLjIxNzA0di0yMi40NTFjLTcuOGUtNCAtMC43ODAyLTAuMDAyNS00LjM3MTMgMC04LjQwODN2LTExLjIyN2MtMC4wODMxNy0xLjM2ODctMS4wMzc1LTEuNzcyMS02Ljg4NDMtNS4xNDctMi45NDgtMS43MDE2LTUuNzA2Ny0zLjIxNzEtNi4xMzA0LTMuMzY4My0wLjYwMDAyLTAuMjE0MDgtMS42MjUyLTAuMzQ0MzktMi41NjI2LTAuMzU4NjN6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zMS4wNjEgOC45MjM5Yy0wLjQyMTk0IDQuMDMyMyAxLjA1OTUgOC4zMjA2IDMuMzI4NCAxMS42OTkgMS4zNDk2IDIuMDA5MyAzLjMxMDIgMy41OTUzIDUuMzI0NCA0LjkzNzUgMi42NDQ4IDEuNzYyNSA1LjU2NzIgMy4yOTE1IDguNjc1MiAzLjk1NjcgMS4xODk2IDAuMjU0NTggMi41MDE2IDAuMzgwMjIgMy42NDk0LTAuMDIyOCAxLjQzNDQtMC41MDM2NSAyLjcyNjEtMS41Njk0IDMuNTc3NC0yLjgyOSAxLjI5NzQtMS45MTk1IDEuNjg4OC00LjM2NjEgMS45Njc3LTYuNjY2IDAuMjg4NjYtMi4zNzk5IDAuMzUxOS00Ljg4NTctMC4zMjgxMi03LjE4NDctMC44MjI3NS0yLjc4MTUtMi40Mjk0LTUuMzc3NS00LjM5NTctNy41MDk5LTEuODEyMi0xLjk2NTMtNC4wNDAyLTMuNzM2My02LjU3MDctNC41OTgzLTIuMzY2Ny0wLjgwNjItNS4wNjA0LTAuOTIzMDQtNy40OTI5LTAuMzQ1LTEuNzAyIDAuNDA0NDMtMy4zNTMzIDEuMzIwNC00LjU3MzUgMi41NzM5LTEuNTc0NiAxLjYxNzYtMi45MjY2IDMuNzQzOC0zLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTE5Ljc4OCA0MC4xOGMtMTAuNzY4IDMuNjUwOC0xMS4zNSAzLjk0OTYtMTIuNTggNS40NjEyLTEuMzI1OCAxLjYyOTUtMS4zNjcgMC45NTI4Mi00LjU1NDYgMTYuOTU3IDAgMC0yLjIyNTcgOS4yMzYtMi42NTA2IDE0LjM4NC0wLjAyMzk1NSAwLjI5MDI0IDAuMTYwMiAwLjg1ODg2IDAuMTYwMiAwLjg1ODg2IDAuMjA5NDIgMS4xMjMzIDEuMTgxNSAyLjcwOTIgMi4wODYyIDMuNDAzNCAyLjc5MzggMi4xNDM3IDYuNTU4NyAxLjQ4MzMgOC41NTM1LTEuNTAwNyAwLjQxOTg1LTAuNjI4MDUgMC40NjgyNS0wLjgzNjk1IDMuMDgwOS0xMy40MzZsMi42NTM2LTEyLjc5OCAwLjE5MTItMC43MTI2MiA5Ljg1MzktNS42NjQ0IDEuMDk0My01LjM2MDJ6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.00612" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="44" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwNC42Mm1tIiBoZWlnaHQ9IjE4My44N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDQuNjIgMTgzLjg3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC43NjIyMyAtNTUuOTg0KSI+PHBhdGggZD0ibTE1NC45NyA3NS45OWExMTMuMjIgMTEzLjIyIDAgMCAwLTE1NS43MyAyNi40OTIgMzkuMjYzIDM5LjI2MyAwIDAgMSA1Mi44NTctNy42NDg3IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MiAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NTY0IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MSAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NDkyIDM5LjI2MyAzOS4yNjMgMCAwIDEgMTAuNTcxIDUzLjc3MyAxMTMuMjIgMTEzLjIyIDAgMCAwLTI5LjQxNS0xNTYuNjV6Ii8+PHBhdGggZD0ibTE2LjM5NCAyMDUuOTRzLTIuMjQyNyA1LjczNTctMi4yODM3IDguNzQ5N2MtMC4wNjY3MiA0LjkwNzYgMC4yMDA2NiAxMC41NjIgMy4zMjk4IDE0LjM0MyAzLjEzMjEgMy43ODQ4IDguNTcgNi4xMzc3IDEzLjQ3OSA1Ljk1OTUgNC41MTkzLTAuMTY0MDYgOS4yMDgtMi43OTY0IDExLjk3OC02LjM3MTIgNDYuMjYyLTU5LjcwNiAxMjMuNzItMTY3LjI2IDEyMy43Mi0xNjcuMjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="45" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="196,60,57,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="46" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk5LjA0OW1tIiBoZWlnaHQ9IjE2MC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5OS4wNDkgMTYwLjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0zOC4xNjkgMTcuNzk3YTI1LjYxNiAyNS42MTYgMCAwIDAtMjUuNjE3IDI1LjYxNyAyNS42MTYgMjUuNjE2IDAgMCAwIDI1LjYxNyAyNS42MTYgMjUuNjE2IDI1LjYxNiAwIDAgMCAyNS42MTYtMjUuNjE2IDI1LjYxNiAyNS42MTYgMCAwIDAtMC4wNTYzLTEuNjYyOWMtMi42NTQyIDEuMjg1Ny00LjgzNTQgMy40NzYzLTYuNzUgNS43MTk1LTEuMzc0NyAxLjYxMDYtMy4yOTM5IDUuNDMxNy0zLjI5MzkgNS40MzE3cy0zLjg0NDMgMi45ODEzLTUuNjYxNyAyLjExMjVjLTEuOTk1NS0wLjk1Mzk4LTIuMzk3Mi00LjEwMzItMi4wOTg2LTYuMjk0NyAwLjQ2Njg0LTMuNDI2MyAzLjE3NjMtNi4zNDU4IDUuNzk0LTguNjA1MiAyLjk3OS0yLjU3MTMgMTAuNjUtNS4wOTE4IDEwLjY1My01LjA5MjdhMjUuNjE2IDI1LjYxNiAwIDAgMC0xZS0zIC0zZS0zYy05ZS0zIC0wLjAxNzQtMy45MjUtNy40MTI2LTYuODgxMi0xMC4yODMtMS4yMDI1LTEuMTY3Ny0yLjY1MjYtMi4zMzQ0LTQuMjY4LTMuMzYyMWEyNS42MTYgMjUuNjE2IDAgMCAwLTEzLjA1Mi0zLjU3NjZ6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTc1LjM4NCAzOC42OGEyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NiAyMy42NjUgMjMuNjY1IDIzLjY2NSAwIDAgMCAyMy42NjYgMjMuNjY2IDIzLjY2NSAyMy42NjUgMCAwIDAgMjMuNjY1LTIzLjY2NiAyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NS0yMy42NjV6bTIuNTkxNiAxMS44ODdjMy41MTI2IDAuMDU3OSA4LjIwODIgMy43Njk0IDkuNDYyNSA2LjgxNjEgMS44NDkgNC40OTEyLTAuMzE2MDQgMTQuMTg0LTUuNTAzIDEzLjQ4OS0zLjYwNDYtMC40ODM0IDAuMzE1MzItNi43ODg0LTAuNzI3MDgtOS45ODQ0LTEuMTI2Mi0zLjQ1MjktOC41NTY1LTYuODM5Ny01LjgwMzMtOS40MTQ5IDAuNjk2NTMtMC42NTE0OSAxLjU4NzQtMC45MjE1NyAyLjU3MDktMC45MDUzN3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48cGF0aCBkPSJtNTMuNjg1IDUyLjkwMS01LjJlLTQgMWUtM3MtMy44NDQzIDIuOTgxMy01LjY2MTcgMi4xMTI1bC0yNC4wMzUgOS43MzIyIDQzLjg3MyAyMC4wMDN6Ii8+PHBhdGggZD0ibTcxLjEzNyAwYy0xMC4wNDMgMC4wMTIwMi0xOS4wODIgNi4wOTU0LTIyLjg3NSAxNS4zOTUgMi43OTkxIDAuNDYwNjcgNS41MDIyIDEuMzgzMSA3Ljk5OSAyLjcyOTUgMC4yMjgwOSAwLjExNzI2IDAuNDUzNjIgMC4yMzk0MSAwLjY3NjQ0IDAuMzY2MzkgMC4wODUzNSAwLjA0NTY4IDAuMTcwNDUgMC4wOTE4NSAwLjI1NTI4IDAuMTM4NDkgMC4xMzMxNyAwLjA4NDcyIDAuMjYzNDEgMC4xNzE4NSAwLjM5NDI5IDAuMjU4MzggMC42MDg2MiAwLjM4NDEgMS4xOTM1IDAuODA0NjUgMS43NTEzIDEuMjU5NCAwLjc2ODg2IDAuNjAwNzUgMS40ODE2IDEuMjIyMiAyLjEyMjQgMS44NDQzIDIuNzk3OCAyLjcxNjcgNi40MTM2IDkuNDA5MyA2LjgwNTMgMTAuMTQyIDIuMTk3Ni0wLjY2NTI0IDQuNDgwMy0xLjAwNzEgNi43NzYzLTEuMDE0OSA2LjMyNzMgMC4wMDYxIDEyLjM4OSAyLjU0NTggMTYuODMgNy4wNTE4IDIuNjAwNi0zLjk5OSAzLjk4OTUtOC42NjQ2IDMuOTk5Mi0xMy40MzUtNy42ZS01IC0xMy42NjEtMTEuMDc0LTI0LjczNS0yNC43MzUtMjQuNzM1em00Ljc5NjEgOC41NzA1YzQuMDgyNi0wLjA1NzEyIDguMTg0NyA0Ljk5OSA4Ljg5ODcgOS4wNzMzIDAuNzYxOTIgNC4zNDc4LTAuODU4NDcgMTEuNzY4LTUuMTc5NiAxMC44NjctMy4xNjM5LTAuNjU5OS0wLjYxMzY4LTUuNjgwNC0xLjUzNjgtOC43Nzc4LTAuODcyMi0yLjkyNjYtNC40MDYxLTQuOTI3MS00LjUwMS03Ljk3OTQtMC4wMzU3LTEuMTQ4NCAwLjM3NDY4LTIuODg4OSAxLjUwMzgtMy4xMDE2IDAuMjcwOTktMC4wNTEwNyAwLjU0Mjc3LTAuMDc3ODM5IDAuODE0OTQtMC4wODE2NDl6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTEyLjk3MSA2Mi41NzctMTIuOTcxIDk3LjUxOCA3MS4wOTItNjcuNDg5cy00Ljc4MDggMS40NDQtNi45MDk3IDAuNTQ2MjJjLTE2LjEwOS02Ljc5MzQtMzEuNDMtMTMuNzY4LTQ1Ljk1Mi0yMi45NzEtMi42MDM0LTEuNjQ5OC01LjI1OTYtNy42MDQyLTUuMjU5Ni03LjYwNDJ6bTM2LjIyMSAyOS4zMDVjMS42ODYgMC4wNDE5IDMuMDUxOSAxLjM5MTggMy4wOTU0IDMuMDk3NWwwLjAxNyAwLjY3OTU1YzAuMDQ0OSAxLjc2MDctMS4zMzYzIDMuMjE0My0zLjA5NyAzLjI1OTJsLTI2LjIxNiAwLjY2ODY5Yy0xLjc2MDcgMC4wNDQ5LTMuMjE0My0xLjMzNjMtMy4yNTkyLTMuMDk3bC0wLjAxNzUyLTAuNjgwMDZjLTAuMDQ0OS0xLjc2MDcgMS4zMzY4LTMuMjE0MyAzLjA5NzUtMy4yNTkybDI2LjIxNi0wLjY2ODE4YzAuMDU1LTFlLTMgMC4xMDk0My0yZS0zIDAuMTYzODItNS4xZS00em0tMTEuMjU3IDE1LjI5N2MxLjY4NDkgMC4wMjc4IDMuMDQxNSAxLjM2NiAzLjA3NDIgMy4wNzE2bDAuMDEyOSAwLjY4MDA2YzAuMDMzOCAxLjc2MDctMS4zNTYxIDMuMjI2LTMuMTE2MSAzLjI4NTZsLTE4LjE1OCAwLjYxNTQ3Yy0xLjc2IDAuMDU5Ni0zLjIwNDMtMS4zMDk5LTMuMjM4LTMuMDcwNmwtMC4wMTI5Mi0wLjY3OTU0Yy0wLjAzMzc5LTEuNzYwNyAxLjM1NjEtMy4yMjY1IDMuMTE2MS0zLjI4NjFsMTguMTU4LTAuNjE1NDZjMC4wNTUtMmUtMyAwLjEwOTQ2LTJlLTMgMC4xNjM4MS0xZS0zem0tMTUuNjIgMTQuMTk0YzEuNjQyNCA5ZS0zIDIuOTM5NCAxLjI4NDQgMi45NTQ5IDIuOTYyNmwwLjAwNjIgMC42Nzk1NGMwLjAxNjIyIDEuNzYwNy0xLjM4NDUgMy4yNzc5LTMuMTQwOSAzLjQwMTlsLTUuNDI5MSAwLjM4MzQ0Yy0xLjc1NjQgMC4xMjM5Ni0zLjE4MzYtMS4xOTM2LTMuMTk5OC0yLjk1NDNsLTAuMDA2Mi0wLjY4MDA2Yy0wLjAxNjIyLTEuNzYwNyAxLjM4NDUtMy4yNzc5IDMuMTQwOS0zLjQwMTlsNS40MjkxLTAuMzgyOTNjMC4wODIzMy02ZS0zIDAuMTY0MTctOWUtMyAwLjI0NDk1LThlLTN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.34102" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="47" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS42Mm1tIiBoZWlnaHQ9IjE0OS41Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDkuNjIgMTQ5LjU2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxjaXJjbGUgY3g9IjE0MS44MSIgY3k9Ijc1LjYyIiByPSI2LjI1MzkiLz48Y2lyY2xlIGN4PSI3LjgwMzkiIGN5PSI3NS42MiIgcj0iNi4yNTM5Ii8+PHJlY3QgeD0iMy4xNzAyZS03IiB5PSIxMzcuNDkiIHdpZHRoPSIxNDkuNjIiIGhlaWdodD0iMTIuMDY5IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjIuNTc1MiIvPjwvZz48Y2lyY2xlIGN4PSI3NC44MDkiIGN5PSIxMy45NjEiIHI9IjEwLjUxMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjYuOSIvPjxwYXRoIGQ9Im02OS4xNDggMjIuNDY3LTU3LjQ3NCA0OS4xOTIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI0LjUiLz48Zz48cGF0aCBkPSJtNjYuNTk3IDIwLjg4LTQ3LjkyIDEwOC44OSA5LjY4NDctMWUtNSA0Ni4zNDktMTA1LjMyeiIvPjxwYXRoIGQ9Im0xNy43NDcgNzUuMzI2YzAuMDA3MyAwLjA5NzkgMC4wMTMxNiAwLjE5NTk1IDAuMDE3NTcgMC4yOTQwNCA0ZS01IDUuNTAwOC00LjQ1OTMgOS45NjAyLTkuOTYwMSA5Ljk2MDEtMC42NTQ4OS0yZS0zIC0xLjMwOC0wLjA2OS0xLjk0OTgtMC4xOTk0NyAyLjE0NDggNC42Mzk3IDUuNTM4OCAxMS42MzEgOC4yMzgzIDE1LjU2MSAyLjM1NzcgMy40MzI5IDguMzQxMSA5LjMwMTIgOC4zNDExIDkuMzAxMmwwLjM1MTQgMC4xMTYyNyAxNS40MTgtMzUuMDM0em0zNi41NDggOC4xNDI3LTE0LjMzNiAzMi41NzdzMi40MDIyIDEuMjI1OCAzLjcwMjEgMS4yMjU4aDMxLjE0OHYtMjkuMjc5Yy04LjEyNzItMmUtMyAtMTUuNzU4LTEuNjg1LTIwLjUxNS00LjUyMzh6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iLjIiLz48cGF0aCBkPSJtMTMuMzQ5IDY3LjUxM3Y1LjQ0NjJoMjUuODk2bDIuMzk2OC01LjQ0NjJ6Ii8+PHBhdGggZD0ibTU3LjgwNCA3NS4zMjYtMi41NzMxIDUuMzkxNGM1LjE2MDcgMi4wODY1IDEyLjIxNSAzLjI2MjEgMTkuNTc4IDMuMjYyOHYtNi4zMDM1Yy02LjE3MjItMmUtMyAtMTQuMzQ2LTEuNjM4My0xNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTgwLjQ3IDIyLjQ2NyA1Ny40NzQgNDkuMTkyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNC41Ii8+PGc+PHBhdGggZD0ibTgzLjAyMSAyMC44OCA0Ny45MiAxMDguODktOS42ODQ3LTFlLTUgLTQ2LjM0OS0xMDUuMzJ6Ii8+PHBhdGggZD0ibTExMS40MiA3NS4zMjYgMTUuNDE4IDM1LjAzNCAwLjM1MTM5LTAuMTE2MjdzNS45ODM0LTUuODY4NCA4LjM0MTEtOS4zMDEyYzIuNjk5NC0zLjkzMDQgNi4wOTM1LTEwLjkyMiA4LjIzODItMTUuNTYxLTAuNjQxNzcgMC4xMzA0Ny0xLjI5NDkgMC4xOTc0Ny0xLjk0OTggMC4xOTk0Ny01LjUwMDggM2UtNSAtOS45NjAyLTQuNDU5My05Ljk2MDEtOS45NjAxIDRlLTMgLTAuMDk4MDkgMC4wMTA2LTAuMTk2MTQgMC4wMTc2LTAuMjk0MDR6bS0xNi4wOTIgOC4xNDI3Yy00Ljc1NjYgMi44Mzg3LTEyLjM4NyA0LjUyMTgtMjAuNTE1IDQuNTIzOHYyOS4yNzloMzEuMTQ4YzEuMjk5OSAwIDMuNzAyMS0xLjIyNTggMy43MDIxLTEuMjI1OHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMiIvPjxwYXRoIGQ9Im0xMzYuMjcgNjcuNTEzdjUuNDQ2MmgtMjUuODk2bC0yLjM5NjgtNS40NDYyeiIvPjxwYXRoIGQ9Im05MS44MTQgNzUuMzI2IDIuNTczMSA1LjM5MTRjLTUuMTYwNyAyLjA4NjUtMTIuMjE1IDMuMjYyMS0xOS41NzggMy4yNjI4di02LjMwMzVjNi4xNzIyLTJlLTMgMTQuMzQ2LTEuNjM4MyAxNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTc0LjgwOSAxMTcuMzd2LTI5LjQ4MiIgZmlsbD0iIzAwZiIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEuNDciLz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="48" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg1LjAyM21tIiBoZWlnaHQ9IjE1Mi43M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4NS4wMjMgMTUyLjczIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im01OCA1OS44ODJ2MTYuMzc0bDguOTcyMSA5LjAyNjNjMy4zNjI3IDMuMzgzMSA3Ljg5NTUgNC4yOTIyIDEwLjE2MyAyLjAzODEgMi4yNjc3LTIuMjU0MSAxLjM4NjEtNi43OTI1LTEuOTc2Ni0xMC4xNzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjQ2NSIvPjxwYXRoIGQ9Im0zNi4zNTUgOTIuNTdjLTIuNjIyNSA0LjUyNjctNS42NDA2IDkuNzQyNC05LjIwNjcgMTUuOTIyLTguMzM2MiAxNC40NDUtMTUuNDA4IDI2LjYzNS0xNS43MTYgMjcuMDktMC45MDA0IDEuMzMyOS0xLjI2MjUgMi41MzU4LTEuMjYwNCA0LjE4NzggMC4wMDE2IDEuMDc5OCAwLjA3MjAxIDEuNTkzNCAwLjMxMzE2IDIuMjgzMSAxLjA3NzkgMy4wODI2IDMuODYyNSA1LjA1NDIgNy4wOTQxIDUuMDIyNCAwLjUxMzQ3LTVlLTMgMS4yNzgyLTAuMTAwNTIgMS42OTk2LTAuMjEyMzkgMS43MDc4LTAuNDUzMzEgMy4xMTE3LTEuNDUxOCA0LjM3MTgtMy4xMDk0IDAuNDMzMzctMC41NzAwNiAxNC45MTktMjUuNTU5IDIzLjQyNS00MC4zMzV6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zOC4wMjQgMjguMzUxYy0wLjU2MjQzLTAuMDA4NS0xLjA5MzQgMC4wMjQ2Ni0xLjQ4MjEgMC4xMDY0NS0wLjQyMTQ2IDAuMDg4NjgtMS4xMTA3IDAuMzAzMjYtMS41MzIyIDAuNDc2OTctMC40MjE0NiAwLjE3MzcxLTYuNDk1OSAzLjYzNTctMTMuNDk4IDcuNjkzMS0xMC40NDQgNi4wNTE1LTEyLjk3NSA3LjUxNTItMTQuMDE3IDguNjcyM2wxNi4wNDQgMC4wMDE2djMuNTYzNmMzLjAwMS0xLjcyODYgNS40Njk5LTMuMDk4OSA1LjU0NTQtMy4wNzM3IDAuMDk2NjEgMC4wMzIyIDAuMTY1OTQgNS40Njk2IDAuMjEyOTEgMTYuNjg1bDAuMDY5NzYgMTYuNjM4IDAuMzI3MTEgMC42MjY4NGMwLjA2NjMzIDAuMTI3MTIgMC42NzQ2MSAwLjc4NDA3IDEuNTg0NCAxLjczNjNsMC4wNjU2My0wLjA2NTExIDI1Ljg5OCAyNi4yMDUgMC4wMjQ4MSAwLjAyNTMgNC42MjYxIDQuNjMwNyA0LjM5MyAxNy42OTVjMy41NjM4IDE0LjM1NSA0LjQ4MzQgMTcuODc5IDQuODczMSAxOC42NzUgMC45NjU3NiAxLjk3MjUgMy4yMDcyIDMuNjI1OCA1LjM3MDIgMy45NjE1IDEuMTQ1OCAwLjE3Nzc4IDEuNTI3NCAwLjE2Njk4IDIuNjQ3NC0wLjA3NTQgMS40NDM4LTAuMzEyNjggMi41OTAyLTAuOTU0OTMgMy42OTQzLTIuMDY5MSAxLjA0OTctMS4wNTkzIDEuNTk3Ni0yLjAwMzMgMS45NDM2LTMuMzQ5NyAwLjQ3MjYxLTEuODM5IDAuNjQ4MzgtMS4wMTY3LTUuMjM3NC0yNC41MDctMi45OTgtMTEuOTY1LTUuNTc1Ni0yMi4xLTUuNzI4My0yMi41MjEtMC4yNTg4Ny0wLjcxNDQtMC45NDY5NS0xLjQzNjItMTAuMTU0LTEwLjY2bC02LjYwOTQtNi42MjE5LTMuMjY2NS0zLjI3MjctMC4yMTcwNC0wLjIxNzA0di0yMi40NTFjLTcuOGUtNCAtMC43ODAyLTAuMDAyNS00LjM3MTMgMC04LjQwODN2LTExLjIyN2MtMC4wODMxNy0xLjM2ODctMS4wMzc1LTEuNzcyMS02Ljg4NDMtNS4xNDctMi45NDgtMS43MDE2LTUuNzA2Ny0zLjIxNzEtNi4xMzA0LTMuMzY4My0wLjYwMDAyLTAuMjE0MDgtMS42MjUyLTAuMzQ0MzktMi41NjI2LTAuMzU4NjN6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zMS4wNjEgOC45MjM5Yy0wLjQyMTk0IDQuMDMyMyAxLjA1OTUgOC4zMjA2IDMuMzI4NCAxMS42OTkgMS4zNDk2IDIuMDA5MyAzLjMxMDIgMy41OTUzIDUuMzI0NCA0LjkzNzUgMi42NDQ4IDEuNzYyNSA1LjU2NzIgMy4yOTE1IDguNjc1MiAzLjk1NjcgMS4xODk2IDAuMjU0NTggMi41MDE2IDAuMzgwMjIgMy42NDk0LTAuMDIyOCAxLjQzNDQtMC41MDM2NSAyLjcyNjEtMS41Njk0IDMuNTc3NC0yLjgyOSAxLjI5NzQtMS45MTk1IDEuNjg4OC00LjM2NjEgMS45Njc3LTYuNjY2IDAuMjg4NjYtMi4zNzk5IDAuMzUxOS00Ljg4NTctMC4zMjgxMi03LjE4NDctMC44MjI3NS0yLjc4MTUtMi40Mjk0LTUuMzc3NS00LjM5NTctNy41MDk5LTEuODEyMi0xLjk2NTMtNC4wNDAyLTMuNzM2My02LjU3MDctNC41OTgzLTIuMzY2Ny0wLjgwNjItNS4wNjA0LTAuOTIzMDQtNy40OTI5LTAuMzQ1LTEuNzAyIDAuNDA0NDMtMy4zNTMzIDEuMzIwNC00LjU3MzUgMi41NzM5LTEuNTc0NiAxLjYxNzYtMi45MjY2IDMuNzQzOC0zLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTE5Ljc4OCA0MC4xOGMtMTAuNzY4IDMuNjUwOC0xMS4zNSAzLjk0OTYtMTIuNTggNS40NjEyLTEuMzI1OCAxLjYyOTUtMS4zNjcgMC45NTI4Mi00LjU1NDYgMTYuOTU3IDAgMC0yLjIyNTcgOS4yMzYtMi42NTA2IDE0LjM4NC0wLjAyMzk1NSAwLjI5MDI0IDAuMTYwMiAwLjg1ODg2IDAuMTYwMiAwLjg1ODg2IDAuMjA5NDIgMS4xMjMzIDEuMTgxNSAyLjcwOTIgMi4wODYyIDMuNDAzNCAyLjc5MzggMi4xNDM3IDYuNTU4NyAxLjQ4MzMgOC41NTM1LTEuNTAwNyAwLjQxOTg1LTAuNjI4MDUgMC40NjgyNS0wLjgzNjk1IDMuMDgwOS0xMy40MzZsMi42NTM2LTEyLjc5OCAwLjE5MTItMC43MTI2MiA5Ljg1MzktNS42NjQ0IDEuMDk0My01LjM2MDJ6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.00612" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="49" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwNC42Mm1tIiBoZWlnaHQ9IjE4My44N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDQuNjIgMTgzLjg3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC43NjIyMyAtNTUuOTg0KSI+PHBhdGggZD0ibTE1NC45NyA3NS45OWExMTMuMjIgMTEzLjIyIDAgMCAwLTE1NS43MyAyNi40OTIgMzkuMjYzIDM5LjI2MyAwIDAgMSA1Mi44NTctNy42NDg3IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MiAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NTY0IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MSAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NDkyIDM5LjI2MyAzOS4yNjMgMCAwIDEgMTAuNTcxIDUzLjc3MyAxMTMuMjIgMTEzLjIyIDAgMCAwLTI5LjQxNS0xNTYuNjV6Ii8+PHBhdGggZD0ibTE2LjM5NCAyMDUuOTRzLTIuMjQyNyA1LjczNTctMi4yODM3IDguNzQ5N2MtMC4wNjY3MiA0LjkwNzYgMC4yMDA2NiAxMC41NjIgMy4zMjk4IDE0LjM0MyAzLjEzMjEgMy43ODQ4IDguNTcgNi4xMzc3IDEzLjQ3OSA1Ljk1OTUgNC41MTkzLTAuMTY0MDYgOS4yMDgtMi43OTY0IDExLjk3OC02LjM3MTIgNDYuMjYyLTU5LjcwNiAxMjMuNzItMTY3LjI2IDEyMy43Mi0xNjcuMjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="196,60,57,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="50" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="229,182,54,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="51" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk5LjA0OW1tIiBoZWlnaHQ9IjE2MC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5OS4wNDkgMTYwLjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0zOC4xNjkgMTcuNzk3YTI1LjYxNiAyNS42MTYgMCAwIDAtMjUuNjE3IDI1LjYxNyAyNS42MTYgMjUuNjE2IDAgMCAwIDI1LjYxNyAyNS42MTYgMjUuNjE2IDI1LjYxNiAwIDAgMCAyNS42MTYtMjUuNjE2IDI1LjYxNiAyNS42MTYgMCAwIDAtMC4wNTYzLTEuNjYyOWMtMi42NTQyIDEuMjg1Ny00LjgzNTQgMy40NzYzLTYuNzUgNS43MTk1LTEuMzc0NyAxLjYxMDYtMy4yOTM5IDUuNDMxNy0zLjI5MzkgNS40MzE3cy0zLjg0NDMgMi45ODEzLTUuNjYxNyAyLjExMjVjLTEuOTk1NS0wLjk1Mzk4LTIuMzk3Mi00LjEwMzItMi4wOTg2LTYuMjk0NyAwLjQ2Njg0LTMuNDI2MyAzLjE3NjMtNi4zNDU4IDUuNzk0LTguNjA1MiAyLjk3OS0yLjU3MTMgMTAuNjUtNS4wOTE4IDEwLjY1My01LjA5MjdhMjUuNjE2IDI1LjYxNiAwIDAgMC0xZS0zIC0zZS0zYy05ZS0zIC0wLjAxNzQtMy45MjUtNy40MTI2LTYuODgxMi0xMC4yODMtMS4yMDI1LTEuMTY3Ny0yLjY1MjYtMi4zMzQ0LTQuMjY4LTMuMzYyMWEyNS42MTYgMjUuNjE2IDAgMCAwLTEzLjA1Mi0zLjU3NjZ6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTc1LjM4NCAzOC42OGEyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NiAyMy42NjUgMjMuNjY1IDIzLjY2NSAwIDAgMCAyMy42NjYgMjMuNjY2IDIzLjY2NSAyMy42NjUgMCAwIDAgMjMuNjY1LTIzLjY2NiAyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NS0yMy42NjV6bTIuNTkxNiAxMS44ODdjMy41MTI2IDAuMDU3OSA4LjIwODIgMy43Njk0IDkuNDYyNSA2LjgxNjEgMS44NDkgNC40OTEyLTAuMzE2MDQgMTQuMTg0LTUuNTAzIDEzLjQ4OS0zLjYwNDYtMC40ODM0IDAuMzE1MzItNi43ODg0LTAuNzI3MDgtOS45ODQ0LTEuMTI2Mi0zLjQ1MjktOC41NTY1LTYuODM5Ny01LjgwMzMtOS40MTQ5IDAuNjk2NTMtMC42NTE0OSAxLjU4NzQtMC45MjE1NyAyLjU3MDktMC45MDUzN3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48cGF0aCBkPSJtNTMuNjg1IDUyLjkwMS01LjJlLTQgMWUtM3MtMy44NDQzIDIuOTgxMy01LjY2MTcgMi4xMTI1bC0yNC4wMzUgOS43MzIyIDQzLjg3MyAyMC4wMDN6Ii8+PHBhdGggZD0ibTcxLjEzNyAwYy0xMC4wNDMgMC4wMTIwMi0xOS4wODIgNi4wOTU0LTIyLjg3NSAxNS4zOTUgMi43OTkxIDAuNDYwNjcgNS41MDIyIDEuMzgzMSA3Ljk5OSAyLjcyOTUgMC4yMjgwOSAwLjExNzI2IDAuNDUzNjIgMC4yMzk0MSAwLjY3NjQ0IDAuMzY2MzkgMC4wODUzNSAwLjA0NTY4IDAuMTcwNDUgMC4wOTE4NSAwLjI1NTI4IDAuMTM4NDkgMC4xMzMxNyAwLjA4NDcyIDAuMjYzNDEgMC4xNzE4NSAwLjM5NDI5IDAuMjU4MzggMC42MDg2MiAwLjM4NDEgMS4xOTM1IDAuODA0NjUgMS43NTEzIDEuMjU5NCAwLjc2ODg2IDAuNjAwNzUgMS40ODE2IDEuMjIyMiAyLjEyMjQgMS44NDQzIDIuNzk3OCAyLjcxNjcgNi40MTM2IDkuNDA5MyA2LjgwNTMgMTAuMTQyIDIuMTk3Ni0wLjY2NTI0IDQuNDgwMy0xLjAwNzEgNi43NzYzLTEuMDE0OSA2LjMyNzMgMC4wMDYxIDEyLjM4OSAyLjU0NTggMTYuODMgNy4wNTE4IDIuNjAwNi0zLjk5OSAzLjk4OTUtOC42NjQ2IDMuOTk5Mi0xMy40MzUtNy42ZS01IC0xMy42NjEtMTEuMDc0LTI0LjczNS0yNC43MzUtMjQuNzM1em00Ljc5NjEgOC41NzA1YzQuMDgyNi0wLjA1NzEyIDguMTg0NyA0Ljk5OSA4Ljg5ODcgOS4wNzMzIDAuNzYxOTIgNC4zNDc4LTAuODU4NDcgMTEuNzY4LTUuMTc5NiAxMC44NjctMy4xNjM5LTAuNjU5OS0wLjYxMzY4LTUuNjgwNC0xLjUzNjgtOC43Nzc4LTAuODcyMi0yLjkyNjYtNC40MDYxLTQuOTI3MS00LjUwMS03Ljk3OTQtMC4wMzU3LTEuMTQ4NCAwLjM3NDY4LTIuODg4OSAxLjUwMzgtMy4xMDE2IDAuMjcwOTktMC4wNTEwNyAwLjU0Mjc3LTAuMDc3ODM5IDAuODE0OTQtMC4wODE2NDl6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTEyLjk3MSA2Mi41NzctMTIuOTcxIDk3LjUxOCA3MS4wOTItNjcuNDg5cy00Ljc4MDggMS40NDQtNi45MDk3IDAuNTQ2MjJjLTE2LjEwOS02Ljc5MzQtMzEuNDMtMTMuNzY4LTQ1Ljk1Mi0yMi45NzEtMi42MDM0LTEuNjQ5OC01LjI1OTYtNy42MDQyLTUuMjU5Ni03LjYwNDJ6bTM2LjIyMSAyOS4zMDVjMS42ODYgMC4wNDE5IDMuMDUxOSAxLjM5MTggMy4wOTU0IDMuMDk3NWwwLjAxNyAwLjY3OTU1YzAuMDQ0OSAxLjc2MDctMS4zMzYzIDMuMjE0My0zLjA5NyAzLjI1OTJsLTI2LjIxNiAwLjY2ODY5Yy0xLjc2MDcgMC4wNDQ5LTMuMjE0My0xLjMzNjMtMy4yNTkyLTMuMDk3bC0wLjAxNzUyLTAuNjgwMDZjLTAuMDQ0OS0xLjc2MDcgMS4zMzY4LTMuMjE0MyAzLjA5NzUtMy4yNTkybDI2LjIxNi0wLjY2ODE4YzAuMDU1LTFlLTMgMC4xMDk0My0yZS0zIDAuMTYzODItNS4xZS00em0tMTEuMjU3IDE1LjI5N2MxLjY4NDkgMC4wMjc4IDMuMDQxNSAxLjM2NiAzLjA3NDIgMy4wNzE2bDAuMDEyOSAwLjY4MDA2YzAuMDMzOCAxLjc2MDctMS4zNTYxIDMuMjI2LTMuMTE2MSAzLjI4NTZsLTE4LjE1OCAwLjYxNTQ3Yy0xLjc2IDAuMDU5Ni0zLjIwNDMtMS4zMDk5LTMuMjM4LTMuMDcwNmwtMC4wMTI5Mi0wLjY3OTU0Yy0wLjAzMzc5LTEuNzYwNyAxLjM1NjEtMy4yMjY1IDMuMTE2MS0zLjI4NjFsMTguMTU4LTAuNjE1NDZjMC4wNTUtMmUtMyAwLjEwOTQ2LTJlLTMgMC4xNjM4MS0xZS0zem0tMTUuNjIgMTQuMTk0YzEuNjQyNCA5ZS0zIDIuOTM5NCAxLjI4NDQgMi45NTQ5IDIuOTYyNmwwLjAwNjIgMC42Nzk1NGMwLjAxNjIyIDEuNzYwNy0xLjM4NDUgMy4yNzc5LTMuMTQwOSAzLjQwMTlsLTUuNDI5MSAwLjM4MzQ0Yy0xLjc1NjQgMC4xMjM5Ni0zLjE4MzYtMS4xOTM2LTMuMTk5OC0yLjk1NDNsLTAuMDA2Mi0wLjY4MDA2Yy0wLjAxNjIyLTEuNzYwNyAxLjM4NDUtMy4yNzc5IDMuMTQwOS0zLjQwMTlsNS40MjkxLTAuMzgyOTNjMC4wODIzMy02ZS0zIDAuMTY0MTctOWUtMyAwLjI0NDk1LThlLTN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.34102" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="52" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS42Mm1tIiBoZWlnaHQ9IjE0OS41Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDkuNjIgMTQ5LjU2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxjaXJjbGUgY3g9IjE0MS44MSIgY3k9Ijc1LjYyIiByPSI2LjI1MzkiLz48Y2lyY2xlIGN4PSI3LjgwMzkiIGN5PSI3NS42MiIgcj0iNi4yNTM5Ii8+PHJlY3QgeD0iMy4xNzAyZS03IiB5PSIxMzcuNDkiIHdpZHRoPSIxNDkuNjIiIGhlaWdodD0iMTIuMDY5IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjIuNTc1MiIvPjwvZz48Y2lyY2xlIGN4PSI3NC44MDkiIGN5PSIxMy45NjEiIHI9IjEwLjUxMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjYuOSIvPjxwYXRoIGQ9Im02OS4xNDggMjIuNDY3LTU3LjQ3NCA0OS4xOTIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI0LjUiLz48Zz48cGF0aCBkPSJtNjYuNTk3IDIwLjg4LTQ3LjkyIDEwOC44OSA5LjY4NDctMWUtNSA0Ni4zNDktMTA1LjMyeiIvPjxwYXRoIGQ9Im0xNy43NDcgNzUuMzI2YzAuMDA3MyAwLjA5NzkgMC4wMTMxNiAwLjE5NTk1IDAuMDE3NTcgMC4yOTQwNCA0ZS01IDUuNTAwOC00LjQ1OTMgOS45NjAyLTkuOTYwMSA5Ljk2MDEtMC42NTQ4OS0yZS0zIC0xLjMwOC0wLjA2OS0xLjk0OTgtMC4xOTk0NyAyLjE0NDggNC42Mzk3IDUuNTM4OCAxMS42MzEgOC4yMzgzIDE1LjU2MSAyLjM1NzcgMy40MzI5IDguMzQxMSA5LjMwMTIgOC4zNDExIDkuMzAxMmwwLjM1MTQgMC4xMTYyNyAxNS40MTgtMzUuMDM0em0zNi41NDggOC4xNDI3LTE0LjMzNiAzMi41NzdzMi40MDIyIDEuMjI1OCAzLjcwMjEgMS4yMjU4aDMxLjE0OHYtMjkuMjc5Yy04LjEyNzItMmUtMyAtMTUuNzU4LTEuNjg1LTIwLjUxNS00LjUyMzh6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iLjIiLz48cGF0aCBkPSJtMTMuMzQ5IDY3LjUxM3Y1LjQ0NjJoMjUuODk2bDIuMzk2OC01LjQ0NjJ6Ii8+PHBhdGggZD0ibTU3LjgwNCA3NS4zMjYtMi41NzMxIDUuMzkxNGM1LjE2MDcgMi4wODY1IDEyLjIxNSAzLjI2MjEgMTkuNTc4IDMuMjYyOHYtNi4zMDM1Yy02LjE3MjItMmUtMyAtMTQuMzQ2LTEuNjM4My0xNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTgwLjQ3IDIyLjQ2NyA1Ny40NzQgNDkuMTkyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNC41Ii8+PGc+PHBhdGggZD0ibTgzLjAyMSAyMC44OCA0Ny45MiAxMDguODktOS42ODQ3LTFlLTUgLTQ2LjM0OS0xMDUuMzJ6Ii8+PHBhdGggZD0ibTExMS40MiA3NS4zMjYgMTUuNDE4IDM1LjAzNCAwLjM1MTM5LTAuMTE2MjdzNS45ODM0LTUuODY4NCA4LjM0MTEtOS4zMDEyYzIuNjk5NC0zLjkzMDQgNi4wOTM1LTEwLjkyMiA4LjIzODItMTUuNTYxLTAuNjQxNzcgMC4xMzA0Ny0xLjI5NDkgMC4xOTc0Ny0xLjk0OTggMC4xOTk0Ny01LjUwMDggM2UtNSAtOS45NjAyLTQuNDU5My05Ljk2MDEtOS45NjAxIDRlLTMgLTAuMDk4MDkgMC4wMTA2LTAuMTk2MTQgMC4wMTc2LTAuMjk0MDR6bS0xNi4wOTIgOC4xNDI3Yy00Ljc1NjYgMi44Mzg3LTEyLjM4NyA0LjUyMTgtMjAuNTE1IDQuNTIzOHYyOS4yNzloMzEuMTQ4YzEuMjk5OSAwIDMuNzAyMS0xLjIyNTggMy43MDIxLTEuMjI1OHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMiIvPjxwYXRoIGQ9Im0xMzYuMjcgNjcuNTEzdjUuNDQ2MmgtMjUuODk2bC0yLjM5NjgtNS40NDYyeiIvPjxwYXRoIGQ9Im05MS44MTQgNzUuMzI2IDIuNTczMSA1LjM5MTRjLTUuMTYwNyAyLjA4NjUtMTIuMjE1IDMuMjYyMS0xOS41NzggMy4yNjI4di02LjMwMzVjNi4xNzIyLTJlLTMgMTQuMzQ2LTEuNjM4MyAxNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTc0LjgwOSAxMTcuMzd2LTI5LjQ4MiIgZmlsbD0iIzAwZiIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEuNDciLz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="53" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg1LjAyM21tIiBoZWlnaHQ9IjE1Mi43M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4NS4wMjMgMTUyLjczIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im01OCA1OS44ODJ2MTYuMzc0bDguOTcyMSA5LjAyNjNjMy4zNjI3IDMuMzgzMSA3Ljg5NTUgNC4yOTIyIDEwLjE2MyAyLjAzODEgMi4yNjc3LTIuMjU0MSAxLjM4NjEtNi43OTI1LTEuOTc2Ni0xMC4xNzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjQ2NSIvPjxwYXRoIGQ9Im0zNi4zNTUgOTIuNTdjLTIuNjIyNSA0LjUyNjctNS42NDA2IDkuNzQyNC05LjIwNjcgMTUuOTIyLTguMzM2MiAxNC40NDUtMTUuNDA4IDI2LjYzNS0xNS43MTYgMjcuMDktMC45MDA0IDEuMzMyOS0xLjI2MjUgMi41MzU4LTEuMjYwNCA0LjE4NzggMC4wMDE2IDEuMDc5OCAwLjA3MjAxIDEuNTkzNCAwLjMxMzE2IDIuMjgzMSAxLjA3NzkgMy4wODI2IDMuODYyNSA1LjA1NDIgNy4wOTQxIDUuMDIyNCAwLjUxMzQ3LTVlLTMgMS4yNzgyLTAuMTAwNTIgMS42OTk2LTAuMjEyMzkgMS43MDc4LTAuNDUzMzEgMy4xMTE3LTEuNDUxOCA0LjM3MTgtMy4xMDk0IDAuNDMzMzctMC41NzAwNiAxNC45MTktMjUuNTU5IDIzLjQyNS00MC4zMzV6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zOC4wMjQgMjguMzUxYy0wLjU2MjQzLTAuMDA4NS0xLjA5MzQgMC4wMjQ2Ni0xLjQ4MjEgMC4xMDY0NS0wLjQyMTQ2IDAuMDg4NjgtMS4xMTA3IDAuMzAzMjYtMS41MzIyIDAuNDc2OTctMC40MjE0NiAwLjE3MzcxLTYuNDk1OSAzLjYzNTctMTMuNDk4IDcuNjkzMS0xMC40NDQgNi4wNTE1LTEyLjk3NSA3LjUxNTItMTQuMDE3IDguNjcyM2wxNi4wNDQgMC4wMDE2djMuNTYzNmMzLjAwMS0xLjcyODYgNS40Njk5LTMuMDk4OSA1LjU0NTQtMy4wNzM3IDAuMDk2NjEgMC4wMzIyIDAuMTY1OTQgNS40Njk2IDAuMjEyOTEgMTYuNjg1bDAuMDY5NzYgMTYuNjM4IDAuMzI3MTEgMC42MjY4NGMwLjA2NjMzIDAuMTI3MTIgMC42NzQ2MSAwLjc4NDA3IDEuNTg0NCAxLjczNjNsMC4wNjU2My0wLjA2NTExIDI1Ljg5OCAyNi4yMDUgMC4wMjQ4MSAwLjAyNTMgNC42MjYxIDQuNjMwNyA0LjM5MyAxNy42OTVjMy41NjM4IDE0LjM1NSA0LjQ4MzQgMTcuODc5IDQuODczMSAxOC42NzUgMC45NjU3NiAxLjk3MjUgMy4yMDcyIDMuNjI1OCA1LjM3MDIgMy45NjE1IDEuMTQ1OCAwLjE3Nzc4IDEuNTI3NCAwLjE2Njk4IDIuNjQ3NC0wLjA3NTQgMS40NDM4LTAuMzEyNjggMi41OTAyLTAuOTU0OTMgMy42OTQzLTIuMDY5MSAxLjA0OTctMS4wNTkzIDEuNTk3Ni0yLjAwMzMgMS45NDM2LTMuMzQ5NyAwLjQ3MjYxLTEuODM5IDAuNjQ4MzgtMS4wMTY3LTUuMjM3NC0yNC41MDctMi45OTgtMTEuOTY1LTUuNTc1Ni0yMi4xLTUuNzI4My0yMi41MjEtMC4yNTg4Ny0wLjcxNDQtMC45NDY5NS0xLjQzNjItMTAuMTU0LTEwLjY2bC02LjYwOTQtNi42MjE5LTMuMjY2NS0zLjI3MjctMC4yMTcwNC0wLjIxNzA0di0yMi40NTFjLTcuOGUtNCAtMC43ODAyLTAuMDAyNS00LjM3MTMgMC04LjQwODN2LTExLjIyN2MtMC4wODMxNy0xLjM2ODctMS4wMzc1LTEuNzcyMS02Ljg4NDMtNS4xNDctMi45NDgtMS43MDE2LTUuNzA2Ny0zLjIxNzEtNi4xMzA0LTMuMzY4My0wLjYwMDAyLTAuMjE0MDgtMS42MjUyLTAuMzQ0MzktMi41NjI2LTAuMzU4NjN6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zMS4wNjEgOC45MjM5Yy0wLjQyMTk0IDQuMDMyMyAxLjA1OTUgOC4zMjA2IDMuMzI4NCAxMS42OTkgMS4zNDk2IDIuMDA5MyAzLjMxMDIgMy41OTUzIDUuMzI0NCA0LjkzNzUgMi42NDQ4IDEuNzYyNSA1LjU2NzIgMy4yOTE1IDguNjc1MiAzLjk1NjcgMS4xODk2IDAuMjU0NTggMi41MDE2IDAuMzgwMjIgMy42NDk0LTAuMDIyOCAxLjQzNDQtMC41MDM2NSAyLjcyNjEtMS41Njk0IDMuNTc3NC0yLjgyOSAxLjI5NzQtMS45MTk1IDEuNjg4OC00LjM2NjEgMS45Njc3LTYuNjY2IDAuMjg4NjYtMi4zNzk5IDAuMzUxOS00Ljg4NTctMC4zMjgxMi03LjE4NDctMC44MjI3NS0yLjc4MTUtMi40Mjk0LTUuMzc3NS00LjM5NTctNy41MDk5LTEuODEyMi0xLjk2NTMtNC4wNDAyLTMuNzM2My02LjU3MDctNC41OTgzLTIuMzY2Ny0wLjgwNjItNS4wNjA0LTAuOTIzMDQtNy40OTI5LTAuMzQ1LTEuNzAyIDAuNDA0NDMtMy4zNTMzIDEuMzIwNC00LjU3MzUgMi41NzM5LTEuNTc0NiAxLjYxNzYtMi45MjY2IDMuNzQzOC0zLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTE5Ljc4OCA0MC4xOGMtMTAuNzY4IDMuNjUwOC0xMS4zNSAzLjk0OTYtMTIuNTggNS40NjEyLTEuMzI1OCAxLjYyOTUtMS4zNjcgMC45NTI4Mi00LjU1NDYgMTYuOTU3IDAgMC0yLjIyNTcgOS4yMzYtMi42NTA2IDE0LjM4NC0wLjAyMzk1NSAwLjI5MDI0IDAuMTYwMiAwLjg1ODg2IDAuMTYwMiAwLjg1ODg2IDAuMjA5NDIgMS4xMjMzIDEuMTgxNSAyLjcwOTIgMi4wODYyIDMuNDAzNCAyLjc5MzggMi4xNDM3IDYuNTU4NyAxLjQ4MzMgOC41NTM1LTEuNTAwNyAwLjQxOTg1LTAuNjI4MDUgMC40NjgyNS0wLjgzNjk1IDMuMDgwOS0xMy40MzZsMi42NTM2LTEyLjc5OCAwLjE5MTItMC43MTI2MiA5Ljg1MzktNS42NjQ0IDEuMDk0My01LjM2MDJ6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.00612" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="54" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwNC42Mm1tIiBoZWlnaHQ9IjE4My44N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDQuNjIgMTgzLjg3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC43NjIyMyAtNTUuOTg0KSI+PHBhdGggZD0ibTE1NC45NyA3NS45OWExMTMuMjIgMTEzLjIyIDAgMCAwLTE1NS43MyAyNi40OTIgMzkuMjYzIDM5LjI2MyAwIDAgMSA1Mi44NTctNy42NDg3IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MiAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NTY0IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MSAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NDkyIDM5LjI2MyAzOS4yNjMgMCAwIDEgMTAuNTcxIDUzLjc3MyAxMTMuMjIgMTEzLjIyIDAgMCAwLTI5LjQxNS0xNTYuNjV6Ii8+PHBhdGggZD0ibTE2LjM5NCAyMDUuOTRzLTIuMjQyNyA1LjczNTctMi4yODM3IDguNzQ5N2MtMC4wNjY3MiA0LjkwNzYgMC4yMDA2NiAxMC41NjIgMy4zMjk4IDE0LjM0MyAzLjEzMjEgMy43ODQ4IDguNTcgNi4xMzc3IDEzLjQ3OSA1Ljk1OTUgNC41MTkzLTAuMTY0MDYgOS4yMDgtMi43OTY0IDExLjk3OC02LjM3MTIgNDYuMjYyLTU5LjcwNiAxMjMuNzItMTY3LjI2IDEyMy43Mi0xNjcuMjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="55" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="225,89,137,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="56" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk5LjA0OW1tIiBoZWlnaHQ9IjE2MC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5OS4wNDkgMTYwLjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0zOC4xNjkgMTcuNzk3YTI1LjYxNiAyNS42MTYgMCAwIDAtMjUuNjE3IDI1LjYxNyAyNS42MTYgMjUuNjE2IDAgMCAwIDI1LjYxNyAyNS42MTYgMjUuNjE2IDI1LjYxNiAwIDAgMCAyNS42MTYtMjUuNjE2IDI1LjYxNiAyNS42MTYgMCAwIDAtMC4wNTYzLTEuNjYyOWMtMi42NTQyIDEuMjg1Ny00LjgzNTQgMy40NzYzLTYuNzUgNS43MTk1LTEuMzc0NyAxLjYxMDYtMy4yOTM5IDUuNDMxNy0zLjI5MzkgNS40MzE3cy0zLjg0NDMgMi45ODEzLTUuNjYxNyAyLjExMjVjLTEuOTk1NS0wLjk1Mzk4LTIuMzk3Mi00LjEwMzItMi4wOTg2LTYuMjk0NyAwLjQ2Njg0LTMuNDI2MyAzLjE3NjMtNi4zNDU4IDUuNzk0LTguNjA1MiAyLjk3OS0yLjU3MTMgMTAuNjUtNS4wOTE4IDEwLjY1My01LjA5MjdhMjUuNjE2IDI1LjYxNiAwIDAgMC0xZS0zIC0zZS0zYy05ZS0zIC0wLjAxNzQtMy45MjUtNy40MTI2LTYuODgxMi0xMC4yODMtMS4yMDI1LTEuMTY3Ny0yLjY1MjYtMi4zMzQ0LTQuMjY4LTMuMzYyMWEyNS42MTYgMjUuNjE2IDAgMCAwLTEzLjA1Mi0zLjU3NjZ6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTc1LjM4NCAzOC42OGEyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NiAyMy42NjUgMjMuNjY1IDIzLjY2NSAwIDAgMCAyMy42NjYgMjMuNjY2IDIzLjY2NSAyMy42NjUgMCAwIDAgMjMuNjY1LTIzLjY2NiAyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NS0yMy42NjV6bTIuNTkxNiAxMS44ODdjMy41MTI2IDAuMDU3OSA4LjIwODIgMy43Njk0IDkuNDYyNSA2LjgxNjEgMS44NDkgNC40OTEyLTAuMzE2MDQgMTQuMTg0LTUuNTAzIDEzLjQ4OS0zLjYwNDYtMC40ODM0IDAuMzE1MzItNi43ODg0LTAuNzI3MDgtOS45ODQ0LTEuMTI2Mi0zLjQ1MjktOC41NTY1LTYuODM5Ny01LjgwMzMtOS40MTQ5IDAuNjk2NTMtMC42NTE0OSAxLjU4NzQtMC45MjE1NyAyLjU3MDktMC45MDUzN3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48cGF0aCBkPSJtNTMuNjg1IDUyLjkwMS01LjJlLTQgMWUtM3MtMy44NDQzIDIuOTgxMy01LjY2MTcgMi4xMTI1bC0yNC4wMzUgOS43MzIyIDQzLjg3MyAyMC4wMDN6Ii8+PHBhdGggZD0ibTcxLjEzNyAwYy0xMC4wNDMgMC4wMTIwMi0xOS4wODIgNi4wOTU0LTIyLjg3NSAxNS4zOTUgMi43OTkxIDAuNDYwNjcgNS41MDIyIDEuMzgzMSA3Ljk5OSAyLjcyOTUgMC4yMjgwOSAwLjExNzI2IDAuNDUzNjIgMC4yMzk0MSAwLjY3NjQ0IDAuMzY2MzkgMC4wODUzNSAwLjA0NTY4IDAuMTcwNDUgMC4wOTE4NSAwLjI1NTI4IDAuMTM4NDkgMC4xMzMxNyAwLjA4NDcyIDAuMjYzNDEgMC4xNzE4NSAwLjM5NDI5IDAuMjU4MzggMC42MDg2MiAwLjM4NDEgMS4xOTM1IDAuODA0NjUgMS43NTEzIDEuMjU5NCAwLjc2ODg2IDAuNjAwNzUgMS40ODE2IDEuMjIyMiAyLjEyMjQgMS44NDQzIDIuNzk3OCAyLjcxNjcgNi40MTM2IDkuNDA5MyA2LjgwNTMgMTAuMTQyIDIuMTk3Ni0wLjY2NTI0IDQuNDgwMy0xLjAwNzEgNi43NzYzLTEuMDE0OSA2LjMyNzMgMC4wMDYxIDEyLjM4OSAyLjU0NTggMTYuODMgNy4wNTE4IDIuNjAwNi0zLjk5OSAzLjk4OTUtOC42NjQ2IDMuOTk5Mi0xMy40MzUtNy42ZS01IC0xMy42NjEtMTEuMDc0LTI0LjczNS0yNC43MzUtMjQuNzM1em00Ljc5NjEgOC41NzA1YzQuMDgyNi0wLjA1NzEyIDguMTg0NyA0Ljk5OSA4Ljg5ODcgOS4wNzMzIDAuNzYxOTIgNC4zNDc4LTAuODU4NDcgMTEuNzY4LTUuMTc5NiAxMC44NjctMy4xNjM5LTAuNjU5OS0wLjYxMzY4LTUuNjgwNC0xLjUzNjgtOC43Nzc4LTAuODcyMi0yLjkyNjYtNC40MDYxLTQuOTI3MS00LjUwMS03Ljk3OTQtMC4wMzU3LTEuMTQ4NCAwLjM3NDY4LTIuODg4OSAxLjUwMzgtMy4xMDE2IDAuMjcwOTktMC4wNTEwNyAwLjU0Mjc3LTAuMDc3ODM5IDAuODE0OTQtMC4wODE2NDl6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTEyLjk3MSA2Mi41NzctMTIuOTcxIDk3LjUxOCA3MS4wOTItNjcuNDg5cy00Ljc4MDggMS40NDQtNi45MDk3IDAuNTQ2MjJjLTE2LjEwOS02Ljc5MzQtMzEuNDMtMTMuNzY4LTQ1Ljk1Mi0yMi45NzEtMi42MDM0LTEuNjQ5OC01LjI1OTYtNy42MDQyLTUuMjU5Ni03LjYwNDJ6bTM2LjIyMSAyOS4zMDVjMS42ODYgMC4wNDE5IDMuMDUxOSAxLjM5MTggMy4wOTU0IDMuMDk3NWwwLjAxNyAwLjY3OTU1YzAuMDQ0OSAxLjc2MDctMS4zMzYzIDMuMjE0My0zLjA5NyAzLjI1OTJsLTI2LjIxNiAwLjY2ODY5Yy0xLjc2MDcgMC4wNDQ5LTMuMjE0My0xLjMzNjMtMy4yNTkyLTMuMDk3bC0wLjAxNzUyLTAuNjgwMDZjLTAuMDQ0OS0xLjc2MDcgMS4zMzY4LTMuMjE0MyAzLjA5NzUtMy4yNTkybDI2LjIxNi0wLjY2ODE4YzAuMDU1LTFlLTMgMC4xMDk0My0yZS0zIDAuMTYzODItNS4xZS00em0tMTEuMjU3IDE1LjI5N2MxLjY4NDkgMC4wMjc4IDMuMDQxNSAxLjM2NiAzLjA3NDIgMy4wNzE2bDAuMDEyOSAwLjY4MDA2YzAuMDMzOCAxLjc2MDctMS4zNTYxIDMuMjI2LTMuMTE2MSAzLjI4NTZsLTE4LjE1OCAwLjYxNTQ3Yy0xLjc2IDAuMDU5Ni0zLjIwNDMtMS4zMDk5LTMuMjM4LTMuMDcwNmwtMC4wMTI5Mi0wLjY3OTU0Yy0wLjAzMzc5LTEuNzYwNyAxLjM1NjEtMy4yMjY1IDMuMTE2MS0zLjI4NjFsMTguMTU4LTAuNjE1NDZjMC4wNTUtMmUtMyAwLjEwOTQ2LTJlLTMgMC4xNjM4MS0xZS0zem0tMTUuNjIgMTQuMTk0YzEuNjQyNCA5ZS0zIDIuOTM5NCAxLjI4NDQgMi45NTQ5IDIuOTYyNmwwLjAwNjIgMC42Nzk1NGMwLjAxNjIyIDEuNzYwNy0xLjM4NDUgMy4yNzc5LTMuMTQwOSAzLjQwMTlsLTUuNDI5MSAwLjM4MzQ0Yy0xLjc1NjQgMC4xMjM5Ni0zLjE4MzYtMS4xOTM2LTMuMTk5OC0yLjk1NDNsLTAuMDA2Mi0wLjY4MDA2Yy0wLjAxNjIyLTEuNzYwNyAxLjM4NDUtMy4yNzc5IDMuMTQwOS0zLjQwMTlsNS40MjkxLTAuMzgyOTNjMC4wODIzMy02ZS0zIDAuMTY0MTctOWUtMyAwLjI0NDk1LThlLTN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.34102" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="57" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS42Mm1tIiBoZWlnaHQ9IjE0OS41Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDkuNjIgMTQ5LjU2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxjaXJjbGUgY3g9IjE0MS44MSIgY3k9Ijc1LjYyIiByPSI2LjI1MzkiLz48Y2lyY2xlIGN4PSI3LjgwMzkiIGN5PSI3NS42MiIgcj0iNi4yNTM5Ii8+PHJlY3QgeD0iMy4xNzAyZS03IiB5PSIxMzcuNDkiIHdpZHRoPSIxNDkuNjIiIGhlaWdodD0iMTIuMDY5IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjIuNTc1MiIvPjwvZz48Y2lyY2xlIGN4PSI3NC44MDkiIGN5PSIxMy45NjEiIHI9IjEwLjUxMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjYuOSIvPjxwYXRoIGQ9Im02OS4xNDggMjIuNDY3LTU3LjQ3NCA0OS4xOTIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI0LjUiLz48Zz48cGF0aCBkPSJtNjYuNTk3IDIwLjg4LTQ3LjkyIDEwOC44OSA5LjY4NDctMWUtNSA0Ni4zNDktMTA1LjMyeiIvPjxwYXRoIGQ9Im0xNy43NDcgNzUuMzI2YzAuMDA3MyAwLjA5NzkgMC4wMTMxNiAwLjE5NTk1IDAuMDE3NTcgMC4yOTQwNCA0ZS01IDUuNTAwOC00LjQ1OTMgOS45NjAyLTkuOTYwMSA5Ljk2MDEtMC42NTQ4OS0yZS0zIC0xLjMwOC0wLjA2OS0xLjk0OTgtMC4xOTk0NyAyLjE0NDggNC42Mzk3IDUuNTM4OCAxMS42MzEgOC4yMzgzIDE1LjU2MSAyLjM1NzcgMy40MzI5IDguMzQxMSA5LjMwMTIgOC4zNDExIDkuMzAxMmwwLjM1MTQgMC4xMTYyNyAxNS40MTgtMzUuMDM0em0zNi41NDggOC4xNDI3LTE0LjMzNiAzMi41NzdzMi40MDIyIDEuMjI1OCAzLjcwMjEgMS4yMjU4aDMxLjE0OHYtMjkuMjc5Yy04LjEyNzItMmUtMyAtMTUuNzU4LTEuNjg1LTIwLjUxNS00LjUyMzh6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iLjIiLz48cGF0aCBkPSJtMTMuMzQ5IDY3LjUxM3Y1LjQ0NjJoMjUuODk2bDIuMzk2OC01LjQ0NjJ6Ii8+PHBhdGggZD0ibTU3LjgwNCA3NS4zMjYtMi41NzMxIDUuMzkxNGM1LjE2MDcgMi4wODY1IDEyLjIxNSAzLjI2MjEgMTkuNTc4IDMuMjYyOHYtNi4zMDM1Yy02LjE3MjItMmUtMyAtMTQuMzQ2LTEuNjM4My0xNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTgwLjQ3IDIyLjQ2NyA1Ny40NzQgNDkuMTkyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNC41Ii8+PGc+PHBhdGggZD0ibTgzLjAyMSAyMC44OCA0Ny45MiAxMDguODktOS42ODQ3LTFlLTUgLTQ2LjM0OS0xMDUuMzJ6Ii8+PHBhdGggZD0ibTExMS40MiA3NS4zMjYgMTUuNDE4IDM1LjAzNCAwLjM1MTM5LTAuMTE2MjdzNS45ODM0LTUuODY4NCA4LjM0MTEtOS4zMDEyYzIuNjk5NC0zLjkzMDQgNi4wOTM1LTEwLjkyMiA4LjIzODItMTUuNTYxLTAuNjQxNzcgMC4xMzA0Ny0xLjI5NDkgMC4xOTc0Ny0xLjk0OTggMC4xOTk0Ny01LjUwMDggM2UtNSAtOS45NjAyLTQuNDU5My05Ljk2MDEtOS45NjAxIDRlLTMgLTAuMDk4MDkgMC4wMTA2LTAuMTk2MTQgMC4wMTc2LTAuMjk0MDR6bS0xNi4wOTIgOC4xNDI3Yy00Ljc1NjYgMi44Mzg3LTEyLjM4NyA0LjUyMTgtMjAuNTE1IDQuNTIzOHYyOS4yNzloMzEuMTQ4YzEuMjk5OSAwIDMuNzAyMS0xLjIyNTggMy43MDIxLTEuMjI1OHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMiIvPjxwYXRoIGQ9Im0xMzYuMjcgNjcuNTEzdjUuNDQ2MmgtMjUuODk2bC0yLjM5NjgtNS40NDYyeiIvPjxwYXRoIGQ9Im05MS44MTQgNzUuMzI2IDIuNTczMSA1LjM5MTRjLTUuMTYwNyAyLjA4NjUtMTIuMjE1IDMuMjYyMS0xOS41NzggMy4yNjI4di02LjMwMzVjNi4xNzIyLTJlLTMgMTQuMzQ2LTEuNjM4MyAxNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTc0LjgwOSAxMTcuMzd2LTI5LjQ4MiIgZmlsbD0iIzAwZiIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEuNDciLz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="58" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg1LjAyM21tIiBoZWlnaHQ9IjE1Mi43M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4NS4wMjMgMTUyLjczIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im01OCA1OS44ODJ2MTYuMzc0bDguOTcyMSA5LjAyNjNjMy4zNjI3IDMuMzgzMSA3Ljg5NTUgNC4yOTIyIDEwLjE2MyAyLjAzODEgMi4yNjc3LTIuMjU0MSAxLjM4NjEtNi43OTI1LTEuOTc2Ni0xMC4xNzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjQ2NSIvPjxwYXRoIGQ9Im0zNi4zNTUgOTIuNTdjLTIuNjIyNSA0LjUyNjctNS42NDA2IDkuNzQyNC05LjIwNjcgMTUuOTIyLTguMzM2MiAxNC40NDUtMTUuNDA4IDI2LjYzNS0xNS43MTYgMjcuMDktMC45MDA0IDEuMzMyOS0xLjI2MjUgMi41MzU4LTEuMjYwNCA0LjE4NzggMC4wMDE2IDEuMDc5OCAwLjA3MjAxIDEuNTkzNCAwLjMxMzE2IDIuMjgzMSAxLjA3NzkgMy4wODI2IDMuODYyNSA1LjA1NDIgNy4wOTQxIDUuMDIyNCAwLjUxMzQ3LTVlLTMgMS4yNzgyLTAuMTAwNTIgMS42OTk2LTAuMjEyMzkgMS43MDc4LTAuNDUzMzEgMy4xMTE3LTEuNDUxOCA0LjM3MTgtMy4xMDk0IDAuNDMzMzctMC41NzAwNiAxNC45MTktMjUuNTU5IDIzLjQyNS00MC4zMzV6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zOC4wMjQgMjguMzUxYy0wLjU2MjQzLTAuMDA4NS0xLjA5MzQgMC4wMjQ2Ni0xLjQ4MjEgMC4xMDY0NS0wLjQyMTQ2IDAuMDg4NjgtMS4xMTA3IDAuMzAzMjYtMS41MzIyIDAuNDc2OTctMC40MjE0NiAwLjE3MzcxLTYuNDk1OSAzLjYzNTctMTMuNDk4IDcuNjkzMS0xMC40NDQgNi4wNTE1LTEyLjk3NSA3LjUxNTItMTQuMDE3IDguNjcyM2wxNi4wNDQgMC4wMDE2djMuNTYzNmMzLjAwMS0xLjcyODYgNS40Njk5LTMuMDk4OSA1LjU0NTQtMy4wNzM3IDAuMDk2NjEgMC4wMzIyIDAuMTY1OTQgNS40Njk2IDAuMjEyOTEgMTYuNjg1bDAuMDY5NzYgMTYuNjM4IDAuMzI3MTEgMC42MjY4NGMwLjA2NjMzIDAuMTI3MTIgMC42NzQ2MSAwLjc4NDA3IDEuNTg0NCAxLjczNjNsMC4wNjU2My0wLjA2NTExIDI1Ljg5OCAyNi4yMDUgMC4wMjQ4MSAwLjAyNTMgNC42MjYxIDQuNjMwNyA0LjM5MyAxNy42OTVjMy41NjM4IDE0LjM1NSA0LjQ4MzQgMTcuODc5IDQuODczMSAxOC42NzUgMC45NjU3NiAxLjk3MjUgMy4yMDcyIDMuNjI1OCA1LjM3MDIgMy45NjE1IDEuMTQ1OCAwLjE3Nzc4IDEuNTI3NCAwLjE2Njk4IDIuNjQ3NC0wLjA3NTQgMS40NDM4LTAuMzEyNjggMi41OTAyLTAuOTU0OTMgMy42OTQzLTIuMDY5MSAxLjA0OTctMS4wNTkzIDEuNTk3Ni0yLjAwMzMgMS45NDM2LTMuMzQ5NyAwLjQ3MjYxLTEuODM5IDAuNjQ4MzgtMS4wMTY3LTUuMjM3NC0yNC41MDctMi45OTgtMTEuOTY1LTUuNTc1Ni0yMi4xLTUuNzI4My0yMi41MjEtMC4yNTg4Ny0wLjcxNDQtMC45NDY5NS0xLjQzNjItMTAuMTU0LTEwLjY2bC02LjYwOTQtNi42MjE5LTMuMjY2NS0zLjI3MjctMC4yMTcwNC0wLjIxNzA0di0yMi40NTFjLTcuOGUtNCAtMC43ODAyLTAuMDAyNS00LjM3MTMgMC04LjQwODN2LTExLjIyN2MtMC4wODMxNy0xLjM2ODctMS4wMzc1LTEuNzcyMS02Ljg4NDMtNS4xNDctMi45NDgtMS43MDE2LTUuNzA2Ny0zLjIxNzEtNi4xMzA0LTMuMzY4My0wLjYwMDAyLTAuMjE0MDgtMS42MjUyLTAuMzQ0MzktMi41NjI2LTAuMzU4NjN6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zMS4wNjEgOC45MjM5Yy0wLjQyMTk0IDQuMDMyMyAxLjA1OTUgOC4zMjA2IDMuMzI4NCAxMS42OTkgMS4zNDk2IDIuMDA5MyAzLjMxMDIgMy41OTUzIDUuMzI0NCA0LjkzNzUgMi42NDQ4IDEuNzYyNSA1LjU2NzIgMy4yOTE1IDguNjc1MiAzLjk1NjcgMS4xODk2IDAuMjU0NTggMi41MDE2IDAuMzgwMjIgMy42NDk0LTAuMDIyOCAxLjQzNDQtMC41MDM2NSAyLjcyNjEtMS41Njk0IDMuNTc3NC0yLjgyOSAxLjI5NzQtMS45MTk1IDEuNjg4OC00LjM2NjEgMS45Njc3LTYuNjY2IDAuMjg4NjYtMi4zNzk5IDAuMzUxOS00Ljg4NTctMC4zMjgxMi03LjE4NDctMC44MjI3NS0yLjc4MTUtMi40Mjk0LTUuMzc3NS00LjM5NTctNy41MDk5LTEuODEyMi0xLjk2NTMtNC4wNDAyLTMuNzM2My02LjU3MDctNC41OTgzLTIuMzY2Ny0wLjgwNjItNS4wNjA0LTAuOTIzMDQtNy40OTI5LTAuMzQ1LTEuNzAyIDAuNDA0NDMtMy4zNTMzIDEuMzIwNC00LjU3MzUgMi41NzM5LTEuNTc0NiAxLjYxNzYtMi45MjY2IDMuNzQzOC0zLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTE5Ljc4OCA0MC4xOGMtMTAuNzY4IDMuNjUwOC0xMS4zNSAzLjk0OTYtMTIuNTggNS40NjEyLTEuMzI1OCAxLjYyOTUtMS4zNjcgMC45NTI4Mi00LjU1NDYgMTYuOTU3IDAgMC0yLjIyNTcgOS4yMzYtMi42NTA2IDE0LjM4NC0wLjAyMzk1NSAwLjI5MDI0IDAuMTYwMiAwLjg1ODg2IDAuMTYwMiAwLjg1ODg2IDAuMjA5NDIgMS4xMjMzIDEuMTgxNSAyLjcwOTIgMi4wODYyIDMuNDAzNCAyLjc5MzggMi4xNDM3IDYuNTU4NyAxLjQ4MzMgOC41NTM1LTEuNTAwNyAwLjQxOTg1LTAuNjI4MDUgMC40NjgyNS0wLjgzNjk1IDMuMDgwOS0xMy40MzZsMi42NTM2LTEyLjc5OCAwLjE5MTItMC43MTI2MiA5Ljg1MzktNS42NjQ0IDEuMDk0My01LjM2MDJ6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.00612" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="59" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwNC42Mm1tIiBoZWlnaHQ9IjE4My44N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDQuNjIgMTgzLjg3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC43NjIyMyAtNTUuOTg0KSI+PHBhdGggZD0ibTE1NC45NyA3NS45OWExMTMuMjIgMTEzLjIyIDAgMCAwLTE1NS43MyAyNi40OTIgMzkuMjYzIDM5LjI2MyAwIDAgMSA1Mi44NTctNy42NDg3IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MiAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NTY0IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MSAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NDkyIDM5LjI2MyAzOS4yNjMgMCAwIDEgMTAuNTcxIDUzLjc3MyAxMTMuMjIgMTEzLjIyIDAgMCAwLTI5LjQxNS0xNTYuNjV6Ii8+PHBhdGggZD0ibTE2LjM5NCAyMDUuOTRzLTIuMjQyNyA1LjczNTctMi4yODM3IDguNzQ5N2MtMC4wNjY3MiA0LjkwNzYgMC4yMDA2NiAxMC41NjIgMy4zMjk4IDE0LjM0MyAzLjEzMjEgMy43ODQ4IDguNTcgNi4xMzc3IDEzLjQ3OSA1Ljk1OTUgNC41MTkzLTAuMTY0MDYgOS4yMDgtMi43OTY0IDExLjk3OC02LjM3MTIgNDYuMjYyLTU5LjcwNiAxMjMuNzItMTY3LjI2IDEyMy43Mi0xNjcuMjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk5LjA0OW1tIiBoZWlnaHQ9IjE2MC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA5OS4wNDkgMTYwLjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0zOC4xNjkgMTcuNzk3YTI1LjYxNiAyNS42MTYgMCAwIDAtMjUuNjE3IDI1LjYxNyAyNS42MTYgMjUuNjE2IDAgMCAwIDI1LjYxNyAyNS42MTYgMjUuNjE2IDI1LjYxNiAwIDAgMCAyNS42MTYtMjUuNjE2IDI1LjYxNiAyNS42MTYgMCAwIDAtMC4wNTYzLTEuNjYyOWMtMi42NTQyIDEuMjg1Ny00LjgzNTQgMy40NzYzLTYuNzUgNS43MTk1LTEuMzc0NyAxLjYxMDYtMy4yOTM5IDUuNDMxNy0zLjI5MzkgNS40MzE3cy0zLjg0NDMgMi45ODEzLTUuNjYxNyAyLjExMjVjLTEuOTk1NS0wLjk1Mzk4LTIuMzk3Mi00LjEwMzItMi4wOTg2LTYuMjk0NyAwLjQ2Njg0LTMuNDI2MyAzLjE3NjMtNi4zNDU4IDUuNzk0LTguNjA1MiAyLjk3OS0yLjU3MTMgMTAuNjUtNS4wOTE4IDEwLjY1My01LjA5MjdhMjUuNjE2IDI1LjYxNiAwIDAgMC0xZS0zIC0zZS0zYy05ZS0zIC0wLjAxNzQtMy45MjUtNy40MTI2LTYuODgxMi0xMC4yODMtMS4yMDI1LTEuMTY3Ny0yLjY1MjYtMi4zMzQ0LTQuMjY4LTMuMzYyMWEyNS42MTYgMjUuNjE2IDAgMCAwLTEzLjA1Mi0zLjU3NjZ6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTc1LjM4NCAzOC42OGEyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NiAyMy42NjUgMjMuNjY1IDIzLjY2NSAwIDAgMCAyMy42NjYgMjMuNjY2IDIzLjY2NSAyMy42NjUgMCAwIDAgMjMuNjY1LTIzLjY2NiAyMy42NjUgMjMuNjY1IDAgMCAwLTIzLjY2NS0yMy42NjV6bTIuNTkxNiAxMS44ODdjMy41MTI2IDAuMDU3OSA4LjIwODIgMy43Njk0IDkuNDYyNSA2LjgxNjEgMS44NDkgNC40OTEyLTAuMzE2MDQgMTQuMTg0LTUuNTAzIDEzLjQ4OS0zLjYwNDYtMC40ODM0IDAuMzE1MzItNi43ODg0LTAuNzI3MDgtOS45ODQ0LTEuMTI2Mi0zLjQ1MjktOC41NTY1LTYuODM5Ny01LjgwMzMtOS40MTQ5IDAuNjk2NTMtMC42NTE0OSAxLjU4NzQtMC45MjE1NyAyLjU3MDktMC45MDUzN3oiIHN0eWxlPSJwYWludC1vcmRlcjpub3JtYWwiLz48cGF0aCBkPSJtNTMuNjg1IDUyLjkwMS01LjJlLTQgMWUtM3MtMy44NDQzIDIuOTgxMy01LjY2MTcgMi4xMTI1bC0yNC4wMzUgOS43MzIyIDQzLjg3MyAyMC4wMDN6Ii8+PHBhdGggZD0ibTcxLjEzNyAwYy0xMC4wNDMgMC4wMTIwMi0xOS4wODIgNi4wOTU0LTIyLjg3NSAxNS4zOTUgMi43OTkxIDAuNDYwNjcgNS41MDIyIDEuMzgzMSA3Ljk5OSAyLjcyOTUgMC4yMjgwOSAwLjExNzI2IDAuNDUzNjIgMC4yMzk0MSAwLjY3NjQ0IDAuMzY2MzkgMC4wODUzNSAwLjA0NTY4IDAuMTcwNDUgMC4wOTE4NSAwLjI1NTI4IDAuMTM4NDkgMC4xMzMxNyAwLjA4NDcyIDAuMjYzNDEgMC4xNzE4NSAwLjM5NDI5IDAuMjU4MzggMC42MDg2MiAwLjM4NDEgMS4xOTM1IDAuODA0NjUgMS43NTEzIDEuMjU5NCAwLjc2ODg2IDAuNjAwNzUgMS40ODE2IDEuMjIyMiAyLjEyMjQgMS44NDQzIDIuNzk3OCAyLjcxNjcgNi40MTM2IDkuNDA5MyA2LjgwNTMgMTAuMTQyIDIuMTk3Ni0wLjY2NTI0IDQuNDgwMy0xLjAwNzEgNi43NzYzLTEuMDE0OSA2LjMyNzMgMC4wMDYxIDEyLjM4OSAyLjU0NTggMTYuODMgNy4wNTE4IDIuNjAwNi0zLjk5OSAzLjk4OTUtOC42NjQ2IDMuOTk5Mi0xMy40MzUtNy42ZS01IC0xMy42NjEtMTEuMDc0LTI0LjczNS0yNC43MzUtMjQuNzM1em00Ljc5NjEgOC41NzA1YzQuMDgyNi0wLjA1NzEyIDguMTg0NyA0Ljk5OSA4Ljg5ODcgOS4wNzMzIDAuNzYxOTIgNC4zNDc4LTAuODU4NDcgMTEuNzY4LTUuMTc5NiAxMC44NjctMy4xNjM5LTAuNjU5OS0wLjYxMzY4LTUuNjgwNC0xLjUzNjgtOC43Nzc4LTAuODcyMi0yLjkyNjYtNC40MDYxLTQuOTI3MS00LjUwMS03Ljk3OTQtMC4wMzU3LTEuMTQ4NCAwLjM3NDY4LTIuODg4OSAxLjUwMzgtMy4xMDE2IDAuMjcwOTktMC4wNTEwNyAwLjU0Mjc3LTAuMDc3ODM5IDAuODE0OTQtMC4wODE2NDl6IiBzdHlsZT0icGFpbnQtb3JkZXI6bm9ybWFsIi8+PHBhdGggZD0ibTEyLjk3MSA2Mi41NzctMTIuOTcxIDk3LjUxOCA3MS4wOTItNjcuNDg5cy00Ljc4MDggMS40NDQtNi45MDk3IDAuNTQ2MjJjLTE2LjEwOS02Ljc5MzQtMzEuNDMtMTMuNzY4LTQ1Ljk1Mi0yMi45NzEtMi42MDM0LTEuNjQ5OC01LjI1OTYtNy42MDQyLTUuMjU5Ni03LjYwNDJ6bTM2LjIyMSAyOS4zMDVjMS42ODYgMC4wNDE5IDMuMDUxOSAxLjM5MTggMy4wOTU0IDMuMDk3NWwwLjAxNyAwLjY3OTU1YzAuMDQ0OSAxLjc2MDctMS4zMzYzIDMuMjE0My0zLjA5NyAzLjI1OTJsLTI2LjIxNiAwLjY2ODY5Yy0xLjc2MDcgMC4wNDQ5LTMuMjE0My0xLjMzNjMtMy4yNTkyLTMuMDk3bC0wLjAxNzUyLTAuNjgwMDZjLTAuMDQ0OS0xLjc2MDcgMS4zMzY4LTMuMjE0MyAzLjA5NzUtMy4yNTkybDI2LjIxNi0wLjY2ODE4YzAuMDU1LTFlLTMgMC4xMDk0My0yZS0zIDAuMTYzODItNS4xZS00em0tMTEuMjU3IDE1LjI5N2MxLjY4NDkgMC4wMjc4IDMuMDQxNSAxLjM2NiAzLjA3NDIgMy4wNzE2bDAuMDEyOSAwLjY4MDA2YzAuMDMzOCAxLjc2MDctMS4zNTYxIDMuMjI2LTMuMTE2MSAzLjI4NTZsLTE4LjE1OCAwLjYxNTQ3Yy0xLjc2IDAuMDU5Ni0zLjIwNDMtMS4zMDk5LTMuMjM4LTMuMDcwNmwtMC4wMTI5Mi0wLjY3OTU0Yy0wLjAzMzc5LTEuNzYwNyAxLjM1NjEtMy4yMjY1IDMuMTE2MS0zLjI4NjFsMTguMTU4LTAuNjE1NDZjMC4wNTUtMmUtMyAwLjEwOTQ2LTJlLTMgMC4xNjM4MS0xZS0zem0tMTUuNjIgMTQuMTk0YzEuNjQyNCA5ZS0zIDIuOTM5NCAxLjI4NDQgMi45NTQ5IDIuOTYyNmwwLjAwNjIgMC42Nzk1NGMwLjAxNjIyIDEuNzYwNy0xLjM4NDUgMy4yNzc5LTMuMTQwOSAzLjQwMTlsLTUuNDI5MSAwLjM4MzQ0Yy0xLjc1NjQgMC4xMjM5Ni0zLjE4MzYtMS4xOTM2LTMuMTk5OC0yLjk1NDNsLTAuMDA2Mi0wLjY4MDA2Yy0wLjAxNjIyLTEuNzYwNyAxLjM4NDUtMy4yNzc5IDMuMTQwOS0zLjQwMTlsNS40MjkxLTAuMzgyOTNjMC4wODIzMy02ZS0zIDAuMTY0MTctOWUtMyAwLjI0NDk1LThlLTN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.34102" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0OS42Mm1tIiBoZWlnaHQ9IjE0OS41Nm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDkuNjIgMTQ5LjU2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxjaXJjbGUgY3g9IjE0MS44MSIgY3k9Ijc1LjYyIiByPSI2LjI1MzkiLz48Y2lyY2xlIGN4PSI3LjgwMzkiIGN5PSI3NS42MiIgcj0iNi4yNTM5Ii8+PHJlY3QgeD0iMy4xNzAyZS03IiB5PSIxMzcuNDkiIHdpZHRoPSIxNDkuNjIiIGhlaWdodD0iMTIuMDY5IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjIuNTc1MiIvPjwvZz48Y2lyY2xlIGN4PSI3NC44MDkiIGN5PSIxMy45NjEiIHI9IjEwLjUxMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjYuOSIvPjxwYXRoIGQ9Im02OS4xNDggMjIuNDY3LTU3LjQ3NCA0OS4xOTIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSI0LjUiLz48Zz48cGF0aCBkPSJtNjYuNTk3IDIwLjg4LTQ3LjkyIDEwOC44OSA5LjY4NDctMWUtNSA0Ni4zNDktMTA1LjMyeiIvPjxwYXRoIGQ9Im0xNy43NDcgNzUuMzI2YzAuMDA3MyAwLjA5NzkgMC4wMTMxNiAwLjE5NTk1IDAuMDE3NTcgMC4yOTQwNCA0ZS01IDUuNTAwOC00LjQ1OTMgOS45NjAyLTkuOTYwMSA5Ljk2MDEtMC42NTQ4OS0yZS0zIC0xLjMwOC0wLjA2OS0xLjk0OTgtMC4xOTk0NyAyLjE0NDggNC42Mzk3IDUuNTM4OCAxMS42MzEgOC4yMzgzIDE1LjU2MSAyLjM1NzcgMy40MzI5IDguMzQxMSA5LjMwMTIgOC4zNDExIDkuMzAxMmwwLjM1MTQgMC4xMTYyNyAxNS40MTgtMzUuMDM0em0zNi41NDggOC4xNDI3LTE0LjMzNiAzMi41NzdzMi40MDIyIDEuMjI1OCAzLjcwMjEgMS4yMjU4aDMxLjE0OHYtMjkuMjc5Yy04LjEyNzItMmUtMyAtMTUuNzU4LTEuNjg1LTIwLjUxNS00LjUyMzh6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iLjIiLz48cGF0aCBkPSJtMTMuMzQ5IDY3LjUxM3Y1LjQ0NjJoMjUuODk2bDIuMzk2OC01LjQ0NjJ6Ii8+PHBhdGggZD0ibTU3LjgwNCA3NS4zMjYtMi41NzMxIDUuMzkxNGM1LjE2MDcgMi4wODY1IDEyLjIxNSAzLjI2MjEgMTkuNTc4IDMuMjYyOHYtNi4zMDM1Yy02LjE3MjItMmUtMyAtMTQuMzQ2LTEuNjM4My0xNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTgwLjQ3IDIyLjQ2NyA1Ny40NzQgNDkuMTkyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iNC41Ii8+PGc+PHBhdGggZD0ibTgzLjAyMSAyMC44OCA0Ny45MiAxMDguODktOS42ODQ3LTFlLTUgLTQ2LjM0OS0xMDUuMzJ6Ii8+PHBhdGggZD0ibTExMS40MiA3NS4zMjYgMTUuNDE4IDM1LjAzNCAwLjM1MTM5LTAuMTE2MjdzNS45ODM0LTUuODY4NCA4LjM0MTEtOS4zMDEyYzIuNjk5NC0zLjkzMDQgNi4wOTM1LTEwLjkyMiA4LjIzODItMTUuNTYxLTAuNjQxNzcgMC4xMzA0Ny0xLjI5NDkgMC4xOTc0Ny0xLjk0OTggMC4xOTk0Ny01LjUwMDggM2UtNSAtOS45NjAyLTQuNDU5My05Ljk2MDEtOS45NjAxIDRlLTMgLTAuMDk4MDkgMC4wMTA2LTAuMTk2MTQgMC4wMTc2LTAuMjk0MDR6bS0xNi4wOTIgOC4xNDI3Yy00Ljc1NjYgMi44Mzg3LTEyLjM4NyA0LjUyMTgtMjAuNTE1IDQuNTIzOHYyOS4yNzloMzEuMTQ4YzEuMjk5OSAwIDMuNzAyMS0xLjIyNTggMy43MDIxLTEuMjI1OHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMiIvPjxwYXRoIGQ9Im0xMzYuMjcgNjcuNTEzdjUuNDQ2MmgtMjUuODk2bC0yLjM5NjgtNS40NDYyeiIvPjxwYXRoIGQ9Im05MS44MTQgNzUuMzI2IDIuNTczMSA1LjM5MTRjLTUuMTYwNyAyLjA4NjUtMTIuMjE1IDMuMjYyMS0xOS41NzggMy4yNjI4di02LjMwMzVjNi4xNzIyLTJlLTMgMTQuMzQ2LTEuNjM4MyAxNy4wMDUtMi4zNTA4eiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSIzLjIiIHN0cm9rZS13aWR0aD0iLjMiLz48L2c+PHBhdGggZD0ibTc0LjgwOSAxMTcuMzd2LTI5LjQ4MiIgZmlsbD0iIzAwZiIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEuNDciLz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijg1LjAyM21tIiBoZWlnaHQ9IjE1Mi43M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4NS4wMjMgMTUyLjczIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im01OCA1OS44ODJ2MTYuMzc0bDguOTcyMSA5LjAyNjNjMy4zNjI3IDMuMzgzMSA3Ljg5NTUgNC4yOTIyIDEwLjE2MyAyLjAzODEgMi4yNjc3LTIuMjU0MSAxLjM4NjEtNi43OTI1LTEuOTc2Ni0xMC4xNzZ6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIxLjQ2NSIvPjxwYXRoIGQ9Im0zNi4zNTUgOTIuNTdjLTIuNjIyNSA0LjUyNjctNS42NDA2IDkuNzQyNC05LjIwNjcgMTUuOTIyLTguMzM2MiAxNC40NDUtMTUuNDA4IDI2LjYzNS0xNS43MTYgMjcuMDktMC45MDA0IDEuMzMyOS0xLjI2MjUgMi41MzU4LTEuMjYwNCA0LjE4NzggMC4wMDE2IDEuMDc5OCAwLjA3MjAxIDEuNTkzNCAwLjMxMzE2IDIuMjgzMSAxLjA3NzkgMy4wODI2IDMuODYyNSA1LjA1NDIgNy4wOTQxIDUuMDIyNCAwLjUxMzQ3LTVlLTMgMS4yNzgyLTAuMTAwNTIgMS42OTk2LTAuMjEyMzkgMS43MDc4LTAuNDUzMzEgMy4xMTE3LTEuNDUxOCA0LjM3MTgtMy4xMDk0IDAuNDMzMzctMC41NzAwNiAxNC45MTktMjUuNTU5IDIzLjQyNS00MC4zMzV6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zOC4wMjQgMjguMzUxYy0wLjU2MjQzLTAuMDA4NS0xLjA5MzQgMC4wMjQ2Ni0xLjQ4MjEgMC4xMDY0NS0wLjQyMTQ2IDAuMDg4NjgtMS4xMTA3IDAuMzAzMjYtMS41MzIyIDAuNDc2OTctMC40MjE0NiAwLjE3MzcxLTYuNDk1OSAzLjYzNTctMTMuNDk4IDcuNjkzMS0xMC40NDQgNi4wNTE1LTEyLjk3NSA3LjUxNTItMTQuMDE3IDguNjcyM2wxNi4wNDQgMC4wMDE2djMuNTYzNmMzLjAwMS0xLjcyODYgNS40Njk5LTMuMDk4OSA1LjU0NTQtMy4wNzM3IDAuMDk2NjEgMC4wMzIyIDAuMTY1OTQgNS40Njk2IDAuMjEyOTEgMTYuNjg1bDAuMDY5NzYgMTYuNjM4IDAuMzI3MTEgMC42MjY4NGMwLjA2NjMzIDAuMTI3MTIgMC42NzQ2MSAwLjc4NDA3IDEuNTg0NCAxLjczNjNsMC4wNjU2My0wLjA2NTExIDI1Ljg5OCAyNi4yMDUgMC4wMjQ4MSAwLjAyNTMgNC42MjYxIDQuNjMwNyA0LjM5MyAxNy42OTVjMy41NjM4IDE0LjM1NSA0LjQ4MzQgMTcuODc5IDQuODczMSAxOC42NzUgMC45NjU3NiAxLjk3MjUgMy4yMDcyIDMuNjI1OCA1LjM3MDIgMy45NjE1IDEuMTQ1OCAwLjE3Nzc4IDEuNTI3NCAwLjE2Njk4IDIuNjQ3NC0wLjA3NTQgMS40NDM4LTAuMzEyNjggMi41OTAyLTAuOTU0OTMgMy42OTQzLTIuMDY5MSAxLjA0OTctMS4wNTkzIDEuNTk3Ni0yLjAwMzMgMS45NDM2LTMuMzQ5NyAwLjQ3MjYxLTEuODM5IDAuNjQ4MzgtMS4wMTY3LTUuMjM3NC0yNC41MDctMi45OTgtMTEuOTY1LTUuNTc1Ni0yMi4xLTUuNzI4My0yMi41MjEtMC4yNTg4Ny0wLjcxNDQtMC45NDY5NS0xLjQzNjItMTAuMTU0LTEwLjY2bC02LjYwOTQtNi42MjE5LTMuMjY2NS0zLjI3MjctMC4yMTcwNC0wLjIxNzA0di0yMi40NTFjLTcuOGUtNCAtMC43ODAyLTAuMDAyNS00LjM3MTMgMC04LjQwODN2LTExLjIyN2MtMC4wODMxNy0xLjM2ODctMS4wMzc1LTEuNzcyMS02Ljg4NDMtNS4xNDctMi45NDgtMS43MDE2LTUuNzA2Ny0zLjIxNzEtNi4xMzA0LTMuMzY4My0wLjYwMDAyLTAuMjE0MDgtMS42MjUyLTAuMzQ0MzktMi41NjI2LTAuMzU4NjN6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjxwYXRoIGQ9Im0zMS4wNjEgOC45MjM5Yy0wLjQyMTk0IDQuMDMyMyAxLjA1OTUgOC4zMjA2IDMuMzI4NCAxMS42OTkgMS4zNDk2IDIuMDA5MyAzLjMxMDIgMy41OTUzIDUuMzI0NCA0LjkzNzUgMi42NDQ4IDEuNzYyNSA1LjU2NzIgMy4yOTE1IDguNjc1MiAzLjk1NjcgMS4xODk2IDAuMjU0NTggMi41MDE2IDAuMzgwMjIgMy42NDk0LTAuMDIyOCAxLjQzNDQtMC41MDM2NSAyLjcyNjEtMS41Njk0IDMuNTc3NC0yLjgyOSAxLjI5NzQtMS45MTk1IDEuNjg4OC00LjM2NjEgMS45Njc3LTYuNjY2IDAuMjg4NjYtMi4zNzk5IDAuMzUxOS00Ljg4NTctMC4zMjgxMi03LjE4NDctMC44MjI3NS0yLjc4MTUtMi40Mjk0LTUuMzc3NS00LjM5NTctNy41MDk5LTEuODEyMi0xLjk2NTMtNC4wNDAyLTMuNzM2My02LjU3MDctNC41OTgzLTIuMzY2Ny0wLjgwNjItNS4wNjA0LTAuOTIzMDQtNy40OTI5LTAuMzQ1LTEuNzAyIDAuNDA0NDMtMy4zNTMzIDEuMzIwNC00LjU3MzUgMi41NzM5LTEuNTc0NiAxLjYxNzYtMi45MjY2IDMuNzQzOC0zLjE2MTUgNS45ODl6Ii8+PHBhdGggZD0ibTE5Ljc4OCA0MC4xOGMtMTAuNzY4IDMuNjUwOC0xMS4zNSAzLjk0OTYtMTIuNTggNS40NjEyLTEuMzI1OCAxLjYyOTUtMS4zNjcgMC45NTI4Mi00LjU1NDYgMTYuOTU3IDAgMC0yLjIyNTcgOS4yMzYtMi42NTA2IDE0LjM4NC0wLjAyMzk1NSAwLjI5MDI0IDAuMTYwMiAwLjg1ODg2IDAuMTYwMiAwLjg1ODg2IDAuMjA5NDIgMS4xMjMzIDEuMTgxNSAyLjcwOTIgMi4wODYyIDMuNDAzNCAyLjc5MzggMi4xNDM3IDYuNTU4NyAxLjQ4MzMgOC41NTM1LTEuNTAwNyAwLjQxOTg1LTAuNjI4MDUgMC40NjgyNS0wLjgzNjk1IDMuMDgwOS0xMy40MzZsMi42NTM2LTEyLjc5OCAwLjE5MTItMC43MTI2MiA5Ljg1MzktNS42NjQ0IDEuMDk0My01LjM2MDJ6IiBzdHJva2Utd2lkdGg9Ii4xMzkzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.00612" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwNC42Mm1tIiBoZWlnaHQ9IjE4My44N21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDQuNjIgMTgzLjg3IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC43NjIyMyAtNTUuOTg0KSI+PHBhdGggZD0ibTE1NC45NyA3NS45OWExMTMuMjIgMTEzLjIyIDAgMCAwLTE1NS43MyAyNi40OTIgMzkuMjYzIDM5LjI2MyAwIDAgMSA1Mi44NTctNy42NDg3IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MiAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NTY0IDM5LjI2MyAzOS4yNjMgMCAwIDEgMTUuNTg3IDQyLjU4MSAzOS4yNjMgMzkuMjYzIDAgMCAxIDQ1LjI3My0wLjU2NDkyIDM5LjI2MyAzOS4yNjMgMCAwIDEgMTAuNTcxIDUzLjc3MyAxMTMuMjIgMTEzLjIyIDAgMCAwLTI5LjQxNS0xNTYuNjV6Ii8+PHBhdGggZD0ibTE2LjM5NCAyMDUuOTRzLTIuMjQyNyA1LjczNTctMi4yODM3IDguNzQ5N2MtMC4wNjY3MiA0LjkwNzYgMC4yMDA2NiAxMC41NjIgMy4zMjk4IDE0LjM0MyAzLjEzMjEgMy43ODQ4IDguNTcgNi4xMzc3IDEzLjQ3OSA1Ljk1OTUgNC41MTkzLTAuMTY0MDYgOS4yMDgtMi43OTY0IDExLjk3OC02LjM3MTIgNDYuMjYyLTU5LjcwNiAxMjMuNzItMTY3LjI2IDEyMy43Mi0xNjcuMjYiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjkuNyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Тематический парк" value="602010901" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Парк культуры и отдыха" value="602010902" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Пешеходная зона" value="602010903" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Благоустроенный пляж, место массовой околоводной рекреации" value="602010904" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="TPARK_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Зоопарк, зоологический сад" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Парк аттракционов" value="10" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Спортивный парк" value="11" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Научно-познавательные парки" value="12" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Детский парк" value="13" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Парк" value="14" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Сквер" value="15" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Детская игровая площадка" value="16" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иной вид открытых территорий со специализированным набором услуг в области культуры и отдыха" value="17" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Ботанический сад" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Зооботанический парк (сад)" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Этнографический парк" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Экологический парк" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Археологический парк" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Военно-исторический, военно-патриотический парк" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Исторический тематический парк" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Парк искусств" value="9" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="PKIO_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Городского значения" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Районного значения" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Загородные" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="PED_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Улица (проспект, переулок, бульвар, проезд, набережная)" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Площадь" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Набережная" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Сеть улиц, площадей, набережных (пешеходный маршрут)" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Квартал (группа кварталов)" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Сквер" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="AQ_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Пляж I категории" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Пляж II категории" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Пляж III категории" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Оборудованное место массовой околоводной рекреации" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SP_AREA" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CAPACITY" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SEASON" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Круглогодичный" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="более 6 месяцев" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="4 - 6 месяцев" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="до 3 месяцев" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="WRK_COUNT" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FUNCTION" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к ликвидации" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="TPARK_TYPE" index="6" name=""/>
    <alias field="PKIO_TYPE" index="7" name=""/>
    <alias field="PED_TYPE" index="8" name=""/>
    <alias field="AQ_STYPE" index="9" name=""/>
    <alias field="SP_AREA" index="10" name="Площадь территории, кв. м"/>
    <alias field="CAPACITY" index="11" name="Среднесуточная посещаемость, чел."/>
    <alias field="SEASON" index="12" name="Продолжительность работы"/>
    <alias field="WRK_COUNT" index="13" name="Количество рабочих мест, единиц"/>
    <alias field="FUNCTION" index="14" name="Назначение объекта"/>
    <alias field="EVENT_TIME" index="15" name=""/>
    <alias field="SOURCE" index="16" name="Источник данных"/>
    <alias field="STATUS" index="17" name="Статус объекта"/>
    <alias field="REG_STATUS" index="18" name="Значение объекта"/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602010901'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="TPARK_TYPE" expression="if(&quot;CLASSID&quot; = '602010901', attribute('TPARK_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="PKIO_TYPE" expression="if(&quot;CLASSID&quot; = '602010902', attribute('PKIO_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="PED_TYPE" expression="if(&quot;CLASSID&quot; = '602010903', attribute('PED_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="AQ_STYPE" expression="if(&quot;CLASSID&quot; = '602010904', attribute('AQ_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="SP_AREA" expression="0" applyOnUpdate="0"/>
    <default field="CAPACITY" expression="0" applyOnUpdate="0"/>
    <default field="SEASON" expression="1" applyOnUpdate="0"/>
    <default field="WRK_COUNT" expression="0" applyOnUpdate="0"/>
    <default field="FUNCTION" expression="''" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="2" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="TPARK_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="PKIO_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="PED_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="AQ_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SP_AREA" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="CAPACITY" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="SEASON" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="WRK_COUNT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FUNCTION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="TPARK_TYPE" desc="Заполняется для объекта 602010901" exp="if(&quot;CLASSID&quot; = '602010901', &quot;TPARK_TYPE&quot; IS NOT NULL, &quot;TPARK_TYPE&quot; IS NULL)"/>
    <constraint field="PKIO_TYPE" desc="Заполняется для объекта 602010902" exp="if(&quot;CLASSID&quot; = '602010902', &quot;PKIO_TYPE&quot; IS NOT NULL, &quot;PKIO_TYPE&quot; IS NULL)"/>
    <constraint field="PED_TYPE" desc="Заполняется для объекта 602010903" exp="if(&quot;CLASSID&quot; = '602010903', &quot;PED_TYPE&quot; IS NOT NULL, &quot;PED_TYPE&quot; IS NULL)"/>
    <constraint field="AQ_STYPE" desc="Заполняется для объекта 602010904" exp="if(&quot;CLASSID&quot; = '602010904', &quot;AQ_STYPE&quot; IS NOT NULL, &quot;AQ_STYPE&quot; IS NULL)"/>
    <constraint field="SP_AREA" desc="" exp=""/>
    <constraint field="CAPACITY" desc="" exp=""/>
    <constraint field="SEASON" desc="" exp=""/>
    <constraint field="WRK_COUNT" desc="" exp=""/>
    <constraint field="FUNCTION" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "TPARK_TYPE")
    control.setHidden(True)
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="12" name="SEASON">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="17" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="18" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="10" name="SP_AREA">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="11" name="CAPACITY">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="WRK_COUNT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="14" name="FUNCTION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="16" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип тематического парка" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010901'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="6" name="TPARK_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип парка культуры и отдыха" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010902'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="7" name="PKIO_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип пешеходной зоны" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010903'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="8" name="PED_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип благоустроенного пляжа, места массовой околоводной рекреации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010904'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="9" name="AQ_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="15" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="AQ_STYPE" editable="1"/>
    <field name="CAPACITY" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="FUNCTION" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="NAME" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="PED_TYPE" editable="1"/>
    <field name="PKIO_TYPE" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="SEASON" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="SP_AREA" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="TPARK_TYPE" editable="1"/>
    <field name="WRK_COUNT" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="AQ_STYPE"/>
    <field labelOnTop="1" name="CAPACITY"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="FUNCTION"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="PED_TYPE"/>
    <field labelOnTop="1" name="PKIO_TYPE"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="SEASON"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="SP_AREA"/>
    <field labelOnTop="1" name="STATUS"/>
    <field labelOnTop="1" name="TPARK_TYPE"/>
    <field labelOnTop="1" name="WRK_COUNT"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="AQ_STYPE" reuseLastValue="0"/>
    <field name="CAPACITY" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="FUNCTION" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="PED_TYPE" reuseLastValue="0"/>
    <field name="PKIO_TYPE" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="SEASON" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="SP_AREA" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="TPARK_TYPE" reuseLastValue="0"/>
    <field name="WRK_COUNT" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
