<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 symbollevels="0" forceraster="0" type="RuleRenderer" enableorderby="0" referencescale="-1">
    <rules key="{b35949ca-48c1-42f1-940a-b17f92cf948f}">
      <rule key="{56d45d57-560d-42b1-8074-9f856d4bce13}" filter="&quot;TerZoneType&quot; = 'Жилая зона'" symbol="0" label="Жилая зона"/>
      <rule key="{1b9ff75d-4467-4b10-9930-e4613333f2d3}" filter="&quot;TerZoneType&quot; = 'Общественно-деловая зона'" symbol="1" label="Общественно-деловая зона"/>
      <rule key="{9d764008-e55f-4559-b827-ed6216e093ed}" filter="&quot;TerZoneType&quot; = 'Производственная зона, зона инженерной и транспортной инфраструктур'" symbol="2" label="Производственная зона, зона инженерной и транспортной инфраструктур"/>
      <rule key="{bbdaa62a-5726-489c-bb31-12c7dddb43df}" filter="&quot;TerZoneType&quot; = 'Зона сельскохозяйственного использования'" symbol="3" label="Зона сельскохозяйственного использования"/>
      <rule key="{cf51d6aa-bb82-405d-8a31-0343c44c5cc6}" filter="&quot;TerZoneType&quot; = 'Зона рекреационного назначения'" symbol="4" label="Зона рекреационного назначения"/>
      <rule key="{bd841eae-8b37-4317-96cb-4f5435ab2576}" filter="&quot;TerZoneType&quot; = 'Зона особо охраняемых территорий'" symbol="5" label="Зона особо охраняемых территорий"/>
      <rule key="{9a4b670e-7e98-40bd-8fc4-a9842efc4f87}" filter="&quot;TerZoneType&quot; = 'Зона специального назначения'" symbol="6" label="Зона специального назначения"/>
      <rule key="{1ca6a1b2-f725-402e-b03e-a23170330d82}" filter="&quot;TerZoneType&quot; = 'Зона размещения военных объектов'" symbol="7" label="Зона размещения военных объектов"/>
      <rule key="{1aff8243-e237-4ad6-9223-2c39654d5443}" filter="ELSE" symbol="8" label="Иная зона"/>
    </rules>
    <symbols>
      <symbol force_rhr="0" alpha="1" type="fill" name="0" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="251,228,229,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="240,123,131,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.3"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="1" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="218,207,228,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="84,30,137,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.3"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="2" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="222,215,207,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="92,53,17,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.3"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="3" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="252,251,237,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="240,237,165,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.3"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="4" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="217,247,215,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="67,214,54,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.3"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="5" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="214,222,207,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="52,92,13,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.3"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="6" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="219,227,238,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="76,113,168,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.3"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="7" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="235,233,231,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="153,144,135,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.3"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="8" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="248,207,247,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="222,13,215,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.3"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="Guid" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ZoneIndex" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="TerZoneType" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" name="Жилая зона" value="Жилая зона"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Общественно-деловая зона" value="Общественно-деловая зона"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Производственная зона, зона инженерной и транспортной инфраструктур" value="Производственная зона, зона инженерной и транспортной инфраструктур"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Зона сельскохозяйственного использования" value="Зона сельскохозяйственного использования"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Зона рекреационного назначения" value="Зона рекреационного назначения"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Зона особо охраняемых территорий" value="Зона особо охраняемых территорий"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Зона специального назначения" value="Зона специального назначения"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Зона размещения военных объектов" value="Зона размещения военных объектов"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Note" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="Guid" name="Идентификатор объекта"/>
    <alias index="1" field="ZoneIndex" name="Индекс зоны"/>
    <alias index="2" field="TerZoneType" name="Вид территориальной зоны (подзоны)"/>
    <alias index="3" field="Note" name="Примечание"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="1" field="Guid" expression="uuid('WithoutBraces')"/>
    <default applyOnUpdate="0" field="ZoneIndex" expression="''"/>
    <default applyOnUpdate="0" field="TerZoneType" expression="'Жилая зона'"/>
    <default applyOnUpdate="0" field="Note" expression="''"/>
  </defaults>
  <constraints>
    <constraint field="Guid" notnull_strength="1" unique_strength="1" exp_strength="0" constraints="3"/>
    <constraint field="ZoneIndex" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="TerZoneType" notnull_strength="1" unique_strength="0" exp_strength="1" constraints="5"/>
    <constraint field="Note" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="Guid"/>
    <constraint exp="" desc="" field="ZoneIndex"/>
    <constraint exp="length(&quot;TerZoneType&quot;) > 0" desc="Минимальная длина строки - 1 символ" field="TerZoneType"/>
    <constraint exp="" desc="" field="Note"/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="0">
      <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" style="" italic="0" underline="0" bold="0"/>
    </labelStyle>
    <attributeEditorContainer collapsedExpressionEnabled="0" groupBox="0" showLabel="1" collapsedExpression="" visibilityExpressionEnabled="0" name="Обязательные атрибуты" collapsed="0" columnCount="1" visibilityExpression="">
      <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="0">
        <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" style="" italic="0" underline="0" bold="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="Guid">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="2" name="TerZoneType">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer collapsedExpressionEnabled="0" groupBox="0" showLabel="1" collapsedExpression="" visibilityExpressionEnabled="0" name="Необязательные атрибуты" collapsed="0" columnCount="1" visibilityExpression="">
      <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="0">
        <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" style="" italic="0" underline="0" bold="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="1" name="ZoneIndex">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="Note">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="Guid" editable="0"/>
    <field name="Note" editable="1"/>
    <field name="TerZoneType" editable="1"/>
    <field name="ZoneIndex" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="Guid" labelOnTop="1"/>
    <field name="Note" labelOnTop="1"/>
    <field name="TerZoneType" labelOnTop="1"/>
    <field name="ZoneIndex" labelOnTop="1"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="Guid" reuseLastValue="0"/>
    <field name="Note" reuseLastValue="0"/>
    <field name="TerZoneType" reuseLastValue="0"/>
    <field name="ZoneIndex" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <layerGeometryType>2</layerGeometryType>
</qgis>
