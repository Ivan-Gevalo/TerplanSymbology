<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 symbollevels="0" forceraster="0" type="RuleRenderer" enableorderby="0" referencescale="-1">
    <rules key="{60264cbb-3d49-4a2d-b903-7e5cf33c45bc}">
      <rule key="{05a2781f-f137-4cda-8d62-745214f77148}" filter="&quot;Class&quot; = '7A.1'" symbol="0" label="Район"/>
      <rule key="{b409cf1d-2a56-4c69-9ff2-17fd5e8f9f49}" filter="&quot;Class&quot; = '7A.2'" symbol="1" label="Микрорайон"/>
      <rule key="{3070cdba-e9a3-45ba-91fa-cacb3a3cbca5}" filter="&quot;Class&quot; = '7A.3'" symbol="2" label="Квартал"/>
      <rule key="{02dc0c24-16ff-4a0e-8c31-0cff6685473f}" filter="&quot;Class&quot; = '7A.4'" symbol="3" label="Территория общего пользования"/>
      <rule key="{4f28d013-b14e-4acf-96d9-d24d73acc9d3}" filter="&quot;Class&quot; = '7A.5'" symbol="4" label="Территория садоводческого, огороднического или дачного некоммерческого объединения граждан"/>
      <rule key="{6400fd77-8d1e-449a-a052-3b0e0373612b}" filter="&quot;Class&quot; = '7A.6'" symbol="5" label="Территория транспортно-пересадочного узла"/>
      <rule key="{3a4bc9b4-7e80-4171-8000-8a1ecf4a6ab5}" filter="&quot;Class&quot; = '7A.7'" symbol="6" label="Территория, занятая линейным объектом и (или) предназначенная для размещения линейного объекта"/>
      <rule key="{2a356607-1a08-4c6f-a5c1-843f3fe3ae4b}" filter="&quot;Class&quot; = '7A.8'" symbol="7" label="Улично-дорожная сеть"/>
    </rules>
    <symbols>
      <symbol force_rhr="0" alpha="1" type="fill" name="0" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" pass="2" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="flat"/>
            <Option type="QString" name="customdash" value="4;2;1;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="line_color" value="148,0,146,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="1" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" pass="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="flat"/>
            <Option type="QString" name="customdash" value="4;2;1;2;1;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="line_color" value="148,22,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.8"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="2" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="217,204,193,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="163,63,48,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.75"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="3" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="193,217,194,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="163,63,48,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.75"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="4" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="122,216,125,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="163,63,48,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.75"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="5" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="74,102,162,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="163,63,48,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.75"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="6" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="187,191,200,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="163,63,48,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.75"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" alpha="1" type="fill" name="7" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="127,191,255,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="163,63,48,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.75"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="Guid" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Class" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" name="Район" value="7A.1"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Микрорайон" value="7A.2"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Квартал" value="7A.3"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Территория общего пользования" value="7A.4"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Территория садоводческого, огороднического или дачного некоммерческого объединения граждан" value="7A.5"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Территория транспортно-пересадочного узла" value="7A.6"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Территория, занятая линейным объектом и (или) предназначенная для размещения линейного объекта" value="7A.7"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Улично-дорожная сеть" value="7A.8"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Status" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" name="Существующий" value="7B.1"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Планируемый" value="7B.2"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Number" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="false"/>
            <Option type="int" name="Max" value="1000000"/>
            <Option type="int" name="Min" value="0"/>
            <Option type="int" name="Precision" value="0"/>
            <Option type="int" name="Step" value="1"/>
            <Option type="QString" name="Style" value="SpinBox"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Area" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Note" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="Guid" name="Идентификатор объекта"/>
    <alias index="1" field="Class" name="Вид элемента планировочной структуры"/>
    <alias index="2" field="Status" name="Статус объекта"/>
    <alias index="3" field="Number" name="Номер элемента планировочной структуры"/>
    <alias index="4" field="Area" name="Площадь общая, кв. м"/>
    <alias index="5" field="Note" name="Примечание"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="1" field="Guid" expression="uuid('WithoutBraces')"/>
    <default applyOnUpdate="0" field="Class" expression="'7A.1'"/>
    <default applyOnUpdate="0" field="Status" expression="'7B.1'"/>
    <default applyOnUpdate="0" field="Number" expression="0"/>
    <default applyOnUpdate="1" field="Area" expression="round(area($geometry), 2)"/>
    <default applyOnUpdate="0" field="Note" expression="''"/>
  </defaults>
  <constraints>
    <constraint field="Guid" notnull_strength="1" unique_strength="1" exp_strength="0" constraints="3"/>
    <constraint field="Class" notnull_strength="1" unique_strength="0" exp_strength="1" constraints="5"/>
    <constraint field="Status" notnull_strength="1" unique_strength="0" exp_strength="1" constraints="5"/>
    <constraint field="Number" notnull_strength="1" unique_strength="0" exp_strength="1" constraints="5"/>
    <constraint field="Area" notnull_strength="1" unique_strength="0" exp_strength="0" constraints="1"/>
    <constraint field="Note" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="Guid"/>
    <constraint exp="&quot;Class&quot; IN ('7A.1', '7A.2', '7A.3', '7A.4', '7A.5', '7A.6', '7A.7', '7A.8')" desc="Поле &quot;Вид элемента планировочной структуры&quot; должно принимать одно из значений справочника &quot;Виды элементов планировочной структуры&quot;" field="Class"/>
    <constraint exp="&quot;Status&quot; IN ('7B.1', '7B.2')" desc="Поле &quot;Статус объекта&quot; должно принимать одно из значений справочника &quot;Статусы объекта&quot;" field="Status"/>
    <constraint exp="&quot;Number&quot; >= 0" desc="Значение должно быть представлено целым неотрицательным числом" field="Number"/>
    <constraint exp="" desc="" field="Area"/>
    <constraint exp="" desc="" field="Note"/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="0">
      <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" style="" italic="0" underline="0" bold="0"/>
    </labelStyle>
    <attributeEditorContainer collapsedExpressionEnabled="0" groupBox="0" showLabel="1" collapsedExpression="" visibilityExpressionEnabled="0" name="Обязательные атрибуты" collapsed="0" columnCount="1" visibilityExpression="">
      <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="0">
        <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" style="" italic="0" underline="0" bold="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="Guid">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="Class">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="2" name="Status">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="Number">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="Area">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer collapsedExpressionEnabled="0" groupBox="0" showLabel="1" collapsedExpression="" visibilityExpressionEnabled="0" name="Необязательные атрибуты" collapsed="0" columnCount="1" visibilityExpression="">
      <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="0">
        <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" style="" italic="0" underline="0" bold="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="Note">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="Area" editable="0"/>
    <field name="Class" editable="1"/>
    <field name="Guid" editable="0"/>
    <field name="Note" editable="1"/>
    <field name="Number" editable="1"/>
    <field name="Status" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="Area" labelOnTop="1"/>
    <field name="Class" labelOnTop="1"/>
    <field name="Guid" labelOnTop="1"/>
    <field name="Note" labelOnTop="1"/>
    <field name="Number" labelOnTop="1"/>
    <field name="Status" labelOnTop="1"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="Area" reuseLastValue="0"/>
    <field name="Class" reuseLastValue="0"/>
    <field name="Guid" reuseLastValue="0"/>
    <field name="Note" reuseLastValue="0"/>
    <field name="Number" reuseLastValue="0"/>
    <field name="Status" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <layerGeometryType>2</layerGeometryType>
</qgis>
