<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{7da88c3e-bf5f-4385-9903-c5d5547941ba}">
      <rule label="Существующая территория населенного пункта" filter=" &quot;STATUS_ADM&quot; = 1" symbol="0" key="{2f77fd04-7c28-41a0-ba32-070dc06a68d5}"/>
      <rule label="Планируемая территория населенного пункта" filter=" &quot;STATUS_ADM&quot; = 2" symbol="1" key="{f1a37ef3-2fef-4e73-ba56-8692374492fc}"/>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="1" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="231,113,72,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.3" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="114,155,111,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0.26" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SimpleLine">
          <Option type="Map">
            <Option name="align_dash_pattern" value="0" type="QString"/>
            <Option name="capstyle" value="square" type="QString"/>
            <Option name="customdash" value="4;2" type="QString"/>
            <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="customdash_unit" value="MM" type="QString"/>
            <Option name="dash_pattern_offset" value="0" type="QString"/>
            <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
            <Option name="draw_inside_polygon" value="0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="line_color" value="128,128,128,255" type="QString"/>
            <Option name="line_style" value="solid" type="QString"/>
            <Option name="line_width" value="0.3" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="trim_distance_end" value="0" type="QString"/>
            <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_end_unit" value="MM" type="QString"/>
            <Option name="trim_distance_start" value="0" type="QString"/>
            <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_start_unit" value="MM" type="QString"/>
            <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
            <Option name="use_custom_dash" value="1" type="QString"/>
            <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Территория населенного пункта" value="601020400" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SETTL_LVL" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Административный центр субъекта Российской Федерации" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Административный центр муниципального района" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Административный центр городского округа" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Административный центр сельского поселения" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Населенный пункт, не имеющий статуса административного центра" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Административный центр муниципального округа" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SETTL_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Город" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Село" value="10" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Деревня" value="11" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Хутор" value="12" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Станция" value="13" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожная станция" value="14" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Поселок при станции (поселок станции)" value="15" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Поселок при железнодорожной станции" value="16" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожный разъезд" value="17" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожная казарма" value="18" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожная будка" value="19" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Поселок городского типа" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожный остановочный пункт" value="20" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Остановочная платформа" value="21" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожный блокпост" value="22" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Блокпост" value="23" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожная платформа" value="24" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожный путевой пост" value="25" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Дорожный разъезд" value="26" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожная площадка" value="27" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Остановочный пункт" value="28" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожная водокачка" value="29" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Рабочий поселок" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Разъезд" value="30" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожный комбинат" value="31" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Железнодорожный пост" value="32" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Монтерский пункт" value="33" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Станица" value="34" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Слобода" value="35" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местечко" value="36" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Починок" value="37" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Участок" value="38" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Выселок" value="39" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Дачный поселок" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Дома" value="40" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Кордон" value="41" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Казарма" value="42" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Заимка" value="43" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Лесничество" value="44" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Лесоучасток" value="45" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Маяк" value="46" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Остров" value="47" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Мыс" value="48" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Гидрологический пост" value="49" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Курортный поселок" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Метеостанция" value="50" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Аал" value="51" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Аул" value="52" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Улус" value="53" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Арбан" value="54" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Зимовка" value="55" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Дом отдыха" value="56" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Турбаза" value="57" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="База отдыха" value="58" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Санаторий" value="59" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Городской поселок" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Усадьба" value="60" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Центральная усадьба" value="61" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Отдельный дом" value="62" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Площадка" value="63" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Погост" value="64" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Подстанция" value="65" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Карьер" value="66" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Аэропорт" value="67" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Будка" value="68" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Контрольный пункт связи" value="69" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Лесной поселок" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Данных о типе населенного пункта нет" value="70" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Населенный пункт" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Поселок" value="9" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="POPULATION" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1.7976931348623157e+308" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS_ADM" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NAME" index="2" name="Наименование объекта"/>
    <alias field="OKTMO" index="3" name="Код ОКТМО"/>
    <alias field="SETTL_LVL" index="4" name="Административное значение населенного пункта"/>
    <alias field="SETTL_TYPE" index="5" name="Тип населенного пункта"/>
    <alias field="POPULATION" index="6" name="Численность населения, тыс. чел."/>
    <alias field="SOURCE" index="7" name="Источник данных (вносятся реквизиты правового акта об установлении границ)"/>
    <alias field="STATUS_ADM" index="8" name="Статус границы единицы административно-территориального деления Российской Федерации"/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'601020400'" applyOnUpdate="1"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="SETTL_LVL" expression="" applyOnUpdate="0"/>
    <default field="SETTL_TYPE" expression="1" applyOnUpdate="0"/>
    <default field="POPULATION" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS_ADM" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="SETTL_LVL" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="SETTL_TYPE" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="POPULATION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS_ADM" unique_strength="0" notnull_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="SETTL_LVL" desc="" exp=""/>
    <constraint field="SETTL_TYPE" desc="" exp=""/>
    <constraint field="POPULATION" desc="" exp=""/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="STATUS_ADM" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="2" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="5" name="SETTL_TYPE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="4" name="SETTL_LVL">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="6" name="POPULATION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="7" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="8" name="STATUS_ADM">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="CLASSID" editable="0"/>
    <field name="GLOBALID" editable="0"/>
    <field name="NAME" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="POPULATION" editable="1"/>
    <field name="SETTL_LVL" editable="1"/>
    <field name="SETTL_TYPE" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS_ADM" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="POPULATION"/>
    <field labelOnTop="1" name="SETTL_LVL"/>
    <field labelOnTop="1" name="SETTL_TYPE"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS_ADM"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="POPULATION" reuseLastValue="0"/>
    <field name="SETTL_LVL" reuseLastValue="0"/>
    <field name="SETTL_TYPE" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS_ADM" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>2</layerGeometryType>
</qgis>
