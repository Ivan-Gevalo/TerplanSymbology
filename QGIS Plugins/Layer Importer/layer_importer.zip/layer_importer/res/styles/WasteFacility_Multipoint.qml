<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{e905f54f-f83b-4a6c-bd1f-4780c7930250}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{e27c307c-5a84-411a-b920-156ed137a257}">
        <rule label="Объект размещения отходов" filter="&quot;CLASSID&quot; = '602020401'" symbol="1" key="{a09bd2f9-d950-4788-8fdc-3571791dfc56}"/>
        <rule label="Объект по обработке, утилизации, обезвреживанию отходов" filter="&quot;CLASSID&quot; = '602020402'" symbol="2" key="{b032d24f-5ceb-40ee-956f-b976fb00b33a}"/>
        <rule label="Объект утилизации, уничтожения биологических отходов" filter="&quot;CLASSID&quot; = '602020403'" symbol="3" key="{5d45a301-1e43-42a3-aef6-bda211803f82}"/>
        <rule label="Объект обращения с радиоактивными отходами" filter="&quot;CLASSID&quot; = '602020404'" symbol="4" key="{a5906758-0179-484c-90a7-c82c6a3fa811}"/>
        <rule label="Места несанкционированного размещения отходов производства и потребления" filter="&quot;CLASSID&quot; = '602020405'" symbol="5" key="{769d7341-f160-4bdd-9d8c-60f7ee345ebd}"/>
        <rule label="Иные объекты обращения с отходами" filter="&quot;CLASSID&quot; = '602020406'" symbol="6" key="{eca6b623-b44c-49d2-b406-e7fd1607d81c}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="7" key="{30b384bd-e46e-4be8-bb9d-fc125f2c2056}">
        <rule label="Объект размещения отходов" filter="&quot;CLASSID&quot; = '602020401'" symbol="8" key="{ea7be997-177a-442f-8e70-ae4a4da4550d}"/>
        <rule label="Объект по обработке, утилизации, обезвреживанию отходов" filter="&quot;CLASSID&quot; = '602020402'" symbol="9" key="{7f2f5dad-55f8-40c5-8576-f8eabb0bc99f}"/>
        <rule label="Объект утилизации, уничтожения биологических отходов" filter="&quot;CLASSID&quot; = '602020403'" symbol="10" key="{8e7b3795-cf4f-4e3c-a0b3-111a2bea077f}"/>
        <rule label="Объект обращения с радиоактивными отходами" filter="&quot;CLASSID&quot; = '602020404'" symbol="11" key="{ce37aa81-d812-4460-8d2e-d61f1b22eae8}"/>
        <rule label="Иные объекты обращения с отходами" filter="&quot;CLASSID&quot; = '602020406'" symbol="12" key="{ea2e1e36-98ae-49fe-946f-5352f1837182}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="13" key="{45b453cb-d8ed-4e36-977b-27eb83f67a85}">
        <rule label="Объект размещения отходов" filter="&quot;CLASSID&quot; = '602020401'" symbol="14" key="{35ea612d-1ffb-44b1-800c-0b2aa232ee57}"/>
        <rule label="Объект по обработке, утилизации, обезвреживанию отходов" filter="&quot;CLASSID&quot; = '602020402'" symbol="15" key="{dda0ce7d-c597-420b-9857-e59544502b99}"/>
        <rule label="Объект утилизации, уничтожения биологических отходов" filter="&quot;CLASSID&quot; = '602020403'" symbol="16" key="{007aa45f-ebff-49b9-8acb-27196af90979}"/>
        <rule label="Объект обращения с радиоактивными отходами" filter="&quot;CLASSID&quot; = '602020404'" symbol="17" key="{12a36bcc-f0c5-4957-8147-6a147343bc77}"/>
        <rule label="Иные объекты обращения с отходами" filter="&quot;CLASSID&quot; = '602020406'" symbol="18" key="{f9fceb2d-53fa-4456-a1fe-9c880c7c8e5e}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="19" key="{18b4a345-6c37-4725-8380-a93f124ddb94}">
        <rule label="Объект размещения отходов" filter="&quot;CLASSID&quot; = '602020401'" symbol="20" key="{185f8fff-4a57-492d-b8ca-7819983c4489}"/>
        <rule label="Объект по обработке, утилизации, обезвреживанию отходов" filter="&quot;CLASSID&quot; = '602020402'" symbol="21" key="{47f3493e-d085-4417-8a3f-eab2832cd1d0}"/>
        <rule label="Объект утилизации, уничтожения биологических отходов" filter="&quot;CLASSID&quot; = '602020403'" symbol="22" key="{58ba5910-a231-49f7-bf86-b6233e9a1c1f}"/>
        <rule label="Объект обращения с радиоактивными отходами" filter="&quot;CLASSID&quot; = '602020404'" symbol="23" key="{9060a2de-a51c-45e8-baf5-52df02d2e489}"/>
        <rule label="Места несанкционированного размещения отходов производства и потребления" filter="&quot;CLASSID&quot; = '602020405'" symbol="24" key="{61652419-82f3-4a29-be42-2322c7b36e6d}"/>
        <rule label="Иные объекты обращения с отходами" filter="&quot;CLASSID&quot; = '602020406'" symbol="25" key="{68e8da34-d4a6-499e-bc9c-deee7cbf3a33}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="26" key="{28a5a358-fc74-47c6-afb1-484d3335e84c}">
        <rule label="Объект размещения отходов" filter="&quot;CLASSID&quot; = '602020401'" symbol="27" key="{2cd1756b-e4bd-4419-aabc-af17928aac3f}"/>
        <rule label="Объект по обработке, утилизации, обезвреживанию отходов" filter="&quot;CLASSID&quot; = '602020402'" symbol="28" key="{881d801a-59a5-4f97-b322-16223e80ab02}"/>
        <rule label="Объект утилизации, уничтожения биологических отходов" filter="&quot;CLASSID&quot; = '602020403'" symbol="29" key="{01ddd3d8-b3c6-4507-930a-c5931141e69b}"/>
        <rule label="Объект обращения с радиоактивными отходами" filter="&quot;CLASSID&quot; = '602020404'" symbol="30" key="{1f2aaf9c-8e26-4ee1-b658-141820e1ec31}"/>
        <rule label="Места несанкционированного размещения отходов производства и потребления" filter="&quot;CLASSID&quot; = '602020405'" symbol="31" key="{95ea7fe5-5f56-46a7-a42b-1579c2400bde}"/>
        <rule label="Иные объекты обращения с отходами" filter="&quot;CLASSID&quot; = '602020406'" symbol="32" key="{24b47b3e-5e0e-41a3-ae10-1277d3415647}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="33" key="{6ac6b150-9f82-4cda-9579-85d3db740c0a}">
        <rule label="Объект размещения отходов" filter="&quot;CLASSID&quot; = '602020401'" symbol="34" key="{d1853bf5-4228-4cda-b006-7a170588d042}"/>
        <rule label="Объект по обработке, утилизации, обезвреживанию отходов" filter="&quot;CLASSID&quot; = '602020402'" symbol="35" key="{98fe7021-9d44-4190-8de6-ba1093472617}"/>
        <rule label="Объект утилизации, уничтожения биологических отходов" filter="&quot;CLASSID&quot; = '602020403'" symbol="36" key="{00f700c7-7070-4e75-9a57-47a49484d29c}"/>
        <rule label="Объект обращения с радиоактивными отходами" filter="&quot;CLASSID&quot; = '602020404'" symbol="37" key="{3bf0a7de-19f1-45a7-936c-9b81e64ccf3a}"/>
        <rule label="Иные объекты обращения с отходами" filter="&quot;CLASSID&quot; = '602020406'" symbol="38" key="{6e012c2e-43a1-459b-b50e-23f21b4f4461}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="39" key="{afaf0b5c-b4f2-48d3-aae8-b9dd246e0c42}">
        <rule label="Объект размещения отходов" filter="&quot;CLASSID&quot; = '602020401'" symbol="40" key="{d2a13c85-c033-4ab1-a3ab-06f50069253e}"/>
        <rule label="Объект по обработке, утилизации, обезвреживанию отходов" filter="&quot;CLASSID&quot; = '602020402'" symbol="41" key="{66ae26b1-bec6-427e-a090-9931ec56172a}"/>
        <rule label="Объект утилизации, уничтожения биологических отходов" filter="&quot;CLASSID&quot; = '602020403'" symbol="42" key="{1f215f54-d7ea-4d64-bcbc-ef06a3c6d774}"/>
        <rule label="Объект обращения с радиоактивными отходами" filter="&quot;CLASSID&quot; = '602020404'" symbol="43" key="{5b491dd5-e409-478c-93e4-6dbf7139c6a1}"/>
        <rule label="Иные объекты обращения с отходами" filter="&quot;CLASSID&quot; = '602020406'" symbol="44" key="{db9d94ae-dea7-4c22-a475-f547ae54f96d}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты регионального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 2" symbol="45" key="{1e207a85-2689-433e-9464-3e33c633b81d}">
        <rule label="Объект размещения отходов" filter="&quot;CLASSID&quot; = '602020401'" symbol="46" key="{7cae1975-09b0-42b9-9cea-9d8aa2c20e4a}"/>
        <rule label="Объект по обработке, утилизации, обезвреживанию отходов" filter="&quot;CLASSID&quot; = '602020402'" symbol="47" key="{3c8c30cd-8dde-4ec6-99b4-0d9fefde60dd}"/>
        <rule label="Объект утилизации, уничтожения биологических отходов" filter="&quot;CLASSID&quot; = '602020403'" symbol="48" key="{601623d7-51c6-485a-a72b-f9a4e2cfdfbc}"/>
        <rule label="Объект обращения с радиоактивными отходами" filter="&quot;CLASSID&quot; = '602020404'" symbol="49" key="{debd62c8-e691-41a0-bedc-c991d845b0a3}"/>
        <rule label="Места несанкционированного размещения отходов производства и потребления" filter="&quot;CLASSID&quot; = '602020405'" symbol="50" key="{8e2fba46-8674-4738-bfeb-4fa8827625e3}"/>
        <rule label="Иные объекты обращения с отходами" filter="&quot;CLASSID&quot; = '602020406'" symbol="51" key="{cc9d43d2-99b5-412c-a77e-7f7726e0b3e8}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="52" key="{671defc3-6776-4747-b483-8b39d7ebe8b6}">
        <rule label="Объект размещения отходов" filter="&quot;CLASSID&quot; = '602020401'" symbol="53" key="{956c2891-8230-44da-89cf-025e75825f3c}"/>
        <rule label="Объект по обработке, утилизации, обезвреживанию отходов" filter="&quot;CLASSID&quot; = '602020402'" symbol="54" key="{2c471af8-4597-446f-aadd-1b193cd2e87e}"/>
        <rule label="Объект утилизации, уничтожения биологических отходов" filter="&quot;CLASSID&quot; = '602020403'" symbol="55" key="{00d57a5c-f22b-42c1-9a76-54e6cba70fb9}"/>
        <rule label="Объект обращения с радиоактивными отходами" filter="&quot;CLASSID&quot; = '602020404'" symbol="56" key="{382cd8c8-4e52-431a-a7a6-5570825df201}"/>
        <rule label="Места несанкционированного размещения отходов производства и потребления" filter="&quot;CLASSID&quot; = '602020405'" symbol="57" key="{af049e91-0f44-437b-8c29-d79305de94f6}"/>
        <rule label="Иные объекты обращения с отходами" filter="&quot;CLASSID&quot; = '602020406'" symbol="58" key="{cbea6f42-f2f5-45ed-95e6-0da1359deab0}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="59" key="{13a28337-8019-4d26-b9e4-22c510998bf5}">
        <rule label="Объект размещения отходов" filter="&quot;CLASSID&quot; = '602020401'" symbol="60" key="{f7500f5d-67cb-43c2-87f8-0f982f75a512}"/>
        <rule label="Объект по обработке, утилизации, обезвреживанию отходов" filter="&quot;CLASSID&quot; = '602020402'" symbol="61" key="{a0673130-7aa8-4d1d-b5bd-8826e6225896}"/>
        <rule label="Объект утилизации, уничтожения биологических отходов" filter="&quot;CLASSID&quot; = '602020403'" symbol="62" key="{c8078d09-c904-4f57-8c26-60544255c869}"/>
        <rule label="Объект обращения с радиоактивными отходами" filter="&quot;CLASSID&quot; = '602020404'" symbol="63" key="{a3322b8f-9bb2-47f8-b42a-b318a5af4a45}"/>
        <rule label="Иные объекты обращения с отходами" filter="&quot;CLASSID&quot; = '602020406'" symbol="64" key="{ae5c7697-7ed8-49cc-bfdb-40f2d526934f}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="65" key="{1f1e9c77-7130-42fb-805f-f43311c6b6a7}">
        <rule label="Объект размещения отходов" filter="&quot;CLASSID&quot; = '602020401'" symbol="66" key="{2c780964-bdf3-4da7-a4c8-85d71cc9bb7f}"/>
        <rule label="Объект по обработке, утилизации, обезвреживанию отходов" filter="&quot;CLASSID&quot; = '602020402'" symbol="67" key="{2dd77faa-d12e-43ec-a659-da3354732af6}"/>
        <rule label="Объект утилизации, уничтожения биологических отходов" filter="&quot;CLASSID&quot; = '602020403'" symbol="68" key="{923b1ef3-f7cf-442c-9ec0-d9d3591515f0}"/>
        <rule label="Объект обращения с радиоактивными отходами" filter="&quot;CLASSID&quot; = '602020404'" symbol="69" key="{1b818fbd-1574-4785-b7f1-c400ecb66b14}"/>
        <rule label="Иные объекты обращения с отходами" filter="&quot;CLASSID&quot; = '602020406'" symbol="70" key="{ef5654f3-f716-4e07-9d05-12a01efe1932}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты федерального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 1" symbol="71" key="{ec7bd1cb-e388-477e-a4b3-125bc99b9b90}">
        <rule label="Объект размещения отходов" filter="&quot;CLASSID&quot; = '602020401'" symbol="72" key="{b59f82d2-a8ed-4628-bc7a-7913d54cd7d7}"/>
        <rule label="Объект по обработке, утилизации, обезвреживанию отходов" filter="&quot;CLASSID&quot; = '602020402'" symbol="73" key="{620835db-43b2-4744-8c22-bfc53ccc5209}"/>
        <rule label="Объект утилизации, уничтожения биологических отходов" filter="&quot;CLASSID&quot; = '602020403'" symbol="74" key="{9c1112b5-4e40-4ee5-906b-36a48b365aa2}"/>
        <rule label="Объект обращения с радиоактивными отходами" filter="&quot;CLASSID&quot; = '602020404'" symbol="75" key="{931e2ce8-9633-4757-b4f2-e5b75e2b7379}"/>
        <rule label="Места несанкционированного размещения отходов производства и потребления" filter="&quot;CLASSID&quot; = '602020405'" symbol="76" key="{cb9978e6-a2cc-4c63-8707-be9a8864950b}"/>
        <rule label="Иные объекты обращения с отходами" filter="&quot;CLASSID&quot; = '602020406'" symbol="77" key="{dd08311d-8065-419e-86ef-4901c29db5c8}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="133,182,111,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExMS4xOW1tIiBoZWlnaHQ9IjE0NC4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTEuMTkgMTQ0LjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ny43MDMgLTc3LjEyNykiPjxyZWN0IHg9IjUwLjkwNSIgeT0iODUuNTEiIHdpZHRoPSIxMDQuNzkiIGhlaWdodD0iMjEuNDY5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi40MDUiLz48cGF0aCBkPSJtNjEuMDI5IDExMS45NXYxMDQuOThoODQuNTR2LTEwNC43MSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjkuMDIzMSIvPjxnPjxyZWN0IHg9Ijc0LjgyMiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjkyLjA0OCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEwNy43NCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEyNC45NiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9Ijg2LjQzNiIgeT0iNzcuMTI3IiB3aWR0aD0iMzMuNzI2IiBoZWlnaHQ9IjcuOTY4NiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.23585" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4NC4wOW1tIiBoZWlnaHQ9IjE4NC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODQuMDkgMTg0LjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC41NzUgLTU1Ljc4NikiPjxyZWN0IHRyYW5zZm9ybT0icm90YXRlKDQ1KSIgeD0iMTIxLjIyIiB5PSItMjkuNTY3IiB3aWR0aD0iMTE3LjQyIiBoZWlnaHQ9IjExNy40MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEyLjc1OSIvPjxjaXJjbGUgY3g9IjEwNi42MiIgY3k9IjE0My42IiByPSIyMi42MTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjI3NyIvPjxnIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi4zODMxIj48cGF0aCBkPSJtMTI5LjYyIDEzMS4xNGEyNi4yNzYgMjYuMjc2IDAgMCAwLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMCAyNi4yNzYgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMCAwIDAgMTMuNjIyLTMuODI1MSAyMi42NyAyMi42NyAwIDAgMS0xMC42NzIgMi42NzQ4IDIyLjY3IDIyLjY3IDAgMCAxLTIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3IDIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxLTEuMTM5IDcuMDYwNiAyNi4yNzYgMjYuMjc2IDAgMCAwIDEuNzk1Mi05LjUxNjcgMjYuMjc2IDI2LjI3NiAwIDAgMC0yNi4yNzYtMjYuMjc2eiIvPjxwYXRoIGQ9Im04My42MjQgMTMxLjE0YTI2LjI3NiAyNi4yNzYgMCAwIDEgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMS0xMy42MjItMy44MjUxIDIyLjY3IDIyLjY3IDAgMCAwIDEwLjY3MiAyLjY3NDggMjIuNjcgMjIuNjcgMCAwIDAgMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjcgMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAgMS4xMzkgNy4wNjA2IDI2LjI3NiAyNi4yNzYgMCAwIDEtMS43OTUyLTkuNTE2NyAyNi4yNzYgMjYuMjc2IDAgMCAxIDI2LjI3Ni0yNi4yNzZ6Ii8+PHBhdGggZD0ibTEyNi44NSAxMzQuNjFhMjYuMjc2IDI2LjI3NiAwIDAgMS0zNi45OTkgMy40NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTMuNDYtMzYuOTk5IDI2LjI3NiAyNi4yNzYgMCAwIDEgMTEuNjM5LTguMDQ2NCAyMi42NyAyMi42NyAwIDAgMC04Ljg3MDIgNi41MDkyIDIyLjY3IDIyLjY3IDAgMCAwIDIuOTg0OCAzMS45MjEgMjIuNjcgMjIuNjcgMCAwIDAgMzEuOTIyLTIuOTg1MiAyMi42NyAyMi42NyAwIDAgMC0yLjk4NTUtMzEuOTIxIDIyLjY3IDIyLjY3IDAgMCAwLTYuMTYyNi0zLjYyOTIgMjYuMjc2IDI2LjI3NiAwIDAgMSA4LjQ3MjQgNC42OTE0IDI2LjI3NiAyNi4yNzYgMCAwIDEgMy40NiAzNi45OTl6Ii8+PC9nPjxwYXRoIHRyYW5zZm9ybT0ibWF0cml4KC42NDM2NyAuMTcyNDcgLS4xNzI0NyAuNjQzNjcgNjUuMzQ3IDM2LjU4NykiIGQ9Im0xMDIuMDggMTQxLjc3LTIuMDMzLTIuMDMzIDIuNzc3MS0wLjc0NDExeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwMS4wNG1tIiBoZWlnaHQ9IjIwMS4wNG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDEuMDQgMjAxLjA0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjIwNTkgLTQ4LjM0NSkiPjxjaXJjbGUgY3g9IjEwMy43MiIgY3k9IjE0OC44NiIgcj0iMTYuMjIxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40MjIiLz48Y2lyY2xlIGN4PSIxMDMuNzIiIGN5PSIxNDguODYiIHI9IjkzLjA5NiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjE0Ljg0NiIvPjxwYXRoIGQ9Im0xMDMuNzIgNTcuNjY5YTkxLjM2MyA5MS4zNjMgMCAwIDAtNDUuNjA3IDEyLjIwMWwzOC44NDYgNjcuMjgzYTEzLjUyMiAxMy41MjIgMCAwIDEgNi43NjEzLTEuODExOCAxMy41MjIgMTMuNTIyIDAgMCAxIDYuNzYwOCAxLjgxMjhsMzguODQ1LTY3LjI4MWE5MS4zNjMgOTEuMzYzIDAgMCAwLTQ1LjYwNi0xMi4yMDR6bS05MS4zNTYgOTEuMTk1YTkxLjM2MyA5MS4zNjMgMCAwIDAtMC4wMDYyIDAuMTY3NDMgOTEuMzYzIDkxLjM2MyAwIDAgMCA0NS42MSA3OS4wNzdsMzguOTkxLTY3LjUzNGExMy41MjIgMTMuNTIyIDAgMCAxLTYuNzYxMy0xMS43MXptMTA0Ljg4IDBhMTMuNTIyIDEzLjUyMiAwIDAgMS02Ljc2MTQgMTEuNzFsMzguOTkxIDY3LjUzNGE5MS4zNjMgOTEuMzYzIDAgMCAwIDQ1LjYxLTc5LjA3NyA5MS4zNjMgOTEuMzYzIDAgMCAwLTJlLTMgLTAuMTY3NDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTI4MHB0IiBoZWlnaHQ9IjEyODBwdCIgdmVyc2lvbj0iMS4wIiB2aWV3Qm94PSIwIDAgMTI4MCAxMjgwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPG1ldGFkYXRhPkNyZWF0ZWQgYnkgcG90cmFjZSAxLjE1LCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxNzwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDEyODApIHNjYWxlKC4xIC0uMSkiPgogIDxwYXRoIGQ9Im02NDk1IDEyNzg5Yy02OTgtNS0xMzUzLTEyLTE0NTUtMTVsLTE4NS03IDgwLTI3YzQ4NS0xNjcgODkyLTUwNSAxMjUxLTEwNDAgMTYwLTIzOSAxNDAtMjAzIDk2OC0xNzI4IDIxMy0zOTIgMzg1LTcxNiAzODItNzIwLTItNC0xODItMTIyLTQwMC0yNjJsLTM5Ny0yNTUgMjc4LTZjMTUzLTQgNzIxLTkgMTI2My0xMyA1NDItMyAxMDczLTkgMTE4MC0xMmwxOTUtNSA3NTUgMTI0N2M0MTUgNjg2IDc2NiAxMjY1IDc3OSAxMjg2bDIzIDQwLTE2OC04OGMtNjI4LTMyOS03NDktMzkyLTc1MS0zOTAtNSA0LTYwOSAxMTIwLTY0MyAxMTg3LTE5OCAzOTItNTc0IDY4NC0xMDI1IDc5NS05MCAyMy0zOTggMjQtMjEzMCAxM3oiLz4KICA8cGF0aCBkPSJtNDI4NSAxMjY2M2MtMjA1LTI2LTQyOC0xMzItNTkyLTI4MC01MS00Ni0xNTA5LTIyOTEtMTQ5Ni0yMzAzIDQtNSA2MjQtMzczIDEzNzctODE5IDc5Ny00NzIgMTM3My04MDggMTM3OC04MDNzMzM3IDU0NCA3MzkgMTE5OGw3MjkgMTE4OC03NSAxNDJjLTQ5MSA5MzktMTE1OSAxNTcwLTE3NjUgMTY2OS04NyAxNC0yMjIgMTgtMjk1IDh6Ii8+CiAgPHBhdGggZD0ibTEwMTc5IDc4MTRjLTc0NS00NTUtMTM2MC04MzItMTM2OC04MzktMTItMTIgODktMjA0IDY1Mi0xMjQ3bDY2Ni0xMjMzaDMxOGMyNDAgMSAzNTMgNSA0NjMgMTkgNDQ5IDU0IDc4NCAxNDcgMTA5NSAzMDEgMTg2IDkyIDMxNiAxODAgNDM3IDI5NCAyNDcgMjMyIDM3NCA1NDMgMzU1IDg3MS0xMyAyMjAgNCAxNzktNTM3IDEyMzUtNTQgMTA1LTIyMCA0MzMtMzcxIDczMC0xNTAgMjk3LTI5MSA1NzUtMzE0IDYxN2wtNDEgNzgtMTM1NS04MjZ6Ii8+CiAgPHBhdGggZD0ibTE2OTAgODU5OGMtNTc1LTQtMTE3Mi0xMS0xMzI4LTE2bC0yODItNyA0MjAtMzI4YzIzMS0xODEgNDIwLTMzMyA0MjAtMzM4IDAtNi0xOTEtMzc2LTQyNS04MjMtMjMzLTQ0Ny00MzUtODQ2LTQ0OS04ODctNzctMjMxLTUzLTQ3OSA2OS03MjQgNzktMTU2IDE3MS0yODAgMzE1LTQyNSAzNzItMzc1IDc0OC01MjAgMTQ3Ny01NzAgMTY0LTExIDY2Ni0xNiA2ODEtNiA1IDMgMjYzIDQxOSA1NzIgOTI1bDU2MiA5MTkgNzctNDFjNDItMjMgMjMxLTEyNSA0MjEtMjI4czM0Ni0xODYgMzQ4LTE4NC0zMjkgNjE5LTczNSAxMzcybC03MzkgMTM2OC0xNzkgMWMtOTkgMC02NTAtMy0xMjI1LTh6Ii8+CiAgPHBhdGggZD0ibTc0NDcgMzkzMy03MTgtMTI5NSAyNjgtNDkxYzE0OC0yNzEgNDcxLTg2MiA3MTgtMTMxNGw0NTAtODIzIDYgNzhjNCA0MiAxMiAyNTUgMTggNDcyczE0IDQxOSAxNyA0NDhsNiA1MyA3NzEtMmM2ODMtMSA3ODIgMSA4NTUgMTUgNDEwIDgyIDgwMyAzNTAgOTkxIDY3NSAzMSA1NCAxNjM4IDMwNTggMTY5NSAzMTY5IDE1IDI5IDEgMjAtODYtNTUtMzg4LTMzNS03ODctNDk4LTE0MjMtNTc5LTExNC0xNS0yOTAtMTgtMTQ2Mi0yMWwtMTMzMy00djQ4Yy0xIDcwLTQ4IDkxNC01MiA5MTgtMiAyLTMyNi01NzktNzIxLTEyOTJ6Ii8+CiAgPHBhdGggZD0ibTIxMiA0OTgwYzQtOCA0MTYtNzcxIDkxNi0xNjk1IDg3MS0xNjA5IDkxMi0xNjgzIDk3OS0xNzU1IDE5MS0yMDYgNTExLTM2MiA4ODQtNDI5IDI5NS01NCAyODktNTMgMTU3Mi01OGwxMTk3LTR2MTYwOSAxNjA5bC02MjIgN2MtMzQzIDMtMTA5MSA5LTE2NjMgMTItMTg3OSAxMS0xNzk5IDEwLTE5MjUgMjgtNTExIDc2LTkyNyAyNzYtMTI1NSA2MDMtNDkgNDktODYgODEtODMgNzN6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="145,82,45,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExMS4xOW1tIiBoZWlnaHQ9IjE0NC4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTEuMTkgMTQ0LjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ny43MDMgLTc3LjEyNykiPjxyZWN0IHg9IjUwLjkwNSIgeT0iODUuNTEiIHdpZHRoPSIxMDQuNzkiIGhlaWdodD0iMjEuNDY5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi40MDUiLz48cGF0aCBkPSJtNjEuMDI5IDExMS45NXYxMDQuOThoODQuNTR2LTEwNC43MSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjkuMDIzMSIvPjxnPjxyZWN0IHg9Ijc0LjgyMiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjkyLjA0OCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEwNy43NCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEyNC45NiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9Ijg2LjQzNiIgeT0iNzcuMTI3IiB3aWR0aD0iMzMuNzI2IiBoZWlnaHQ9IjcuOTY4NiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.23585" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC4wN21tIiBoZWlnaHQ9IjEzNC40bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC4wNyAxMzQuNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQuMzgxIC03OS4wMjcpIj48Zz48cmVjdCB4PSIyNC4zODEiIHk9IjEzOC40NiIgd2lkdGg9IjE2MC4wNyIgaGVpZ2h0PSI3NC45NjEiLz48cmVjdCB4PSI5NC43OTQiIHk9IjEwMi45MiIgd2lkdGg9IjI1LjA0NiIgaGVpZ2h0PSI1OC40NDUiLz48cmVjdCB4PSIxMzEuNjIiIHk9Ijc5LjAyNyIgd2lkdGg9IjM0LjU0NiIgaGVpZ2h0PSI2NC4zODQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4NC4wOW1tIiBoZWlnaHQ9IjE4NC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODQuMDkgMTg0LjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC41NzUgLTU1Ljc4NikiPjxyZWN0IHRyYW5zZm9ybT0icm90YXRlKDQ1KSIgeD0iMTIxLjIyIiB5PSItMjkuNTY3IiB3aWR0aD0iMTE3LjQyIiBoZWlnaHQ9IjExNy40MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEyLjc1OSIvPjxjaXJjbGUgY3g9IjEwNi42MiIgY3k9IjE0My42IiByPSIyMi42MTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjI3NyIvPjxnIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi4zODMxIj48cGF0aCBkPSJtMTI5LjYyIDEzMS4xNGEyNi4yNzYgMjYuMjc2IDAgMCAwLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMCAyNi4yNzYgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMCAwIDAgMTMuNjIyLTMuODI1MSAyMi42NyAyMi42NyAwIDAgMS0xMC42NzIgMi42NzQ4IDIyLjY3IDIyLjY3IDAgMCAxLTIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3IDIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxLTEuMTM5IDcuMDYwNiAyNi4yNzYgMjYuMjc2IDAgMCAwIDEuNzk1Mi05LjUxNjcgMjYuMjc2IDI2LjI3NiAwIDAgMC0yNi4yNzYtMjYuMjc2eiIvPjxwYXRoIGQ9Im04My42MjQgMTMxLjE0YTI2LjI3NiAyNi4yNzYgMCAwIDEgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMS0xMy42MjItMy44MjUxIDIyLjY3IDIyLjY3IDAgMCAwIDEwLjY3MiAyLjY3NDggMjIuNjcgMjIuNjcgMCAwIDAgMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjcgMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAgMS4xMzkgNy4wNjA2IDI2LjI3NiAyNi4yNzYgMCAwIDEtMS43OTUyLTkuNTE2NyAyNi4yNzYgMjYuMjc2IDAgMCAxIDI2LjI3Ni0yNi4yNzZ6Ii8+PHBhdGggZD0ibTEyNi44NSAxMzQuNjFhMjYuMjc2IDI2LjI3NiAwIDAgMS0zNi45OTkgMy40NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTMuNDYtMzYuOTk5IDI2LjI3NiAyNi4yNzYgMCAwIDEgMTEuNjM5LTguMDQ2NCAyMi42NyAyMi42NyAwIDAgMC04Ljg3MDIgNi41MDkyIDIyLjY3IDIyLjY3IDAgMCAwIDIuOTg0OCAzMS45MjEgMjIuNjcgMjIuNjcgMCAwIDAgMzEuOTIyLTIuOTg1MiAyMi42NyAyMi42NyAwIDAgMC0yLjk4NTUtMzEuOTIxIDIyLjY3IDIyLjY3IDAgMCAwLTYuMTYyNi0zLjYyOTIgMjYuMjc2IDI2LjI3NiAwIDAgMSA4LjQ3MjQgNC42OTE0IDI2LjI3NiAyNi4yNzYgMCAwIDEgMy40NiAzNi45OTl6Ii8+PC9nPjxwYXRoIHRyYW5zZm9ybT0ibWF0cml4KC42NDM2NyAuMTcyNDcgLS4xNzI0NyAuNjQzNjcgNjUuMzQ3IDM2LjU4NykiIGQ9Im0xMDIuMDggMTQxLjc3LTIuMDMzLTIuMDMzIDIuNzc3MS0wLjc0NDExeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwMS4wNG1tIiBoZWlnaHQ9IjIwMS4wNG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDEuMDQgMjAxLjA0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjIwNTkgLTQ4LjM0NSkiPjxjaXJjbGUgY3g9IjEwMy43MiIgY3k9IjE0OC44NiIgcj0iMTYuMjIxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40MjIiLz48Y2lyY2xlIGN4PSIxMDMuNzIiIGN5PSIxNDguODYiIHI9IjkzLjA5NiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjE0Ljg0NiIvPjxwYXRoIGQ9Im0xMDMuNzIgNTcuNjY5YTkxLjM2MyA5MS4zNjMgMCAwIDAtNDUuNjA3IDEyLjIwMWwzOC44NDYgNjcuMjgzYTEzLjUyMiAxMy41MjIgMCAwIDEgNi43NjEzLTEuODExOCAxMy41MjIgMTMuNTIyIDAgMCAxIDYuNzYwOCAxLjgxMjhsMzguODQ1LTY3LjI4MWE5MS4zNjMgOTEuMzYzIDAgMCAwLTQ1LjYwNi0xMi4yMDR6bS05MS4zNTYgOTEuMTk1YTkxLjM2MyA5MS4zNjMgMCAwIDAtMC4wMDYyIDAuMTY3NDMgOTEuMzYzIDkxLjM2MyAwIDAgMCA0NS42MSA3OS4wNzdsMzguOTkxLTY3LjUzNGExMy41MjIgMTMuNTIyIDAgMCAxLTYuNzYxMy0xMS43MXptMTA0Ljg4IDBhMTMuNTIyIDEzLjUyMiAwIDAgMS02Ljc2MTQgMTEuNzFsMzguOTkxIDY3LjUzNGE5MS4zNjMgOTEuMzYzIDAgMCAwIDQ1LjYxLTc5LjA3NyA5MS4zNjMgOTEuMzYzIDAgMCAwLTJlLTMgLTAuMTY3NDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTI4MHB0IiBoZWlnaHQ9IjEyODBwdCIgdmVyc2lvbj0iMS4wIiB2aWV3Qm94PSIwIDAgMTI4MCAxMjgwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPG1ldGFkYXRhPkNyZWF0ZWQgYnkgcG90cmFjZSAxLjE1LCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxNzwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDEyODApIHNjYWxlKC4xIC0uMSkiPgogIDxwYXRoIGQ9Im02NDk1IDEyNzg5Yy02OTgtNS0xMzUzLTEyLTE0NTUtMTVsLTE4NS03IDgwLTI3YzQ4NS0xNjcgODkyLTUwNSAxMjUxLTEwNDAgMTYwLTIzOSAxNDAtMjAzIDk2OC0xNzI4IDIxMy0zOTIgMzg1LTcxNiAzODItNzIwLTItNC0xODItMTIyLTQwMC0yNjJsLTM5Ny0yNTUgMjc4LTZjMTUzLTQgNzIxLTkgMTI2My0xMyA1NDItMyAxMDczLTkgMTE4MC0xMmwxOTUtNSA3NTUgMTI0N2M0MTUgNjg2IDc2NiAxMjY1IDc3OSAxMjg2bDIzIDQwLTE2OC04OGMtNjI4LTMyOS03NDktMzkyLTc1MS0zOTAtNSA0LTYwOSAxMTIwLTY0MyAxMTg3LTE5OCAzOTItNTc0IDY4NC0xMDI1IDc5NS05MCAyMy0zOTggMjQtMjEzMCAxM3oiLz4KICA8cGF0aCBkPSJtNDI4NSAxMjY2M2MtMjA1LTI2LTQyOC0xMzItNTkyLTI4MC01MS00Ni0xNTA5LTIyOTEtMTQ5Ni0yMzAzIDQtNSA2MjQtMzczIDEzNzctODE5IDc5Ny00NzIgMTM3My04MDggMTM3OC04MDNzMzM3IDU0NCA3MzkgMTE5OGw3MjkgMTE4OC03NSAxNDJjLTQ5MSA5MzktMTE1OSAxNTcwLTE3NjUgMTY2OS04NyAxNC0yMjIgMTgtMjk1IDh6Ii8+CiAgPHBhdGggZD0ibTEwMTc5IDc4MTRjLTc0NS00NTUtMTM2MC04MzItMTM2OC04MzktMTItMTIgODktMjA0IDY1Mi0xMjQ3bDY2Ni0xMjMzaDMxOGMyNDAgMSAzNTMgNSA0NjMgMTkgNDQ5IDU0IDc4NCAxNDcgMTA5NSAzMDEgMTg2IDkyIDMxNiAxODAgNDM3IDI5NCAyNDcgMjMyIDM3NCA1NDMgMzU1IDg3MS0xMyAyMjAgNCAxNzktNTM3IDEyMzUtNTQgMTA1LTIyMCA0MzMtMzcxIDczMC0xNTAgMjk3LTI5MSA1NzUtMzE0IDYxN2wtNDEgNzgtMTM1NS04MjZ6Ii8+CiAgPHBhdGggZD0ibTE2OTAgODU5OGMtNTc1LTQtMTE3Mi0xMS0xMzI4LTE2bC0yODItNyA0MjAtMzI4YzIzMS0xODEgNDIwLTMzMyA0MjAtMzM4IDAtNi0xOTEtMzc2LTQyNS04MjMtMjMzLTQ0Ny00MzUtODQ2LTQ0OS04ODctNzctMjMxLTUzLTQ3OSA2OS03MjQgNzktMTU2IDE3MS0yODAgMzE1LTQyNSAzNzItMzc1IDc0OC01MjAgMTQ3Ny01NzAgMTY0LTExIDY2Ni0xNiA2ODEtNiA1IDMgMjYzIDQxOSA1NzIgOTI1bDU2MiA5MTkgNzctNDFjNDItMjMgMjMxLTEyNSA0MjEtMjI4czM0Ni0xODYgMzQ4LTE4NC0zMjkgNjE5LTczNSAxMzcybC03MzkgMTM2OC0xNzkgMWMtOTkgMC02NTAtMy0xMjI1LTh6Ii8+CiAgPHBhdGggZD0ibTc0NDcgMzkzMy03MTgtMTI5NSAyNjgtNDkxYzE0OC0yNzEgNDcxLTg2MiA3MTgtMTMxNGw0NTAtODIzIDYgNzhjNCA0MiAxMiAyNTUgMTggNDcyczE0IDQxOSAxNyA0NDhsNiA1MyA3NzEtMmM2ODMtMSA3ODIgMSA4NTUgMTUgNDEwIDgyIDgwMyAzNTAgOTkxIDY3NSAzMSA1NCAxNjM4IDMwNTggMTY5NSAzMTY5IDE1IDI5IDEgMjAtODYtNTUtMzg4LTMzNS03ODctNDk4LTE0MjMtNTc5LTExNC0xNS0yOTAtMTgtMTQ2Mi0yMWwtMTMzMy00djQ4Yy0xIDcwLTQ4IDkxNC01MiA5MTgtMiAyLTMyNi01NzktNzIxLTEyOTJ6Ii8+CiAgPHBhdGggZD0ibTIxMiA0OTgwYzQtOCA0MTYtNzcxIDkxNi0xNjk1IDg3MS0xNjA5IDkxMi0xNjgzIDk3OS0xNzU1IDE5MS0yMDYgNTExLTM2MiA4ODQtNDI5IDI5NS01NCAyODktNTMgMTU3Mi01OGwxMTk3LTR2MTYwOSAxNjA5bC02MjIgN2MtMzQzIDMtMTA5MSA5LTE2NjMgMTItMTg3OSAxMS0xNzk5IDEwLTE5MjUgMjgtNTExIDc2LTkyNyAyNzYtMTI1NSA2MDMtNDkgNDktODYgODEtODMgNzN6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,178,151,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC4wN21tIiBoZWlnaHQ9IjEzNC40bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC4wNyAxMzQuNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQuMzgxIC03OS4wMjcpIj48Zz48cmVjdCB4PSIyNC4zODEiIHk9IjEzOC40NiIgd2lkdGg9IjE2MC4wNyIgaGVpZ2h0PSI3NC45NjEiLz48cmVjdCB4PSI5NC43OTQiIHk9IjEwMi45MiIgd2lkdGg9IjI1LjA0NiIgaGVpZ2h0PSI1OC40NDUiLz48cmVjdCB4PSIxMzEuNjIiIHk9Ijc5LjAyNyIgd2lkdGg9IjM0LjU0NiIgaGVpZ2h0PSI2NC4zODQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExMS4xOW1tIiBoZWlnaHQ9IjE0NC4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTEuMTkgMTQ0LjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ny43MDMgLTc3LjEyNykiPjxyZWN0IHg9IjUwLjkwNSIgeT0iODUuNTEiIHdpZHRoPSIxMDQuNzkiIGhlaWdodD0iMjEuNDY5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi40MDUiLz48cGF0aCBkPSJtNjEuMDI5IDExMS45NXYxMDQuOThoODQuNTR2LTEwNC43MSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjkuMDIzMSIvPjxnPjxyZWN0IHg9Ijc0LjgyMiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjkyLjA0OCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEwNy43NCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEyNC45NiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9Ijg2LjQzNiIgeT0iNzcuMTI3IiB3aWR0aD0iMzMuNzI2IiBoZWlnaHQ9IjcuOTY4NiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.23585" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC4wN21tIiBoZWlnaHQ9IjEzNC40bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC4wNyAxMzQuNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQuMzgxIC03OS4wMjcpIj48Zz48cmVjdCB4PSIyNC4zODEiIHk9IjEzOC40NiIgd2lkdGg9IjE2MC4wNyIgaGVpZ2h0PSI3NC45NjEiLz48cmVjdCB4PSI5NC43OTQiIHk9IjEwMi45MiIgd2lkdGg9IjI1LjA0NiIgaGVpZ2h0PSI1OC40NDUiLz48cmVjdCB4PSIxMzEuNjIiIHk9Ijc5LjAyNyIgd2lkdGg9IjM0LjU0NiIgaGVpZ2h0PSI2NC4zODQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4NC4wOW1tIiBoZWlnaHQ9IjE4NC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODQuMDkgMTg0LjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC41NzUgLTU1Ljc4NikiPjxyZWN0IHRyYW5zZm9ybT0icm90YXRlKDQ1KSIgeD0iMTIxLjIyIiB5PSItMjkuNTY3IiB3aWR0aD0iMTE3LjQyIiBoZWlnaHQ9IjExNy40MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEyLjc1OSIvPjxjaXJjbGUgY3g9IjEwNi42MiIgY3k9IjE0My42IiByPSIyMi42MTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjI3NyIvPjxnIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi4zODMxIj48cGF0aCBkPSJtMTI5LjYyIDEzMS4xNGEyNi4yNzYgMjYuMjc2IDAgMCAwLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMCAyNi4yNzYgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMCAwIDAgMTMuNjIyLTMuODI1MSAyMi42NyAyMi42NyAwIDAgMS0xMC42NzIgMi42NzQ4IDIyLjY3IDIyLjY3IDAgMCAxLTIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3IDIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxLTEuMTM5IDcuMDYwNiAyNi4yNzYgMjYuMjc2IDAgMCAwIDEuNzk1Mi05LjUxNjcgMjYuMjc2IDI2LjI3NiAwIDAgMC0yNi4yNzYtMjYuMjc2eiIvPjxwYXRoIGQ9Im04My42MjQgMTMxLjE0YTI2LjI3NiAyNi4yNzYgMCAwIDEgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMS0xMy42MjItMy44MjUxIDIyLjY3IDIyLjY3IDAgMCAwIDEwLjY3MiAyLjY3NDggMjIuNjcgMjIuNjcgMCAwIDAgMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjcgMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAgMS4xMzkgNy4wNjA2IDI2LjI3NiAyNi4yNzYgMCAwIDEtMS43OTUyLTkuNTE2NyAyNi4yNzYgMjYuMjc2IDAgMCAxIDI2LjI3Ni0yNi4yNzZ6Ii8+PHBhdGggZD0ibTEyNi44NSAxMzQuNjFhMjYuMjc2IDI2LjI3NiAwIDAgMS0zNi45OTkgMy40NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTMuNDYtMzYuOTk5IDI2LjI3NiAyNi4yNzYgMCAwIDEgMTEuNjM5LTguMDQ2NCAyMi42NyAyMi42NyAwIDAgMC04Ljg3MDIgNi41MDkyIDIyLjY3IDIyLjY3IDAgMCAwIDIuOTg0OCAzMS45MjEgMjIuNjcgMjIuNjcgMCAwIDAgMzEuOTIyLTIuOTg1MiAyMi42NyAyMi42NyAwIDAgMC0yLjk4NTUtMzEuOTIxIDIyLjY3IDIyLjY3IDAgMCAwLTYuMTYyNi0zLjYyOTIgMjYuMjc2IDI2LjI3NiAwIDAgMSA4LjQ3MjQgNC42OTE0IDI2LjI3NiAyNi4yNzYgMCAwIDEgMy40NiAzNi45OTl6Ii8+PC9nPjxwYXRoIHRyYW5zZm9ybT0ibWF0cml4KC42NDM2NyAuMTcyNDcgLS4xNzI0NyAuNjQzNjcgNjUuMzQ3IDM2LjU4NykiIGQ9Im0xMDIuMDggMTQxLjc3LTIuMDMzLTIuMDMzIDIuNzc3MS0wLjc0NDExeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwMS4wNG1tIiBoZWlnaHQ9IjIwMS4wNG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDEuMDQgMjAxLjA0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjIwNTkgLTQ4LjM0NSkiPjxjaXJjbGUgY3g9IjEwMy43MiIgY3k9IjE0OC44NiIgcj0iMTYuMjIxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40MjIiLz48Y2lyY2xlIGN4PSIxMDMuNzIiIGN5PSIxNDguODYiIHI9IjkzLjA5NiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjE0Ljg0NiIvPjxwYXRoIGQ9Im0xMDMuNzIgNTcuNjY5YTkxLjM2MyA5MS4zNjMgMCAwIDAtNDUuNjA3IDEyLjIwMWwzOC44NDYgNjcuMjgzYTEzLjUyMiAxMy41MjIgMCAwIDEgNi43NjEzLTEuODExOCAxMy41MjIgMTMuNTIyIDAgMCAxIDYuNzYwOCAxLjgxMjhsMzguODQ1LTY3LjI4MWE5MS4zNjMgOTEuMzYzIDAgMCAwLTQ1LjYwNi0xMi4yMDR6bS05MS4zNTYgOTEuMTk1YTkxLjM2MyA5MS4zNjMgMCAwIDAtMC4wMDYyIDAuMTY3NDMgOTEuMzYzIDkxLjM2MyAwIDAgMCA0NS42MSA3OS4wNzdsMzguOTkxLTY3LjUzNGExMy41MjIgMTMuNTIyIDAgMCAxLTYuNzYxMy0xMS43MXptMTA0Ljg4IDBhMTMuNTIyIDEzLjUyMiAwIDAgMS02Ljc2MTQgMTEuNzFsMzguOTkxIDY3LjUzNGE5MS4zNjMgOTEuMzYzIDAgMCAwIDQ1LjYxLTc5LjA3NyA5MS4zNjMgOTEuMzYzIDAgMCAwLTJlLTMgLTAuMTY3NDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwM21tIiBoZWlnaHQ9IjE0NC40NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDMgMTQ0LjQ0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjEzMDQgLTcwLjE5OCkiPjxwYXRoIGQ9Im0xNi4zODUgMTQzLjExYzkuMzQ0MS0xMC4zOTYgMTguOTIxLTE2LjE2NyAyOC4wMzItMjQuNjM3IDE3LjUzMy0xNi4zIDE0LjIzNy0yNS4zNCAyNS41MzQtMzMuODE4IDcuNjU1My01Ljc0NDkgMTcuMjcyLTEwLjU1MiAyNi44MzctMTAuMjA5IDguOTEyMSAwLjMxOTI3IDE3LjcxIDUuMjI2NSAyNC4yNiAxMS4yNzcgMTIuODc0IDExLjg5MiAxNi4zMDggMzIuMzk3IDI1Ljg3IDQ1Ljc3MiAxMy4zOTYgMTguNzM4IDQ3Ljg2NCAyNC40MjUgNTQuMjA3IDQzLjI4OCA1Ljg0ODQgMTcuMzkyLTIwLjggMjYuMjE1LTM3LjE1MyAzMS4wMzItMjQuODMxIDcuMzE0Ny01MS44NSA0LjE5MjQtNzcuNjM0IDEuOTAzLTE5Ljk1OS0xLjc3MjEtNDIuMjU3LTAuODcxNTktNTguODk1LTEyLjAzOC05LjkyODMtNi42NjM0LTE4LjY2Ny0xNy45MTYtMTkuOTY0LTI5LjgwMy0wLjg4NDE2LTguMTAxMSAzLjQ1NjgtMTYuNzA4IDguOTA0My0yMi43Njh6IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40NTYiLz48cGF0aCBkPSJtMTA3LjQxIDEzMi43OGMtMC40NTUzNy0wLjMwNDcxLTAuMzc5MzUtMC4zOTkwMSAxLjI4ODktMS41OTg5IDAuNTMzOTctMC4zODQwOCAwLjU0MjYxLTAuNDgyIDAuMTQ0MTgtMS42MzQ2LTAuMzQyNjgtMC45OTEzLTAuNjE3MDUtMS4yODk4LTEuNDMzLTEuNTU5My0wLjYwNDY4LTAuMTk5NjctMS4xMTktMC4yMjg1Ni0xLjI4MzItMC4wNzIxLTAuNTMyNTQgMC41MDc3MS0wLjc0Mjg2IDAuMjUyNDItMC4zMjE2Ni0wLjM5MDQyIDAuNDU1MjktMC42OTQ4NiAwLjM3NzUtMC45MTk5Mi0wLjYwNDY1LTEuNzQ5Mi0wLjYxNTQ0LTAuNTE5NjItMC42MzMyNS0wLjUxMjE4LTEuMzY5NyAwLjU3MTU1LTAuNzgwMzUgMS4xNDg0LTEuMDI3NyAwLjc3MTYyLTAuMzEzNi0wLjQ3NzYyIDEuMDU5LTEuODUyNSAwLjA2MDctMy43NTAzLTEuNDUxNi0yLjc1OTQtMS45MzYgMS4yNjg1LTIuOTg0NyAyLjk2NjItMi4xNTA2IDMuNDgxNiAwLjUwNTQ5IDAuMzEyNDEtMC4zODk0NyAwLjkxODU0LTEuODkyNyAxLjI4MTktMi43MyAwLjY1OTg0LTIuODQ2NCAwLjY2MTY3LTMuMjE4OCAwLjA1MDctMC4zMDYyNS0wLjUwMjQyLTAuMjM4MzgtMC42NzE5NSAwLjUyNjc0LTEuMzE1OCAwLjQ4MzA1LTAuNDA2NDcgMS4wNDIxLTAuNzM5MDMgMS4yNDI0LTAuNzM5MDMgMC41MTAyNCAwIDEuMDMzNC0xLjI3MzEgMS4wMzM0LTIuNTE0OHYtMS4wNDU5bDAuNzA0NzUgMC42NjIwOGMwLjU4MDY2IDAuNTQ1NSAwLjg5MDk2IDAuNjI3MTQgMS43NjIzIDAuNDYzNjggMC41ODE2Ni0wLjEwOTEyIDEuMzc1LTAuNTE1ODggMS43NjMxLTAuOTAzOTEgMC42NDU4Mi0wLjY0NTgyIDAuNjY2NTktMC43NDQ0MyAwLjI0NTU1LTEuMTY1NS0wLjQ2NDI2LTAuNDY0MjUtMC41Nzc5Mi0wLjQ1OTktMy4yNjIgMC4xMjQ4MS0wLjg5MjA0IDAuMTk0MzItMS4yMDc3IDAuMTc5MTUtMS4xMzEyLTAuMDU0MyAwLjA1ODM3LTAuMTc4MTQgMC41NTAzLTAuMzY2NDcgMS4wOTMyLTAuNDE4NTEgMS41MDY0LTAuMTQ0NDQgMi4wMDA0LTAuNzMxMTUgMS42NTg0LTEuOTY5OC0wLjMzNTcyLTEuMjE1OS0wLjEzNjgtMS41NjkgMC4zNTM1My0wLjYyNzUyIDAuMTkyOTIgMC4zNzA0MiAwLjM3NzA3IDAuNzA2NTUgMC40MDkyMiAwLjc0Njk2IDAuMjE3NzYgMC4yNzM3NiAzLjI0MTktMC42MTkwMSAzLjY3NjMtMS4wODUzIDAuNjc3NDYtMC43MjcxNiAzLjY4NjEtMC45MzA3OCAzLjkyNDUtMC4yNjU2IDAuMTUzNDYgMC40MjgyIDEuMTE4IDAuMzEwNDQgMS42MjcxLTAuMTk4NjUgMC42MjAwOC0wLjYyMDA4IDAuODY1MzktMC4zMjczMyAwLjM4NzI4IDAuNDYyMTktMC4zNDkzNCAwLjU3Njg2LTAuMjc3MzMgMC43MjA0NSAwLjg4MTM2IDEuNzU3NSAxLjc1NTggMS41NzE0IDIuOTA3MiAxLjg2NTEgNS42OTAzIDEuNDUxMSAxLjg1ODYtMC4yNzY0MyAyLjMxMDEtMC4yNjQ4IDIuNjQzIDAuMDY4IDAuMzQyOTcgMC4zNDI5NyAwLjI2NzIxIDAuNTU0MjUtMC41MjA1MSAxLjQ1MTQtMC44MDc5IDAuOTIwMTUtMC44NzMyOSAxLjExMi0wLjUyODgxIDEuNTUxNCAwLjc2MDQ1IDAuOTcgMS4yNzExIDEuMjA0IDIuNjQ2OCAxLjIxMzEgMS41MDE1IDAuMDEgMi4yMTYyIDAuMjk1NjIgMy4zMzUxIDEuMzMzMWwwLjcxOTczIDAuNjY3MzctMC43ODU2OSAwLjI5ODcyYy0wLjQzMjEzIDAuMTY0MjktMS4zOTc0IDAuMjk1MTEtMi4xNDUgMC4yOTA3MS0wLjc0NzYzLTRlLTMgLTIuMDczMyAwLjA3MjEtMi45NDU5IDAuMTY5OTQtMS40MTQxIDAuMTU4NTgtMS42NTQ1IDAuMTA0OTQtMi4yMTE2LTAuNDkzNDEtMC4zNDM3OC0wLjM2OTIzLTAuNjY3ODgtMS4wNTQyLTAuNzIwMjMtMS41MjIzLTAuMDY2My0wLjU5MzE5LTAuMzY3NzUtMS4wMDk1LTAuOTk1MDMtMS4zNzQ0LTAuNzg3OTQtMC40NTgzOC0xLjAzOS0wLjQ3ODA2LTIuMDE4NC0wLjE1ODI4LTEuMDM4NiAwLjMzOTEtMS4xMjQ5IDAuNDUxNjQtMS4yMDY1IDEuNTc0NS0wLjA1MDYgMC42OTYyOCAwLjEwMjMgMS41NzcgMC4zNjA0MyAyLjA3NjIgMC40OTc5IDAuOTYyODMgMC41OTM1OCAyLjA0OSAwLjE4MDUgMi4wNDktMC4xNDczMSAwLTAuNzUxMTUgMC40NTU4NC0xLjM0MTkgMS4wMTMtMC41OTA3MyAwLjU1NzEzLTEuMTUxIDAuOTM2MDMtMS4yNDUgMC44NDE5OS0wLjA5NC0wLjA5NCAwLjMxNTE4LTAuNjE2NSAwLjkwOTM2LTEuMTYxIDEuMTY0OS0xLjA2NzUgMS4yODk2LTEuNTg5NyAwLjY0NzgxLTIuNzEyNC0wLjIyNjY1LTAuMzk2NDgtMC40MTY2OS0xLjI2MDgtMC40MjIzMS0xLjkyMDctOGUtMyAtMC45OTI0IDAuMTQzMTgtMS4zMjg5IDAuODc2OTYtMS45NDY0IDAuNzIxNTEtMC42MDcxMSAxLjE4NjQtMC43NDY1MSAyLjQ4OTUtMC43NDY1MSAxLjM4NjkgMCAxLjY5MzEtMC4xMDU2IDIuMjc3NC0wLjc4NTU4IDAuNTkyMjktMC42ODkzIDAuNjE5MDctMC44MTY5IDAuMjE4NS0xLjA0MTEtMC4yNTEwOS0wLjE0MDUyLTAuOTUxMDItMC4xNzY0MS0xLjU1NTQtMC4wNzk4LTEuMzA2MiAwLjIwODg3LTMuMjUwNy0wLjUzMTM3LTQuODQyNS0xLjg0MzUtMS43NTQ4LTEuNDQ2NS0yLjE2ODUtMS4xMjMzLTIuODIxOCAyLjIwNDktMC44NTE0NyA0LjMzODEtMC44NTA2OCA0LjM3NyAwLjExMDM3IDUuMzkwMyAwLjQ3NTk3IDAuNTAxODUgMS4wNzUgMS4zMjg1IDEuMzMxMSAxLjgzNzEgMC40NTU0OCAwLjkwNDI2IDAuNDQ4MzIgMC45NDA3NS0wLjMyNTIxIDEuNjU4LTAuNDM1MDIgMC40MDMzNy0wLjkwNDcyIDAuNzMzNC0xLjA0MzggMC43MzM0cy0wLjE4NDk3IDAuMjU5NTItMC4xMDIwMyAwLjU3NjdjMC4xNjM4NCAwLjYyNjUxLTAuMjQ3ODQgMC43NDczNS0wLjk0ODYgMC4yNzg0NnptLTEwLjEyNy01LjM2MTVjMC41MjUxNC0wLjM2NzgyIDAuNTg1ODQtMC41MjI5MSAwLjI4MDQyLTAuNzE2NDUtMC42MTY2Ni0wLjM5MDc4LTEuNjA1My0wLjI5Njc0LTIuMTAyIDAuMTk5OTItMC45NTI5MiAwLjk1MjkyIDAuNTc4NSAxLjM4NzIgMS44MjE1IDAuNTE2NTN6bTI0LjI1Ni0wLjIzNzg3YzAtMC4zNzA3OC0xLjU3MzQtMS4wMTY2LTIuNDg3OC0xLjAyMTItMC40NzM0OS0yZS0zIC0xLjA1MzMgMC43ODc2Ni0wLjgzNjA4IDEuMTM5MiAwLjEwMjMxIDAuMTY1NTQgMC44OTIwMyAwLjMwMDk4IDEuNzU0OSAwLjMwMDk4IDEuMTc5OCAwIDEuNTY4OS0wLjEwMzkxIDEuNTY4OS0wLjQxODk3em0tMTQuNDE3LTQuNzEzNmMwLTAuNTY3MjktMC43OTk3Mi0wLjkyMjcyLTIuMDc2MS0wLjkyMjcyLTEuMDAxOSAwLTEuMzg0MSAwLjExMjgtMS4zODQxIDAuNDA4NDkgMCAwLjIyNDY4IDAuMTYyMiAwLjQ3Mzk1IDAuMzYwNDQgMC41NTM5NCAwLjU5NjA2IDAuMjQwNTEgMy4wOTk4IDAuMjA4NDQgMy4wOTk4LTAuMDM5N3ptMC4yNjE4OS0yLjAyNjdjMC4yMDc0MS0wLjM4NzU1IDAuMTM0ODItMC43Njk1NC0wLjI3Mzk3LTEuNDQxOC0wLjY2ODItMS4wOTg4LTAuODQ2Ni0xLjEyMTItMS42OTkyLTAuMjEzNjUtMC4zNjY4OCAwLjM5MDUyLTEuMTU1MiAwLjc4NDc3LTEuNzgwNCAwLjg5MDM5LTEuNjk1NyAwLjI4NjQ5LTEuNDU0NyAwLjk1MDQ5IDAuMzkxODkgMS4wNzk3IDAuODMyNjEgMC4wNTgyIDEuODY2MSAwLjEyOTkgMi4yOTY2IDAuMTU5MjQgMC41MDI0MSAwLjAzNDIgMC44ODM4OC0wLjEzNTUyIDEuMDY1LTAuNDczOTF6IiBmaWxsPSJub25lIi8+PHBhdGggZD0ibTExMC42MyAyMDcuM2MtMTAuMjQ5LTAuODg1MTUtMzIuNTA1LTIuNjYyNy0zOS44MTYtMy4xODAxLTI3LjgyOS0xLjk2OTQtMzguNzk5LTUuNjkxMy00OS45NTYtMTYuOTQ4LTUuOTYxMi02LjAxNDctOS42Ni0xMi4yOTUtMTAuOTY3LTE4LjYyMS0yLjI3MjMtMTAuOTk1IDQuMjAwMy0yMS4yNTcgMjIuMTUyLTM1LjEyMiAxMS4yMS04LjY1NzQgMTcuMTgtMTUuMzI4IDI1LjQtMjguMzggMy43NTg3LTUuOTY4MiA4LjIxMzEtMTIuMzkyIDkuODk4Ny0xNC4yNzUgOC4xMDU0LTkuMDU0NiAyMy4wNjgtMTUuNTE0IDMyLjA2Ny0xMy44NDMgNi43ODcgMS4yNjA0IDEzLjg4OCA1LjEwNjMgMTkuNjEgMTAuNjIxIDUuNDQ2IDUuMjQ4NSA4LjQzNjIgMTAuNTE2IDE3LjQyMyAzMC42OTUgOC4zOTUyIDE4Ljg1IDEzLjI2NSAyMy43NjcgMzYuODM5IDM3LjE5OSAxMy43MDUgNy44MDg2IDE4LjIwOSAxMC44OCAyMi4xMTYgMTUuMDc5IDcuMDA3OSA3LjUzMjIgNi44MTYgMTMuNzIxLTAuNjA5NCAxOS42NjEtOC41NDE0IDYuODMyNC0yOS43MzEgMTQuMzc5LTQ2LjYwMSAxNi41OTgtNi40Mjc2IDAuODQ1MjMtMjkuOTk2IDEuMTY5Mi0zNy41NTcgMC41MTYyMnptNDMuNjc4LTE1LjQxNHYtNi4yNjgyaC0xNi42Mzl2MTIuNTM2aDE2LjYzOXptLTYxLjgwMyAxLjc5MDl2LTMuMjgzNGgtNS45NDI2djYuNTY2N2g1Ljk0MjZ6bTI5LjcxMy01Ljk2OTd2LTYuODY1MmgtMTYuMDQ1djEzLjczaDE2LjA0NXptLTUwLjUxMi0xMC4xNDl2LTE1LjgyaC01Ljk0MjZ2MzEuNjRoNS45NDI2em0tMjEuMzk0IDEuNDkyNHYtMTEuOTM5aC03LjcyNTR2MjMuODc5aDcuNzI1NHptMTMxLjMzLTEuMTk0di00Ljc3NThoLTEwLjEwMnY5LjU1MTZoMTAuMTAyem0tMTUyLjczLTYuODY1MnYtMy44ODAzaC0xNC4yNjJ2Ny43NjA2aDE0LjI2MnptNzUuNDcyLTYuODY1MnYtNC4xNzg4aC0xNy4yMzR2OC4zNTc2aDE3LjIzNHptNTIuODg5LTIuOTg0OXYtNi41NjY3aC0xMC4xMDJ2MTMuMTMzaDEwLjEwMnptLTI5LjExOS0yLjM4Nzl2LTUuOTY5N2gtOC4zMTk3djExLjkzOWg4LjMxOTd6bS03Ni4wNjYtOC42Njg3di0zLjg5MjlsLTIzLjQ3MyAwLjMyMzcyLTAuMTc2OTIgMy43MzExLTAuMTc2OTIgMy43MzExaDIzLjgyN3ptNDQuNTctOC4wNDY1di0yLjk4NDloLTI2Ljc0MnY1Ljk2OTdoMjYuNzQyem0zNi44NDQtNi41NjY3di00LjE3ODhoLTIwLjc5OXY4LjM1NzZoMjAuNzk5em0tODIuNzItNy4wMTQ0IDAuMTc5NjItMy4xMzQxaC00LjIyMnY2LjY0MjNsMS45MzE0LTAuMTg3MDZjMS44ODM0LTAuMTgyNDIgMS45MzU4LTAuMjY0ODUgMi4xMTEtMy4zMjEyem00My4zNzQtNy43NjA2IDAuMTcyNi00LjkyNWgtMTAuMTUxdjQuNjc2M2MwIDIuNTcyIDAuMTg4NTQgNC44NjU3IDAuNDE4OTggNS4wOTcyIDAuMjMwNDQgMC4yMzE0OSAyLjQzNjYgMC4zNDM0MSA0LjkwMjcgMC4yNDg3NGw0LjQ4MzctMC4xNzIxNXptLTIzLjY0Ni03LjAxNDR2LTExLjY0MWgtNC43NTQxdjIzLjI4Mmg0Ljc1NDF6bTUwLjUxMi0wLjg5NTQ1di00Ljc3NThoLTguMzE5N3Y5LjU1MTZoOC4zMTk3em0tMjEuOTg4LTE5Ljd2LTEwLjE0OWgtMTUuNDUxdjIwLjI5N2gxNS40NTF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTI4MHB0IiBoZWlnaHQ9IjEyODBwdCIgdmVyc2lvbj0iMS4wIiB2aWV3Qm94PSIwIDAgMTI4MCAxMjgwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPG1ldGFkYXRhPkNyZWF0ZWQgYnkgcG90cmFjZSAxLjE1LCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxNzwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDEyODApIHNjYWxlKC4xIC0uMSkiPgogIDxwYXRoIGQ9Im02NDk1IDEyNzg5Yy02OTgtNS0xMzUzLTEyLTE0NTUtMTVsLTE4NS03IDgwLTI3YzQ4NS0xNjcgODkyLTUwNSAxMjUxLTEwNDAgMTYwLTIzOSAxNDAtMjAzIDk2OC0xNzI4IDIxMy0zOTIgMzg1LTcxNiAzODItNzIwLTItNC0xODItMTIyLTQwMC0yNjJsLTM5Ny0yNTUgMjc4LTZjMTUzLTQgNzIxLTkgMTI2My0xMyA1NDItMyAxMDczLTkgMTE4MC0xMmwxOTUtNSA3NTUgMTI0N2M0MTUgNjg2IDc2NiAxMjY1IDc3OSAxMjg2bDIzIDQwLTE2OC04OGMtNjI4LTMyOS03NDktMzkyLTc1MS0zOTAtNSA0LTYwOSAxMTIwLTY0MyAxMTg3LTE5OCAzOTItNTc0IDY4NC0xMDI1IDc5NS05MCAyMy0zOTggMjQtMjEzMCAxM3oiLz4KICA8cGF0aCBkPSJtNDI4NSAxMjY2M2MtMjA1LTI2LTQyOC0xMzItNTkyLTI4MC01MS00Ni0xNTA5LTIyOTEtMTQ5Ni0yMzAzIDQtNSA2MjQtMzczIDEzNzctODE5IDc5Ny00NzIgMTM3My04MDggMTM3OC04MDNzMzM3IDU0NCA3MzkgMTE5OGw3MjkgMTE4OC03NSAxNDJjLTQ5MSA5MzktMTE1OSAxNTcwLTE3NjUgMTY2OS04NyAxNC0yMjIgMTgtMjk1IDh6Ii8+CiAgPHBhdGggZD0ibTEwMTc5IDc4MTRjLTc0NS00NTUtMTM2MC04MzItMTM2OC04MzktMTItMTIgODktMjA0IDY1Mi0xMjQ3bDY2Ni0xMjMzaDMxOGMyNDAgMSAzNTMgNSA0NjMgMTkgNDQ5IDU0IDc4NCAxNDcgMTA5NSAzMDEgMTg2IDkyIDMxNiAxODAgNDM3IDI5NCAyNDcgMjMyIDM3NCA1NDMgMzU1IDg3MS0xMyAyMjAgNCAxNzktNTM3IDEyMzUtNTQgMTA1LTIyMCA0MzMtMzcxIDczMC0xNTAgMjk3LTI5MSA1NzUtMzE0IDYxN2wtNDEgNzgtMTM1NS04MjZ6Ii8+CiAgPHBhdGggZD0ibTE2OTAgODU5OGMtNTc1LTQtMTE3Mi0xMS0xMzI4LTE2bC0yODItNyA0MjAtMzI4YzIzMS0xODEgNDIwLTMzMyA0MjAtMzM4IDAtNi0xOTEtMzc2LTQyNS04MjMtMjMzLTQ0Ny00MzUtODQ2LTQ0OS04ODctNzctMjMxLTUzLTQ3OSA2OS03MjQgNzktMTU2IDE3MS0yODAgMzE1LTQyNSAzNzItMzc1IDc0OC01MjAgMTQ3Ny01NzAgMTY0LTExIDY2Ni0xNiA2ODEtNiA1IDMgMjYzIDQxOSA1NzIgOTI1bDU2MiA5MTkgNzctNDFjNDItMjMgMjMxLTEyNSA0MjEtMjI4czM0Ni0xODYgMzQ4LTE4NC0zMjkgNjE5LTczNSAxMzcybC03MzkgMTM2OC0xNzkgMWMtOTkgMC02NTAtMy0xMjI1LTh6Ii8+CiAgPHBhdGggZD0ibTc0NDcgMzkzMy03MTgtMTI5NSAyNjgtNDkxYzE0OC0yNzEgNDcxLTg2MiA3MTgtMTMxNGw0NTAtODIzIDYgNzhjNCA0MiAxMiAyNTUgMTggNDcyczE0IDQxOSAxNyA0NDhsNiA1MyA3NzEtMmM2ODMtMSA3ODIgMSA4NTUgMTUgNDEwIDgyIDgwMyAzNTAgOTkxIDY3NSAzMSA1NCAxNjM4IDMwNTggMTY5NSAzMTY5IDE1IDI5IDEgMjAtODYtNTUtMzg4LTMzNS03ODctNDk4LTE0MjMtNTc5LTExNC0xNS0yOTAtMTgtMTQ2Mi0yMWwtMTMzMy00djQ4Yy0xIDcwLTQ4IDkxNC01MiA5MTgtMiAyLTMyNi01NzktNzIxLTEyOTJ6Ii8+CiAgPHBhdGggZD0ibTIxMiA0OTgwYzQtOCA0MTYtNzcxIDkxNi0xNjk1IDg3MS0xNjA5IDkxMi0xNjgzIDk3OS0xNzU1IDE5MS0yMDYgNTExLTM2MiA4ODQtNDI5IDI5NS01NCAyODktNTMgMTU3Mi01OGwxMTk3LTR2MTYwOSAxNjA5bC02MjIgN2MtMzQzIDMtMTA5MSA5LTE2NjMgMTItMTg3OSAxMS0xNzk5IDEwLTE5MjUgMjgtNTExIDc2LTkyNyAyNzYtMTI1NSA2MDMtNDkgNDktODYgODEtODMgNzN6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="133,182,111,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExMS4xOW1tIiBoZWlnaHQ9IjE0NC4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTEuMTkgMTQ0LjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ny43MDMgLTc3LjEyNykiPjxyZWN0IHg9IjUwLjkwNSIgeT0iODUuNTEiIHdpZHRoPSIxMDQuNzkiIGhlaWdodD0iMjEuNDY5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi40MDUiLz48cGF0aCBkPSJtNjEuMDI5IDExMS45NXYxMDQuOThoODQuNTR2LTEwNC43MSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjkuMDIzMSIvPjxnPjxyZWN0IHg9Ijc0LjgyMiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjkyLjA0OCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEwNy43NCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEyNC45NiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9Ijg2LjQzNiIgeT0iNzcuMTI3IiB3aWR0aD0iMzMuNzI2IiBoZWlnaHQ9IjcuOTY4NiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.23585" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC4wN21tIiBoZWlnaHQ9IjEzNC40bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC4wNyAxMzQuNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQuMzgxIC03OS4wMjcpIj48Zz48cmVjdCB4PSIyNC4zODEiIHk9IjEzOC40NiIgd2lkdGg9IjE2MC4wNyIgaGVpZ2h0PSI3NC45NjEiLz48cmVjdCB4PSI5NC43OTQiIHk9IjEwMi45MiIgd2lkdGg9IjI1LjA0NiIgaGVpZ2h0PSI1OC40NDUiLz48cmVjdCB4PSIxMzEuNjIiIHk9Ijc5LjAyNyIgd2lkdGg9IjM0LjU0NiIgaGVpZ2h0PSI2NC4zODQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4NC4wOW1tIiBoZWlnaHQ9IjE4NC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODQuMDkgMTg0LjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC41NzUgLTU1Ljc4NikiPjxyZWN0IHRyYW5zZm9ybT0icm90YXRlKDQ1KSIgeD0iMTIxLjIyIiB5PSItMjkuNTY3IiB3aWR0aD0iMTE3LjQyIiBoZWlnaHQ9IjExNy40MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEyLjc1OSIvPjxjaXJjbGUgY3g9IjEwNi42MiIgY3k9IjE0My42IiByPSIyMi42MTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjI3NyIvPjxnIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi4zODMxIj48cGF0aCBkPSJtMTI5LjYyIDEzMS4xNGEyNi4yNzYgMjYuMjc2IDAgMCAwLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMCAyNi4yNzYgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMCAwIDAgMTMuNjIyLTMuODI1MSAyMi42NyAyMi42NyAwIDAgMS0xMC42NzIgMi42NzQ4IDIyLjY3IDIyLjY3IDAgMCAxLTIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3IDIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxLTEuMTM5IDcuMDYwNiAyNi4yNzYgMjYuMjc2IDAgMCAwIDEuNzk1Mi05LjUxNjcgMjYuMjc2IDI2LjI3NiAwIDAgMC0yNi4yNzYtMjYuMjc2eiIvPjxwYXRoIGQ9Im04My42MjQgMTMxLjE0YTI2LjI3NiAyNi4yNzYgMCAwIDEgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMS0xMy42MjItMy44MjUxIDIyLjY3IDIyLjY3IDAgMCAwIDEwLjY3MiAyLjY3NDggMjIuNjcgMjIuNjcgMCAwIDAgMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjcgMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAgMS4xMzkgNy4wNjA2IDI2LjI3NiAyNi4yNzYgMCAwIDEtMS43OTUyLTkuNTE2NyAyNi4yNzYgMjYuMjc2IDAgMCAxIDI2LjI3Ni0yNi4yNzZ6Ii8+PHBhdGggZD0ibTEyNi44NSAxMzQuNjFhMjYuMjc2IDI2LjI3NiAwIDAgMS0zNi45OTkgMy40NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTMuNDYtMzYuOTk5IDI2LjI3NiAyNi4yNzYgMCAwIDEgMTEuNjM5LTguMDQ2NCAyMi42NyAyMi42NyAwIDAgMC04Ljg3MDIgNi41MDkyIDIyLjY3IDIyLjY3IDAgMCAwIDIuOTg0OCAzMS45MjEgMjIuNjcgMjIuNjcgMCAwIDAgMzEuOTIyLTIuOTg1MiAyMi42NyAyMi42NyAwIDAgMC0yLjk4NTUtMzEuOTIxIDIyLjY3IDIyLjY3IDAgMCAwLTYuMTYyNi0zLjYyOTIgMjYuMjc2IDI2LjI3NiAwIDAgMSA4LjQ3MjQgNC42OTE0IDI2LjI3NiAyNi4yNzYgMCAwIDEgMy40NiAzNi45OTl6Ii8+PC9nPjxwYXRoIHRyYW5zZm9ybT0ibWF0cml4KC42NDM2NyAuMTcyNDcgLS4xNzI0NyAuNjQzNjcgNjUuMzQ3IDM2LjU4NykiIGQ9Im0xMDIuMDggMTQxLjc3LTIuMDMzLTIuMDMzIDIuNzc3MS0wLjc0NDExeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4NC4wOW1tIiBoZWlnaHQ9IjE4NC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODQuMDkgMTg0LjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC41NzUgLTU1Ljc4NikiPjxyZWN0IHRyYW5zZm9ybT0icm90YXRlKDQ1KSIgeD0iMTIxLjIyIiB5PSItMjkuNTY3IiB3aWR0aD0iMTE3LjQyIiBoZWlnaHQ9IjExNy40MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEyLjc1OSIvPjxjaXJjbGUgY3g9IjEwNi42MiIgY3k9IjE0My42IiByPSIyMi42MTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjI3NyIvPjxnIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi4zODMxIj48cGF0aCBkPSJtMTI5LjYyIDEzMS4xNGEyNi4yNzYgMjYuMjc2IDAgMCAwLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMCAyNi4yNzYgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMCAwIDAgMTMuNjIyLTMuODI1MSAyMi42NyAyMi42NyAwIDAgMS0xMC42NzIgMi42NzQ4IDIyLjY3IDIyLjY3IDAgMCAxLTIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3IDIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxLTEuMTM5IDcuMDYwNiAyNi4yNzYgMjYuMjc2IDAgMCAwIDEuNzk1Mi05LjUxNjcgMjYuMjc2IDI2LjI3NiAwIDAgMC0yNi4yNzYtMjYuMjc2eiIvPjxwYXRoIGQ9Im04My42MjQgMTMxLjE0YTI2LjI3NiAyNi4yNzYgMCAwIDEgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMS0xMy42MjItMy44MjUxIDIyLjY3IDIyLjY3IDAgMCAwIDEwLjY3MiAyLjY3NDggMjIuNjcgMjIuNjcgMCAwIDAgMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjcgMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAgMS4xMzkgNy4wNjA2IDI2LjI3NiAyNi4yNzYgMCAwIDEtMS43OTUyLTkuNTE2NyAyNi4yNzYgMjYuMjc2IDAgMCAxIDI2LjI3Ni0yNi4yNzZ6Ii8+PHBhdGggZD0ibTEyNi44NSAxMzQuNjFhMjYuMjc2IDI2LjI3NiAwIDAgMS0zNi45OTkgMy40NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTMuNDYtMzYuOTk5IDI2LjI3NiAyNi4yNzYgMCAwIDEgMTEuNjM5LTguMDQ2NCAyMi42NyAyMi42NyAwIDAgMC04Ljg3MDIgNi41MDkyIDIyLjY3IDIyLjY3IDAgMCAwIDIuOTg0OCAzMS45MjEgMjIuNjcgMjIuNjcgMCAwIDAgMzEuOTIyLTIuOTg1MiAyMi42NyAyMi42NyAwIDAgMC0yLjk4NTUtMzEuOTIxIDIyLjY3IDIyLjY3IDAgMCAwLTYuMTYyNi0zLjYyOTIgMjYuMjc2IDI2LjI3NiAwIDAgMSA4LjQ3MjQgNC42OTE0IDI2LjI3NiAyNi4yNzYgMCAwIDEgMy40NiAzNi45OTl6Ii8+PC9nPjxwYXRoIHRyYW5zZm9ybT0ibWF0cml4KC42NDM2NyAuMTcyNDcgLS4xNzI0NyAuNjQzNjcgNjUuMzQ3IDM2LjU4NykiIGQ9Im0xMDIuMDggMTQxLjc3LTIuMDMzLTIuMDMzIDIuNzc3MS0wLjc0NDExeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwMS4wNG1tIiBoZWlnaHQ9IjIwMS4wNG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDEuMDQgMjAxLjA0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjIwNTkgLTQ4LjM0NSkiPjxjaXJjbGUgY3g9IjEwMy43MiIgY3k9IjE0OC44NiIgcj0iMTYuMjIxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40MjIiLz48Y2lyY2xlIGN4PSIxMDMuNzIiIGN5PSIxNDguODYiIHI9IjkzLjA5NiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjE0Ljg0NiIvPjxwYXRoIGQ9Im0xMDMuNzIgNTcuNjY5YTkxLjM2MyA5MS4zNjMgMCAwIDAtNDUuNjA3IDEyLjIwMWwzOC44NDYgNjcuMjgzYTEzLjUyMiAxMy41MjIgMCAwIDEgNi43NjEzLTEuODExOCAxMy41MjIgMTMuNTIyIDAgMCAxIDYuNzYwOCAxLjgxMjhsMzguODQ1LTY3LjI4MWE5MS4zNjMgOTEuMzYzIDAgMCAwLTQ1LjYwNi0xMi4yMDR6bS05MS4zNTYgOTEuMTk1YTkxLjM2MyA5MS4zNjMgMCAwIDAtMC4wMDYyIDAuMTY3NDMgOTEuMzYzIDkxLjM2MyAwIDAgMCA0NS42MSA3OS4wNzdsMzguOTkxLTY3LjUzNGExMy41MjIgMTMuNTIyIDAgMCAxLTYuNzYxMy0xMS43MXptMTA0Ljg4IDBhMTMuNTIyIDEzLjUyMiAwIDAgMS02Ljc2MTQgMTEuNzFsMzguOTkxIDY3LjUzNGE5MS4zNjMgOTEuMzYzIDAgMCAwIDQ1LjYxLTc5LjA3NyA5MS4zNjMgOTEuMzYzIDAgMCAwLTJlLTMgLTAuMTY3NDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwM21tIiBoZWlnaHQ9IjE0NC40NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDMgMTQ0LjQ0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjEzMDQgLTcwLjE5OCkiPjxwYXRoIGQ9Im0xNi4zODUgMTQzLjExYzkuMzQ0MS0xMC4zOTYgMTguOTIxLTE2LjE2NyAyOC4wMzItMjQuNjM3IDE3LjUzMy0xNi4zIDE0LjIzNy0yNS4zNCAyNS41MzQtMzMuODE4IDcuNjU1My01Ljc0NDkgMTcuMjcyLTEwLjU1MiAyNi44MzctMTAuMjA5IDguOTEyMSAwLjMxOTI3IDE3LjcxIDUuMjI2NSAyNC4yNiAxMS4yNzcgMTIuODc0IDExLjg5MiAxNi4zMDggMzIuMzk3IDI1Ljg3IDQ1Ljc3MiAxMy4zOTYgMTguNzM4IDQ3Ljg2NCAyNC40MjUgNTQuMjA3IDQzLjI4OCA1Ljg0ODQgMTcuMzkyLTIwLjggMjYuMjE1LTM3LjE1MyAzMS4wMzItMjQuODMxIDcuMzE0Ny01MS44NSA0LjE5MjQtNzcuNjM0IDEuOTAzLTE5Ljk1OS0xLjc3MjEtNDIuMjU3LTAuODcxNTktNTguODk1LTEyLjAzOC05LjkyODMtNi42NjM0LTE4LjY2Ny0xNy45MTYtMTkuOTY0LTI5LjgwMy0wLjg4NDE2LTguMTAxMSAzLjQ1NjgtMTYuNzA4IDguOTA0My0yMi43Njh6IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40NTYiLz48cGF0aCBkPSJtMTA3LjQxIDEzMi43OGMtMC40NTUzNy0wLjMwNDcxLTAuMzc5MzUtMC4zOTkwMSAxLjI4ODktMS41OTg5IDAuNTMzOTctMC4zODQwOCAwLjU0MjYxLTAuNDgyIDAuMTQ0MTgtMS42MzQ2LTAuMzQyNjgtMC45OTEzLTAuNjE3MDUtMS4yODk4LTEuNDMzLTEuNTU5My0wLjYwNDY4LTAuMTk5NjctMS4xMTktMC4yMjg1Ni0xLjI4MzItMC4wNzIxLTAuNTMyNTQgMC41MDc3MS0wLjc0Mjg2IDAuMjUyNDItMC4zMjE2Ni0wLjM5MDQyIDAuNDU1MjktMC42OTQ4NiAwLjM3NzUtMC45MTk5Mi0wLjYwNDY1LTEuNzQ5Mi0wLjYxNTQ0LTAuNTE5NjItMC42MzMyNS0wLjUxMjE4LTEuMzY5NyAwLjU3MTU1LTAuNzgwMzUgMS4xNDg0LTEuMDI3NyAwLjc3MTYyLTAuMzEzNi0wLjQ3NzYyIDEuMDU5LTEuODUyNSAwLjA2MDctMy43NTAzLTEuNDUxNi0yLjc1OTQtMS45MzYgMS4yNjg1LTIuOTg0NyAyLjk2NjItMi4xNTA2IDMuNDgxNiAwLjUwNTQ5IDAuMzEyNDEtMC4zODk0NyAwLjkxODU0LTEuODkyNyAxLjI4MTktMi43MyAwLjY1OTg0LTIuODQ2NCAwLjY2MTY3LTMuMjE4OCAwLjA1MDctMC4zMDYyNS0wLjUwMjQyLTAuMjM4MzgtMC42NzE5NSAwLjUyNjc0LTEuMzE1OCAwLjQ4MzA1LTAuNDA2NDcgMS4wNDIxLTAuNzM5MDMgMS4yNDI0LTAuNzM5MDMgMC41MTAyNCAwIDEuMDMzNC0xLjI3MzEgMS4wMzM0LTIuNTE0OHYtMS4wNDU5bDAuNzA0NzUgMC42NjIwOGMwLjU4MDY2IDAuNTQ1NSAwLjg5MDk2IDAuNjI3MTQgMS43NjIzIDAuNDYzNjggMC41ODE2Ni0wLjEwOTEyIDEuMzc1LTAuNTE1ODggMS43NjMxLTAuOTAzOTEgMC42NDU4Mi0wLjY0NTgyIDAuNjY2NTktMC43NDQ0MyAwLjI0NTU1LTEuMTY1NS0wLjQ2NDI2LTAuNDY0MjUtMC41Nzc5Mi0wLjQ1OTktMy4yNjIgMC4xMjQ4MS0wLjg5MjA0IDAuMTk0MzItMS4yMDc3IDAuMTc5MTUtMS4xMzEyLTAuMDU0MyAwLjA1ODM3LTAuMTc4MTQgMC41NTAzLTAuMzY2NDcgMS4wOTMyLTAuNDE4NTEgMS41MDY0LTAuMTQ0NDQgMi4wMDA0LTAuNzMxMTUgMS42NTg0LTEuOTY5OC0wLjMzNTcyLTEuMjE1OS0wLjEzNjgtMS41NjkgMC4zNTM1My0wLjYyNzUyIDAuMTkyOTIgMC4zNzA0MiAwLjM3NzA3IDAuNzA2NTUgMC40MDkyMiAwLjc0Njk2IDAuMjE3NzYgMC4yNzM3NiAzLjI0MTktMC42MTkwMSAzLjY3NjMtMS4wODUzIDAuNjc3NDYtMC43MjcxNiAzLjY4NjEtMC45MzA3OCAzLjkyNDUtMC4yNjU2IDAuMTUzNDYgMC40MjgyIDEuMTE4IDAuMzEwNDQgMS42MjcxLTAuMTk4NjUgMC42MjAwOC0wLjYyMDA4IDAuODY1MzktMC4zMjczMyAwLjM4NzI4IDAuNDYyMTktMC4zNDkzNCAwLjU3Njg2LTAuMjc3MzMgMC43MjA0NSAwLjg4MTM2IDEuNzU3NSAxLjc1NTggMS41NzE0IDIuOTA3MiAxLjg2NTEgNS42OTAzIDEuNDUxMSAxLjg1ODYtMC4yNzY0MyAyLjMxMDEtMC4yNjQ4IDIuNjQzIDAuMDY4IDAuMzQyOTcgMC4zNDI5NyAwLjI2NzIxIDAuNTU0MjUtMC41MjA1MSAxLjQ1MTQtMC44MDc5IDAuOTIwMTUtMC44NzMyOSAxLjExMi0wLjUyODgxIDEuNTUxNCAwLjc2MDQ1IDAuOTcgMS4yNzExIDEuMjA0IDIuNjQ2OCAxLjIxMzEgMS41MDE1IDAuMDEgMi4yMTYyIDAuMjk1NjIgMy4zMzUxIDEuMzMzMWwwLjcxOTczIDAuNjY3MzctMC43ODU2OSAwLjI5ODcyYy0wLjQzMjEzIDAuMTY0MjktMS4zOTc0IDAuMjk1MTEtMi4xNDUgMC4yOTA3MS0wLjc0NzYzLTRlLTMgLTIuMDczMyAwLjA3MjEtMi45NDU5IDAuMTY5OTQtMS40MTQxIDAuMTU4NTgtMS42NTQ1IDAuMTA0OTQtMi4yMTE2LTAuNDkzNDEtMC4zNDM3OC0wLjM2OTIzLTAuNjY3ODgtMS4wNTQyLTAuNzIwMjMtMS41MjIzLTAuMDY2My0wLjU5MzE5LTAuMzY3NzUtMS4wMDk1LTAuOTk1MDMtMS4zNzQ0LTAuNzg3OTQtMC40NTgzOC0xLjAzOS0wLjQ3ODA2LTIuMDE4NC0wLjE1ODI4LTEuMDM4NiAwLjMzOTEtMS4xMjQ5IDAuNDUxNjQtMS4yMDY1IDEuNTc0NS0wLjA1MDYgMC42OTYyOCAwLjEwMjMgMS41NzcgMC4zNjA0MyAyLjA3NjIgMC40OTc5IDAuOTYyODMgMC41OTM1OCAyLjA0OSAwLjE4MDUgMi4wNDktMC4xNDczMSAwLTAuNzUxMTUgMC40NTU4NC0xLjM0MTkgMS4wMTMtMC41OTA3MyAwLjU1NzEzLTEuMTUxIDAuOTM2MDMtMS4yNDUgMC44NDE5OS0wLjA5NC0wLjA5NCAwLjMxNTE4LTAuNjE2NSAwLjkwOTM2LTEuMTYxIDEuMTY0OS0xLjA2NzUgMS4yODk2LTEuNTg5NyAwLjY0NzgxLTIuNzEyNC0wLjIyNjY1LTAuMzk2NDgtMC40MTY2OS0xLjI2MDgtMC40MjIzMS0xLjkyMDctOGUtMyAtMC45OTI0IDAuMTQzMTgtMS4zMjg5IDAuODc2OTYtMS45NDY0IDAuNzIxNTEtMC42MDcxMSAxLjE4NjQtMC43NDY1MSAyLjQ4OTUtMC43NDY1MSAxLjM4NjkgMCAxLjY5MzEtMC4xMDU2IDIuMjc3NC0wLjc4NTU4IDAuNTkyMjktMC42ODkzIDAuNjE5MDctMC44MTY5IDAuMjE4NS0xLjA0MTEtMC4yNTEwOS0wLjE0MDUyLTAuOTUxMDItMC4xNzY0MS0xLjU1NTQtMC4wNzk4LTEuMzA2MiAwLjIwODg3LTMuMjUwNy0wLjUzMTM3LTQuODQyNS0xLjg0MzUtMS43NTQ4LTEuNDQ2NS0yLjE2ODUtMS4xMjMzLTIuODIxOCAyLjIwNDktMC44NTE0NyA0LjMzODEtMC44NTA2OCA0LjM3NyAwLjExMDM3IDUuMzkwMyAwLjQ3NTk3IDAuNTAxODUgMS4wNzUgMS4zMjg1IDEuMzMxMSAxLjgzNzEgMC40NTU0OCAwLjkwNDI2IDAuNDQ4MzIgMC45NDA3NS0wLjMyNTIxIDEuNjU4LTAuNDM1MDIgMC40MDMzNy0wLjkwNDcyIDAuNzMzNC0xLjA0MzggMC43MzM0cy0wLjE4NDk3IDAuMjU5NTItMC4xMDIwMyAwLjU3NjdjMC4xNjM4NCAwLjYyNjUxLTAuMjQ3ODQgMC43NDczNS0wLjk0ODYgMC4yNzg0NnptLTEwLjEyNy01LjM2MTVjMC41MjUxNC0wLjM2NzgyIDAuNTg1ODQtMC41MjI5MSAwLjI4MDQyLTAuNzE2NDUtMC42MTY2Ni0wLjM5MDc4LTEuNjA1My0wLjI5Njc0LTIuMTAyIDAuMTk5OTItMC45NTI5MiAwLjk1MjkyIDAuNTc4NSAxLjM4NzIgMS44MjE1IDAuNTE2NTN6bTI0LjI1Ni0wLjIzNzg3YzAtMC4zNzA3OC0xLjU3MzQtMS4wMTY2LTIuNDg3OC0xLjAyMTItMC40NzM0OS0yZS0zIC0xLjA1MzMgMC43ODc2Ni0wLjgzNjA4IDEuMTM5MiAwLjEwMjMxIDAuMTY1NTQgMC44OTIwMyAwLjMwMDk4IDEuNzU0OSAwLjMwMDk4IDEuMTc5OCAwIDEuNTY4OS0wLjEwMzkxIDEuNTY4OS0wLjQxODk3em0tMTQuNDE3LTQuNzEzNmMwLTAuNTY3MjktMC43OTk3Mi0wLjkyMjcyLTIuMDc2MS0wLjkyMjcyLTEuMDAxOSAwLTEuMzg0MSAwLjExMjgtMS4zODQxIDAuNDA4NDkgMCAwLjIyNDY4IDAuMTYyMiAwLjQ3Mzk1IDAuMzYwNDQgMC41NTM5NCAwLjU5NjA2IDAuMjQwNTEgMy4wOTk4IDAuMjA4NDQgMy4wOTk4LTAuMDM5N3ptMC4yNjE4OS0yLjAyNjdjMC4yMDc0MS0wLjM4NzU1IDAuMTM0ODItMC43Njk1NC0wLjI3Mzk3LTEuNDQxOC0wLjY2ODItMS4wOTg4LTAuODQ2Ni0xLjEyMTItMS42OTkyLTAuMjEzNjUtMC4zNjY4OCAwLjM5MDUyLTEuMTU1MiAwLjc4NDc3LTEuNzgwNCAwLjg5MDM5LTEuNjk1NyAwLjI4NjQ5LTEuNDU0NyAwLjk1MDQ5IDAuMzkxODkgMS4wNzk3IDAuODMyNjEgMC4wNTgyIDEuODY2MSAwLjEyOTkgMi4yOTY2IDAuMTU5MjQgMC41MDI0MSAwLjAzNDIgMC44ODM4OC0wLjEzNTUyIDEuMDY1LTAuNDczOTF6IiBmaWxsPSJub25lIi8+PHBhdGggZD0ibTExMC42MyAyMDcuM2MtMTAuMjQ5LTAuODg1MTUtMzIuNTA1LTIuNjYyNy0zOS44MTYtMy4xODAxLTI3LjgyOS0xLjk2OTQtMzguNzk5LTUuNjkxMy00OS45NTYtMTYuOTQ4LTUuOTYxMi02LjAxNDctOS42Ni0xMi4yOTUtMTAuOTY3LTE4LjYyMS0yLjI3MjMtMTAuOTk1IDQuMjAwMy0yMS4yNTcgMjIuMTUyLTM1LjEyMiAxMS4yMS04LjY1NzQgMTcuMTgtMTUuMzI4IDI1LjQtMjguMzggMy43NTg3LTUuOTY4MiA4LjIxMzEtMTIuMzkyIDkuODk4Ny0xNC4yNzUgOC4xMDU0LTkuMDU0NiAyMy4wNjgtMTUuNTE0IDMyLjA2Ny0xMy44NDMgNi43ODcgMS4yNjA0IDEzLjg4OCA1LjEwNjMgMTkuNjEgMTAuNjIxIDUuNDQ2IDUuMjQ4NSA4LjQzNjIgMTAuNTE2IDE3LjQyMyAzMC42OTUgOC4zOTUyIDE4Ljg1IDEzLjI2NSAyMy43NjcgMzYuODM5IDM3LjE5OSAxMy43MDUgNy44MDg2IDE4LjIwOSAxMC44OCAyMi4xMTYgMTUuMDc5IDcuMDA3OSA3LjUzMjIgNi44MTYgMTMuNzIxLTAuNjA5NCAxOS42NjEtOC41NDE0IDYuODMyNC0yOS43MzEgMTQuMzc5LTQ2LjYwMSAxNi41OTgtNi40Mjc2IDAuODQ1MjMtMjkuOTk2IDEuMTY5Mi0zNy41NTcgMC41MTYyMnptNDMuNjc4LTE1LjQxNHYtNi4yNjgyaC0xNi42Mzl2MTIuNTM2aDE2LjYzOXptLTYxLjgwMyAxLjc5MDl2LTMuMjgzNGgtNS45NDI2djYuNTY2N2g1Ljk0MjZ6bTI5LjcxMy01Ljk2OTd2LTYuODY1MmgtMTYuMDQ1djEzLjczaDE2LjA0NXptLTUwLjUxMi0xMC4xNDl2LTE1LjgyaC01Ljk0MjZ2MzEuNjRoNS45NDI2em0tMjEuMzk0IDEuNDkyNHYtMTEuOTM5aC03LjcyNTR2MjMuODc5aDcuNzI1NHptMTMxLjMzLTEuMTk0di00Ljc3NThoLTEwLjEwMnY5LjU1MTZoMTAuMTAyem0tMTUyLjczLTYuODY1MnYtMy44ODAzaC0xNC4yNjJ2Ny43NjA2aDE0LjI2MnptNzUuNDcyLTYuODY1MnYtNC4xNzg4aC0xNy4yMzR2OC4zNTc2aDE3LjIzNHptNTIuODg5LTIuOTg0OXYtNi41NjY3aC0xMC4xMDJ2MTMuMTMzaDEwLjEwMnptLTI5LjExOS0yLjM4Nzl2LTUuOTY5N2gtOC4zMTk3djExLjkzOWg4LjMxOTd6bS03Ni4wNjYtOC42Njg3di0zLjg5MjlsLTIzLjQ3MyAwLjMyMzcyLTAuMTc2OTIgMy43MzExLTAuMTc2OTIgMy43MzExaDIzLjgyN3ptNDQuNTctOC4wNDY1di0yLjk4NDloLTI2Ljc0MnY1Ljk2OTdoMjYuNzQyem0zNi44NDQtNi41NjY3di00LjE3ODhoLTIwLjc5OXY4LjM1NzZoMjAuNzk5em0tODIuNzItNy4wMTQ0IDAuMTc5NjItMy4xMzQxaC00LjIyMnY2LjY0MjNsMS45MzE0LTAuMTg3MDZjMS44ODM0LTAuMTgyNDIgMS45MzU4LTAuMjY0ODUgMi4xMTEtMy4zMjEyem00My4zNzQtNy43NjA2IDAuMTcyNi00LjkyNWgtMTAuMTUxdjQuNjc2M2MwIDIuNTcyIDAuMTg4NTQgNC44NjU3IDAuNDE4OTggNS4wOTcyIDAuMjMwNDQgMC4yMzE0OSAyLjQzNjYgMC4zNDM0MSA0LjkwMjcgMC4yNDg3NGw0LjQ4MzctMC4xNzIxNXptLTIzLjY0Ni03LjAxNDR2LTExLjY0MWgtNC43NTQxdjIzLjI4Mmg0Ljc1NDF6bTUwLjUxMi0wLjg5NTQ1di00Ljc3NThoLTguMzE5N3Y5LjU1MTZoOC4zMTk3em0tMjEuOTg4LTE5Ljd2LTEwLjE0OWgtMTUuNDUxdjIwLjI5N2gxNS40NTF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTI4MHB0IiBoZWlnaHQ9IjEyODBwdCIgdmVyc2lvbj0iMS4wIiB2aWV3Qm94PSIwIDAgMTI4MCAxMjgwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPG1ldGFkYXRhPkNyZWF0ZWQgYnkgcG90cmFjZSAxLjE1LCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxNzwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDEyODApIHNjYWxlKC4xIC0uMSkiPgogIDxwYXRoIGQ9Im02NDk1IDEyNzg5Yy02OTgtNS0xMzUzLTEyLTE0NTUtMTVsLTE4NS03IDgwLTI3YzQ4NS0xNjcgODkyLTUwNSAxMjUxLTEwNDAgMTYwLTIzOSAxNDAtMjAzIDk2OC0xNzI4IDIxMy0zOTIgMzg1LTcxNiAzODItNzIwLTItNC0xODItMTIyLTQwMC0yNjJsLTM5Ny0yNTUgMjc4LTZjMTUzLTQgNzIxLTkgMTI2My0xMyA1NDItMyAxMDczLTkgMTE4MC0xMmwxOTUtNSA3NTUgMTI0N2M0MTUgNjg2IDc2NiAxMjY1IDc3OSAxMjg2bDIzIDQwLTE2OC04OGMtNjI4LTMyOS03NDktMzkyLTc1MS0zOTAtNSA0LTYwOSAxMTIwLTY0MyAxMTg3LTE5OCAzOTItNTc0IDY4NC0xMDI1IDc5NS05MCAyMy0zOTggMjQtMjEzMCAxM3oiLz4KICA8cGF0aCBkPSJtNDI4NSAxMjY2M2MtMjA1LTI2LTQyOC0xMzItNTkyLTI4MC01MS00Ni0xNTA5LTIyOTEtMTQ5Ni0yMzAzIDQtNSA2MjQtMzczIDEzNzctODE5IDc5Ny00NzIgMTM3My04MDggMTM3OC04MDNzMzM3IDU0NCA3MzkgMTE5OGw3MjkgMTE4OC03NSAxNDJjLTQ5MSA5MzktMTE1OSAxNTcwLTE3NjUgMTY2OS04NyAxNC0yMjIgMTgtMjk1IDh6Ii8+CiAgPHBhdGggZD0ibTEwMTc5IDc4MTRjLTc0NS00NTUtMTM2MC04MzItMTM2OC04MzktMTItMTIgODktMjA0IDY1Mi0xMjQ3bDY2Ni0xMjMzaDMxOGMyNDAgMSAzNTMgNSA0NjMgMTkgNDQ5IDU0IDc4NCAxNDcgMTA5NSAzMDEgMTg2IDkyIDMxNiAxODAgNDM3IDI5NCAyNDcgMjMyIDM3NCA1NDMgMzU1IDg3MS0xMyAyMjAgNCAxNzktNTM3IDEyMzUtNTQgMTA1LTIyMCA0MzMtMzcxIDczMC0xNTAgMjk3LTI5MSA1NzUtMzE0IDYxN2wtNDEgNzgtMTM1NS04MjZ6Ii8+CiAgPHBhdGggZD0ibTE2OTAgODU5OGMtNTc1LTQtMTE3Mi0xMS0xMzI4LTE2bC0yODItNyA0MjAtMzI4YzIzMS0xODEgNDIwLTMzMyA0MjAtMzM4IDAtNi0xOTEtMzc2LTQyNS04MjMtMjMzLTQ0Ny00MzUtODQ2LTQ0OS04ODctNzctMjMxLTUzLTQ3OSA2OS03MjQgNzktMTU2IDE3MS0yODAgMzE1LTQyNSAzNzItMzc1IDc0OC01MjAgMTQ3Ny01NzAgMTY0LTExIDY2Ni0xNiA2ODEtNiA1IDMgMjYzIDQxOSA1NzIgOTI1bDU2MiA5MTkgNzctNDFjNDItMjMgMjMxLTEyNSA0MjEtMjI4czM0Ni0xODYgMzQ4LTE4NC0zMjkgNjE5LTczNSAxMzcybC03MzkgMTM2OC0xNzkgMWMtOTkgMC02NTAtMy0xMjI1LTh6Ii8+CiAgPHBhdGggZD0ibTc0NDcgMzkzMy03MTgtMTI5NSAyNjgtNDkxYzE0OC0yNzEgNDcxLTg2MiA3MTgtMTMxNGw0NTAtODIzIDYgNzhjNCA0MiAxMiAyNTUgMTggNDcyczE0IDQxOSAxNyA0NDhsNiA1MyA3NzEtMmM2ODMtMSA3ODIgMSA4NTUgMTUgNDEwIDgyIDgwMyAzNTAgOTkxIDY3NSAzMSA1NCAxNjM4IDMwNTggMTY5NSAzMTY5IDE1IDI5IDEgMjAtODYtNTUtMzg4LTMzNS03ODctNDk4LTE0MjMtNTc5LTExNC0xNS0yOTAtMTgtMTQ2Mi0yMWwtMTMzMy00djQ4Yy0xIDcwLTQ4IDkxNC01MiA5MTgtMiAyLTMyNi01NzktNzIxLTEyOTJ6Ii8+CiAgPHBhdGggZD0ibTIxMiA0OTgwYzQtOCA0MTYtNzcxIDkxNi0xNjk1IDg3MS0xNjA5IDkxMi0xNjgzIDk3OS0xNzU1IDE5MS0yMDYgNTExLTM2MiA4ODQtNDI5IDI5NS01NCAyODktNTMgMTU3Mi01OGwxMTk3LTR2MTYwOSAxNjA5bC02MjIgN2MtMzQzIDMtMTA5MSA5LTE2NjMgMTItMTg3OSAxMS0xNzk5IDEwLTE5MjUgMjgtNTExIDc2LTkyNyAyNzYtMTI1NSA2MDMtNDkgNDktODYgODEtODMgNzN6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExMS4xOW1tIiBoZWlnaHQ9IjE0NC4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTEuMTkgMTQ0LjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ny43MDMgLTc3LjEyNykiPjxyZWN0IHg9IjUwLjkwNSIgeT0iODUuNTEiIHdpZHRoPSIxMDQuNzkiIGhlaWdodD0iMjEuNDY5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi40MDUiLz48cGF0aCBkPSJtNjEuMDI5IDExMS45NXYxMDQuOThoODQuNTR2LTEwNC43MSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjkuMDIzMSIvPjxnPjxyZWN0IHg9Ijc0LjgyMiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjkyLjA0OCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEwNy43NCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEyNC45NiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9Ijg2LjQzNiIgeT0iNzcuMTI3IiB3aWR0aD0iMzMuNzI2IiBoZWlnaHQ9IjcuOTY4NiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.23585" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC4wN21tIiBoZWlnaHQ9IjEzNC40bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC4wNyAxMzQuNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQuMzgxIC03OS4wMjcpIj48Zz48cmVjdCB4PSIyNC4zODEiIHk9IjEzOC40NiIgd2lkdGg9IjE2MC4wNyIgaGVpZ2h0PSI3NC45NjEiLz48cmVjdCB4PSI5NC43OTQiIHk9IjEwMi45MiIgd2lkdGg9IjI1LjA0NiIgaGVpZ2h0PSI1OC40NDUiLz48cmVjdCB4PSIxMzEuNjIiIHk9Ijc5LjAyNyIgd2lkdGg9IjM0LjU0NiIgaGVpZ2h0PSI2NC4zODQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="36" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4NC4wOW1tIiBoZWlnaHQ9IjE4NC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODQuMDkgMTg0LjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC41NzUgLTU1Ljc4NikiPjxyZWN0IHRyYW5zZm9ybT0icm90YXRlKDQ1KSIgeD0iMTIxLjIyIiB5PSItMjkuNTY3IiB3aWR0aD0iMTE3LjQyIiBoZWlnaHQ9IjExNy40MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEyLjc1OSIvPjxjaXJjbGUgY3g9IjEwNi42MiIgY3k9IjE0My42IiByPSIyMi42MTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjI3NyIvPjxnIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi4zODMxIj48cGF0aCBkPSJtMTI5LjYyIDEzMS4xNGEyNi4yNzYgMjYuMjc2IDAgMCAwLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMCAyNi4yNzYgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMCAwIDAgMTMuNjIyLTMuODI1MSAyMi42NyAyMi42NyAwIDAgMS0xMC42NzIgMi42NzQ4IDIyLjY3IDIyLjY3IDAgMCAxLTIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3IDIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxLTEuMTM5IDcuMDYwNiAyNi4yNzYgMjYuMjc2IDAgMCAwIDEuNzk1Mi05LjUxNjcgMjYuMjc2IDI2LjI3NiAwIDAgMC0yNi4yNzYtMjYuMjc2eiIvPjxwYXRoIGQ9Im04My42MjQgMTMxLjE0YTI2LjI3NiAyNi4yNzYgMCAwIDEgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMS0xMy42MjItMy44MjUxIDIyLjY3IDIyLjY3IDAgMCAwIDEwLjY3MiAyLjY3NDggMjIuNjcgMjIuNjcgMCAwIDAgMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjcgMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAgMS4xMzkgNy4wNjA2IDI2LjI3NiAyNi4yNzYgMCAwIDEtMS43OTUyLTkuNTE2NyAyNi4yNzYgMjYuMjc2IDAgMCAxIDI2LjI3Ni0yNi4yNzZ6Ii8+PHBhdGggZD0ibTEyNi44NSAxMzQuNjFhMjYuMjc2IDI2LjI3NiAwIDAgMS0zNi45OTkgMy40NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTMuNDYtMzYuOTk5IDI2LjI3NiAyNi4yNzYgMCAwIDEgMTEuNjM5LTguMDQ2NCAyMi42NyAyMi42NyAwIDAgMC04Ljg3MDIgNi41MDkyIDIyLjY3IDIyLjY3IDAgMCAwIDIuOTg0OCAzMS45MjEgMjIuNjcgMjIuNjcgMCAwIDAgMzEuOTIyLTIuOTg1MiAyMi42NyAyMi42NyAwIDAgMC0yLjk4NTUtMzEuOTIxIDIyLjY3IDIyLjY3IDAgMCAwLTYuMTYyNi0zLjYyOTIgMjYuMjc2IDI2LjI3NiAwIDAgMSA4LjQ3MjQgNC42OTE0IDI2LjI3NiAyNi4yNzYgMCAwIDEgMy40NiAzNi45OTl6Ii8+PC9nPjxwYXRoIHRyYW5zZm9ybT0ibWF0cml4KC42NDM2NyAuMTcyNDcgLS4xNzI0NyAuNjQzNjcgNjUuMzQ3IDM2LjU4NykiIGQ9Im0xMDIuMDggMTQxLjc3LTIuMDMzLTIuMDMzIDIuNzc3MS0wLjc0NDExeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="37" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwMS4wNG1tIiBoZWlnaHQ9IjIwMS4wNG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDEuMDQgMjAxLjA0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjIwNTkgLTQ4LjM0NSkiPjxjaXJjbGUgY3g9IjEwMy43MiIgY3k9IjE0OC44NiIgcj0iMTYuMjIxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40MjIiLz48Y2lyY2xlIGN4PSIxMDMuNzIiIGN5PSIxNDguODYiIHI9IjkzLjA5NiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjE0Ljg0NiIvPjxwYXRoIGQ9Im0xMDMuNzIgNTcuNjY5YTkxLjM2MyA5MS4zNjMgMCAwIDAtNDUuNjA3IDEyLjIwMWwzOC44NDYgNjcuMjgzYTEzLjUyMiAxMy41MjIgMCAwIDEgNi43NjEzLTEuODExOCAxMy41MjIgMTMuNTIyIDAgMCAxIDYuNzYwOCAxLjgxMjhsMzguODQ1LTY3LjI4MWE5MS4zNjMgOTEuMzYzIDAgMCAwLTQ1LjYwNi0xMi4yMDR6bS05MS4zNTYgOTEuMTk1YTkxLjM2MyA5MS4zNjMgMCAwIDAtMC4wMDYyIDAuMTY3NDMgOTEuMzYzIDkxLjM2MyAwIDAgMCA0NS42MSA3OS4wNzdsMzguOTkxLTY3LjUzNGExMy41MjIgMTMuNTIyIDAgMCAxLTYuNzYxMy0xMS43MXptMTA0Ljg4IDBhMTMuNTIyIDEzLjUyMiAwIDAgMS02Ljc2MTQgMTEuNzFsMzguOTkxIDY3LjUzNGE5MS4zNjMgOTEuMzYzIDAgMCAwIDQ1LjYxLTc5LjA3NyA5MS4zNjMgOTEuMzYzIDAgMCAwLTJlLTMgLTAuMTY3NDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="38" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTI4MHB0IiBoZWlnaHQ9IjEyODBwdCIgdmVyc2lvbj0iMS4wIiB2aWV3Qm94PSIwIDAgMTI4MCAxMjgwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPG1ldGFkYXRhPkNyZWF0ZWQgYnkgcG90cmFjZSAxLjE1LCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxNzwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDEyODApIHNjYWxlKC4xIC0uMSkiPgogIDxwYXRoIGQ9Im02NDk1IDEyNzg5Yy02OTgtNS0xMzUzLTEyLTE0NTUtMTVsLTE4NS03IDgwLTI3YzQ4NS0xNjcgODkyLTUwNSAxMjUxLTEwNDAgMTYwLTIzOSAxNDAtMjAzIDk2OC0xNzI4IDIxMy0zOTIgMzg1LTcxNiAzODItNzIwLTItNC0xODItMTIyLTQwMC0yNjJsLTM5Ny0yNTUgMjc4LTZjMTUzLTQgNzIxLTkgMTI2My0xMyA1NDItMyAxMDczLTkgMTE4MC0xMmwxOTUtNSA3NTUgMTI0N2M0MTUgNjg2IDc2NiAxMjY1IDc3OSAxMjg2bDIzIDQwLTE2OC04OGMtNjI4LTMyOS03NDktMzkyLTc1MS0zOTAtNSA0LTYwOSAxMTIwLTY0MyAxMTg3LTE5OCAzOTItNTc0IDY4NC0xMDI1IDc5NS05MCAyMy0zOTggMjQtMjEzMCAxM3oiLz4KICA8cGF0aCBkPSJtNDI4NSAxMjY2M2MtMjA1LTI2LTQyOC0xMzItNTkyLTI4MC01MS00Ni0xNTA5LTIyOTEtMTQ5Ni0yMzAzIDQtNSA2MjQtMzczIDEzNzctODE5IDc5Ny00NzIgMTM3My04MDggMTM3OC04MDNzMzM3IDU0NCA3MzkgMTE5OGw3MjkgMTE4OC03NSAxNDJjLTQ5MSA5MzktMTE1OSAxNTcwLTE3NjUgMTY2OS04NyAxNC0yMjIgMTgtMjk1IDh6Ii8+CiAgPHBhdGggZD0ibTEwMTc5IDc4MTRjLTc0NS00NTUtMTM2MC04MzItMTM2OC04MzktMTItMTIgODktMjA0IDY1Mi0xMjQ3bDY2Ni0xMjMzaDMxOGMyNDAgMSAzNTMgNSA0NjMgMTkgNDQ5IDU0IDc4NCAxNDcgMTA5NSAzMDEgMTg2IDkyIDMxNiAxODAgNDM3IDI5NCAyNDcgMjMyIDM3NCA1NDMgMzU1IDg3MS0xMyAyMjAgNCAxNzktNTM3IDEyMzUtNTQgMTA1LTIyMCA0MzMtMzcxIDczMC0xNTAgMjk3LTI5MSA1NzUtMzE0IDYxN2wtNDEgNzgtMTM1NS04MjZ6Ii8+CiAgPHBhdGggZD0ibTE2OTAgODU5OGMtNTc1LTQtMTE3Mi0xMS0xMzI4LTE2bC0yODItNyA0MjAtMzI4YzIzMS0xODEgNDIwLTMzMyA0MjAtMzM4IDAtNi0xOTEtMzc2LTQyNS04MjMtMjMzLTQ0Ny00MzUtODQ2LTQ0OS04ODctNzctMjMxLTUzLTQ3OSA2OS03MjQgNzktMTU2IDE3MS0yODAgMzE1LTQyNSAzNzItMzc1IDc0OC01MjAgMTQ3Ny01NzAgMTY0LTExIDY2Ni0xNiA2ODEtNiA1IDMgMjYzIDQxOSA1NzIgOTI1bDU2MiA5MTkgNzctNDFjNDItMjMgMjMxLTEyNSA0MjEtMjI4czM0Ni0xODYgMzQ4LTE4NC0zMjkgNjE5LTczNSAxMzcybC03MzkgMTM2OC0xNzkgMWMtOTkgMC02NTAtMy0xMjI1LTh6Ii8+CiAgPHBhdGggZD0ibTc0NDcgMzkzMy03MTgtMTI5NSAyNjgtNDkxYzE0OC0yNzEgNDcxLTg2MiA3MTgtMTMxNGw0NTAtODIzIDYgNzhjNCA0MiAxMiAyNTUgMTggNDcyczE0IDQxOSAxNyA0NDhsNiA1MyA3NzEtMmM2ODMtMSA3ODIgMSA4NTUgMTUgNDEwIDgyIDgwMyAzNTAgOTkxIDY3NSAzMSA1NCAxNjM4IDMwNTggMTY5NSAzMTY5IDE1IDI5IDEgMjAtODYtNTUtMzg4LTMzNS03ODctNDk4LTE0MjMtNTc5LTExNC0xNS0yOTAtMTgtMTQ2Mi0yMWwtMTMzMy00djQ4Yy0xIDcwLTQ4IDkxNC01MiA5MTgtMiAyLTMyNi01NzktNzIxLTEyOTJ6Ii8+CiAgPHBhdGggZD0ibTIxMiA0OTgwYzQtOCA0MTYtNzcxIDkxNi0xNjk1IDg3MS0xNjA5IDkxMi0xNjgzIDk3OS0xNzU1IDE5MS0yMDYgNTExLTM2MiA4ODQtNDI5IDI5NS01NCAyODktNTMgMTU3Mi01OGwxMTk3LTR2MTYwOSAxNjA5bC02MjIgN2MtMzQzIDMtMTA5MSA5LTE2NjMgMTItMTg3OSAxMS0xNzk5IDEwLTE5MjUgMjgtNTExIDc2LTkyNyAyNzYtMTI1NSA2MDMtNDkgNDktODYgODEtODMgNzN6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="39" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="145,82,45,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwMS4wNG1tIiBoZWlnaHQ9IjIwMS4wNG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDEuMDQgMjAxLjA0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjIwNTkgLTQ4LjM0NSkiPjxjaXJjbGUgY3g9IjEwMy43MiIgY3k9IjE0OC44NiIgcj0iMTYuMjIxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40MjIiLz48Y2lyY2xlIGN4PSIxMDMuNzIiIGN5PSIxNDguODYiIHI9IjkzLjA5NiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjE0Ljg0NiIvPjxwYXRoIGQ9Im0xMDMuNzIgNTcuNjY5YTkxLjM2MyA5MS4zNjMgMCAwIDAtNDUuNjA3IDEyLjIwMWwzOC44NDYgNjcuMjgzYTEzLjUyMiAxMy41MjIgMCAwIDEgNi43NjEzLTEuODExOCAxMy41MjIgMTMuNTIyIDAgMCAxIDYuNzYwOCAxLjgxMjhsMzguODQ1LTY3LjI4MWE5MS4zNjMgOTEuMzYzIDAgMCAwLTQ1LjYwNi0xMi4yMDR6bS05MS4zNTYgOTEuMTk1YTkxLjM2MyA5MS4zNjMgMCAwIDAtMC4wMDYyIDAuMTY3NDMgOTEuMzYzIDkxLjM2MyAwIDAgMCA0NS42MSA3OS4wNzdsMzguOTkxLTY3LjUzNGExMy41MjIgMTMuNTIyIDAgMCAxLTYuNzYxMy0xMS43MXptMTA0Ljg4IDBhMTMuNTIyIDEzLjUyMiAwIDAgMS02Ljc2MTQgMTEuNzFsMzguOTkxIDY3LjUzNGE5MS4zNjMgOTEuMzYzIDAgMCAwIDQ1LjYxLTc5LjA3NyA5MS4zNjMgOTEuMzYzIDAgMCAwLTJlLTMgLTAuMTY3NDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="40" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExMS4xOW1tIiBoZWlnaHQ9IjE0NC4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTEuMTkgMTQ0LjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ny43MDMgLTc3LjEyNykiPjxyZWN0IHg9IjUwLjkwNSIgeT0iODUuNTEiIHdpZHRoPSIxMDQuNzkiIGhlaWdodD0iMjEuNDY5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi40MDUiLz48cGF0aCBkPSJtNjEuMDI5IDExMS45NXYxMDQuOThoODQuNTR2LTEwNC43MSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjkuMDIzMSIvPjxnPjxyZWN0IHg9Ijc0LjgyMiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjkyLjA0OCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEwNy43NCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEyNC45NiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9Ijg2LjQzNiIgeT0iNzcuMTI3IiB3aWR0aD0iMzMuNzI2IiBoZWlnaHQ9IjcuOTY4NiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.23585" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="41" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC4wN21tIiBoZWlnaHQ9IjEzNC40bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC4wNyAxMzQuNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQuMzgxIC03OS4wMjcpIj48Zz48cmVjdCB4PSIyNC4zODEiIHk9IjEzOC40NiIgd2lkdGg9IjE2MC4wNyIgaGVpZ2h0PSI3NC45NjEiLz48cmVjdCB4PSI5NC43OTQiIHk9IjEwMi45MiIgd2lkdGg9IjI1LjA0NiIgaGVpZ2h0PSI1OC40NDUiLz48cmVjdCB4PSIxMzEuNjIiIHk9Ijc5LjAyNyIgd2lkdGg9IjM0LjU0NiIgaGVpZ2h0PSI2NC4zODQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="42" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4NC4wOW1tIiBoZWlnaHQ9IjE4NC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODQuMDkgMTg0LjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC41NzUgLTU1Ljc4NikiPjxyZWN0IHRyYW5zZm9ybT0icm90YXRlKDQ1KSIgeD0iMTIxLjIyIiB5PSItMjkuNTY3IiB3aWR0aD0iMTE3LjQyIiBoZWlnaHQ9IjExNy40MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEyLjc1OSIvPjxjaXJjbGUgY3g9IjEwNi42MiIgY3k9IjE0My42IiByPSIyMi42MTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjI3NyIvPjxnIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi4zODMxIj48cGF0aCBkPSJtMTI5LjYyIDEzMS4xNGEyNi4yNzYgMjYuMjc2IDAgMCAwLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMCAyNi4yNzYgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMCAwIDAgMTMuNjIyLTMuODI1MSAyMi42NyAyMi42NyAwIDAgMS0xMC42NzIgMi42NzQ4IDIyLjY3IDIyLjY3IDAgMCAxLTIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3IDIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxLTEuMTM5IDcuMDYwNiAyNi4yNzYgMjYuMjc2IDAgMCAwIDEuNzk1Mi05LjUxNjcgMjYuMjc2IDI2LjI3NiAwIDAgMC0yNi4yNzYtMjYuMjc2eiIvPjxwYXRoIGQ9Im04My42MjQgMTMxLjE0YTI2LjI3NiAyNi4yNzYgMCAwIDEgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMS0xMy42MjItMy44MjUxIDIyLjY3IDIyLjY3IDAgMCAwIDEwLjY3MiAyLjY3NDggMjIuNjcgMjIuNjcgMCAwIDAgMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjcgMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAgMS4xMzkgNy4wNjA2IDI2LjI3NiAyNi4yNzYgMCAwIDEtMS43OTUyLTkuNTE2NyAyNi4yNzYgMjYuMjc2IDAgMCAxIDI2LjI3Ni0yNi4yNzZ6Ii8+PHBhdGggZD0ibTEyNi44NSAxMzQuNjFhMjYuMjc2IDI2LjI3NiAwIDAgMS0zNi45OTkgMy40NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTMuNDYtMzYuOTk5IDI2LjI3NiAyNi4yNzYgMCAwIDEgMTEuNjM5LTguMDQ2NCAyMi42NyAyMi42NyAwIDAgMC04Ljg3MDIgNi41MDkyIDIyLjY3IDIyLjY3IDAgMCAwIDIuOTg0OCAzMS45MjEgMjIuNjcgMjIuNjcgMCAwIDAgMzEuOTIyLTIuOTg1MiAyMi42NyAyMi42NyAwIDAgMC0yLjk4NTUtMzEuOTIxIDIyLjY3IDIyLjY3IDAgMCAwLTYuMTYyNi0zLjYyOTIgMjYuMjc2IDI2LjI3NiAwIDAgMSA4LjQ3MjQgNC42OTE0IDI2LjI3NiAyNi4yNzYgMCAwIDEgMy40NiAzNi45OTl6Ii8+PC9nPjxwYXRoIHRyYW5zZm9ybT0ibWF0cml4KC42NDM2NyAuMTcyNDcgLS4xNzI0NyAuNjQzNjcgNjUuMzQ3IDM2LjU4NykiIGQ9Im0xMDIuMDggMTQxLjc3LTIuMDMzLTIuMDMzIDIuNzc3MS0wLjc0NDExeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="43" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwMS4wNG1tIiBoZWlnaHQ9IjIwMS4wNG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDEuMDQgMjAxLjA0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjIwNTkgLTQ4LjM0NSkiPjxjaXJjbGUgY3g9IjEwMy43MiIgY3k9IjE0OC44NiIgcj0iMTYuMjIxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40MjIiLz48Y2lyY2xlIGN4PSIxMDMuNzIiIGN5PSIxNDguODYiIHI9IjkzLjA5NiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjE0Ljg0NiIvPjxwYXRoIGQ9Im0xMDMuNzIgNTcuNjY5YTkxLjM2MyA5MS4zNjMgMCAwIDAtNDUuNjA3IDEyLjIwMWwzOC44NDYgNjcuMjgzYTEzLjUyMiAxMy41MjIgMCAwIDEgNi43NjEzLTEuODExOCAxMy41MjIgMTMuNTIyIDAgMCAxIDYuNzYwOCAxLjgxMjhsMzguODQ1LTY3LjI4MWE5MS4zNjMgOTEuMzYzIDAgMCAwLTQ1LjYwNi0xMi4yMDR6bS05MS4zNTYgOTEuMTk1YTkxLjM2MyA5MS4zNjMgMCAwIDAtMC4wMDYyIDAuMTY3NDMgOTEuMzYzIDkxLjM2MyAwIDAgMCA0NS42MSA3OS4wNzdsMzguOTkxLTY3LjUzNGExMy41MjIgMTMuNTIyIDAgMCAxLTYuNzYxMy0xMS43MXptMTA0Ljg4IDBhMTMuNTIyIDEzLjUyMiAwIDAgMS02Ljc2MTQgMTEuNzFsMzguOTkxIDY3LjUzNGE5MS4zNjMgOTEuMzYzIDAgMCAwIDQ1LjYxLTc5LjA3NyA5MS4zNjMgOTEuMzYzIDAgMCAwLTJlLTMgLTAuMTY3NDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="44" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTI4MHB0IiBoZWlnaHQ9IjEyODBwdCIgdmVyc2lvbj0iMS4wIiB2aWV3Qm94PSIwIDAgMTI4MCAxMjgwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPG1ldGFkYXRhPkNyZWF0ZWQgYnkgcG90cmFjZSAxLjE1LCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxNzwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDEyODApIHNjYWxlKC4xIC0uMSkiPgogIDxwYXRoIGQ9Im02NDk1IDEyNzg5Yy02OTgtNS0xMzUzLTEyLTE0NTUtMTVsLTE4NS03IDgwLTI3YzQ4NS0xNjcgODkyLTUwNSAxMjUxLTEwNDAgMTYwLTIzOSAxNDAtMjAzIDk2OC0xNzI4IDIxMy0zOTIgMzg1LTcxNiAzODItNzIwLTItNC0xODItMTIyLTQwMC0yNjJsLTM5Ny0yNTUgMjc4LTZjMTUzLTQgNzIxLTkgMTI2My0xMyA1NDItMyAxMDczLTkgMTE4MC0xMmwxOTUtNSA3NTUgMTI0N2M0MTUgNjg2IDc2NiAxMjY1IDc3OSAxMjg2bDIzIDQwLTE2OC04OGMtNjI4LTMyOS03NDktMzkyLTc1MS0zOTAtNSA0LTYwOSAxMTIwLTY0MyAxMTg3LTE5OCAzOTItNTc0IDY4NC0xMDI1IDc5NS05MCAyMy0zOTggMjQtMjEzMCAxM3oiLz4KICA8cGF0aCBkPSJtNDI4NSAxMjY2M2MtMjA1LTI2LTQyOC0xMzItNTkyLTI4MC01MS00Ni0xNTA5LTIyOTEtMTQ5Ni0yMzAzIDQtNSA2MjQtMzczIDEzNzctODE5IDc5Ny00NzIgMTM3My04MDggMTM3OC04MDNzMzM3IDU0NCA3MzkgMTE5OGw3MjkgMTE4OC03NSAxNDJjLTQ5MSA5MzktMTE1OSAxNTcwLTE3NjUgMTY2OS04NyAxNC0yMjIgMTgtMjk1IDh6Ii8+CiAgPHBhdGggZD0ibTEwMTc5IDc4MTRjLTc0NS00NTUtMTM2MC04MzItMTM2OC04MzktMTItMTIgODktMjA0IDY1Mi0xMjQ3bDY2Ni0xMjMzaDMxOGMyNDAgMSAzNTMgNSA0NjMgMTkgNDQ5IDU0IDc4NCAxNDcgMTA5NSAzMDEgMTg2IDkyIDMxNiAxODAgNDM3IDI5NCAyNDcgMjMyIDM3NCA1NDMgMzU1IDg3MS0xMyAyMjAgNCAxNzktNTM3IDEyMzUtNTQgMTA1LTIyMCA0MzMtMzcxIDczMC0xNTAgMjk3LTI5MSA1NzUtMzE0IDYxN2wtNDEgNzgtMTM1NS04MjZ6Ii8+CiAgPHBhdGggZD0ibTE2OTAgODU5OGMtNTc1LTQtMTE3Mi0xMS0xMzI4LTE2bC0yODItNyA0MjAtMzI4YzIzMS0xODEgNDIwLTMzMyA0MjAtMzM4IDAtNi0xOTEtMzc2LTQyNS04MjMtMjMzLTQ0Ny00MzUtODQ2LTQ0OS04ODctNzctMjMxLTUzLTQ3OSA2OS03MjQgNzktMTU2IDE3MS0yODAgMzE1LTQyNSAzNzItMzc1IDc0OC01MjAgMTQ3Ny01NzAgMTY0LTExIDY2Ni0xNiA2ODEtNiA1IDMgMjYzIDQxOSA1NzIgOTI1bDU2MiA5MTkgNzctNDFjNDItMjMgMjMxLTEyNSA0MjEtMjI4czM0Ni0xODYgMzQ4LTE4NC0zMjkgNjE5LTczNSAxMzcybC03MzkgMTM2OC0xNzkgMWMtOTkgMC02NTAtMy0xMjI1LTh6Ii8+CiAgPHBhdGggZD0ibTc0NDcgMzkzMy03MTgtMTI5NSAyNjgtNDkxYzE0OC0yNzEgNDcxLTg2MiA3MTgtMTMxNGw0NTAtODIzIDYgNzhjNCA0MiAxMiAyNTUgMTggNDcyczE0IDQxOSAxNyA0NDhsNiA1MyA3NzEtMmM2ODMtMSA3ODIgMSA4NTUgMTUgNDEwIDgyIDgwMyAzNTAgOTkxIDY3NSAzMSA1NCAxNjM4IDMwNTggMTY5NSAzMTY5IDE1IDI5IDEgMjAtODYtNTUtMzg4LTMzNS03ODctNDk4LTE0MjMtNTc5LTExNC0xNS0yOTAtMTgtMTQ2Mi0yMWwtMTMzMy00djQ4Yy0xIDcwLTQ4IDkxNC01MiA5MTgtMiAyLTMyNi01NzktNzIxLTEyOTJ6Ii8+CiAgPHBhdGggZD0ibTIxMiA0OTgwYzQtOCA0MTYtNzcxIDkxNi0xNjk1IDg3MS0xNjA5IDkxMi0xNjgzIDk3OS0xNzU1IDE5MS0yMDYgNTExLTM2MiA4ODQtNDI5IDI5NS01NCAyODktNTMgMTU3Mi01OGwxMTk3LTR2MTYwOSAxNjA5bC02MjIgN2MtMzQzIDMtMTA5MSA5LTE2NjMgMTItMTg3OSAxMS0xNzk5IDEwLTE5MjUgMjgtNTExIDc2LTkyNyAyNzYtMTI1NSA2MDMtNDkgNDktODYgODEtODMgNzN6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="45" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,178,151,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="46" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExMS4xOW1tIiBoZWlnaHQ9IjE0NC4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTEuMTkgMTQ0LjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ny43MDMgLTc3LjEyNykiPjxyZWN0IHg9IjUwLjkwNSIgeT0iODUuNTEiIHdpZHRoPSIxMDQuNzkiIGhlaWdodD0iMjEuNDY5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi40MDUiLz48cGF0aCBkPSJtNjEuMDI5IDExMS45NXYxMDQuOThoODQuNTR2LTEwNC43MSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjkuMDIzMSIvPjxnPjxyZWN0IHg9Ijc0LjgyMiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjkyLjA0OCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEwNy43NCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEyNC45NiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9Ijg2LjQzNiIgeT0iNzcuMTI3IiB3aWR0aD0iMzMuNzI2IiBoZWlnaHQ9IjcuOTY4NiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.23585" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="47" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC4wN21tIiBoZWlnaHQ9IjEzNC40bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC4wNyAxMzQuNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQuMzgxIC03OS4wMjcpIj48Zz48cmVjdCB4PSIyNC4zODEiIHk9IjEzOC40NiIgd2lkdGg9IjE2MC4wNyIgaGVpZ2h0PSI3NC45NjEiLz48cmVjdCB4PSI5NC43OTQiIHk9IjEwMi45MiIgd2lkdGg9IjI1LjA0NiIgaGVpZ2h0PSI1OC40NDUiLz48cmVjdCB4PSIxMzEuNjIiIHk9Ijc5LjAyNyIgd2lkdGg9IjM0LjU0NiIgaGVpZ2h0PSI2NC4zODQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="48" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4NC4wOW1tIiBoZWlnaHQ9IjE4NC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODQuMDkgMTg0LjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC41NzUgLTU1Ljc4NikiPjxyZWN0IHRyYW5zZm9ybT0icm90YXRlKDQ1KSIgeD0iMTIxLjIyIiB5PSItMjkuNTY3IiB3aWR0aD0iMTE3LjQyIiBoZWlnaHQ9IjExNy40MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEyLjc1OSIvPjxjaXJjbGUgY3g9IjEwNi42MiIgY3k9IjE0My42IiByPSIyMi42MTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjI3NyIvPjxnIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi4zODMxIj48cGF0aCBkPSJtMTI5LjYyIDEzMS4xNGEyNi4yNzYgMjYuMjc2IDAgMCAwLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMCAyNi4yNzYgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMCAwIDAgMTMuNjIyLTMuODI1MSAyMi42NyAyMi42NyAwIDAgMS0xMC42NzIgMi42NzQ4IDIyLjY3IDIyLjY3IDAgMCAxLTIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3IDIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxLTEuMTM5IDcuMDYwNiAyNi4yNzYgMjYuMjc2IDAgMCAwIDEuNzk1Mi05LjUxNjcgMjYuMjc2IDI2LjI3NiAwIDAgMC0yNi4yNzYtMjYuMjc2eiIvPjxwYXRoIGQ9Im04My42MjQgMTMxLjE0YTI2LjI3NiAyNi4yNzYgMCAwIDEgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMS0xMy42MjItMy44MjUxIDIyLjY3IDIyLjY3IDAgMCAwIDEwLjY3MiAyLjY3NDggMjIuNjcgMjIuNjcgMCAwIDAgMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjcgMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAgMS4xMzkgNy4wNjA2IDI2LjI3NiAyNi4yNzYgMCAwIDEtMS43OTUyLTkuNTE2NyAyNi4yNzYgMjYuMjc2IDAgMCAxIDI2LjI3Ni0yNi4yNzZ6Ii8+PHBhdGggZD0ibTEyNi44NSAxMzQuNjFhMjYuMjc2IDI2LjI3NiAwIDAgMS0zNi45OTkgMy40NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTMuNDYtMzYuOTk5IDI2LjI3NiAyNi4yNzYgMCAwIDEgMTEuNjM5LTguMDQ2NCAyMi42NyAyMi42NyAwIDAgMC04Ljg3MDIgNi41MDkyIDIyLjY3IDIyLjY3IDAgMCAwIDIuOTg0OCAzMS45MjEgMjIuNjcgMjIuNjcgMCAwIDAgMzEuOTIyLTIuOTg1MiAyMi42NyAyMi42NyAwIDAgMC0yLjk4NTUtMzEuOTIxIDIyLjY3IDIyLjY3IDAgMCAwLTYuMTYyNi0zLjYyOTIgMjYuMjc2IDI2LjI3NiAwIDAgMSA4LjQ3MjQgNC42OTE0IDI2LjI3NiAyNi4yNzYgMCAwIDEgMy40NiAzNi45OTl6Ii8+PC9nPjxwYXRoIHRyYW5zZm9ybT0ibWF0cml4KC42NDM2NyAuMTcyNDcgLS4xNzI0NyAuNjQzNjcgNjUuMzQ3IDM2LjU4NykiIGQ9Im0xMDIuMDggMTQxLjc3LTIuMDMzLTIuMDMzIDIuNzc3MS0wLjc0NDExeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="49" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwMS4wNG1tIiBoZWlnaHQ9IjIwMS4wNG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDEuMDQgMjAxLjA0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjIwNTkgLTQ4LjM0NSkiPjxjaXJjbGUgY3g9IjEwMy43MiIgY3k9IjE0OC44NiIgcj0iMTYuMjIxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40MjIiLz48Y2lyY2xlIGN4PSIxMDMuNzIiIGN5PSIxNDguODYiIHI9IjkzLjA5NiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjE0Ljg0NiIvPjxwYXRoIGQ9Im0xMDMuNzIgNTcuNjY5YTkxLjM2MyA5MS4zNjMgMCAwIDAtNDUuNjA3IDEyLjIwMWwzOC44NDYgNjcuMjgzYTEzLjUyMiAxMy41MjIgMCAwIDEgNi43NjEzLTEuODExOCAxMy41MjIgMTMuNTIyIDAgMCAxIDYuNzYwOCAxLjgxMjhsMzguODQ1LTY3LjI4MWE5MS4zNjMgOTEuMzYzIDAgMCAwLTQ1LjYwNi0xMi4yMDR6bS05MS4zNTYgOTEuMTk1YTkxLjM2MyA5MS4zNjMgMCAwIDAtMC4wMDYyIDAuMTY3NDMgOTEuMzYzIDkxLjM2MyAwIDAgMCA0NS42MSA3OS4wNzdsMzguOTkxLTY3LjUzNGExMy41MjIgMTMuNTIyIDAgMCAxLTYuNzYxMy0xMS43MXptMTA0Ljg4IDBhMTMuNTIyIDEzLjUyMiAwIDAgMS02Ljc2MTQgMTEuNzFsMzguOTkxIDY3LjUzNGE5MS4zNjMgOTEuMzYzIDAgMCAwIDQ1LjYxLTc5LjA3NyA5MS4zNjMgOTEuMzYzIDAgMCAwLTJlLTMgLTAuMTY3NDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwM21tIiBoZWlnaHQ9IjE0NC40NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDMgMTQ0LjQ0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjEzMDQgLTcwLjE5OCkiPjxwYXRoIGQ9Im0xNi4zODUgMTQzLjExYzkuMzQ0MS0xMC4zOTYgMTguOTIxLTE2LjE2NyAyOC4wMzItMjQuNjM3IDE3LjUzMy0xNi4zIDE0LjIzNy0yNS4zNCAyNS41MzQtMzMuODE4IDcuNjU1My01Ljc0NDkgMTcuMjcyLTEwLjU1MiAyNi44MzctMTAuMjA5IDguOTEyMSAwLjMxOTI3IDE3LjcxIDUuMjI2NSAyNC4yNiAxMS4yNzcgMTIuODc0IDExLjg5MiAxNi4zMDggMzIuMzk3IDI1Ljg3IDQ1Ljc3MiAxMy4zOTYgMTguNzM4IDQ3Ljg2NCAyNC40MjUgNTQuMjA3IDQzLjI4OCA1Ljg0ODQgMTcuMzkyLTIwLjggMjYuMjE1LTM3LjE1MyAzMS4wMzItMjQuODMxIDcuMzE0Ny01MS44NSA0LjE5MjQtNzcuNjM0IDEuOTAzLTE5Ljk1OS0xLjc3MjEtNDIuMjU3LTAuODcxNTktNTguODk1LTEyLjAzOC05LjkyODMtNi42NjM0LTE4LjY2Ny0xNy45MTYtMTkuOTY0LTI5LjgwMy0wLjg4NDE2LTguMTAxMSAzLjQ1NjgtMTYuNzA4IDguOTA0My0yMi43Njh6IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40NTYiLz48cGF0aCBkPSJtMTA3LjQxIDEzMi43OGMtMC40NTUzNy0wLjMwNDcxLTAuMzc5MzUtMC4zOTkwMSAxLjI4ODktMS41OTg5IDAuNTMzOTctMC4zODQwOCAwLjU0MjYxLTAuNDgyIDAuMTQ0MTgtMS42MzQ2LTAuMzQyNjgtMC45OTEzLTAuNjE3MDUtMS4yODk4LTEuNDMzLTEuNTU5My0wLjYwNDY4LTAuMTk5NjctMS4xMTktMC4yMjg1Ni0xLjI4MzItMC4wNzIxLTAuNTMyNTQgMC41MDc3MS0wLjc0Mjg2IDAuMjUyNDItMC4zMjE2Ni0wLjM5MDQyIDAuNDU1MjktMC42OTQ4NiAwLjM3NzUtMC45MTk5Mi0wLjYwNDY1LTEuNzQ5Mi0wLjYxNTQ0LTAuNTE5NjItMC42MzMyNS0wLjUxMjE4LTEuMzY5NyAwLjU3MTU1LTAuNzgwMzUgMS4xNDg0LTEuMDI3NyAwLjc3MTYyLTAuMzEzNi0wLjQ3NzYyIDEuMDU5LTEuODUyNSAwLjA2MDctMy43NTAzLTEuNDUxNi0yLjc1OTQtMS45MzYgMS4yNjg1LTIuOTg0NyAyLjk2NjItMi4xNTA2IDMuNDgxNiAwLjUwNTQ5IDAuMzEyNDEtMC4zODk0NyAwLjkxODU0LTEuODkyNyAxLjI4MTktMi43MyAwLjY1OTg0LTIuODQ2NCAwLjY2MTY3LTMuMjE4OCAwLjA1MDctMC4zMDYyNS0wLjUwMjQyLTAuMjM4MzgtMC42NzE5NSAwLjUyNjc0LTEuMzE1OCAwLjQ4MzA1LTAuNDA2NDcgMS4wNDIxLTAuNzM5MDMgMS4yNDI0LTAuNzM5MDMgMC41MTAyNCAwIDEuMDMzNC0xLjI3MzEgMS4wMzM0LTIuNTE0OHYtMS4wNDU5bDAuNzA0NzUgMC42NjIwOGMwLjU4MDY2IDAuNTQ1NSAwLjg5MDk2IDAuNjI3MTQgMS43NjIzIDAuNDYzNjggMC41ODE2Ni0wLjEwOTEyIDEuMzc1LTAuNTE1ODggMS43NjMxLTAuOTAzOTEgMC42NDU4Mi0wLjY0NTgyIDAuNjY2NTktMC43NDQ0MyAwLjI0NTU1LTEuMTY1NS0wLjQ2NDI2LTAuNDY0MjUtMC41Nzc5Mi0wLjQ1OTktMy4yNjIgMC4xMjQ4MS0wLjg5MjA0IDAuMTk0MzItMS4yMDc3IDAuMTc5MTUtMS4xMzEyLTAuMDU0MyAwLjA1ODM3LTAuMTc4MTQgMC41NTAzLTAuMzY2NDcgMS4wOTMyLTAuNDE4NTEgMS41MDY0LTAuMTQ0NDQgMi4wMDA0LTAuNzMxMTUgMS42NTg0LTEuOTY5OC0wLjMzNTcyLTEuMjE1OS0wLjEzNjgtMS41NjkgMC4zNTM1My0wLjYyNzUyIDAuMTkyOTIgMC4zNzA0MiAwLjM3NzA3IDAuNzA2NTUgMC40MDkyMiAwLjc0Njk2IDAuMjE3NzYgMC4yNzM3NiAzLjI0MTktMC42MTkwMSAzLjY3NjMtMS4wODUzIDAuNjc3NDYtMC43MjcxNiAzLjY4NjEtMC45MzA3OCAzLjkyNDUtMC4yNjU2IDAuMTUzNDYgMC40MjgyIDEuMTE4IDAuMzEwNDQgMS42MjcxLTAuMTk4NjUgMC42MjAwOC0wLjYyMDA4IDAuODY1MzktMC4zMjczMyAwLjM4NzI4IDAuNDYyMTktMC4zNDkzNCAwLjU3Njg2LTAuMjc3MzMgMC43MjA0NSAwLjg4MTM2IDEuNzU3NSAxLjc1NTggMS41NzE0IDIuOTA3MiAxLjg2NTEgNS42OTAzIDEuNDUxMSAxLjg1ODYtMC4yNzY0MyAyLjMxMDEtMC4yNjQ4IDIuNjQzIDAuMDY4IDAuMzQyOTcgMC4zNDI5NyAwLjI2NzIxIDAuNTU0MjUtMC41MjA1MSAxLjQ1MTQtMC44MDc5IDAuOTIwMTUtMC44NzMyOSAxLjExMi0wLjUyODgxIDEuNTUxNCAwLjc2MDQ1IDAuOTcgMS4yNzExIDEuMjA0IDIuNjQ2OCAxLjIxMzEgMS41MDE1IDAuMDEgMi4yMTYyIDAuMjk1NjIgMy4zMzUxIDEuMzMzMWwwLjcxOTczIDAuNjY3MzctMC43ODU2OSAwLjI5ODcyYy0wLjQzMjEzIDAuMTY0MjktMS4zOTc0IDAuMjk1MTEtMi4xNDUgMC4yOTA3MS0wLjc0NzYzLTRlLTMgLTIuMDczMyAwLjA3MjEtMi45NDU5IDAuMTY5OTQtMS40MTQxIDAuMTU4NTgtMS42NTQ1IDAuMTA0OTQtMi4yMTE2LTAuNDkzNDEtMC4zNDM3OC0wLjM2OTIzLTAuNjY3ODgtMS4wNTQyLTAuNzIwMjMtMS41MjIzLTAuMDY2My0wLjU5MzE5LTAuMzY3NzUtMS4wMDk1LTAuOTk1MDMtMS4zNzQ0LTAuNzg3OTQtMC40NTgzOC0xLjAzOS0wLjQ3ODA2LTIuMDE4NC0wLjE1ODI4LTEuMDM4NiAwLjMzOTEtMS4xMjQ5IDAuNDUxNjQtMS4yMDY1IDEuNTc0NS0wLjA1MDYgMC42OTYyOCAwLjEwMjMgMS41NzcgMC4zNjA0MyAyLjA3NjIgMC40OTc5IDAuOTYyODMgMC41OTM1OCAyLjA0OSAwLjE4MDUgMi4wNDktMC4xNDczMSAwLTAuNzUxMTUgMC40NTU4NC0xLjM0MTkgMS4wMTMtMC41OTA3MyAwLjU1NzEzLTEuMTUxIDAuOTM2MDMtMS4yNDUgMC44NDE5OS0wLjA5NC0wLjA5NCAwLjMxNTE4LTAuNjE2NSAwLjkwOTM2LTEuMTYxIDEuMTY0OS0xLjA2NzUgMS4yODk2LTEuNTg5NyAwLjY0NzgxLTIuNzEyNC0wLjIyNjY1LTAuMzk2NDgtMC40MTY2OS0xLjI2MDgtMC40MjIzMS0xLjkyMDctOGUtMyAtMC45OTI0IDAuMTQzMTgtMS4zMjg5IDAuODc2OTYtMS45NDY0IDAuNzIxNTEtMC42MDcxMSAxLjE4NjQtMC43NDY1MSAyLjQ4OTUtMC43NDY1MSAxLjM4NjkgMCAxLjY5MzEtMC4xMDU2IDIuMjc3NC0wLjc4NTU4IDAuNTkyMjktMC42ODkzIDAuNjE5MDctMC44MTY5IDAuMjE4NS0xLjA0MTEtMC4yNTEwOS0wLjE0MDUyLTAuOTUxMDItMC4xNzY0MS0xLjU1NTQtMC4wNzk4LTEuMzA2MiAwLjIwODg3LTMuMjUwNy0wLjUzMTM3LTQuODQyNS0xLjg0MzUtMS43NTQ4LTEuNDQ2NS0yLjE2ODUtMS4xMjMzLTIuODIxOCAyLjIwNDktMC44NTE0NyA0LjMzODEtMC44NTA2OCA0LjM3NyAwLjExMDM3IDUuMzkwMyAwLjQ3NTk3IDAuNTAxODUgMS4wNzUgMS4zMjg1IDEuMzMxMSAxLjgzNzEgMC40NTU0OCAwLjkwNDI2IDAuNDQ4MzIgMC45NDA3NS0wLjMyNTIxIDEuNjU4LTAuNDM1MDIgMC40MDMzNy0wLjkwNDcyIDAuNzMzNC0xLjA0MzggMC43MzM0cy0wLjE4NDk3IDAuMjU5NTItMC4xMDIwMyAwLjU3NjdjMC4xNjM4NCAwLjYyNjUxLTAuMjQ3ODQgMC43NDczNS0wLjk0ODYgMC4yNzg0NnptLTEwLjEyNy01LjM2MTVjMC41MjUxNC0wLjM2NzgyIDAuNTg1ODQtMC41MjI5MSAwLjI4MDQyLTAuNzE2NDUtMC42MTY2Ni0wLjM5MDc4LTEuNjA1My0wLjI5Njc0LTIuMTAyIDAuMTk5OTItMC45NTI5MiAwLjk1MjkyIDAuNTc4NSAxLjM4NzIgMS44MjE1IDAuNTE2NTN6bTI0LjI1Ni0wLjIzNzg3YzAtMC4zNzA3OC0xLjU3MzQtMS4wMTY2LTIuNDg3OC0xLjAyMTItMC40NzM0OS0yZS0zIC0xLjA1MzMgMC43ODc2Ni0wLjgzNjA4IDEuMTM5MiAwLjEwMjMxIDAuMTY1NTQgMC44OTIwMyAwLjMwMDk4IDEuNzU0OSAwLjMwMDk4IDEuMTc5OCAwIDEuNTY4OS0wLjEwMzkxIDEuNTY4OS0wLjQxODk3em0tMTQuNDE3LTQuNzEzNmMwLTAuNTY3MjktMC43OTk3Mi0wLjkyMjcyLTIuMDc2MS0wLjkyMjcyLTEuMDAxOSAwLTEuMzg0MSAwLjExMjgtMS4zODQxIDAuNDA4NDkgMCAwLjIyNDY4IDAuMTYyMiAwLjQ3Mzk1IDAuMzYwNDQgMC41NTM5NCAwLjU5NjA2IDAuMjQwNTEgMy4wOTk4IDAuMjA4NDQgMy4wOTk4LTAuMDM5N3ptMC4yNjE4OS0yLjAyNjdjMC4yMDc0MS0wLjM4NzU1IDAuMTM0ODItMC43Njk1NC0wLjI3Mzk3LTEuNDQxOC0wLjY2ODItMS4wOTg4LTAuODQ2Ni0xLjEyMTItMS42OTkyLTAuMjEzNjUtMC4zNjY4OCAwLjM5MDUyLTEuMTU1MiAwLjc4NDc3LTEuNzgwNCAwLjg5MDM5LTEuNjk1NyAwLjI4NjQ5LTEuNDU0NyAwLjk1MDQ5IDAuMzkxODkgMS4wNzk3IDAuODMyNjEgMC4wNTgyIDEuODY2MSAwLjEyOTkgMi4yOTY2IDAuMTU5MjQgMC41MDI0MSAwLjAzNDIgMC44ODM4OC0wLjEzNTUyIDEuMDY1LTAuNDczOTF6IiBmaWxsPSJub25lIi8+PHBhdGggZD0ibTExMC42MyAyMDcuM2MtMTAuMjQ5LTAuODg1MTUtMzIuNTA1LTIuNjYyNy0zOS44MTYtMy4xODAxLTI3LjgyOS0xLjk2OTQtMzguNzk5LTUuNjkxMy00OS45NTYtMTYuOTQ4LTUuOTYxMi02LjAxNDctOS42Ni0xMi4yOTUtMTAuOTY3LTE4LjYyMS0yLjI3MjMtMTAuOTk1IDQuMjAwMy0yMS4yNTcgMjIuMTUyLTM1LjEyMiAxMS4yMS04LjY1NzQgMTcuMTgtMTUuMzI4IDI1LjQtMjguMzggMy43NTg3LTUuOTY4MiA4LjIxMzEtMTIuMzkyIDkuODk4Ny0xNC4yNzUgOC4xMDU0LTkuMDU0NiAyMy4wNjgtMTUuNTE0IDMyLjA2Ny0xMy44NDMgNi43ODcgMS4yNjA0IDEzLjg4OCA1LjEwNjMgMTkuNjEgMTAuNjIxIDUuNDQ2IDUuMjQ4NSA4LjQzNjIgMTAuNTE2IDE3LjQyMyAzMC42OTUgOC4zOTUyIDE4Ljg1IDEzLjI2NSAyMy43NjcgMzYuODM5IDM3LjE5OSAxMy43MDUgNy44MDg2IDE4LjIwOSAxMC44OCAyMi4xMTYgMTUuMDc5IDcuMDA3OSA3LjUzMjIgNi44MTYgMTMuNzIxLTAuNjA5NCAxOS42NjEtOC41NDE0IDYuODMyNC0yOS43MzEgMTQuMzc5LTQ2LjYwMSAxNi41OTgtNi40Mjc2IDAuODQ1MjMtMjkuOTk2IDEuMTY5Mi0zNy41NTcgMC41MTYyMnptNDMuNjc4LTE1LjQxNHYtNi4yNjgyaC0xNi42Mzl2MTIuNTM2aDE2LjYzOXptLTYxLjgwMyAxLjc5MDl2LTMuMjgzNGgtNS45NDI2djYuNTY2N2g1Ljk0MjZ6bTI5LjcxMy01Ljk2OTd2LTYuODY1MmgtMTYuMDQ1djEzLjczaDE2LjA0NXptLTUwLjUxMi0xMC4xNDl2LTE1LjgyaC01Ljk0MjZ2MzEuNjRoNS45NDI2em0tMjEuMzk0IDEuNDkyNHYtMTEuOTM5aC03LjcyNTR2MjMuODc5aDcuNzI1NHptMTMxLjMzLTEuMTk0di00Ljc3NThoLTEwLjEwMnY5LjU1MTZoMTAuMTAyem0tMTUyLjczLTYuODY1MnYtMy44ODAzaC0xNC4yNjJ2Ny43NjA2aDE0LjI2MnptNzUuNDcyLTYuODY1MnYtNC4xNzg4aC0xNy4yMzR2OC4zNTc2aDE3LjIzNHptNTIuODg5LTIuOTg0OXYtNi41NjY3aC0xMC4xMDJ2MTMuMTMzaDEwLjEwMnptLTI5LjExOS0yLjM4Nzl2LTUuOTY5N2gtOC4zMTk3djExLjkzOWg4LjMxOTd6bS03Ni4wNjYtOC42Njg3di0zLjg5MjlsLTIzLjQ3MyAwLjMyMzcyLTAuMTc2OTIgMy43MzExLTAuMTc2OTIgMy43MzExaDIzLjgyN3ptNDQuNTctOC4wNDY1di0yLjk4NDloLTI2Ljc0MnY1Ljk2OTdoMjYuNzQyem0zNi44NDQtNi41NjY3di00LjE3ODhoLTIwLjc5OXY4LjM1NzZoMjAuNzk5em0tODIuNzItNy4wMTQ0IDAuMTc5NjItMy4xMzQxaC00LjIyMnY2LjY0MjNsMS45MzE0LTAuMTg3MDZjMS44ODM0LTAuMTgyNDIgMS45MzU4LTAuMjY0ODUgMi4xMTEtMy4zMjEyem00My4zNzQtNy43NjA2IDAuMTcyNi00LjkyNWgtMTAuMTUxdjQuNjc2M2MwIDIuNTcyIDAuMTg4NTQgNC44NjU3IDAuNDE4OTggNS4wOTcyIDAuMjMwNDQgMC4yMzE0OSAyLjQzNjYgMC4zNDM0MSA0LjkwMjcgMC4yNDg3NGw0LjQ4MzctMC4xNzIxNXptLTIzLjY0Ni03LjAxNDR2LTExLjY0MWgtNC43NTQxdjIzLjI4Mmg0Ljc1NDF6bTUwLjUxMi0wLjg5NTQ1di00Ljc3NThoLTguMzE5N3Y5LjU1MTZoOC4zMTk3em0tMjEuOTg4LTE5Ljd2LTEwLjE0OWgtMTUuNDUxdjIwLjI5N2gxNS40NTF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="50" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwM21tIiBoZWlnaHQ9IjE0NC40NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDMgMTQ0LjQ0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjEzMDQgLTcwLjE5OCkiPjxwYXRoIGQ9Im0xNi4zODUgMTQzLjExYzkuMzQ0MS0xMC4zOTYgMTguOTIxLTE2LjE2NyAyOC4wMzItMjQuNjM3IDE3LjUzMy0xNi4zIDE0LjIzNy0yNS4zNCAyNS41MzQtMzMuODE4IDcuNjU1My01Ljc0NDkgMTcuMjcyLTEwLjU1MiAyNi44MzctMTAuMjA5IDguOTEyMSAwLjMxOTI3IDE3LjcxIDUuMjI2NSAyNC4yNiAxMS4yNzcgMTIuODc0IDExLjg5MiAxNi4zMDggMzIuMzk3IDI1Ljg3IDQ1Ljc3MiAxMy4zOTYgMTguNzM4IDQ3Ljg2NCAyNC40MjUgNTQuMjA3IDQzLjI4OCA1Ljg0ODQgMTcuMzkyLTIwLjggMjYuMjE1LTM3LjE1MyAzMS4wMzItMjQuODMxIDcuMzE0Ny01MS44NSA0LjE5MjQtNzcuNjM0IDEuOTAzLTE5Ljk1OS0xLjc3MjEtNDIuMjU3LTAuODcxNTktNTguODk1LTEyLjAzOC05LjkyODMtNi42NjM0LTE4LjY2Ny0xNy45MTYtMTkuOTY0LTI5LjgwMy0wLjg4NDE2LTguMTAxMSAzLjQ1NjgtMTYuNzA4IDguOTA0My0yMi43Njh6IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40NTYiLz48cGF0aCBkPSJtMTA3LjQxIDEzMi43OGMtMC40NTUzNy0wLjMwNDcxLTAuMzc5MzUtMC4zOTkwMSAxLjI4ODktMS41OTg5IDAuNTMzOTctMC4zODQwOCAwLjU0MjYxLTAuNDgyIDAuMTQ0MTgtMS42MzQ2LTAuMzQyNjgtMC45OTEzLTAuNjE3MDUtMS4yODk4LTEuNDMzLTEuNTU5My0wLjYwNDY4LTAuMTk5NjctMS4xMTktMC4yMjg1Ni0xLjI4MzItMC4wNzIxLTAuNTMyNTQgMC41MDc3MS0wLjc0Mjg2IDAuMjUyNDItMC4zMjE2Ni0wLjM5MDQyIDAuNDU1MjktMC42OTQ4NiAwLjM3NzUtMC45MTk5Mi0wLjYwNDY1LTEuNzQ5Mi0wLjYxNTQ0LTAuNTE5NjItMC42MzMyNS0wLjUxMjE4LTEuMzY5NyAwLjU3MTU1LTAuNzgwMzUgMS4xNDg0LTEuMDI3NyAwLjc3MTYyLTAuMzEzNi0wLjQ3NzYyIDEuMDU5LTEuODUyNSAwLjA2MDctMy43NTAzLTEuNDUxNi0yLjc1OTQtMS45MzYgMS4yNjg1LTIuOTg0NyAyLjk2NjItMi4xNTA2IDMuNDgxNiAwLjUwNTQ5IDAuMzEyNDEtMC4zODk0NyAwLjkxODU0LTEuODkyNyAxLjI4MTktMi43MyAwLjY1OTg0LTIuODQ2NCAwLjY2MTY3LTMuMjE4OCAwLjA1MDctMC4zMDYyNS0wLjUwMjQyLTAuMjM4MzgtMC42NzE5NSAwLjUyNjc0LTEuMzE1OCAwLjQ4MzA1LTAuNDA2NDcgMS4wNDIxLTAuNzM5MDMgMS4yNDI0LTAuNzM5MDMgMC41MTAyNCAwIDEuMDMzNC0xLjI3MzEgMS4wMzM0LTIuNTE0OHYtMS4wNDU5bDAuNzA0NzUgMC42NjIwOGMwLjU4MDY2IDAuNTQ1NSAwLjg5MDk2IDAuNjI3MTQgMS43NjIzIDAuNDYzNjggMC41ODE2Ni0wLjEwOTEyIDEuMzc1LTAuNTE1ODggMS43NjMxLTAuOTAzOTEgMC42NDU4Mi0wLjY0NTgyIDAuNjY2NTktMC43NDQ0MyAwLjI0NTU1LTEuMTY1NS0wLjQ2NDI2LTAuNDY0MjUtMC41Nzc5Mi0wLjQ1OTktMy4yNjIgMC4xMjQ4MS0wLjg5MjA0IDAuMTk0MzItMS4yMDc3IDAuMTc5MTUtMS4xMzEyLTAuMDU0MyAwLjA1ODM3LTAuMTc4MTQgMC41NTAzLTAuMzY2NDcgMS4wOTMyLTAuNDE4NTEgMS41MDY0LTAuMTQ0NDQgMi4wMDA0LTAuNzMxMTUgMS42NTg0LTEuOTY5OC0wLjMzNTcyLTEuMjE1OS0wLjEzNjgtMS41NjkgMC4zNTM1My0wLjYyNzUyIDAuMTkyOTIgMC4zNzA0MiAwLjM3NzA3IDAuNzA2NTUgMC40MDkyMiAwLjc0Njk2IDAuMjE3NzYgMC4yNzM3NiAzLjI0MTktMC42MTkwMSAzLjY3NjMtMS4wODUzIDAuNjc3NDYtMC43MjcxNiAzLjY4NjEtMC45MzA3OCAzLjkyNDUtMC4yNjU2IDAuMTUzNDYgMC40MjgyIDEuMTE4IDAuMzEwNDQgMS42MjcxLTAuMTk4NjUgMC42MjAwOC0wLjYyMDA4IDAuODY1MzktMC4zMjczMyAwLjM4NzI4IDAuNDYyMTktMC4zNDkzNCAwLjU3Njg2LTAuMjc3MzMgMC43MjA0NSAwLjg4MTM2IDEuNzU3NSAxLjc1NTggMS41NzE0IDIuOTA3MiAxLjg2NTEgNS42OTAzIDEuNDUxMSAxLjg1ODYtMC4yNzY0MyAyLjMxMDEtMC4yNjQ4IDIuNjQzIDAuMDY4IDAuMzQyOTcgMC4zNDI5NyAwLjI2NzIxIDAuNTU0MjUtMC41MjA1MSAxLjQ1MTQtMC44MDc5IDAuOTIwMTUtMC44NzMyOSAxLjExMi0wLjUyODgxIDEuNTUxNCAwLjc2MDQ1IDAuOTcgMS4yNzExIDEuMjA0IDIuNjQ2OCAxLjIxMzEgMS41MDE1IDAuMDEgMi4yMTYyIDAuMjk1NjIgMy4zMzUxIDEuMzMzMWwwLjcxOTczIDAuNjY3MzctMC43ODU2OSAwLjI5ODcyYy0wLjQzMjEzIDAuMTY0MjktMS4zOTc0IDAuMjk1MTEtMi4xNDUgMC4yOTA3MS0wLjc0NzYzLTRlLTMgLTIuMDczMyAwLjA3MjEtMi45NDU5IDAuMTY5OTQtMS40MTQxIDAuMTU4NTgtMS42NTQ1IDAuMTA0OTQtMi4yMTE2LTAuNDkzNDEtMC4zNDM3OC0wLjM2OTIzLTAuNjY3ODgtMS4wNTQyLTAuNzIwMjMtMS41MjIzLTAuMDY2My0wLjU5MzE5LTAuMzY3NzUtMS4wMDk1LTAuOTk1MDMtMS4zNzQ0LTAuNzg3OTQtMC40NTgzOC0xLjAzOS0wLjQ3ODA2LTIuMDE4NC0wLjE1ODI4LTEuMDM4NiAwLjMzOTEtMS4xMjQ5IDAuNDUxNjQtMS4yMDY1IDEuNTc0NS0wLjA1MDYgMC42OTYyOCAwLjEwMjMgMS41NzcgMC4zNjA0MyAyLjA3NjIgMC40OTc5IDAuOTYyODMgMC41OTM1OCAyLjA0OSAwLjE4MDUgMi4wNDktMC4xNDczMSAwLTAuNzUxMTUgMC40NTU4NC0xLjM0MTkgMS4wMTMtMC41OTA3MyAwLjU1NzEzLTEuMTUxIDAuOTM2MDMtMS4yNDUgMC44NDE5OS0wLjA5NC0wLjA5NCAwLjMxNTE4LTAuNjE2NSAwLjkwOTM2LTEuMTYxIDEuMTY0OS0xLjA2NzUgMS4yODk2LTEuNTg5NyAwLjY0NzgxLTIuNzEyNC0wLjIyNjY1LTAuMzk2NDgtMC40MTY2OS0xLjI2MDgtMC40MjIzMS0xLjkyMDctOGUtMyAtMC45OTI0IDAuMTQzMTgtMS4zMjg5IDAuODc2OTYtMS45NDY0IDAuNzIxNTEtMC42MDcxMSAxLjE4NjQtMC43NDY1MSAyLjQ4OTUtMC43NDY1MSAxLjM4NjkgMCAxLjY5MzEtMC4xMDU2IDIuMjc3NC0wLjc4NTU4IDAuNTkyMjktMC42ODkzIDAuNjE5MDctMC44MTY5IDAuMjE4NS0xLjA0MTEtMC4yNTEwOS0wLjE0MDUyLTAuOTUxMDItMC4xNzY0MS0xLjU1NTQtMC4wNzk4LTEuMzA2MiAwLjIwODg3LTMuMjUwNy0wLjUzMTM3LTQuODQyNS0xLjg0MzUtMS43NTQ4LTEuNDQ2NS0yLjE2ODUtMS4xMjMzLTIuODIxOCAyLjIwNDktMC44NTE0NyA0LjMzODEtMC44NTA2OCA0LjM3NyAwLjExMDM3IDUuMzkwMyAwLjQ3NTk3IDAuNTAxODUgMS4wNzUgMS4zMjg1IDEuMzMxMSAxLjgzNzEgMC40NTU0OCAwLjkwNDI2IDAuNDQ4MzIgMC45NDA3NS0wLjMyNTIxIDEuNjU4LTAuNDM1MDIgMC40MDMzNy0wLjkwNDcyIDAuNzMzNC0xLjA0MzggMC43MzM0cy0wLjE4NDk3IDAuMjU5NTItMC4xMDIwMyAwLjU3NjdjMC4xNjM4NCAwLjYyNjUxLTAuMjQ3ODQgMC43NDczNS0wLjk0ODYgMC4yNzg0NnptLTEwLjEyNy01LjM2MTVjMC41MjUxNC0wLjM2NzgyIDAuNTg1ODQtMC41MjI5MSAwLjI4MDQyLTAuNzE2NDUtMC42MTY2Ni0wLjM5MDc4LTEuNjA1My0wLjI5Njc0LTIuMTAyIDAuMTk5OTItMC45NTI5MiAwLjk1MjkyIDAuNTc4NSAxLjM4NzIgMS44MjE1IDAuNTE2NTN6bTI0LjI1Ni0wLjIzNzg3YzAtMC4zNzA3OC0xLjU3MzQtMS4wMTY2LTIuNDg3OC0xLjAyMTItMC40NzM0OS0yZS0zIC0xLjA1MzMgMC43ODc2Ni0wLjgzNjA4IDEuMTM5MiAwLjEwMjMxIDAuMTY1NTQgMC44OTIwMyAwLjMwMDk4IDEuNzU0OSAwLjMwMDk4IDEuMTc5OCAwIDEuNTY4OS0wLjEwMzkxIDEuNTY4OS0wLjQxODk3em0tMTQuNDE3LTQuNzEzNmMwLTAuNTY3MjktMC43OTk3Mi0wLjkyMjcyLTIuMDc2MS0wLjkyMjcyLTEuMDAxOSAwLTEuMzg0MSAwLjExMjgtMS4zODQxIDAuNDA4NDkgMCAwLjIyNDY4IDAuMTYyMiAwLjQ3Mzk1IDAuMzYwNDQgMC41NTM5NCAwLjU5NjA2IDAuMjQwNTEgMy4wOTk4IDAuMjA4NDQgMy4wOTk4LTAuMDM5N3ptMC4yNjE4OS0yLjAyNjdjMC4yMDc0MS0wLjM4NzU1IDAuMTM0ODItMC43Njk1NC0wLjI3Mzk3LTEuNDQxOC0wLjY2ODItMS4wOTg4LTAuODQ2Ni0xLjEyMTItMS42OTkyLTAuMjEzNjUtMC4zNjY4OCAwLjM5MDUyLTEuMTU1MiAwLjc4NDc3LTEuNzgwNCAwLjg5MDM5LTEuNjk1NyAwLjI4NjQ5LTEuNDU0NyAwLjk1MDQ5IDAuMzkxODkgMS4wNzk3IDAuODMyNjEgMC4wNTgyIDEuODY2MSAwLjEyOTkgMi4yOTY2IDAuMTU5MjQgMC41MDI0MSAwLjAzNDIgMC44ODM4OC0wLjEzNTUyIDEuMDY1LTAuNDczOTF6IiBmaWxsPSJub25lIi8+PHBhdGggZD0ibTExMC42MyAyMDcuM2MtMTAuMjQ5LTAuODg1MTUtMzIuNTA1LTIuNjYyNy0zOS44MTYtMy4xODAxLTI3LjgyOS0xLjk2OTQtMzguNzk5LTUuNjkxMy00OS45NTYtMTYuOTQ4LTUuOTYxMi02LjAxNDctOS42Ni0xMi4yOTUtMTAuOTY3LTE4LjYyMS0yLjI3MjMtMTAuOTk1IDQuMjAwMy0yMS4yNTcgMjIuMTUyLTM1LjEyMiAxMS4yMS04LjY1NzQgMTcuMTgtMTUuMzI4IDI1LjQtMjguMzggMy43NTg3LTUuOTY4MiA4LjIxMzEtMTIuMzkyIDkuODk4Ny0xNC4yNzUgOC4xMDU0LTkuMDU0NiAyMy4wNjgtMTUuNTE0IDMyLjA2Ny0xMy44NDMgNi43ODcgMS4yNjA0IDEzLjg4OCA1LjEwNjMgMTkuNjEgMTAuNjIxIDUuNDQ2IDUuMjQ4NSA4LjQzNjIgMTAuNTE2IDE3LjQyMyAzMC42OTUgOC4zOTUyIDE4Ljg1IDEzLjI2NSAyMy43NjcgMzYuODM5IDM3LjE5OSAxMy43MDUgNy44MDg2IDE4LjIwOSAxMC44OCAyMi4xMTYgMTUuMDc5IDcuMDA3OSA3LjUzMjIgNi44MTYgMTMuNzIxLTAuNjA5NCAxOS42NjEtOC41NDE0IDYuODMyNC0yOS43MzEgMTQuMzc5LTQ2LjYwMSAxNi41OTgtNi40Mjc2IDAuODQ1MjMtMjkuOTk2IDEuMTY5Mi0zNy41NTcgMC41MTYyMnptNDMuNjc4LTE1LjQxNHYtNi4yNjgyaC0xNi42Mzl2MTIuNTM2aDE2LjYzOXptLTYxLjgwMyAxLjc5MDl2LTMuMjgzNGgtNS45NDI2djYuNTY2N2g1Ljk0MjZ6bTI5LjcxMy01Ljk2OTd2LTYuODY1MmgtMTYuMDQ1djEzLjczaDE2LjA0NXptLTUwLjUxMi0xMC4xNDl2LTE1LjgyaC01Ljk0MjZ2MzEuNjRoNS45NDI2em0tMjEuMzk0IDEuNDkyNHYtMTEuOTM5aC03LjcyNTR2MjMuODc5aDcuNzI1NHptMTMxLjMzLTEuMTk0di00Ljc3NThoLTEwLjEwMnY5LjU1MTZoMTAuMTAyem0tMTUyLjczLTYuODY1MnYtMy44ODAzaC0xNC4yNjJ2Ny43NjA2aDE0LjI2MnptNzUuNDcyLTYuODY1MnYtNC4xNzg4aC0xNy4yMzR2OC4zNTc2aDE3LjIzNHptNTIuODg5LTIuOTg0OXYtNi41NjY3aC0xMC4xMDJ2MTMuMTMzaDEwLjEwMnptLTI5LjExOS0yLjM4Nzl2LTUuOTY5N2gtOC4zMTk3djExLjkzOWg4LjMxOTd6bS03Ni4wNjYtOC42Njg3di0zLjg5MjlsLTIzLjQ3MyAwLjMyMzcyLTAuMTc2OTIgMy43MzExLTAuMTc2OTIgMy43MzExaDIzLjgyN3ptNDQuNTctOC4wNDY1di0yLjk4NDloLTI2Ljc0MnY1Ljk2OTdoMjYuNzQyem0zNi44NDQtNi41NjY3di00LjE3ODhoLTIwLjc5OXY4LjM1NzZoMjAuNzk5em0tODIuNzItNy4wMTQ0IDAuMTc5NjItMy4xMzQxaC00LjIyMnY2LjY0MjNsMS45MzE0LTAuMTg3MDZjMS44ODM0LTAuMTgyNDIgMS45MzU4LTAuMjY0ODUgMi4xMTEtMy4zMjEyem00My4zNzQtNy43NjA2IDAuMTcyNi00LjkyNWgtMTAuMTUxdjQuNjc2M2MwIDIuNTcyIDAuMTg4NTQgNC44NjU3IDAuNDE4OTggNS4wOTcyIDAuMjMwNDQgMC4yMzE0OSAyLjQzNjYgMC4zNDM0MSA0LjkwMjcgMC4yNDg3NGw0LjQ4MzctMC4xNzIxNXptLTIzLjY0Ni03LjAxNDR2LTExLjY0MWgtNC43NTQxdjIzLjI4Mmg0Ljc1NDF6bTUwLjUxMi0wLjg5NTQ1di00Ljc3NThoLTguMzE5N3Y5LjU1MTZoOC4zMTk3em0tMjEuOTg4LTE5Ljd2LTEwLjE0OWgtMTUuNDUxdjIwLjI5N2gxNS40NTF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="51" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTI4MHB0IiBoZWlnaHQ9IjEyODBwdCIgdmVyc2lvbj0iMS4wIiB2aWV3Qm94PSIwIDAgMTI4MCAxMjgwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPG1ldGFkYXRhPkNyZWF0ZWQgYnkgcG90cmFjZSAxLjE1LCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxNzwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDEyODApIHNjYWxlKC4xIC0uMSkiPgogIDxwYXRoIGQ9Im02NDk1IDEyNzg5Yy02OTgtNS0xMzUzLTEyLTE0NTUtMTVsLTE4NS03IDgwLTI3YzQ4NS0xNjcgODkyLTUwNSAxMjUxLTEwNDAgMTYwLTIzOSAxNDAtMjAzIDk2OC0xNzI4IDIxMy0zOTIgMzg1LTcxNiAzODItNzIwLTItNC0xODItMTIyLTQwMC0yNjJsLTM5Ny0yNTUgMjc4LTZjMTUzLTQgNzIxLTkgMTI2My0xMyA1NDItMyAxMDczLTkgMTE4MC0xMmwxOTUtNSA3NTUgMTI0N2M0MTUgNjg2IDc2NiAxMjY1IDc3OSAxMjg2bDIzIDQwLTE2OC04OGMtNjI4LTMyOS03NDktMzkyLTc1MS0zOTAtNSA0LTYwOSAxMTIwLTY0MyAxMTg3LTE5OCAzOTItNTc0IDY4NC0xMDI1IDc5NS05MCAyMy0zOTggMjQtMjEzMCAxM3oiLz4KICA8cGF0aCBkPSJtNDI4NSAxMjY2M2MtMjA1LTI2LTQyOC0xMzItNTkyLTI4MC01MS00Ni0xNTA5LTIyOTEtMTQ5Ni0yMzAzIDQtNSA2MjQtMzczIDEzNzctODE5IDc5Ny00NzIgMTM3My04MDggMTM3OC04MDNzMzM3IDU0NCA3MzkgMTE5OGw3MjkgMTE4OC03NSAxNDJjLTQ5MSA5MzktMTE1OSAxNTcwLTE3NjUgMTY2OS04NyAxNC0yMjIgMTgtMjk1IDh6Ii8+CiAgPHBhdGggZD0ibTEwMTc5IDc4MTRjLTc0NS00NTUtMTM2MC04MzItMTM2OC04MzktMTItMTIgODktMjA0IDY1Mi0xMjQ3bDY2Ni0xMjMzaDMxOGMyNDAgMSAzNTMgNSA0NjMgMTkgNDQ5IDU0IDc4NCAxNDcgMTA5NSAzMDEgMTg2IDkyIDMxNiAxODAgNDM3IDI5NCAyNDcgMjMyIDM3NCA1NDMgMzU1IDg3MS0xMyAyMjAgNCAxNzktNTM3IDEyMzUtNTQgMTA1LTIyMCA0MzMtMzcxIDczMC0xNTAgMjk3LTI5MSA1NzUtMzE0IDYxN2wtNDEgNzgtMTM1NS04MjZ6Ii8+CiAgPHBhdGggZD0ibTE2OTAgODU5OGMtNTc1LTQtMTE3Mi0xMS0xMzI4LTE2bC0yODItNyA0MjAtMzI4YzIzMS0xODEgNDIwLTMzMyA0MjAtMzM4IDAtNi0xOTEtMzc2LTQyNS04MjMtMjMzLTQ0Ny00MzUtODQ2LTQ0OS04ODctNzctMjMxLTUzLTQ3OSA2OS03MjQgNzktMTU2IDE3MS0yODAgMzE1LTQyNSAzNzItMzc1IDc0OC01MjAgMTQ3Ny01NzAgMTY0LTExIDY2Ni0xNiA2ODEtNiA1IDMgMjYzIDQxOSA1NzIgOTI1bDU2MiA5MTkgNzctNDFjNDItMjMgMjMxLTEyNSA0MjEtMjI4czM0Ni0xODYgMzQ4LTE4NC0zMjkgNjE5LTczNSAxMzcybC03MzkgMTM2OC0xNzkgMWMtOTkgMC02NTAtMy0xMjI1LTh6Ii8+CiAgPHBhdGggZD0ibTc0NDcgMzkzMy03MTgtMTI5NSAyNjgtNDkxYzE0OC0yNzEgNDcxLTg2MiA3MTgtMTMxNGw0NTAtODIzIDYgNzhjNCA0MiAxMiAyNTUgMTggNDcyczE0IDQxOSAxNyA0NDhsNiA1MyA3NzEtMmM2ODMtMSA3ODIgMSA4NTUgMTUgNDEwIDgyIDgwMyAzNTAgOTkxIDY3NSAzMSA1NCAxNjM4IDMwNTggMTY5NSAzMTY5IDE1IDI5IDEgMjAtODYtNTUtMzg4LTMzNS03ODctNDk4LTE0MjMtNTc5LTExNC0xNS0yOTAtMTgtMTQ2Mi0yMWwtMTMzMy00djQ4Yy0xIDcwLTQ4IDkxNC01MiA5MTgtMiAyLTMyNi01NzktNzIxLTEyOTJ6Ii8+CiAgPHBhdGggZD0ibTIxMiA0OTgwYzQtOCA0MTYtNzcxIDkxNi0xNjk1IDg3MS0xNjA5IDkxMi0xNjgzIDk3OS0xNzU1IDE5MS0yMDYgNTExLTM2MiA4ODQtNDI5IDI5NS01NCAyODktNTMgMTU3Mi01OGwxMTk3LTR2MTYwOSAxNjA5bC02MjIgN2MtMzQzIDMtMTA5MSA5LTE2NjMgMTItMTg3OSAxMS0xNzk5IDEwLTE5MjUgMjgtNTExIDc2LTkyNyAyNzYtMTI1NSA2MDMtNDkgNDktODYgODEtODMgNzN6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="52" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="133,182,111,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="53" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExMS4xOW1tIiBoZWlnaHQ9IjE0NC4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTEuMTkgMTQ0LjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ny43MDMgLTc3LjEyNykiPjxyZWN0IHg9IjUwLjkwNSIgeT0iODUuNTEiIHdpZHRoPSIxMDQuNzkiIGhlaWdodD0iMjEuNDY5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi40MDUiLz48cGF0aCBkPSJtNjEuMDI5IDExMS45NXYxMDQuOThoODQuNTR2LTEwNC43MSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjkuMDIzMSIvPjxnPjxyZWN0IHg9Ijc0LjgyMiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjkyLjA0OCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEwNy43NCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEyNC45NiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9Ijg2LjQzNiIgeT0iNzcuMTI3IiB3aWR0aD0iMzMuNzI2IiBoZWlnaHQ9IjcuOTY4NiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.23585" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="54" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC4wN21tIiBoZWlnaHQ9IjEzNC40bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC4wNyAxMzQuNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQuMzgxIC03OS4wMjcpIj48Zz48cmVjdCB4PSIyNC4zODEiIHk9IjEzOC40NiIgd2lkdGg9IjE2MC4wNyIgaGVpZ2h0PSI3NC45NjEiLz48cmVjdCB4PSI5NC43OTQiIHk9IjEwMi45MiIgd2lkdGg9IjI1LjA0NiIgaGVpZ2h0PSI1OC40NDUiLz48cmVjdCB4PSIxMzEuNjIiIHk9Ijc5LjAyNyIgd2lkdGg9IjM0LjU0NiIgaGVpZ2h0PSI2NC4zODQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="55" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4NC4wOW1tIiBoZWlnaHQ9IjE4NC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODQuMDkgMTg0LjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC41NzUgLTU1Ljc4NikiPjxyZWN0IHRyYW5zZm9ybT0icm90YXRlKDQ1KSIgeD0iMTIxLjIyIiB5PSItMjkuNTY3IiB3aWR0aD0iMTE3LjQyIiBoZWlnaHQ9IjExNy40MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEyLjc1OSIvPjxjaXJjbGUgY3g9IjEwNi42MiIgY3k9IjE0My42IiByPSIyMi42MTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjI3NyIvPjxnIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi4zODMxIj48cGF0aCBkPSJtMTI5LjYyIDEzMS4xNGEyNi4yNzYgMjYuMjc2IDAgMCAwLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMCAyNi4yNzYgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMCAwIDAgMTMuNjIyLTMuODI1MSAyMi42NyAyMi42NyAwIDAgMS0xMC42NzIgMi42NzQ4IDIyLjY3IDIyLjY3IDAgMCAxLTIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3IDIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxLTEuMTM5IDcuMDYwNiAyNi4yNzYgMjYuMjc2IDAgMCAwIDEuNzk1Mi05LjUxNjcgMjYuMjc2IDI2LjI3NiAwIDAgMC0yNi4yNzYtMjYuMjc2eiIvPjxwYXRoIGQ9Im04My42MjQgMTMxLjE0YTI2LjI3NiAyNi4yNzYgMCAwIDEgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMS0xMy42MjItMy44MjUxIDIyLjY3IDIyLjY3IDAgMCAwIDEwLjY3MiAyLjY3NDggMjIuNjcgMjIuNjcgMCAwIDAgMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjcgMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAgMS4xMzkgNy4wNjA2IDI2LjI3NiAyNi4yNzYgMCAwIDEtMS43OTUyLTkuNTE2NyAyNi4yNzYgMjYuMjc2IDAgMCAxIDI2LjI3Ni0yNi4yNzZ6Ii8+PHBhdGggZD0ibTEyNi44NSAxMzQuNjFhMjYuMjc2IDI2LjI3NiAwIDAgMS0zNi45OTkgMy40NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTMuNDYtMzYuOTk5IDI2LjI3NiAyNi4yNzYgMCAwIDEgMTEuNjM5LTguMDQ2NCAyMi42NyAyMi42NyAwIDAgMC04Ljg3MDIgNi41MDkyIDIyLjY3IDIyLjY3IDAgMCAwIDIuOTg0OCAzMS45MjEgMjIuNjcgMjIuNjcgMCAwIDAgMzEuOTIyLTIuOTg1MiAyMi42NyAyMi42NyAwIDAgMC0yLjk4NTUtMzEuOTIxIDIyLjY3IDIyLjY3IDAgMCAwLTYuMTYyNi0zLjYyOTIgMjYuMjc2IDI2LjI3NiAwIDAgMSA4LjQ3MjQgNC42OTE0IDI2LjI3NiAyNi4yNzYgMCAwIDEgMy40NiAzNi45OTl6Ii8+PC9nPjxwYXRoIHRyYW5zZm9ybT0ibWF0cml4KC42NDM2NyAuMTcyNDcgLS4xNzI0NyAuNjQzNjcgNjUuMzQ3IDM2LjU4NykiIGQ9Im0xMDIuMDggMTQxLjc3LTIuMDMzLTIuMDMzIDIuNzc3MS0wLjc0NDExeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="56" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwMS4wNG1tIiBoZWlnaHQ9IjIwMS4wNG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDEuMDQgMjAxLjA0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjIwNTkgLTQ4LjM0NSkiPjxjaXJjbGUgY3g9IjEwMy43MiIgY3k9IjE0OC44NiIgcj0iMTYuMjIxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40MjIiLz48Y2lyY2xlIGN4PSIxMDMuNzIiIGN5PSIxNDguODYiIHI9IjkzLjA5NiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjE0Ljg0NiIvPjxwYXRoIGQ9Im0xMDMuNzIgNTcuNjY5YTkxLjM2MyA5MS4zNjMgMCAwIDAtNDUuNjA3IDEyLjIwMWwzOC44NDYgNjcuMjgzYTEzLjUyMiAxMy41MjIgMCAwIDEgNi43NjEzLTEuODExOCAxMy41MjIgMTMuNTIyIDAgMCAxIDYuNzYwOCAxLjgxMjhsMzguODQ1LTY3LjI4MWE5MS4zNjMgOTEuMzYzIDAgMCAwLTQ1LjYwNi0xMi4yMDR6bS05MS4zNTYgOTEuMTk1YTkxLjM2MyA5MS4zNjMgMCAwIDAtMC4wMDYyIDAuMTY3NDMgOTEuMzYzIDkxLjM2MyAwIDAgMCA0NS42MSA3OS4wNzdsMzguOTkxLTY3LjUzNGExMy41MjIgMTMuNTIyIDAgMCAxLTYuNzYxMy0xMS43MXptMTA0Ljg4IDBhMTMuNTIyIDEzLjUyMiAwIDAgMS02Ljc2MTQgMTEuNzFsMzguOTkxIDY3LjUzNGE5MS4zNjMgOTEuMzYzIDAgMCAwIDQ1LjYxLTc5LjA3NyA5MS4zNjMgOTEuMzYzIDAgMCAwLTJlLTMgLTAuMTY3NDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="57" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwM21tIiBoZWlnaHQ9IjE0NC40NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDMgMTQ0LjQ0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjEzMDQgLTcwLjE5OCkiPjxwYXRoIGQ9Im0xNi4zODUgMTQzLjExYzkuMzQ0MS0xMC4zOTYgMTguOTIxLTE2LjE2NyAyOC4wMzItMjQuNjM3IDE3LjUzMy0xNi4zIDE0LjIzNy0yNS4zNCAyNS41MzQtMzMuODE4IDcuNjU1My01Ljc0NDkgMTcuMjcyLTEwLjU1MiAyNi44MzctMTAuMjA5IDguOTEyMSAwLjMxOTI3IDE3LjcxIDUuMjI2NSAyNC4yNiAxMS4yNzcgMTIuODc0IDExLjg5MiAxNi4zMDggMzIuMzk3IDI1Ljg3IDQ1Ljc3MiAxMy4zOTYgMTguNzM4IDQ3Ljg2NCAyNC40MjUgNTQuMjA3IDQzLjI4OCA1Ljg0ODQgMTcuMzkyLTIwLjggMjYuMjE1LTM3LjE1MyAzMS4wMzItMjQuODMxIDcuMzE0Ny01MS44NSA0LjE5MjQtNzcuNjM0IDEuOTAzLTE5Ljk1OS0xLjc3MjEtNDIuMjU3LTAuODcxNTktNTguODk1LTEyLjAzOC05LjkyODMtNi42NjM0LTE4LjY2Ny0xNy45MTYtMTkuOTY0LTI5LjgwMy0wLjg4NDE2LTguMTAxMSAzLjQ1NjgtMTYuNzA4IDguOTA0My0yMi43Njh6IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40NTYiLz48cGF0aCBkPSJtMTA3LjQxIDEzMi43OGMtMC40NTUzNy0wLjMwNDcxLTAuMzc5MzUtMC4zOTkwMSAxLjI4ODktMS41OTg5IDAuNTMzOTctMC4zODQwOCAwLjU0MjYxLTAuNDgyIDAuMTQ0MTgtMS42MzQ2LTAuMzQyNjgtMC45OTEzLTAuNjE3MDUtMS4yODk4LTEuNDMzLTEuNTU5My0wLjYwNDY4LTAuMTk5NjctMS4xMTktMC4yMjg1Ni0xLjI4MzItMC4wNzIxLTAuNTMyNTQgMC41MDc3MS0wLjc0Mjg2IDAuMjUyNDItMC4zMjE2Ni0wLjM5MDQyIDAuNDU1MjktMC42OTQ4NiAwLjM3NzUtMC45MTk5Mi0wLjYwNDY1LTEuNzQ5Mi0wLjYxNTQ0LTAuNTE5NjItMC42MzMyNS0wLjUxMjE4LTEuMzY5NyAwLjU3MTU1LTAuNzgwMzUgMS4xNDg0LTEuMDI3NyAwLjc3MTYyLTAuMzEzNi0wLjQ3NzYyIDEuMDU5LTEuODUyNSAwLjA2MDctMy43NTAzLTEuNDUxNi0yLjc1OTQtMS45MzYgMS4yNjg1LTIuOTg0NyAyLjk2NjItMi4xNTA2IDMuNDgxNiAwLjUwNTQ5IDAuMzEyNDEtMC4zODk0NyAwLjkxODU0LTEuODkyNyAxLjI4MTktMi43MyAwLjY1OTg0LTIuODQ2NCAwLjY2MTY3LTMuMjE4OCAwLjA1MDctMC4zMDYyNS0wLjUwMjQyLTAuMjM4MzgtMC42NzE5NSAwLjUyNjc0LTEuMzE1OCAwLjQ4MzA1LTAuNDA2NDcgMS4wNDIxLTAuNzM5MDMgMS4yNDI0LTAuNzM5MDMgMC41MTAyNCAwIDEuMDMzNC0xLjI3MzEgMS4wMzM0LTIuNTE0OHYtMS4wNDU5bDAuNzA0NzUgMC42NjIwOGMwLjU4MDY2IDAuNTQ1NSAwLjg5MDk2IDAuNjI3MTQgMS43NjIzIDAuNDYzNjggMC41ODE2Ni0wLjEwOTEyIDEuMzc1LTAuNTE1ODggMS43NjMxLTAuOTAzOTEgMC42NDU4Mi0wLjY0NTgyIDAuNjY2NTktMC43NDQ0MyAwLjI0NTU1LTEuMTY1NS0wLjQ2NDI2LTAuNDY0MjUtMC41Nzc5Mi0wLjQ1OTktMy4yNjIgMC4xMjQ4MS0wLjg5MjA0IDAuMTk0MzItMS4yMDc3IDAuMTc5MTUtMS4xMzEyLTAuMDU0MyAwLjA1ODM3LTAuMTc4MTQgMC41NTAzLTAuMzY2NDcgMS4wOTMyLTAuNDE4NTEgMS41MDY0LTAuMTQ0NDQgMi4wMDA0LTAuNzMxMTUgMS42NTg0LTEuOTY5OC0wLjMzNTcyLTEuMjE1OS0wLjEzNjgtMS41NjkgMC4zNTM1My0wLjYyNzUyIDAuMTkyOTIgMC4zNzA0MiAwLjM3NzA3IDAuNzA2NTUgMC40MDkyMiAwLjc0Njk2IDAuMjE3NzYgMC4yNzM3NiAzLjI0MTktMC42MTkwMSAzLjY3NjMtMS4wODUzIDAuNjc3NDYtMC43MjcxNiAzLjY4NjEtMC45MzA3OCAzLjkyNDUtMC4yNjU2IDAuMTUzNDYgMC40MjgyIDEuMTE4IDAuMzEwNDQgMS42MjcxLTAuMTk4NjUgMC42MjAwOC0wLjYyMDA4IDAuODY1MzktMC4zMjczMyAwLjM4NzI4IDAuNDYyMTktMC4zNDkzNCAwLjU3Njg2LTAuMjc3MzMgMC43MjA0NSAwLjg4MTM2IDEuNzU3NSAxLjc1NTggMS41NzE0IDIuOTA3MiAxLjg2NTEgNS42OTAzIDEuNDUxMSAxLjg1ODYtMC4yNzY0MyAyLjMxMDEtMC4yNjQ4IDIuNjQzIDAuMDY4IDAuMzQyOTcgMC4zNDI5NyAwLjI2NzIxIDAuNTU0MjUtMC41MjA1MSAxLjQ1MTQtMC44MDc5IDAuOTIwMTUtMC44NzMyOSAxLjExMi0wLjUyODgxIDEuNTUxNCAwLjc2MDQ1IDAuOTcgMS4yNzExIDEuMjA0IDIuNjQ2OCAxLjIxMzEgMS41MDE1IDAuMDEgMi4yMTYyIDAuMjk1NjIgMy4zMzUxIDEuMzMzMWwwLjcxOTczIDAuNjY3MzctMC43ODU2OSAwLjI5ODcyYy0wLjQzMjEzIDAuMTY0MjktMS4zOTc0IDAuMjk1MTEtMi4xNDUgMC4yOTA3MS0wLjc0NzYzLTRlLTMgLTIuMDczMyAwLjA3MjEtMi45NDU5IDAuMTY5OTQtMS40MTQxIDAuMTU4NTgtMS42NTQ1IDAuMTA0OTQtMi4yMTE2LTAuNDkzNDEtMC4zNDM3OC0wLjM2OTIzLTAuNjY3ODgtMS4wNTQyLTAuNzIwMjMtMS41MjIzLTAuMDY2My0wLjU5MzE5LTAuMzY3NzUtMS4wMDk1LTAuOTk1MDMtMS4zNzQ0LTAuNzg3OTQtMC40NTgzOC0xLjAzOS0wLjQ3ODA2LTIuMDE4NC0wLjE1ODI4LTEuMDM4NiAwLjMzOTEtMS4xMjQ5IDAuNDUxNjQtMS4yMDY1IDEuNTc0NS0wLjA1MDYgMC42OTYyOCAwLjEwMjMgMS41NzcgMC4zNjA0MyAyLjA3NjIgMC40OTc5IDAuOTYyODMgMC41OTM1OCAyLjA0OSAwLjE4MDUgMi4wNDktMC4xNDczMSAwLTAuNzUxMTUgMC40NTU4NC0xLjM0MTkgMS4wMTMtMC41OTA3MyAwLjU1NzEzLTEuMTUxIDAuOTM2MDMtMS4yNDUgMC44NDE5OS0wLjA5NC0wLjA5NCAwLjMxNTE4LTAuNjE2NSAwLjkwOTM2LTEuMTYxIDEuMTY0OS0xLjA2NzUgMS4yODk2LTEuNTg5NyAwLjY0NzgxLTIuNzEyNC0wLjIyNjY1LTAuMzk2NDgtMC40MTY2OS0xLjI2MDgtMC40MjIzMS0xLjkyMDctOGUtMyAtMC45OTI0IDAuMTQzMTgtMS4zMjg5IDAuODc2OTYtMS45NDY0IDAuNzIxNTEtMC42MDcxMSAxLjE4NjQtMC43NDY1MSAyLjQ4OTUtMC43NDY1MSAxLjM4NjkgMCAxLjY5MzEtMC4xMDU2IDIuMjc3NC0wLjc4NTU4IDAuNTkyMjktMC42ODkzIDAuNjE5MDctMC44MTY5IDAuMjE4NS0xLjA0MTEtMC4yNTEwOS0wLjE0MDUyLTAuOTUxMDItMC4xNzY0MS0xLjU1NTQtMC4wNzk4LTEuMzA2MiAwLjIwODg3LTMuMjUwNy0wLjUzMTM3LTQuODQyNS0xLjg0MzUtMS43NTQ4LTEuNDQ2NS0yLjE2ODUtMS4xMjMzLTIuODIxOCAyLjIwNDktMC44NTE0NyA0LjMzODEtMC44NTA2OCA0LjM3NyAwLjExMDM3IDUuMzkwMyAwLjQ3NTk3IDAuNTAxODUgMS4wNzUgMS4zMjg1IDEuMzMxMSAxLjgzNzEgMC40NTU0OCAwLjkwNDI2IDAuNDQ4MzIgMC45NDA3NS0wLjMyNTIxIDEuNjU4LTAuNDM1MDIgMC40MDMzNy0wLjkwNDcyIDAuNzMzNC0xLjA0MzggMC43MzM0cy0wLjE4NDk3IDAuMjU5NTItMC4xMDIwMyAwLjU3NjdjMC4xNjM4NCAwLjYyNjUxLTAuMjQ3ODQgMC43NDczNS0wLjk0ODYgMC4yNzg0NnptLTEwLjEyNy01LjM2MTVjMC41MjUxNC0wLjM2NzgyIDAuNTg1ODQtMC41MjI5MSAwLjI4MDQyLTAuNzE2NDUtMC42MTY2Ni0wLjM5MDc4LTEuNjA1My0wLjI5Njc0LTIuMTAyIDAuMTk5OTItMC45NTI5MiAwLjk1MjkyIDAuNTc4NSAxLjM4NzIgMS44MjE1IDAuNTE2NTN6bTI0LjI1Ni0wLjIzNzg3YzAtMC4zNzA3OC0xLjU3MzQtMS4wMTY2LTIuNDg3OC0xLjAyMTItMC40NzM0OS0yZS0zIC0xLjA1MzMgMC43ODc2Ni0wLjgzNjA4IDEuMTM5MiAwLjEwMjMxIDAuMTY1NTQgMC44OTIwMyAwLjMwMDk4IDEuNzU0OSAwLjMwMDk4IDEuMTc5OCAwIDEuNTY4OS0wLjEwMzkxIDEuNTY4OS0wLjQxODk3em0tMTQuNDE3LTQuNzEzNmMwLTAuNTY3MjktMC43OTk3Mi0wLjkyMjcyLTIuMDc2MS0wLjkyMjcyLTEuMDAxOSAwLTEuMzg0MSAwLjExMjgtMS4zODQxIDAuNDA4NDkgMCAwLjIyNDY4IDAuMTYyMiAwLjQ3Mzk1IDAuMzYwNDQgMC41NTM5NCAwLjU5NjA2IDAuMjQwNTEgMy4wOTk4IDAuMjA4NDQgMy4wOTk4LTAuMDM5N3ptMC4yNjE4OS0yLjAyNjdjMC4yMDc0MS0wLjM4NzU1IDAuMTM0ODItMC43Njk1NC0wLjI3Mzk3LTEuNDQxOC0wLjY2ODItMS4wOTg4LTAuODQ2Ni0xLjEyMTItMS42OTkyLTAuMjEzNjUtMC4zNjY4OCAwLjM5MDUyLTEuMTU1MiAwLjc4NDc3LTEuNzgwNCAwLjg5MDM5LTEuNjk1NyAwLjI4NjQ5LTEuNDU0NyAwLjk1MDQ5IDAuMzkxODkgMS4wNzk3IDAuODMyNjEgMC4wNTgyIDEuODY2MSAwLjEyOTkgMi4yOTY2IDAuMTU5MjQgMC41MDI0MSAwLjAzNDIgMC44ODM4OC0wLjEzNTUyIDEuMDY1LTAuNDczOTF6IiBmaWxsPSJub25lIi8+PHBhdGggZD0ibTExMC42MyAyMDcuM2MtMTAuMjQ5LTAuODg1MTUtMzIuNTA1LTIuNjYyNy0zOS44MTYtMy4xODAxLTI3LjgyOS0xLjk2OTQtMzguNzk5LTUuNjkxMy00OS45NTYtMTYuOTQ4LTUuOTYxMi02LjAxNDctOS42Ni0xMi4yOTUtMTAuOTY3LTE4LjYyMS0yLjI3MjMtMTAuOTk1IDQuMjAwMy0yMS4yNTcgMjIuMTUyLTM1LjEyMiAxMS4yMS04LjY1NzQgMTcuMTgtMTUuMzI4IDI1LjQtMjguMzggMy43NTg3LTUuOTY4MiA4LjIxMzEtMTIuMzkyIDkuODk4Ny0xNC4yNzUgOC4xMDU0LTkuMDU0NiAyMy4wNjgtMTUuNTE0IDMyLjA2Ny0xMy44NDMgNi43ODcgMS4yNjA0IDEzLjg4OCA1LjEwNjMgMTkuNjEgMTAuNjIxIDUuNDQ2IDUuMjQ4NSA4LjQzNjIgMTAuNTE2IDE3LjQyMyAzMC42OTUgOC4zOTUyIDE4Ljg1IDEzLjI2NSAyMy43NjcgMzYuODM5IDM3LjE5OSAxMy43MDUgNy44MDg2IDE4LjIwOSAxMC44OCAyMi4xMTYgMTUuMDc5IDcuMDA3OSA3LjUzMjIgNi44MTYgMTMuNzIxLTAuNjA5NCAxOS42NjEtOC41NDE0IDYuODMyNC0yOS43MzEgMTQuMzc5LTQ2LjYwMSAxNi41OTgtNi40Mjc2IDAuODQ1MjMtMjkuOTk2IDEuMTY5Mi0zNy41NTcgMC41MTYyMnptNDMuNjc4LTE1LjQxNHYtNi4yNjgyaC0xNi42Mzl2MTIuNTM2aDE2LjYzOXptLTYxLjgwMyAxLjc5MDl2LTMuMjgzNGgtNS45NDI2djYuNTY2N2g1Ljk0MjZ6bTI5LjcxMy01Ljk2OTd2LTYuODY1MmgtMTYuMDQ1djEzLjczaDE2LjA0NXptLTUwLjUxMi0xMC4xNDl2LTE1LjgyaC01Ljk0MjZ2MzEuNjRoNS45NDI2em0tMjEuMzk0IDEuNDkyNHYtMTEuOTM5aC03LjcyNTR2MjMuODc5aDcuNzI1NHptMTMxLjMzLTEuMTk0di00Ljc3NThoLTEwLjEwMnY5LjU1MTZoMTAuMTAyem0tMTUyLjczLTYuODY1MnYtMy44ODAzaC0xNC4yNjJ2Ny43NjA2aDE0LjI2MnptNzUuNDcyLTYuODY1MnYtNC4xNzg4aC0xNy4yMzR2OC4zNTc2aDE3LjIzNHptNTIuODg5LTIuOTg0OXYtNi41NjY3aC0xMC4xMDJ2MTMuMTMzaDEwLjEwMnptLTI5LjExOS0yLjM4Nzl2LTUuOTY5N2gtOC4zMTk3djExLjkzOWg4LjMxOTd6bS03Ni4wNjYtOC42Njg3di0zLjg5MjlsLTIzLjQ3MyAwLjMyMzcyLTAuMTc2OTIgMy43MzExLTAuMTc2OTIgMy43MzExaDIzLjgyN3ptNDQuNTctOC4wNDY1di0yLjk4NDloLTI2Ljc0MnY1Ljk2OTdoMjYuNzQyem0zNi44NDQtNi41NjY3di00LjE3ODhoLTIwLjc5OXY4LjM1NzZoMjAuNzk5em0tODIuNzItNy4wMTQ0IDAuMTc5NjItMy4xMzQxaC00LjIyMnY2LjY0MjNsMS45MzE0LTAuMTg3MDZjMS44ODM0LTAuMTgyNDIgMS45MzU4LTAuMjY0ODUgMi4xMTEtMy4zMjEyem00My4zNzQtNy43NjA2IDAuMTcyNi00LjkyNWgtMTAuMTUxdjQuNjc2M2MwIDIuNTcyIDAuMTg4NTQgNC44NjU3IDAuNDE4OTggNS4wOTcyIDAuMjMwNDQgMC4yMzE0OSAyLjQzNjYgMC4zNDM0MSA0LjkwMjcgMC4yNDg3NGw0LjQ4MzctMC4xNzIxNXptLTIzLjY0Ni03LjAxNDR2LTExLjY0MWgtNC43NTQxdjIzLjI4Mmg0Ljc1NDF6bTUwLjUxMi0wLjg5NTQ1di00Ljc3NThoLTguMzE5N3Y5LjU1MTZoOC4zMTk3em0tMjEuOTg4LTE5Ljd2LTEwLjE0OWgtMTUuNDUxdjIwLjI5N2gxNS40NTF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="58" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTI4MHB0IiBoZWlnaHQ9IjEyODBwdCIgdmVyc2lvbj0iMS4wIiB2aWV3Qm94PSIwIDAgMTI4MCAxMjgwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPG1ldGFkYXRhPkNyZWF0ZWQgYnkgcG90cmFjZSAxLjE1LCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxNzwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDEyODApIHNjYWxlKC4xIC0uMSkiPgogIDxwYXRoIGQ9Im02NDk1IDEyNzg5Yy02OTgtNS0xMzUzLTEyLTE0NTUtMTVsLTE4NS03IDgwLTI3YzQ4NS0xNjcgODkyLTUwNSAxMjUxLTEwNDAgMTYwLTIzOSAxNDAtMjAzIDk2OC0xNzI4IDIxMy0zOTIgMzg1LTcxNiAzODItNzIwLTItNC0xODItMTIyLTQwMC0yNjJsLTM5Ny0yNTUgMjc4LTZjMTUzLTQgNzIxLTkgMTI2My0xMyA1NDItMyAxMDczLTkgMTE4MC0xMmwxOTUtNSA3NTUgMTI0N2M0MTUgNjg2IDc2NiAxMjY1IDc3OSAxMjg2bDIzIDQwLTE2OC04OGMtNjI4LTMyOS03NDktMzkyLTc1MS0zOTAtNSA0LTYwOSAxMTIwLTY0MyAxMTg3LTE5OCAzOTItNTc0IDY4NC0xMDI1IDc5NS05MCAyMy0zOTggMjQtMjEzMCAxM3oiLz4KICA8cGF0aCBkPSJtNDI4NSAxMjY2M2MtMjA1LTI2LTQyOC0xMzItNTkyLTI4MC01MS00Ni0xNTA5LTIyOTEtMTQ5Ni0yMzAzIDQtNSA2MjQtMzczIDEzNzctODE5IDc5Ny00NzIgMTM3My04MDggMTM3OC04MDNzMzM3IDU0NCA3MzkgMTE5OGw3MjkgMTE4OC03NSAxNDJjLTQ5MSA5MzktMTE1OSAxNTcwLTE3NjUgMTY2OS04NyAxNC0yMjIgMTgtMjk1IDh6Ii8+CiAgPHBhdGggZD0ibTEwMTc5IDc4MTRjLTc0NS00NTUtMTM2MC04MzItMTM2OC04MzktMTItMTIgODktMjA0IDY1Mi0xMjQ3bDY2Ni0xMjMzaDMxOGMyNDAgMSAzNTMgNSA0NjMgMTkgNDQ5IDU0IDc4NCAxNDcgMTA5NSAzMDEgMTg2IDkyIDMxNiAxODAgNDM3IDI5NCAyNDcgMjMyIDM3NCA1NDMgMzU1IDg3MS0xMyAyMjAgNCAxNzktNTM3IDEyMzUtNTQgMTA1LTIyMCA0MzMtMzcxIDczMC0xNTAgMjk3LTI5MSA1NzUtMzE0IDYxN2wtNDEgNzgtMTM1NS04MjZ6Ii8+CiAgPHBhdGggZD0ibTE2OTAgODU5OGMtNTc1LTQtMTE3Mi0xMS0xMzI4LTE2bC0yODItNyA0MjAtMzI4YzIzMS0xODEgNDIwLTMzMyA0MjAtMzM4IDAtNi0xOTEtMzc2LTQyNS04MjMtMjMzLTQ0Ny00MzUtODQ2LTQ0OS04ODctNzctMjMxLTUzLTQ3OSA2OS03MjQgNzktMTU2IDE3MS0yODAgMzE1LTQyNSAzNzItMzc1IDc0OC01MjAgMTQ3Ny01NzAgMTY0LTExIDY2Ni0xNiA2ODEtNiA1IDMgMjYzIDQxOSA1NzIgOTI1bDU2MiA5MTkgNzctNDFjNDItMjMgMjMxLTEyNSA0MjEtMjI4czM0Ni0xODYgMzQ4LTE4NC0zMjkgNjE5LTczNSAxMzcybC03MzkgMTM2OC0xNzkgMWMtOTkgMC02NTAtMy0xMjI1LTh6Ii8+CiAgPHBhdGggZD0ibTc0NDcgMzkzMy03MTgtMTI5NSAyNjgtNDkxYzE0OC0yNzEgNDcxLTg2MiA3MTgtMTMxNGw0NTAtODIzIDYgNzhjNCA0MiAxMiAyNTUgMTggNDcyczE0IDQxOSAxNyA0NDhsNiA1MyA3NzEtMmM2ODMtMSA3ODIgMSA4NTUgMTUgNDEwIDgyIDgwMyAzNTAgOTkxIDY3NSAzMSA1NCAxNjM4IDMwNTggMTY5NSAzMTY5IDE1IDI5IDEgMjAtODYtNTUtMzg4LTMzNS03ODctNDk4LTE0MjMtNTc5LTExNC0xNS0yOTAtMTgtMTQ2Mi0yMWwtMTMzMy00djQ4Yy0xIDcwLTQ4IDkxNC01MiA5MTgtMiAyLTMyNi01NzktNzIxLTEyOTJ6Ii8+CiAgPHBhdGggZD0ibTIxMiA0OTgwYzQtOCA0MTYtNzcxIDkxNi0xNjk1IDg3MS0xNjA5IDkxMi0xNjgzIDk3OS0xNzU1IDE5MS0yMDYgNTExLTM2MiA4ODQtNDI5IDI5NS01NCAyODktNTMgMTU3Mi01OGwxMTk3LTR2MTYwOSAxNjA5bC02MjIgN2MtMzQzIDMtMTA5MSA5LTE2NjMgMTItMTg3OSAxMS0xNzk5IDEwLTE5MjUgMjgtNTExIDc2LTkyNyAyNzYtMTI1NSA2MDMtNDkgNDktODYgODEtODMgNzN6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="59" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTI4MHB0IiBoZWlnaHQ9IjEyODBwdCIgdmVyc2lvbj0iMS4wIiB2aWV3Qm94PSIwIDAgMTI4MCAxMjgwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPG1ldGFkYXRhPkNyZWF0ZWQgYnkgcG90cmFjZSAxLjE1LCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxNzwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDEyODApIHNjYWxlKC4xIC0uMSkiPgogIDxwYXRoIGQ9Im02NDk1IDEyNzg5Yy02OTgtNS0xMzUzLTEyLTE0NTUtMTVsLTE4NS03IDgwLTI3YzQ4NS0xNjcgODkyLTUwNSAxMjUxLTEwNDAgMTYwLTIzOSAxNDAtMjAzIDk2OC0xNzI4IDIxMy0zOTIgMzg1LTcxNiAzODItNzIwLTItNC0xODItMTIyLTQwMC0yNjJsLTM5Ny0yNTUgMjc4LTZjMTUzLTQgNzIxLTkgMTI2My0xMyA1NDItMyAxMDczLTkgMTE4MC0xMmwxOTUtNSA3NTUgMTI0N2M0MTUgNjg2IDc2NiAxMjY1IDc3OSAxMjg2bDIzIDQwLTE2OC04OGMtNjI4LTMyOS03NDktMzkyLTc1MS0zOTAtNSA0LTYwOSAxMTIwLTY0MyAxMTg3LTE5OCAzOTItNTc0IDY4NC0xMDI1IDc5NS05MCAyMy0zOTggMjQtMjEzMCAxM3oiLz4KICA8cGF0aCBkPSJtNDI4NSAxMjY2M2MtMjA1LTI2LTQyOC0xMzItNTkyLTI4MC01MS00Ni0xNTA5LTIyOTEtMTQ5Ni0yMzAzIDQtNSA2MjQtMzczIDEzNzctODE5IDc5Ny00NzIgMTM3My04MDggMTM3OC04MDNzMzM3IDU0NCA3MzkgMTE5OGw3MjkgMTE4OC03NSAxNDJjLTQ5MSA5MzktMTE1OSAxNTcwLTE3NjUgMTY2OS04NyAxNC0yMjIgMTgtMjk1IDh6Ii8+CiAgPHBhdGggZD0ibTEwMTc5IDc4MTRjLTc0NS00NTUtMTM2MC04MzItMTM2OC04MzktMTItMTIgODktMjA0IDY1Mi0xMjQ3bDY2Ni0xMjMzaDMxOGMyNDAgMSAzNTMgNSA0NjMgMTkgNDQ5IDU0IDc4NCAxNDcgMTA5NSAzMDEgMTg2IDkyIDMxNiAxODAgNDM3IDI5NCAyNDcgMjMyIDM3NCA1NDMgMzU1IDg3MS0xMyAyMjAgNCAxNzktNTM3IDEyMzUtNTQgMTA1LTIyMCA0MzMtMzcxIDczMC0xNTAgMjk3LTI5MSA1NzUtMzE0IDYxN2wtNDEgNzgtMTM1NS04MjZ6Ii8+CiAgPHBhdGggZD0ibTE2OTAgODU5OGMtNTc1LTQtMTE3Mi0xMS0xMzI4LTE2bC0yODItNyA0MjAtMzI4YzIzMS0xODEgNDIwLTMzMyA0MjAtMzM4IDAtNi0xOTEtMzc2LTQyNS04MjMtMjMzLTQ0Ny00MzUtODQ2LTQ0OS04ODctNzctMjMxLTUzLTQ3OSA2OS03MjQgNzktMTU2IDE3MS0yODAgMzE1LTQyNSAzNzItMzc1IDc0OC01MjAgMTQ3Ny01NzAgMTY0LTExIDY2Ni0xNiA2ODEtNiA1IDMgMjYzIDQxOSA1NzIgOTI1bDU2MiA5MTkgNzctNDFjNDItMjMgMjMxLTEyNSA0MjEtMjI4czM0Ni0xODYgMzQ4LTE4NC0zMjkgNjE5LTczNSAxMzcybC03MzkgMTM2OC0xNzkgMWMtOTkgMC02NTAtMy0xMjI1LTh6Ii8+CiAgPHBhdGggZD0ibTc0NDcgMzkzMy03MTgtMTI5NSAyNjgtNDkxYzE0OC0yNzEgNDcxLTg2MiA3MTgtMTMxNGw0NTAtODIzIDYgNzhjNCA0MiAxMiAyNTUgMTggNDcyczE0IDQxOSAxNyA0NDhsNiA1MyA3NzEtMmM2ODMtMSA3ODIgMSA4NTUgMTUgNDEwIDgyIDgwMyAzNTAgOTkxIDY3NSAzMSA1NCAxNjM4IDMwNTggMTY5NSAzMTY5IDE1IDI5IDEgMjAtODYtNTUtMzg4LTMzNS03ODctNDk4LTE0MjMtNTc5LTExNC0xNS0yOTAtMTgtMTQ2Mi0yMWwtMTMzMy00djQ4Yy0xIDcwLTQ4IDkxNC01MiA5MTgtMiAyLTMyNi01NzktNzIxLTEyOTJ6Ii8+CiAgPHBhdGggZD0ibTIxMiA0OTgwYzQtOCA0MTYtNzcxIDkxNi0xNjk1IDg3MS0xNjA5IDkxMi0xNjgzIDk3OS0xNzU1IDE5MS0yMDYgNTExLTM2MiA4ODQtNDI5IDI5NS01NCAyODktNTMgMTU3Mi01OGwxMTk3LTR2MTYwOSAxNjA5bC02MjIgN2MtMzQzIDMtMTA5MSA5LTE2NjMgMTItMTg3OSAxMS0xNzk5IDEwLTE5MjUgMjgtNTExIDc2LTkyNyAyNzYtMTI1NSA2MDMtNDkgNDktODYgODEtODMgNzN6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="60" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExMS4xOW1tIiBoZWlnaHQ9IjE0NC4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTEuMTkgMTQ0LjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ny43MDMgLTc3LjEyNykiPjxyZWN0IHg9IjUwLjkwNSIgeT0iODUuNTEiIHdpZHRoPSIxMDQuNzkiIGhlaWdodD0iMjEuNDY5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi40MDUiLz48cGF0aCBkPSJtNjEuMDI5IDExMS45NXYxMDQuOThoODQuNTR2LTEwNC43MSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjkuMDIzMSIvPjxnPjxyZWN0IHg9Ijc0LjgyMiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjkyLjA0OCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEwNy43NCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEyNC45NiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9Ijg2LjQzNiIgeT0iNzcuMTI3IiB3aWR0aD0iMzMuNzI2IiBoZWlnaHQ9IjcuOTY4NiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.23585" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="61" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC4wN21tIiBoZWlnaHQ9IjEzNC40bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC4wNyAxMzQuNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQuMzgxIC03OS4wMjcpIj48Zz48cmVjdCB4PSIyNC4zODEiIHk9IjEzOC40NiIgd2lkdGg9IjE2MC4wNyIgaGVpZ2h0PSI3NC45NjEiLz48cmVjdCB4PSI5NC43OTQiIHk9IjEwMi45MiIgd2lkdGg9IjI1LjA0NiIgaGVpZ2h0PSI1OC40NDUiLz48cmVjdCB4PSIxMzEuNjIiIHk9Ijc5LjAyNyIgd2lkdGg9IjM0LjU0NiIgaGVpZ2h0PSI2NC4zODQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="62" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4NC4wOW1tIiBoZWlnaHQ9IjE4NC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODQuMDkgMTg0LjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC41NzUgLTU1Ljc4NikiPjxyZWN0IHRyYW5zZm9ybT0icm90YXRlKDQ1KSIgeD0iMTIxLjIyIiB5PSItMjkuNTY3IiB3aWR0aD0iMTE3LjQyIiBoZWlnaHQ9IjExNy40MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEyLjc1OSIvPjxjaXJjbGUgY3g9IjEwNi42MiIgY3k9IjE0My42IiByPSIyMi42MTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjI3NyIvPjxnIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi4zODMxIj48cGF0aCBkPSJtMTI5LjYyIDEzMS4xNGEyNi4yNzYgMjYuMjc2IDAgMCAwLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMCAyNi4yNzYgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMCAwIDAgMTMuNjIyLTMuODI1MSAyMi42NyAyMi42NyAwIDAgMS0xMC42NzIgMi42NzQ4IDIyLjY3IDIyLjY3IDAgMCAxLTIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3IDIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxLTEuMTM5IDcuMDYwNiAyNi4yNzYgMjYuMjc2IDAgMCAwIDEuNzk1Mi05LjUxNjcgMjYuMjc2IDI2LjI3NiAwIDAgMC0yNi4yNzYtMjYuMjc2eiIvPjxwYXRoIGQ9Im04My42MjQgMTMxLjE0YTI2LjI3NiAyNi4yNzYgMCAwIDEgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMS0xMy42MjItMy44MjUxIDIyLjY3IDIyLjY3IDAgMCAwIDEwLjY3MiAyLjY3NDggMjIuNjcgMjIuNjcgMCAwIDAgMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjcgMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAgMS4xMzkgNy4wNjA2IDI2LjI3NiAyNi4yNzYgMCAwIDEtMS43OTUyLTkuNTE2NyAyNi4yNzYgMjYuMjc2IDAgMCAxIDI2LjI3Ni0yNi4yNzZ6Ii8+PHBhdGggZD0ibTEyNi44NSAxMzQuNjFhMjYuMjc2IDI2LjI3NiAwIDAgMS0zNi45OTkgMy40NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTMuNDYtMzYuOTk5IDI2LjI3NiAyNi4yNzYgMCAwIDEgMTEuNjM5LTguMDQ2NCAyMi42NyAyMi42NyAwIDAgMC04Ljg3MDIgNi41MDkyIDIyLjY3IDIyLjY3IDAgMCAwIDIuOTg0OCAzMS45MjEgMjIuNjcgMjIuNjcgMCAwIDAgMzEuOTIyLTIuOTg1MiAyMi42NyAyMi42NyAwIDAgMC0yLjk4NTUtMzEuOTIxIDIyLjY3IDIyLjY3IDAgMCAwLTYuMTYyNi0zLjYyOTIgMjYuMjc2IDI2LjI3NiAwIDAgMSA4LjQ3MjQgNC42OTE0IDI2LjI3NiAyNi4yNzYgMCAwIDEgMy40NiAzNi45OTl6Ii8+PC9nPjxwYXRoIHRyYW5zZm9ybT0ibWF0cml4KC42NDM2NyAuMTcyNDcgLS4xNzI0NyAuNjQzNjcgNjUuMzQ3IDM2LjU4NykiIGQ9Im0xMDIuMDggMTQxLjc3LTIuMDMzLTIuMDMzIDIuNzc3MS0wLjc0NDExeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="63" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwMS4wNG1tIiBoZWlnaHQ9IjIwMS4wNG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDEuMDQgMjAxLjA0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjIwNTkgLTQ4LjM0NSkiPjxjaXJjbGUgY3g9IjEwMy43MiIgY3k9IjE0OC44NiIgcj0iMTYuMjIxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40MjIiLz48Y2lyY2xlIGN4PSIxMDMuNzIiIGN5PSIxNDguODYiIHI9IjkzLjA5NiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjE0Ljg0NiIvPjxwYXRoIGQ9Im0xMDMuNzIgNTcuNjY5YTkxLjM2MyA5MS4zNjMgMCAwIDAtNDUuNjA3IDEyLjIwMWwzOC44NDYgNjcuMjgzYTEzLjUyMiAxMy41MjIgMCAwIDEgNi43NjEzLTEuODExOCAxMy41MjIgMTMuNTIyIDAgMCAxIDYuNzYwOCAxLjgxMjhsMzguODQ1LTY3LjI4MWE5MS4zNjMgOTEuMzYzIDAgMCAwLTQ1LjYwNi0xMi4yMDR6bS05MS4zNTYgOTEuMTk1YTkxLjM2MyA5MS4zNjMgMCAwIDAtMC4wMDYyIDAuMTY3NDMgOTEuMzYzIDkxLjM2MyAwIDAgMCA0NS42MSA3OS4wNzdsMzguOTkxLTY3LjUzNGExMy41MjIgMTMuNTIyIDAgMCAxLTYuNzYxMy0xMS43MXptMTA0Ljg4IDBhMTMuNTIyIDEzLjUyMiAwIDAgMS02Ljc2MTQgMTEuNzFsMzguOTkxIDY3LjUzNGE5MS4zNjMgOTEuMzYzIDAgMCAwIDQ1LjYxLTc5LjA3NyA5MS4zNjMgOTEuMzYzIDAgMCAwLTJlLTMgLTAuMTY3NDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="64" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTI4MHB0IiBoZWlnaHQ9IjEyODBwdCIgdmVyc2lvbj0iMS4wIiB2aWV3Qm94PSIwIDAgMTI4MCAxMjgwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPG1ldGFkYXRhPkNyZWF0ZWQgYnkgcG90cmFjZSAxLjE1LCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxNzwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDEyODApIHNjYWxlKC4xIC0uMSkiPgogIDxwYXRoIGQ9Im02NDk1IDEyNzg5Yy02OTgtNS0xMzUzLTEyLTE0NTUtMTVsLTE4NS03IDgwLTI3YzQ4NS0xNjcgODkyLTUwNSAxMjUxLTEwNDAgMTYwLTIzOSAxNDAtMjAzIDk2OC0xNzI4IDIxMy0zOTIgMzg1LTcxNiAzODItNzIwLTItNC0xODItMTIyLTQwMC0yNjJsLTM5Ny0yNTUgMjc4LTZjMTUzLTQgNzIxLTkgMTI2My0xMyA1NDItMyAxMDczLTkgMTE4MC0xMmwxOTUtNSA3NTUgMTI0N2M0MTUgNjg2IDc2NiAxMjY1IDc3OSAxMjg2bDIzIDQwLTE2OC04OGMtNjI4LTMyOS03NDktMzkyLTc1MS0zOTAtNSA0LTYwOSAxMTIwLTY0MyAxMTg3LTE5OCAzOTItNTc0IDY4NC0xMDI1IDc5NS05MCAyMy0zOTggMjQtMjEzMCAxM3oiLz4KICA8cGF0aCBkPSJtNDI4NSAxMjY2M2MtMjA1LTI2LTQyOC0xMzItNTkyLTI4MC01MS00Ni0xNTA5LTIyOTEtMTQ5Ni0yMzAzIDQtNSA2MjQtMzczIDEzNzctODE5IDc5Ny00NzIgMTM3My04MDggMTM3OC04MDNzMzM3IDU0NCA3MzkgMTE5OGw3MjkgMTE4OC03NSAxNDJjLTQ5MSA5MzktMTE1OSAxNTcwLTE3NjUgMTY2OS04NyAxNC0yMjIgMTgtMjk1IDh6Ii8+CiAgPHBhdGggZD0ibTEwMTc5IDc4MTRjLTc0NS00NTUtMTM2MC04MzItMTM2OC04MzktMTItMTIgODktMjA0IDY1Mi0xMjQ3bDY2Ni0xMjMzaDMxOGMyNDAgMSAzNTMgNSA0NjMgMTkgNDQ5IDU0IDc4NCAxNDcgMTA5NSAzMDEgMTg2IDkyIDMxNiAxODAgNDM3IDI5NCAyNDcgMjMyIDM3NCA1NDMgMzU1IDg3MS0xMyAyMjAgNCAxNzktNTM3IDEyMzUtNTQgMTA1LTIyMCA0MzMtMzcxIDczMC0xNTAgMjk3LTI5MSA1NzUtMzE0IDYxN2wtNDEgNzgtMTM1NS04MjZ6Ii8+CiAgPHBhdGggZD0ibTE2OTAgODU5OGMtNTc1LTQtMTE3Mi0xMS0xMzI4LTE2bC0yODItNyA0MjAtMzI4YzIzMS0xODEgNDIwLTMzMyA0MjAtMzM4IDAtNi0xOTEtMzc2LTQyNS04MjMtMjMzLTQ0Ny00MzUtODQ2LTQ0OS04ODctNzctMjMxLTUzLTQ3OSA2OS03MjQgNzktMTU2IDE3MS0yODAgMzE1LTQyNSAzNzItMzc1IDc0OC01MjAgMTQ3Ny01NzAgMTY0LTExIDY2Ni0xNiA2ODEtNiA1IDMgMjYzIDQxOSA1NzIgOTI1bDU2MiA5MTkgNzctNDFjNDItMjMgMjMxLTEyNSA0MjEtMjI4czM0Ni0xODYgMzQ4LTE4NC0zMjkgNjE5LTczNSAxMzcybC03MzkgMTM2OC0xNzkgMWMtOTkgMC02NTAtMy0xMjI1LTh6Ii8+CiAgPHBhdGggZD0ibTc0NDcgMzkzMy03MTgtMTI5NSAyNjgtNDkxYzE0OC0yNzEgNDcxLTg2MiA3MTgtMTMxNGw0NTAtODIzIDYgNzhjNCA0MiAxMiAyNTUgMTggNDcyczE0IDQxOSAxNyA0NDhsNiA1MyA3NzEtMmM2ODMtMSA3ODIgMSA4NTUgMTUgNDEwIDgyIDgwMyAzNTAgOTkxIDY3NSAzMSA1NCAxNjM4IDMwNTggMTY5NSAzMTY5IDE1IDI5IDEgMjAtODYtNTUtMzg4LTMzNS03ODctNDk4LTE0MjMtNTc5LTExNC0xNS0yOTAtMTgtMTQ2Mi0yMWwtMTMzMy00djQ4Yy0xIDcwLTQ4IDkxNC01MiA5MTgtMiAyLTMyNi01NzktNzIxLTEyOTJ6Ii8+CiAgPHBhdGggZD0ibTIxMiA0OTgwYzQtOCA0MTYtNzcxIDkxNi0xNjk1IDg3MS0xNjA5IDkxMi0xNjgzIDk3OS0xNzU1IDE5MS0yMDYgNTExLTM2MiA4ODQtNDI5IDI5NS01NCAyODktNTMgMTU3Mi01OGwxMTk3LTR2MTYwOSAxNjA5bC02MjIgN2MtMzQzIDMtMTA5MSA5LTE2NjMgMTItMTg3OSAxMS0xNzk5IDEwLTE5MjUgMjgtNTExIDc2LTkyNyAyNzYtMTI1NSA2MDMtNDkgNDktODYgODEtODMgNzN6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="65" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="145,82,45,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="66" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExMS4xOW1tIiBoZWlnaHQ9IjE0NC4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTEuMTkgMTQ0LjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ny43MDMgLTc3LjEyNykiPjxyZWN0IHg9IjUwLjkwNSIgeT0iODUuNTEiIHdpZHRoPSIxMDQuNzkiIGhlaWdodD0iMjEuNDY5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi40MDUiLz48cGF0aCBkPSJtNjEuMDI5IDExMS45NXYxMDQuOThoODQuNTR2LTEwNC43MSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjkuMDIzMSIvPjxnPjxyZWN0IHg9Ijc0LjgyMiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjkyLjA0OCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEwNy43NCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEyNC45NiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9Ijg2LjQzNiIgeT0iNzcuMTI3IiB3aWR0aD0iMzMuNzI2IiBoZWlnaHQ9IjcuOTY4NiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.23585" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="67" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC4wN21tIiBoZWlnaHQ9IjEzNC40bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC4wNyAxMzQuNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQuMzgxIC03OS4wMjcpIj48Zz48cmVjdCB4PSIyNC4zODEiIHk9IjEzOC40NiIgd2lkdGg9IjE2MC4wNyIgaGVpZ2h0PSI3NC45NjEiLz48cmVjdCB4PSI5NC43OTQiIHk9IjEwMi45MiIgd2lkdGg9IjI1LjA0NiIgaGVpZ2h0PSI1OC40NDUiLz48cmVjdCB4PSIxMzEuNjIiIHk9Ijc5LjAyNyIgd2lkdGg9IjM0LjU0NiIgaGVpZ2h0PSI2NC4zODQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="68" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4NC4wOW1tIiBoZWlnaHQ9IjE4NC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODQuMDkgMTg0LjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC41NzUgLTU1Ljc4NikiPjxyZWN0IHRyYW5zZm9ybT0icm90YXRlKDQ1KSIgeD0iMTIxLjIyIiB5PSItMjkuNTY3IiB3aWR0aD0iMTE3LjQyIiBoZWlnaHQ9IjExNy40MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEyLjc1OSIvPjxjaXJjbGUgY3g9IjEwNi42MiIgY3k9IjE0My42IiByPSIyMi42MTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjI3NyIvPjxnIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi4zODMxIj48cGF0aCBkPSJtMTI5LjYyIDEzMS4xNGEyNi4yNzYgMjYuMjc2IDAgMCAwLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMCAyNi4yNzYgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMCAwIDAgMTMuNjIyLTMuODI1MSAyMi42NyAyMi42NyAwIDAgMS0xMC42NzIgMi42NzQ4IDIyLjY3IDIyLjY3IDAgMCAxLTIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3IDIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxLTEuMTM5IDcuMDYwNiAyNi4yNzYgMjYuMjc2IDAgMCAwIDEuNzk1Mi05LjUxNjcgMjYuMjc2IDI2LjI3NiAwIDAgMC0yNi4yNzYtMjYuMjc2eiIvPjxwYXRoIGQ9Im04My42MjQgMTMxLjE0YTI2LjI3NiAyNi4yNzYgMCAwIDEgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMS0xMy42MjItMy44MjUxIDIyLjY3IDIyLjY3IDAgMCAwIDEwLjY3MiAyLjY3NDggMjIuNjcgMjIuNjcgMCAwIDAgMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjcgMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAgMS4xMzkgNy4wNjA2IDI2LjI3NiAyNi4yNzYgMCAwIDEtMS43OTUyLTkuNTE2NyAyNi4yNzYgMjYuMjc2IDAgMCAxIDI2LjI3Ni0yNi4yNzZ6Ii8+PHBhdGggZD0ibTEyNi44NSAxMzQuNjFhMjYuMjc2IDI2LjI3NiAwIDAgMS0zNi45OTkgMy40NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTMuNDYtMzYuOTk5IDI2LjI3NiAyNi4yNzYgMCAwIDEgMTEuNjM5LTguMDQ2NCAyMi42NyAyMi42NyAwIDAgMC04Ljg3MDIgNi41MDkyIDIyLjY3IDIyLjY3IDAgMCAwIDIuOTg0OCAzMS45MjEgMjIuNjcgMjIuNjcgMCAwIDAgMzEuOTIyLTIuOTg1MiAyMi42NyAyMi42NyAwIDAgMC0yLjk4NTUtMzEuOTIxIDIyLjY3IDIyLjY3IDAgMCAwLTYuMTYyNi0zLjYyOTIgMjYuMjc2IDI2LjI3NiAwIDAgMSA4LjQ3MjQgNC42OTE0IDI2LjI3NiAyNi4yNzYgMCAwIDEgMy40NiAzNi45OTl6Ii8+PC9nPjxwYXRoIHRyYW5zZm9ybT0ibWF0cml4KC42NDM2NyAuMTcyNDcgLS4xNzI0NyAuNjQzNjcgNjUuMzQ3IDM2LjU4NykiIGQ9Im0xMDIuMDggMTQxLjc3LTIuMDMzLTIuMDMzIDIuNzc3MS0wLjc0NDExeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="69" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwMS4wNG1tIiBoZWlnaHQ9IjIwMS4wNG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDEuMDQgMjAxLjA0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjIwNTkgLTQ4LjM0NSkiPjxjaXJjbGUgY3g9IjEwMy43MiIgY3k9IjE0OC44NiIgcj0iMTYuMjIxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40MjIiLz48Y2lyY2xlIGN4PSIxMDMuNzIiIGN5PSIxNDguODYiIHI9IjkzLjA5NiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjE0Ljg0NiIvPjxwYXRoIGQ9Im0xMDMuNzIgNTcuNjY5YTkxLjM2MyA5MS4zNjMgMCAwIDAtNDUuNjA3IDEyLjIwMWwzOC44NDYgNjcuMjgzYTEzLjUyMiAxMy41MjIgMCAwIDEgNi43NjEzLTEuODExOCAxMy41MjIgMTMuNTIyIDAgMCAxIDYuNzYwOCAxLjgxMjhsMzguODQ1LTY3LjI4MWE5MS4zNjMgOTEuMzYzIDAgMCAwLTQ1LjYwNi0xMi4yMDR6bS05MS4zNTYgOTEuMTk1YTkxLjM2MyA5MS4zNjMgMCAwIDAtMC4wMDYyIDAuMTY3NDMgOTEuMzYzIDkxLjM2MyAwIDAgMCA0NS42MSA3OS4wNzdsMzguOTkxLTY3LjUzNGExMy41MjIgMTMuNTIyIDAgMCAxLTYuNzYxMy0xMS43MXptMTA0Ljg4IDBhMTMuNTIyIDEzLjUyMiAwIDAgMS02Ljc2MTQgMTEuNzFsMzguOTkxIDY3LjUzNGE5MS4zNjMgOTEuMzYzIDAgMCAwIDQ1LjYxLTc5LjA3NyA5MS4zNjMgOTEuMzYzIDAgMCAwLTJlLTMgLTAuMTY3NDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="70" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTI4MHB0IiBoZWlnaHQ9IjEyODBwdCIgdmVyc2lvbj0iMS4wIiB2aWV3Qm94PSIwIDAgMTI4MCAxMjgwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPG1ldGFkYXRhPkNyZWF0ZWQgYnkgcG90cmFjZSAxLjE1LCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxNzwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDEyODApIHNjYWxlKC4xIC0uMSkiPgogIDxwYXRoIGQ9Im02NDk1IDEyNzg5Yy02OTgtNS0xMzUzLTEyLTE0NTUtMTVsLTE4NS03IDgwLTI3YzQ4NS0xNjcgODkyLTUwNSAxMjUxLTEwNDAgMTYwLTIzOSAxNDAtMjAzIDk2OC0xNzI4IDIxMy0zOTIgMzg1LTcxNiAzODItNzIwLTItNC0xODItMTIyLTQwMC0yNjJsLTM5Ny0yNTUgMjc4LTZjMTUzLTQgNzIxLTkgMTI2My0xMyA1NDItMyAxMDczLTkgMTE4MC0xMmwxOTUtNSA3NTUgMTI0N2M0MTUgNjg2IDc2NiAxMjY1IDc3OSAxMjg2bDIzIDQwLTE2OC04OGMtNjI4LTMyOS03NDktMzkyLTc1MS0zOTAtNSA0LTYwOSAxMTIwLTY0MyAxMTg3LTE5OCAzOTItNTc0IDY4NC0xMDI1IDc5NS05MCAyMy0zOTggMjQtMjEzMCAxM3oiLz4KICA8cGF0aCBkPSJtNDI4NSAxMjY2M2MtMjA1LTI2LTQyOC0xMzItNTkyLTI4MC01MS00Ni0xNTA5LTIyOTEtMTQ5Ni0yMzAzIDQtNSA2MjQtMzczIDEzNzctODE5IDc5Ny00NzIgMTM3My04MDggMTM3OC04MDNzMzM3IDU0NCA3MzkgMTE5OGw3MjkgMTE4OC03NSAxNDJjLTQ5MSA5MzktMTE1OSAxNTcwLTE3NjUgMTY2OS04NyAxNC0yMjIgMTgtMjk1IDh6Ii8+CiAgPHBhdGggZD0ibTEwMTc5IDc4MTRjLTc0NS00NTUtMTM2MC04MzItMTM2OC04MzktMTItMTIgODktMjA0IDY1Mi0xMjQ3bDY2Ni0xMjMzaDMxOGMyNDAgMSAzNTMgNSA0NjMgMTkgNDQ5IDU0IDc4NCAxNDcgMTA5NSAzMDEgMTg2IDkyIDMxNiAxODAgNDM3IDI5NCAyNDcgMjMyIDM3NCA1NDMgMzU1IDg3MS0xMyAyMjAgNCAxNzktNTM3IDEyMzUtNTQgMTA1LTIyMCA0MzMtMzcxIDczMC0xNTAgMjk3LTI5MSA1NzUtMzE0IDYxN2wtNDEgNzgtMTM1NS04MjZ6Ii8+CiAgPHBhdGggZD0ibTE2OTAgODU5OGMtNTc1LTQtMTE3Mi0xMS0xMzI4LTE2bC0yODItNyA0MjAtMzI4YzIzMS0xODEgNDIwLTMzMyA0MjAtMzM4IDAtNi0xOTEtMzc2LTQyNS04MjMtMjMzLTQ0Ny00MzUtODQ2LTQ0OS04ODctNzctMjMxLTUzLTQ3OSA2OS03MjQgNzktMTU2IDE3MS0yODAgMzE1LTQyNSAzNzItMzc1IDc0OC01MjAgMTQ3Ny01NzAgMTY0LTExIDY2Ni0xNiA2ODEtNiA1IDMgMjYzIDQxOSA1NzIgOTI1bDU2MiA5MTkgNzctNDFjNDItMjMgMjMxLTEyNSA0MjEtMjI4czM0Ni0xODYgMzQ4LTE4NC0zMjkgNjE5LTczNSAxMzcybC03MzkgMTM2OC0xNzkgMWMtOTkgMC02NTAtMy0xMjI1LTh6Ii8+CiAgPHBhdGggZD0ibTc0NDcgMzkzMy03MTgtMTI5NSAyNjgtNDkxYzE0OC0yNzEgNDcxLTg2MiA3MTgtMTMxNGw0NTAtODIzIDYgNzhjNCA0MiAxMiAyNTUgMTggNDcyczE0IDQxOSAxNyA0NDhsNiA1MyA3NzEtMmM2ODMtMSA3ODIgMSA4NTUgMTUgNDEwIDgyIDgwMyAzNTAgOTkxIDY3NSAzMSA1NCAxNjM4IDMwNTggMTY5NSAzMTY5IDE1IDI5IDEgMjAtODYtNTUtMzg4LTMzNS03ODctNDk4LTE0MjMtNTc5LTExNC0xNS0yOTAtMTgtMTQ2Mi0yMWwtMTMzMy00djQ4Yy0xIDcwLTQ4IDkxNC01MiA5MTgtMiAyLTMyNi01NzktNzIxLTEyOTJ6Ii8+CiAgPHBhdGggZD0ibTIxMiA0OTgwYzQtOCA0MTYtNzcxIDkxNi0xNjk1IDg3MS0xNjA5IDkxMi0xNjgzIDk3OS0xNzU1IDE5MS0yMDYgNTExLTM2MiA4ODQtNDI5IDI5NS01NCAyODktNTMgMTU3Mi01OGwxMTk3LTR2MTYwOSAxNjA5bC02MjIgN2MtMzQzIDMtMTA5MSA5LTE2NjMgMTItMTg3OSAxMS0xNzk5IDEwLTE5MjUgMjgtNTExIDc2LTkyNyAyNzYtMTI1NSA2MDMtNDkgNDktODYgODEtODMgNzN6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="71" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="190,178,151,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="72" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExMS4xOW1tIiBoZWlnaHQ9IjE0NC4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTEuMTkgMTQ0LjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ny43MDMgLTc3LjEyNykiPjxyZWN0IHg9IjUwLjkwNSIgeT0iODUuNTEiIHdpZHRoPSIxMDQuNzkiIGhlaWdodD0iMjEuNDY5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi40MDUiLz48cGF0aCBkPSJtNjEuMDI5IDExMS45NXYxMDQuOThoODQuNTR2LTEwNC43MSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjkuMDIzMSIvPjxnPjxyZWN0IHg9Ijc0LjgyMiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjkyLjA0OCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEwNy43NCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEyNC45NiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9Ijg2LjQzNiIgeT0iNzcuMTI3IiB3aWR0aD0iMzMuNzI2IiBoZWlnaHQ9IjcuOTY4NiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.23585" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="73" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC4wN21tIiBoZWlnaHQ9IjEzNC40bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC4wNyAxMzQuNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQuMzgxIC03OS4wMjcpIj48Zz48cmVjdCB4PSIyNC4zODEiIHk9IjEzOC40NiIgd2lkdGg9IjE2MC4wNyIgaGVpZ2h0PSI3NC45NjEiLz48cmVjdCB4PSI5NC43OTQiIHk9IjEwMi45MiIgd2lkdGg9IjI1LjA0NiIgaGVpZ2h0PSI1OC40NDUiLz48cmVjdCB4PSIxMzEuNjIiIHk9Ijc5LjAyNyIgd2lkdGg9IjM0LjU0NiIgaGVpZ2h0PSI2NC4zODQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="74" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4NC4wOW1tIiBoZWlnaHQ9IjE4NC4wOW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODQuMDkgMTg0LjA5IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC41NzUgLTU1Ljc4NikiPjxyZWN0IHRyYW5zZm9ybT0icm90YXRlKDQ1KSIgeD0iMTIxLjIyIiB5PSItMjkuNTY3IiB3aWR0aD0iMTE3LjQyIiBoZWlnaHQ9IjExNy40MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjEyLjc1OSIvPjxjaXJjbGUgY3g9IjEwNi42MiIgY3k9IjE0My42IiByPSIyMi42MTQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSI3LjI3NyIvPjxnIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi4zODMxIj48cGF0aCBkPSJtMTI5LjYyIDEzMS4xNGEyNi4yNzYgMjYuMjc2IDAgMCAwLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMCAyNi4yNzYgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMCAwIDAgMTMuNjIyLTMuODI1MSAyMi42NyAyMi42NyAwIDAgMS0xMC42NzIgMi42NzQ4IDIyLjY3IDIyLjY3IDAgMCAxLTIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3LTIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxIDIyLjY3IDIyLjY3IDIyLjY3IDIyLjY3IDAgMCAxLTEuMTM5IDcuMDYwNiAyNi4yNzYgMjYuMjc2IDAgMCAwIDEuNzk1Mi05LjUxNjcgMjYuMjc2IDI2LjI3NiAwIDAgMC0yNi4yNzYtMjYuMjc2eiIvPjxwYXRoIGQ9Im04My42MjQgMTMxLjE0YTI2LjI3NiAyNi4yNzYgMCAwIDEgMjYuMjc2IDI2LjI3NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTI2LjI3NiAyNi4yNzYgMjYuMjc2IDI2LjI3NiAwIDAgMS0xMy42MjItMy44MjUxIDIyLjY3IDIyLjY3IDAgMCAwIDEwLjY3MiAyLjY3NDggMjIuNjcgMjIuNjcgMCAwIDAgMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjctMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAtMjIuNjcgMjIuNjcgMjIuNjcgMjIuNjcgMCAwIDAgMS4xMzkgNy4wNjA2IDI2LjI3NiAyNi4yNzYgMCAwIDEtMS43OTUyLTkuNTE2NyAyNi4yNzYgMjYuMjc2IDAgMCAxIDI2LjI3Ni0yNi4yNzZ6Ii8+PHBhdGggZD0ibTEyNi44NSAxMzQuNjFhMjYuMjc2IDI2LjI3NiAwIDAgMS0zNi45OTkgMy40NiAyNi4yNzYgMjYuMjc2IDAgMCAxLTMuNDYtMzYuOTk5IDI2LjI3NiAyNi4yNzYgMCAwIDEgMTEuNjM5LTguMDQ2NCAyMi42NyAyMi42NyAwIDAgMC04Ljg3MDIgNi41MDkyIDIyLjY3IDIyLjY3IDAgMCAwIDIuOTg0OCAzMS45MjEgMjIuNjcgMjIuNjcgMCAwIDAgMzEuOTIyLTIuOTg1MiAyMi42NyAyMi42NyAwIDAgMC0yLjk4NTUtMzEuOTIxIDIyLjY3IDIyLjY3IDAgMCAwLTYuMTYyNi0zLjYyOTIgMjYuMjc2IDI2LjI3NiAwIDAgMSA4LjQ3MjQgNC42OTE0IDI2LjI3NiAyNi4yNzYgMCAwIDEgMy40NiAzNi45OTl6Ii8+PC9nPjxwYXRoIHRyYW5zZm9ybT0ibWF0cml4KC42NDM2NyAuMTcyNDcgLS4xNzI0NyAuNjQzNjcgNjUuMzQ3IDM2LjU4NykiIGQ9Im0xMDIuMDggMTQxLjc3LTIuMDMzLTIuMDMzIDIuNzc3MS0wLjc0NDExeiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="75" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwMS4wNG1tIiBoZWlnaHQ9IjIwMS4wNG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDEuMDQgMjAxLjA0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjIwNTkgLTQ4LjM0NSkiPjxjaXJjbGUgY3g9IjEwMy43MiIgY3k9IjE0OC44NiIgcj0iMTYuMjIxIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40MjIiLz48Y2lyY2xlIGN4PSIxMDMuNzIiIGN5PSIxNDguODYiIHI9IjkzLjA5NiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjE0Ljg0NiIvPjxwYXRoIGQ9Im0xMDMuNzIgNTcuNjY5YTkxLjM2MyA5MS4zNjMgMCAwIDAtNDUuNjA3IDEyLjIwMWwzOC44NDYgNjcuMjgzYTEzLjUyMiAxMy41MjIgMCAwIDEgNi43NjEzLTEuODExOCAxMy41MjIgMTMuNTIyIDAgMCAxIDYuNzYwOCAxLjgxMjhsMzguODQ1LTY3LjI4MWE5MS4zNjMgOTEuMzYzIDAgMCAwLTQ1LjYwNi0xMi4yMDR6bS05MS4zNTYgOTEuMTk1YTkxLjM2MyA5MS4zNjMgMCAwIDAtMC4wMDYyIDAuMTY3NDMgOTEuMzYzIDkxLjM2MyAwIDAgMCA0NS42MSA3OS4wNzdsMzguOTkxLTY3LjUzNGExMy41MjIgMTMuNTIyIDAgMCAxLTYuNzYxMy0xMS43MXptMTA0Ljg4IDBhMTMuNTIyIDEzLjUyMiAwIDAgMS02Ljc2MTQgMTEuNzFsMzguOTkxIDY3LjUzNGE5MS4zNjMgOTEuMzYzIDAgMCAwIDQ1LjYxLTc5LjA3NyA5MS4zNjMgOTEuMzYzIDAgMCAwLTJlLTMgLTAuMTY3NDN6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="76" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjIwM21tIiBoZWlnaHQ9IjE0NC40NG1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDMgMTQ0LjQ0IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zLjEzMDQgLTcwLjE5OCkiPjxwYXRoIGQ9Im0xNi4zODUgMTQzLjExYzkuMzQ0MS0xMC4zOTYgMTguOTIxLTE2LjE2NyAyOC4wMzItMjQuNjM3IDE3LjUzMy0xNi4zIDE0LjIzNy0yNS4zNCAyNS41MzQtMzMuODE4IDcuNjU1My01Ljc0NDkgMTcuMjcyLTEwLjU1MiAyNi44MzctMTAuMjA5IDguOTEyMSAwLjMxOTI3IDE3LjcxIDUuMjI2NSAyNC4yNiAxMS4yNzcgMTIuODc0IDExLjg5MiAxNi4zMDggMzIuMzk3IDI1Ljg3IDQ1Ljc3MiAxMy4zOTYgMTguNzM4IDQ3Ljg2NCAyNC40MjUgNTQuMjA3IDQzLjI4OCA1Ljg0ODQgMTcuMzkyLTIwLjggMjYuMjE1LTM3LjE1MyAzMS4wMzItMjQuODMxIDcuMzE0Ny01MS44NSA0LjE5MjQtNzcuNjM0IDEuOTAzLTE5Ljk1OS0xLjc3MjEtNDIuMjU3LTAuODcxNTktNTguODk1LTEyLjAzOC05LjkyODMtNi42NjM0LTE4LjY2Ny0xNy45MTYtMTkuOTY0LTI5LjgwMy0wLjg4NDE2LTguMTAxMSAzLjQ1NjgtMTYuNzA4IDguOTA0My0yMi43Njh6IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iOC40NTYiLz48cGF0aCBkPSJtMTA3LjQxIDEzMi43OGMtMC40NTUzNy0wLjMwNDcxLTAuMzc5MzUtMC4zOTkwMSAxLjI4ODktMS41OTg5IDAuNTMzOTctMC4zODQwOCAwLjU0MjYxLTAuNDgyIDAuMTQ0MTgtMS42MzQ2LTAuMzQyNjgtMC45OTEzLTAuNjE3MDUtMS4yODk4LTEuNDMzLTEuNTU5My0wLjYwNDY4LTAuMTk5NjctMS4xMTktMC4yMjg1Ni0xLjI4MzItMC4wNzIxLTAuNTMyNTQgMC41MDc3MS0wLjc0Mjg2IDAuMjUyNDItMC4zMjE2Ni0wLjM5MDQyIDAuNDU1MjktMC42OTQ4NiAwLjM3NzUtMC45MTk5Mi0wLjYwNDY1LTEuNzQ5Mi0wLjYxNTQ0LTAuNTE5NjItMC42MzMyNS0wLjUxMjE4LTEuMzY5NyAwLjU3MTU1LTAuNzgwMzUgMS4xNDg0LTEuMDI3NyAwLjc3MTYyLTAuMzEzNi0wLjQ3NzYyIDEuMDU5LTEuODUyNSAwLjA2MDctMy43NTAzLTEuNDUxNi0yLjc1OTQtMS45MzYgMS4yNjg1LTIuOTg0NyAyLjk2NjItMi4xNTA2IDMuNDgxNiAwLjUwNTQ5IDAuMzEyNDEtMC4zODk0NyAwLjkxODU0LTEuODkyNyAxLjI4MTktMi43MyAwLjY1OTg0LTIuODQ2NCAwLjY2MTY3LTMuMjE4OCAwLjA1MDctMC4zMDYyNS0wLjUwMjQyLTAuMjM4MzgtMC42NzE5NSAwLjUyNjc0LTEuMzE1OCAwLjQ4MzA1LTAuNDA2NDcgMS4wNDIxLTAuNzM5MDMgMS4yNDI0LTAuNzM5MDMgMC41MTAyNCAwIDEuMDMzNC0xLjI3MzEgMS4wMzM0LTIuNTE0OHYtMS4wNDU5bDAuNzA0NzUgMC42NjIwOGMwLjU4MDY2IDAuNTQ1NSAwLjg5MDk2IDAuNjI3MTQgMS43NjIzIDAuNDYzNjggMC41ODE2Ni0wLjEwOTEyIDEuMzc1LTAuNTE1ODggMS43NjMxLTAuOTAzOTEgMC42NDU4Mi0wLjY0NTgyIDAuNjY2NTktMC43NDQ0MyAwLjI0NTU1LTEuMTY1NS0wLjQ2NDI2LTAuNDY0MjUtMC41Nzc5Mi0wLjQ1OTktMy4yNjIgMC4xMjQ4MS0wLjg5MjA0IDAuMTk0MzItMS4yMDc3IDAuMTc5MTUtMS4xMzEyLTAuMDU0MyAwLjA1ODM3LTAuMTc4MTQgMC41NTAzLTAuMzY2NDcgMS4wOTMyLTAuNDE4NTEgMS41MDY0LTAuMTQ0NDQgMi4wMDA0LTAuNzMxMTUgMS42NTg0LTEuOTY5OC0wLjMzNTcyLTEuMjE1OS0wLjEzNjgtMS41NjkgMC4zNTM1My0wLjYyNzUyIDAuMTkyOTIgMC4zNzA0MiAwLjM3NzA3IDAuNzA2NTUgMC40MDkyMiAwLjc0Njk2IDAuMjE3NzYgMC4yNzM3NiAzLjI0MTktMC42MTkwMSAzLjY3NjMtMS4wODUzIDAuNjc3NDYtMC43MjcxNiAzLjY4NjEtMC45MzA3OCAzLjkyNDUtMC4yNjU2IDAuMTUzNDYgMC40MjgyIDEuMTE4IDAuMzEwNDQgMS42MjcxLTAuMTk4NjUgMC42MjAwOC0wLjYyMDA4IDAuODY1MzktMC4zMjczMyAwLjM4NzI4IDAuNDYyMTktMC4zNDkzNCAwLjU3Njg2LTAuMjc3MzMgMC43MjA0NSAwLjg4MTM2IDEuNzU3NSAxLjc1NTggMS41NzE0IDIuOTA3MiAxLjg2NTEgNS42OTAzIDEuNDUxMSAxLjg1ODYtMC4yNzY0MyAyLjMxMDEtMC4yNjQ4IDIuNjQzIDAuMDY4IDAuMzQyOTcgMC4zNDI5NyAwLjI2NzIxIDAuNTU0MjUtMC41MjA1MSAxLjQ1MTQtMC44MDc5IDAuOTIwMTUtMC44NzMyOSAxLjExMi0wLjUyODgxIDEuNTUxNCAwLjc2MDQ1IDAuOTcgMS4yNzExIDEuMjA0IDIuNjQ2OCAxLjIxMzEgMS41MDE1IDAuMDEgMi4yMTYyIDAuMjk1NjIgMy4zMzUxIDEuMzMzMWwwLjcxOTczIDAuNjY3MzctMC43ODU2OSAwLjI5ODcyYy0wLjQzMjEzIDAuMTY0MjktMS4zOTc0IDAuMjk1MTEtMi4xNDUgMC4yOTA3MS0wLjc0NzYzLTRlLTMgLTIuMDczMyAwLjA3MjEtMi45NDU5IDAuMTY5OTQtMS40MTQxIDAuMTU4NTgtMS42NTQ1IDAuMTA0OTQtMi4yMTE2LTAuNDkzNDEtMC4zNDM3OC0wLjM2OTIzLTAuNjY3ODgtMS4wNTQyLTAuNzIwMjMtMS41MjIzLTAuMDY2My0wLjU5MzE5LTAuMzY3NzUtMS4wMDk1LTAuOTk1MDMtMS4zNzQ0LTAuNzg3OTQtMC40NTgzOC0xLjAzOS0wLjQ3ODA2LTIuMDE4NC0wLjE1ODI4LTEuMDM4NiAwLjMzOTEtMS4xMjQ5IDAuNDUxNjQtMS4yMDY1IDEuNTc0NS0wLjA1MDYgMC42OTYyOCAwLjEwMjMgMS41NzcgMC4zNjA0MyAyLjA3NjIgMC40OTc5IDAuOTYyODMgMC41OTM1OCAyLjA0OSAwLjE4MDUgMi4wNDktMC4xNDczMSAwLTAuNzUxMTUgMC40NTU4NC0xLjM0MTkgMS4wMTMtMC41OTA3MyAwLjU1NzEzLTEuMTUxIDAuOTM2MDMtMS4yNDUgMC44NDE5OS0wLjA5NC0wLjA5NCAwLjMxNTE4LTAuNjE2NSAwLjkwOTM2LTEuMTYxIDEuMTY0OS0xLjA2NzUgMS4yODk2LTEuNTg5NyAwLjY0NzgxLTIuNzEyNC0wLjIyNjY1LTAuMzk2NDgtMC40MTY2OS0xLjI2MDgtMC40MjIzMS0xLjkyMDctOGUtMyAtMC45OTI0IDAuMTQzMTgtMS4zMjg5IDAuODc2OTYtMS45NDY0IDAuNzIxNTEtMC42MDcxMSAxLjE4NjQtMC43NDY1MSAyLjQ4OTUtMC43NDY1MSAxLjM4NjkgMCAxLjY5MzEtMC4xMDU2IDIuMjc3NC0wLjc4NTU4IDAuNTkyMjktMC42ODkzIDAuNjE5MDctMC44MTY5IDAuMjE4NS0xLjA0MTEtMC4yNTEwOS0wLjE0MDUyLTAuOTUxMDItMC4xNzY0MS0xLjU1NTQtMC4wNzk4LTEuMzA2MiAwLjIwODg3LTMuMjUwNy0wLjUzMTM3LTQuODQyNS0xLjg0MzUtMS43NTQ4LTEuNDQ2NS0yLjE2ODUtMS4xMjMzLTIuODIxOCAyLjIwNDktMC44NTE0NyA0LjMzODEtMC44NTA2OCA0LjM3NyAwLjExMDM3IDUuMzkwMyAwLjQ3NTk3IDAuNTAxODUgMS4wNzUgMS4zMjg1IDEuMzMxMSAxLjgzNzEgMC40NTU0OCAwLjkwNDI2IDAuNDQ4MzIgMC45NDA3NS0wLjMyNTIxIDEuNjU4LTAuNDM1MDIgMC40MDMzNy0wLjkwNDcyIDAuNzMzNC0xLjA0MzggMC43MzM0cy0wLjE4NDk3IDAuMjU5NTItMC4xMDIwMyAwLjU3NjdjMC4xNjM4NCAwLjYyNjUxLTAuMjQ3ODQgMC43NDczNS0wLjk0ODYgMC4yNzg0NnptLTEwLjEyNy01LjM2MTVjMC41MjUxNC0wLjM2NzgyIDAuNTg1ODQtMC41MjI5MSAwLjI4MDQyLTAuNzE2NDUtMC42MTY2Ni0wLjM5MDc4LTEuNjA1My0wLjI5Njc0LTIuMTAyIDAuMTk5OTItMC45NTI5MiAwLjk1MjkyIDAuNTc4NSAxLjM4NzIgMS44MjE1IDAuNTE2NTN6bTI0LjI1Ni0wLjIzNzg3YzAtMC4zNzA3OC0xLjU3MzQtMS4wMTY2LTIuNDg3OC0xLjAyMTItMC40NzM0OS0yZS0zIC0xLjA1MzMgMC43ODc2Ni0wLjgzNjA4IDEuMTM5MiAwLjEwMjMxIDAuMTY1NTQgMC44OTIwMyAwLjMwMDk4IDEuNzU0OSAwLjMwMDk4IDEuMTc5OCAwIDEuNTY4OS0wLjEwMzkxIDEuNTY4OS0wLjQxODk3em0tMTQuNDE3LTQuNzEzNmMwLTAuNTY3MjktMC43OTk3Mi0wLjkyMjcyLTIuMDc2MS0wLjkyMjcyLTEuMDAxOSAwLTEuMzg0MSAwLjExMjgtMS4zODQxIDAuNDA4NDkgMCAwLjIyNDY4IDAuMTYyMiAwLjQ3Mzk1IDAuMzYwNDQgMC41NTM5NCAwLjU5NjA2IDAuMjQwNTEgMy4wOTk4IDAuMjA4NDQgMy4wOTk4LTAuMDM5N3ptMC4yNjE4OS0yLjAyNjdjMC4yMDc0MS0wLjM4NzU1IDAuMTM0ODItMC43Njk1NC0wLjI3Mzk3LTEuNDQxOC0wLjY2ODItMS4wOTg4LTAuODQ2Ni0xLjEyMTItMS42OTkyLTAuMjEzNjUtMC4zNjY4OCAwLjM5MDUyLTEuMTU1MiAwLjc4NDc3LTEuNzgwNCAwLjg5MDM5LTEuNjk1NyAwLjI4NjQ5LTEuNDU0NyAwLjk1MDQ5IDAuMzkxODkgMS4wNzk3IDAuODMyNjEgMC4wNTgyIDEuODY2MSAwLjEyOTkgMi4yOTY2IDAuMTU5MjQgMC41MDI0MSAwLjAzNDIgMC44ODM4OC0wLjEzNTUyIDEuMDY1LTAuNDczOTF6IiBmaWxsPSJub25lIi8+PHBhdGggZD0ibTExMC42MyAyMDcuM2MtMTAuMjQ5LTAuODg1MTUtMzIuNTA1LTIuNjYyNy0zOS44MTYtMy4xODAxLTI3LjgyOS0xLjk2OTQtMzguNzk5LTUuNjkxMy00OS45NTYtMTYuOTQ4LTUuOTYxMi02LjAxNDctOS42Ni0xMi4yOTUtMTAuOTY3LTE4LjYyMS0yLjI3MjMtMTAuOTk1IDQuMjAwMy0yMS4yNTcgMjIuMTUyLTM1LjEyMiAxMS4yMS04LjY1NzQgMTcuMTgtMTUuMzI4IDI1LjQtMjguMzggMy43NTg3LTUuOTY4MiA4LjIxMzEtMTIuMzkyIDkuODk4Ny0xNC4yNzUgOC4xMDU0LTkuMDU0NiAyMy4wNjgtMTUuNTE0IDMyLjA2Ny0xMy44NDMgNi43ODcgMS4yNjA0IDEzLjg4OCA1LjEwNjMgMTkuNjEgMTAuNjIxIDUuNDQ2IDUuMjQ4NSA4LjQzNjIgMTAuNTE2IDE3LjQyMyAzMC42OTUgOC4zOTUyIDE4Ljg1IDEzLjI2NSAyMy43NjcgMzYuODM5IDM3LjE5OSAxMy43MDUgNy44MDg2IDE4LjIwOSAxMC44OCAyMi4xMTYgMTUuMDc5IDcuMDA3OSA3LjUzMjIgNi44MTYgMTMuNzIxLTAuNjA5NCAxOS42NjEtOC41NDE0IDYuODMyNC0yOS43MzEgMTQuMzc5LTQ2LjYwMSAxNi41OTgtNi40Mjc2IDAuODQ1MjMtMjkuOTk2IDEuMTY5Mi0zNy41NTcgMC41MTYyMnptNDMuNjc4LTE1LjQxNHYtNi4yNjgyaC0xNi42Mzl2MTIuNTM2aDE2LjYzOXptLTYxLjgwMyAxLjc5MDl2LTMuMjgzNGgtNS45NDI2djYuNTY2N2g1Ljk0MjZ6bTI5LjcxMy01Ljk2OTd2LTYuODY1MmgtMTYuMDQ1djEzLjczaDE2LjA0NXptLTUwLjUxMi0xMC4xNDl2LTE1LjgyaC01Ljk0MjZ2MzEuNjRoNS45NDI2em0tMjEuMzk0IDEuNDkyNHYtMTEuOTM5aC03LjcyNTR2MjMuODc5aDcuNzI1NHptMTMxLjMzLTEuMTk0di00Ljc3NThoLTEwLjEwMnY5LjU1MTZoMTAuMTAyem0tMTUyLjczLTYuODY1MnYtMy44ODAzaC0xNC4yNjJ2Ny43NjA2aDE0LjI2MnptNzUuNDcyLTYuODY1MnYtNC4xNzg4aC0xNy4yMzR2OC4zNTc2aDE3LjIzNHptNTIuODg5LTIuOTg0OXYtNi41NjY3aC0xMC4xMDJ2MTMuMTMzaDEwLjEwMnptLTI5LjExOS0yLjM4Nzl2LTUuOTY5N2gtOC4zMTk3djExLjkzOWg4LjMxOTd6bS03Ni4wNjYtOC42Njg3di0zLjg5MjlsLTIzLjQ3MyAwLjMyMzcyLTAuMTc2OTIgMy43MzExLTAuMTc2OTIgMy43MzExaDIzLjgyN3ptNDQuNTctOC4wNDY1di0yLjk4NDloLTI2Ljc0MnY1Ljk2OTdoMjYuNzQyem0zNi44NDQtNi41NjY3di00LjE3ODhoLTIwLjc5OXY4LjM1NzZoMjAuNzk5em0tODIuNzItNy4wMTQ0IDAuMTc5NjItMy4xMzQxaC00LjIyMnY2LjY0MjNsMS45MzE0LTAuMTg3MDZjMS44ODM0LTAuMTgyNDIgMS45MzU4LTAuMjY0ODUgMi4xMTEtMy4zMjEyem00My4zNzQtNy43NjA2IDAuMTcyNi00LjkyNWgtMTAuMTUxdjQuNjc2M2MwIDIuNTcyIDAuMTg4NTQgNC44NjU3IDAuNDE4OTggNS4wOTcyIDAuMjMwNDQgMC4yMzE0OSAyLjQzNjYgMC4zNDM0MSA0LjkwMjcgMC4yNDg3NGw0LjQ4MzctMC4xNzIxNXptLTIzLjY0Ni03LjAxNDR2LTExLjY0MWgtNC43NTQxdjIzLjI4Mmg0Ljc1NDF6bTUwLjUxMi0wLjg5NTQ1di00Ljc3NThoLTguMzE5N3Y5LjU1MTZoOC4zMTk3em0tMjEuOTg4LTE5Ljd2LTEwLjE0OWgtMTUuNDUxdjIwLjI5N2gxNS40NTF6Ii8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="77" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="35,35,35,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTI4MHB0IiBoZWlnaHQ9IjEyODBwdCIgdmVyc2lvbj0iMS4wIiB2aWV3Qm94PSIwIDAgMTI4MCAxMjgwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPG1ldGFkYXRhPkNyZWF0ZWQgYnkgcG90cmFjZSAxLjE1LCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxNzwvbWV0YWRhdGE+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDEyODApIHNjYWxlKC4xIC0uMSkiPgogIDxwYXRoIGQ9Im02NDk1IDEyNzg5Yy02OTgtNS0xMzUzLTEyLTE0NTUtMTVsLTE4NS03IDgwLTI3YzQ4NS0xNjcgODkyLTUwNSAxMjUxLTEwNDAgMTYwLTIzOSAxNDAtMjAzIDk2OC0xNzI4IDIxMy0zOTIgMzg1LTcxNiAzODItNzIwLTItNC0xODItMTIyLTQwMC0yNjJsLTM5Ny0yNTUgMjc4LTZjMTUzLTQgNzIxLTkgMTI2My0xMyA1NDItMyAxMDczLTkgMTE4MC0xMmwxOTUtNSA3NTUgMTI0N2M0MTUgNjg2IDc2NiAxMjY1IDc3OSAxMjg2bDIzIDQwLTE2OC04OGMtNjI4LTMyOS03NDktMzkyLTc1MS0zOTAtNSA0LTYwOSAxMTIwLTY0MyAxMTg3LTE5OCAzOTItNTc0IDY4NC0xMDI1IDc5NS05MCAyMy0zOTggMjQtMjEzMCAxM3oiLz4KICA8cGF0aCBkPSJtNDI4NSAxMjY2M2MtMjA1LTI2LTQyOC0xMzItNTkyLTI4MC01MS00Ni0xNTA5LTIyOTEtMTQ5Ni0yMzAzIDQtNSA2MjQtMzczIDEzNzctODE5IDc5Ny00NzIgMTM3My04MDggMTM3OC04MDNzMzM3IDU0NCA3MzkgMTE5OGw3MjkgMTE4OC03NSAxNDJjLTQ5MSA5MzktMTE1OSAxNTcwLTE3NjUgMTY2OS04NyAxNC0yMjIgMTgtMjk1IDh6Ii8+CiAgPHBhdGggZD0ibTEwMTc5IDc4MTRjLTc0NS00NTUtMTM2MC04MzItMTM2OC04MzktMTItMTIgODktMjA0IDY1Mi0xMjQ3bDY2Ni0xMjMzaDMxOGMyNDAgMSAzNTMgNSA0NjMgMTkgNDQ5IDU0IDc4NCAxNDcgMTA5NSAzMDEgMTg2IDkyIDMxNiAxODAgNDM3IDI5NCAyNDcgMjMyIDM3NCA1NDMgMzU1IDg3MS0xMyAyMjAgNCAxNzktNTM3IDEyMzUtNTQgMTA1LTIyMCA0MzMtMzcxIDczMC0xNTAgMjk3LTI5MSA1NzUtMzE0IDYxN2wtNDEgNzgtMTM1NS04MjZ6Ii8+CiAgPHBhdGggZD0ibTE2OTAgODU5OGMtNTc1LTQtMTE3Mi0xMS0xMzI4LTE2bC0yODItNyA0MjAtMzI4YzIzMS0xODEgNDIwLTMzMyA0MjAtMzM4IDAtNi0xOTEtMzc2LTQyNS04MjMtMjMzLTQ0Ny00MzUtODQ2LTQ0OS04ODctNzctMjMxLTUzLTQ3OSA2OS03MjQgNzktMTU2IDE3MS0yODAgMzE1LTQyNSAzNzItMzc1IDc0OC01MjAgMTQ3Ny01NzAgMTY0LTExIDY2Ni0xNiA2ODEtNiA1IDMgMjYzIDQxOSA1NzIgOTI1bDU2MiA5MTkgNzctNDFjNDItMjMgMjMxLTEyNSA0MjEtMjI4czM0Ni0xODYgMzQ4LTE4NC0zMjkgNjE5LTczNSAxMzcybC03MzkgMTM2OC0xNzkgMWMtOTkgMC02NTAtMy0xMjI1LTh6Ii8+CiAgPHBhdGggZD0ibTc0NDcgMzkzMy03MTgtMTI5NSAyNjgtNDkxYzE0OC0yNzEgNDcxLTg2MiA3MTgtMTMxNGw0NTAtODIzIDYgNzhjNCA0MiAxMiAyNTUgMTggNDcyczE0IDQxOSAxNyA0NDhsNiA1MyA3NzEtMmM2ODMtMSA3ODIgMSA4NTUgMTUgNDEwIDgyIDgwMyAzNTAgOTkxIDY3NSAzMSA1NCAxNjM4IDMwNTggMTY5NSAzMTY5IDE1IDI5IDEgMjAtODYtNTUtMzg4LTMzNS03ODctNDk4LTE0MjMtNTc5LTExNC0xNS0yOTAtMTgtMTQ2Mi0yMWwtMTMzMy00djQ4Yy0xIDcwLTQ4IDkxNC01MiA5MTgtMiAyLTMyNi01NzktNzIxLTEyOTJ6Ii8+CiAgPHBhdGggZD0ibTIxMiA0OTgwYzQtOCA0MTYtNzcxIDkxNi0xNjk1IDg3MS0xNjA5IDkxMi0xNjgzIDk3OS0xNzU1IDE5MS0yMDYgNTExLTM2MiA4ODQtNDI5IDI5NS01NCAyODktNTMgMTU3Mi01OGwxMTk3LTR2MTYwOSAxNjA5bC02MjIgN2MtMzQzIDMtMTA5MSA5LTE2NjMgMTItMTg3OSAxMS0xNzk5IDEwLTE5MjUgMjgtNTExIDc2LTkyNyAyNzYtMTI1NSA2MDMtNDkgNDktODYgODEtODMgNzN6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExMS4xOW1tIiBoZWlnaHQ9IjE0NC4zMm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTEuMTkgMTQ0LjMyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ny43MDMgLTc3LjEyNykiPjxyZWN0IHg9IjUwLjkwNSIgeT0iODUuNTEiIHdpZHRoPSIxMDQuNzkiIGhlaWdodD0iMjEuNDY5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iNi40MDUiLz48cGF0aCBkPSJtNjEuMDI5IDExMS45NXYxMDQuOThoODQuNTR2LTEwNC43MSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44IiBzdHJva2Utd2lkdGg9IjkuMDIzMSIvPjxnPjxyZWN0IHg9Ijc0LjgyMiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjkyLjA0OCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEwNy43NCIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9IjEyNC45NiIgeT0iMTE0Ljk3IiB3aWR0aD0iNi44MTM3IiBoZWlnaHQ9IjkyLjg2MiIvPjxyZWN0IHg9Ijg2LjQzNiIgeT0iNzcuMTI3IiB3aWR0aD0iMzMuNzI2IiBoZWlnaHQ9IjcuOTY4NiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.23585" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2MC4wN21tIiBoZWlnaHQ9IjEzNC40bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2MC4wNyAxMzQuNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQuMzgxIC03OS4wMjcpIj48Zz48cmVjdCB4PSIyNC4zODEiIHk9IjEzOC40NiIgd2lkdGg9IjE2MC4wNyIgaGVpZ2h0PSI3NC45NjEiLz48cmVjdCB4PSI5NC43OTQiIHk9IjEwMi45MiIgd2lkdGg9IjI1LjA0NiIgaGVpZ2h0PSI1OC40NDUiLz48cmVjdCB4PSIxMzEuNjIiIHk9Ijc5LjAyNyIgd2lkdGg9IjM0LjU0NiIgaGVpZ2h0PSI2NC4zODQiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Объект размещения отходов" value="602020401" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объект по обработке, утилизации, обезвреживанию отходов" value="602020402" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объект утилизации, уничтожения биологических отходов" value="602020403" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объект обращения с радиоактивными отходами" value="602020404" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Места несанкционированного размещения отходов производства и потребления" value="602020405" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иные объекты обращения с отходами" value="602020406" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ORO_NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ORO_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Хранение отходов" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Захоронение отходов" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ORO_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Полигон захоронения твердых коммунальных отходов" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Навозохранилище" value="10" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Пометохранилище" value="11" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Открытая площадка с грунтовым покрытием" value="12" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Открытая площадка с водонепроницаемым покрытием" value="13" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Крытая площадка (под навесом) с грунтовым покрытием" value="14" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Крытая площадка (под навесом) с водонепроницаемым покрытием" value="15" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Производственное помещение (или его часть)" value="16" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Полигон захоронения промышленных отходов" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Выработанная шахта, штольня, используемая для захоронения отходов" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Шламохранилище (кроме шламового амбара)" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Шламовый амбар" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Хвостохранилище" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Отвал горных пород, террикон" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Отработанный карьер, используемый для захоронения отходов" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Шлакозолоотвал" value="9" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Другой специально оборудованный объект хранения отходов" value="98" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Другой специально оборудованный объект захоронения отходов" value="99" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="RECYC_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Объект обработки отходов" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объект утилизации отходов" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты обезвреживания отходов в форме сжигания" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты обезвреживания отходов (за исключением сжигания)" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="BUR_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Скотомогильник с захоронением в яме" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Скотомогильник с биологическими камерами (Яма Беккари)" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Скотомогильник сибиреязвенный" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объект утилизации биологических отходов" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объект сжигания биологических отходов" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="WRK_COUNT" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="HZRD_CLASS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="I класс опасности объекта" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="II класс опасности объекта" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="III класс опасности объекта" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="IV класс опасности объекта" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="V класс опасности объекта" value="5" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="HZRD_CAT" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Объекты, оказывающие значительное негативное воздействие на окружающую среду и относящиеся к областям применения наилучших доступных технологий, - объекты I категории" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты, оказывающие умеренное негативное воздействие на окружающую среду, - объекты II категории" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты, оказывающие незначительное негативное воздействие на окружающую среду, - объекты III категории" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты, оказывающие минимальное негативное воздействие на окружающую среду, - объекты IV категории" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="DANGER_OBJ" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Объекты использования атомной энергии (в том числе ядерные установки, пункты хранения ядерных материалов и радиоактивных веществ, пункты хранения радиоактивных отходов)" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Тепловые электростанции мощностью 150 мегаватт и выше" value="10" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Подвесные канатные дороги" value="11" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасные производственные объекты I и II классов опасности, на которых получаются, используются, перерабатываются, образуются, хранятся, транспортируются, уничтожаются опасные вещества" value="12" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасные производственные объекты, на которых получаются, транспортируются, используются расплавы черных и цветных металлов, сплавы на основе этих расплавов с применением оборудования, рассчитанного на максимальное количество расплава 500 килограммов иболее" value="13" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасные производственные объекты, на которых ведутся горные работы (за исключением добычи общераспространенных полезных ископаемых и разработки россыпных месторождений полезных ископаемых, осуществляемых открытым способом без применения взрывных работ), работы по обогащению полезных ископаемых" value="14" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Антенно-мачтовое сооружение (АМС)" value="15" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Гидротехнические сооружения первого и второго классов, устанавливаемые в соответствии с законодательством о безопасности гидротехнических сооружений" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Сооружения связи, являющиеся особо опасными, технически сложными в соответствии с законодательством Российской Федерации в области связи" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Линии электропередачи и иные объекты электросетевого хозяйства напряжением 330 киловольт и более" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты космической инфраструктуры" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты инфраструктуры воздушного транспорта, являющиеся особо опасными, технически сложными объектами в соответствии с воздушным законодательством Российской Федерации" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты капитального строительства инфраструктуры железнодорожного транспорта общего пользования, являющиеся особо опасными, технически сложными объектами в соответствии с законодательством Российской Федерации о железнодорожном транспорте" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты инфраструктуры внеуличного транспорта" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Портовые гидротехнические сооружения, относящиеся к объектам инфраструктуры морского порта, за исключением объектов инфраструктуры морского порта, предназначенных для стоянок и обслуживания маломерных, спортивных парусных и прогулочных судов" value="9" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FUNCTION" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к ликвидации" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTROKS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTRZU" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAMEDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="DATEDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBERDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="ORO_NUMBER" index="6" name=""/>
    <alias field="ORO_TYPE" index="7" name=""/>
    <alias field="ORO_STYPE" index="8" name=""/>
    <alias field="RECYC_TYPE" index="9" name=""/>
    <alias field="BUR_TYPE" index="10" name=""/>
    <alias field="WRK_COUNT" index="11" name="Количество рабочих мест, единиц"/>
    <alias field="HZRD_CLASS" index="12" name="Класс опасности объекта в соответствии с санитарной классификацией"/>
    <alias field="HZRD_CAT" index="13" name="Категория объекта, оказывающего негативное воздействие на окружающую среду"/>
    <alias field="DANGER_OBJ" index="14" name="Критерии отнесения объекта к особо опасным и технически сложным объектам"/>
    <alias field="FUNCTION" index="15" name="Назначение объекта"/>
    <alias field="EVENT_TIME" index="16" name=""/>
    <alias field="SOURCE" index="17" name="Источник данных"/>
    <alias field="NOTE" index="18" name="Примечание"/>
    <alias field="STATUS" index="19" name="Статус объекта"/>
    <alias field="REG_STATUS" index="20" name="Значение объекта"/>
    <alias field="KADASTROKS" index="21" name="Кадастровый номер объекта капитального строительства"/>
    <alias field="KADASTRZU" index="22" name=""/>
    <alias field="NAMEDOCOSN" index="23" name=""/>
    <alias field="DATEDOCOSN" index="24" name=""/>
    <alias field="NUMBERDOCOSN" index="25" name=""/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602020401'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="ORO_NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="ORO_TYPE" expression="if(&quot;CLASSID&quot; = '602020401', attribute('ORO_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="ORO_STYPE" expression="if(&quot;CLASSID&quot; = '602020401', attribute('ORO_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="RECYC_TYPE" expression="if(&quot;CLASSID&quot; = '602020402', attribute('RECYC_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="BUR_TYPE" expression="if(&quot;CLASSID&quot; = '602020403', attribute('BUR_TYPE'), NULL)" applyOnUpdate="1"/>
    <default field="WRK_COUNT" expression="0" applyOnUpdate="0"/>
    <default field="HZRD_CLASS" expression="1" applyOnUpdate="0"/>
    <default field="HZRD_CAT" expression="" applyOnUpdate="0"/>
    <default field="DANGER_OBJ" expression="" applyOnUpdate="0"/>
    <default field="FUNCTION" expression="''" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
    <default field="KADASTROKS" expression="''" applyOnUpdate="0"/>
    <default field="KADASTRZU" expression="''" applyOnUpdate="0"/>
    <default field="NAMEDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="DATEDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="NUMBERDOCOSN" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="ORO_NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="ORO_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="ORO_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="RECYC_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="BUR_TYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="WRK_COUNT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="HZRD_CLASS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="HZRD_CAT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="DANGER_OBJ" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FUNCTION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="2" field="KADASTROKS" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="KADASTRZU" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAMEDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="DATEDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NUMBERDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="ORO_NUMBER" desc="Заполняется для объекта 602020401" exp="if (&quot;CLASSID&quot; = '602020401',&#xa;&#x9;length(&quot;ORO_NUMBER&quot;) > 0,&#xa;&#x9;length(&quot;ORO_NUMBER&quot;) >= 0)"/>
    <constraint field="ORO_TYPE" desc="Заполняется для объекта 602020401" exp="if(&quot;CLASSID&quot; = '602020401', &quot;ORO_TYPE&quot; IS NOT NULL, &quot;ORO_TYPE&quot; IS NULL)"/>
    <constraint field="ORO_STYPE" desc="Заполняется для объекта 602020401" exp="if(&quot;CLASSID&quot; = '602020401', &quot;ORO_STYPE&quot; IS NOT NULL, &quot;ORO_STYPE&quot; IS NULL)"/>
    <constraint field="RECYC_TYPE" desc="Заполняется для объекта 602020402" exp="if(&quot;CLASSID&quot; = '602020402', &quot;RECYC_TYPE&quot; IS NOT NULL, &quot;RECYC_TYPE&quot; IS NULL)"/>
    <constraint field="BUR_TYPE" desc="Заполняется для объекта 602020403" exp="if(&quot;CLASSID&quot; = '602020403', &quot;BUR_TYPE&quot; IS NOT NULL, &quot;BUR_TYPE&quot; IS NULL)"/>
    <constraint field="WRK_COUNT" desc="" exp=""/>
    <constraint field="HZRD_CLASS" desc="" exp=""/>
    <constraint field="HZRD_CAT" desc="" exp=""/>
    <constraint field="DANGER_OBJ" desc="" exp=""/>
    <constraint field="FUNCTION" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
    <constraint field="KADASTROKS" desc="Кадастровый номер объекта должен соответствовать формату, принятому в ЕГРН" exp="regexp_match(&quot;KADASTROKS&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$')"/>
    <constraint field="KADASTRZU" desc="Обязательно для значений атрибута &quot;STATUS&quot; 1, 3, 4" exp="if (&quot;STATUS&quot; = 1 OR &quot;STATUS&quot; = 3 OR &quot;STATUS&quot; = 4,&#xd;&#xa;&#x9;regexp_match(&quot;KADASTRZU&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$|^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1})$'),&#xd;&#xa;&#x9;length(&quot;KADASTRZU&quot;) >= 0)"/>
    <constraint field="NAMEDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NAMEDOCOSN&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NAMEDOCOSN&quot;) >= 0)"/>
    <constraint field="DATEDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3. Формат даты (ДД.ММ.ГГГГ)." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;regexp_match(&quot;DATEDOCOSN&quot;, '^\\d{2}\\.\\d{2}\\.\\d{4}$'),&#xd;&#xa;&#x9;length(&quot;DATEDOCOSN&quot;) >= 0)"/>
    <constraint field="NUMBERDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NUMBERDOCOSN&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NUMBERDOCOSN&quot;) >= 0)"/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="12" name="HZRD_CLASS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="19" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="20" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="11" name="WRK_COUNT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="HZRD_CAT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="14" name="DANGER_OBJ">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="15" name="FUNCTION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="17" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="18" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="21" name="KADASTROKS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Учетный номер объекта размещения отходов" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602020401'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="6" name="ORO_NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Назначение объекта размещения отходов" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602020401'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="7" name="ORO_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Вид объекта размещения отходов" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602020401'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="8" name="ORO_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Вид объекта по обработке, утилизации, обезвреживанию отходов" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602020402'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="9" name="RECYC_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Вид объекта утилизации, уничтожения биологических отходов" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602020403'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="10" name="BUR_TYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="16" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Кадастровый номер земельного участка и (или) номер кадастрового квартала, в границах которого расположен объект" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (1, 3, 4)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="22" name="KADASTRZU">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Наименование документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="23" name="NAMEDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Дата документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="24" name="DATEDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="25" name="NUMBERDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="BUR_TYPE" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="DANGER_OBJ" editable="1"/>
    <field name="DATEDOCOSN" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="FUNCTION" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="HZRD_CAT" editable="1"/>
    <field name="HZRD_CLASS" editable="1"/>
    <field name="KADASTROKS" editable="1"/>
    <field name="KADASTRZU" editable="1"/>
    <field name="NAME" editable="1"/>
    <field name="NAMEDOCOSN" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="NUMBERDOCOSN" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="ORO_NUMBER" editable="1"/>
    <field name="ORO_STYPE" editable="1"/>
    <field name="ORO_TYPE" editable="1"/>
    <field name="RECYC_TYPE" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="WRK_COUNT" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="BUR_TYPE"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="DANGER_OBJ"/>
    <field labelOnTop="1" name="DATEDOCOSN"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="FUNCTION"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="HZRD_CAT"/>
    <field labelOnTop="1" name="HZRD_CLASS"/>
    <field labelOnTop="1" name="KADASTROKS"/>
    <field labelOnTop="1" name="KADASTRZU"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NAMEDOCOSN"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="NUMBERDOCOSN"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="ORO_NUMBER"/>
    <field labelOnTop="1" name="ORO_STYPE"/>
    <field labelOnTop="1" name="ORO_TYPE"/>
    <field labelOnTop="1" name="RECYC_TYPE"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS"/>
    <field labelOnTop="1" name="WRK_COUNT"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="BUR_TYPE" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="DANGER_OBJ" reuseLastValue="0"/>
    <field name="DATEDOCOSN" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="FUNCTION" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="HZRD_CAT" reuseLastValue="0"/>
    <field name="HZRD_CLASS" reuseLastValue="0"/>
    <field name="KADASTROKS" reuseLastValue="0"/>
    <field name="KADASTRZU" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NAMEDOCOSN" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="NUMBERDOCOSN" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="ORO_NUMBER" reuseLastValue="0"/>
    <field name="ORO_STYPE" reuseLastValue="0"/>
    <field name="ORO_TYPE" reuseLastValue="0"/>
    <field name="RECYC_TYPE" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="WRK_COUNT" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
