<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{cea0dd59-7054-44e5-8fec-9d2da313938b}">
      <rule label="Территории, подверженные риску возникновения чрезвычайных ситуаций техногенного характера" filter="&quot;CLASSID&quot; = '606010201'" symbol="0" key="{9f03cdfb-fefe-44ef-85fe-3b1993028253}"/>
      <rule label="Зона, подверженная риску радиоактивного загрязнения" filter="&quot;CLASSID&quot; = '606010202'" symbol="1" key="{7b559bca-0e9f-4e5c-9830-cb4155b18dd8}"/>
      <rule label="Зона, подверженная риску химического заажения" filter="&quot;CLASSID&quot; = '606010203'" symbol="2" key="{6eb94d49-6619-48de-a925-0ade6425037e}"/>
      <rule label="Зона возможного катастрофического затопления (при аварии на гидродинамически опасном объекте)" filter="&quot;CLASSID&quot; = '606010204'" symbol="3" key="{d9ecf6d2-14dd-4ae0-89f3-9dad2e7596f8}"/>
      <rule label="Зона локального загрязнения почв" filter="&quot;CLASSID&quot; = '606010206'" symbol="4" key="{a2765573-00f7-4aac-8b71-4b84cedd35c9}"/>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="145,82,45,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9Ijk0Ljk0Nm1tIiBoZWlnaHQ9IjY2LjU4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDk0Ljk0NiA2Ni41OCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUuNDY4IC0yNC4yMzUpIj48cGF0aCBkPSJtNzEuNDk5IDg4LjczMmg2My41ODZsMTIuMDExLTE0LjA3Mi04LjIyMzEgMy40NDQ1IDEuNjAwMi00LjU2NzctNi4yNjE4IDEuNzcxOCAxNC4xMjEtMzIuMDQzLTI1Ljg5NSAyNS43OTMtMS4zOTAxLTExLjY2Ni0xMC4yNzYgMTkuMjItMC45MjUzNC0zMS4xNTgtOC41MDcgMTcuMjg1LTIxLjMzOS0zNi40MjQgMy40MiAzOS45MzgtOS42NjItNi4zNjQyLTAuNDE0NzQgMTguNTg5LTE1Ljc5NC0xMC44NTd6IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSI0LjE2NSIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="145,82,45,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2Mi42N21tIiBoZWlnaHQ9IjE1My4xbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE2Mi42NyAxNTMuMSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Zz48cGF0aCBkPSJtMTQ4LjI3IDEyOC4yYy01LjUxNjQgNy44Njg0LTEzLjEyMSAxNS4yOTctMjEuMjUgMjAuNzU4bC00LjI4MjMgMi44NzctMy40NjM5LTYuMDMzM2MtMS45MDUxLTMuMzE4My03LjkyOTQtMTMuODAzLTEzLjM4Ny0yMy4yOTktNS40NTc4LTkuNDk1OS0xMC4wODEtMTcuNjMyLTEwLjI3My0xOC4wOC0wLjMyODAxLTAuNzY1MjEtMC4yMDUyMi0wLjkzNDUgMi4wMDg2LTIuNzY4OSA0LjU0LTMuNzYxOSA3LjY0NTYtOS44MjE3IDcuOTU3My0xNS41MjdsMC4xMTYwNy0yLjEyNDQgNTYuOTY1IDAuMDQ2MzMtMC4yMDE1NSAzLjUwNTljLTAuNzkxODcgMTMuNzc0LTYuMTg4OSAyOS4yMzMtMTQuMTg5IDQwLjY0NXptLTExMC41OCAyMS43OTljLTE3LjY4OC0xMS4zNy0yOS43MTQtMjcuNjQxLTM0Ljk3NC00Ny4zMjMtMS45NTgyLTcuMzI2Ni0zLjM4MjQtMTguMzg4LTIuNC0xOC42NDEgMC4yNDY1My0wLjA2MzU0NiAxMy45NzgtMC4xMTU5NCAzMC41MTUtMC4xMTY0MmwzMC4wNjctOC44NmUtNCAwLjA2ODg1IDEuMTI0MWMwLjI1MTQ3IDQuMTA1NCAxLjc0MzMgOC42OTAyIDMuODQ1IDExLjgxNiAxLjQ0MzkgMi4xNDc4IDQuMzE2NSA1LjE1NzUgNS42NjY3IDUuOTM3bDAuODEzMzkgMC40Njk2MS0yOC43NzQgNDkuODM4em01NC41MTgtODYuMDM4Yy0yLjk0OTEtMS4xMjIyLTcuMjM4Mi0xLjg2NTQtOS45MzU4LTEuNzIxNS0yLjY3MiAwLjE0MjUtNy4yMzI5IDEuMjkyOS04Ljc4MiAyLjIxNTItMC42NDc0NSAwLjM4NTQ2LTAuODI4MTEgMC4zMTkyMS0xLjM0Mi0wLjQ5MjA5LTAuOTQyMTQtMS40ODc1LTMwLjczNi01Mi44NjUtMzAuODI1LTUzLjE1Ni0wLjI4NTQxLTAuOTMzMTMgMTAuNDM4LTUuNTc2MiAxNy41OTktNy42MjAyIDkuOTA2Ni0yLjgyNzYgMTguNDczLTMuNjk1NSAyOC43MzItMi45MTA5IDExLjYwOCAwLjg4Nzk1IDI0LjExOSA0LjY0MzIgMzMuNDg3IDEwLjA1MmwyLjg1NTYgMS42NDg3LTMwLjMzMyA1Mi41Mzh6IiBzdHJva2Utd2lkdGg9Ii40MSIvPjxjaXJjbGUgY3g9IjgzLjI5OCIgY3k9Ijg0LjI3MyIgcj0iMTguOTcxIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIuNDAzNjEiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="145,82,45,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEwMy41OW1tIiBoZWlnaHQ9IjEwMi45M21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMDMuNTkgMTAyLjkzIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTEuNDYxIC0xMi40NDMpIj48cGF0aCB0cmFuc2Zvcm09Im1hdHJpeCgxLjU3MzggMCAwIDEuNTYzOSAtMTYuNTUyIDI3LjU0OCkiIGQ9Im03Ni4xMjYgNTQuODEtMzEuNTU4LTMxLjU1OCAzMS41NTgtMzEuNTU4IDMxLjU1OCAzMS41NTh6IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAyMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxLjkxMjIiLz48cGF0aCBkPSJtNTMuNTg5IDYzLjkxMWg5OS4zMzQiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIzIi8+PGcgc3Ryb2tlPSIjMDAwIj48Y2lyY2xlIGN4PSIyNDguMjkiIGN5PSIzOS40ODkiIHI9Ii4wNTUwNDciIHN0cm9rZS13aWR0aD0iLjI2NDU4Ii8+PGNpcmNsZSBjeD0iMjUxLjM2IiBjeT0iMTA2LjM3IiByPSIuMDU1MDQ3IiBzdHJva2Utd2lkdGg9Ii4yNjQ1OCIvPjxnIHN0cm9rZS13aWR0aD0iLjI2NDU4cHgiPjxwYXRoIGQ9Im02Ni42OTEgNjMuOTExdi0xMS44NzNsMTMuMTQzLTE0LjQ5NXYyNi40MDJsLTEzLjE0My0wLjAzNDU1NCIvPjxwYXRoIGQ9Im04MS44MzQgNjMuOTExdi0yNy4wNDlsMTMuMTQzLTEyLjc3M3YzOS44NTdsLTEzLjE0My0wLjAzNDU1Ii8+PHBhdGggZD0ibTE0MC40MSA2My45MTF2LTExLjg3M2wtMTMuMTQzLTE0LjQ5NXYyNi40MDJsMTMuMTQzLTAuMDM0NTUiLz48cGF0aCBkPSJtMTI1LjI2IDYzLjkxMXYtMjcuMDQ5bC0xMy4xNDMtMTIuNzczdjM5Ljg1N2wxMy4xNDMtMC4wMzQ1NSIvPjxwYXRoIGQ9Im05Ni45NzcgNjQuMDc2di00Mi40NTZsNi4yNzk5LTcuNDA4OSA2Ljg2MzEgNy42MTI0djQyLjE0MXoiLz48cGF0aCBkPSJtNTMuNTg5IDYzLjkxMWgxMS4xMDF2LTExLjgxN2wtMTEuMDYzIDExLjg1NiIvPjxwYXRoIGQ9Im0xNTMuNTEgNjMuOTExaC0xMS4xMDF2LTExLjgxN2wxMS4wNjMgMTEuODU2Ii8+PC9nPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="145,82,45,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjkwLjY0bW0iIGhlaWdodD0iNzcuNTU1bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDkwLjY0IDc3LjU1NSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNjAuNjcgLTI0LjExMikiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuMjY5MDFweCI+PHBhdGggZD0ibTYxLjU4NyAzOC41OTZzOC45NDkxLTEzLjg5NiAxNi4yNzMtMTQuMzM3YzguNDUwNC0wLjUwODY2IDEyLjMwNCAxMy42MzIgMjAuNzUzIDE0LjE2MyA1LjYwNTkgMC4zNTE4MyAxNC45MS03LjU5NjkgMTQuOTEtNy41OTY5cy05LjQxMjkgMTMuOTk2LTE2LjkxOCAxNC40MjJjLTcuNDAyMSAwLjQxOTQ4LTEwLjk0NC0xMS4yNjgtMTguMjktMTIuMjQyLTUuODQ0OC0wLjc3NTI2LTE2LjcyNyA1LjU5MTYtMTYuNzI3IDUuNTkxNnoiLz48cGF0aCBkPSJtOTkuMjYyIDY3LjIxNnM4Ljk0OTEtMTMuODk2IDE2LjI3My0xNC4zMzdjOC40NTA0LTAuNTA4NjYgMTIuMzA0IDEzLjYzMiAyMC43NTMgMTQuMTYzIDUuNjA1OSAwLjM1MTgzIDE0LjkxLTcuNTk2OSAxNC45MS03LjU5NjlzLTkuNDEyOSAxMy45OTYtMTYuOTE4IDE0LjQyMmMtNy40MDIxIDAuNDE5NDgtMTAuOTQ0LTExLjI2OC0xOC4yOS0xMi4yNDItNS44NDQ4LTAuNzc1MjYtMTYuNzI3IDUuNTkxNi0xNi43MjcgNS41OTE2eiIvPjxwYXRoIGQ9Im02MC43ODMgOTQuODdzOC45NDkxLTEzLjg5NiAxNi4yNzMtMTQuMzM3YzguNDUwNC0wLjUwODY2IDEyLjMwNCAxMy42MzIgMjAuNzUzIDE0LjE2MyA1LjYwNTkgMC4zNTE4MyAxNC45MS03LjU5NjkgMTQuOTEtNy41OTY5cy05LjQxMjkgMTMuOTk2LTE2LjkxOCAxNC40MjJjLTcuNDAyMSAwLjQxOTQ4LTEwLjk0NC0xMS4yNjgtMTguMjktMTIuMjQyLTUuODQ0OC0wLjc3NTI2LTE2LjcyNyA1LjU5MTYtMTYuNzI3IDUuNTkxNnoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.4" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="145,82,45,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE3Ljg4bW0iIGhlaWdodD0iMTI5Ljk4bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNy44OCAxMjkuOTgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ4LjA5OSAtNzQuMzg5KSI+PHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoNDUpIiBkPSJtMTI3LjA1LTIxLjg0M3YyLjg2N2w4OS4wNDIgODkuMDQyaDIuODY3di03LjgzOGwtODQuMDcxLTg0LjA3MXptMCAxOC4xNjF2MTAuNzA2bDYzLjA0MiA2My4wNDJoMTAuNzA2em0yMy4xMzItMTguMTYxIDY4Ljc3NiA2OC43NzZ2LTEwLjcwNmwtNTguMDcxLTU4LjA3MXptLTIzLjEzMiA0NC4xNjJ2MTAuNzA1bDM3LjA0MiAzNy4wNDJoMTAuNzA1em00OS4xMzMtNDQuMTYyIDQyLjc3NiA0Mi43NzZ2LTEwLjcwNmwtMzIuMDctMzIuMDd6bS00OS4xMzMgNzAuMTYxdjEwLjcwNmwxMS4wNDIgMTEuMDQyaDEwLjcwNnptNzUuMTMzLTcwLjE2MSAxNi43NzYgMTYuNzc2di0xMC43MDVsLTYuMDcwOS02LjA3MDl6IiBzdHJva2UtbWl0ZXJsaW1pdD0iMi4xIiBzdHJva2Utd2lkdGg9IjEuNDEzMyIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.89731" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Территории, подверженные риску возникновения чрезвычайных ситуаций техногенного характера" value="606010201" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Зона, подверженная риску радиоактивного загрязнения" value="606010202" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Зона, подверженная риску химического заражения" value="606010203" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Зона возможного катастрофического затопления (при аварии на гидродинамически опасном объекте)" value="606010204" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="TM_SOURCE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Промышленная авария (катастрофа)" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасное происшествие на транспорте" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Пожар (взрыв)" value="3" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="IND_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Радиационная авария" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Авария на подземном сооружении" value="10" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Химическая авария" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Биологическая авария" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Гидродинамическая авария" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Пожар, взрыв" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Авария электроэнергетической системы, системы связи" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Авария коммунальной системы жизнеобеспечения" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Транспортная авария" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Авария на магистральном трубопроводе" value="9" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="RAD_CLASS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Умеренного" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Сильного" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасного" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Чрезвычайно-опасного" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EME_CLASS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Локального характера" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Муниципального характера" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Межмуниципального характера" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Регионального характера" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Межрегионального характера" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Федерального характера" value="6" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OTHER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="TM_SOURCE" index="2" name="Источник техногенной чрезвычайной ситуации"/>
    <alias field="IND_TYPE" index="3" name="Вид техногенной аварии"/>
    <alias field="RAD_CLASS" index="4" name="Степень возможного радиоактивного загрязнения"/>
    <alias field="EME_CLASS" index="5" name="Классификация чрезвычайной ситуации"/>
    <alias field="OTHER" index="6" name="Иной параметр и его единицы измерения"/>
    <alias field="NOTE" index="7" name="Примечание"/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'606010201'" applyOnUpdate="0"/>
    <default field="TM_SOURCE" expression="1" applyOnUpdate="0"/>
    <default field="IND_TYPE" expression="1" applyOnUpdate="0"/>
    <default field="RAD_CLASS" expression="" applyOnUpdate="0"/>
    <default field="EME_CLASS" expression="1" applyOnUpdate="0"/>
    <default field="OTHER" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="TM_SOURCE" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="IND_TYPE" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="RAD_CLASS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="EME_CLASS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="OTHER" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="TM_SOURCE" desc="" exp=""/>
    <constraint field="IND_TYPE" desc="" exp=""/>
    <constraint field="RAD_CLASS" desc="" exp=""/>
    <constraint field="EME_CLASS" desc="" exp=""/>
    <constraint field="OTHER" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="2" name="TM_SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="IND_TYPE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="5" name="EME_CLASS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="4" name="RAD_CLASS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="6" name="OTHER">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="7" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="CLASSID" editable="1"/>
    <field name="EME_CLASS" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="IND_TYPE" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="OTHER" editable="1"/>
    <field name="RAD_CLASS" editable="1"/>
    <field name="TM_SOURCE" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="EME_CLASS"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="IND_TYPE"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="OTHER"/>
    <field labelOnTop="1" name="RAD_CLASS"/>
    <field labelOnTop="1" name="TM_SOURCE"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="EME_CLASS" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="IND_TYPE" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="OTHER" reuseLastValue="0"/>
    <field name="RAD_CLASS" reuseLastValue="0"/>
    <field name="TM_SOURCE" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
