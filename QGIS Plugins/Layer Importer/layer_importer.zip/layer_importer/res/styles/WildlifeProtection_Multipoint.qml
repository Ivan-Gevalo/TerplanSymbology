<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{5dfe8f5c-6e37-4202-bbce-959a0cceb316}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{d3ac5186-db3f-4c2e-aab9-f9c01befd93b}">
        <rule label="Центры реабилитации животных" filter="&quot;CLASSID&quot; = '602050501'" symbol="1" key="{e619f4d9-5754-4b3f-85ed-e2c2a72acbb5}"/>
        <rule label="Зверопереходы (экодуки)" filter="&quot;CLASSID&quot; = '602050502'" symbol="2" key="{7d816550-ef04-4c8d-8784-dc48d1e487b5}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="3" key="{ceba4da1-5e08-44af-a681-0b0c1ad9b0c8}">
        <rule label="Центры реабилитации животных" filter="&quot;CLASSID&quot; = '602050501'" symbol="4" key="{218f609f-6db2-4152-9b24-7bdddbd41e91}"/>
        <rule label="Зверопереходы (экодуки)" filter="&quot;CLASSID&quot; = '602050502'" symbol="5" key="{743d99fd-c706-40d0-a9c7-715efa14e35d}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="6" key="{9898ac4f-ee02-4f80-947f-3c072524ab87}">
        <rule label="Центры реабилитации животных" filter="&quot;CLASSID&quot; = '602050501'" symbol="7" key="{f678990e-d36f-46ac-8b28-7c3f0fa184ba}"/>
        <rule label="Зверопереходы (экодуки)" filter="&quot;CLASSID&quot; = '602050502'" symbol="8" key="{eb52de8b-6bf1-46cc-af40-fd9103b12886}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="9" key="{528d675c-ba4a-462a-bce7-d691e2ff78b5}">
        <rule label="Центры реабилитации животных" filter="&quot;CLASSID&quot; = '602050501'" symbol="10" key="{2f596efd-a760-4999-a4c0-bd6d5b71c834}"/>
        <rule label="Зверопереходы (экодуки)" filter="&quot;CLASSID&quot; = '602050502'" symbol="11" key="{7380fdb7-43ea-4b68-a133-8a5a31e96d82}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="12" key="{2ac0e2f5-217c-43ad-b624-c0d0dc2febc6}">
        <rule label="Центры реабилитации животных" filter="&quot;CLASSID&quot; = '602050501'" symbol="13" key="{08f1c41a-88b8-4c96-83ba-b80393415be8}"/>
        <rule label="Зверопереходы (экодуки)" filter="&quot;CLASSID&quot; = '602050502'" symbol="14" key="{ba13f25d-b945-4722-9008-cd401d68dab1}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="15" key="{b7aac316-2c2c-4200-bf32-707772a70787}">
        <rule label="Центры реабилитации животных" filter="&quot;CLASSID&quot; = '602050501'" symbol="16" key="{af949c5e-8ada-4170-8d81-6c1c549a0aab}"/>
        <rule label="Зверопереходы (экодуки)" filter="&quot;CLASSID&quot; = '602050502'" symbol="17" key="{c9b4f160-2222-4333-b1a7-ab24bce4aa28}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="18" key="{b9888876-fc81-4de6-84a5-c0fca5bce148}">
        <rule label="Центры реабилитации животных" filter="&quot;CLASSID&quot; = '602050501'" symbol="19" key="{82ffd471-0e9c-4823-8138-6b2a31003579}"/>
        <rule label="Зверопереходы (экодуки)" filter="&quot;CLASSID&quot; = '602050502'" symbol="20" key="{285e8bb9-1355-4b6c-b156-ab1c65935c5e}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты регионального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 2" symbol="21" key="{af19793c-eef2-4437-9244-1f03504b85fc}">
        <rule label="Центры реабилитации животных" filter="&quot;CLASSID&quot; = '602050501'" symbol="22" key="{57f9064d-b084-459d-b280-99213bd1c7da}"/>
        <rule label="Зверопереходы (экодуки)" filter="&quot;CLASSID&quot; = '602050502'" symbol="23" key="{18749761-ec68-4871-b9c4-6f21d7f7e123}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="24" key="{1b6d61dc-64bf-4bb6-9073-4ca51f04f9df}">
        <rule label="Центры реабилитации животных" filter="&quot;CLASSID&quot; = '602050501'" symbol="25" key="{464a303b-ddcf-4c7f-8719-7bd9ce857321}"/>
        <rule label="Зверопереходы (экодуки)" filter="&quot;CLASSID&quot; = '602050502'" symbol="26" key="{4b0eccad-e004-4c74-a98e-14a64e89d652}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="27" key="{244f5b50-bf5c-41f7-ba27-2db501c21d16}">
        <rule label="Центры реабилитации животных" filter="&quot;CLASSID&quot; = '602050501'" symbol="28" key="{37bdaa96-a90f-4d3a-9e96-9a52b2fb8d06}"/>
        <rule label="Зверопереходы (экодуки)" filter="&quot;CLASSID&quot; = '602050502'" symbol="29" key="{2d596b38-4563-4e3e-9625-0f645bccf58a}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="30" key="{387ba21b-10b5-4e08-b9d0-19c967f4d193}">
        <rule label="Центры реабилитации животных" filter="&quot;CLASSID&quot; = '602050501'" symbol="31" key="{ec27ea30-1f16-45d9-b900-acfaffcac6d0}"/>
        <rule label="Зверопереходы (экодуки)" filter="&quot;CLASSID&quot; = '602050502'" symbol="32" key="{44fedd4a-fa82-413f-bfe8-f7d9ca056a21}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты федерального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 1" symbol="33" key="{be477d94-31c5-4371-82a5-51a7a229e21d}">
        <rule label="Центры реабилитации животных" filter="&quot;CLASSID&quot; = '602050501'" symbol="34" key="{a40225e4-519f-4201-b789-2822abe2ca9b}"/>
        <rule label="Зверопереходы (экодуки)" filter="&quot;CLASSID&quot; = '602050502'" symbol="35" key="{331459be-0a38-42cd-9575-c40be4290e9b}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="213,180,60,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yNW1tIiBoZWlnaHQ9IjE1My42MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODIuMjUgMTUzLjYxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC4xNDggLTcwLjY0MikiPjxwYXRoIGQ9Im0yMC4yMTcgMjIyLjM0Yy0xMC45NzYtMy4zOTc3LTUuMTM4MS0xNi4yMjQgMi4zODM2LTE5Ljg2IDguNzQ3LTUuNzcwOCAxOC42MDggMC41MzQyNiAyNy41MjgtMi4zMjAzIDguMjQ3Mi0xLjk5NzUgMTguMjQzLTEyLjA4OCA3LjMwOTgtMTcuOTc0LTYuMzYwOC00LjgyMzYtMTUuMDI3LTguNzkzNS0xNi43ODMtMTcuNDU4IDAuMjI1MTgtMTAuMDA0LTMuNjQ4Ni0xOS45NDMtMTMuMTktMjQuNDc3LTQuNTAzOS04LjU2MzEtMy4xOTEyLTE4LjgxMS01LjY3MTItMjguMDA0LTEuMDgtMTAuNjA1IDAuNTAxMTktMjEuMDYyIDIuMTA0LTMxLjQ4NyAxLjAxNDItMTMuMDg0IDE0LjM1LTQuMzgyOSAxOS41OTYgMC45MzIwOSA2LjgwMDkgNi44MTk1IDEyLjEwOSAxNS4xNDEgMTguNTk3IDIyLjM4OSA1LjIzODYgOC43NDI0IDEzLjc3NyAxNC4wMTYgMjIuNDI2IDE4Ljg4IDEwLjcyNyA2LjA3NDIgMTcuNzY3IDE1LjYxNiAyNS4yMjggMjUuMDYzIDEuMTg0IDEuMjk1MSAxLjE1ODEgMi44NDQ3IDEuNTE2NCAzLjE2NTkgMC4yNTI3NyAwLjIyNjU5IDEuMzA0NSAxLjE2MzUgMS44MzM5IDAuODgwODUgMy4wMTM1LTEuOTI4NCA4LjA5NS0xMS44MDIgMTAuMzk2LTE0Ljc2NSA3LjQwODgtMTEuMzc1IDEzLjYwNi0yMy41MDggMjAuOTc1LTM0LjkxOSA1LjMwNjctOS4yMjM3IDEwLjgwMi0xOC40NjQgMTguNzk1LTI1LjY1NyA4LjY1MzgtMTAuNDc2IDE1LjUyLTUuODA4NyAxNy45MjkgMS44Nzg2IDMuMDQyIDkuNzA3OCAxMy4xODYgMTQuMDY4IDExLjA5MiAyNC4yNSAwLjM2MzE2IDkuODU0Ni0wLjE1OTQ0IDIxLjQxMy05LjE3MjcgMjcuNTgtNy4xMzUxIDcuMTAwMS0xOC4wMDkgOS41MDUzLTIzLjk5MSAxNy43NDgtMS42MzI0IDQuODIzLTkuNTY2MyAxOC43NDYtMy42Mjg0IDIxLjkzMyA1LjI5MTgtMC43NDE5OSA3LjY4ODQtNS44NzUyIDExLjc0MS01Ljk5ODggNS4wMDcyIDAgNy4wOTk0LTFlLTUgMTIuMDEyIDAuNzMzMDYgNS44MjIzIDAuODY4NzggMTEuOTY5IDMuODM5MiAxMy43NTcgOC4xODcyIDAuOTY2MDQgMi4zNDk2IDMuMjA2NSA5LjQ5ODggMy4zNTUzIDEyLjY4NSAwLjA5MTggMS45NjY4IDAuMjY0NDkgMy4xMTkxLTIuMDU2NSA0LjIzNy0yLjk4IDEuNDM1My0xNi4wMzggMC4yNjI4OS0xOC4yMy0wLjM3NjU3LTcuOTM4My0yLjMxNS04LjgwOC00LjQ4NDItMTYuMTQ1IDAuMjUwNi03LjkxMDYgNS43ODU0LTE2Ljg1MSAxMS4zMzctMjYuNDIgMTQuMjYxLTE5LjU1IDYuNTg5NS00MC40NTkgMTEuMDkyLTU5LjY1MSAxMC4zMi01Ljk2MzgtMC4yNjQzNC0xMi4zNzQtMS4zNTA0LTE4LjU3IDAuNzgzMjQtMi45NzE4IDEuMDIzNS02LjcwNyA0LjcyOTktOS40NjA4IDYuNDIwOC02LjgzMSAzLjYzMTgtMTQuODUzIDIuNDQ0LTIyLjMzNSAyLjQ2ODMtMS4yMzYgNGUtMyAtMi4xNzk5LTEuMTY1Ni0zLjI2OTgtMS43NDg0eiIgc3Ryb2tlLXdpZHRoPSIuNTUyNjMiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yNW1tIiBoZWlnaHQ9IjE1My42MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODIuMjUgMTUzLjYxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC4xNDggLTcwLjY0MikiPjxwYXRoIGQ9Im0yMC4yMTcgMjIyLjM0Yy0xMC45NzYtMy4zOTc3LTUuMTM4MS0xNi4yMjQgMi4zODM2LTE5Ljg2IDguNzQ3LTUuNzcwOCAxOC42MDggMC41MzQyNiAyNy41MjgtMi4zMjAzIDguMjQ3Mi0xLjk5NzUgMTguMjQzLTEyLjA4OCA3LjMwOTgtMTcuOTc0LTYuMzYwOC00LjgyMzYtMTUuMDI3LTguNzkzNS0xNi43ODMtMTcuNDU4IDAuMjI1MTgtMTAuMDA0LTMuNjQ4Ni0xOS45NDMtMTMuMTktMjQuNDc3LTQuNTAzOS04LjU2MzEtMy4xOTEyLTE4LjgxMS01LjY3MTItMjguMDA0LTEuMDgtMTAuNjA1IDAuNTAxMTktMjEuMDYyIDIuMTA0LTMxLjQ4NyAxLjAxNDItMTMuMDg0IDE0LjM1LTQuMzgyOSAxOS41OTYgMC45MzIwOSA2LjgwMDkgNi44MTk1IDEyLjEwOSAxNS4xNDEgMTguNTk3IDIyLjM4OSA1LjIzODYgOC43NDI0IDEzLjc3NyAxNC4wMTYgMjIuNDI2IDE4Ljg4IDEwLjcyNyA2LjA3NDIgMTcuNzY3IDE1LjYxNiAyNS4yMjggMjUuMDYzIDEuMTg0IDEuMjk1MSAxLjE1ODEgMi44NDQ3IDEuNTE2NCAzLjE2NTkgMC4yNTI3NyAwLjIyNjU5IDEuMzA0NSAxLjE2MzUgMS44MzM5IDAuODgwODUgMy4wMTM1LTEuOTI4NCA4LjA5NS0xMS44MDIgMTAuMzk2LTE0Ljc2NSA3LjQwODgtMTEuMzc1IDEzLjYwNi0yMy41MDggMjAuOTc1LTM0LjkxOSA1LjMwNjctOS4yMjM3IDEwLjgwMi0xOC40NjQgMTguNzk1LTI1LjY1NyA4LjY1MzgtMTAuNDc2IDE1LjUyLTUuODA4NyAxNy45MjkgMS44Nzg2IDMuMDQyIDkuNzA3OCAxMy4xODYgMTQuMDY4IDExLjA5MiAyNC4yNSAwLjM2MzE2IDkuODU0Ni0wLjE1OTQ0IDIxLjQxMy05LjE3MjcgMjcuNTgtNy4xMzUxIDcuMTAwMS0xOC4wMDkgOS41MDUzLTIzLjk5MSAxNy43NDgtMS42MzI0IDQuODIzLTkuNTY2MyAxOC43NDYtMy42Mjg0IDIxLjkzMyA1LjI5MTgtMC43NDE5OSA3LjY4ODQtNS44NzUyIDExLjc0MS01Ljk5ODggNS4wMDcyIDAgNy4wOTk0LTFlLTUgMTIuMDEyIDAuNzMzMDYgNS44MjIzIDAuODY4NzggMTEuOTY5IDMuODM5MiAxMy43NTcgOC4xODcyIDAuOTY2MDQgMi4zNDk2IDMuMjA2NSA5LjQ5ODggMy4zNTUzIDEyLjY4NSAwLjA5MTggMS45NjY4IDAuMjY0NDkgMy4xMTkxLTIuMDU2NSA0LjIzNy0yLjk4IDEuNDM1My0xNi4wMzggMC4yNjI4OS0xOC4yMy0wLjM3NjU3LTcuOTM4My0yLjMxNS04LjgwOC00LjQ4NDItMTYuMTQ1IDAuMjUwNi03LjkxMDYgNS43ODU0LTE2Ljg1MSAxMS4zMzctMjYuNDIgMTQuMjYxLTE5LjU1IDYuNTg5NS00MC40NTkgMTEuMDkyLTU5LjY1MSAxMC4zMi01Ljk2MzgtMC4yNjQzNC0xMi4zNzQtMS4zNTA0LTE4LjU3IDAuNzgzMjQtMi45NzE4IDEuMDIzNS02LjcwNyA0LjcyOTktOS40NjA4IDYuNDIwOC02LjgzMSAzLjYzMTgtMTQuODUzIDIuNDQ0LTIyLjMzNSAyLjQ2ODMtMS4yMzYgNGUtMyAtMi4xNzk5LTEuMTY1Ni0zLjI2OTgtMS43NDg0eiIgc3Ryb2tlLXdpZHRoPSIuNTUyNjMiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0MC41Nm1tIiBoZWlnaHQ9IjE0My42bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0MC41NiAxNDMuNiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDUuODc2IC03Mi4wMTQpIj48Zz48ZWxsaXBzZSB0cmFuc2Zvcm09Im1hdHJpeCguNjAxNjYgLS43OTg3NSAuNjg2OCAuNzI2ODUgMCAwKSIgY3g9Ii00NC43ODUiIGN5PSIxMzcuOSIgcng9IjIxLjQ0IiByeT0iMjUuNzU0Ii8+PGVsbGlwc2UgdHJhbnNmb3JtPSJtYXRyaXgoLjY1MTI0IC0uNzU4ODcgLjUzMDU4IC44NDc2MyAwIDApIiBjeD0iMzAuOTMiIGN5PSIxNDYuODgiIHJ4PSIyMi4zNCIgcnk9IjI3Ljc3NSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45NTUzNCAtLjI5NTUxIC0uMDA5MzMwMiAuOTk5OTYgMCAwKSIgY3g9IjE0OC4wMyIgY3k9IjE0Ni41NSIgcng9IjIwLjk3NyIgcnk9IjI2LjcwOSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45OTgzOSAtLjA1NjY1NCAtLjI2MzU4IC45NjQ2NCAwIDApIiBjeD0iMjA3LjgzIiBjeT0iMTU5Ljc5IiByeD0iMjAuMTI1IiByeT0iMjMuODkiLz48cGF0aCBkPSJtMTE2Ljg2IDEzOC45OWMxNy42ODQgMC44NjY3MyA0Ny43MjYgMzkuNTk3IDQzLjQxMSA2NC4xMjQtMS4zOTM1IDcuOTE5Ny0xMy42ODYgOS44MTQ4LTIxLjY5MyAxMC41NTQtOC4wODIgMC43NDU2MS0xNS40OTEtNi41NDM5LTIzLjQ3NS02LjQ2NjQtNy40OTEzIDAuMDcyNy0xMC4wODEgNC4xMzk5LTE0LjE3IDUuNTgxLTExLjk5MiA0LjIyNy0yNy4xMTQgNS4xMTQtMzIuMDY3LTcuMjk1My0xMC41ODgtMjYuNTI3IDMwLjc2LTY3LjM0MiA0Ny45OTQtNjYuNDk3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="213,180,60,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yNW1tIiBoZWlnaHQ9IjE1My42MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODIuMjUgMTUzLjYxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC4xNDggLTcwLjY0MikiPjxwYXRoIGQ9Im0yMC4yMTcgMjIyLjM0Yy0xMC45NzYtMy4zOTc3LTUuMTM4MS0xNi4yMjQgMi4zODM2LTE5Ljg2IDguNzQ3LTUuNzcwOCAxOC42MDggMC41MzQyNiAyNy41MjgtMi4zMjAzIDguMjQ3Mi0xLjk5NzUgMTguMjQzLTEyLjA4OCA3LjMwOTgtMTcuOTc0LTYuMzYwOC00LjgyMzYtMTUuMDI3LTguNzkzNS0xNi43ODMtMTcuNDU4IDAuMjI1MTgtMTAuMDA0LTMuNjQ4Ni0xOS45NDMtMTMuMTktMjQuNDc3LTQuNTAzOS04LjU2MzEtMy4xOTEyLTE4LjgxMS01LjY3MTItMjguMDA0LTEuMDgtMTAuNjA1IDAuNTAxMTktMjEuMDYyIDIuMTA0LTMxLjQ4NyAxLjAxNDItMTMuMDg0IDE0LjM1LTQuMzgyOSAxOS41OTYgMC45MzIwOSA2LjgwMDkgNi44MTk1IDEyLjEwOSAxNS4xNDEgMTguNTk3IDIyLjM4OSA1LjIzODYgOC43NDI0IDEzLjc3NyAxNC4wMTYgMjIuNDI2IDE4Ljg4IDEwLjcyNyA2LjA3NDIgMTcuNzY3IDE1LjYxNiAyNS4yMjggMjUuMDYzIDEuMTg0IDEuMjk1MSAxLjE1ODEgMi44NDQ3IDEuNTE2NCAzLjE2NTkgMC4yNTI3NyAwLjIyNjU5IDEuMzA0NSAxLjE2MzUgMS44MzM5IDAuODgwODUgMy4wMTM1LTEuOTI4NCA4LjA5NS0xMS44MDIgMTAuMzk2LTE0Ljc2NSA3LjQwODgtMTEuMzc1IDEzLjYwNi0yMy41MDggMjAuOTc1LTM0LjkxOSA1LjMwNjctOS4yMjM3IDEwLjgwMi0xOC40NjQgMTguNzk1LTI1LjY1NyA4LjY1MzgtMTAuNDc2IDE1LjUyLTUuODA4NyAxNy45MjkgMS44Nzg2IDMuMDQyIDkuNzA3OCAxMy4xODYgMTQuMDY4IDExLjA5MiAyNC4yNSAwLjM2MzE2IDkuODU0Ni0wLjE1OTQ0IDIxLjQxMy05LjE3MjcgMjcuNTgtNy4xMzUxIDcuMTAwMS0xOC4wMDkgOS41MDUzLTIzLjk5MSAxNy43NDgtMS42MzI0IDQuODIzLTkuNTY2MyAxOC43NDYtMy42Mjg0IDIxLjkzMyA1LjI5MTgtMC43NDE5OSA3LjY4ODQtNS44NzUyIDExLjc0MS01Ljk5ODggNS4wMDcyIDAgNy4wOTk0LTFlLTUgMTIuMDEyIDAuNzMzMDYgNS44MjIzIDAuODY4NzggMTEuOTY5IDMuODM5MiAxMy43NTcgOC4xODcyIDAuOTY2MDQgMi4zNDk2IDMuMjA2NSA5LjQ5ODggMy4zNTUzIDEyLjY4NSAwLjA5MTggMS45NjY4IDAuMjY0NDkgMy4xMTkxLTIuMDU2NSA0LjIzNy0yLjk4IDEuNDM1My0xNi4wMzggMC4yNjI4OS0xOC4yMy0wLjM3NjU3LTcuOTM4My0yLjMxNS04LjgwOC00LjQ4NDItMTYuMTQ1IDAuMjUwNi03LjkxMDYgNS43ODU0LTE2Ljg1MSAxMS4zMzctMjYuNDIgMTQuMjYxLTE5LjU1IDYuNTg5NS00MC40NTkgMTEuMDkyLTU5LjY1MSAxMC4zMi01Ljk2MzgtMC4yNjQzNC0xMi4zNzQtMS4zNTA0LTE4LjU3IDAuNzgzMjQtMi45NzE4IDEuMDIzNS02LjcwNyA0LjcyOTktOS40NjA4IDYuNDIwOC02LjgzMSAzLjYzMTgtMTQuODUzIDIuNDQ0LTIyLjMzNSAyLjQ2ODMtMS4yMzYgNGUtMyAtMi4xNzk5LTEuMTY1Ni0zLjI2OTgtMS43NDg0eiIgc3Ryb2tlLXdpZHRoPSIuNTUyNjMiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0MC41Nm1tIiBoZWlnaHQ9IjE0My42bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0MC41NiAxNDMuNiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDUuODc2IC03Mi4wMTQpIj48Zz48ZWxsaXBzZSB0cmFuc2Zvcm09Im1hdHJpeCguNjAxNjYgLS43OTg3NSAuNjg2OCAuNzI2ODUgMCAwKSIgY3g9Ii00NC43ODUiIGN5PSIxMzcuOSIgcng9IjIxLjQ0IiByeT0iMjUuNzU0Ii8+PGVsbGlwc2UgdHJhbnNmb3JtPSJtYXRyaXgoLjY1MTI0IC0uNzU4ODcgLjUzMDU4IC44NDc2MyAwIDApIiBjeD0iMzAuOTMiIGN5PSIxNDYuODgiIHJ4PSIyMi4zNCIgcnk9IjI3Ljc3NSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45NTUzNCAtLjI5NTUxIC0uMDA5MzMwMiAuOTk5OTYgMCAwKSIgY3g9IjE0OC4wMyIgY3k9IjE0Ni41NSIgcng9IjIwLjk3NyIgcnk9IjI2LjcwOSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45OTgzOSAtLjA1NjY1NCAtLjI2MzU4IC45NjQ2NCAwIDApIiBjeD0iMjA3LjgzIiBjeT0iMTU5Ljc5IiByeD0iMjAuMTI1IiByeT0iMjMuODkiLz48cGF0aCBkPSJtMTE2Ljg2IDEzOC45OWMxNy42ODQgMC44NjY3MyA0Ny43MjYgMzkuNTk3IDQzLjQxMSA2NC4xMjQtMS4zOTM1IDcuOTE5Ny0xMy42ODYgOS44MTQ4LTIxLjY5MyAxMC41NTQtOC4wODIgMC43NDU2MS0xNS40OTEtNi41NDM5LTIzLjQ3NS02LjQ2NjQtNy40OTEzIDAuMDcyNy0xMC4wODEgNC4xMzk5LTE0LjE3IDUuNTgxLTExLjk5MiA0LjIyNy0yNy4xMTQgNS4xMTQtMzIuMDY3LTcuMjk1My0xMC41ODgtMjYuNTI3IDMwLjc2LTY3LjM0MiA0Ny45OTQtNjYuNDk3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="213,180,60,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yNW1tIiBoZWlnaHQ9IjE1My42MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODIuMjUgMTUzLjYxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC4xNDggLTcwLjY0MikiPjxwYXRoIGQ9Im0yMC4yMTcgMjIyLjM0Yy0xMC45NzYtMy4zOTc3LTUuMTM4MS0xNi4yMjQgMi4zODM2LTE5Ljg2IDguNzQ3LTUuNzcwOCAxOC42MDggMC41MzQyNiAyNy41MjgtMi4zMjAzIDguMjQ3Mi0xLjk5NzUgMTguMjQzLTEyLjA4OCA3LjMwOTgtMTcuOTc0LTYuMzYwOC00LjgyMzYtMTUuMDI3LTguNzkzNS0xNi43ODMtMTcuNDU4IDAuMjI1MTgtMTAuMDA0LTMuNjQ4Ni0xOS45NDMtMTMuMTktMjQuNDc3LTQuNTAzOS04LjU2MzEtMy4xOTEyLTE4LjgxMS01LjY3MTItMjguMDA0LTEuMDgtMTAuNjA1IDAuNTAxMTktMjEuMDYyIDIuMTA0LTMxLjQ4NyAxLjAxNDItMTMuMDg0IDE0LjM1LTQuMzgyOSAxOS41OTYgMC45MzIwOSA2LjgwMDkgNi44MTk1IDEyLjEwOSAxNS4xNDEgMTguNTk3IDIyLjM4OSA1LjIzODYgOC43NDI0IDEzLjc3NyAxNC4wMTYgMjIuNDI2IDE4Ljg4IDEwLjcyNyA2LjA3NDIgMTcuNzY3IDE1LjYxNiAyNS4yMjggMjUuMDYzIDEuMTg0IDEuMjk1MSAxLjE1ODEgMi44NDQ3IDEuNTE2NCAzLjE2NTkgMC4yNTI3NyAwLjIyNjU5IDEuMzA0NSAxLjE2MzUgMS44MzM5IDAuODgwODUgMy4wMTM1LTEuOTI4NCA4LjA5NS0xMS44MDIgMTAuMzk2LTE0Ljc2NSA3LjQwODgtMTEuMzc1IDEzLjYwNi0yMy41MDggMjAuOTc1LTM0LjkxOSA1LjMwNjctOS4yMjM3IDEwLjgwMi0xOC40NjQgMTguNzk1LTI1LjY1NyA4LjY1MzgtMTAuNDc2IDE1LjUyLTUuODA4NyAxNy45MjkgMS44Nzg2IDMuMDQyIDkuNzA3OCAxMy4xODYgMTQuMDY4IDExLjA5MiAyNC4yNSAwLjM2MzE2IDkuODU0Ni0wLjE1OTQ0IDIxLjQxMy05LjE3MjcgMjcuNTgtNy4xMzUxIDcuMTAwMS0xOC4wMDkgOS41MDUzLTIzLjk5MSAxNy43NDgtMS42MzI0IDQuODIzLTkuNTY2MyAxOC43NDYtMy42Mjg0IDIxLjkzMyA1LjI5MTgtMC43NDE5OSA3LjY4ODQtNS44NzUyIDExLjc0MS01Ljk5ODggNS4wMDcyIDAgNy4wOTk0LTFlLTUgMTIuMDEyIDAuNzMzMDYgNS44MjIzIDAuODY4NzggMTEuOTY5IDMuODM5MiAxMy43NTcgOC4xODcyIDAuOTY2MDQgMi4zNDk2IDMuMjA2NSA5LjQ5ODggMy4zNTUzIDEyLjY4NSAwLjA5MTggMS45NjY4IDAuMjY0NDkgMy4xMTkxLTIuMDU2NSA0LjIzNy0yLjk4IDEuNDM1My0xNi4wMzggMC4yNjI4OS0xOC4yMy0wLjM3NjU3LTcuOTM4My0yLjMxNS04LjgwOC00LjQ4NDItMTYuMTQ1IDAuMjUwNi03LjkxMDYgNS43ODU0LTE2Ljg1MSAxMS4zMzctMjYuNDIgMTQuMjYxLTE5LjU1IDYuNTg5NS00MC40NTkgMTEuMDkyLTU5LjY1MSAxMC4zMi01Ljk2MzgtMC4yNjQzNC0xMi4zNzQtMS4zNTA0LTE4LjU3IDAuNzgzMjQtMi45NzE4IDEuMDIzNS02LjcwNyA0LjcyOTktOS40NjA4IDYuNDIwOC02LjgzMSAzLjYzMTgtMTQuODUzIDIuNDQ0LTIyLjMzNSAyLjQ2ODMtMS4yMzYgNGUtMyAtMi4xNzk5LTEuMTY1Ni0zLjI2OTgtMS43NDg0eiIgc3Ryb2tlLXdpZHRoPSIuNTUyNjMiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0MC41Nm1tIiBoZWlnaHQ9IjE0My42bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0MC41NiAxNDMuNiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDUuODc2IC03Mi4wMTQpIj48Zz48ZWxsaXBzZSB0cmFuc2Zvcm09Im1hdHJpeCguNjAxNjYgLS43OTg3NSAuNjg2OCAuNzI2ODUgMCAwKSIgY3g9Ii00NC43ODUiIGN5PSIxMzcuOSIgcng9IjIxLjQ0IiByeT0iMjUuNzU0Ii8+PGVsbGlwc2UgdHJhbnNmb3JtPSJtYXRyaXgoLjY1MTI0IC0uNzU4ODcgLjUzMDU4IC44NDc2MyAwIDApIiBjeD0iMzAuOTMiIGN5PSIxNDYuODgiIHJ4PSIyMi4zNCIgcnk9IjI3Ljc3NSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45NTUzNCAtLjI5NTUxIC0uMDA5MzMwMiAuOTk5OTYgMCAwKSIgY3g9IjE0OC4wMyIgY3k9IjE0Ni41NSIgcng9IjIwLjk3NyIgcnk9IjI2LjcwOSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45OTgzOSAtLjA1NjY1NCAtLjI2MzU4IC45NjQ2NCAwIDApIiBjeD0iMjA3LjgzIiBjeT0iMTU5Ljc5IiByeD0iMjAuMTI1IiByeT0iMjMuODkiLz48cGF0aCBkPSJtMTE2Ljg2IDEzOC45OWMxNy42ODQgMC44NjY3MyA0Ny43MjYgMzkuNTk3IDQzLjQxMSA2NC4xMjQtMS4zOTM1IDcuOTE5Ny0xMy42ODYgOS44MTQ4LTIxLjY5MyAxMC41NTQtOC4wODIgMC43NDU2MS0xNS40OTEtNi41NDM5LTIzLjQ3NS02LjQ2NjQtNy40OTEzIDAuMDcyNy0xMC4wODEgNC4xMzk5LTE0LjE3IDUuNTgxLTExLjk5MiA0LjIyNy0yNy4xMTQgNS4xMTQtMzIuMDY3LTcuMjk1My0xMC41ODgtMjYuNTI3IDMwLjc2LTY3LjM0MiA0Ny45OTQtNjYuNDk3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="213,180,60,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yNW1tIiBoZWlnaHQ9IjE1My42MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODIuMjUgMTUzLjYxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC4xNDggLTcwLjY0MikiPjxwYXRoIGQ9Im0yMC4yMTcgMjIyLjM0Yy0xMC45NzYtMy4zOTc3LTUuMTM4MS0xNi4yMjQgMi4zODM2LTE5Ljg2IDguNzQ3LTUuNzcwOCAxOC42MDggMC41MzQyNiAyNy41MjgtMi4zMjAzIDguMjQ3Mi0xLjk5NzUgMTguMjQzLTEyLjA4OCA3LjMwOTgtMTcuOTc0LTYuMzYwOC00LjgyMzYtMTUuMDI3LTguNzkzNS0xNi43ODMtMTcuNDU4IDAuMjI1MTgtMTAuMDA0LTMuNjQ4Ni0xOS45NDMtMTMuMTktMjQuNDc3LTQuNTAzOS04LjU2MzEtMy4xOTEyLTE4LjgxMS01LjY3MTItMjguMDA0LTEuMDgtMTAuNjA1IDAuNTAxMTktMjEuMDYyIDIuMTA0LTMxLjQ4NyAxLjAxNDItMTMuMDg0IDE0LjM1LTQuMzgyOSAxOS41OTYgMC45MzIwOSA2LjgwMDkgNi44MTk1IDEyLjEwOSAxNS4xNDEgMTguNTk3IDIyLjM4OSA1LjIzODYgOC43NDI0IDEzLjc3NyAxNC4wMTYgMjIuNDI2IDE4Ljg4IDEwLjcyNyA2LjA3NDIgMTcuNzY3IDE1LjYxNiAyNS4yMjggMjUuMDYzIDEuMTg0IDEuMjk1MSAxLjE1ODEgMi44NDQ3IDEuNTE2NCAzLjE2NTkgMC4yNTI3NyAwLjIyNjU5IDEuMzA0NSAxLjE2MzUgMS44MzM5IDAuODgwODUgMy4wMTM1LTEuOTI4NCA4LjA5NS0xMS44MDIgMTAuMzk2LTE0Ljc2NSA3LjQwODgtMTEuMzc1IDEzLjYwNi0yMy41MDggMjAuOTc1LTM0LjkxOSA1LjMwNjctOS4yMjM3IDEwLjgwMi0xOC40NjQgMTguNzk1LTI1LjY1NyA4LjY1MzgtMTAuNDc2IDE1LjUyLTUuODA4NyAxNy45MjkgMS44Nzg2IDMuMDQyIDkuNzA3OCAxMy4xODYgMTQuMDY4IDExLjA5MiAyNC4yNSAwLjM2MzE2IDkuODU0Ni0wLjE1OTQ0IDIxLjQxMy05LjE3MjcgMjcuNTgtNy4xMzUxIDcuMTAwMS0xOC4wMDkgOS41MDUzLTIzLjk5MSAxNy43NDgtMS42MzI0IDQuODIzLTkuNTY2MyAxOC43NDYtMy42Mjg0IDIxLjkzMyA1LjI5MTgtMC43NDE5OSA3LjY4ODQtNS44NzUyIDExLjc0MS01Ljk5ODggNS4wMDcyIDAgNy4wOTk0LTFlLTUgMTIuMDEyIDAuNzMzMDYgNS44MjIzIDAuODY4NzggMTEuOTY5IDMuODM5MiAxMy43NTcgOC4xODcyIDAuOTY2MDQgMi4zNDk2IDMuMjA2NSA5LjQ5ODggMy4zNTUzIDEyLjY4NSAwLjA5MTggMS45NjY4IDAuMjY0NDkgMy4xMTkxLTIuMDU2NSA0LjIzNy0yLjk4IDEuNDM1My0xNi4wMzggMC4yNjI4OS0xOC4yMy0wLjM3NjU3LTcuOTM4My0yLjMxNS04LjgwOC00LjQ4NDItMTYuMTQ1IDAuMjUwNi03LjkxMDYgNS43ODU0LTE2Ljg1MSAxMS4zMzctMjYuNDIgMTQuMjYxLTE5LjU1IDYuNTg5NS00MC40NTkgMTEuMDkyLTU5LjY1MSAxMC4zMi01Ljk2MzgtMC4yNjQzNC0xMi4zNzQtMS4zNTA0LTE4LjU3IDAuNzgzMjQtMi45NzE4IDEuMDIzNS02LjcwNyA0LjcyOTktOS40NjA4IDYuNDIwOC02LjgzMSAzLjYzMTgtMTQuODUzIDIuNDQ0LTIyLjMzNSAyLjQ2ODMtMS4yMzYgNGUtMyAtMi4xNzk5LTEuMTY1Ni0zLjI2OTgtMS43NDg0eiIgc3Ryb2tlLXdpZHRoPSIuNTUyNjMiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0MC41Nm1tIiBoZWlnaHQ9IjE0My42bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0MC41NiAxNDMuNiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDUuODc2IC03Mi4wMTQpIj48Zz48ZWxsaXBzZSB0cmFuc2Zvcm09Im1hdHJpeCguNjAxNjYgLS43OTg3NSAuNjg2OCAuNzI2ODUgMCAwKSIgY3g9Ii00NC43ODUiIGN5PSIxMzcuOSIgcng9IjIxLjQ0IiByeT0iMjUuNzU0Ii8+PGVsbGlwc2UgdHJhbnNmb3JtPSJtYXRyaXgoLjY1MTI0IC0uNzU4ODcgLjUzMDU4IC44NDc2MyAwIDApIiBjeD0iMzAuOTMiIGN5PSIxNDYuODgiIHJ4PSIyMi4zNCIgcnk9IjI3Ljc3NSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45NTUzNCAtLjI5NTUxIC0uMDA5MzMwMiAuOTk5OTYgMCAwKSIgY3g9IjE0OC4wMyIgY3k9IjE0Ni41NSIgcng9IjIwLjk3NyIgcnk9IjI2LjcwOSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45OTgzOSAtLjA1NjY1NCAtLjI2MzU4IC45NjQ2NCAwIDApIiBjeD0iMjA3LjgzIiBjeT0iMTU5Ljc5IiByeD0iMjAuMTI1IiByeT0iMjMuODkiLz48cGF0aCBkPSJtMTE2Ljg2IDEzOC45OWMxNy42ODQgMC44NjY3MyA0Ny43MjYgMzkuNTk3IDQzLjQxMSA2NC4xMjQtMS4zOTM1IDcuOTE5Ny0xMy42ODYgOS44MTQ4LTIxLjY5MyAxMC41NTQtOC4wODIgMC43NDU2MS0xNS40OTEtNi41NDM5LTIzLjQ3NS02LjQ2NjQtNy40OTEzIDAuMDcyNy0xMC4wODEgNC4xMzk5LTE0LjE3IDUuNTgxLTExLjk5MiA0LjIyNy0yNy4xMTQgNS4xMTQtMzIuMDY3LTcuMjk1My0xMC41ODgtMjYuNTI3IDMwLjc2LTY3LjM0MiA0Ny45OTQtNjYuNDk3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0MC41Nm1tIiBoZWlnaHQ9IjE0My42bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0MC41NiAxNDMuNiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDUuODc2IC03Mi4wMTQpIj48Zz48ZWxsaXBzZSB0cmFuc2Zvcm09Im1hdHJpeCguNjAxNjYgLS43OTg3NSAuNjg2OCAuNzI2ODUgMCAwKSIgY3g9Ii00NC43ODUiIGN5PSIxMzcuOSIgcng9IjIxLjQ0IiByeT0iMjUuNzU0Ii8+PGVsbGlwc2UgdHJhbnNmb3JtPSJtYXRyaXgoLjY1MTI0IC0uNzU4ODcgLjUzMDU4IC44NDc2MyAwIDApIiBjeD0iMzAuOTMiIGN5PSIxNDYuODgiIHJ4PSIyMi4zNCIgcnk9IjI3Ljc3NSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45NTUzNCAtLjI5NTUxIC0uMDA5MzMwMiAuOTk5OTYgMCAwKSIgY3g9IjE0OC4wMyIgY3k9IjE0Ni41NSIgcng9IjIwLjk3NyIgcnk9IjI2LjcwOSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45OTgzOSAtLjA1NjY1NCAtLjI2MzU4IC45NjQ2NCAwIDApIiBjeD0iMjA3LjgzIiBjeT0iMTU5Ljc5IiByeD0iMjAuMTI1IiByeT0iMjMuODkiLz48cGF0aCBkPSJtMTE2Ljg2IDEzOC45OWMxNy42ODQgMC44NjY3MyA0Ny43MjYgMzkuNTk3IDQzLjQxMSA2NC4xMjQtMS4zOTM1IDcuOTE5Ny0xMy42ODYgOS44MTQ4LTIxLjY5MyAxMC41NTQtOC4wODIgMC43NDU2MS0xNS40OTEtNi41NDM5LTIzLjQ3NS02LjQ2NjQtNy40OTEzIDAuMDcyNy0xMC4wODEgNC4xMzk5LTE0LjE3IDUuNTgxLTExLjk5MiA0LjIyNy0yNy4xMTQgNS4xMTQtMzIuMDY3LTcuMjk1My0xMC41ODgtMjYuNTI3IDMwLjc2LTY3LjM0MiA0Ny45OTQtNjYuNDk3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="213,180,60,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yNW1tIiBoZWlnaHQ9IjE1My42MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODIuMjUgMTUzLjYxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC4xNDggLTcwLjY0MikiPjxwYXRoIGQ9Im0yMC4yMTcgMjIyLjM0Yy0xMC45NzYtMy4zOTc3LTUuMTM4MS0xNi4yMjQgMi4zODM2LTE5Ljg2IDguNzQ3LTUuNzcwOCAxOC42MDggMC41MzQyNiAyNy41MjgtMi4zMjAzIDguMjQ3Mi0xLjk5NzUgMTguMjQzLTEyLjA4OCA3LjMwOTgtMTcuOTc0LTYuMzYwOC00LjgyMzYtMTUuMDI3LTguNzkzNS0xNi43ODMtMTcuNDU4IDAuMjI1MTgtMTAuMDA0LTMuNjQ4Ni0xOS45NDMtMTMuMTktMjQuNDc3LTQuNTAzOS04LjU2MzEtMy4xOTEyLTE4LjgxMS01LjY3MTItMjguMDA0LTEuMDgtMTAuNjA1IDAuNTAxMTktMjEuMDYyIDIuMTA0LTMxLjQ4NyAxLjAxNDItMTMuMDg0IDE0LjM1LTQuMzgyOSAxOS41OTYgMC45MzIwOSA2LjgwMDkgNi44MTk1IDEyLjEwOSAxNS4xNDEgMTguNTk3IDIyLjM4OSA1LjIzODYgOC43NDI0IDEzLjc3NyAxNC4wMTYgMjIuNDI2IDE4Ljg4IDEwLjcyNyA2LjA3NDIgMTcuNzY3IDE1LjYxNiAyNS4yMjggMjUuMDYzIDEuMTg0IDEuMjk1MSAxLjE1ODEgMi44NDQ3IDEuNTE2NCAzLjE2NTkgMC4yNTI3NyAwLjIyNjU5IDEuMzA0NSAxLjE2MzUgMS44MzM5IDAuODgwODUgMy4wMTM1LTEuOTI4NCA4LjA5NS0xMS44MDIgMTAuMzk2LTE0Ljc2NSA3LjQwODgtMTEuMzc1IDEzLjYwNi0yMy41MDggMjAuOTc1LTM0LjkxOSA1LjMwNjctOS4yMjM3IDEwLjgwMi0xOC40NjQgMTguNzk1LTI1LjY1NyA4LjY1MzgtMTAuNDc2IDE1LjUyLTUuODA4NyAxNy45MjkgMS44Nzg2IDMuMDQyIDkuNzA3OCAxMy4xODYgMTQuMDY4IDExLjA5MiAyNC4yNSAwLjM2MzE2IDkuODU0Ni0wLjE1OTQ0IDIxLjQxMy05LjE3MjcgMjcuNTgtNy4xMzUxIDcuMTAwMS0xOC4wMDkgOS41MDUzLTIzLjk5MSAxNy43NDgtMS42MzI0IDQuODIzLTkuNTY2MyAxOC43NDYtMy42Mjg0IDIxLjkzMyA1LjI5MTgtMC43NDE5OSA3LjY4ODQtNS44NzUyIDExLjc0MS01Ljk5ODggNS4wMDcyIDAgNy4wOTk0LTFlLTUgMTIuMDEyIDAuNzMzMDYgNS44MjIzIDAuODY4NzggMTEuOTY5IDMuODM5MiAxMy43NTcgOC4xODcyIDAuOTY2MDQgMi4zNDk2IDMuMjA2NSA5LjQ5ODggMy4zNTUzIDEyLjY4NSAwLjA5MTggMS45NjY4IDAuMjY0NDkgMy4xMTkxLTIuMDU2NSA0LjIzNy0yLjk4IDEuNDM1My0xNi4wMzggMC4yNjI4OS0xOC4yMy0wLjM3NjU3LTcuOTM4My0yLjMxNS04LjgwOC00LjQ4NDItMTYuMTQ1IDAuMjUwNi03LjkxMDYgNS43ODU0LTE2Ljg1MSAxMS4zMzctMjYuNDIgMTQuMjYxLTE5LjU1IDYuNTg5NS00MC40NTkgMTEuMDkyLTU5LjY1MSAxMC4zMi01Ljk2MzgtMC4yNjQzNC0xMi4zNzQtMS4zNTA0LTE4LjU3IDAuNzgzMjQtMi45NzE4IDEuMDIzNS02LjcwNyA0LjcyOTktOS40NjA4IDYuNDIwOC02LjgzMSAzLjYzMTgtMTQuODUzIDIuNDQ0LTIyLjMzNSAyLjQ2ODMtMS4yMzYgNGUtMyAtMi4xNzk5LTEuMTY1Ni0zLjI2OTgtMS43NDg0eiIgc3Ryb2tlLXdpZHRoPSIuNTUyNjMiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0MC41Nm1tIiBoZWlnaHQ9IjE0My42bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0MC41NiAxNDMuNiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDUuODc2IC03Mi4wMTQpIj48Zz48ZWxsaXBzZSB0cmFuc2Zvcm09Im1hdHJpeCguNjAxNjYgLS43OTg3NSAuNjg2OCAuNzI2ODUgMCAwKSIgY3g9Ii00NC43ODUiIGN5PSIxMzcuOSIgcng9IjIxLjQ0IiByeT0iMjUuNzU0Ii8+PGVsbGlwc2UgdHJhbnNmb3JtPSJtYXRyaXgoLjY1MTI0IC0uNzU4ODcgLjUzMDU4IC44NDc2MyAwIDApIiBjeD0iMzAuOTMiIGN5PSIxNDYuODgiIHJ4PSIyMi4zNCIgcnk9IjI3Ljc3NSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45NTUzNCAtLjI5NTUxIC0uMDA5MzMwMiAuOTk5OTYgMCAwKSIgY3g9IjE0OC4wMyIgY3k9IjE0Ni41NSIgcng9IjIwLjk3NyIgcnk9IjI2LjcwOSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45OTgzOSAtLjA1NjY1NCAtLjI2MzU4IC45NjQ2NCAwIDApIiBjeD0iMjA3LjgzIiBjeT0iMTU5Ljc5IiByeD0iMjAuMTI1IiByeT0iMjMuODkiLz48cGF0aCBkPSJtMTE2Ljg2IDEzOC45OWMxNy42ODQgMC44NjY3MyA0Ny43MjYgMzkuNTk3IDQzLjQxMSA2NC4xMjQtMS4zOTM1IDcuOTE5Ny0xMy42ODYgOS44MTQ4LTIxLjY5MyAxMC41NTQtOC4wODIgMC43NDU2MS0xNS40OTEtNi41NDM5LTIzLjQ3NS02LjQ2NjQtNy40OTEzIDAuMDcyNy0xMC4wODEgNC4xMzk5LTE0LjE3IDUuNTgxLTExLjk5MiA0LjIyNy0yNy4xMTQgNS4xMTQtMzIuMDY3LTcuMjk1My0xMC41ODgtMjYuNTI3IDMwLjc2LTY3LjM0MiA0Ny45OTQtNjYuNDk3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="213,180,60,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yNW1tIiBoZWlnaHQ9IjE1My42MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODIuMjUgMTUzLjYxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC4xNDggLTcwLjY0MikiPjxwYXRoIGQ9Im0yMC4yMTcgMjIyLjM0Yy0xMC45NzYtMy4zOTc3LTUuMTM4MS0xNi4yMjQgMi4zODM2LTE5Ljg2IDguNzQ3LTUuNzcwOCAxOC42MDggMC41MzQyNiAyNy41MjgtMi4zMjAzIDguMjQ3Mi0xLjk5NzUgMTguMjQzLTEyLjA4OCA3LjMwOTgtMTcuOTc0LTYuMzYwOC00LjgyMzYtMTUuMDI3LTguNzkzNS0xNi43ODMtMTcuNDU4IDAuMjI1MTgtMTAuMDA0LTMuNjQ4Ni0xOS45NDMtMTMuMTktMjQuNDc3LTQuNTAzOS04LjU2MzEtMy4xOTEyLTE4LjgxMS01LjY3MTItMjguMDA0LTEuMDgtMTAuNjA1IDAuNTAxMTktMjEuMDYyIDIuMTA0LTMxLjQ4NyAxLjAxNDItMTMuMDg0IDE0LjM1LTQuMzgyOSAxOS41OTYgMC45MzIwOSA2LjgwMDkgNi44MTk1IDEyLjEwOSAxNS4xNDEgMTguNTk3IDIyLjM4OSA1LjIzODYgOC43NDI0IDEzLjc3NyAxNC4wMTYgMjIuNDI2IDE4Ljg4IDEwLjcyNyA2LjA3NDIgMTcuNzY3IDE1LjYxNiAyNS4yMjggMjUuMDYzIDEuMTg0IDEuMjk1MSAxLjE1ODEgMi44NDQ3IDEuNTE2NCAzLjE2NTkgMC4yNTI3NyAwLjIyNjU5IDEuMzA0NSAxLjE2MzUgMS44MzM5IDAuODgwODUgMy4wMTM1LTEuOTI4NCA4LjA5NS0xMS44MDIgMTAuMzk2LTE0Ljc2NSA3LjQwODgtMTEuMzc1IDEzLjYwNi0yMy41MDggMjAuOTc1LTM0LjkxOSA1LjMwNjctOS4yMjM3IDEwLjgwMi0xOC40NjQgMTguNzk1LTI1LjY1NyA4LjY1MzgtMTAuNDc2IDE1LjUyLTUuODA4NyAxNy45MjkgMS44Nzg2IDMuMDQyIDkuNzA3OCAxMy4xODYgMTQuMDY4IDExLjA5MiAyNC4yNSAwLjM2MzE2IDkuODU0Ni0wLjE1OTQ0IDIxLjQxMy05LjE3MjcgMjcuNTgtNy4xMzUxIDcuMTAwMS0xOC4wMDkgOS41MDUzLTIzLjk5MSAxNy43NDgtMS42MzI0IDQuODIzLTkuNTY2MyAxOC43NDYtMy42Mjg0IDIxLjkzMyA1LjI5MTgtMC43NDE5OSA3LjY4ODQtNS44NzUyIDExLjc0MS01Ljk5ODggNS4wMDcyIDAgNy4wOTk0LTFlLTUgMTIuMDEyIDAuNzMzMDYgNS44MjIzIDAuODY4NzggMTEuOTY5IDMuODM5MiAxMy43NTcgOC4xODcyIDAuOTY2MDQgMi4zNDk2IDMuMjA2NSA5LjQ5ODggMy4zNTUzIDEyLjY4NSAwLjA5MTggMS45NjY4IDAuMjY0NDkgMy4xMTkxLTIuMDU2NSA0LjIzNy0yLjk4IDEuNDM1My0xNi4wMzggMC4yNjI4OS0xOC4yMy0wLjM3NjU3LTcuOTM4My0yLjMxNS04LjgwOC00LjQ4NDItMTYuMTQ1IDAuMjUwNi03LjkxMDYgNS43ODU0LTE2Ljg1MSAxMS4zMzctMjYuNDIgMTQuMjYxLTE5LjU1IDYuNTg5NS00MC40NTkgMTEuMDkyLTU5LjY1MSAxMC4zMi01Ljk2MzgtMC4yNjQzNC0xMi4zNzQtMS4zNTA0LTE4LjU3IDAuNzgzMjQtMi45NzE4IDEuMDIzNS02LjcwNyA0LjcyOTktOS40NjA4IDYuNDIwOC02LjgzMSAzLjYzMTgtMTQuODUzIDIuNDQ0LTIyLjMzNSAyLjQ2ODMtMS4yMzYgNGUtMyAtMi4xNzk5LTEuMTY1Ni0zLjI2OTgtMS43NDg0eiIgc3Ryb2tlLXdpZHRoPSIuNTUyNjMiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0MC41Nm1tIiBoZWlnaHQ9IjE0My42bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0MC41NiAxNDMuNiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDUuODc2IC03Mi4wMTQpIj48Zz48ZWxsaXBzZSB0cmFuc2Zvcm09Im1hdHJpeCguNjAxNjYgLS43OTg3NSAuNjg2OCAuNzI2ODUgMCAwKSIgY3g9Ii00NC43ODUiIGN5PSIxMzcuOSIgcng9IjIxLjQ0IiByeT0iMjUuNzU0Ii8+PGVsbGlwc2UgdHJhbnNmb3JtPSJtYXRyaXgoLjY1MTI0IC0uNzU4ODcgLjUzMDU4IC44NDc2MyAwIDApIiBjeD0iMzAuOTMiIGN5PSIxNDYuODgiIHJ4PSIyMi4zNCIgcnk9IjI3Ljc3NSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45NTUzNCAtLjI5NTUxIC0uMDA5MzMwMiAuOTk5OTYgMCAwKSIgY3g9IjE0OC4wMyIgY3k9IjE0Ni41NSIgcng9IjIwLjk3NyIgcnk9IjI2LjcwOSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45OTgzOSAtLjA1NjY1NCAtLjI2MzU4IC45NjQ2NCAwIDApIiBjeD0iMjA3LjgzIiBjeT0iMTU5Ljc5IiByeD0iMjAuMTI1IiByeT0iMjMuODkiLz48cGF0aCBkPSJtMTE2Ljg2IDEzOC45OWMxNy42ODQgMC44NjY3MyA0Ny43MjYgMzkuNTk3IDQzLjQxMSA2NC4xMjQtMS4zOTM1IDcuOTE5Ny0xMy42ODYgOS44MTQ4LTIxLjY5MyAxMC41NTQtOC4wODIgMC43NDU2MS0xNS40OTEtNi41NDM5LTIzLjQ3NS02LjQ2NjQtNy40OTEzIDAuMDcyNy0xMC4wODEgNC4xMzk5LTE0LjE3IDUuNTgxLTExLjk5MiA0LjIyNy0yNy4xMTQgNS4xMTQtMzIuMDY3LTcuMjk1My0xMC41ODgtMjYuNTI3IDMwLjc2LTY3LjM0MiA0Ny45OTQtNjYuNDk3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="213,180,60,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yNW1tIiBoZWlnaHQ9IjE1My42MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODIuMjUgMTUzLjYxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC4xNDggLTcwLjY0MikiPjxwYXRoIGQ9Im0yMC4yMTcgMjIyLjM0Yy0xMC45NzYtMy4zOTc3LTUuMTM4MS0xNi4yMjQgMi4zODM2LTE5Ljg2IDguNzQ3LTUuNzcwOCAxOC42MDggMC41MzQyNiAyNy41MjgtMi4zMjAzIDguMjQ3Mi0xLjk5NzUgMTguMjQzLTEyLjA4OCA3LjMwOTgtMTcuOTc0LTYuMzYwOC00LjgyMzYtMTUuMDI3LTguNzkzNS0xNi43ODMtMTcuNDU4IDAuMjI1MTgtMTAuMDA0LTMuNjQ4Ni0xOS45NDMtMTMuMTktMjQuNDc3LTQuNTAzOS04LjU2MzEtMy4xOTEyLTE4LjgxMS01LjY3MTItMjguMDA0LTEuMDgtMTAuNjA1IDAuNTAxMTktMjEuMDYyIDIuMTA0LTMxLjQ4NyAxLjAxNDItMTMuMDg0IDE0LjM1LTQuMzgyOSAxOS41OTYgMC45MzIwOSA2LjgwMDkgNi44MTk1IDEyLjEwOSAxNS4xNDEgMTguNTk3IDIyLjM4OSA1LjIzODYgOC43NDI0IDEzLjc3NyAxNC4wMTYgMjIuNDI2IDE4Ljg4IDEwLjcyNyA2LjA3NDIgMTcuNzY3IDE1LjYxNiAyNS4yMjggMjUuMDYzIDEuMTg0IDEuMjk1MSAxLjE1ODEgMi44NDQ3IDEuNTE2NCAzLjE2NTkgMC4yNTI3NyAwLjIyNjU5IDEuMzA0NSAxLjE2MzUgMS44MzM5IDAuODgwODUgMy4wMTM1LTEuOTI4NCA4LjA5NS0xMS44MDIgMTAuMzk2LTE0Ljc2NSA3LjQwODgtMTEuMzc1IDEzLjYwNi0yMy41MDggMjAuOTc1LTM0LjkxOSA1LjMwNjctOS4yMjM3IDEwLjgwMi0xOC40NjQgMTguNzk1LTI1LjY1NyA4LjY1MzgtMTAuNDc2IDE1LjUyLTUuODA4NyAxNy45MjkgMS44Nzg2IDMuMDQyIDkuNzA3OCAxMy4xODYgMTQuMDY4IDExLjA5MiAyNC4yNSAwLjM2MzE2IDkuODU0Ni0wLjE1OTQ0IDIxLjQxMy05LjE3MjcgMjcuNTgtNy4xMzUxIDcuMTAwMS0xOC4wMDkgOS41MDUzLTIzLjk5MSAxNy43NDgtMS42MzI0IDQuODIzLTkuNTY2MyAxOC43NDYtMy42Mjg0IDIxLjkzMyA1LjI5MTgtMC43NDE5OSA3LjY4ODQtNS44NzUyIDExLjc0MS01Ljk5ODggNS4wMDcyIDAgNy4wOTk0LTFlLTUgMTIuMDEyIDAuNzMzMDYgNS44MjIzIDAuODY4NzggMTEuOTY5IDMuODM5MiAxMy43NTcgOC4xODcyIDAuOTY2MDQgMi4zNDk2IDMuMjA2NSA5LjQ5ODggMy4zNTUzIDEyLjY4NSAwLjA5MTggMS45NjY4IDAuMjY0NDkgMy4xMTkxLTIuMDU2NSA0LjIzNy0yLjk4IDEuNDM1My0xNi4wMzggMC4yNjI4OS0xOC4yMy0wLjM3NjU3LTcuOTM4My0yLjMxNS04LjgwOC00LjQ4NDItMTYuMTQ1IDAuMjUwNi03LjkxMDYgNS43ODU0LTE2Ljg1MSAxMS4zMzctMjYuNDIgMTQuMjYxLTE5LjU1IDYuNTg5NS00MC40NTkgMTEuMDkyLTU5LjY1MSAxMC4zMi01Ljk2MzgtMC4yNjQzNC0xMi4zNzQtMS4zNTA0LTE4LjU3IDAuNzgzMjQtMi45NzE4IDEuMDIzNS02LjcwNyA0LjcyOTktOS40NjA4IDYuNDIwOC02LjgzMSAzLjYzMTgtMTQuODUzIDIuNDQ0LTIyLjMzNSAyLjQ2ODMtMS4yMzYgNGUtMyAtMi4xNzk5LTEuMTY1Ni0zLjI2OTgtMS43NDg0eiIgc3Ryb2tlLXdpZHRoPSIuNTUyNjMiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0MC41Nm1tIiBoZWlnaHQ9IjE0My42bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0MC41NiAxNDMuNiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDUuODc2IC03Mi4wMTQpIj48Zz48ZWxsaXBzZSB0cmFuc2Zvcm09Im1hdHJpeCguNjAxNjYgLS43OTg3NSAuNjg2OCAuNzI2ODUgMCAwKSIgY3g9Ii00NC43ODUiIGN5PSIxMzcuOSIgcng9IjIxLjQ0IiByeT0iMjUuNzU0Ii8+PGVsbGlwc2UgdHJhbnNmb3JtPSJtYXRyaXgoLjY1MTI0IC0uNzU4ODcgLjUzMDU4IC44NDc2MyAwIDApIiBjeD0iMzAuOTMiIGN5PSIxNDYuODgiIHJ4PSIyMi4zNCIgcnk9IjI3Ljc3NSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45NTUzNCAtLjI5NTUxIC0uMDA5MzMwMiAuOTk5OTYgMCAwKSIgY3g9IjE0OC4wMyIgY3k9IjE0Ni41NSIgcng9IjIwLjk3NyIgcnk9IjI2LjcwOSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45OTgzOSAtLjA1NjY1NCAtLjI2MzU4IC45NjQ2NCAwIDApIiBjeD0iMjA3LjgzIiBjeT0iMTU5Ljc5IiByeD0iMjAuMTI1IiByeT0iMjMuODkiLz48cGF0aCBkPSJtMTE2Ljg2IDEzOC45OWMxNy42ODQgMC44NjY3MyA0Ny43MjYgMzkuNTk3IDQzLjQxMSA2NC4xMjQtMS4zOTM1IDcuOTE5Ny0xMy42ODYgOS44MTQ4LTIxLjY5MyAxMC41NTQtOC4wODIgMC43NDU2MS0xNS40OTEtNi41NDM5LTIzLjQ3NS02LjQ2NjQtNy40OTEzIDAuMDcyNy0xMC4wODEgNC4xMzk5LTE0LjE3IDUuNTgxLTExLjk5MiA0LjIyNy0yNy4xMTQgNS4xMTQtMzIuMDY3LTcuMjk1My0xMC41ODgtMjYuNTI3IDMwLjc2LTY3LjM0MiA0Ny45OTQtNjYuNDk3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="213,180,60,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="213,180,60,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yNW1tIiBoZWlnaHQ9IjE1My42MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODIuMjUgMTUzLjYxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC4xNDggLTcwLjY0MikiPjxwYXRoIGQ9Im0yMC4yMTcgMjIyLjM0Yy0xMC45NzYtMy4zOTc3LTUuMTM4MS0xNi4yMjQgMi4zODM2LTE5Ljg2IDguNzQ3LTUuNzcwOCAxOC42MDggMC41MzQyNiAyNy41MjgtMi4zMjAzIDguMjQ3Mi0xLjk5NzUgMTguMjQzLTEyLjA4OCA3LjMwOTgtMTcuOTc0LTYuMzYwOC00LjgyMzYtMTUuMDI3LTguNzkzNS0xNi43ODMtMTcuNDU4IDAuMjI1MTgtMTAuMDA0LTMuNjQ4Ni0xOS45NDMtMTMuMTktMjQuNDc3LTQuNTAzOS04LjU2MzEtMy4xOTEyLTE4LjgxMS01LjY3MTItMjguMDA0LTEuMDgtMTAuNjA1IDAuNTAxMTktMjEuMDYyIDIuMTA0LTMxLjQ4NyAxLjAxNDItMTMuMDg0IDE0LjM1LTQuMzgyOSAxOS41OTYgMC45MzIwOSA2LjgwMDkgNi44MTk1IDEyLjEwOSAxNS4xNDEgMTguNTk3IDIyLjM4OSA1LjIzODYgOC43NDI0IDEzLjc3NyAxNC4wMTYgMjIuNDI2IDE4Ljg4IDEwLjcyNyA2LjA3NDIgMTcuNzY3IDE1LjYxNiAyNS4yMjggMjUuMDYzIDEuMTg0IDEuMjk1MSAxLjE1ODEgMi44NDQ3IDEuNTE2NCAzLjE2NTkgMC4yNTI3NyAwLjIyNjU5IDEuMzA0NSAxLjE2MzUgMS44MzM5IDAuODgwODUgMy4wMTM1LTEuOTI4NCA4LjA5NS0xMS44MDIgMTAuMzk2LTE0Ljc2NSA3LjQwODgtMTEuMzc1IDEzLjYwNi0yMy41MDggMjAuOTc1LTM0LjkxOSA1LjMwNjctOS4yMjM3IDEwLjgwMi0xOC40NjQgMTguNzk1LTI1LjY1NyA4LjY1MzgtMTAuNDc2IDE1LjUyLTUuODA4NyAxNy45MjkgMS44Nzg2IDMuMDQyIDkuNzA3OCAxMy4xODYgMTQuMDY4IDExLjA5MiAyNC4yNSAwLjM2MzE2IDkuODU0Ni0wLjE1OTQ0IDIxLjQxMy05LjE3MjcgMjcuNTgtNy4xMzUxIDcuMTAwMS0xOC4wMDkgOS41MDUzLTIzLjk5MSAxNy43NDgtMS42MzI0IDQuODIzLTkuNTY2MyAxOC43NDYtMy42Mjg0IDIxLjkzMyA1LjI5MTgtMC43NDE5OSA3LjY4ODQtNS44NzUyIDExLjc0MS01Ljk5ODggNS4wMDcyIDAgNy4wOTk0LTFlLTUgMTIuMDEyIDAuNzMzMDYgNS44MjIzIDAuODY4NzggMTEuOTY5IDMuODM5MiAxMy43NTcgOC4xODcyIDAuOTY2MDQgMi4zNDk2IDMuMjA2NSA5LjQ5ODggMy4zNTUzIDEyLjY4NSAwLjA5MTggMS45NjY4IDAuMjY0NDkgMy4xMTkxLTIuMDU2NSA0LjIzNy0yLjk4IDEuNDM1My0xNi4wMzggMC4yNjI4OS0xOC4yMy0wLjM3NjU3LTcuOTM4My0yLjMxNS04LjgwOC00LjQ4NDItMTYuMTQ1IDAuMjUwNi03LjkxMDYgNS43ODU0LTE2Ljg1MSAxMS4zMzctMjYuNDIgMTQuMjYxLTE5LjU1IDYuNTg5NS00MC40NTkgMTEuMDkyLTU5LjY1MSAxMC4zMi01Ljk2MzgtMC4yNjQzNC0xMi4zNzQtMS4zNTA0LTE4LjU3IDAuNzgzMjQtMi45NzE4IDEuMDIzNS02LjcwNyA0LjcyOTktOS40NjA4IDYuNDIwOC02LjgzMSAzLjYzMTgtMTQuODUzIDIuNDQ0LTIyLjMzNSAyLjQ2ODMtMS4yMzYgNGUtMyAtMi4xNzk5LTEuMTY1Ni0zLjI2OTgtMS43NDg0eiIgc3Ryb2tlLXdpZHRoPSIuNTUyNjMiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0MC41Nm1tIiBoZWlnaHQ9IjE0My42bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0MC41NiAxNDMuNiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDUuODc2IC03Mi4wMTQpIj48Zz48ZWxsaXBzZSB0cmFuc2Zvcm09Im1hdHJpeCguNjAxNjYgLS43OTg3NSAuNjg2OCAuNzI2ODUgMCAwKSIgY3g9Ii00NC43ODUiIGN5PSIxMzcuOSIgcng9IjIxLjQ0IiByeT0iMjUuNzU0Ii8+PGVsbGlwc2UgdHJhbnNmb3JtPSJtYXRyaXgoLjY1MTI0IC0uNzU4ODcgLjUzMDU4IC44NDc2MyAwIDApIiBjeD0iMzAuOTMiIGN5PSIxNDYuODgiIHJ4PSIyMi4zNCIgcnk9IjI3Ljc3NSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45NTUzNCAtLjI5NTUxIC0uMDA5MzMwMiAuOTk5OTYgMCAwKSIgY3g9IjE0OC4wMyIgY3k9IjE0Ni41NSIgcng9IjIwLjk3NyIgcnk9IjI2LjcwOSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45OTgzOSAtLjA1NjY1NCAtLjI2MzU4IC45NjQ2NCAwIDApIiBjeD0iMjA3LjgzIiBjeT0iMTU5Ljc5IiByeD0iMjAuMTI1IiByeT0iMjMuODkiLz48cGF0aCBkPSJtMTE2Ljg2IDEzOC45OWMxNy42ODQgMC44NjY3MyA0Ny43MjYgMzkuNTk3IDQzLjQxMSA2NC4xMjQtMS4zOTM1IDcuOTE5Ny0xMy42ODYgOS44MTQ4LTIxLjY5MyAxMC41NTQtOC4wODIgMC43NDU2MS0xNS40OTEtNi41NDM5LTIzLjQ3NS02LjQ2NjQtNy40OTEzIDAuMDcyNy0xMC4wODEgNC4xMzk5LTE0LjE3IDUuNTgxLTExLjk5MiA0LjIyNy0yNy4xMTQgNS4xMTQtMzIuMDY3LTcuMjk1My0xMC41ODgtMjYuNTI3IDMwLjc2LTY3LjM0MiA0Ny45OTQtNjYuNDk3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="213,180,60,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yNW1tIiBoZWlnaHQ9IjE1My42MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODIuMjUgMTUzLjYxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC4xNDggLTcwLjY0MikiPjxwYXRoIGQ9Im0yMC4yMTcgMjIyLjM0Yy0xMC45NzYtMy4zOTc3LTUuMTM4MS0xNi4yMjQgMi4zODM2LTE5Ljg2IDguNzQ3LTUuNzcwOCAxOC42MDggMC41MzQyNiAyNy41MjgtMi4zMjAzIDguMjQ3Mi0xLjk5NzUgMTguMjQzLTEyLjA4OCA3LjMwOTgtMTcuOTc0LTYuMzYwOC00LjgyMzYtMTUuMDI3LTguNzkzNS0xNi43ODMtMTcuNDU4IDAuMjI1MTgtMTAuMDA0LTMuNjQ4Ni0xOS45NDMtMTMuMTktMjQuNDc3LTQuNTAzOS04LjU2MzEtMy4xOTEyLTE4LjgxMS01LjY3MTItMjguMDA0LTEuMDgtMTAuNjA1IDAuNTAxMTktMjEuMDYyIDIuMTA0LTMxLjQ4NyAxLjAxNDItMTMuMDg0IDE0LjM1LTQuMzgyOSAxOS41OTYgMC45MzIwOSA2LjgwMDkgNi44MTk1IDEyLjEwOSAxNS4xNDEgMTguNTk3IDIyLjM4OSA1LjIzODYgOC43NDI0IDEzLjc3NyAxNC4wMTYgMjIuNDI2IDE4Ljg4IDEwLjcyNyA2LjA3NDIgMTcuNzY3IDE1LjYxNiAyNS4yMjggMjUuMDYzIDEuMTg0IDEuMjk1MSAxLjE1ODEgMi44NDQ3IDEuNTE2NCAzLjE2NTkgMC4yNTI3NyAwLjIyNjU5IDEuMzA0NSAxLjE2MzUgMS44MzM5IDAuODgwODUgMy4wMTM1LTEuOTI4NCA4LjA5NS0xMS44MDIgMTAuMzk2LTE0Ljc2NSA3LjQwODgtMTEuMzc1IDEzLjYwNi0yMy41MDggMjAuOTc1LTM0LjkxOSA1LjMwNjctOS4yMjM3IDEwLjgwMi0xOC40NjQgMTguNzk1LTI1LjY1NyA4LjY1MzgtMTAuNDc2IDE1LjUyLTUuODA4NyAxNy45MjkgMS44Nzg2IDMuMDQyIDkuNzA3OCAxMy4xODYgMTQuMDY4IDExLjA5MiAyNC4yNSAwLjM2MzE2IDkuODU0Ni0wLjE1OTQ0IDIxLjQxMy05LjE3MjcgMjcuNTgtNy4xMzUxIDcuMTAwMS0xOC4wMDkgOS41MDUzLTIzLjk5MSAxNy43NDgtMS42MzI0IDQuODIzLTkuNTY2MyAxOC43NDYtMy42Mjg0IDIxLjkzMyA1LjI5MTgtMC43NDE5OSA3LjY4ODQtNS44NzUyIDExLjc0MS01Ljk5ODggNS4wMDcyIDAgNy4wOTk0LTFlLTUgMTIuMDEyIDAuNzMzMDYgNS44MjIzIDAuODY4NzggMTEuOTY5IDMuODM5MiAxMy43NTcgOC4xODcyIDAuOTY2MDQgMi4zNDk2IDMuMjA2NSA5LjQ5ODggMy4zNTUzIDEyLjY4NSAwLjA5MTggMS45NjY4IDAuMjY0NDkgMy4xMTkxLTIuMDU2NSA0LjIzNy0yLjk4IDEuNDM1My0xNi4wMzggMC4yNjI4OS0xOC4yMy0wLjM3NjU3LTcuOTM4My0yLjMxNS04LjgwOC00LjQ4NDItMTYuMTQ1IDAuMjUwNi03LjkxMDYgNS43ODU0LTE2Ljg1MSAxMS4zMzctMjYuNDIgMTQuMjYxLTE5LjU1IDYuNTg5NS00MC40NTkgMTEuMDkyLTU5LjY1MSAxMC4zMi01Ljk2MzgtMC4yNjQzNC0xMi4zNzQtMS4zNTA0LTE4LjU3IDAuNzgzMjQtMi45NzE4IDEuMDIzNS02LjcwNyA0LjcyOTktOS40NjA4IDYuNDIwOC02LjgzMSAzLjYzMTgtMTQuODUzIDIuNDQ0LTIyLjMzNSAyLjQ2ODMtMS4yMzYgNGUtMyAtMi4xNzk5LTEuMTY1Ni0zLjI2OTgtMS43NDg0eiIgc3Ryb2tlLXdpZHRoPSIuNTUyNjMiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0MC41Nm1tIiBoZWlnaHQ9IjE0My42bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0MC41NiAxNDMuNiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDUuODc2IC03Mi4wMTQpIj48Zz48ZWxsaXBzZSB0cmFuc2Zvcm09Im1hdHJpeCguNjAxNjYgLS43OTg3NSAuNjg2OCAuNzI2ODUgMCAwKSIgY3g9Ii00NC43ODUiIGN5PSIxMzcuOSIgcng9IjIxLjQ0IiByeT0iMjUuNzU0Ii8+PGVsbGlwc2UgdHJhbnNmb3JtPSJtYXRyaXgoLjY1MTI0IC0uNzU4ODcgLjUzMDU4IC44NDc2MyAwIDApIiBjeD0iMzAuOTMiIGN5PSIxNDYuODgiIHJ4PSIyMi4zNCIgcnk9IjI3Ljc3NSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45NTUzNCAtLjI5NTUxIC0uMDA5MzMwMiAuOTk5OTYgMCAwKSIgY3g9IjE0OC4wMyIgY3k9IjE0Ni41NSIgcng9IjIwLjk3NyIgcnk9IjI2LjcwOSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45OTgzOSAtLjA1NjY1NCAtLjI2MzU4IC45NjQ2NCAwIDApIiBjeD0iMjA3LjgzIiBjeT0iMTU5Ljc5IiByeD0iMjAuMTI1IiByeT0iMjMuODkiLz48cGF0aCBkPSJtMTE2Ljg2IDEzOC45OWMxNy42ODQgMC44NjY3MyA0Ny43MjYgMzkuNTk3IDQzLjQxMSA2NC4xMjQtMS4zOTM1IDcuOTE5Ny0xMy42ODYgOS44MTQ4LTIxLjY5MyAxMC41NTQtOC4wODIgMC43NDU2MS0xNS40OTEtNi41NDM5LTIzLjQ3NS02LjQ2NjQtNy40OTEzIDAuMDcyNy0xMC4wODEgNC4xMzk5LTE0LjE3IDUuNTgxLTExLjk5MiA0LjIyNy0yNy4xMTQgNS4xMTQtMzIuMDY3LTcuMjk1My0xMC41ODgtMjYuNTI3IDMwLjc2LTY3LjM0MiA0Ny45OTQtNjYuNDk3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yNW1tIiBoZWlnaHQ9IjE1My42MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODIuMjUgMTUzLjYxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC4xNDggLTcwLjY0MikiPjxwYXRoIGQ9Im0yMC4yMTcgMjIyLjM0Yy0xMC45NzYtMy4zOTc3LTUuMTM4MS0xNi4yMjQgMi4zODM2LTE5Ljg2IDguNzQ3LTUuNzcwOCAxOC42MDggMC41MzQyNiAyNy41MjgtMi4zMjAzIDguMjQ3Mi0xLjk5NzUgMTguMjQzLTEyLjA4OCA3LjMwOTgtMTcuOTc0LTYuMzYwOC00LjgyMzYtMTUuMDI3LTguNzkzNS0xNi43ODMtMTcuNDU4IDAuMjI1MTgtMTAuMDA0LTMuNjQ4Ni0xOS45NDMtMTMuMTktMjQuNDc3LTQuNTAzOS04LjU2MzEtMy4xOTEyLTE4LjgxMS01LjY3MTItMjguMDA0LTEuMDgtMTAuNjA1IDAuNTAxMTktMjEuMDYyIDIuMTA0LTMxLjQ4NyAxLjAxNDItMTMuMDg0IDE0LjM1LTQuMzgyOSAxOS41OTYgMC45MzIwOSA2LjgwMDkgNi44MTk1IDEyLjEwOSAxNS4xNDEgMTguNTk3IDIyLjM4OSA1LjIzODYgOC43NDI0IDEzLjc3NyAxNC4wMTYgMjIuNDI2IDE4Ljg4IDEwLjcyNyA2LjA3NDIgMTcuNzY3IDE1LjYxNiAyNS4yMjggMjUuMDYzIDEuMTg0IDEuMjk1MSAxLjE1ODEgMi44NDQ3IDEuNTE2NCAzLjE2NTkgMC4yNTI3NyAwLjIyNjU5IDEuMzA0NSAxLjE2MzUgMS44MzM5IDAuODgwODUgMy4wMTM1LTEuOTI4NCA4LjA5NS0xMS44MDIgMTAuMzk2LTE0Ljc2NSA3LjQwODgtMTEuMzc1IDEzLjYwNi0yMy41MDggMjAuOTc1LTM0LjkxOSA1LjMwNjctOS4yMjM3IDEwLjgwMi0xOC40NjQgMTguNzk1LTI1LjY1NyA4LjY1MzgtMTAuNDc2IDE1LjUyLTUuODA4NyAxNy45MjkgMS44Nzg2IDMuMDQyIDkuNzA3OCAxMy4xODYgMTQuMDY4IDExLjA5MiAyNC4yNSAwLjM2MzE2IDkuODU0Ni0wLjE1OTQ0IDIxLjQxMy05LjE3MjcgMjcuNTgtNy4xMzUxIDcuMTAwMS0xOC4wMDkgOS41MDUzLTIzLjk5MSAxNy43NDgtMS42MzI0IDQuODIzLTkuNTY2MyAxOC43NDYtMy42Mjg0IDIxLjkzMyA1LjI5MTgtMC43NDE5OSA3LjY4ODQtNS44NzUyIDExLjc0MS01Ljk5ODggNS4wMDcyIDAgNy4wOTk0LTFlLTUgMTIuMDEyIDAuNzMzMDYgNS44MjIzIDAuODY4NzggMTEuOTY5IDMuODM5MiAxMy43NTcgOC4xODcyIDAuOTY2MDQgMi4zNDk2IDMuMjA2NSA5LjQ5ODggMy4zNTUzIDEyLjY4NSAwLjA5MTggMS45NjY4IDAuMjY0NDkgMy4xMTkxLTIuMDU2NSA0LjIzNy0yLjk4IDEuNDM1My0xNi4wMzggMC4yNjI4OS0xOC4yMy0wLjM3NjU3LTcuOTM4My0yLjMxNS04LjgwOC00LjQ4NDItMTYuMTQ1IDAuMjUwNi03LjkxMDYgNS43ODU0LTE2Ljg1MSAxMS4zMzctMjYuNDIgMTQuMjYxLTE5LjU1IDYuNTg5NS00MC40NTkgMTEuMDkyLTU5LjY1MSAxMC4zMi01Ljk2MzgtMC4yNjQzNC0xMi4zNzQtMS4zNTA0LTE4LjU3IDAuNzgzMjQtMi45NzE4IDEuMDIzNS02LjcwNyA0LjcyOTktOS40NjA4IDYuNDIwOC02LjgzMSAzLjYzMTgtMTQuODUzIDIuNDQ0LTIyLjMzNSAyLjQ2ODMtMS4yMzYgNGUtMyAtMi4xNzk5LTEuMTY1Ni0zLjI2OTgtMS43NDg0eiIgc3Ryb2tlLXdpZHRoPSIuNTUyNjMiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0MC41Nm1tIiBoZWlnaHQ9IjE0My42bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0MC41NiAxNDMuNiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDUuODc2IC03Mi4wMTQpIj48Zz48ZWxsaXBzZSB0cmFuc2Zvcm09Im1hdHJpeCguNjAxNjYgLS43OTg3NSAuNjg2OCAuNzI2ODUgMCAwKSIgY3g9Ii00NC43ODUiIGN5PSIxMzcuOSIgcng9IjIxLjQ0IiByeT0iMjUuNzU0Ii8+PGVsbGlwc2UgdHJhbnNmb3JtPSJtYXRyaXgoLjY1MTI0IC0uNzU4ODcgLjUzMDU4IC44NDc2MyAwIDApIiBjeD0iMzAuOTMiIGN5PSIxNDYuODgiIHJ4PSIyMi4zNCIgcnk9IjI3Ljc3NSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45NTUzNCAtLjI5NTUxIC0uMDA5MzMwMiAuOTk5OTYgMCAwKSIgY3g9IjE0OC4wMyIgY3k9IjE0Ni41NSIgcng9IjIwLjk3NyIgcnk9IjI2LjcwOSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45OTgzOSAtLjA1NjY1NCAtLjI2MzU4IC45NjQ2NCAwIDApIiBjeD0iMjA3LjgzIiBjeT0iMTU5Ljc5IiByeD0iMjAuMTI1IiByeT0iMjMuODkiLz48cGF0aCBkPSJtMTE2Ljg2IDEzOC45OWMxNy42ODQgMC44NjY3MyA0Ny43MjYgMzkuNTk3IDQzLjQxMSA2NC4xMjQtMS4zOTM1IDcuOTE5Ny0xMy42ODYgOS44MTQ4LTIxLjY5MyAxMC41NTQtOC4wODIgMC43NDU2MS0xNS40OTEtNi41NDM5LTIzLjQ3NS02LjQ2NjQtNy40OTEzIDAuMDcyNy0xMC4wODEgNC4xMzk5LTE0LjE3IDUuNTgxLTExLjk5MiA0LjIyNy0yNy4xMTQgNS4xMTQtMzIuMDY3LTcuMjk1My0xMC41ODgtMjYuNTI3IDMwLjc2LTY3LjM0MiA0Ny45OTQtNjYuNDk3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="213,180,60,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE4Mi4yNW1tIiBoZWlnaHQ9IjE1My42MW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxODIuMjUgMTUzLjYxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xNC4xNDggLTcwLjY0MikiPjxwYXRoIGQ9Im0yMC4yMTcgMjIyLjM0Yy0xMC45NzYtMy4zOTc3LTUuMTM4MS0xNi4yMjQgMi4zODM2LTE5Ljg2IDguNzQ3LTUuNzcwOCAxOC42MDggMC41MzQyNiAyNy41MjgtMi4zMjAzIDguMjQ3Mi0xLjk5NzUgMTguMjQzLTEyLjA4OCA3LjMwOTgtMTcuOTc0LTYuMzYwOC00LjgyMzYtMTUuMDI3LTguNzkzNS0xNi43ODMtMTcuNDU4IDAuMjI1MTgtMTAuMDA0LTMuNjQ4Ni0xOS45NDMtMTMuMTktMjQuNDc3LTQuNTAzOS04LjU2MzEtMy4xOTEyLTE4LjgxMS01LjY3MTItMjguMDA0LTEuMDgtMTAuNjA1IDAuNTAxMTktMjEuMDYyIDIuMTA0LTMxLjQ4NyAxLjAxNDItMTMuMDg0IDE0LjM1LTQuMzgyOSAxOS41OTYgMC45MzIwOSA2LjgwMDkgNi44MTk1IDEyLjEwOSAxNS4xNDEgMTguNTk3IDIyLjM4OSA1LjIzODYgOC43NDI0IDEzLjc3NyAxNC4wMTYgMjIuNDI2IDE4Ljg4IDEwLjcyNyA2LjA3NDIgMTcuNzY3IDE1LjYxNiAyNS4yMjggMjUuMDYzIDEuMTg0IDEuMjk1MSAxLjE1ODEgMi44NDQ3IDEuNTE2NCAzLjE2NTkgMC4yNTI3NyAwLjIyNjU5IDEuMzA0NSAxLjE2MzUgMS44MzM5IDAuODgwODUgMy4wMTM1LTEuOTI4NCA4LjA5NS0xMS44MDIgMTAuMzk2LTE0Ljc2NSA3LjQwODgtMTEuMzc1IDEzLjYwNi0yMy41MDggMjAuOTc1LTM0LjkxOSA1LjMwNjctOS4yMjM3IDEwLjgwMi0xOC40NjQgMTguNzk1LTI1LjY1NyA4LjY1MzgtMTAuNDc2IDE1LjUyLTUuODA4NyAxNy45MjkgMS44Nzg2IDMuMDQyIDkuNzA3OCAxMy4xODYgMTQuMDY4IDExLjA5MiAyNC4yNSAwLjM2MzE2IDkuODU0Ni0wLjE1OTQ0IDIxLjQxMy05LjE3MjcgMjcuNTgtNy4xMzUxIDcuMTAwMS0xOC4wMDkgOS41MDUzLTIzLjk5MSAxNy43NDgtMS42MzI0IDQuODIzLTkuNTY2MyAxOC43NDYtMy42Mjg0IDIxLjkzMyA1LjI5MTgtMC43NDE5OSA3LjY4ODQtNS44NzUyIDExLjc0MS01Ljk5ODggNS4wMDcyIDAgNy4wOTk0LTFlLTUgMTIuMDEyIDAuNzMzMDYgNS44MjIzIDAuODY4NzggMTEuOTY5IDMuODM5MiAxMy43NTcgOC4xODcyIDAuOTY2MDQgMi4zNDk2IDMuMjA2NSA5LjQ5ODggMy4zNTUzIDEyLjY4NSAwLjA5MTggMS45NjY4IDAuMjY0NDkgMy4xMTkxLTIuMDU2NSA0LjIzNy0yLjk4IDEuNDM1My0xNi4wMzggMC4yNjI4OS0xOC4yMy0wLjM3NjU3LTcuOTM4My0yLjMxNS04LjgwOC00LjQ4NDItMTYuMTQ1IDAuMjUwNi03LjkxMDYgNS43ODU0LTE2Ljg1MSAxMS4zMzctMjYuNDIgMTQuMjYxLTE5LjU1IDYuNTg5NS00MC40NTkgMTEuMDkyLTU5LjY1MSAxMC4zMi01Ljk2MzgtMC4yNjQzNC0xMi4zNzQtMS4zNTA0LTE4LjU3IDAuNzgzMjQtMi45NzE4IDEuMDIzNS02LjcwNyA0LjcyOTktOS40NjA4IDYuNDIwOC02LjgzMSAzLjYzMTgtMTQuODUzIDIuNDQ0LTIyLjMzNSAyLjQ2ODMtMS4yMzYgNGUtMyAtMi4xNzk5LTEuMTY1Ni0zLjI2OTgtMS43NDg0eiIgc3Ryb2tlLXdpZHRoPSIuNTUyNjMiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="164,113,88,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0MC41Nm1tIiBoZWlnaHQ9IjE0My42bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0MC41NiAxNDMuNiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDUuODc2IC03Mi4wMTQpIj48Zz48ZWxsaXBzZSB0cmFuc2Zvcm09Im1hdHJpeCguNjAxNjYgLS43OTg3NSAuNjg2OCAuNzI2ODUgMCAwKSIgY3g9Ii00NC43ODUiIGN5PSIxMzcuOSIgcng9IjIxLjQ0IiByeT0iMjUuNzU0Ii8+PGVsbGlwc2UgdHJhbnNmb3JtPSJtYXRyaXgoLjY1MTI0IC0uNzU4ODcgLjUzMDU4IC44NDc2MyAwIDApIiBjeD0iMzAuOTMiIGN5PSIxNDYuODgiIHJ4PSIyMi4zNCIgcnk9IjI3Ljc3NSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45NTUzNCAtLjI5NTUxIC0uMDA5MzMwMiAuOTk5OTYgMCAwKSIgY3g9IjE0OC4wMyIgY3k9IjE0Ni41NSIgcng9IjIwLjk3NyIgcnk9IjI2LjcwOSIvPjxlbGxpcHNlIHRyYW5zZm9ybT0ibWF0cml4KC45OTgzOSAtLjA1NjY1NCAtLjI2MzU4IC45NjQ2NCAwIDApIiBjeD0iMjA3LjgzIiBjeT0iMTU5Ljc5IiByeD0iMjAuMTI1IiByeT0iMjMuODkiLz48cGF0aCBkPSJtMTE2Ljg2IDEzOC45OWMxNy42ODQgMC44NjY3MyA0Ny43MjYgMzkuNTk3IDQzLjQxMSA2NC4xMjQtMS4zOTM1IDcuOTE5Ny0xMy42ODYgOS44MTQ4LTIxLjY5MyAxMC41NTQtOC4wODIgMC43NDU2MS0xNS40OTEtNi41NDM5LTIzLjQ3NS02LjQ2NjQtNy40OTEzIDAuMDcyNy0xMC4wODEgNC4xMzk5LTE0LjE3IDUuNTgxLTExLjk5MiA0LjIyNy0yNy4xMTQgNS4xMTQtMzIuMDY3LTcuMjk1My0xMC41ODgtMjYuNTI3IDMwLjc2LTY3LjM0MiA0Ny45OTQtNjYuNDk3eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="213,180,60,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Центры реабилитации, репродукции и сохранения животных" value="602050501" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Зверопереходы (экодуки)" value="602050502" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="HZRD_CLASS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="I класс опасности объекта" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="II класс опасности объекта" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="III класс опасности объекта" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="IV класс опасности объекта" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="V класс опасности объекта" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="AREA" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FUNCTION" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к ликвидации" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTROKS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTRZU" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="HZRD_CLASS" index="6" name="Класс опасности объекта в соответствии с санитарной классификацией"/>
    <alias field="AREA" index="7" name="Площадь объекта, га"/>
    <alias field="FUNCTION" index="8" name="Назначение объекта"/>
    <alias field="EVENT_TIME" index="9" name=""/>
    <alias field="SOURCE" index="10" name="Источник данных"/>
    <alias field="NOTE" index="11" name="Примечание"/>
    <alias field="STATUS" index="12" name="Статус объекта"/>
    <alias field="REG_STATUS" index="13" name="Значение объекта"/>
    <alias field="KADASTROKS" index="14" name="Кадастровый номер объекта капитального строительства"/>
    <alias field="KADASTRZU" index="15" name=""/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602050501'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="HZRD_CLASS" expression="" applyOnUpdate="0"/>
    <default field="AREA" expression="0" applyOnUpdate="0"/>
    <default field="FUNCTION" expression="''" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
    <default field="KADASTROKS" expression="''" applyOnUpdate="0"/>
    <default field="KADASTRZU" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="HZRD_CLASS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="AREA" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FUNCTION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="2" field="KADASTROKS" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="KADASTRZU" unique_strength="0" notnull_strength="0" constraints="4"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="HZRD_CLASS" desc="" exp=""/>
    <constraint field="AREA" desc="" exp=""/>
    <constraint field="FUNCTION" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
    <constraint field="KADASTROKS" desc="Кадастровый номер объекта должен соответствовать формату, принятому в ЕГРН." exp="regexp_match(&quot;KADASTROKS&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$')"/>
    <constraint field="KADASTRZU" desc="Обязательно для значений атрибута &quot;STATUS&quot; 1, 3, 4." exp="if (&quot;STATUS&quot; = 1 OR &quot;STATUS&quot; = 3 OR &quot;STATUS&quot; = 4,&#xd;&#xa;&#x9;regexp_match(&quot;KADASTRZU&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$|^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1})$'),&#xd;&#xa;&#x9;length(&quot;KADASTRZU&quot;) >= 0)"/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="12" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="6" name="HZRD_CLASS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="7" name="AREA">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="8" name="FUNCTION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="10" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="11" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="14" name="KADASTROKS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="9" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Кадастровый номер земельного участка и (или) номер кадастрового квартала, к границах которого расположен объект" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (1, 3, 4)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="15" name="KADASTRZU">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="AREA" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="FUNCTION" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="HZRD_CLASS" editable="1"/>
    <field name="KADASTROKS" editable="1"/>
    <field name="KADASTRZU" editable="1"/>
    <field name="NAME" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="AREA"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="FUNCTION"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="HZRD_CLASS"/>
    <field labelOnTop="1" name="KADASTROKS"/>
    <field labelOnTop="1" name="KADASTRZU"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="AREA" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="FUNCTION" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="HZRD_CLASS" reuseLastValue="0"/>
    <field name="KADASTROKS" reuseLastValue="0"/>
    <field name="KADASTRZU" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
