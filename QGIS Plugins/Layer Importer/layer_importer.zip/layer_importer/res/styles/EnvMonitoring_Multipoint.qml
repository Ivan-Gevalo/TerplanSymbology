<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{04068981-27ea-43bc-bebf-a57e66c21b33}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{3271b7ab-ca43-4b52-8bd9-b870cc544cc9}">
        <rule label="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" filter="&quot;CLASSID&quot; = '602050401'" symbol="1" key="{087f5b6a-8522-45f6-8182-b37e94ccf588}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="2" key="{69870e04-6d5a-43a6-9b60-cc7d55ccfe7a}">
        <rule label="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" filter="&quot;CLASSID&quot; = '602050401'" symbol="3" key="{dfed27ce-8bbc-4960-b524-caf890d8f76f}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="4" key="{cb2c8e2c-cc1d-428e-bd7d-50c91f8476e7}">
        <rule label="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" filter="&quot;CLASSID&quot; = '602050401'" symbol="5" key="{5fd7c126-0a9f-496d-b522-a79972470114}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="6" key="{fc990c62-335b-402c-bd58-c64b623b7a80}">
        <rule label="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" filter="&quot;CLASSID&quot; = '602050401'" symbol="7" key="{de2eeeaf-5a82-487b-b99a-4b9c12059aa2}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="8" key="{6637d7c0-c1b9-4ec7-a8e2-87db1decf3cc}">
        <rule label="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" filter="&quot;CLASSID&quot; = '602050401'" symbol="9" key="{28fd74d7-4fd0-4a27-886c-a0a3e19f249a}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="10" key="{61e5185b-bfd8-41d4-b5ad-81d4cd7027bd}">
        <rule label="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" filter="&quot;CLASSID&quot; = '602050401'" symbol="11" key="{77f096b8-b5a8-433f-9869-54d9ebf20810}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="12" key="{39d81352-a0a7-466d-bccf-2d98a8641f55}">
        <rule label="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" filter="&quot;CLASSID&quot; = '602050401'" symbol="13" key="{f23c0e48-7d0d-40d1-a61e-f41074e6f7ad}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты регионального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 2" symbol="14" key="{bdf43312-d581-48e7-8d72-2c3a1d93c0fe}">
        <rule label="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" filter="&quot;CLASSID&quot; = '602050401'" symbol="15" key="{f3c9cfe1-180f-4c45-bcf9-39b07b0f8917}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="16" key="{8781bc91-7c5a-4b45-a242-4e955d3943da}">
        <rule label="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" filter="&quot;CLASSID&quot; = '602050401'" symbol="17" key="{b0f82122-f752-4de1-8881-a52b137432c6}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="18" key="{88d6d7a3-435c-4fd1-b985-40b6384b219d}">
        <rule label="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" filter="&quot;CLASSID&quot; = '602050401'" symbol="19" key="{febbcae6-8971-4805-a63c-73bb2f9e7174}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="20" key="{53679d2f-1b74-44d5-aee6-ea18707c23f7}">
        <rule label="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" filter="&quot;CLASSID&quot; = '602050401'" symbol="21" key="{5978f871-680c-4776-95fe-22ad95b167e7}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты федерального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 1" symbol="22" key="{c83556ee-abbe-4194-9481-49a98d34402d}">
        <rule label="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" filter="&quot;CLASSID&quot; = '602050401'" symbol="23" key="{57430bd7-8697-45cc-8f7a-c7fb076bcfa6}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny4wNm1tIiBoZWlnaHQ9IjEyNy4zMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuMDYgMTI3LjMxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41OTIgLTc5LjA0KSI+PHBhdGggZD0ibTY0LjI3NyA3OS4wNHYxOC4wNTRjMS43MzAxLTIuMTY3OCAzLjcxODktMi4wMzI2IDUuNjk4Ni0xLjc2MzggMS4zOTEyIDAuMTg4OSAyLjc3NzkgMC40NDM3NiA0LjA2NzIgMC4wMTE3di0xNi4zMDJ6bTAgNjcuMzIxdjU5Ljk4OWg5Ljc2NTh2LTU2LjA4M2wtMy4wNTM0LTMuMDk2czAuMzg1MTggMC4xNTUzNy0zLjMzNjYtMC4xOTIwNmMtMC45Mjg0NC0wLjA4NjctMS44NDU0LTAuMzAxNDItMy4zNzU4LTAuNjE3MTR6Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSIxNzguNDEiIGN5PSIxNDEuMDUiIHI9IjguNzYxMiIgc3Ryb2tlLXdpZHRoPSIyLjk2OCIvPjxwYXRoIGQ9Im0xNzguNDEgMTQ5LjgxaC0xMDYuNzUiIHN0cm9rZS13aWR0aD0iMy4wMDIiLz48cGF0aCBkPSJtNjkuMzQ2IDk1LjA3MWMtMTQuNDAxIDAuNzU0MDItMjUuNjk0IDEyLjY0Ni0yNS43MDIgMjcuMDY3IDAuMDA4MyAxNC40MjEgMTEuMzAxIDI2LjMxNCAyNS43MDIgMjcuMDY4IiBzdHJva2Utd2lkdGg9IjQuMTAzMyIvPjxwYXRoIGQ9Im0xODEuMDMgMTMyLjY4LTk2LjQ0OC0zNi4yMDYiIHN0cm9rZS13aWR0aD0iMi45NiIvPjwvZz48Zz48cGF0aCBkPSJtMTUyLjU2IDE0OS41NGMtNC41MzE4LTIuODYzLTcuOTk3Ni04LjUwMzctNy40MDU1LTE0LjEzIDAuNTQ3ODgtNS4yMDU2IDYuOTU1NS05Ljg4MTggMTEuOTQ5LTExLjA1MSA2LjYwODYtMS41NDY5IDE5LjIyNSA2LjcwOSAxOS4yMjUgNi43MDlzLTUuNjM5NyA1LjAzNC02LjIyNzggOC40OTU2Yy0wLjU4MjkzIDMuNDMxMSAzLjA0NTUgOS45ODY3IDMuMDQ1NSA5Ljk4NjdzLTE0Ljg3OCAzLjU5NTItMjAuNTg2LTAuMDExeiIvPjxwYXRoIGQ9Im0xMTQuOTEgMTUwLjU2Yy04Ljc1OTgtNS43OTIyLTExLjY2OC0xNS4yOTItOS42MjQzLTIzLjk5IDEuOTQyMS04LjI2NTggOC43MTg2LTE1LjU3MSAyMC4zMDktMTQuNTY2bDE1LjI0NSA1Ljg2NzFjLTkuNjgxNiAyLjM5NTItMTMuMjM3IDcuMDI0NC0xNC43NDggMTMuNTItMS41NTk1IDYuNzA0IDEuNTk2NyAxNC4xNjIgNy40OTk4IDE5LjIzOXoiLz48cGF0aCBkPSJtOTQuOTkxIDE1MC4yN2MtOS4wMDkyLTguMzI5NC0xNC4xMTUtMTguNTcxLTExLjg4NS0yOC42NzQgMS44ODE1LTguNTI3MiA4LjgzMDUtMTcuNzMyIDE5LjI4My0xNy43MzIgOC4yMSAwLTguNzQ2Ny00LjgyMzgtMTMuNDYtNC40NjUyLTEwLjEwNCAwLjc2ODY2LTIxLjUzNCA1LjM0MTctMjcuMDc0IDEzLjgyNi0zLjc5NTYgNS44MTI1LTMuMjYzMiAxNi4zNy0xLjIxMzkgMjAuNzkxIDMuMTE2NSA2LjcyMjcgNi41NjYzIDEyLjQwNiAxMi40NTkgMTUuMzYzIDYuNTI3NSAzLjI3NTIgMjEuODkxIDAuODkxNzcgMjEuODkxIDAuODkxNzd6Ii8+PHBhdGggZD0ibTY4LjM5OSA5Ny4xOTdzNS43MTc2LTAuMDU0OTEgOC40Mzk2IDAuNjkyMDhjMy4yOTE2IDAuOTAzMjkgOS4yMDMyIDQuNDg5NCA5LjIwMzIgNC40ODk0bDUuMzY0OC0zLjQyMzdzLTYuMjI0OS01LjEyMDMtMTAuNjg0LTQuNzk3NmMtNC4wOTk3IDAuMjk2NzQtMTIuMzItMC41MzExOC0xMi4zMi0wLjUzMTE4eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0.20000000000000001,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny4wNm1tIiBoZWlnaHQ9IjEyNy4zMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuMDYgMTI3LjMxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41OTIgLTc5LjA0KSI+PHBhdGggZD0ibTY0LjI3NyA3OS4wNHYxOC4wNTRjMS43MzAxLTIuMTY3OCAzLjcxODktMi4wMzI2IDUuNjk4Ni0xLjc2MzggMS4zOTEyIDAuMTg4OSAyLjc3NzkgMC40NDM3NiA0LjA2NzIgMC4wMTE3di0xNi4zMDJ6bTAgNjcuMzIxdjU5Ljk4OWg5Ljc2NTh2LTU2LjA4M2wtMy4wNTM0LTMuMDk2czAuMzg1MTggMC4xNTUzNy0zLjMzNjYtMC4xOTIwNmMtMC45Mjg0NC0wLjA4NjctMS44NDU0LTAuMzAxNDItMy4zNzU4LTAuNjE3MTR6Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSIxNzguNDEiIGN5PSIxNDEuMDUiIHI9IjguNzYxMiIgc3Ryb2tlLXdpZHRoPSIyLjk2OCIvPjxwYXRoIGQ9Im0xNzguNDEgMTQ5LjgxaC0xMDYuNzUiIHN0cm9rZS13aWR0aD0iMy4wMDIiLz48cGF0aCBkPSJtNjkuMzQ2IDk1LjA3MWMtMTQuNDAxIDAuNzU0MDItMjUuNjk0IDEyLjY0Ni0yNS43MDIgMjcuMDY3IDAuMDA4MyAxNC40MjEgMTEuMzAxIDI2LjMxNCAyNS43MDIgMjcuMDY4IiBzdHJva2Utd2lkdGg9IjQuMTAzMyIvPjxwYXRoIGQ9Im0xODEuMDMgMTMyLjY4LTk2LjQ0OC0zNi4yMDYiIHN0cm9rZS13aWR0aD0iMi45NiIvPjwvZz48Zz48cGF0aCBkPSJtMTUyLjU2IDE0OS41NGMtNC41MzE4LTIuODYzLTcuOTk3Ni04LjUwMzctNy40MDU1LTE0LjEzIDAuNTQ3ODgtNS4yMDU2IDYuOTU1NS05Ljg4MTggMTEuOTQ5LTExLjA1MSA2LjYwODYtMS41NDY5IDE5LjIyNSA2LjcwOSAxOS4yMjUgNi43MDlzLTUuNjM5NyA1LjAzNC02LjIyNzggOC40OTU2Yy0wLjU4MjkzIDMuNDMxMSAzLjA0NTUgOS45ODY3IDMuMDQ1NSA5Ljk4NjdzLTE0Ljg3OCAzLjU5NTItMjAuNTg2LTAuMDExeiIvPjxwYXRoIGQ9Im0xMTQuOTEgMTUwLjU2Yy04Ljc1OTgtNS43OTIyLTExLjY2OC0xNS4yOTItOS42MjQzLTIzLjk5IDEuOTQyMS04LjI2NTggOC43MTg2LTE1LjU3MSAyMC4zMDktMTQuNTY2bDE1LjI0NSA1Ljg2NzFjLTkuNjgxNiAyLjM5NTItMTMuMjM3IDcuMDI0NC0xNC43NDggMTMuNTItMS41NTk1IDYuNzA0IDEuNTk2NyAxNC4xNjIgNy40OTk4IDE5LjIzOXoiLz48cGF0aCBkPSJtOTQuOTkxIDE1MC4yN2MtOS4wMDkyLTguMzI5NC0xNC4xMTUtMTguNTcxLTExLjg4NS0yOC42NzQgMS44ODE1LTguNTI3MiA4LjgzMDUtMTcuNzMyIDE5LjI4My0xNy43MzIgOC4yMSAwLTguNzQ2Ny00LjgyMzgtMTMuNDYtNC40NjUyLTEwLjEwNCAwLjc2ODY2LTIxLjUzNCA1LjM0MTctMjcuMDc0IDEzLjgyNi0zLjc5NTYgNS44MTI1LTMuMjYzMiAxNi4zNy0xLjIxMzkgMjAuNzkxIDMuMTE2NSA2LjcyMjcgNi41NjYzIDEyLjQwNiAxMi40NTkgMTUuMzYzIDYuNTI3NSAzLjI3NTIgMjEuODkxIDAuODkxNzcgMjEuODkxIDAuODkxNzd6Ii8+PHBhdGggZD0ibTY4LjM5OSA5Ny4xOTdzNS43MTc2LTAuMDU0OTEgOC40Mzk2IDAuNjkyMDhjMy4yOTE2IDAuOTAzMjkgOS4yMDMyIDQuNDg5NCA5LjIwMzIgNC40ODk0bDUuMzY0OC0zLjQyMzdzLTYuMjI0OS01LjEyMDMtMTAuNjg0LTQuNzk3NmMtNC4wOTk3IDAuMjk2NzQtMTIuMzItMC41MzExOC0xMi4zMi0wLjUzMTE4eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0.20000000000000001,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny4wNm1tIiBoZWlnaHQ9IjEyNy4zMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuMDYgMTI3LjMxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41OTIgLTc5LjA0KSI+PHBhdGggZD0ibTY0LjI3NyA3OS4wNHYxOC4wNTRjMS43MzAxLTIuMTY3OCAzLjcxODktMi4wMzI2IDUuNjk4Ni0xLjc2MzggMS4zOTEyIDAuMTg4OSAyLjc3NzkgMC40NDM3NiA0LjA2NzIgMC4wMTE3di0xNi4zMDJ6bTAgNjcuMzIxdjU5Ljk4OWg5Ljc2NTh2LTU2LjA4M2wtMy4wNTM0LTMuMDk2czAuMzg1MTggMC4xNTUzNy0zLjMzNjYtMC4xOTIwNmMtMC45Mjg0NC0wLjA4NjctMS44NDU0LTAuMzAxNDItMy4zNzU4LTAuNjE3MTR6Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSIxNzguNDEiIGN5PSIxNDEuMDUiIHI9IjguNzYxMiIgc3Ryb2tlLXdpZHRoPSIyLjk2OCIvPjxwYXRoIGQ9Im0xNzguNDEgMTQ5LjgxaC0xMDYuNzUiIHN0cm9rZS13aWR0aD0iMy4wMDIiLz48cGF0aCBkPSJtNjkuMzQ2IDk1LjA3MWMtMTQuNDAxIDAuNzU0MDItMjUuNjk0IDEyLjY0Ni0yNS43MDIgMjcuMDY3IDAuMDA4MyAxNC40MjEgMTEuMzAxIDI2LjMxNCAyNS43MDIgMjcuMDY4IiBzdHJva2Utd2lkdGg9IjQuMTAzMyIvPjxwYXRoIGQ9Im0xODEuMDMgMTMyLjY4LTk2LjQ0OC0zNi4yMDYiIHN0cm9rZS13aWR0aD0iMi45NiIvPjwvZz48Zz48cGF0aCBkPSJtMTUyLjU2IDE0OS41NGMtNC41MzE4LTIuODYzLTcuOTk3Ni04LjUwMzctNy40MDU1LTE0LjEzIDAuNTQ3ODgtNS4yMDU2IDYuOTU1NS05Ljg4MTggMTEuOTQ5LTExLjA1MSA2LjYwODYtMS41NDY5IDE5LjIyNSA2LjcwOSAxOS4yMjUgNi43MDlzLTUuNjM5NyA1LjAzNC02LjIyNzggOC40OTU2Yy0wLjU4MjkzIDMuNDMxMSAzLjA0NTUgOS45ODY3IDMuMDQ1NSA5Ljk4NjdzLTE0Ljg3OCAzLjU5NTItMjAuNTg2LTAuMDExeiIvPjxwYXRoIGQ9Im0xMTQuOTEgMTUwLjU2Yy04Ljc1OTgtNS43OTIyLTExLjY2OC0xNS4yOTItOS42MjQzLTIzLjk5IDEuOTQyMS04LjI2NTggOC43MTg2LTE1LjU3MSAyMC4zMDktMTQuNTY2bDE1LjI0NSA1Ljg2NzFjLTkuNjgxNiAyLjM5NTItMTMuMjM3IDcuMDI0NC0xNC43NDggMTMuNTItMS41NTk1IDYuNzA0IDEuNTk2NyAxNC4xNjIgNy40OTk4IDE5LjIzOXoiLz48cGF0aCBkPSJtOTQuOTkxIDE1MC4yN2MtOS4wMDkyLTguMzI5NC0xNC4xMTUtMTguNTcxLTExLjg4NS0yOC42NzQgMS44ODE1LTguNTI3MiA4LjgzMDUtMTcuNzMyIDE5LjI4My0xNy43MzIgOC4yMSAwLTguNzQ2Ny00LjgyMzgtMTMuNDYtNC40NjUyLTEwLjEwNCAwLjc2ODY2LTIxLjUzNCA1LjM0MTctMjcuMDc0IDEzLjgyNi0zLjc5NTYgNS44MTI1LTMuMjYzMiAxNi4zNy0xLjIxMzkgMjAuNzkxIDMuMTE2NSA2LjcyMjcgNi41NjYzIDEyLjQwNiAxMi40NTkgMTUuMzYzIDYuNTI3NSAzLjI3NTIgMjEuODkxIDAuODkxNzcgMjEuODkxIDAuODkxNzd6Ii8+PHBhdGggZD0ibTY4LjM5OSA5Ny4xOTdzNS43MTc2LTAuMDU0OTEgOC40Mzk2IDAuNjkyMDhjMy4yOTE2IDAuOTAzMjkgOS4yMDMyIDQuNDg5NCA5LjIwMzIgNC40ODk0bDUuMzY0OC0zLjQyMzdzLTYuMjI0OS01LjEyMDMtMTAuNjg0LTQuNzk3NmMtNC4wOTk3IDAuMjk2NzQtMTIuMzItMC41MzExOC0xMi4zMi0wLjUzMTE4eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0.20000000000000001,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny4wNm1tIiBoZWlnaHQ9IjEyNy4zMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuMDYgMTI3LjMxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41OTIgLTc5LjA0KSI+PHBhdGggZD0ibTY0LjI3NyA3OS4wNHYxOC4wNTRjMS43MzAxLTIuMTY3OCAzLjcxODktMi4wMzI2IDUuNjk4Ni0xLjc2MzggMS4zOTEyIDAuMTg4OSAyLjc3NzkgMC40NDM3NiA0LjA2NzIgMC4wMTE3di0xNi4zMDJ6bTAgNjcuMzIxdjU5Ljk4OWg5Ljc2NTh2LTU2LjA4M2wtMy4wNTM0LTMuMDk2czAuMzg1MTggMC4xNTUzNy0zLjMzNjYtMC4xOTIwNmMtMC45Mjg0NC0wLjA4NjctMS44NDU0LTAuMzAxNDItMy4zNzU4LTAuNjE3MTR6Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSIxNzguNDEiIGN5PSIxNDEuMDUiIHI9IjguNzYxMiIgc3Ryb2tlLXdpZHRoPSIyLjk2OCIvPjxwYXRoIGQ9Im0xNzguNDEgMTQ5LjgxaC0xMDYuNzUiIHN0cm9rZS13aWR0aD0iMy4wMDIiLz48cGF0aCBkPSJtNjkuMzQ2IDk1LjA3MWMtMTQuNDAxIDAuNzU0MDItMjUuNjk0IDEyLjY0Ni0yNS43MDIgMjcuMDY3IDAuMDA4MyAxNC40MjEgMTEuMzAxIDI2LjMxNCAyNS43MDIgMjcuMDY4IiBzdHJva2Utd2lkdGg9IjQuMTAzMyIvPjxwYXRoIGQ9Im0xODEuMDMgMTMyLjY4LTk2LjQ0OC0zNi4yMDYiIHN0cm9rZS13aWR0aD0iMi45NiIvPjwvZz48Zz48cGF0aCBkPSJtMTUyLjU2IDE0OS41NGMtNC41MzE4LTIuODYzLTcuOTk3Ni04LjUwMzctNy40MDU1LTE0LjEzIDAuNTQ3ODgtNS4yMDU2IDYuOTU1NS05Ljg4MTggMTEuOTQ5LTExLjA1MSA2LjYwODYtMS41NDY5IDE5LjIyNSA2LjcwOSAxOS4yMjUgNi43MDlzLTUuNjM5NyA1LjAzNC02LjIyNzggOC40OTU2Yy0wLjU4MjkzIDMuNDMxMSAzLjA0NTUgOS45ODY3IDMuMDQ1NSA5Ljk4NjdzLTE0Ljg3OCAzLjU5NTItMjAuNTg2LTAuMDExeiIvPjxwYXRoIGQ9Im0xMTQuOTEgMTUwLjU2Yy04Ljc1OTgtNS43OTIyLTExLjY2OC0xNS4yOTItOS42MjQzLTIzLjk5IDEuOTQyMS04LjI2NTggOC43MTg2LTE1LjU3MSAyMC4zMDktMTQuNTY2bDE1LjI0NSA1Ljg2NzFjLTkuNjgxNiAyLjM5NTItMTMuMjM3IDcuMDI0NC0xNC43NDggMTMuNTItMS41NTk1IDYuNzA0IDEuNTk2NyAxNC4xNjIgNy40OTk4IDE5LjIzOXoiLz48cGF0aCBkPSJtOTQuOTkxIDE1MC4yN2MtOS4wMDkyLTguMzI5NC0xNC4xMTUtMTguNTcxLTExLjg4NS0yOC42NzQgMS44ODE1LTguNTI3MiA4LjgzMDUtMTcuNzMyIDE5LjI4My0xNy43MzIgOC4yMSAwLTguNzQ2Ny00LjgyMzgtMTMuNDYtNC40NjUyLTEwLjEwNCAwLjc2ODY2LTIxLjUzNCA1LjM0MTctMjcuMDc0IDEzLjgyNi0zLjc5NTYgNS44MTI1LTMuMjYzMiAxNi4zNy0xLjIxMzkgMjAuNzkxIDMuMTE2NSA2LjcyMjcgNi41NjYzIDEyLjQwNiAxMi40NTkgMTUuMzYzIDYuNTI3NSAzLjI3NTIgMjEuODkxIDAuODkxNzcgMjEuODkxIDAuODkxNzd6Ii8+PHBhdGggZD0ibTY4LjM5OSA5Ny4xOTdzNS43MTc2LTAuMDU0OTEgOC40Mzk2IDAuNjkyMDhjMy4yOTE2IDAuOTAzMjkgOS4yMDMyIDQuNDg5NCA5LjIwMzIgNC40ODk0bDUuMzY0OC0zLjQyMzdzLTYuMjI0OS01LjEyMDMtMTAuNjg0LTQuNzk3NmMtNC4wOTk3IDAuMjk2NzQtMTIuMzItMC41MzExOC0xMi4zMi0wLjUzMTE4eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0.20000000000000001,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny4wNm1tIiBoZWlnaHQ9IjEyNy4zMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuMDYgMTI3LjMxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41OTIgLTc5LjA0KSI+PHBhdGggZD0ibTY0LjI3NyA3OS4wNHYxOC4wNTRjMS43MzAxLTIuMTY3OCAzLjcxODktMi4wMzI2IDUuNjk4Ni0xLjc2MzggMS4zOTEyIDAuMTg4OSAyLjc3NzkgMC40NDM3NiA0LjA2NzIgMC4wMTE3di0xNi4zMDJ6bTAgNjcuMzIxdjU5Ljk4OWg5Ljc2NTh2LTU2LjA4M2wtMy4wNTM0LTMuMDk2czAuMzg1MTggMC4xNTUzNy0zLjMzNjYtMC4xOTIwNmMtMC45Mjg0NC0wLjA4NjctMS44NDU0LTAuMzAxNDItMy4zNzU4LTAuNjE3MTR6Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSIxNzguNDEiIGN5PSIxNDEuMDUiIHI9IjguNzYxMiIgc3Ryb2tlLXdpZHRoPSIyLjk2OCIvPjxwYXRoIGQ9Im0xNzguNDEgMTQ5LjgxaC0xMDYuNzUiIHN0cm9rZS13aWR0aD0iMy4wMDIiLz48cGF0aCBkPSJtNjkuMzQ2IDk1LjA3MWMtMTQuNDAxIDAuNzU0MDItMjUuNjk0IDEyLjY0Ni0yNS43MDIgMjcuMDY3IDAuMDA4MyAxNC40MjEgMTEuMzAxIDI2LjMxNCAyNS43MDIgMjcuMDY4IiBzdHJva2Utd2lkdGg9IjQuMTAzMyIvPjxwYXRoIGQ9Im0xODEuMDMgMTMyLjY4LTk2LjQ0OC0zNi4yMDYiIHN0cm9rZS13aWR0aD0iMi45NiIvPjwvZz48Zz48cGF0aCBkPSJtMTUyLjU2IDE0OS41NGMtNC41MzE4LTIuODYzLTcuOTk3Ni04LjUwMzctNy40MDU1LTE0LjEzIDAuNTQ3ODgtNS4yMDU2IDYuOTU1NS05Ljg4MTggMTEuOTQ5LTExLjA1MSA2LjYwODYtMS41NDY5IDE5LjIyNSA2LjcwOSAxOS4yMjUgNi43MDlzLTUuNjM5NyA1LjAzNC02LjIyNzggOC40OTU2Yy0wLjU4MjkzIDMuNDMxMSAzLjA0NTUgOS45ODY3IDMuMDQ1NSA5Ljk4NjdzLTE0Ljg3OCAzLjU5NTItMjAuNTg2LTAuMDExeiIvPjxwYXRoIGQ9Im0xMTQuOTEgMTUwLjU2Yy04Ljc1OTgtNS43OTIyLTExLjY2OC0xNS4yOTItOS42MjQzLTIzLjk5IDEuOTQyMS04LjI2NTggOC43MTg2LTE1LjU3MSAyMC4zMDktMTQuNTY2bDE1LjI0NSA1Ljg2NzFjLTkuNjgxNiAyLjM5NTItMTMuMjM3IDcuMDI0NC0xNC43NDggMTMuNTItMS41NTk1IDYuNzA0IDEuNTk2NyAxNC4xNjIgNy40OTk4IDE5LjIzOXoiLz48cGF0aCBkPSJtOTQuOTkxIDE1MC4yN2MtOS4wMDkyLTguMzI5NC0xNC4xMTUtMTguNTcxLTExLjg4NS0yOC42NzQgMS44ODE1LTguNTI3MiA4LjgzMDUtMTcuNzMyIDE5LjI4My0xNy43MzIgOC4yMSAwLTguNzQ2Ny00LjgyMzgtMTMuNDYtNC40NjUyLTEwLjEwNCAwLjc2ODY2LTIxLjUzNCA1LjM0MTctMjcuMDc0IDEzLjgyNi0zLjc5NTYgNS44MTI1LTMuMjYzMiAxNi4zNy0xLjIxMzkgMjAuNzkxIDMuMTE2NSA2LjcyMjcgNi41NjYzIDEyLjQwNiAxMi40NTkgMTUuMzYzIDYuNTI3NSAzLjI3NTIgMjEuODkxIDAuODkxNzcgMjEuODkxIDAuODkxNzd6Ii8+PHBhdGggZD0ibTY4LjM5OSA5Ny4xOTdzNS43MTc2LTAuMDU0OTEgOC40Mzk2IDAuNjkyMDhjMy4yOTE2IDAuOTAzMjkgOS4yMDMyIDQuNDg5NCA5LjIwMzIgNC40ODk0bDUuMzY0OC0zLjQyMzdzLTYuMjI0OS01LjEyMDMtMTAuNjg0LTQuNzk3NmMtNC4wOTk3IDAuMjk2NzQtMTIuMzItMC41MzExOC0xMi4zMi0wLjUzMTE4eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0.20000000000000004,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny4wNm1tIiBoZWlnaHQ9IjEyNy4zMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuMDYgMTI3LjMxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41OTIgLTc5LjA0KSI+PHBhdGggZD0ibTY0LjI3NyA3OS4wNHYxOC4wNTRjMS43MzAxLTIuMTY3OCAzLjcxODktMi4wMzI2IDUuNjk4Ni0xLjc2MzggMS4zOTEyIDAuMTg4OSAyLjc3NzkgMC40NDM3NiA0LjA2NzIgMC4wMTE3di0xNi4zMDJ6bTAgNjcuMzIxdjU5Ljk4OWg5Ljc2NTh2LTU2LjA4M2wtMy4wNTM0LTMuMDk2czAuMzg1MTggMC4xNTUzNy0zLjMzNjYtMC4xOTIwNmMtMC45Mjg0NC0wLjA4NjctMS44NDU0LTAuMzAxNDItMy4zNzU4LTAuNjE3MTR6Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSIxNzguNDEiIGN5PSIxNDEuMDUiIHI9IjguNzYxMiIgc3Ryb2tlLXdpZHRoPSIyLjk2OCIvPjxwYXRoIGQ9Im0xNzguNDEgMTQ5LjgxaC0xMDYuNzUiIHN0cm9rZS13aWR0aD0iMy4wMDIiLz48cGF0aCBkPSJtNjkuMzQ2IDk1LjA3MWMtMTQuNDAxIDAuNzU0MDItMjUuNjk0IDEyLjY0Ni0yNS43MDIgMjcuMDY3IDAuMDA4MyAxNC40MjEgMTEuMzAxIDI2LjMxNCAyNS43MDIgMjcuMDY4IiBzdHJva2Utd2lkdGg9IjQuMTAzMyIvPjxwYXRoIGQ9Im0xODEuMDMgMTMyLjY4LTk2LjQ0OC0zNi4yMDYiIHN0cm9rZS13aWR0aD0iMi45NiIvPjwvZz48Zz48cGF0aCBkPSJtMTUyLjU2IDE0OS41NGMtNC41MzE4LTIuODYzLTcuOTk3Ni04LjUwMzctNy40MDU1LTE0LjEzIDAuNTQ3ODgtNS4yMDU2IDYuOTU1NS05Ljg4MTggMTEuOTQ5LTExLjA1MSA2LjYwODYtMS41NDY5IDE5LjIyNSA2LjcwOSAxOS4yMjUgNi43MDlzLTUuNjM5NyA1LjAzNC02LjIyNzggOC40OTU2Yy0wLjU4MjkzIDMuNDMxMSAzLjA0NTUgOS45ODY3IDMuMDQ1NSA5Ljk4NjdzLTE0Ljg3OCAzLjU5NTItMjAuNTg2LTAuMDExeiIvPjxwYXRoIGQ9Im0xMTQuOTEgMTUwLjU2Yy04Ljc1OTgtNS43OTIyLTExLjY2OC0xNS4yOTItOS42MjQzLTIzLjk5IDEuOTQyMS04LjI2NTggOC43MTg2LTE1LjU3MSAyMC4zMDktMTQuNTY2bDE1LjI0NSA1Ljg2NzFjLTkuNjgxNiAyLjM5NTItMTMuMjM3IDcuMDI0NC0xNC43NDggMTMuNTItMS41NTk1IDYuNzA0IDEuNTk2NyAxNC4xNjIgNy40OTk4IDE5LjIzOXoiLz48cGF0aCBkPSJtOTQuOTkxIDE1MC4yN2MtOS4wMDkyLTguMzI5NC0xNC4xMTUtMTguNTcxLTExLjg4NS0yOC42NzQgMS44ODE1LTguNTI3MiA4LjgzMDUtMTcuNzMyIDE5LjI4My0xNy43MzIgOC4yMSAwLTguNzQ2Ny00LjgyMzgtMTMuNDYtNC40NjUyLTEwLjEwNCAwLjc2ODY2LTIxLjUzNCA1LjM0MTctMjcuMDc0IDEzLjgyNi0zLjc5NTYgNS44MTI1LTMuMjYzMiAxNi4zNy0xLjIxMzkgMjAuNzkxIDMuMTE2NSA2LjcyMjcgNi41NjYzIDEyLjQwNiAxMi40NTkgMTUuMzYzIDYuNTI3NSAzLjI3NTIgMjEuODkxIDAuODkxNzcgMjEuODkxIDAuODkxNzd6Ii8+PHBhdGggZD0ibTY4LjM5OSA5Ny4xOTdzNS43MTc2LTAuMDU0OTEgOC40Mzk2IDAuNjkyMDhjMy4yOTE2IDAuOTAzMjkgOS4yMDMyIDQuNDg5NCA5LjIwMzIgNC40ODk0bDUuMzY0OC0zLjQyMzdzLTYuMjI0OS01LjEyMDMtMTAuNjg0LTQuNzk3NmMtNC4wOTk3IDAuMjk2NzQtMTIuMzItMC41MzExOC0xMi4zMi0wLjUzMTE4eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0.20000000000000001,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny4wNm1tIiBoZWlnaHQ9IjEyNy4zMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuMDYgMTI3LjMxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41OTIgLTc5LjA0KSI+PHBhdGggZD0ibTY0LjI3NyA3OS4wNHYxOC4wNTRjMS43MzAxLTIuMTY3OCAzLjcxODktMi4wMzI2IDUuNjk4Ni0xLjc2MzggMS4zOTEyIDAuMTg4OSAyLjc3NzkgMC40NDM3NiA0LjA2NzIgMC4wMTE3di0xNi4zMDJ6bTAgNjcuMzIxdjU5Ljk4OWg5Ljc2NTh2LTU2LjA4M2wtMy4wNTM0LTMuMDk2czAuMzg1MTggMC4xNTUzNy0zLjMzNjYtMC4xOTIwNmMtMC45Mjg0NC0wLjA4NjctMS44NDU0LTAuMzAxNDItMy4zNzU4LTAuNjE3MTR6Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSIxNzguNDEiIGN5PSIxNDEuMDUiIHI9IjguNzYxMiIgc3Ryb2tlLXdpZHRoPSIyLjk2OCIvPjxwYXRoIGQ9Im0xNzguNDEgMTQ5LjgxaC0xMDYuNzUiIHN0cm9rZS13aWR0aD0iMy4wMDIiLz48cGF0aCBkPSJtNjkuMzQ2IDk1LjA3MWMtMTQuNDAxIDAuNzU0MDItMjUuNjk0IDEyLjY0Ni0yNS43MDIgMjcuMDY3IDAuMDA4MyAxNC40MjEgMTEuMzAxIDI2LjMxNCAyNS43MDIgMjcuMDY4IiBzdHJva2Utd2lkdGg9IjQuMTAzMyIvPjxwYXRoIGQ9Im0xODEuMDMgMTMyLjY4LTk2LjQ0OC0zNi4yMDYiIHN0cm9rZS13aWR0aD0iMi45NiIvPjwvZz48Zz48cGF0aCBkPSJtMTUyLjU2IDE0OS41NGMtNC41MzE4LTIuODYzLTcuOTk3Ni04LjUwMzctNy40MDU1LTE0LjEzIDAuNTQ3ODgtNS4yMDU2IDYuOTU1NS05Ljg4MTggMTEuOTQ5LTExLjA1MSA2LjYwODYtMS41NDY5IDE5LjIyNSA2LjcwOSAxOS4yMjUgNi43MDlzLTUuNjM5NyA1LjAzNC02LjIyNzggOC40OTU2Yy0wLjU4MjkzIDMuNDMxMSAzLjA0NTUgOS45ODY3IDMuMDQ1NSA5Ljk4NjdzLTE0Ljg3OCAzLjU5NTItMjAuNTg2LTAuMDExeiIvPjxwYXRoIGQ9Im0xMTQuOTEgMTUwLjU2Yy04Ljc1OTgtNS43OTIyLTExLjY2OC0xNS4yOTItOS42MjQzLTIzLjk5IDEuOTQyMS04LjI2NTggOC43MTg2LTE1LjU3MSAyMC4zMDktMTQuNTY2bDE1LjI0NSA1Ljg2NzFjLTkuNjgxNiAyLjM5NTItMTMuMjM3IDcuMDI0NC0xNC43NDggMTMuNTItMS41NTk1IDYuNzA0IDEuNTk2NyAxNC4xNjIgNy40OTk4IDE5LjIzOXoiLz48cGF0aCBkPSJtOTQuOTkxIDE1MC4yN2MtOS4wMDkyLTguMzI5NC0xNC4xMTUtMTguNTcxLTExLjg4NS0yOC42NzQgMS44ODE1LTguNTI3MiA4LjgzMDUtMTcuNzMyIDE5LjI4My0xNy43MzIgOC4yMSAwLTguNzQ2Ny00LjgyMzgtMTMuNDYtNC40NjUyLTEwLjEwNCAwLjc2ODY2LTIxLjUzNCA1LjM0MTctMjcuMDc0IDEzLjgyNi0zLjc5NTYgNS44MTI1LTMuMjYzMiAxNi4zNy0xLjIxMzkgMjAuNzkxIDMuMTE2NSA2LjcyMjcgNi41NjYzIDEyLjQwNiAxMi40NTkgMTUuMzYzIDYuNTI3NSAzLjI3NTIgMjEuODkxIDAuODkxNzcgMjEuODkxIDAuODkxNzd6Ii8+PHBhdGggZD0ibTY4LjM5OSA5Ny4xOTdzNS43MTc2LTAuMDU0OTEgOC40Mzk2IDAuNjkyMDhjMy4yOTE2IDAuOTAzMjkgOS4yMDMyIDQuNDg5NCA5LjIwMzIgNC40ODk0bDUuMzY0OC0zLjQyMzdzLTYuMjI0OS01LjEyMDMtMTAuNjg0LTQuNzk3NmMtNC4wOTk3IDAuMjk2NzQtMTIuMzItMC41MzExOC0xMi4zMi0wLjUzMTE4eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0.20000000000000001,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny4wNm1tIiBoZWlnaHQ9IjEyNy4zMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuMDYgMTI3LjMxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41OTIgLTc5LjA0KSI+PHBhdGggZD0ibTY0LjI3NyA3OS4wNHYxOC4wNTRjMS43MzAxLTIuMTY3OCAzLjcxODktMi4wMzI2IDUuNjk4Ni0xLjc2MzggMS4zOTEyIDAuMTg4OSAyLjc3NzkgMC40NDM3NiA0LjA2NzIgMC4wMTE3di0xNi4zMDJ6bTAgNjcuMzIxdjU5Ljk4OWg5Ljc2NTh2LTU2LjA4M2wtMy4wNTM0LTMuMDk2czAuMzg1MTggMC4xNTUzNy0zLjMzNjYtMC4xOTIwNmMtMC45Mjg0NC0wLjA4NjctMS44NDU0LTAuMzAxNDItMy4zNzU4LTAuNjE3MTR6Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSIxNzguNDEiIGN5PSIxNDEuMDUiIHI9IjguNzYxMiIgc3Ryb2tlLXdpZHRoPSIyLjk2OCIvPjxwYXRoIGQ9Im0xNzguNDEgMTQ5LjgxaC0xMDYuNzUiIHN0cm9rZS13aWR0aD0iMy4wMDIiLz48cGF0aCBkPSJtNjkuMzQ2IDk1LjA3MWMtMTQuNDAxIDAuNzU0MDItMjUuNjk0IDEyLjY0Ni0yNS43MDIgMjcuMDY3IDAuMDA4MyAxNC40MjEgMTEuMzAxIDI2LjMxNCAyNS43MDIgMjcuMDY4IiBzdHJva2Utd2lkdGg9IjQuMTAzMyIvPjxwYXRoIGQ9Im0xODEuMDMgMTMyLjY4LTk2LjQ0OC0zNi4yMDYiIHN0cm9rZS13aWR0aD0iMi45NiIvPjwvZz48Zz48cGF0aCBkPSJtMTUyLjU2IDE0OS41NGMtNC41MzE4LTIuODYzLTcuOTk3Ni04LjUwMzctNy40MDU1LTE0LjEzIDAuNTQ3ODgtNS4yMDU2IDYuOTU1NS05Ljg4MTggMTEuOTQ5LTExLjA1MSA2LjYwODYtMS41NDY5IDE5LjIyNSA2LjcwOSAxOS4yMjUgNi43MDlzLTUuNjM5NyA1LjAzNC02LjIyNzggOC40OTU2Yy0wLjU4MjkzIDMuNDMxMSAzLjA0NTUgOS45ODY3IDMuMDQ1NSA5Ljk4NjdzLTE0Ljg3OCAzLjU5NTItMjAuNTg2LTAuMDExeiIvPjxwYXRoIGQ9Im0xMTQuOTEgMTUwLjU2Yy04Ljc1OTgtNS43OTIyLTExLjY2OC0xNS4yOTItOS42MjQzLTIzLjk5IDEuOTQyMS04LjI2NTggOC43MTg2LTE1LjU3MSAyMC4zMDktMTQuNTY2bDE1LjI0NSA1Ljg2NzFjLTkuNjgxNiAyLjM5NTItMTMuMjM3IDcuMDI0NC0xNC43NDggMTMuNTItMS41NTk1IDYuNzA0IDEuNTk2NyAxNC4xNjIgNy40OTk4IDE5LjIzOXoiLz48cGF0aCBkPSJtOTQuOTkxIDE1MC4yN2MtOS4wMDkyLTguMzI5NC0xNC4xMTUtMTguNTcxLTExLjg4NS0yOC42NzQgMS44ODE1LTguNTI3MiA4LjgzMDUtMTcuNzMyIDE5LjI4My0xNy43MzIgOC4yMSAwLTguNzQ2Ny00LjgyMzgtMTMuNDYtNC40NjUyLTEwLjEwNCAwLjc2ODY2LTIxLjUzNCA1LjM0MTctMjcuMDc0IDEzLjgyNi0zLjc5NTYgNS44MTI1LTMuMjYzMiAxNi4zNy0xLjIxMzkgMjAuNzkxIDMuMTE2NSA2LjcyMjcgNi41NjYzIDEyLjQwNiAxMi40NTkgMTUuMzYzIDYuNTI3NSAzLjI3NTIgMjEuODkxIDAuODkxNzcgMjEuODkxIDAuODkxNzd6Ii8+PHBhdGggZD0ibTY4LjM5OSA5Ny4xOTdzNS43MTc2LTAuMDU0OTEgOC40Mzk2IDAuNjkyMDhjMy4yOTE2IDAuOTAzMjkgOS4yMDMyIDQuNDg5NCA5LjIwMzIgNC40ODk0bDUuMzY0OC0zLjQyMzdzLTYuMjI0OS01LjEyMDMtMTAuNjg0LTQuNzk3NmMtNC4wOTk3IDAuMjk2NzQtMTIuMzItMC41MzExOC0xMi4zMi0wLjUzMTE4eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0.20000000000000001,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny4wNm1tIiBoZWlnaHQ9IjEyNy4zMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuMDYgMTI3LjMxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41OTIgLTc5LjA0KSI+PHBhdGggZD0ibTY0LjI3NyA3OS4wNHYxOC4wNTRjMS43MzAxLTIuMTY3OCAzLjcxODktMi4wMzI2IDUuNjk4Ni0xLjc2MzggMS4zOTEyIDAuMTg4OSAyLjc3NzkgMC40NDM3NiA0LjA2NzIgMC4wMTE3di0xNi4zMDJ6bTAgNjcuMzIxdjU5Ljk4OWg5Ljc2NTh2LTU2LjA4M2wtMy4wNTM0LTMuMDk2czAuMzg1MTggMC4xNTUzNy0zLjMzNjYtMC4xOTIwNmMtMC45Mjg0NC0wLjA4NjctMS44NDU0LTAuMzAxNDItMy4zNzU4LTAuNjE3MTR6Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSIxNzguNDEiIGN5PSIxNDEuMDUiIHI9IjguNzYxMiIgc3Ryb2tlLXdpZHRoPSIyLjk2OCIvPjxwYXRoIGQ9Im0xNzguNDEgMTQ5LjgxaC0xMDYuNzUiIHN0cm9rZS13aWR0aD0iMy4wMDIiLz48cGF0aCBkPSJtNjkuMzQ2IDk1LjA3MWMtMTQuNDAxIDAuNzU0MDItMjUuNjk0IDEyLjY0Ni0yNS43MDIgMjcuMDY3IDAuMDA4MyAxNC40MjEgMTEuMzAxIDI2LjMxNCAyNS43MDIgMjcuMDY4IiBzdHJva2Utd2lkdGg9IjQuMTAzMyIvPjxwYXRoIGQ9Im0xODEuMDMgMTMyLjY4LTk2LjQ0OC0zNi4yMDYiIHN0cm9rZS13aWR0aD0iMi45NiIvPjwvZz48Zz48cGF0aCBkPSJtMTUyLjU2IDE0OS41NGMtNC41MzE4LTIuODYzLTcuOTk3Ni04LjUwMzctNy40MDU1LTE0LjEzIDAuNTQ3ODgtNS4yMDU2IDYuOTU1NS05Ljg4MTggMTEuOTQ5LTExLjA1MSA2LjYwODYtMS41NDY5IDE5LjIyNSA2LjcwOSAxOS4yMjUgNi43MDlzLTUuNjM5NyA1LjAzNC02LjIyNzggOC40OTU2Yy0wLjU4MjkzIDMuNDMxMSAzLjA0NTUgOS45ODY3IDMuMDQ1NSA5Ljk4NjdzLTE0Ljg3OCAzLjU5NTItMjAuNTg2LTAuMDExeiIvPjxwYXRoIGQ9Im0xMTQuOTEgMTUwLjU2Yy04Ljc1OTgtNS43OTIyLTExLjY2OC0xNS4yOTItOS42MjQzLTIzLjk5IDEuOTQyMS04LjI2NTggOC43MTg2LTE1LjU3MSAyMC4zMDktMTQuNTY2bDE1LjI0NSA1Ljg2NzFjLTkuNjgxNiAyLjM5NTItMTMuMjM3IDcuMDI0NC0xNC43NDggMTMuNTItMS41NTk1IDYuNzA0IDEuNTk2NyAxNC4xNjIgNy40OTk4IDE5LjIzOXoiLz48cGF0aCBkPSJtOTQuOTkxIDE1MC4yN2MtOS4wMDkyLTguMzI5NC0xNC4xMTUtMTguNTcxLTExLjg4NS0yOC42NzQgMS44ODE1LTguNTI3MiA4LjgzMDUtMTcuNzMyIDE5LjI4My0xNy43MzIgOC4yMSAwLTguNzQ2Ny00LjgyMzgtMTMuNDYtNC40NjUyLTEwLjEwNCAwLjc2ODY2LTIxLjUzNCA1LjM0MTctMjcuMDc0IDEzLjgyNi0zLjc5NTYgNS44MTI1LTMuMjYzMiAxNi4zNy0xLjIxMzkgMjAuNzkxIDMuMTE2NSA2LjcyMjcgNi41NjYzIDEyLjQwNiAxMi40NTkgMTUuMzYzIDYuNTI3NSAzLjI3NTIgMjEuODkxIDAuODkxNzcgMjEuODkxIDAuODkxNzd6Ii8+PHBhdGggZD0ibTY4LjM5OSA5Ny4xOTdzNS43MTc2LTAuMDU0OTEgOC40Mzk2IDAuNjkyMDhjMy4yOTE2IDAuOTAzMjkgOS4yMDMyIDQuNDg5NCA5LjIwMzIgNC40ODk0bDUuMzY0OC0zLjQyMzdzLTYuMjI0OS01LjEyMDMtMTAuNjg0LTQuNzk3NmMtNC4wOTk3IDAuMjk2NzQtMTIuMzItMC41MzExOC0xMi4zMi0wLjUzMTE4eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0.20000000000000001,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny4wNm1tIiBoZWlnaHQ9IjEyNy4zMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuMDYgMTI3LjMxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41OTIgLTc5LjA0KSI+PHBhdGggZD0ibTY0LjI3NyA3OS4wNHYxOC4wNTRjMS43MzAxLTIuMTY3OCAzLjcxODktMi4wMzI2IDUuNjk4Ni0xLjc2MzggMS4zOTEyIDAuMTg4OSAyLjc3NzkgMC40NDM3NiA0LjA2NzIgMC4wMTE3di0xNi4zMDJ6bTAgNjcuMzIxdjU5Ljk4OWg5Ljc2NTh2LTU2LjA4M2wtMy4wNTM0LTMuMDk2czAuMzg1MTggMC4xNTUzNy0zLjMzNjYtMC4xOTIwNmMtMC45Mjg0NC0wLjA4NjctMS44NDU0LTAuMzAxNDItMy4zNzU4LTAuNjE3MTR6Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSIxNzguNDEiIGN5PSIxNDEuMDUiIHI9IjguNzYxMiIgc3Ryb2tlLXdpZHRoPSIyLjk2OCIvPjxwYXRoIGQ9Im0xNzguNDEgMTQ5LjgxaC0xMDYuNzUiIHN0cm9rZS13aWR0aD0iMy4wMDIiLz48cGF0aCBkPSJtNjkuMzQ2IDk1LjA3MWMtMTQuNDAxIDAuNzU0MDItMjUuNjk0IDEyLjY0Ni0yNS43MDIgMjcuMDY3IDAuMDA4MyAxNC40MjEgMTEuMzAxIDI2LjMxNCAyNS43MDIgMjcuMDY4IiBzdHJva2Utd2lkdGg9IjQuMTAzMyIvPjxwYXRoIGQ9Im0xODEuMDMgMTMyLjY4LTk2LjQ0OC0zNi4yMDYiIHN0cm9rZS13aWR0aD0iMi45NiIvPjwvZz48Zz48cGF0aCBkPSJtMTUyLjU2IDE0OS41NGMtNC41MzE4LTIuODYzLTcuOTk3Ni04LjUwMzctNy40MDU1LTE0LjEzIDAuNTQ3ODgtNS4yMDU2IDYuOTU1NS05Ljg4MTggMTEuOTQ5LTExLjA1MSA2LjYwODYtMS41NDY5IDE5LjIyNSA2LjcwOSAxOS4yMjUgNi43MDlzLTUuNjM5NyA1LjAzNC02LjIyNzggOC40OTU2Yy0wLjU4MjkzIDMuNDMxMSAzLjA0NTUgOS45ODY3IDMuMDQ1NSA5Ljk4NjdzLTE0Ljg3OCAzLjU5NTItMjAuNTg2LTAuMDExeiIvPjxwYXRoIGQ9Im0xMTQuOTEgMTUwLjU2Yy04Ljc1OTgtNS43OTIyLTExLjY2OC0xNS4yOTItOS42MjQzLTIzLjk5IDEuOTQyMS04LjI2NTggOC43MTg2LTE1LjU3MSAyMC4zMDktMTQuNTY2bDE1LjI0NSA1Ljg2NzFjLTkuNjgxNiAyLjM5NTItMTMuMjM3IDcuMDI0NC0xNC43NDggMTMuNTItMS41NTk1IDYuNzA0IDEuNTk2NyAxNC4xNjIgNy40OTk4IDE5LjIzOXoiLz48cGF0aCBkPSJtOTQuOTkxIDE1MC4yN2MtOS4wMDkyLTguMzI5NC0xNC4xMTUtMTguNTcxLTExLjg4NS0yOC42NzQgMS44ODE1LTguNTI3MiA4LjgzMDUtMTcuNzMyIDE5LjI4My0xNy43MzIgOC4yMSAwLTguNzQ2Ny00LjgyMzgtMTMuNDYtNC40NjUyLTEwLjEwNCAwLjc2ODY2LTIxLjUzNCA1LjM0MTctMjcuMDc0IDEzLjgyNi0zLjc5NTYgNS44MTI1LTMuMjYzMiAxNi4zNy0xLjIxMzkgMjAuNzkxIDMuMTE2NSA2LjcyMjcgNi41NjYzIDEyLjQwNiAxMi40NTkgMTUuMzYzIDYuNTI3NSAzLjI3NTIgMjEuODkxIDAuODkxNzcgMjEuODkxIDAuODkxNzd6Ii8+PHBhdGggZD0ibTY4LjM5OSA5Ny4xOTdzNS43MTc2LTAuMDU0OTEgOC40Mzk2IDAuNjkyMDhjMy4yOTE2IDAuOTAzMjkgOS4yMDMyIDQuNDg5NCA5LjIwMzIgNC40ODk0bDUuMzY0OC0zLjQyMzdzLTYuMjI0OS01LjEyMDMtMTAuNjg0LTQuNzk3NmMtNC4wOTk3IDAuMjk2NzQtMTIuMzItMC41MzExOC0xMi4zMi0wLjUzMTE4eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0.20000000000000001,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny4wNm1tIiBoZWlnaHQ9IjEyNy4zMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuMDYgMTI3LjMxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41OTIgLTc5LjA0KSI+PHBhdGggZD0ibTY0LjI3NyA3OS4wNHYxOC4wNTRjMS43MzAxLTIuMTY3OCAzLjcxODktMi4wMzI2IDUuNjk4Ni0xLjc2MzggMS4zOTEyIDAuMTg4OSAyLjc3NzkgMC40NDM3NiA0LjA2NzIgMC4wMTE3di0xNi4zMDJ6bTAgNjcuMzIxdjU5Ljk4OWg5Ljc2NTh2LTU2LjA4M2wtMy4wNTM0LTMuMDk2czAuMzg1MTggMC4xNTUzNy0zLjMzNjYtMC4xOTIwNmMtMC45Mjg0NC0wLjA4NjctMS44NDU0LTAuMzAxNDItMy4zNzU4LTAuNjE3MTR6Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSIxNzguNDEiIGN5PSIxNDEuMDUiIHI9IjguNzYxMiIgc3Ryb2tlLXdpZHRoPSIyLjk2OCIvPjxwYXRoIGQ9Im0xNzguNDEgMTQ5LjgxaC0xMDYuNzUiIHN0cm9rZS13aWR0aD0iMy4wMDIiLz48cGF0aCBkPSJtNjkuMzQ2IDk1LjA3MWMtMTQuNDAxIDAuNzU0MDItMjUuNjk0IDEyLjY0Ni0yNS43MDIgMjcuMDY3IDAuMDA4MyAxNC40MjEgMTEuMzAxIDI2LjMxNCAyNS43MDIgMjcuMDY4IiBzdHJva2Utd2lkdGg9IjQuMTAzMyIvPjxwYXRoIGQ9Im0xODEuMDMgMTMyLjY4LTk2LjQ0OC0zNi4yMDYiIHN0cm9rZS13aWR0aD0iMi45NiIvPjwvZz48Zz48cGF0aCBkPSJtMTUyLjU2IDE0OS41NGMtNC41MzE4LTIuODYzLTcuOTk3Ni04LjUwMzctNy40MDU1LTE0LjEzIDAuNTQ3ODgtNS4yMDU2IDYuOTU1NS05Ljg4MTggMTEuOTQ5LTExLjA1MSA2LjYwODYtMS41NDY5IDE5LjIyNSA2LjcwOSAxOS4yMjUgNi43MDlzLTUuNjM5NyA1LjAzNC02LjIyNzggOC40OTU2Yy0wLjU4MjkzIDMuNDMxMSAzLjA0NTUgOS45ODY3IDMuMDQ1NSA5Ljk4NjdzLTE0Ljg3OCAzLjU5NTItMjAuNTg2LTAuMDExeiIvPjxwYXRoIGQ9Im0xMTQuOTEgMTUwLjU2Yy04Ljc1OTgtNS43OTIyLTExLjY2OC0xNS4yOTItOS42MjQzLTIzLjk5IDEuOTQyMS04LjI2NTggOC43MTg2LTE1LjU3MSAyMC4zMDktMTQuNTY2bDE1LjI0NSA1Ljg2NzFjLTkuNjgxNiAyLjM5NTItMTMuMjM3IDcuMDI0NC0xNC43NDggMTMuNTItMS41NTk1IDYuNzA0IDEuNTk2NyAxNC4xNjIgNy40OTk4IDE5LjIzOXoiLz48cGF0aCBkPSJtOTQuOTkxIDE1MC4yN2MtOS4wMDkyLTguMzI5NC0xNC4xMTUtMTguNTcxLTExLjg4NS0yOC42NzQgMS44ODE1LTguNTI3MiA4LjgzMDUtMTcuNzMyIDE5LjI4My0xNy43MzIgOC4yMSAwLTguNzQ2Ny00LjgyMzgtMTMuNDYtNC40NjUyLTEwLjEwNCAwLjc2ODY2LTIxLjUzNCA1LjM0MTctMjcuMDc0IDEzLjgyNi0zLjc5NTYgNS44MTI1LTMuMjYzMiAxNi4zNy0xLjIxMzkgMjAuNzkxIDMuMTE2NSA2LjcyMjcgNi41NjYzIDEyLjQwNiAxMi40NTkgMTUuMzYzIDYuNTI3NSAzLjI3NTIgMjEuODkxIDAuODkxNzcgMjEuODkxIDAuODkxNzd6Ii8+PHBhdGggZD0ibTY4LjM5OSA5Ny4xOTdzNS43MTc2LTAuMDU0OTEgOC40Mzk2IDAuNjkyMDhjMy4yOTE2IDAuOTAzMjkgOS4yMDMyIDQuNDg5NCA5LjIwMzIgNC40ODk0bDUuMzY0OC0zLjQyMzdzLTYuMjI0OS01LjEyMDMtMTAuNjg0LTQuNzk3NmMtNC4wOTk3IDAuMjk2NzQtMTIuMzItMC41MzExOC0xMi4zMi0wLjUzMTE4eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0.20000000000000001,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE0Ny4wNm1tIiBoZWlnaHQ9IjEyNy4zMW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNDcuMDYgMTI3LjMxIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MS41OTIgLTc5LjA0KSI+PHBhdGggZD0ibTY0LjI3NyA3OS4wNHYxOC4wNTRjMS43MzAxLTIuMTY3OCAzLjcxODktMi4wMzI2IDUuNjk4Ni0xLjc2MzggMS4zOTEyIDAuMTg4OSAyLjc3NzkgMC40NDM3NiA0LjA2NzIgMC4wMTE3di0xNi4zMDJ6bTAgNjcuMzIxdjU5Ljk4OWg5Ljc2NTh2LTU2LjA4M2wtMy4wNTM0LTMuMDk2czAuMzg1MTggMC4xNTUzNy0zLjMzNjYtMC4xOTIwNmMtMC45Mjg0NC0wLjA4NjctMS44NDU0LTAuMzAxNDItMy4zNzU4LTAuNjE3MTR6Ii8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2UtbWl0ZXJsaW1pdD0iNC44Ij48Y2lyY2xlIGN4PSIxNzguNDEiIGN5PSIxNDEuMDUiIHI9IjguNzYxMiIgc3Ryb2tlLXdpZHRoPSIyLjk2OCIvPjxwYXRoIGQ9Im0xNzguNDEgMTQ5LjgxaC0xMDYuNzUiIHN0cm9rZS13aWR0aD0iMy4wMDIiLz48cGF0aCBkPSJtNjkuMzQ2IDk1LjA3MWMtMTQuNDAxIDAuNzU0MDItMjUuNjk0IDEyLjY0Ni0yNS43MDIgMjcuMDY3IDAuMDA4MyAxNC40MjEgMTEuMzAxIDI2LjMxNCAyNS43MDIgMjcuMDY4IiBzdHJva2Utd2lkdGg9IjQuMTAzMyIvPjxwYXRoIGQ9Im0xODEuMDMgMTMyLjY4LTk2LjQ0OC0zNi4yMDYiIHN0cm9rZS13aWR0aD0iMi45NiIvPjwvZz48Zz48cGF0aCBkPSJtMTUyLjU2IDE0OS41NGMtNC41MzE4LTIuODYzLTcuOTk3Ni04LjUwMzctNy40MDU1LTE0LjEzIDAuNTQ3ODgtNS4yMDU2IDYuOTU1NS05Ljg4MTggMTEuOTQ5LTExLjA1MSA2LjYwODYtMS41NDY5IDE5LjIyNSA2LjcwOSAxOS4yMjUgNi43MDlzLTUuNjM5NyA1LjAzNC02LjIyNzggOC40OTU2Yy0wLjU4MjkzIDMuNDMxMSAzLjA0NTUgOS45ODY3IDMuMDQ1NSA5Ljk4NjdzLTE0Ljg3OCAzLjU5NTItMjAuNTg2LTAuMDExeiIvPjxwYXRoIGQ9Im0xMTQuOTEgMTUwLjU2Yy04Ljc1OTgtNS43OTIyLTExLjY2OC0xNS4yOTItOS42MjQzLTIzLjk5IDEuOTQyMS04LjI2NTggOC43MTg2LTE1LjU3MSAyMC4zMDktMTQuNTY2bDE1LjI0NSA1Ljg2NzFjLTkuNjgxNiAyLjM5NTItMTMuMjM3IDcuMDI0NC0xNC43NDggMTMuNTItMS41NTk1IDYuNzA0IDEuNTk2NyAxNC4xNjIgNy40OTk4IDE5LjIzOXoiLz48cGF0aCBkPSJtOTQuOTkxIDE1MC4yN2MtOS4wMDkyLTguMzI5NC0xNC4xMTUtMTguNTcxLTExLjg4NS0yOC42NzQgMS44ODE1LTguNTI3MiA4LjgzMDUtMTcuNzMyIDE5LjI4My0xNy43MzIgOC4yMSAwLTguNzQ2Ny00LjgyMzgtMTMuNDYtNC40NjUyLTEwLjEwNCAwLjc2ODY2LTIxLjUzNCA1LjM0MTctMjcuMDc0IDEzLjgyNi0zLjc5NTYgNS44MTI1LTMuMjYzMiAxNi4zNy0xLjIxMzkgMjAuNzkxIDMuMTE2NSA2LjcyMjcgNi41NjYzIDEyLjQwNiAxMi40NTkgMTUuMzYzIDYuNTI3NSAzLjI3NTIgMjEuODkxIDAuODkxNzcgMjEuODkxIDAuODkxNzd6Ii8+PHBhdGggZD0ibTY4LjM5OSA5Ny4xOTdzNS43MTc2LTAuMDU0OTEgOC40Mzk2IDAuNjkyMDhjMy4yOTE2IDAuOTAzMjkgOS4yMDMyIDQuNDg5NCA5LjIwMzIgNC40ODk0bDUuMzY0OC0zLjQyMzdzLTYuMjI0OS01LjEyMDMtMTAuNjg0LTQuNzk3NmMtNC4wOTk3IDAuMjk2NzQtMTIuMzItMC41MzExOC0xMi4zMi0wLjUzMTE4eiIvPjwvZz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0.20000000000000001,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Стационарный пункт наблюдений за состоянием окружающей природной среды, ее загрязнением" value="602050401" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ZONE_SIZE" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="AREA" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FUNCTION" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к ликвидации" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTROKS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTRZU" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="ZONE_SIZE" index="6" name="Размер охранной зоны, м"/>
    <alias field="AREA" index="7" name="Площадь объекта, га"/>
    <alias field="FUNCTION" index="8" name="Назначение объекта"/>
    <alias field="EVENT_TIME" index="9" name=""/>
    <alias field="SOURCE" index="10" name="Источник данных"/>
    <alias field="NOTE" index="11" name="Примечание"/>
    <alias field="STATUS" index="12" name="Статус объекта"/>
    <alias field="REG_STATUS" index="13" name="Значение объекта"/>
    <alias field="KADASTROKS" index="14" name="Кадастровый номер объекта капитального строительства"/>
    <alias field="KADASTRZU" index="15" name=""/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602050401'" applyOnUpdate="1"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="ZONE_SIZE" expression="0" applyOnUpdate="0"/>
    <default field="AREA" expression="0" applyOnUpdate="0"/>
    <default field="FUNCTION" expression="''" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
    <default field="KADASTROKS" expression="''" applyOnUpdate="0"/>
    <default field="KADASTRZU" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="ZONE_SIZE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="AREA" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FUNCTION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="2" field="KADASTROKS" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="KADASTRZU" unique_strength="0" notnull_strength="0" constraints="4"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="ZONE_SIZE" desc="" exp=""/>
    <constraint field="AREA" desc="" exp=""/>
    <constraint field="FUNCTION" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xd;&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
    <constraint field="KADASTROKS" desc="Кадастровый номер объекта должен соответствовать формату, принятому в ЕГРН." exp="regexp_match(&quot;KADASTROKS&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$')"/>
    <constraint field="KADASTRZU" desc="Обязательно для значений атрибута &quot;STATUS&quot; 1, 3, 4." exp="if (&quot;STATUS&quot; = 1 OR &quot;STATUS&quot; = 3 OR &quot;STATUS&quot; = 4,&#xd;&#xa;&#x9;regexp_match(&quot;KADASTRZU&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$|^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1})$'),&#xd;&#xa;&#x9;length(&quot;KADASTRZU&quot;) >= 0)"/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="12" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="6" name="ZONE_SIZE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="7" name="AREA">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="8" name="FUNCTION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="10" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="11" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="14" name="KADASTROKS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="9" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Кадастровый номер земельного участка и (или) номер кадастрового квартала, в границах которого расположен объект" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (1, 3, 4)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="15" name="KADASTRZU">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="AREA" editable="1"/>
    <field name="CLASSID" editable="0"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="FUNCTION" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="KADASTROKS" editable="1"/>
    <field name="KADASTRZU" editable="1"/>
    <field name="NAME" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="ZONE_SIZE" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="AREA"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="FUNCTION"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="KADASTROKS"/>
    <field labelOnTop="1" name="KADASTRZU"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS"/>
    <field labelOnTop="1" name="ZONE_SIZE"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="AREA" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="FUNCTION" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="KADASTROKS" reuseLastValue="0"/>
    <field name="KADASTRZU" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="ZONE_SIZE" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
