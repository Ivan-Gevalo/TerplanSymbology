<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{ecb35b66-0de6-4da5-b9a0-648ddcc374a3}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{7bc23e76-3744-42e7-b1b1-4aa6f0e52d50}">
        <rule label="Электродепо метрополитена" filter="&quot;CLASSID&quot; = '602030801'" symbol="1" key="{9b48ce6e-eee1-4bd0-bb6a-6f4bf87de0bc}"/>
        <rule label="Трамвайное депо" filter="&quot;CLASSID&quot; = '602030802'" symbol="2" key="{c74100d8-d691-4363-bccc-51198d5db787}"/>
        <rule label="Троллейбусное депо" filter="&quot;CLASSID&quot; = '602030803'" symbol="3" key="{8c1ee6b5-42c3-4dfe-82e5-0773683df0a0}"/>
        <rule label="Совмещенное троллейбусно-трамвайное депо" filter="&quot;CLASSID&quot; = '602030804'" symbol="4" key="{ed7934e6-2eb2-4162-90b6-124e0e2cbf2d}"/>
        <rule label="Автобусный парк" filter="&quot;CLASSID&quot; = '602030805'" symbol="5" key="{604e6a37-8d49-4743-91fe-f57f82afa018}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="6" key="{f2a09280-dc97-40a6-929a-3b7e6b70e3b2}">
        <rule label="Электродепо метрополитена" filter="&quot;CLASSID&quot; = '602030801'" symbol="7" key="{206e67be-cf3d-43b7-a211-ef045733abca}"/>
        <rule label="Трамвайное депо" filter="&quot;CLASSID&quot; = '602030802'" symbol="8" key="{81ea8876-fbfb-4f4f-ab17-4ca25170a86e}"/>
        <rule label="Троллейбусное депо" filter="&quot;CLASSID&quot; = '602030803'" symbol="9" key="{3600e8ad-4786-43f2-9407-63088a7db3aa}"/>
        <rule label="Совмещенное троллейбусно-трамвайное депо" filter="&quot;CLASSID&quot; = '602030804'" symbol="10" key="{8916c677-7d31-4d22-b613-619916e402bd}"/>
        <rule label="Автобусный парк" filter="&quot;CLASSID&quot; = '602030805'" symbol="11" key="{b9fcabe7-7621-4f5d-a4d4-908ab206bbc4}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="12" key="{9d065553-e8c4-4c4e-8750-04f34ad8ad5b}">
        <rule label="Электродепо метрополитена" filter="&quot;CLASSID&quot; = '602030801'" symbol="13" key="{7bdefd32-b4f8-45e3-8c9d-aa95eaabaa25}"/>
        <rule label="Трамвайное депо" filter="&quot;CLASSID&quot; = '602030802'" symbol="14" key="{94f96d6f-4a2d-4613-ae7e-698ce85a4483}"/>
        <rule label="Троллейбусное депо" filter="&quot;CLASSID&quot; = '602030803'" symbol="15" key="{5aa92dc4-0e51-4b2a-83a9-796d126812d6}"/>
        <rule label="Совмещенное троллейбусно-трамвайное депо" filter="&quot;CLASSID&quot; = '602030804'" symbol="16" key="{b29f8a6c-0eb8-4b25-8925-5b0c1ae8d732}"/>
        <rule label="Автобусный парк" filter="&quot;CLASSID&quot; = '602030805'" symbol="17" key="{6b495ab8-fd44-42c2-8fbd-948515fa1999}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="18" key="{52fb2535-3a9b-4db3-8948-22b3fd5970be}">
        <rule label="Электродепо метрополитена" filter="&quot;CLASSID&quot; = '602030801'" symbol="19" key="{e1feb31e-fd71-4f3f-9100-ae9cfa79e877}"/>
        <rule label="Трамвайное депо" filter="&quot;CLASSID&quot; = '602030802'" symbol="20" key="{c4b7a632-699c-481f-bd1a-8357c0da42bd}"/>
        <rule label="Троллейбусное депо" filter="&quot;CLASSID&quot; = '602030803'" symbol="21" key="{57de7693-68b5-4262-9acb-0dfae8ecb8c9}"/>
        <rule label="Совмещенное троллейбусно-трамвайное депо" filter="&quot;CLASSID&quot; = '602030804'" symbol="22" key="{51862f2c-bf2e-4fd2-ac34-b5667fd9efe7}"/>
        <rule label="Автобусный парк" filter="&quot;CLASSID&quot; = '602030805'" symbol="23" key="{64d525f7-6016-4482-b2e2-5a963bc8e286}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="24" key="{9b481359-3b96-41b0-b9a0-ae3f9b7ad1c8}">
        <rule label="Электродепо метрополитена" filter="&quot;CLASSID&quot; = '602030801'" symbol="25" key="{c7785cb1-6ff8-4eed-8f79-3988d18454e6}"/>
        <rule label="Трамвайное депо" filter="&quot;CLASSID&quot; = '602030802'" symbol="26" key="{84d4ba47-46b8-4a97-adf1-035a7e951620}"/>
        <rule label="Троллейбусное депо" filter="&quot;CLASSID&quot; = '602030803'" symbol="27" key="{e96f36e0-9299-483a-b819-fe527760ac30}"/>
        <rule label="Совмещенное троллейбусно-трамвайное депо" filter="&quot;CLASSID&quot; = '602030804'" symbol="28" key="{78e11d35-da1f-4417-9150-8afbff8256f5}"/>
        <rule label="Автобусный парк" filter="&quot;CLASSID&quot; = '602030805'" symbol="29" key="{2f4e007d-edcd-4b7f-8eca-37f953bff9ec}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="30" key="{3f97fed7-4aba-414a-88a2-da337e9fb738}">
        <rule label="Электродепо метрополитена" filter="&quot;CLASSID&quot; = '602030801'" symbol="31" key="{5c8e51c8-3562-4ccf-8b3d-f86c6fde9931}"/>
        <rule label="Трамвайное депо" filter="&quot;CLASSID&quot; = '602030802'" symbol="32" key="{3b2d218a-bf60-41ce-8d79-b918fb1dc1c2}"/>
        <rule label="Троллейбусное депо" filter="&quot;CLASSID&quot; = '602030803'" symbol="33" key="{d7b2ba3a-d7e3-45dc-9922-c21c09f90455}"/>
        <rule label="Совмещенное троллейбусно-трамвайное депо" filter="&quot;CLASSID&quot; = '602030804'" symbol="34" key="{05812b6b-3289-4516-880c-71b05ac035ae}"/>
        <rule label="Автобусный парк" filter="&quot;CLASSID&quot; = '602030805'" symbol="35" key="{fc8e7471-2da6-44e2-bfb8-18ef13dd900d}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="36" key="{64b505b2-fff2-4483-aef3-60d0522fc640}">
        <rule label="Электродепо метрополитена" filter="&quot;CLASSID&quot; = '602030801'" symbol="37" key="{c3f77e7e-5c44-4d62-a36b-2f4e3e87240f}"/>
        <rule label="Трамвайное депо" filter="&quot;CLASSID&quot; = '602030802'" symbol="38" key="{faa19a39-9ddb-45ec-a6b7-ecee9e0892e5}"/>
        <rule label="Троллейбусное депо" filter="&quot;CLASSID&quot; = '602030803'" symbol="39" key="{1a7285d7-46a3-4bbd-99bb-e35bbd35f7a2}"/>
        <rule label="Совмещенное троллейбусно-трамвайное депо" filter="&quot;CLASSID&quot; = '602030804'" symbol="40" key="{2a1d38f8-84b9-4310-aa67-943a1d28e1a2}"/>
        <rule label="Автобусный парк" filter="&quot;CLASSID&quot; = '602030805'" symbol="41" key="{171ec584-7326-41eb-88fe-9cc9d693c91b}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты регионального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 2" symbol="42" key="{a57f27ad-8c1d-4e34-9d95-eafa0f08a480}">
        <rule label="Электродепо метрополитена" filter="&quot;CLASSID&quot; = '602030801'" symbol="43" key="{f757d1fe-d98c-4234-b902-7347ebe92e6e}"/>
        <rule label="Трамвайное депо" filter="&quot;CLASSID&quot; = '602030802'" symbol="44" key="{9a638f9a-e6d5-4ca4-8265-7b7ba646e9ab}"/>
        <rule label="Троллейбусное депо" filter="&quot;CLASSID&quot; = '602030803'" symbol="45" key="{2ee9a876-e3ee-40d1-ac1e-9f68a3af6307}"/>
        <rule label="Совмещенное троллейбусно-трамвайное депо" filter="&quot;CLASSID&quot; = '602030804'" symbol="46" key="{867d719e-6c56-47a2-af64-4fa14fa5ba7e}"/>
        <rule label="Автобусный парк" filter="&quot;CLASSID&quot; = '602030805'" symbol="47" key="{cd7d1861-323a-429f-b409-5d40d7d27769}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="48" key="{3a9f4c28-d45a-4268-9db6-71d7bb3d806a}">
        <rule label="Электродепо метрополитена" filter="&quot;CLASSID&quot; = '602030801'" symbol="49" key="{7f9e7f8e-5ae0-4357-993a-4eeb5a94619f}"/>
        <rule label="Трамвайное депо" filter="&quot;CLASSID&quot; = '602030802'" symbol="50" key="{c756ae82-843c-4913-919b-68b6cb0d9057}"/>
        <rule label="Троллейбусное депо" filter="&quot;CLASSID&quot; = '602030803'" symbol="51" key="{9dff0d17-51ea-4df3-9473-266090ace6f6}"/>
        <rule label="Совмещенное троллейбусно-трамвайное депо" filter="&quot;CLASSID&quot; = '602030804'" symbol="52" key="{46dfffb9-87af-4194-a258-4b11a3d14224}"/>
        <rule label="Автобусный парк" filter="&quot;CLASSID&quot; = '602030805'" symbol="53" key="{26b8593b-e348-4f08-b3f6-fd7cbb7c4cb4}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="54" key="{03e60cc6-cbfb-47e9-9855-c9e67914ad4a}">
        <rule label="Электродепо метрополитена" filter="&quot;CLASSID&quot; = '602030801'" symbol="55" key="{d9fc2954-9031-4730-8cac-402ca76e0b47}"/>
        <rule label="Трамвайное депо" filter="&quot;CLASSID&quot; = '602030802'" symbol="56" key="{ead03242-1f60-4009-af8c-0fe84f88d7e8}"/>
        <rule label="Троллейбусное депо" filter="&quot;CLASSID&quot; = '602030803'" symbol="57" key="{6f829d8c-075f-4297-9ad8-1cad8fcc83d5}"/>
        <rule label="Совмещенное троллейбусно-трамвайное депо" filter="&quot;CLASSID&quot; = '602030804'" symbol="58" key="{64491f77-d2fb-4615-afb4-79a0a6ac6f2a}"/>
        <rule label="Автобусный парк" filter="&quot;CLASSID&quot; = '602030805'" symbol="59" key="{1f218b1b-f25b-431b-abce-298f0843b5f0}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="60" key="{4aa9def1-cf9e-4706-bc2d-65da81125250}">
        <rule label="Электродепо метрополитена" filter="&quot;CLASSID&quot; = '602030801'" symbol="61" key="{155502fa-f217-47fe-83c0-bec717d98785}"/>
        <rule label="Трамвайное депо" filter="&quot;CLASSID&quot; = '602030802'" symbol="62" key="{f0e7038f-52c1-415e-ba41-53e6796bf1a6}"/>
        <rule label="Троллейбусное депо" filter="&quot;CLASSID&quot; = '602030803'" symbol="63" key="{e90d9216-a277-4c04-9381-895450f65e3b}"/>
        <rule label="Совмещенное троллейбусно-трамвайное депо" filter="&quot;CLASSID&quot; = '602030804'" symbol="64" key="{045300cd-9d25-4e58-afea-fd4f92fa29db}"/>
        <rule label="Автобусный парк" filter="&quot;CLASSID&quot; = '602030805'" symbol="65" key="{f22e3b64-cf6c-40df-a682-13f39854bf84}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты федерального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 1" symbol="66" key="{a5ced6a6-cd64-4af2-99df-fed8679e113f}">
        <rule label="Электродепо метрополитена" filter="&quot;CLASSID&quot; = '602030801'" symbol="67" key="{a0a1e0b3-bb98-41e2-9ea2-27e9b2bdfe4b}"/>
        <rule label="Трамвайное депо" filter="&quot;CLASSID&quot; = '602030802'" symbol="68" key="{97f3e7fd-7eb7-4306-b729-47db3b8ce17a}"/>
        <rule label="Троллейбусное депо" filter="&quot;CLASSID&quot; = '602030803'" symbol="69" key="{a65b5084-5fc8-400d-a642-debaeba98a54}"/>
        <rule label="Совмещенное троллейбусно-трамвайное депо" filter="&quot;CLASSID&quot; = '602030804'" symbol="70" key="{eb39e6dd-321b-47f0-b1d1-39dcf0a0bd0d}"/>
        <rule label="Автобусный парк" filter="&quot;CLASSID&quot; = '602030805'" symbol="71" key="{d7a60d5f-d447-4eff-b0f2-993a01534848}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2OC44OW1tIiBoZWlnaHQ9IjE0OC40Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjguODkgMTQ4LjQyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMC42NjIgLTgwLjU3OCkiPjxwYXRoIGQ9Im0yNS41ODQgMTUxLjVjLTIuNzI3IDAtNC45MjIyIDIuMTk1Ny00LjkyMjIgNC45MjI3djY3LjY1MmMwIDIuNzI3IDIuMTk1MiA0LjkyMjcgNC45MjIyIDQuOTIyN2gxNTkuMDVjMi43MjcgMCA0LjkyMjItMi4xOTU3IDQuOTIyMi00LjkyMjd2LTY3LjY1MmMwLTIuNzI3LTIuMTk1Mi00LjkyMjctNC45MjIyLTQuOTIyN2gtMjQuODA4YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDU2OCA5LjkyNWgtMTA3LjU0YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDYyLTkuOTI1eiIvPjxjaXJjbGUgY3g9IjEwNS4xMSIgY3k9IjE0OS40NiIgcj0iNjAuODcyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMTYuMDI1Ii8+PGc+PHBhdGggZD0ibTc5Ljk5NiAxMTUuODhjLTIuOTkgMC01LjM5NzEgMi40MDcxLTUuMzk3MSA1LjM5NzF2MjkuODk1YzAgMi45OSAyLjQwNzEgNS4zOTcxIDUuMzk3MSA1LjM5NzFoNTAuMjIzYzIuOTkgMCA1LjM5NzEtMi40MDcxIDUuMzk3MS01LjM5NzF2LTI5Ljg5NWMwLTIuOTktMi40MDcxLTUuMzk3MS01LjM5NzEtNS4zOTcxem04LjA4NTMgNS45NDloMTAuNjY2YzAuOTYxNTUgMCAxLjczNTMgMC43NzQyNiAxLjczNTMgMS43MzU4djcuNjE5N2MwIDAuOTYxNTUtMC43NzM3NSAxLjczNTMtMS43MzUzIDEuNzM1M2gtMTAuNjY2Yy0wLjk2MTU1IDAtMS43MzUzLTAuNzczNzUtMS43MzUzLTEuNzM1M3YtNy42MTk3YzAtMC45NjE1NSAwLjc3Mzc1LTEuNzM1OCAxLjczNTMtMS43MzU4em0yMy4zODcgMGgxMC42NjZjMC45NjE1NSAwIDEuNzM1OCAwLjc3NDI2IDEuNzM1OCAxLjczNTh2Ny42MTk3YzAgMC45NjE1NS0wLjc3NDI2IDEuNzM1My0xLjczNTggMS43MzUzaC0xMC42NjZjLTAuOTYxNTUgMC0xLjczNTgtMC43NzM3NS0xLjczNTgtMS43MzUzdi03LjYxOTdjMC0wLjk2MTU1IDAuNzc0MjYtMS43MzU4IDEuNzM1OC0xLjczNTh6Ii8+PHJlY3QgeD0iODEuNzIxIiB5PSIxNTIuMzciIHdpZHRoPSIxMS4zODEiIGhlaWdodD0iMTQuMDMiIHJ5PSI1LjM5NzEiLz48cmVjdCB4PSIxMTcuMTEiIHk9IjE1Mi4zNyIgd2lkdGg9IjExLjM4MSIgaGVpZ2h0PSIxNC4wMyIgcnk9IjUuMzk3MSIvPjxwYXRoIGQ9Im0xMDUuMTEgMTAwLjkyYTMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA4IDIwLjM1NSAzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODMgMi4zOTI2aDkuNTc5OGMwLjU1MDAzLTIuMzk4NyAyLjY4OTktNC4xNzc1IDUuMjYwMS00LjE3NzVoOC4wMDI2YzIuNTcwMiAwIDQuNzA5NiAxLjc3ODkgNS4yNTk2IDQuMTc3NWg1LjAyNjZjMC4yOTYwNS0yLjcwNjIgMi41NzYtNC43OTg3IDUuMzYzNS00Ljc5ODdoOC4wMDMxYzIuNzg3NSAwIDUuMDY3NCAyLjA5MjUgNS4zNjM1IDQuNzk4N2g4LjcwN2EzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODItMi4zOTI2IDMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA5LTIwLjM1NXoiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE1LjQzbW0iIGhlaWdodD0iMTY5LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNS40MyAxNjkuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ2LjE5NCAtNjIuOTE1KSI+PHBhdGggZD0ibTg2Ljg5IDYyLjkxNWMtMS4xMjM3IDAtMi4wMjgzIDAuOTA0NTgtMi4wMjgzIDIuMDI4M3YxMS4zMzRoLTYuNjU3Yy0xMy42NjkgMC0yNC42NzMgMTEuMDA1LTI0LjY3MyAyNC42NzN2NzEuNTY2YzAgMTAuODExIDYuODg2OSAxOS45NSAxNi41MjkgMjMuMzAxaC0yLjU2ODhsLTIxLjI5OCAyNC4zMjF2MTIuNTg5aDE0LjgxN2wxOS40ODUtMjQuMzc3aDQ2LjgyNWwxOS40ODUgMjQuMzc3aDE0LjgxNnYtMTIuNTg5bC0yMS4yOTctMjQuMzJoLTIuNTY5NGM5LjY0Mi0zLjM1MDkgMTYuNTI5LTEyLjQ4OSAxNi41MjktMjMuMzAxdi03MS41NjZjMC0xMy42NjktMTEuMDA1LTI0LjY3My0yNC42NzMtMjQuNjczaC02LjY1NjR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU4LTIuMDI4My0yLjAyODMtMi4wMjgzaC0xMi41NTVjLTEuMTIzNyAwLTIuMDI4MyAwLjkwNDU4LTIuMDI4MyAyLjAyODN2MTEuMzM0aC00Ljg2ODR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU5LTIuMDI4My0yLjAyODMtMi4wMjgzem04Ljg0NjUgMjQuNDk5aDE2LjM0MmMxLjEyMzcgMCAyLjAyODMgMC45MDQ1OSAyLjAyODMgMi4wMjgzdjMuNTE0YzAgMS4xMjM3LTAuOTA0NTggMi4wMjgzLTIuMDI4MyAyLjAyODNoLTE2LjM0MmMtMS4xMjM3IDAtMi4wMjgzLTAuOTA0NTktMi4wMjgzLTIuMDI4M3YtMy41MTRjMC0xLjEyMzcgMC45MDQ1OS0yLjAyODMgMi4wMjgzLTIuMDI4M3ptLTE2LjU5MiAxOC4wNDloNDkuNTI2YzQuMDI5NyAwIDcuMjczNSAzLjI0MzggNy4yNzM1IDcuMjczNHYxMi42YzAgNC4wMjk2LTMuMjQzOCA3LjI3MzUtNy4yNzM1IDcuMjczNWgtNDkuNTI2Yy00LjAyOTcgMC03LjI3NC0zLjI0MzgtNy4yNzQtNy4yNzM1di0xMi42YzAtNC4wMjk2IDMuMjQ0My03LjI3MzQgNy4yNzQtNy4yNzM0em0tMi41NzA5IDY0LjIzN2E2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNTUtNi4xMzU1IDYuMTM1NCA2LjEzNTQgMCAwIDEgNi4xMzU1LTYuMTM1em01NC42NjcgMGE2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNS02LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMSA2LjEzNS02LjEzNXoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.94261" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTQ4LjUzbW0iIGhlaWdodD0iODkuNjY5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OC41MyA4OS42NjkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM3Ljc1OCAtMTE3LjU1KSI+PHBhdGggZD0ibTM3Ljc1OCAxODYuNTR2MjAuNjczaDE0OC41M3YtMjAuNjczaC0xNi45NDV2Ni43NDAyaC0zOC42MDV2LTYuNzQwMmgtMzcuNDI5djYuNzQwMmgtMzguNjA1di02Ljc0MDJ6Ii8+PHBhdGggZD0ibTU2LjUyNSAxMTcuNTUtMTcuODI0IDM3LjMwMXY3LjY4MjdsMC43MDI4IDAuNTI5MTcgMTUuMjk5IDExLjUxNmg1LjE3ZS00IDguNzI3NnY3LjM1M2gyNS40NTV2LTcuMzUzaDQ2LjI3MnY3LjM1M2gyNS40NTV2LTcuMzUzaDguNzI3NmwxNS4zLTExLjUxNiAwLjcwMjgtMC41MjkxN3YtNy42NzE5bC0xNS4wMjItMzcuMzExaC0xMTMuOHptMi42MTA3IDYuMjg3aDIxLjExN3YxOC4zMzloLTI4LjYxNGw3LjQ5NzItMTguMzM5em0yNi4yNzIgMGgyNC4wMzd2MTguMzM5aC0yNC4wMzd2LTE4LjMzOXptMjkuMTkzIDBoMjQuMDM3djE4LjMzOWgtMjQuMDM3di0xOC4zMzl6bTI5LjE5MyAwaDIxLjExN2w3LjQ5NjcgMTguMzM5aC0yOC42MTN2LTE4LjMzOXoiIHN0cm9rZS1taXRlcmxpbWl0PSIyLjEiIHN0cm9rZS13aWR0aD0iNC4xMTIxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2OC44OW1tIiBoZWlnaHQ9IjE0OC40Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjguODkgMTQ4LjQyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMC42NjIgLTgwLjU3OCkiPjxwYXRoIGQ9Im0yNS41ODQgMTUxLjVjLTIuNzI3IDAtNC45MjIyIDIuMTk1Ny00LjkyMjIgNC45MjI3djY3LjY1MmMwIDIuNzI3IDIuMTk1MiA0LjkyMjcgNC45MjIyIDQuOTIyN2gxNTkuMDVjMi43MjcgMCA0LjkyMjItMi4xOTU3IDQuOTIyMi00LjkyMjd2LTY3LjY1MmMwLTIuNzI3LTIuMTk1Mi00LjkyMjctNC45MjIyLTQuOTIyN2gtMjQuODA4YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDU2OCA5LjkyNWgtMTA3LjU0YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDYyLTkuOTI1eiIvPjxjaXJjbGUgY3g9IjEwNS4xMSIgY3k9IjE0OS40NiIgcj0iNjAuODcyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMTYuMDI1Ii8+PGc+PHBhdGggZD0ibTc5Ljk5NiAxMTUuODhjLTIuOTkgMC01LjM5NzEgMi40MDcxLTUuMzk3MSA1LjM5NzF2MjkuODk1YzAgMi45OSAyLjQwNzEgNS4zOTcxIDUuMzk3MSA1LjM5NzFoNTAuMjIzYzIuOTkgMCA1LjM5NzEtMi40MDcxIDUuMzk3MS01LjM5NzF2LTI5Ljg5NWMwLTIuOTktMi40MDcxLTUuMzk3MS01LjM5NzEtNS4zOTcxem04LjA4NTMgNS45NDloMTAuNjY2YzAuOTYxNTUgMCAxLjczNTMgMC43NzQyNiAxLjczNTMgMS43MzU4djcuNjE5N2MwIDAuOTYxNTUtMC43NzM3NSAxLjczNTMtMS43MzUzIDEuNzM1M2gtMTAuNjY2Yy0wLjk2MTU1IDAtMS43MzUzLTAuNzczNzUtMS43MzUzLTEuNzM1M3YtNy42MTk3YzAtMC45NjE1NSAwLjc3Mzc1LTEuNzM1OCAxLjczNTMtMS43MzU4em0yMy4zODcgMGgxMC42NjZjMC45NjE1NSAwIDEuNzM1OCAwLjc3NDI2IDEuNzM1OCAxLjczNTh2Ny42MTk3YzAgMC45NjE1NS0wLjc3NDI2IDEuNzM1My0xLjczNTggMS43MzUzaC0xMC42NjZjLTAuOTYxNTUgMC0xLjczNTgtMC43NzM3NS0xLjczNTgtMS43MzUzdi03LjYxOTdjMC0wLjk2MTU1IDAuNzc0MjYtMS43MzU4IDEuNzM1OC0xLjczNTh6Ii8+PHJlY3QgeD0iODEuNzIxIiB5PSIxNTIuMzciIHdpZHRoPSIxMS4zODEiIGhlaWdodD0iMTQuMDMiIHJ5PSI1LjM5NzEiLz48cmVjdCB4PSIxMTcuMTEiIHk9IjE1Mi4zNyIgd2lkdGg9IjExLjM4MSIgaGVpZ2h0PSIxNC4wMyIgcnk9IjUuMzk3MSIvPjxwYXRoIGQ9Im0xMDUuMTEgMTAwLjkyYTMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA4IDIwLjM1NSAzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODMgMi4zOTI2aDkuNTc5OGMwLjU1MDAzLTIuMzk4NyAyLjY4OTktNC4xNzc1IDUuMjYwMS00LjE3NzVoOC4wMDI2YzIuNTcwMiAwIDQuNzA5NiAxLjc3ODkgNS4yNTk2IDQuMTc3NWg1LjAyNjZjMC4yOTYwNS0yLjcwNjIgMi41NzYtNC43OTg3IDUuMzYzNS00Ljc5ODdoOC4wMDMxYzIuNzg3NSAwIDUuMDY3NCAyLjA5MjUgNS4zNjM1IDQuNzk4N2g4LjcwN2EzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODItMi4zOTI2IDMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA5LTIwLjM1NXoiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTU5LjU2bW0iIGhlaWdodD0iMTEyLjI0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1OS41NiAxMTIuMjQiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Ljk4MSAtODEuNDk3KSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48Y2lyY2xlIGN4PSI1Mi43MDEiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48Y2lyY2xlIGN4PSI3My4yNTkiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48cGF0aCBkPSJtNDAuMzk1IDEyNC40LTE1LjQxNSAyMy44MDl2MzcuMTUxaDE0LjIzMWMtMC4xMTk4OC0wLjcyNjE5LTAuMTgzNDUtMS40NzE4LTAuMTgzNDUtMi4yMzI5IDAtNy40ODIyIDYuMDI0LTEzLjUwNiAxMy41MDYtMTMuNTA2aDEwNC40NWM3LjQ4MjIgMCAxMy41MDYgNi4wMjQgMTMuNTA2IDEzLjUwNiAwIDAuNzYxMTktMC4wNjM2IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgxNC4yM3YtMzkuNTk1bC0xNC4zNzEtMjEuMzY2em0wLjkwMDcyIDUuNzc5YzEuOTUwOSAxZS0zIDYuMjkyMSAwIDYuMjkyMSAwIDEuNjUxOSAwIDIuOTgyMiAxLjMyOTggMi45ODIyIDIuOTgxN3YxMi41NmMwIDEuNjUxOS0xLjMzMDMgMi45ODE3LTIuOTgyMiAyLjk4MTdoLTEyLjY5NWMtMS42NTE5IDAtMi44NzIzLTIuNDU3NS0yLjA0NjQtMy44ODgxbDMuODA0OS02LjU5MDN6bTE4LjM1NSAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzIgMGgyNC42N2MxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yNC42N2MtMS42NTE5IDAtMi45ODE3LTEuMzI5OC0yLjk4MTctMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMyOTgtMi45ODE3IDIuOTgxNy0yLjk4MTd6bTM2LjczMyAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzMgMHM0LjM0MTMgMWUtMyA2LjI5MjEgMGw4LjQ0OTYgMTQuNjM1YzAuODI1OTYgMS40MzA2LTAuMzk0NDYgMy44ODgxLTIuMDQ2NCAzLjg4ODFoLTEyLjY5NWMtMS42NTE5IDAtMi45ODIyLTEuMzI5OC0yLjk4MjItMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMzMDMtMi45ODE3IDIuOTgyMi0yLjk4MTd6bS04MC44OTggNDIuMTAzYzMuMzAzOCAyLjQ1NzYgNS40MzY5IDYuMzkzMiA1LjQzNjkgMTAuODQ1IDAgMC43NjExOS0wLjA2MzU4IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgzNi45NDhjLTAuMTE5ODctMC43MjYxOS0wLjE4MzQ1LTEuNDcxOC0wLjE4MzQ1LTIuMjMyOSAwLTQuNDUyMSAyLjEzMzItOC4zODc3IDUuNDM2OS0xMC44NDV6IiBzdHJva2Utd2lkdGg9IjE0LjU4MiIvPjxjaXJjbGUgY3g9IjEzNi4yNiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjxjaXJjbGUgY3g9IjE1Ni44MiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjwvZz48cGF0aCBkPSJtOTAuNzQyIDExNi43OS0xMC43ODYtMTEuMTYgMjQuNjM4LTEzLjcxIDI1LjEwNiAxMy43MS05LjUxMDQgMTEuMTZjLTI3Ljc5NCAwLTYuNjg2My0xZS01IC0yOS40NDctMWUtNXoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLXdpZHRoPSI0LjI2Ii8+PHJlY3QgeD0iMTAyLjYzIiB5PSI4MS40OTciIHdpZHRoPSI0LjI2IiBoZWlnaHQ9IjExLjk2NCIgcnk9IjAiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzkuODdtbSIgaGVpZ2h0PSIxMjIuNjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNzkuODcgMTIyLjY4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wOCAtOTUuOTQ2KSI+PHBhdGggZD0ibTEwOS43OCAxMjEuMTd2NS4yZS00YTMxLjYgNi40NDU5IDAgMCAwLTEzLjU5NSAwLjYyOTQyaDAuMDAzNmExMC43MTYgMzAuMjcyIDY3LjgyOCAwIDAtMTEuNTkyIDQuNDUzIDEwLjcxNiAzMC4yNzIgNjcuODI4IDAgMC0xNC40OTcgOS4xODk2bC0xZS0zIDFlLTNhMTAuNzE2IDMwLjI3MiA2Ny44MjggMCAwLTAuMDIzMjUgMC4wMTkxdjcxLjU0OWg3LjMwNnYxMS42MTVoMTEuMjg3di0xMS42MTVoNDIuMTQ0djExLjYxNWgxMS4yODh2LTExLjYxNWg3LjMwNTV2LTM4LjkwN2gwLjA3OHYtMzIuNjRhMzkuNzA0IDE0LjU0NSAwIDAgMCAwLTUuMmUtNHYtNS4xZS00YTMwLjI3MiAxMC43MTYgMjIuMTcyIDAgMC0wLjAxNS0wLjAxMjkgMzAuMjcyIDEwLjcxNiAyMi4xNzIgMCAwLThlLTMgLTdlLTNsLTFlLTMgLTUuMmUtNGEzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTQuNDk4LTkuMTkwNiAzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTEuNTkyLTQuNDUzaDAuMDI4OWEzMS42IDYuNDQ1OSAwIDAgMC0xMy42Mi0wLjYyOTk0em0tMTcuMjQxIDkuMDExM2gzNC40ODNjMC40MjI1MSAwIDAuNzYyNzQgMC4zMzk3MSAwLjc2Mjc0IDAuNzYyMjN2My45MDMxYzAgMC40MjI1MS0wLjM0MDIzIDAuNzYyNzQtMC43NjI3NCAwLjc2Mjc0aC0zNC40ODNjLTAuNDIyNTEgMC0wLjc2Mjc0LTAuMzQwMjMtMC43NjI3NC0wLjc2Mjc0di0zLjkwMzFjMC0wLjQyMjUyIDAuMzQwMjMtMC43NjIyMyAwLjc2Mjc0LTAuNzYyMjN6bS0xMi4zNzEgMTAuODc3aDU5LjIyNWMxLjEyNTcgMCAyLjAzMTkgMC45MDY2OSAyLjAzMTkgMi4wMzI0djI0LjIwNmMwIDEuMTI1OC0wLjkwNjE4IDIuMDMxOS0yLjAzMTkgMi4wMzE5aC01OS4yMjVjLTEuMTI1NyAwLTIuMDMxOS0wLjkwNjE3LTIuMDMxOS0yLjAzMTl2LTI0LjIwNmMwLTEuMTI1OCAwLjkwNjE4LTIuMDMyNCAyLjAzMTktMi4wMzI0em0yLjg1NzcgNDMuNTY3YTQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzIDQuMjMxOCA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMyMyA0LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMS00LjIzMjMtNC4yMzIzIDQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzLTQuMjMxOHptNTMuNDMxIDBhNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMjMgNC4yMzE4IDQuMjMyMiA0LjIzMjIgMCAwIDEtNC4yMzIzIDQuMjMyMyA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMxOC00LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMTgtNC4yMzE4eiIvPjxwYXRoIGQ9Im05Ni43MTcgMTI1LjQzIDMwLjA0LTI4LjI4NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMi40Ii8+PHBhdGggZD0ibTExOC43MSAxMjUuNDMgMzAuMDQtMjguMjg0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIyLjQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.51563" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE1LjQzbW0iIGhlaWdodD0iMTY5LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNS40MyAxNjkuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ2LjE5NCAtNjIuOTE1KSI+PHBhdGggZD0ibTg2Ljg5IDYyLjkxNWMtMS4xMjM3IDAtMi4wMjgzIDAuOTA0NTgtMi4wMjgzIDIuMDI4M3YxMS4zMzRoLTYuNjU3Yy0xMy42NjkgMC0yNC42NzMgMTEuMDA1LTI0LjY3MyAyNC42NzN2NzEuNTY2YzAgMTAuODExIDYuODg2OSAxOS45NSAxNi41MjkgMjMuMzAxaC0yLjU2ODhsLTIxLjI5OCAyNC4zMjF2MTIuNTg5aDE0LjgxN2wxOS40ODUtMjQuMzc3aDQ2LjgyNWwxOS40ODUgMjQuMzc3aDE0LjgxNnYtMTIuNTg5bC0yMS4yOTctMjQuMzJoLTIuNTY5NGM5LjY0Mi0zLjM1MDkgMTYuNTI5LTEyLjQ4OSAxNi41MjktMjMuMzAxdi03MS41NjZjMC0xMy42NjktMTEuMDA1LTI0LjY3My0yNC42NzMtMjQuNjczaC02LjY1NjR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU4LTIuMDI4My0yLjAyODMtMi4wMjgzaC0xMi41NTVjLTEuMTIzNyAwLTIuMDI4MyAwLjkwNDU4LTIuMDI4MyAyLjAyODN2MTEuMzM0aC00Ljg2ODR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU5LTIuMDI4My0yLjAyODMtMi4wMjgzem04Ljg0NjUgMjQuNDk5aDE2LjM0MmMxLjEyMzcgMCAyLjAyODMgMC45MDQ1OSAyLjAyODMgMi4wMjgzdjMuNTE0YzAgMS4xMjM3LTAuOTA0NTggMi4wMjgzLTIuMDI4MyAyLjAyODNoLTE2LjM0MmMtMS4xMjM3IDAtMi4wMjgzLTAuOTA0NTktMi4wMjgzLTIuMDI4M3YtMy41MTRjMC0xLjEyMzcgMC45MDQ1OS0yLjAyODMgMi4wMjgzLTIuMDI4M3ptLTE2LjU5MiAxOC4wNDloNDkuNTI2YzQuMDI5NyAwIDcuMjczNSAzLjI0MzggNy4yNzM1IDcuMjczNHYxMi42YzAgNC4wMjk2LTMuMjQzOCA3LjI3MzUtNy4yNzM1IDcuMjczNWgtNDkuNTI2Yy00LjAyOTcgMC03LjI3NC0zLjI0MzgtNy4yNzQtNy4yNzM1di0xMi42YzAtNC4wMjk2IDMuMjQ0My03LjI3MzQgNy4yNzQtNy4yNzM0em0tMi41NzA5IDY0LjIzN2E2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNTUtNi4xMzU1IDYuMTM1NCA2LjEzNTQgMCAwIDEgNi4xMzU1LTYuMTM1em01NC42NjcgMGE2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNS02LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMSA2LjEzNS02LjEzNXoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.94261" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTQ4LjUzbW0iIGhlaWdodD0iODkuNjY5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OC41MyA4OS42NjkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM3Ljc1OCAtMTE3LjU1KSI+PHBhdGggZD0ibTM3Ljc1OCAxODYuNTR2MjAuNjczaDE0OC41M3YtMjAuNjczaC0xNi45NDV2Ni43NDAyaC0zOC42MDV2LTYuNzQwMmgtMzcuNDI5djYuNzQwMmgtMzguNjA1di02Ljc0MDJ6Ii8+PHBhdGggZD0ibTU2LjUyNSAxMTcuNTUtMTcuODI0IDM3LjMwMXY3LjY4MjdsMC43MDI4IDAuNTI5MTcgMTUuMjk5IDExLjUxNmg1LjE3ZS00IDguNzI3NnY3LjM1M2gyNS40NTV2LTcuMzUzaDQ2LjI3MnY3LjM1M2gyNS40NTV2LTcuMzUzaDguNzI3NmwxNS4zLTExLjUxNiAwLjcwMjgtMC41MjkxN3YtNy42NzE5bC0xNS4wMjItMzcuMzExaC0xMTMuOHptMi42MTA3IDYuMjg3aDIxLjExN3YxOC4zMzloLTI4LjYxNGw3LjQ5NzItMTguMzM5em0yNi4yNzIgMGgyNC4wMzd2MTguMzM5aC0yNC4wMzd2LTE4LjMzOXptMjkuMTkzIDBoMjQuMDM3djE4LjMzOWgtMjQuMDM3di0xOC4zMzl6bTI5LjE5MyAwaDIxLjExN2w3LjQ5NjcgMTguMzM5aC0yOC42MTN2LTE4LjMzOXoiIHN0cm9rZS1taXRlcmxpbWl0PSIyLjEiIHN0cm9rZS13aWR0aD0iNC4xMTIxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2OC44OW1tIiBoZWlnaHQ9IjE0OC40Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjguODkgMTQ4LjQyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMC42NjIgLTgwLjU3OCkiPjxwYXRoIGQ9Im0yNS41ODQgMTUxLjVjLTIuNzI3IDAtNC45MjIyIDIuMTk1Ny00LjkyMjIgNC45MjI3djY3LjY1MmMwIDIuNzI3IDIuMTk1MiA0LjkyMjcgNC45MjIyIDQuOTIyN2gxNTkuMDVjMi43MjcgMCA0LjkyMjItMi4xOTU3IDQuOTIyMi00LjkyMjd2LTY3LjY1MmMwLTIuNzI3LTIuMTk1Mi00LjkyMjctNC45MjIyLTQuOTIyN2gtMjQuODA4YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDU2OCA5LjkyNWgtMTA3LjU0YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDYyLTkuOTI1eiIvPjxjaXJjbGUgY3g9IjEwNS4xMSIgY3k9IjE0OS40NiIgcj0iNjAuODcyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMTYuMDI1Ii8+PGc+PHBhdGggZD0ibTc5Ljk5NiAxMTUuODhjLTIuOTkgMC01LjM5NzEgMi40MDcxLTUuMzk3MSA1LjM5NzF2MjkuODk1YzAgMi45OSAyLjQwNzEgNS4zOTcxIDUuMzk3MSA1LjM5NzFoNTAuMjIzYzIuOTkgMCA1LjM5NzEtMi40MDcxIDUuMzk3MS01LjM5NzF2LTI5Ljg5NWMwLTIuOTktMi40MDcxLTUuMzk3MS01LjM5NzEtNS4zOTcxem04LjA4NTMgNS45NDloMTAuNjY2YzAuOTYxNTUgMCAxLjczNTMgMC43NzQyNiAxLjczNTMgMS43MzU4djcuNjE5N2MwIDAuOTYxNTUtMC43NzM3NSAxLjczNTMtMS43MzUzIDEuNzM1M2gtMTAuNjY2Yy0wLjk2MTU1IDAtMS43MzUzLTAuNzczNzUtMS43MzUzLTEuNzM1M3YtNy42MTk3YzAtMC45NjE1NSAwLjc3Mzc1LTEuNzM1OCAxLjczNTMtMS43MzU4em0yMy4zODcgMGgxMC42NjZjMC45NjE1NSAwIDEuNzM1OCAwLjc3NDI2IDEuNzM1OCAxLjczNTh2Ny42MTk3YzAgMC45NjE1NS0wLjc3NDI2IDEuNzM1My0xLjczNTggMS43MzUzaC0xMC42NjZjLTAuOTYxNTUgMC0xLjczNTgtMC43NzM3NS0xLjczNTgtMS43MzUzdi03LjYxOTdjMC0wLjk2MTU1IDAuNzc0MjYtMS43MzU4IDEuNzM1OC0xLjczNTh6Ii8+PHJlY3QgeD0iODEuNzIxIiB5PSIxNTIuMzciIHdpZHRoPSIxMS4zODEiIGhlaWdodD0iMTQuMDMiIHJ5PSI1LjM5NzEiLz48cmVjdCB4PSIxMTcuMTEiIHk9IjE1Mi4zNyIgd2lkdGg9IjExLjM4MSIgaGVpZ2h0PSIxNC4wMyIgcnk9IjUuMzk3MSIvPjxwYXRoIGQ9Im0xMDUuMTEgMTAwLjkyYTMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA4IDIwLjM1NSAzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODMgMi4zOTI2aDkuNTc5OGMwLjU1MDAzLTIuMzk4NyAyLjY4OTktNC4xNzc1IDUuMjYwMS00LjE3NzVoOC4wMDI2YzIuNTcwMiAwIDQuNzA5NiAxLjc3ODkgNS4yNTk2IDQuMTc3NWg1LjAyNjZjMC4yOTYwNS0yLjcwNjIgMi41NzYtNC43OTg3IDUuMzYzNS00Ljc5ODdoOC4wMDMxYzIuNzg3NSAwIDUuMDY3NCAyLjA5MjUgNS4zNjM1IDQuNzk4N2g4LjcwN2EzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODItMi4zOTI2IDMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA5LTIwLjM1NXoiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTU5LjU2bW0iIGhlaWdodD0iMTEyLjI0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1OS41NiAxMTIuMjQiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Ljk4MSAtODEuNDk3KSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48Y2lyY2xlIGN4PSI1Mi43MDEiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48Y2lyY2xlIGN4PSI3My4yNTkiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48cGF0aCBkPSJtNDAuMzk1IDEyNC40LTE1LjQxNSAyMy44MDl2MzcuMTUxaDE0LjIzMWMtMC4xMTk4OC0wLjcyNjE5LTAuMTgzNDUtMS40NzE4LTAuMTgzNDUtMi4yMzI5IDAtNy40ODIyIDYuMDI0LTEzLjUwNiAxMy41MDYtMTMuNTA2aDEwNC40NWM3LjQ4MjIgMCAxMy41MDYgNi4wMjQgMTMuNTA2IDEzLjUwNiAwIDAuNzYxMTktMC4wNjM2IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgxNC4yM3YtMzkuNTk1bC0xNC4zNzEtMjEuMzY2em0wLjkwMDcyIDUuNzc5YzEuOTUwOSAxZS0zIDYuMjkyMSAwIDYuMjkyMSAwIDEuNjUxOSAwIDIuOTgyMiAxLjMyOTggMi45ODIyIDIuOTgxN3YxMi41NmMwIDEuNjUxOS0xLjMzMDMgMi45ODE3LTIuOTgyMiAyLjk4MTdoLTEyLjY5NWMtMS42NTE5IDAtMi44NzIzLTIuNDU3NS0yLjA0NjQtMy44ODgxbDMuODA0OS02LjU5MDN6bTE4LjM1NSAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzIgMGgyNC42N2MxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yNC42N2MtMS42NTE5IDAtMi45ODE3LTEuMzI5OC0yLjk4MTctMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMyOTgtMi45ODE3IDIuOTgxNy0yLjk4MTd6bTM2LjczMyAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzMgMHM0LjM0MTMgMWUtMyA2LjI5MjEgMGw4LjQ0OTYgMTQuNjM1YzAuODI1OTYgMS40MzA2LTAuMzk0NDYgMy44ODgxLTIuMDQ2NCAzLjg4ODFoLTEyLjY5NWMtMS42NTE5IDAtMi45ODIyLTEuMzI5OC0yLjk4MjItMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMzMDMtMi45ODE3IDIuOTgyMi0yLjk4MTd6bS04MC44OTggNDIuMTAzYzMuMzAzOCAyLjQ1NzYgNS40MzY5IDYuMzkzMiA1LjQzNjkgMTAuODQ1IDAgMC43NjExOS0wLjA2MzU4IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgzNi45NDhjLTAuMTE5ODctMC43MjYxOS0wLjE4MzQ1LTEuNDcxOC0wLjE4MzQ1LTIuMjMyOSAwLTQuNDUyMSAyLjEzMzItOC4zODc3IDUuNDM2OS0xMC44NDV6IiBzdHJva2Utd2lkdGg9IjE0LjU4MiIvPjxjaXJjbGUgY3g9IjEzNi4yNiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjxjaXJjbGUgY3g9IjE1Ni44MiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjwvZz48cGF0aCBkPSJtOTAuNzQyIDExNi43OS0xMC43ODYtMTEuMTYgMjQuNjM4LTEzLjcxIDI1LjEwNiAxMy43MS05LjUxMDQgMTEuMTZjLTI3Ljc5NCAwLTYuNjg2My0xZS01IC0yOS40NDctMWUtNXoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLXdpZHRoPSI0LjI2Ii8+PHJlY3QgeD0iMTAyLjYzIiB5PSI4MS40OTciIHdpZHRoPSI0LjI2IiBoZWlnaHQ9IjExLjk2NCIgcnk9IjAiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTU5LjU2bW0iIGhlaWdodD0iMTEyLjI0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1OS41NiAxMTIuMjQiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Ljk4MSAtODEuNDk3KSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48Y2lyY2xlIGN4PSI1Mi43MDEiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48Y2lyY2xlIGN4PSI3My4yNTkiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48cGF0aCBkPSJtNDAuMzk1IDEyNC40LTE1LjQxNSAyMy44MDl2MzcuMTUxaDE0LjIzMWMtMC4xMTk4OC0wLjcyNjE5LTAuMTgzNDUtMS40NzE4LTAuMTgzNDUtMi4yMzI5IDAtNy40ODIyIDYuMDI0LTEzLjUwNiAxMy41MDYtMTMuNTA2aDEwNC40NWM3LjQ4MjIgMCAxMy41MDYgNi4wMjQgMTMuNTA2IDEzLjUwNiAwIDAuNzYxMTktMC4wNjM2IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgxNC4yM3YtMzkuNTk1bC0xNC4zNzEtMjEuMzY2em0wLjkwMDcyIDUuNzc5YzEuOTUwOSAxZS0zIDYuMjkyMSAwIDYuMjkyMSAwIDEuNjUxOSAwIDIuOTgyMiAxLjMyOTggMi45ODIyIDIuOTgxN3YxMi41NmMwIDEuNjUxOS0xLjMzMDMgMi45ODE3LTIuOTgyMiAyLjk4MTdoLTEyLjY5NWMtMS42NTE5IDAtMi44NzIzLTIuNDU3NS0yLjA0NjQtMy44ODgxbDMuODA0OS02LjU5MDN6bTE4LjM1NSAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzIgMGgyNC42N2MxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yNC42N2MtMS42NTE5IDAtMi45ODE3LTEuMzI5OC0yLjk4MTctMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMyOTgtMi45ODE3IDIuOTgxNy0yLjk4MTd6bTM2LjczMyAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzMgMHM0LjM0MTMgMWUtMyA2LjI5MjEgMGw4LjQ0OTYgMTQuNjM1YzAuODI1OTYgMS40MzA2LTAuMzk0NDYgMy44ODgxLTIuMDQ2NCAzLjg4ODFoLTEyLjY5NWMtMS42NTE5IDAtMi45ODIyLTEuMzI5OC0yLjk4MjItMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMzMDMtMi45ODE3IDIuOTgyMi0yLjk4MTd6bS04MC44OTggNDIuMTAzYzMuMzAzOCAyLjQ1NzYgNS40MzY5IDYuMzkzMiA1LjQzNjkgMTAuODQ1IDAgMC43NjExOS0wLjA2MzU4IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgzNi45NDhjLTAuMTE5ODctMC43MjYxOS0wLjE4MzQ1LTEuNDcxOC0wLjE4MzQ1LTIuMjMyOSAwLTQuNDUyMSAyLjEzMzItOC4zODc3IDUuNDM2OS0xMC44NDV6IiBzdHJva2Utd2lkdGg9IjE0LjU4MiIvPjxjaXJjbGUgY3g9IjEzNi4yNiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjxjaXJjbGUgY3g9IjE1Ni44MiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjwvZz48cGF0aCBkPSJtOTAuNzQyIDExNi43OS0xMC43ODYtMTEuMTYgMjQuNjM4LTEzLjcxIDI1LjEwNiAxMy43MS05LjUxMDQgMTEuMTZjLTI3Ljc5NCAwLTYuNjg2My0xZS01IC0yOS40NDctMWUtNXoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLXdpZHRoPSI0LjI2Ii8+PHJlY3QgeD0iMTAyLjYzIiB5PSI4MS40OTciIHdpZHRoPSI0LjI2IiBoZWlnaHQ9IjExLjk2NCIgcnk9IjAiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzkuODdtbSIgaGVpZ2h0PSIxMjIuNjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNzkuODcgMTIyLjY4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wOCAtOTUuOTQ2KSI+PHBhdGggZD0ibTEwOS43OCAxMjEuMTd2NS4yZS00YTMxLjYgNi40NDU5IDAgMCAwLTEzLjU5NSAwLjYyOTQyaDAuMDAzNmExMC43MTYgMzAuMjcyIDY3LjgyOCAwIDAtMTEuNTkyIDQuNDUzIDEwLjcxNiAzMC4yNzIgNjcuODI4IDAgMC0xNC40OTcgOS4xODk2bC0xZS0zIDFlLTNhMTAuNzE2IDMwLjI3MiA2Ny44MjggMCAwLTAuMDIzMjUgMC4wMTkxdjcxLjU0OWg3LjMwNnYxMS42MTVoMTEuMjg3di0xMS42MTVoNDIuMTQ0djExLjYxNWgxMS4yODh2LTExLjYxNWg3LjMwNTV2LTM4LjkwN2gwLjA3OHYtMzIuNjRhMzkuNzA0IDE0LjU0NSAwIDAgMCAwLTUuMmUtNHYtNS4xZS00YTMwLjI3MiAxMC43MTYgMjIuMTcyIDAgMC0wLjAxNS0wLjAxMjkgMzAuMjcyIDEwLjcxNiAyMi4xNzIgMCAwLThlLTMgLTdlLTNsLTFlLTMgLTUuMmUtNGEzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTQuNDk4LTkuMTkwNiAzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTEuNTkyLTQuNDUzaDAuMDI4OWEzMS42IDYuNDQ1OSAwIDAgMC0xMy42Mi0wLjYyOTk0em0tMTcuMjQxIDkuMDExM2gzNC40ODNjMC40MjI1MSAwIDAuNzYyNzQgMC4zMzk3MSAwLjc2Mjc0IDAuNzYyMjN2My45MDMxYzAgMC40MjI1MS0wLjM0MDIzIDAuNzYyNzQtMC43NjI3NCAwLjc2Mjc0aC0zNC40ODNjLTAuNDIyNTEgMC0wLjc2Mjc0LTAuMzQwMjMtMC43NjI3NC0wLjc2Mjc0di0zLjkwMzFjMC0wLjQyMjUyIDAuMzQwMjMtMC43NjIyMyAwLjc2Mjc0LTAuNzYyMjN6bS0xMi4zNzEgMTAuODc3aDU5LjIyNWMxLjEyNTcgMCAyLjAzMTkgMC45MDY2OSAyLjAzMTkgMi4wMzI0djI0LjIwNmMwIDEuMTI1OC0wLjkwNjE4IDIuMDMxOS0yLjAzMTkgMi4wMzE5aC01OS4yMjVjLTEuMTI1NyAwLTIuMDMxOS0wLjkwNjE3LTIuMDMxOS0yLjAzMTl2LTI0LjIwNmMwLTEuMTI1OCAwLjkwNjE4LTIuMDMyNCAyLjAzMTktMi4wMzI0em0yLjg1NzcgNDMuNTY3YTQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzIDQuMjMxOCA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMyMyA0LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMS00LjIzMjMtNC4yMzIzIDQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzLTQuMjMxOHptNTMuNDMxIDBhNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMjMgNC4yMzE4IDQuMjMyMiA0LjIzMjIgMCAwIDEtNC4yMzIzIDQuMjMyMyA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMxOC00LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMTgtNC4yMzE4eiIvPjxwYXRoIGQ9Im05Ni43MTcgMTI1LjQzIDMwLjA0LTI4LjI4NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMi40Ii8+PHBhdGggZD0ibTExOC43MSAxMjUuNDMgMzAuMDQtMjguMjg0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIyLjQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.51563" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE1LjQzbW0iIGhlaWdodD0iMTY5LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNS40MyAxNjkuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ2LjE5NCAtNjIuOTE1KSI+PHBhdGggZD0ibTg2Ljg5IDYyLjkxNWMtMS4xMjM3IDAtMi4wMjgzIDAuOTA0NTgtMi4wMjgzIDIuMDI4M3YxMS4zMzRoLTYuNjU3Yy0xMy42NjkgMC0yNC42NzMgMTEuMDA1LTI0LjY3MyAyNC42NzN2NzEuNTY2YzAgMTAuODExIDYuODg2OSAxOS45NSAxNi41MjkgMjMuMzAxaC0yLjU2ODhsLTIxLjI5OCAyNC4zMjF2MTIuNTg5aDE0LjgxN2wxOS40ODUtMjQuMzc3aDQ2LjgyNWwxOS40ODUgMjQuMzc3aDE0LjgxNnYtMTIuNTg5bC0yMS4yOTctMjQuMzJoLTIuNTY5NGM5LjY0Mi0zLjM1MDkgMTYuNTI5LTEyLjQ4OSAxNi41MjktMjMuMzAxdi03MS41NjZjMC0xMy42NjktMTEuMDA1LTI0LjY3My0yNC42NzMtMjQuNjczaC02LjY1NjR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU4LTIuMDI4My0yLjAyODMtMi4wMjgzaC0xMi41NTVjLTEuMTIzNyAwLTIuMDI4MyAwLjkwNDU4LTIuMDI4MyAyLjAyODN2MTEuMzM0aC00Ljg2ODR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU5LTIuMDI4My0yLjAyODMtMi4wMjgzem04Ljg0NjUgMjQuNDk5aDE2LjM0MmMxLjEyMzcgMCAyLjAyODMgMC45MDQ1OSAyLjAyODMgMi4wMjgzdjMuNTE0YzAgMS4xMjM3LTAuOTA0NTggMi4wMjgzLTIuMDI4MyAyLjAyODNoLTE2LjM0MmMtMS4xMjM3IDAtMi4wMjgzLTAuOTA0NTktMi4wMjgzLTIuMDI4M3YtMy41MTRjMC0xLjEyMzcgMC45MDQ1OS0yLjAyODMgMi4wMjgzLTIuMDI4M3ptLTE2LjU5MiAxOC4wNDloNDkuNTI2YzQuMDI5NyAwIDcuMjczNSAzLjI0MzggNy4yNzM1IDcuMjczNHYxMi42YzAgNC4wMjk2LTMuMjQzOCA3LjI3MzUtNy4yNzM1IDcuMjczNWgtNDkuNTI2Yy00LjAyOTcgMC03LjI3NC0zLjI0MzgtNy4yNzQtNy4yNzM1di0xMi42YzAtNC4wMjk2IDMuMjQ0My03LjI3MzQgNy4yNzQtNy4yNzM0em0tMi41NzA5IDY0LjIzN2E2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNTUtNi4xMzU1IDYuMTM1NCA2LjEzNTQgMCAwIDEgNi4xMzU1LTYuMTM1em01NC42NjcgMGE2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNS02LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMSA2LjEzNS02LjEzNXoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.94261" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTQ4LjUzbW0iIGhlaWdodD0iODkuNjY5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OC41MyA4OS42NjkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM3Ljc1OCAtMTE3LjU1KSI+PHBhdGggZD0ibTM3Ljc1OCAxODYuNTR2MjAuNjczaDE0OC41M3YtMjAuNjczaC0xNi45NDV2Ni43NDAyaC0zOC42MDV2LTYuNzQwMmgtMzcuNDI5djYuNzQwMmgtMzguNjA1di02Ljc0MDJ6Ii8+PHBhdGggZD0ibTU2LjUyNSAxMTcuNTUtMTcuODI0IDM3LjMwMXY3LjY4MjdsMC43MDI4IDAuNTI5MTcgMTUuMjk5IDExLjUxNmg1LjE3ZS00IDguNzI3NnY3LjM1M2gyNS40NTV2LTcuMzUzaDQ2LjI3MnY3LjM1M2gyNS40NTV2LTcuMzUzaDguNzI3NmwxNS4zLTExLjUxNiAwLjcwMjgtMC41MjkxN3YtNy42NzE5bC0xNS4wMjItMzcuMzExaC0xMTMuOHptMi42MTA3IDYuMjg3aDIxLjExN3YxOC4zMzloLTI4LjYxNGw3LjQ5NzItMTguMzM5em0yNi4yNzIgMGgyNC4wMzd2MTguMzM5aC0yNC4wMzd2LTE4LjMzOXptMjkuMTkzIDBoMjQuMDM3djE4LjMzOWgtMjQuMDM3di0xOC4zMzl6bTI5LjE5MyAwaDIxLjExN2w3LjQ5NjcgMTguMzM5aC0yOC42MTN2LTE4LjMzOXoiIHN0cm9rZS1taXRlcmxpbWl0PSIyLjEiIHN0cm9rZS13aWR0aD0iNC4xMTIxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2OC44OW1tIiBoZWlnaHQ9IjE0OC40Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjguODkgMTQ4LjQyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMC42NjIgLTgwLjU3OCkiPjxwYXRoIGQ9Im0yNS41ODQgMTUxLjVjLTIuNzI3IDAtNC45MjIyIDIuMTk1Ny00LjkyMjIgNC45MjI3djY3LjY1MmMwIDIuNzI3IDIuMTk1MiA0LjkyMjcgNC45MjIyIDQuOTIyN2gxNTkuMDVjMi43MjcgMCA0LjkyMjItMi4xOTU3IDQuOTIyMi00LjkyMjd2LTY3LjY1MmMwLTIuNzI3LTIuMTk1Mi00LjkyMjctNC45MjIyLTQuOTIyN2gtMjQuODA4YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDU2OCA5LjkyNWgtMTA3LjU0YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDYyLTkuOTI1eiIvPjxjaXJjbGUgY3g9IjEwNS4xMSIgY3k9IjE0OS40NiIgcj0iNjAuODcyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMTYuMDI1Ii8+PGc+PHBhdGggZD0ibTc5Ljk5NiAxMTUuODhjLTIuOTkgMC01LjM5NzEgMi40MDcxLTUuMzk3MSA1LjM5NzF2MjkuODk1YzAgMi45OSAyLjQwNzEgNS4zOTcxIDUuMzk3MSA1LjM5NzFoNTAuMjIzYzIuOTkgMCA1LjM5NzEtMi40MDcxIDUuMzk3MS01LjM5NzF2LTI5Ljg5NWMwLTIuOTktMi40MDcxLTUuMzk3MS01LjM5NzEtNS4zOTcxem04LjA4NTMgNS45NDloMTAuNjY2YzAuOTYxNTUgMCAxLjczNTMgMC43NzQyNiAxLjczNTMgMS43MzU4djcuNjE5N2MwIDAuOTYxNTUtMC43NzM3NSAxLjczNTMtMS43MzUzIDEuNzM1M2gtMTAuNjY2Yy0wLjk2MTU1IDAtMS43MzUzLTAuNzczNzUtMS43MzUzLTEuNzM1M3YtNy42MTk3YzAtMC45NjE1NSAwLjc3Mzc1LTEuNzM1OCAxLjczNTMtMS43MzU4em0yMy4zODcgMGgxMC42NjZjMC45NjE1NSAwIDEuNzM1OCAwLjc3NDI2IDEuNzM1OCAxLjczNTh2Ny42MTk3YzAgMC45NjE1NS0wLjc3NDI2IDEuNzM1My0xLjczNTggMS43MzUzaC0xMC42NjZjLTAuOTYxNTUgMC0xLjczNTgtMC43NzM3NS0xLjczNTgtMS43MzUzdi03LjYxOTdjMC0wLjk2MTU1IDAuNzc0MjYtMS43MzU4IDEuNzM1OC0xLjczNTh6Ii8+PHJlY3QgeD0iODEuNzIxIiB5PSIxNTIuMzciIHdpZHRoPSIxMS4zODEiIGhlaWdodD0iMTQuMDMiIHJ5PSI1LjM5NzEiLz48cmVjdCB4PSIxMTcuMTEiIHk9IjE1Mi4zNyIgd2lkdGg9IjExLjM4MSIgaGVpZ2h0PSIxNC4wMyIgcnk9IjUuMzk3MSIvPjxwYXRoIGQ9Im0xMDUuMTEgMTAwLjkyYTMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA4IDIwLjM1NSAzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODMgMi4zOTI2aDkuNTc5OGMwLjU1MDAzLTIuMzk4NyAyLjY4OTktNC4xNzc1IDUuMjYwMS00LjE3NzVoOC4wMDI2YzIuNTcwMiAwIDQuNzA5NiAxLjc3ODkgNS4yNTk2IDQuMTc3NWg1LjAyNjZjMC4yOTYwNS0yLjcwNjIgMi41NzYtNC43OTg3IDUuMzYzNS00Ljc5ODdoOC4wMDMxYzIuNzg3NSAwIDUuMDY3NCAyLjA5MjUgNS4zNjM1IDQuNzk4N2g4LjcwN2EzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODItMi4zOTI2IDMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA5LTIwLjM1NXoiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTU5LjU2bW0iIGhlaWdodD0iMTEyLjI0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1OS41NiAxMTIuMjQiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Ljk4MSAtODEuNDk3KSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48Y2lyY2xlIGN4PSI1Mi43MDEiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48Y2lyY2xlIGN4PSI3My4yNTkiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48cGF0aCBkPSJtNDAuMzk1IDEyNC40LTE1LjQxNSAyMy44MDl2MzcuMTUxaDE0LjIzMWMtMC4xMTk4OC0wLjcyNjE5LTAuMTgzNDUtMS40NzE4LTAuMTgzNDUtMi4yMzI5IDAtNy40ODIyIDYuMDI0LTEzLjUwNiAxMy41MDYtMTMuNTA2aDEwNC40NWM3LjQ4MjIgMCAxMy41MDYgNi4wMjQgMTMuNTA2IDEzLjUwNiAwIDAuNzYxMTktMC4wNjM2IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgxNC4yM3YtMzkuNTk1bC0xNC4zNzEtMjEuMzY2em0wLjkwMDcyIDUuNzc5YzEuOTUwOSAxZS0zIDYuMjkyMSAwIDYuMjkyMSAwIDEuNjUxOSAwIDIuOTgyMiAxLjMyOTggMi45ODIyIDIuOTgxN3YxMi41NmMwIDEuNjUxOS0xLjMzMDMgMi45ODE3LTIuOTgyMiAyLjk4MTdoLTEyLjY5NWMtMS42NTE5IDAtMi44NzIzLTIuNDU3NS0yLjA0NjQtMy44ODgxbDMuODA0OS02LjU5MDN6bTE4LjM1NSAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzIgMGgyNC42N2MxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yNC42N2MtMS42NTE5IDAtMi45ODE3LTEuMzI5OC0yLjk4MTctMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMyOTgtMi45ODE3IDIuOTgxNy0yLjk4MTd6bTM2LjczMyAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzMgMHM0LjM0MTMgMWUtMyA2LjI5MjEgMGw4LjQ0OTYgMTQuNjM1YzAuODI1OTYgMS40MzA2LTAuMzk0NDYgMy44ODgxLTIuMDQ2NCAzLjg4ODFoLTEyLjY5NWMtMS42NTE5IDAtMi45ODIyLTEuMzI5OC0yLjk4MjItMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMzMDMtMi45ODE3IDIuOTgyMi0yLjk4MTd6bS04MC44OTggNDIuMTAzYzMuMzAzOCAyLjQ1NzYgNS40MzY5IDYuMzkzMiA1LjQzNjkgMTAuODQ1IDAgMC43NjExOS0wLjA2MzU4IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgzNi45NDhjLTAuMTE5ODctMC43MjYxOS0wLjE4MzQ1LTEuNDcxOC0wLjE4MzQ1LTIuMjMyOSAwLTQuNDUyMSAyLjEzMzItOC4zODc3IDUuNDM2OS0xMC44NDV6IiBzdHJva2Utd2lkdGg9IjE0LjU4MiIvPjxjaXJjbGUgY3g9IjEzNi4yNiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjxjaXJjbGUgY3g9IjE1Ni44MiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjwvZz48cGF0aCBkPSJtOTAuNzQyIDExNi43OS0xMC43ODYtMTEuMTYgMjQuNjM4LTEzLjcxIDI1LjEwNiAxMy43MS05LjUxMDQgMTEuMTZjLTI3Ljc5NCAwLTYuNjg2My0xZS01IC0yOS40NDctMWUtNXoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLXdpZHRoPSI0LjI2Ii8+PHJlY3QgeD0iMTAyLjYzIiB5PSI4MS40OTciIHdpZHRoPSI0LjI2IiBoZWlnaHQ9IjExLjk2NCIgcnk9IjAiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzkuODdtbSIgaGVpZ2h0PSIxMjIuNjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNzkuODcgMTIyLjY4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wOCAtOTUuOTQ2KSI+PHBhdGggZD0ibTEwOS43OCAxMjEuMTd2NS4yZS00YTMxLjYgNi40NDU5IDAgMCAwLTEzLjU5NSAwLjYyOTQyaDAuMDAzNmExMC43MTYgMzAuMjcyIDY3LjgyOCAwIDAtMTEuNTkyIDQuNDUzIDEwLjcxNiAzMC4yNzIgNjcuODI4IDAgMC0xNC40OTcgOS4xODk2bC0xZS0zIDFlLTNhMTAuNzE2IDMwLjI3MiA2Ny44MjggMCAwLTAuMDIzMjUgMC4wMTkxdjcxLjU0OWg3LjMwNnYxMS42MTVoMTEuMjg3di0xMS42MTVoNDIuMTQ0djExLjYxNWgxMS4yODh2LTExLjYxNWg3LjMwNTV2LTM4LjkwN2gwLjA3OHYtMzIuNjRhMzkuNzA0IDE0LjU0NSAwIDAgMCAwLTUuMmUtNHYtNS4xZS00YTMwLjI3MiAxMC43MTYgMjIuMTcyIDAgMC0wLjAxNS0wLjAxMjkgMzAuMjcyIDEwLjcxNiAyMi4xNzIgMCAwLThlLTMgLTdlLTNsLTFlLTMgLTUuMmUtNGEzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTQuNDk4LTkuMTkwNiAzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTEuNTkyLTQuNDUzaDAuMDI4OWEzMS42IDYuNDQ1OSAwIDAgMC0xMy42Mi0wLjYyOTk0em0tMTcuMjQxIDkuMDExM2gzNC40ODNjMC40MjI1MSAwIDAuNzYyNzQgMC4zMzk3MSAwLjc2Mjc0IDAuNzYyMjN2My45MDMxYzAgMC40MjI1MS0wLjM0MDIzIDAuNzYyNzQtMC43NjI3NCAwLjc2Mjc0aC0zNC40ODNjLTAuNDIyNTEgMC0wLjc2Mjc0LTAuMzQwMjMtMC43NjI3NC0wLjc2Mjc0di0zLjkwMzFjMC0wLjQyMjUyIDAuMzQwMjMtMC43NjIyMyAwLjc2Mjc0LTAuNzYyMjN6bS0xMi4zNzEgMTAuODc3aDU5LjIyNWMxLjEyNTcgMCAyLjAzMTkgMC45MDY2OSAyLjAzMTkgMi4wMzI0djI0LjIwNmMwIDEuMTI1OC0wLjkwNjE4IDIuMDMxOS0yLjAzMTkgMi4wMzE5aC01OS4yMjVjLTEuMTI1NyAwLTIuMDMxOS0wLjkwNjE3LTIuMDMxOS0yLjAzMTl2LTI0LjIwNmMwLTEuMTI1OCAwLjkwNjE4LTIuMDMyNCAyLjAzMTktMi4wMzI0em0yLjg1NzcgNDMuNTY3YTQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzIDQuMjMxOCA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMyMyA0LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMS00LjIzMjMtNC4yMzIzIDQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzLTQuMjMxOHptNTMuNDMxIDBhNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMjMgNC4yMzE4IDQuMjMyMiA0LjIzMjIgMCAwIDEtNC4yMzIzIDQuMjMyMyA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMxOC00LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMTgtNC4yMzE4eiIvPjxwYXRoIGQ9Im05Ni43MTcgMTI1LjQzIDMwLjA0LTI4LjI4NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMi40Ii8+PHBhdGggZD0ibTExOC43MSAxMjUuNDMgMzAuMDQtMjguMjg0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIyLjQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.51563" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE1LjQzbW0iIGhlaWdodD0iMTY5LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNS40MyAxNjkuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ2LjE5NCAtNjIuOTE1KSI+PHBhdGggZD0ibTg2Ljg5IDYyLjkxNWMtMS4xMjM3IDAtMi4wMjgzIDAuOTA0NTgtMi4wMjgzIDIuMDI4M3YxMS4zMzRoLTYuNjU3Yy0xMy42NjkgMC0yNC42NzMgMTEuMDA1LTI0LjY3MyAyNC42NzN2NzEuNTY2YzAgMTAuODExIDYuODg2OSAxOS45NSAxNi41MjkgMjMuMzAxaC0yLjU2ODhsLTIxLjI5OCAyNC4zMjF2MTIuNTg5aDE0LjgxN2wxOS40ODUtMjQuMzc3aDQ2LjgyNWwxOS40ODUgMjQuMzc3aDE0LjgxNnYtMTIuNTg5bC0yMS4yOTctMjQuMzJoLTIuNTY5NGM5LjY0Mi0zLjM1MDkgMTYuNTI5LTEyLjQ4OSAxNi41MjktMjMuMzAxdi03MS41NjZjMC0xMy42NjktMTEuMDA1LTI0LjY3My0yNC42NzMtMjQuNjczaC02LjY1NjR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU4LTIuMDI4My0yLjAyODMtMi4wMjgzaC0xMi41NTVjLTEuMTIzNyAwLTIuMDI4MyAwLjkwNDU4LTIuMDI4MyAyLjAyODN2MTEuMzM0aC00Ljg2ODR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU5LTIuMDI4My0yLjAyODMtMi4wMjgzem04Ljg0NjUgMjQuNDk5aDE2LjM0MmMxLjEyMzcgMCAyLjAyODMgMC45MDQ1OSAyLjAyODMgMi4wMjgzdjMuNTE0YzAgMS4xMjM3LTAuOTA0NTggMi4wMjgzLTIuMDI4MyAyLjAyODNoLTE2LjM0MmMtMS4xMjM3IDAtMi4wMjgzLTAuOTA0NTktMi4wMjgzLTIuMDI4M3YtMy41MTRjMC0xLjEyMzcgMC45MDQ1OS0yLjAyODMgMi4wMjgzLTIuMDI4M3ptLTE2LjU5MiAxOC4wNDloNDkuNTI2YzQuMDI5NyAwIDcuMjczNSAzLjI0MzggNy4yNzM1IDcuMjczNHYxMi42YzAgNC4wMjk2LTMuMjQzOCA3LjI3MzUtNy4yNzM1IDcuMjczNWgtNDkuNTI2Yy00LjAyOTcgMC03LjI3NC0zLjI0MzgtNy4yNzQtNy4yNzM1di0xMi42YzAtNC4wMjk2IDMuMjQ0My03LjI3MzQgNy4yNzQtNy4yNzM0em0tMi41NzA5IDY0LjIzN2E2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNTUtNi4xMzU1IDYuMTM1NCA2LjEzNTQgMCAwIDEgNi4xMzU1LTYuMTM1em01NC42NjcgMGE2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNS02LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMSA2LjEzNS02LjEzNXoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.94261" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTQ4LjUzbW0iIGhlaWdodD0iODkuNjY5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OC41MyA4OS42NjkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM3Ljc1OCAtMTE3LjU1KSI+PHBhdGggZD0ibTM3Ljc1OCAxODYuNTR2MjAuNjczaDE0OC41M3YtMjAuNjczaC0xNi45NDV2Ni43NDAyaC0zOC42MDV2LTYuNzQwMmgtMzcuNDI5djYuNzQwMmgtMzguNjA1di02Ljc0MDJ6Ii8+PHBhdGggZD0ibTU2LjUyNSAxMTcuNTUtMTcuODI0IDM3LjMwMXY3LjY4MjdsMC43MDI4IDAuNTI5MTcgMTUuMjk5IDExLjUxNmg1LjE3ZS00IDguNzI3NnY3LjM1M2gyNS40NTV2LTcuMzUzaDQ2LjI3MnY3LjM1M2gyNS40NTV2LTcuMzUzaDguNzI3NmwxNS4zLTExLjUxNiAwLjcwMjgtMC41MjkxN3YtNy42NzE5bC0xNS4wMjItMzcuMzExaC0xMTMuOHptMi42MTA3IDYuMjg3aDIxLjExN3YxOC4zMzloLTI4LjYxNGw3LjQ5NzItMTguMzM5em0yNi4yNzIgMGgyNC4wMzd2MTguMzM5aC0yNC4wMzd2LTE4LjMzOXptMjkuMTkzIDBoMjQuMDM3djE4LjMzOWgtMjQuMDM3di0xOC4zMzl6bTI5LjE5MyAwaDIxLjExN2w3LjQ5NjcgMTguMzM5aC0yOC42MTN2LTE4LjMzOXoiIHN0cm9rZS1taXRlcmxpbWl0PSIyLjEiIHN0cm9rZS13aWR0aD0iNC4xMTIxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzkuODdtbSIgaGVpZ2h0PSIxMjIuNjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNzkuODcgMTIyLjY4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wOCAtOTUuOTQ2KSI+PHBhdGggZD0ibTEwOS43OCAxMjEuMTd2NS4yZS00YTMxLjYgNi40NDU5IDAgMCAwLTEzLjU5NSAwLjYyOTQyaDAuMDAzNmExMC43MTYgMzAuMjcyIDY3LjgyOCAwIDAtMTEuNTkyIDQuNDUzIDEwLjcxNiAzMC4yNzIgNjcuODI4IDAgMC0xNC40OTcgOS4xODk2bC0xZS0zIDFlLTNhMTAuNzE2IDMwLjI3MiA2Ny44MjggMCAwLTAuMDIzMjUgMC4wMTkxdjcxLjU0OWg3LjMwNnYxMS42MTVoMTEuMjg3di0xMS42MTVoNDIuMTQ0djExLjYxNWgxMS4yODh2LTExLjYxNWg3LjMwNTV2LTM4LjkwN2gwLjA3OHYtMzIuNjRhMzkuNzA0IDE0LjU0NSAwIDAgMCAwLTUuMmUtNHYtNS4xZS00YTMwLjI3MiAxMC43MTYgMjIuMTcyIDAgMC0wLjAxNS0wLjAxMjkgMzAuMjcyIDEwLjcxNiAyMi4xNzIgMCAwLThlLTMgLTdlLTNsLTFlLTMgLTUuMmUtNGEzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTQuNDk4LTkuMTkwNiAzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTEuNTkyLTQuNDUzaDAuMDI4OWEzMS42IDYuNDQ1OSAwIDAgMC0xMy42Mi0wLjYyOTk0em0tMTcuMjQxIDkuMDExM2gzNC40ODNjMC40MjI1MSAwIDAuNzYyNzQgMC4zMzk3MSAwLjc2Mjc0IDAuNzYyMjN2My45MDMxYzAgMC40MjI1MS0wLjM0MDIzIDAuNzYyNzQtMC43NjI3NCAwLjc2Mjc0aC0zNC40ODNjLTAuNDIyNTEgMC0wLjc2Mjc0LTAuMzQwMjMtMC43NjI3NC0wLjc2Mjc0di0zLjkwMzFjMC0wLjQyMjUyIDAuMzQwMjMtMC43NjIyMyAwLjc2Mjc0LTAuNzYyMjN6bS0xMi4zNzEgMTAuODc3aDU5LjIyNWMxLjEyNTcgMCAyLjAzMTkgMC45MDY2OSAyLjAzMTkgMi4wMzI0djI0LjIwNmMwIDEuMTI1OC0wLjkwNjE4IDIuMDMxOS0yLjAzMTkgMi4wMzE5aC01OS4yMjVjLTEuMTI1NyAwLTIuMDMxOS0wLjkwNjE3LTIuMDMxOS0yLjAzMTl2LTI0LjIwNmMwLTEuMTI1OCAwLjkwNjE4LTIuMDMyNCAyLjAzMTktMi4wMzI0em0yLjg1NzcgNDMuNTY3YTQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzIDQuMjMxOCA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMyMyA0LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMS00LjIzMjMtNC4yMzIzIDQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzLTQuMjMxOHptNTMuNDMxIDBhNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMjMgNC4yMzE4IDQuMjMyMiA0LjIzMjIgMCAwIDEtNC4yMzIzIDQuMjMyMyA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMxOC00LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMTgtNC4yMzE4eiIvPjxwYXRoIGQ9Im05Ni43MTcgMTI1LjQzIDMwLjA0LTI4LjI4NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMi40Ii8+PHBhdGggZD0ibTExOC43MSAxMjUuNDMgMzAuMDQtMjguMjg0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIyLjQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.51563" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2OC44OW1tIiBoZWlnaHQ9IjE0OC40Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjguODkgMTQ4LjQyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMC42NjIgLTgwLjU3OCkiPjxwYXRoIGQ9Im0yNS41ODQgMTUxLjVjLTIuNzI3IDAtNC45MjIyIDIuMTk1Ny00LjkyMjIgNC45MjI3djY3LjY1MmMwIDIuNzI3IDIuMTk1MiA0LjkyMjcgNC45MjIyIDQuOTIyN2gxNTkuMDVjMi43MjcgMCA0LjkyMjItMi4xOTU3IDQuOTIyMi00LjkyMjd2LTY3LjY1MmMwLTIuNzI3LTIuMTk1Mi00LjkyMjctNC45MjIyLTQuOTIyN2gtMjQuODA4YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDU2OCA5LjkyNWgtMTA3LjU0YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDYyLTkuOTI1eiIvPjxjaXJjbGUgY3g9IjEwNS4xMSIgY3k9IjE0OS40NiIgcj0iNjAuODcyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMTYuMDI1Ii8+PGc+PHBhdGggZD0ibTc5Ljk5NiAxMTUuODhjLTIuOTkgMC01LjM5NzEgMi40MDcxLTUuMzk3MSA1LjM5NzF2MjkuODk1YzAgMi45OSAyLjQwNzEgNS4zOTcxIDUuMzk3MSA1LjM5NzFoNTAuMjIzYzIuOTkgMCA1LjM5NzEtMi40MDcxIDUuMzk3MS01LjM5NzF2LTI5Ljg5NWMwLTIuOTktMi40MDcxLTUuMzk3MS01LjM5NzEtNS4zOTcxem04LjA4NTMgNS45NDloMTAuNjY2YzAuOTYxNTUgMCAxLjczNTMgMC43NzQyNiAxLjczNTMgMS43MzU4djcuNjE5N2MwIDAuOTYxNTUtMC43NzM3NSAxLjczNTMtMS43MzUzIDEuNzM1M2gtMTAuNjY2Yy0wLjk2MTU1IDAtMS43MzUzLTAuNzczNzUtMS43MzUzLTEuNzM1M3YtNy42MTk3YzAtMC45NjE1NSAwLjc3Mzc1LTEuNzM1OCAxLjczNTMtMS43MzU4em0yMy4zODcgMGgxMC42NjZjMC45NjE1NSAwIDEuNzM1OCAwLjc3NDI2IDEuNzM1OCAxLjczNTh2Ny42MTk3YzAgMC45NjE1NS0wLjc3NDI2IDEuNzM1My0xLjczNTggMS43MzUzaC0xMC42NjZjLTAuOTYxNTUgMC0xLjczNTgtMC43NzM3NS0xLjczNTgtMS43MzUzdi03LjYxOTdjMC0wLjk2MTU1IDAuNzc0MjYtMS43MzU4IDEuNzM1OC0xLjczNTh6Ii8+PHJlY3QgeD0iODEuNzIxIiB5PSIxNTIuMzciIHdpZHRoPSIxMS4zODEiIGhlaWdodD0iMTQuMDMiIHJ5PSI1LjM5NzEiLz48cmVjdCB4PSIxMTcuMTEiIHk9IjE1Mi4zNyIgd2lkdGg9IjExLjM4MSIgaGVpZ2h0PSIxNC4wMyIgcnk9IjUuMzk3MSIvPjxwYXRoIGQ9Im0xMDUuMTEgMTAwLjkyYTMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA4IDIwLjM1NSAzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODMgMi4zOTI2aDkuNTc5OGMwLjU1MDAzLTIuMzk4NyAyLjY4OTktNC4xNzc1IDUuMjYwMS00LjE3NzVoOC4wMDI2YzIuNTcwMiAwIDQuNzA5NiAxLjc3ODkgNS4yNTk2IDQuMTc3NWg1LjAyNjZjMC4yOTYwNS0yLjcwNjIgMi41NzYtNC43OTg3IDUuMzYzNS00Ljc5ODdoOC4wMDMxYzIuNzg3NSAwIDUuMDY3NCAyLjA5MjUgNS4zNjM1IDQuNzk4N2g4LjcwN2EzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODItMi4zOTI2IDMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA5LTIwLjM1NXoiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTU5LjU2bW0iIGhlaWdodD0iMTEyLjI0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1OS41NiAxMTIuMjQiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Ljk4MSAtODEuNDk3KSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48Y2lyY2xlIGN4PSI1Mi43MDEiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48Y2lyY2xlIGN4PSI3My4yNTkiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48cGF0aCBkPSJtNDAuMzk1IDEyNC40LTE1LjQxNSAyMy44MDl2MzcuMTUxaDE0LjIzMWMtMC4xMTk4OC0wLjcyNjE5LTAuMTgzNDUtMS40NzE4LTAuMTgzNDUtMi4yMzI5IDAtNy40ODIyIDYuMDI0LTEzLjUwNiAxMy41MDYtMTMuNTA2aDEwNC40NWM3LjQ4MjIgMCAxMy41MDYgNi4wMjQgMTMuNTA2IDEzLjUwNiAwIDAuNzYxMTktMC4wNjM2IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgxNC4yM3YtMzkuNTk1bC0xNC4zNzEtMjEuMzY2em0wLjkwMDcyIDUuNzc5YzEuOTUwOSAxZS0zIDYuMjkyMSAwIDYuMjkyMSAwIDEuNjUxOSAwIDIuOTgyMiAxLjMyOTggMi45ODIyIDIuOTgxN3YxMi41NmMwIDEuNjUxOS0xLjMzMDMgMi45ODE3LTIuOTgyMiAyLjk4MTdoLTEyLjY5NWMtMS42NTE5IDAtMi44NzIzLTIuNDU3NS0yLjA0NjQtMy44ODgxbDMuODA0OS02LjU5MDN6bTE4LjM1NSAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzIgMGgyNC42N2MxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yNC42N2MtMS42NTE5IDAtMi45ODE3LTEuMzI5OC0yLjk4MTctMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMyOTgtMi45ODE3IDIuOTgxNy0yLjk4MTd6bTM2LjczMyAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzMgMHM0LjM0MTMgMWUtMyA2LjI5MjEgMGw4LjQ0OTYgMTQuNjM1YzAuODI1OTYgMS40MzA2LTAuMzk0NDYgMy44ODgxLTIuMDQ2NCAzLjg4ODFoLTEyLjY5NWMtMS42NTE5IDAtMi45ODIyLTEuMzI5OC0yLjk4MjItMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMzMDMtMi45ODE3IDIuOTgyMi0yLjk4MTd6bS04MC44OTggNDIuMTAzYzMuMzAzOCAyLjQ1NzYgNS40MzY5IDYuMzkzMiA1LjQzNjkgMTAuODQ1IDAgMC43NjExOS0wLjA2MzU4IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgzNi45NDhjLTAuMTE5ODctMC43MjYxOS0wLjE4MzQ1LTEuNDcxOC0wLjE4MzQ1LTIuMjMyOSAwLTQuNDUyMSAyLjEzMzItOC4zODc3IDUuNDM2OS0xMC44NDV6IiBzdHJva2Utd2lkdGg9IjE0LjU4MiIvPjxjaXJjbGUgY3g9IjEzNi4yNiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjxjaXJjbGUgY3g9IjE1Ni44MiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjwvZz48cGF0aCBkPSJtOTAuNzQyIDExNi43OS0xMC43ODYtMTEuMTYgMjQuNjM4LTEzLjcxIDI1LjEwNiAxMy43MS05LjUxMDQgMTEuMTZjLTI3Ljc5NCAwLTYuNjg2My0xZS01IC0yOS40NDctMWUtNXoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLXdpZHRoPSI0LjI2Ii8+PHJlY3QgeD0iMTAyLjYzIiB5PSI4MS40OTciIHdpZHRoPSI0LjI2IiBoZWlnaHQ9IjExLjk2NCIgcnk9IjAiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzkuODdtbSIgaGVpZ2h0PSIxMjIuNjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNzkuODcgMTIyLjY4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wOCAtOTUuOTQ2KSI+PHBhdGggZD0ibTEwOS43OCAxMjEuMTd2NS4yZS00YTMxLjYgNi40NDU5IDAgMCAwLTEzLjU5NSAwLjYyOTQyaDAuMDAzNmExMC43MTYgMzAuMjcyIDY3LjgyOCAwIDAtMTEuNTkyIDQuNDUzIDEwLjcxNiAzMC4yNzIgNjcuODI4IDAgMC0xNC40OTcgOS4xODk2bC0xZS0zIDFlLTNhMTAuNzE2IDMwLjI3MiA2Ny44MjggMCAwLTAuMDIzMjUgMC4wMTkxdjcxLjU0OWg3LjMwNnYxMS42MTVoMTEuMjg3di0xMS42MTVoNDIuMTQ0djExLjYxNWgxMS4yODh2LTExLjYxNWg3LjMwNTV2LTM4LjkwN2gwLjA3OHYtMzIuNjRhMzkuNzA0IDE0LjU0NSAwIDAgMCAwLTUuMmUtNHYtNS4xZS00YTMwLjI3MiAxMC43MTYgMjIuMTcyIDAgMC0wLjAxNS0wLjAxMjkgMzAuMjcyIDEwLjcxNiAyMi4xNzIgMCAwLThlLTMgLTdlLTNsLTFlLTMgLTUuMmUtNGEzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTQuNDk4LTkuMTkwNiAzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTEuNTkyLTQuNDUzaDAuMDI4OWEzMS42IDYuNDQ1OSAwIDAgMC0xMy42Mi0wLjYyOTk0em0tMTcuMjQxIDkuMDExM2gzNC40ODNjMC40MjI1MSAwIDAuNzYyNzQgMC4zMzk3MSAwLjc2Mjc0IDAuNzYyMjN2My45MDMxYzAgMC40MjI1MS0wLjM0MDIzIDAuNzYyNzQtMC43NjI3NCAwLjc2Mjc0aC0zNC40ODNjLTAuNDIyNTEgMC0wLjc2Mjc0LTAuMzQwMjMtMC43NjI3NC0wLjc2Mjc0di0zLjkwMzFjMC0wLjQyMjUyIDAuMzQwMjMtMC43NjIyMyAwLjc2Mjc0LTAuNzYyMjN6bS0xMi4zNzEgMTAuODc3aDU5LjIyNWMxLjEyNTcgMCAyLjAzMTkgMC45MDY2OSAyLjAzMTkgMi4wMzI0djI0LjIwNmMwIDEuMTI1OC0wLjkwNjE4IDIuMDMxOS0yLjAzMTkgMi4wMzE5aC01OS4yMjVjLTEuMTI1NyAwLTIuMDMxOS0wLjkwNjE3LTIuMDMxOS0yLjAzMTl2LTI0LjIwNmMwLTEuMTI1OCAwLjkwNjE4LTIuMDMyNCAyLjAzMTktMi4wMzI0em0yLjg1NzcgNDMuNTY3YTQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzIDQuMjMxOCA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMyMyA0LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMS00LjIzMjMtNC4yMzIzIDQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzLTQuMjMxOHptNTMuNDMxIDBhNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMjMgNC4yMzE4IDQuMjMyMiA0LjIzMjIgMCAwIDEtNC4yMzIzIDQuMjMyMyA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMxOC00LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMTgtNC4yMzE4eiIvPjxwYXRoIGQ9Im05Ni43MTcgMTI1LjQzIDMwLjA0LTI4LjI4NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMi40Ii8+PHBhdGggZD0ibTExOC43MSAxMjUuNDMgMzAuMDQtMjguMjg0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIyLjQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.51563" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE1LjQzbW0iIGhlaWdodD0iMTY5LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNS40MyAxNjkuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ2LjE5NCAtNjIuOTE1KSI+PHBhdGggZD0ibTg2Ljg5IDYyLjkxNWMtMS4xMjM3IDAtMi4wMjgzIDAuOTA0NTgtMi4wMjgzIDIuMDI4M3YxMS4zMzRoLTYuNjU3Yy0xMy42NjkgMC0yNC42NzMgMTEuMDA1LTI0LjY3MyAyNC42NzN2NzEuNTY2YzAgMTAuODExIDYuODg2OSAxOS45NSAxNi41MjkgMjMuMzAxaC0yLjU2ODhsLTIxLjI5OCAyNC4zMjF2MTIuNTg5aDE0LjgxN2wxOS40ODUtMjQuMzc3aDQ2LjgyNWwxOS40ODUgMjQuMzc3aDE0LjgxNnYtMTIuNTg5bC0yMS4yOTctMjQuMzJoLTIuNTY5NGM5LjY0Mi0zLjM1MDkgMTYuNTI5LTEyLjQ4OSAxNi41MjktMjMuMzAxdi03MS41NjZjMC0xMy42NjktMTEuMDA1LTI0LjY3My0yNC42NzMtMjQuNjczaC02LjY1NjR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU4LTIuMDI4My0yLjAyODMtMi4wMjgzaC0xMi41NTVjLTEuMTIzNyAwLTIuMDI4MyAwLjkwNDU4LTIuMDI4MyAyLjAyODN2MTEuMzM0aC00Ljg2ODR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU5LTIuMDI4My0yLjAyODMtMi4wMjgzem04Ljg0NjUgMjQuNDk5aDE2LjM0MmMxLjEyMzcgMCAyLjAyODMgMC45MDQ1OSAyLjAyODMgMi4wMjgzdjMuNTE0YzAgMS4xMjM3LTAuOTA0NTggMi4wMjgzLTIuMDI4MyAyLjAyODNoLTE2LjM0MmMtMS4xMjM3IDAtMi4wMjgzLTAuOTA0NTktMi4wMjgzLTIuMDI4M3YtMy41MTRjMC0xLjEyMzcgMC45MDQ1OS0yLjAyODMgMi4wMjgzLTIuMDI4M3ptLTE2LjU5MiAxOC4wNDloNDkuNTI2YzQuMDI5NyAwIDcuMjczNSAzLjI0MzggNy4yNzM1IDcuMjczNHYxMi42YzAgNC4wMjk2LTMuMjQzOCA3LjI3MzUtNy4yNzM1IDcuMjczNWgtNDkuNTI2Yy00LjAyOTcgMC03LjI3NC0zLjI0MzgtNy4yNzQtNy4yNzM1di0xMi42YzAtNC4wMjk2IDMuMjQ0My03LjI3MzQgNy4yNzQtNy4yNzM0em0tMi41NzA5IDY0LjIzN2E2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNTUtNi4xMzU1IDYuMTM1NCA2LjEzNTQgMCAwIDEgNi4xMzU1LTYuMTM1em01NC42NjcgMGE2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNS02LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMSA2LjEzNS02LjEzNXoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.94261" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTQ4LjUzbW0iIGhlaWdodD0iODkuNjY5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OC41MyA4OS42NjkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM3Ljc1OCAtMTE3LjU1KSI+PHBhdGggZD0ibTM3Ljc1OCAxODYuNTR2MjAuNjczaDE0OC41M3YtMjAuNjczaC0xNi45NDV2Ni43NDAyaC0zOC42MDV2LTYuNzQwMmgtMzcuNDI5djYuNzQwMmgtMzguNjA1di02Ljc0MDJ6Ii8+PHBhdGggZD0ibTU2LjUyNSAxMTcuNTUtMTcuODI0IDM3LjMwMXY3LjY4MjdsMC43MDI4IDAuNTI5MTcgMTUuMjk5IDExLjUxNmg1LjE3ZS00IDguNzI3NnY3LjM1M2gyNS40NTV2LTcuMzUzaDQ2LjI3MnY3LjM1M2gyNS40NTV2LTcuMzUzaDguNzI3NmwxNS4zLTExLjUxNiAwLjcwMjgtMC41MjkxN3YtNy42NzE5bC0xNS4wMjItMzcuMzExaC0xMTMuOHptMi42MTA3IDYuMjg3aDIxLjExN3YxOC4zMzloLTI4LjYxNGw3LjQ5NzItMTguMzM5em0yNi4yNzIgMGgyNC4wMzd2MTguMzM5aC0yNC4wMzd2LTE4LjMzOXptMjkuMTkzIDBoMjQuMDM3djE4LjMzOWgtMjQuMDM3di0xOC4zMzl6bTI5LjE5MyAwaDIxLjExN2w3LjQ5NjcgMTguMzM5aC0yOC42MTN2LTE4LjMzOXoiIHN0cm9rZS1taXRlcmxpbWl0PSIyLjEiIHN0cm9rZS13aWR0aD0iNC4xMTIxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="36" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="37" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2OC44OW1tIiBoZWlnaHQ9IjE0OC40Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjguODkgMTQ4LjQyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMC42NjIgLTgwLjU3OCkiPjxwYXRoIGQ9Im0yNS41ODQgMTUxLjVjLTIuNzI3IDAtNC45MjIyIDIuMTk1Ny00LjkyMjIgNC45MjI3djY3LjY1MmMwIDIuNzI3IDIuMTk1MiA0LjkyMjcgNC45MjIyIDQuOTIyN2gxNTkuMDVjMi43MjcgMCA0LjkyMjItMi4xOTU3IDQuOTIyMi00LjkyMjd2LTY3LjY1MmMwLTIuNzI3LTIuMTk1Mi00LjkyMjctNC45MjIyLTQuOTIyN2gtMjQuODA4YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDU2OCA5LjkyNWgtMTA3LjU0YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDYyLTkuOTI1eiIvPjxjaXJjbGUgY3g9IjEwNS4xMSIgY3k9IjE0OS40NiIgcj0iNjAuODcyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMTYuMDI1Ii8+PGc+PHBhdGggZD0ibTc5Ljk5NiAxMTUuODhjLTIuOTkgMC01LjM5NzEgMi40MDcxLTUuMzk3MSA1LjM5NzF2MjkuODk1YzAgMi45OSAyLjQwNzEgNS4zOTcxIDUuMzk3MSA1LjM5NzFoNTAuMjIzYzIuOTkgMCA1LjM5NzEtMi40MDcxIDUuMzk3MS01LjM5NzF2LTI5Ljg5NWMwLTIuOTktMi40MDcxLTUuMzk3MS01LjM5NzEtNS4zOTcxem04LjA4NTMgNS45NDloMTAuNjY2YzAuOTYxNTUgMCAxLjczNTMgMC43NzQyNiAxLjczNTMgMS43MzU4djcuNjE5N2MwIDAuOTYxNTUtMC43NzM3NSAxLjczNTMtMS43MzUzIDEuNzM1M2gtMTAuNjY2Yy0wLjk2MTU1IDAtMS43MzUzLTAuNzczNzUtMS43MzUzLTEuNzM1M3YtNy42MTk3YzAtMC45NjE1NSAwLjc3Mzc1LTEuNzM1OCAxLjczNTMtMS43MzU4em0yMy4zODcgMGgxMC42NjZjMC45NjE1NSAwIDEuNzM1OCAwLjc3NDI2IDEuNzM1OCAxLjczNTh2Ny42MTk3YzAgMC45NjE1NS0wLjc3NDI2IDEuNzM1My0xLjczNTggMS43MzUzaC0xMC42NjZjLTAuOTYxNTUgMC0xLjczNTgtMC43NzM3NS0xLjczNTgtMS43MzUzdi03LjYxOTdjMC0wLjk2MTU1IDAuNzc0MjYtMS43MzU4IDEuNzM1OC0xLjczNTh6Ii8+PHJlY3QgeD0iODEuNzIxIiB5PSIxNTIuMzciIHdpZHRoPSIxMS4zODEiIGhlaWdodD0iMTQuMDMiIHJ5PSI1LjM5NzEiLz48cmVjdCB4PSIxMTcuMTEiIHk9IjE1Mi4zNyIgd2lkdGg9IjExLjM4MSIgaGVpZ2h0PSIxNC4wMyIgcnk9IjUuMzk3MSIvPjxwYXRoIGQ9Im0xMDUuMTEgMTAwLjkyYTMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA4IDIwLjM1NSAzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODMgMi4zOTI2aDkuNTc5OGMwLjU1MDAzLTIuMzk4NyAyLjY4OTktNC4xNzc1IDUuMjYwMS00LjE3NzVoOC4wMDI2YzIuNTcwMiAwIDQuNzA5NiAxLjc3ODkgNS4yNTk2IDQuMTc3NWg1LjAyNjZjMC4yOTYwNS0yLjcwNjIgMi41NzYtNC43OTg3IDUuMzYzNS00Ljc5ODdoOC4wMDMxYzIuNzg3NSAwIDUuMDY3NCAyLjA5MjUgNS4zNjM1IDQuNzk4N2g4LjcwN2EzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODItMi4zOTI2IDMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA5LTIwLjM1NXoiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="38" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTU5LjU2bW0iIGhlaWdodD0iMTEyLjI0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1OS41NiAxMTIuMjQiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Ljk4MSAtODEuNDk3KSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48Y2lyY2xlIGN4PSI1Mi43MDEiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48Y2lyY2xlIGN4PSI3My4yNTkiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48cGF0aCBkPSJtNDAuMzk1IDEyNC40LTE1LjQxNSAyMy44MDl2MzcuMTUxaDE0LjIzMWMtMC4xMTk4OC0wLjcyNjE5LTAuMTgzNDUtMS40NzE4LTAuMTgzNDUtMi4yMzI5IDAtNy40ODIyIDYuMDI0LTEzLjUwNiAxMy41MDYtMTMuNTA2aDEwNC40NWM3LjQ4MjIgMCAxMy41MDYgNi4wMjQgMTMuNTA2IDEzLjUwNiAwIDAuNzYxMTktMC4wNjM2IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgxNC4yM3YtMzkuNTk1bC0xNC4zNzEtMjEuMzY2em0wLjkwMDcyIDUuNzc5YzEuOTUwOSAxZS0zIDYuMjkyMSAwIDYuMjkyMSAwIDEuNjUxOSAwIDIuOTgyMiAxLjMyOTggMi45ODIyIDIuOTgxN3YxMi41NmMwIDEuNjUxOS0xLjMzMDMgMi45ODE3LTIuOTgyMiAyLjk4MTdoLTEyLjY5NWMtMS42NTE5IDAtMi44NzIzLTIuNDU3NS0yLjA0NjQtMy44ODgxbDMuODA0OS02LjU5MDN6bTE4LjM1NSAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzIgMGgyNC42N2MxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yNC42N2MtMS42NTE5IDAtMi45ODE3LTEuMzI5OC0yLjk4MTctMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMyOTgtMi45ODE3IDIuOTgxNy0yLjk4MTd6bTM2LjczMyAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzMgMHM0LjM0MTMgMWUtMyA2LjI5MjEgMGw4LjQ0OTYgMTQuNjM1YzAuODI1OTYgMS40MzA2LTAuMzk0NDYgMy44ODgxLTIuMDQ2NCAzLjg4ODFoLTEyLjY5NWMtMS42NTE5IDAtMi45ODIyLTEuMzI5OC0yLjk4MjItMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMzMDMtMi45ODE3IDIuOTgyMi0yLjk4MTd6bS04MC44OTggNDIuMTAzYzMuMzAzOCAyLjQ1NzYgNS40MzY5IDYuMzkzMiA1LjQzNjkgMTAuODQ1IDAgMC43NjExOS0wLjA2MzU4IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgzNi45NDhjLTAuMTE5ODctMC43MjYxOS0wLjE4MzQ1LTEuNDcxOC0wLjE4MzQ1LTIuMjMyOSAwLTQuNDUyMSAyLjEzMzItOC4zODc3IDUuNDM2OS0xMC44NDV6IiBzdHJva2Utd2lkdGg9IjE0LjU4MiIvPjxjaXJjbGUgY3g9IjEzNi4yNiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjxjaXJjbGUgY3g9IjE1Ni44MiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjwvZz48cGF0aCBkPSJtOTAuNzQyIDExNi43OS0xMC43ODYtMTEuMTYgMjQuNjM4LTEzLjcxIDI1LjEwNiAxMy43MS05LjUxMDQgMTEuMTZjLTI3Ljc5NCAwLTYuNjg2My0xZS01IC0yOS40NDctMWUtNXoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLXdpZHRoPSI0LjI2Ii8+PHJlY3QgeD0iMTAyLjYzIiB5PSI4MS40OTciIHdpZHRoPSI0LjI2IiBoZWlnaHQ9IjExLjk2NCIgcnk9IjAiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="39" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzkuODdtbSIgaGVpZ2h0PSIxMjIuNjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNzkuODcgMTIyLjY4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wOCAtOTUuOTQ2KSI+PHBhdGggZD0ibTEwOS43OCAxMjEuMTd2NS4yZS00YTMxLjYgNi40NDU5IDAgMCAwLTEzLjU5NSAwLjYyOTQyaDAuMDAzNmExMC43MTYgMzAuMjcyIDY3LjgyOCAwIDAtMTEuNTkyIDQuNDUzIDEwLjcxNiAzMC4yNzIgNjcuODI4IDAgMC0xNC40OTcgOS4xODk2bC0xZS0zIDFlLTNhMTAuNzE2IDMwLjI3MiA2Ny44MjggMCAwLTAuMDIzMjUgMC4wMTkxdjcxLjU0OWg3LjMwNnYxMS42MTVoMTEuMjg3di0xMS42MTVoNDIuMTQ0djExLjYxNWgxMS4yODh2LTExLjYxNWg3LjMwNTV2LTM4LjkwN2gwLjA3OHYtMzIuNjRhMzkuNzA0IDE0LjU0NSAwIDAgMCAwLTUuMmUtNHYtNS4xZS00YTMwLjI3MiAxMC43MTYgMjIuMTcyIDAgMC0wLjAxNS0wLjAxMjkgMzAuMjcyIDEwLjcxNiAyMi4xNzIgMCAwLThlLTMgLTdlLTNsLTFlLTMgLTUuMmUtNGEzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTQuNDk4LTkuMTkwNiAzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTEuNTkyLTQuNDUzaDAuMDI4OWEzMS42IDYuNDQ1OSAwIDAgMC0xMy42Mi0wLjYyOTk0em0tMTcuMjQxIDkuMDExM2gzNC40ODNjMC40MjI1MSAwIDAuNzYyNzQgMC4zMzk3MSAwLjc2Mjc0IDAuNzYyMjN2My45MDMxYzAgMC40MjI1MS0wLjM0MDIzIDAuNzYyNzQtMC43NjI3NCAwLjc2Mjc0aC0zNC40ODNjLTAuNDIyNTEgMC0wLjc2Mjc0LTAuMzQwMjMtMC43NjI3NC0wLjc2Mjc0di0zLjkwMzFjMC0wLjQyMjUyIDAuMzQwMjMtMC43NjIyMyAwLjc2Mjc0LTAuNzYyMjN6bS0xMi4zNzEgMTAuODc3aDU5LjIyNWMxLjEyNTcgMCAyLjAzMTkgMC45MDY2OSAyLjAzMTkgMi4wMzI0djI0LjIwNmMwIDEuMTI1OC0wLjkwNjE4IDIuMDMxOS0yLjAzMTkgMi4wMzE5aC01OS4yMjVjLTEuMTI1NyAwLTIuMDMxOS0wLjkwNjE3LTIuMDMxOS0yLjAzMTl2LTI0LjIwNmMwLTEuMTI1OCAwLjkwNjE4LTIuMDMyNCAyLjAzMTktMi4wMzI0em0yLjg1NzcgNDMuNTY3YTQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzIDQuMjMxOCA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMyMyA0LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMS00LjIzMjMtNC4yMzIzIDQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzLTQuMjMxOHptNTMuNDMxIDBhNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMjMgNC4yMzE4IDQuMjMyMiA0LjIzMjIgMCAwIDEtNC4yMzIzIDQuMjMyMyA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMxOC00LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMTgtNC4yMzE4eiIvPjxwYXRoIGQ9Im05Ni43MTcgMTI1LjQzIDMwLjA0LTI4LjI4NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMi40Ii8+PHBhdGggZD0ibTExOC43MSAxMjUuNDMgMzAuMDQtMjguMjg0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIyLjQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.51563" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE1LjQzbW0iIGhlaWdodD0iMTY5LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNS40MyAxNjkuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ2LjE5NCAtNjIuOTE1KSI+PHBhdGggZD0ibTg2Ljg5IDYyLjkxNWMtMS4xMjM3IDAtMi4wMjgzIDAuOTA0NTgtMi4wMjgzIDIuMDI4M3YxMS4zMzRoLTYuNjU3Yy0xMy42NjkgMC0yNC42NzMgMTEuMDA1LTI0LjY3MyAyNC42NzN2NzEuNTY2YzAgMTAuODExIDYuODg2OSAxOS45NSAxNi41MjkgMjMuMzAxaC0yLjU2ODhsLTIxLjI5OCAyNC4zMjF2MTIuNTg5aDE0LjgxN2wxOS40ODUtMjQuMzc3aDQ2LjgyNWwxOS40ODUgMjQuMzc3aDE0LjgxNnYtMTIuNTg5bC0yMS4yOTctMjQuMzJoLTIuNTY5NGM5LjY0Mi0zLjM1MDkgMTYuNTI5LTEyLjQ4OSAxNi41MjktMjMuMzAxdi03MS41NjZjMC0xMy42NjktMTEuMDA1LTI0LjY3My0yNC42NzMtMjQuNjczaC02LjY1NjR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU4LTIuMDI4My0yLjAyODMtMi4wMjgzaC0xMi41NTVjLTEuMTIzNyAwLTIuMDI4MyAwLjkwNDU4LTIuMDI4MyAyLjAyODN2MTEuMzM0aC00Ljg2ODR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU5LTIuMDI4My0yLjAyODMtMi4wMjgzem04Ljg0NjUgMjQuNDk5aDE2LjM0MmMxLjEyMzcgMCAyLjAyODMgMC45MDQ1OSAyLjAyODMgMi4wMjgzdjMuNTE0YzAgMS4xMjM3LTAuOTA0NTggMi4wMjgzLTIuMDI4MyAyLjAyODNoLTE2LjM0MmMtMS4xMjM3IDAtMi4wMjgzLTAuOTA0NTktMi4wMjgzLTIuMDI4M3YtMy41MTRjMC0xLjEyMzcgMC45MDQ1OS0yLjAyODMgMi4wMjgzLTIuMDI4M3ptLTE2LjU5MiAxOC4wNDloNDkuNTI2YzQuMDI5NyAwIDcuMjczNSAzLjI0MzggNy4yNzM1IDcuMjczNHYxMi42YzAgNC4wMjk2LTMuMjQzOCA3LjI3MzUtNy4yNzM1IDcuMjczNWgtNDkuNTI2Yy00LjAyOTcgMC03LjI3NC0zLjI0MzgtNy4yNzQtNy4yNzM1di0xMi42YzAtNC4wMjk2IDMuMjQ0My03LjI3MzQgNy4yNzQtNy4yNzM0em0tMi41NzA5IDY0LjIzN2E2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNTUtNi4xMzU1IDYuMTM1NCA2LjEzNTQgMCAwIDEgNi4xMzU1LTYuMTM1em01NC42NjcgMGE2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNS02LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMSA2LjEzNS02LjEzNXoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.94261" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="40" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE1LjQzbW0iIGhlaWdodD0iMTY5LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNS40MyAxNjkuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ2LjE5NCAtNjIuOTE1KSI+PHBhdGggZD0ibTg2Ljg5IDYyLjkxNWMtMS4xMjM3IDAtMi4wMjgzIDAuOTA0NTgtMi4wMjgzIDIuMDI4M3YxMS4zMzRoLTYuNjU3Yy0xMy42NjkgMC0yNC42NzMgMTEuMDA1LTI0LjY3MyAyNC42NzN2NzEuNTY2YzAgMTAuODExIDYuODg2OSAxOS45NSAxNi41MjkgMjMuMzAxaC0yLjU2ODhsLTIxLjI5OCAyNC4zMjF2MTIuNTg5aDE0LjgxN2wxOS40ODUtMjQuMzc3aDQ2LjgyNWwxOS40ODUgMjQuMzc3aDE0LjgxNnYtMTIuNTg5bC0yMS4yOTctMjQuMzJoLTIuNTY5NGM5LjY0Mi0zLjM1MDkgMTYuNTI5LTEyLjQ4OSAxNi41MjktMjMuMzAxdi03MS41NjZjMC0xMy42NjktMTEuMDA1LTI0LjY3My0yNC42NzMtMjQuNjczaC02LjY1NjR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU4LTIuMDI4My0yLjAyODMtMi4wMjgzaC0xMi41NTVjLTEuMTIzNyAwLTIuMDI4MyAwLjkwNDU4LTIuMDI4MyAyLjAyODN2MTEuMzM0aC00Ljg2ODR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU5LTIuMDI4My0yLjAyODMtMi4wMjgzem04Ljg0NjUgMjQuNDk5aDE2LjM0MmMxLjEyMzcgMCAyLjAyODMgMC45MDQ1OSAyLjAyODMgMi4wMjgzdjMuNTE0YzAgMS4xMjM3LTAuOTA0NTggMi4wMjgzLTIuMDI4MyAyLjAyODNoLTE2LjM0MmMtMS4xMjM3IDAtMi4wMjgzLTAuOTA0NTktMi4wMjgzLTIuMDI4M3YtMy41MTRjMC0xLjEyMzcgMC45MDQ1OS0yLjAyODMgMi4wMjgzLTIuMDI4M3ptLTE2LjU5MiAxOC4wNDloNDkuNTI2YzQuMDI5NyAwIDcuMjczNSAzLjI0MzggNy4yNzM1IDcuMjczNHYxMi42YzAgNC4wMjk2LTMuMjQzOCA3LjI3MzUtNy4yNzM1IDcuMjczNWgtNDkuNTI2Yy00LjAyOTcgMC03LjI3NC0zLjI0MzgtNy4yNzQtNy4yNzM1di0xMi42YzAtNC4wMjk2IDMuMjQ0My03LjI3MzQgNy4yNzQtNy4yNzM0em0tMi41NzA5IDY0LjIzN2E2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNTUtNi4xMzU1IDYuMTM1NCA2LjEzNTQgMCAwIDEgNi4xMzU1LTYuMTM1em01NC42NjcgMGE2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNS02LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMSA2LjEzNS02LjEzNXoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.94261" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="41" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTQ4LjUzbW0iIGhlaWdodD0iODkuNjY5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OC41MyA4OS42NjkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM3Ljc1OCAtMTE3LjU1KSI+PHBhdGggZD0ibTM3Ljc1OCAxODYuNTR2MjAuNjczaDE0OC41M3YtMjAuNjczaC0xNi45NDV2Ni43NDAyaC0zOC42MDV2LTYuNzQwMmgtMzcuNDI5djYuNzQwMmgtMzguNjA1di02Ljc0MDJ6Ii8+PHBhdGggZD0ibTU2LjUyNSAxMTcuNTUtMTcuODI0IDM3LjMwMXY3LjY4MjdsMC43MDI4IDAuNTI5MTcgMTUuMjk5IDExLjUxNmg1LjE3ZS00IDguNzI3NnY3LjM1M2gyNS40NTV2LTcuMzUzaDQ2LjI3MnY3LjM1M2gyNS40NTV2LTcuMzUzaDguNzI3NmwxNS4zLTExLjUxNiAwLjcwMjgtMC41MjkxN3YtNy42NzE5bC0xNS4wMjItMzcuMzExaC0xMTMuOHptMi42MTA3IDYuMjg3aDIxLjExN3YxOC4zMzloLTI4LjYxNGw3LjQ5NzItMTguMzM5em0yNi4yNzIgMGgyNC4wMzd2MTguMzM5aC0yNC4wMzd2LTE4LjMzOXptMjkuMTkzIDBoMjQuMDM3djE4LjMzOWgtMjQuMDM3di0xOC4zMzl6bTI5LjE5MyAwaDIxLjExN2w3LjQ5NjcgMTguMzM5aC0yOC42MTN2LTE4LjMzOXoiIHN0cm9rZS1taXRlcmxpbWl0PSIyLjEiIHN0cm9rZS13aWR0aD0iNC4xMTIxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="42" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="43" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2OC44OW1tIiBoZWlnaHQ9IjE0OC40Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjguODkgMTQ4LjQyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMC42NjIgLTgwLjU3OCkiPjxwYXRoIGQ9Im0yNS41ODQgMTUxLjVjLTIuNzI3IDAtNC45MjIyIDIuMTk1Ny00LjkyMjIgNC45MjI3djY3LjY1MmMwIDIuNzI3IDIuMTk1MiA0LjkyMjcgNC45MjIyIDQuOTIyN2gxNTkuMDVjMi43MjcgMCA0LjkyMjItMi4xOTU3IDQuOTIyMi00LjkyMjd2LTY3LjY1MmMwLTIuNzI3LTIuMTk1Mi00LjkyMjctNC45MjIyLTQuOTIyN2gtMjQuODA4YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDU2OCA5LjkyNWgtMTA3LjU0YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDYyLTkuOTI1eiIvPjxjaXJjbGUgY3g9IjEwNS4xMSIgY3k9IjE0OS40NiIgcj0iNjAuODcyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMTYuMDI1Ii8+PGc+PHBhdGggZD0ibTc5Ljk5NiAxMTUuODhjLTIuOTkgMC01LjM5NzEgMi40MDcxLTUuMzk3MSA1LjM5NzF2MjkuODk1YzAgMi45OSAyLjQwNzEgNS4zOTcxIDUuMzk3MSA1LjM5NzFoNTAuMjIzYzIuOTkgMCA1LjM5NzEtMi40MDcxIDUuMzk3MS01LjM5NzF2LTI5Ljg5NWMwLTIuOTktMi40MDcxLTUuMzk3MS01LjM5NzEtNS4zOTcxem04LjA4NTMgNS45NDloMTAuNjY2YzAuOTYxNTUgMCAxLjczNTMgMC43NzQyNiAxLjczNTMgMS43MzU4djcuNjE5N2MwIDAuOTYxNTUtMC43NzM3NSAxLjczNTMtMS43MzUzIDEuNzM1M2gtMTAuNjY2Yy0wLjk2MTU1IDAtMS43MzUzLTAuNzczNzUtMS43MzUzLTEuNzM1M3YtNy42MTk3YzAtMC45NjE1NSAwLjc3Mzc1LTEuNzM1OCAxLjczNTMtMS43MzU4em0yMy4zODcgMGgxMC42NjZjMC45NjE1NSAwIDEuNzM1OCAwLjc3NDI2IDEuNzM1OCAxLjczNTh2Ny42MTk3YzAgMC45NjE1NS0wLjc3NDI2IDEuNzM1My0xLjczNTggMS43MzUzaC0xMC42NjZjLTAuOTYxNTUgMC0xLjczNTgtMC43NzM3NS0xLjczNTgtMS43MzUzdi03LjYxOTdjMC0wLjk2MTU1IDAuNzc0MjYtMS43MzU4IDEuNzM1OC0xLjczNTh6Ii8+PHJlY3QgeD0iODEuNzIxIiB5PSIxNTIuMzciIHdpZHRoPSIxMS4zODEiIGhlaWdodD0iMTQuMDMiIHJ5PSI1LjM5NzEiLz48cmVjdCB4PSIxMTcuMTEiIHk9IjE1Mi4zNyIgd2lkdGg9IjExLjM4MSIgaGVpZ2h0PSIxNC4wMyIgcnk9IjUuMzk3MSIvPjxwYXRoIGQ9Im0xMDUuMTEgMTAwLjkyYTMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA4IDIwLjM1NSAzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODMgMi4zOTI2aDkuNTc5OGMwLjU1MDAzLTIuMzk4NyAyLjY4OTktNC4xNzc1IDUuMjYwMS00LjE3NzVoOC4wMDI2YzIuNTcwMiAwIDQuNzA5NiAxLjc3ODkgNS4yNTk2IDQuMTc3NWg1LjAyNjZjMC4yOTYwNS0yLjcwNjIgMi41NzYtNC43OTg3IDUuMzYzNS00Ljc5ODdoOC4wMDMxYzIuNzg3NSAwIDUuMDY3NCAyLjA5MjUgNS4zNjM1IDQuNzk4N2g4LjcwN2EzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODItMi4zOTI2IDMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA5LTIwLjM1NXoiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="44" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTU5LjU2bW0iIGhlaWdodD0iMTEyLjI0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1OS41NiAxMTIuMjQiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Ljk4MSAtODEuNDk3KSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48Y2lyY2xlIGN4PSI1Mi43MDEiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48Y2lyY2xlIGN4PSI3My4yNTkiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48cGF0aCBkPSJtNDAuMzk1IDEyNC40LTE1LjQxNSAyMy44MDl2MzcuMTUxaDE0LjIzMWMtMC4xMTk4OC0wLjcyNjE5LTAuMTgzNDUtMS40NzE4LTAuMTgzNDUtMi4yMzI5IDAtNy40ODIyIDYuMDI0LTEzLjUwNiAxMy41MDYtMTMuNTA2aDEwNC40NWM3LjQ4MjIgMCAxMy41MDYgNi4wMjQgMTMuNTA2IDEzLjUwNiAwIDAuNzYxMTktMC4wNjM2IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgxNC4yM3YtMzkuNTk1bC0xNC4zNzEtMjEuMzY2em0wLjkwMDcyIDUuNzc5YzEuOTUwOSAxZS0zIDYuMjkyMSAwIDYuMjkyMSAwIDEuNjUxOSAwIDIuOTgyMiAxLjMyOTggMi45ODIyIDIuOTgxN3YxMi41NmMwIDEuNjUxOS0xLjMzMDMgMi45ODE3LTIuOTgyMiAyLjk4MTdoLTEyLjY5NWMtMS42NTE5IDAtMi44NzIzLTIuNDU3NS0yLjA0NjQtMy44ODgxbDMuODA0OS02LjU5MDN6bTE4LjM1NSAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzIgMGgyNC42N2MxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yNC42N2MtMS42NTE5IDAtMi45ODE3LTEuMzI5OC0yLjk4MTctMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMyOTgtMi45ODE3IDIuOTgxNy0yLjk4MTd6bTM2LjczMyAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzMgMHM0LjM0MTMgMWUtMyA2LjI5MjEgMGw4LjQ0OTYgMTQuNjM1YzAuODI1OTYgMS40MzA2LTAuMzk0NDYgMy44ODgxLTIuMDQ2NCAzLjg4ODFoLTEyLjY5NWMtMS42NTE5IDAtMi45ODIyLTEuMzI5OC0yLjk4MjItMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMzMDMtMi45ODE3IDIuOTgyMi0yLjk4MTd6bS04MC44OTggNDIuMTAzYzMuMzAzOCAyLjQ1NzYgNS40MzY5IDYuMzkzMiA1LjQzNjkgMTAuODQ1IDAgMC43NjExOS0wLjA2MzU4IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgzNi45NDhjLTAuMTE5ODctMC43MjYxOS0wLjE4MzQ1LTEuNDcxOC0wLjE4MzQ1LTIuMjMyOSAwLTQuNDUyMSAyLjEzMzItOC4zODc3IDUuNDM2OS0xMC44NDV6IiBzdHJva2Utd2lkdGg9IjE0LjU4MiIvPjxjaXJjbGUgY3g9IjEzNi4yNiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjxjaXJjbGUgY3g9IjE1Ni44MiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjwvZz48cGF0aCBkPSJtOTAuNzQyIDExNi43OS0xMC43ODYtMTEuMTYgMjQuNjM4LTEzLjcxIDI1LjEwNiAxMy43MS05LjUxMDQgMTEuMTZjLTI3Ljc5NCAwLTYuNjg2My0xZS01IC0yOS40NDctMWUtNXoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLXdpZHRoPSI0LjI2Ii8+PHJlY3QgeD0iMTAyLjYzIiB5PSI4MS40OTciIHdpZHRoPSI0LjI2IiBoZWlnaHQ9IjExLjk2NCIgcnk9IjAiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="45" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzkuODdtbSIgaGVpZ2h0PSIxMjIuNjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNzkuODcgMTIyLjY4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wOCAtOTUuOTQ2KSI+PHBhdGggZD0ibTEwOS43OCAxMjEuMTd2NS4yZS00YTMxLjYgNi40NDU5IDAgMCAwLTEzLjU5NSAwLjYyOTQyaDAuMDAzNmExMC43MTYgMzAuMjcyIDY3LjgyOCAwIDAtMTEuNTkyIDQuNDUzIDEwLjcxNiAzMC4yNzIgNjcuODI4IDAgMC0xNC40OTcgOS4xODk2bC0xZS0zIDFlLTNhMTAuNzE2IDMwLjI3MiA2Ny44MjggMCAwLTAuMDIzMjUgMC4wMTkxdjcxLjU0OWg3LjMwNnYxMS42MTVoMTEuMjg3di0xMS42MTVoNDIuMTQ0djExLjYxNWgxMS4yODh2LTExLjYxNWg3LjMwNTV2LTM4LjkwN2gwLjA3OHYtMzIuNjRhMzkuNzA0IDE0LjU0NSAwIDAgMCAwLTUuMmUtNHYtNS4xZS00YTMwLjI3MiAxMC43MTYgMjIuMTcyIDAgMC0wLjAxNS0wLjAxMjkgMzAuMjcyIDEwLjcxNiAyMi4xNzIgMCAwLThlLTMgLTdlLTNsLTFlLTMgLTUuMmUtNGEzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTQuNDk4LTkuMTkwNiAzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTEuNTkyLTQuNDUzaDAuMDI4OWEzMS42IDYuNDQ1OSAwIDAgMC0xMy42Mi0wLjYyOTk0em0tMTcuMjQxIDkuMDExM2gzNC40ODNjMC40MjI1MSAwIDAuNzYyNzQgMC4zMzk3MSAwLjc2Mjc0IDAuNzYyMjN2My45MDMxYzAgMC40MjI1MS0wLjM0MDIzIDAuNzYyNzQtMC43NjI3NCAwLjc2Mjc0aC0zNC40ODNjLTAuNDIyNTEgMC0wLjc2Mjc0LTAuMzQwMjMtMC43NjI3NC0wLjc2Mjc0di0zLjkwMzFjMC0wLjQyMjUyIDAuMzQwMjMtMC43NjIyMyAwLjc2Mjc0LTAuNzYyMjN6bS0xMi4zNzEgMTAuODc3aDU5LjIyNWMxLjEyNTcgMCAyLjAzMTkgMC45MDY2OSAyLjAzMTkgMi4wMzI0djI0LjIwNmMwIDEuMTI1OC0wLjkwNjE4IDIuMDMxOS0yLjAzMTkgMi4wMzE5aC01OS4yMjVjLTEuMTI1NyAwLTIuMDMxOS0wLjkwNjE3LTIuMDMxOS0yLjAzMTl2LTI0LjIwNmMwLTEuMTI1OCAwLjkwNjE4LTIuMDMyNCAyLjAzMTktMi4wMzI0em0yLjg1NzcgNDMuNTY3YTQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzIDQuMjMxOCA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMyMyA0LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMS00LjIzMjMtNC4yMzIzIDQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzLTQuMjMxOHptNTMuNDMxIDBhNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMjMgNC4yMzE4IDQuMjMyMiA0LjIzMjIgMCAwIDEtNC4yMzIzIDQuMjMyMyA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMxOC00LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMTgtNC4yMzE4eiIvPjxwYXRoIGQ9Im05Ni43MTcgMTI1LjQzIDMwLjA0LTI4LjI4NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMi40Ii8+PHBhdGggZD0ibTExOC43MSAxMjUuNDMgMzAuMDQtMjguMjg0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIyLjQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.51563" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="46" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE1LjQzbW0iIGhlaWdodD0iMTY5LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNS40MyAxNjkuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ2LjE5NCAtNjIuOTE1KSI+PHBhdGggZD0ibTg2Ljg5IDYyLjkxNWMtMS4xMjM3IDAtMi4wMjgzIDAuOTA0NTgtMi4wMjgzIDIuMDI4M3YxMS4zMzRoLTYuNjU3Yy0xMy42NjkgMC0yNC42NzMgMTEuMDA1LTI0LjY3MyAyNC42NzN2NzEuNTY2YzAgMTAuODExIDYuODg2OSAxOS45NSAxNi41MjkgMjMuMzAxaC0yLjU2ODhsLTIxLjI5OCAyNC4zMjF2MTIuNTg5aDE0LjgxN2wxOS40ODUtMjQuMzc3aDQ2LjgyNWwxOS40ODUgMjQuMzc3aDE0LjgxNnYtMTIuNTg5bC0yMS4yOTctMjQuMzJoLTIuNTY5NGM5LjY0Mi0zLjM1MDkgMTYuNTI5LTEyLjQ4OSAxNi41MjktMjMuMzAxdi03MS41NjZjMC0xMy42NjktMTEuMDA1LTI0LjY3My0yNC42NzMtMjQuNjczaC02LjY1NjR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU4LTIuMDI4My0yLjAyODMtMi4wMjgzaC0xMi41NTVjLTEuMTIzNyAwLTIuMDI4MyAwLjkwNDU4LTIuMDI4MyAyLjAyODN2MTEuMzM0aC00Ljg2ODR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU5LTIuMDI4My0yLjAyODMtMi4wMjgzem04Ljg0NjUgMjQuNDk5aDE2LjM0MmMxLjEyMzcgMCAyLjAyODMgMC45MDQ1OSAyLjAyODMgMi4wMjgzdjMuNTE0YzAgMS4xMjM3LTAuOTA0NTggMi4wMjgzLTIuMDI4MyAyLjAyODNoLTE2LjM0MmMtMS4xMjM3IDAtMi4wMjgzLTAuOTA0NTktMi4wMjgzLTIuMDI4M3YtMy41MTRjMC0xLjEyMzcgMC45MDQ1OS0yLjAyODMgMi4wMjgzLTIuMDI4M3ptLTE2LjU5MiAxOC4wNDloNDkuNTI2YzQuMDI5NyAwIDcuMjczNSAzLjI0MzggNy4yNzM1IDcuMjczNHYxMi42YzAgNC4wMjk2LTMuMjQzOCA3LjI3MzUtNy4yNzM1IDcuMjczNWgtNDkuNTI2Yy00LjAyOTcgMC03LjI3NC0zLjI0MzgtNy4yNzQtNy4yNzM1di0xMi42YzAtNC4wMjk2IDMuMjQ0My03LjI3MzQgNy4yNzQtNy4yNzM0em0tMi41NzA5IDY0LjIzN2E2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNTUtNi4xMzU1IDYuMTM1NCA2LjEzNTQgMCAwIDEgNi4xMzU1LTYuMTM1em01NC42NjcgMGE2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNS02LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMSA2LjEzNS02LjEzNXoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.94261" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="47" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTQ4LjUzbW0iIGhlaWdodD0iODkuNjY5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OC41MyA4OS42NjkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM3Ljc1OCAtMTE3LjU1KSI+PHBhdGggZD0ibTM3Ljc1OCAxODYuNTR2MjAuNjczaDE0OC41M3YtMjAuNjczaC0xNi45NDV2Ni43NDAyaC0zOC42MDV2LTYuNzQwMmgtMzcuNDI5djYuNzQwMmgtMzguNjA1di02Ljc0MDJ6Ii8+PHBhdGggZD0ibTU2LjUyNSAxMTcuNTUtMTcuODI0IDM3LjMwMXY3LjY4MjdsMC43MDI4IDAuNTI5MTcgMTUuMjk5IDExLjUxNmg1LjE3ZS00IDguNzI3NnY3LjM1M2gyNS40NTV2LTcuMzUzaDQ2LjI3MnY3LjM1M2gyNS40NTV2LTcuMzUzaDguNzI3NmwxNS4zLTExLjUxNiAwLjcwMjgtMC41MjkxN3YtNy42NzE5bC0xNS4wMjItMzcuMzExaC0xMTMuOHptMi42MTA3IDYuMjg3aDIxLjExN3YxOC4zMzloLTI4LjYxNGw3LjQ5NzItMTguMzM5em0yNi4yNzIgMGgyNC4wMzd2MTguMzM5aC0yNC4wMzd2LTE4LjMzOXptMjkuMTkzIDBoMjQuMDM3djE4LjMzOWgtMjQuMDM3di0xOC4zMzl6bTI5LjE5MyAwaDIxLjExN2w3LjQ5NjcgMTguMzM5aC0yOC42MTN2LTE4LjMzOXoiIHN0cm9rZS1taXRlcmxpbWl0PSIyLjEiIHN0cm9rZS13aWR0aD0iNC4xMTIxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="48" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="49" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2OC44OW1tIiBoZWlnaHQ9IjE0OC40Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjguODkgMTQ4LjQyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMC42NjIgLTgwLjU3OCkiPjxwYXRoIGQ9Im0yNS41ODQgMTUxLjVjLTIuNzI3IDAtNC45MjIyIDIuMTk1Ny00LjkyMjIgNC45MjI3djY3LjY1MmMwIDIuNzI3IDIuMTk1MiA0LjkyMjcgNC45MjIyIDQuOTIyN2gxNTkuMDVjMi43MjcgMCA0LjkyMjItMi4xOTU3IDQuOTIyMi00LjkyMjd2LTY3LjY1MmMwLTIuNzI3LTIuMTk1Mi00LjkyMjctNC45MjIyLTQuOTIyN2gtMjQuODA4YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDU2OCA5LjkyNWgtMTA3LjU0YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDYyLTkuOTI1eiIvPjxjaXJjbGUgY3g9IjEwNS4xMSIgY3k9IjE0OS40NiIgcj0iNjAuODcyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMTYuMDI1Ii8+PGc+PHBhdGggZD0ibTc5Ljk5NiAxMTUuODhjLTIuOTkgMC01LjM5NzEgMi40MDcxLTUuMzk3MSA1LjM5NzF2MjkuODk1YzAgMi45OSAyLjQwNzEgNS4zOTcxIDUuMzk3MSA1LjM5NzFoNTAuMjIzYzIuOTkgMCA1LjM5NzEtMi40MDcxIDUuMzk3MS01LjM5NzF2LTI5Ljg5NWMwLTIuOTktMi40MDcxLTUuMzk3MS01LjM5NzEtNS4zOTcxem04LjA4NTMgNS45NDloMTAuNjY2YzAuOTYxNTUgMCAxLjczNTMgMC43NzQyNiAxLjczNTMgMS43MzU4djcuNjE5N2MwIDAuOTYxNTUtMC43NzM3NSAxLjczNTMtMS43MzUzIDEuNzM1M2gtMTAuNjY2Yy0wLjk2MTU1IDAtMS43MzUzLTAuNzczNzUtMS43MzUzLTEuNzM1M3YtNy42MTk3YzAtMC45NjE1NSAwLjc3Mzc1LTEuNzM1OCAxLjczNTMtMS43MzU4em0yMy4zODcgMGgxMC42NjZjMC45NjE1NSAwIDEuNzM1OCAwLjc3NDI2IDEuNzM1OCAxLjczNTh2Ny42MTk3YzAgMC45NjE1NS0wLjc3NDI2IDEuNzM1My0xLjczNTggMS43MzUzaC0xMC42NjZjLTAuOTYxNTUgMC0xLjczNTgtMC43NzM3NS0xLjczNTgtMS43MzUzdi03LjYxOTdjMC0wLjk2MTU1IDAuNzc0MjYtMS43MzU4IDEuNzM1OC0xLjczNTh6Ii8+PHJlY3QgeD0iODEuNzIxIiB5PSIxNTIuMzciIHdpZHRoPSIxMS4zODEiIGhlaWdodD0iMTQuMDMiIHJ5PSI1LjM5NzEiLz48cmVjdCB4PSIxMTcuMTEiIHk9IjE1Mi4zNyIgd2lkdGg9IjExLjM4MSIgaGVpZ2h0PSIxNC4wMyIgcnk9IjUuMzk3MSIvPjxwYXRoIGQ9Im0xMDUuMTEgMTAwLjkyYTMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA4IDIwLjM1NSAzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODMgMi4zOTI2aDkuNTc5OGMwLjU1MDAzLTIuMzk4NyAyLjY4OTktNC4xNzc1IDUuMjYwMS00LjE3NzVoOC4wMDI2YzIuNTcwMiAwIDQuNzA5NiAxLjc3ODkgNS4yNTk2IDQuMTc3NWg1LjAyNjZjMC4yOTYwNS0yLjcwNjIgMi41NzYtNC43OTg3IDUuMzYzNS00Ljc5ODdoOC4wMDMxYzIuNzg3NSAwIDUuMDY3NCAyLjA5MjUgNS4zNjM1IDQuNzk4N2g4LjcwN2EzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODItMi4zOTI2IDMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA5LTIwLjM1NXoiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTQ4LjUzbW0iIGhlaWdodD0iODkuNjY5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OC41MyA4OS42NjkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM3Ljc1OCAtMTE3LjU1KSI+PHBhdGggZD0ibTM3Ljc1OCAxODYuNTR2MjAuNjczaDE0OC41M3YtMjAuNjczaC0xNi45NDV2Ni43NDAyaC0zOC42MDV2LTYuNzQwMmgtMzcuNDI5djYuNzQwMmgtMzguNjA1di02Ljc0MDJ6Ii8+PHBhdGggZD0ibTU2LjUyNSAxMTcuNTUtMTcuODI0IDM3LjMwMXY3LjY4MjdsMC43MDI4IDAuNTI5MTcgMTUuMjk5IDExLjUxNmg1LjE3ZS00IDguNzI3NnY3LjM1M2gyNS40NTV2LTcuMzUzaDQ2LjI3MnY3LjM1M2gyNS40NTV2LTcuMzUzaDguNzI3NmwxNS4zLTExLjUxNiAwLjcwMjgtMC41MjkxN3YtNy42NzE5bC0xNS4wMjItMzcuMzExaC0xMTMuOHptMi42MTA3IDYuMjg3aDIxLjExN3YxOC4zMzloLTI4LjYxNGw3LjQ5NzItMTguMzM5em0yNi4yNzIgMGgyNC4wMzd2MTguMzM5aC0yNC4wMzd2LTE4LjMzOXptMjkuMTkzIDBoMjQuMDM3djE4LjMzOWgtMjQuMDM3di0xOC4zMzl6bTI5LjE5MyAwaDIxLjExN2w3LjQ5NjcgMTguMzM5aC0yOC42MTN2LTE4LjMzOXoiIHN0cm9rZS1taXRlcmxpbWl0PSIyLjEiIHN0cm9rZS13aWR0aD0iNC4xMTIxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="50" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTU5LjU2bW0iIGhlaWdodD0iMTEyLjI0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1OS41NiAxMTIuMjQiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Ljk4MSAtODEuNDk3KSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48Y2lyY2xlIGN4PSI1Mi43MDEiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48Y2lyY2xlIGN4PSI3My4yNTkiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48cGF0aCBkPSJtNDAuMzk1IDEyNC40LTE1LjQxNSAyMy44MDl2MzcuMTUxaDE0LjIzMWMtMC4xMTk4OC0wLjcyNjE5LTAuMTgzNDUtMS40NzE4LTAuMTgzNDUtMi4yMzI5IDAtNy40ODIyIDYuMDI0LTEzLjUwNiAxMy41MDYtMTMuNTA2aDEwNC40NWM3LjQ4MjIgMCAxMy41MDYgNi4wMjQgMTMuNTA2IDEzLjUwNiAwIDAuNzYxMTktMC4wNjM2IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgxNC4yM3YtMzkuNTk1bC0xNC4zNzEtMjEuMzY2em0wLjkwMDcyIDUuNzc5YzEuOTUwOSAxZS0zIDYuMjkyMSAwIDYuMjkyMSAwIDEuNjUxOSAwIDIuOTgyMiAxLjMyOTggMi45ODIyIDIuOTgxN3YxMi41NmMwIDEuNjUxOS0xLjMzMDMgMi45ODE3LTIuOTgyMiAyLjk4MTdoLTEyLjY5NWMtMS42NTE5IDAtMi44NzIzLTIuNDU3NS0yLjA0NjQtMy44ODgxbDMuODA0OS02LjU5MDN6bTE4LjM1NSAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzIgMGgyNC42N2MxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yNC42N2MtMS42NTE5IDAtMi45ODE3LTEuMzI5OC0yLjk4MTctMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMyOTgtMi45ODE3IDIuOTgxNy0yLjk4MTd6bTM2LjczMyAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzMgMHM0LjM0MTMgMWUtMyA2LjI5MjEgMGw4LjQ0OTYgMTQuNjM1YzAuODI1OTYgMS40MzA2LTAuMzk0NDYgMy44ODgxLTIuMDQ2NCAzLjg4ODFoLTEyLjY5NWMtMS42NTE5IDAtMi45ODIyLTEuMzI5OC0yLjk4MjItMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMzMDMtMi45ODE3IDIuOTgyMi0yLjk4MTd6bS04MC44OTggNDIuMTAzYzMuMzAzOCAyLjQ1NzYgNS40MzY5IDYuMzkzMiA1LjQzNjkgMTAuODQ1IDAgMC43NjExOS0wLjA2MzU4IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgzNi45NDhjLTAuMTE5ODctMC43MjYxOS0wLjE4MzQ1LTEuNDcxOC0wLjE4MzQ1LTIuMjMyOSAwLTQuNDUyMSAyLjEzMzItOC4zODc3IDUuNDM2OS0xMC44NDV6IiBzdHJva2Utd2lkdGg9IjE0LjU4MiIvPjxjaXJjbGUgY3g9IjEzNi4yNiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjxjaXJjbGUgY3g9IjE1Ni44MiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjwvZz48cGF0aCBkPSJtOTAuNzQyIDExNi43OS0xMC43ODYtMTEuMTYgMjQuNjM4LTEzLjcxIDI1LjEwNiAxMy43MS05LjUxMDQgMTEuMTZjLTI3Ljc5NCAwLTYuNjg2My0xZS01IC0yOS40NDctMWUtNXoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLXdpZHRoPSI0LjI2Ii8+PHJlY3QgeD0iMTAyLjYzIiB5PSI4MS40OTciIHdpZHRoPSI0LjI2IiBoZWlnaHQ9IjExLjk2NCIgcnk9IjAiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="51" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzkuODdtbSIgaGVpZ2h0PSIxMjIuNjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNzkuODcgMTIyLjY4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wOCAtOTUuOTQ2KSI+PHBhdGggZD0ibTEwOS43OCAxMjEuMTd2NS4yZS00YTMxLjYgNi40NDU5IDAgMCAwLTEzLjU5NSAwLjYyOTQyaDAuMDAzNmExMC43MTYgMzAuMjcyIDY3LjgyOCAwIDAtMTEuNTkyIDQuNDUzIDEwLjcxNiAzMC4yNzIgNjcuODI4IDAgMC0xNC40OTcgOS4xODk2bC0xZS0zIDFlLTNhMTAuNzE2IDMwLjI3MiA2Ny44MjggMCAwLTAuMDIzMjUgMC4wMTkxdjcxLjU0OWg3LjMwNnYxMS42MTVoMTEuMjg3di0xMS42MTVoNDIuMTQ0djExLjYxNWgxMS4yODh2LTExLjYxNWg3LjMwNTV2LTM4LjkwN2gwLjA3OHYtMzIuNjRhMzkuNzA0IDE0LjU0NSAwIDAgMCAwLTUuMmUtNHYtNS4xZS00YTMwLjI3MiAxMC43MTYgMjIuMTcyIDAgMC0wLjAxNS0wLjAxMjkgMzAuMjcyIDEwLjcxNiAyMi4xNzIgMCAwLThlLTMgLTdlLTNsLTFlLTMgLTUuMmUtNGEzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTQuNDk4LTkuMTkwNiAzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTEuNTkyLTQuNDUzaDAuMDI4OWEzMS42IDYuNDQ1OSAwIDAgMC0xMy42Mi0wLjYyOTk0em0tMTcuMjQxIDkuMDExM2gzNC40ODNjMC40MjI1MSAwIDAuNzYyNzQgMC4zMzk3MSAwLjc2Mjc0IDAuNzYyMjN2My45MDMxYzAgMC40MjI1MS0wLjM0MDIzIDAuNzYyNzQtMC43NjI3NCAwLjc2Mjc0aC0zNC40ODNjLTAuNDIyNTEgMC0wLjc2Mjc0LTAuMzQwMjMtMC43NjI3NC0wLjc2Mjc0di0zLjkwMzFjMC0wLjQyMjUyIDAuMzQwMjMtMC43NjIyMyAwLjc2Mjc0LTAuNzYyMjN6bS0xMi4zNzEgMTAuODc3aDU5LjIyNWMxLjEyNTcgMCAyLjAzMTkgMC45MDY2OSAyLjAzMTkgMi4wMzI0djI0LjIwNmMwIDEuMTI1OC0wLjkwNjE4IDIuMDMxOS0yLjAzMTkgMi4wMzE5aC01OS4yMjVjLTEuMTI1NyAwLTIuMDMxOS0wLjkwNjE3LTIuMDMxOS0yLjAzMTl2LTI0LjIwNmMwLTEuMTI1OCAwLjkwNjE4LTIuMDMyNCAyLjAzMTktMi4wMzI0em0yLjg1NzcgNDMuNTY3YTQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzIDQuMjMxOCA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMyMyA0LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMS00LjIzMjMtNC4yMzIzIDQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzLTQuMjMxOHptNTMuNDMxIDBhNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMjMgNC4yMzE4IDQuMjMyMiA0LjIzMjIgMCAwIDEtNC4yMzIzIDQuMjMyMyA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMxOC00LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMTgtNC4yMzE4eiIvPjxwYXRoIGQ9Im05Ni43MTcgMTI1LjQzIDMwLjA0LTI4LjI4NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMi40Ii8+PHBhdGggZD0ibTExOC43MSAxMjUuNDMgMzAuMDQtMjguMjg0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIyLjQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.51563" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="52" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE1LjQzbW0iIGhlaWdodD0iMTY5LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNS40MyAxNjkuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ2LjE5NCAtNjIuOTE1KSI+PHBhdGggZD0ibTg2Ljg5IDYyLjkxNWMtMS4xMjM3IDAtMi4wMjgzIDAuOTA0NTgtMi4wMjgzIDIuMDI4M3YxMS4zMzRoLTYuNjU3Yy0xMy42NjkgMC0yNC42NzMgMTEuMDA1LTI0LjY3MyAyNC42NzN2NzEuNTY2YzAgMTAuODExIDYuODg2OSAxOS45NSAxNi41MjkgMjMuMzAxaC0yLjU2ODhsLTIxLjI5OCAyNC4zMjF2MTIuNTg5aDE0LjgxN2wxOS40ODUtMjQuMzc3aDQ2LjgyNWwxOS40ODUgMjQuMzc3aDE0LjgxNnYtMTIuNTg5bC0yMS4yOTctMjQuMzJoLTIuNTY5NGM5LjY0Mi0zLjM1MDkgMTYuNTI5LTEyLjQ4OSAxNi41MjktMjMuMzAxdi03MS41NjZjMC0xMy42NjktMTEuMDA1LTI0LjY3My0yNC42NzMtMjQuNjczaC02LjY1NjR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU4LTIuMDI4My0yLjAyODMtMi4wMjgzaC0xMi41NTVjLTEuMTIzNyAwLTIuMDI4MyAwLjkwNDU4LTIuMDI4MyAyLjAyODN2MTEuMzM0aC00Ljg2ODR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU5LTIuMDI4My0yLjAyODMtMi4wMjgzem04Ljg0NjUgMjQuNDk5aDE2LjM0MmMxLjEyMzcgMCAyLjAyODMgMC45MDQ1OSAyLjAyODMgMi4wMjgzdjMuNTE0YzAgMS4xMjM3LTAuOTA0NTggMi4wMjgzLTIuMDI4MyAyLjAyODNoLTE2LjM0MmMtMS4xMjM3IDAtMi4wMjgzLTAuOTA0NTktMi4wMjgzLTIuMDI4M3YtMy41MTRjMC0xLjEyMzcgMC45MDQ1OS0yLjAyODMgMi4wMjgzLTIuMDI4M3ptLTE2LjU5MiAxOC4wNDloNDkuNTI2YzQuMDI5NyAwIDcuMjczNSAzLjI0MzggNy4yNzM1IDcuMjczNHYxMi42YzAgNC4wMjk2LTMuMjQzOCA3LjI3MzUtNy4yNzM1IDcuMjczNWgtNDkuNTI2Yy00LjAyOTcgMC03LjI3NC0zLjI0MzgtNy4yNzQtNy4yNzM1di0xMi42YzAtNC4wMjk2IDMuMjQ0My03LjI3MzQgNy4yNzQtNy4yNzM0em0tMi41NzA5IDY0LjIzN2E2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNTUtNi4xMzU1IDYuMTM1NCA2LjEzNTQgMCAwIDEgNi4xMzU1LTYuMTM1em01NC42NjcgMGE2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNS02LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMSA2LjEzNS02LjEzNXoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.94261" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="53" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTQ4LjUzbW0iIGhlaWdodD0iODkuNjY5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OC41MyA4OS42NjkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM3Ljc1OCAtMTE3LjU1KSI+PHBhdGggZD0ibTM3Ljc1OCAxODYuNTR2MjAuNjczaDE0OC41M3YtMjAuNjczaC0xNi45NDV2Ni43NDAyaC0zOC42MDV2LTYuNzQwMmgtMzcuNDI5djYuNzQwMmgtMzguNjA1di02Ljc0MDJ6Ii8+PHBhdGggZD0ibTU2LjUyNSAxMTcuNTUtMTcuODI0IDM3LjMwMXY3LjY4MjdsMC43MDI4IDAuNTI5MTcgMTUuMjk5IDExLjUxNmg1LjE3ZS00IDguNzI3NnY3LjM1M2gyNS40NTV2LTcuMzUzaDQ2LjI3MnY3LjM1M2gyNS40NTV2LTcuMzUzaDguNzI3NmwxNS4zLTExLjUxNiAwLjcwMjgtMC41MjkxN3YtNy42NzE5bC0xNS4wMjItMzcuMzExaC0xMTMuOHptMi42MTA3IDYuMjg3aDIxLjExN3YxOC4zMzloLTI4LjYxNGw3LjQ5NzItMTguMzM5em0yNi4yNzIgMGgyNC4wMzd2MTguMzM5aC0yNC4wMzd2LTE4LjMzOXptMjkuMTkzIDBoMjQuMDM3djE4LjMzOWgtMjQuMDM3di0xOC4zMzl6bTI5LjE5MyAwaDIxLjExN2w3LjQ5NjcgMTguMzM5aC0yOC42MTN2LTE4LjMzOXoiIHN0cm9rZS1taXRlcmxpbWl0PSIyLjEiIHN0cm9rZS13aWR0aD0iNC4xMTIxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="54" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="55" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2OC44OW1tIiBoZWlnaHQ9IjE0OC40Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjguODkgMTQ4LjQyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMC42NjIgLTgwLjU3OCkiPjxwYXRoIGQ9Im0yNS41ODQgMTUxLjVjLTIuNzI3IDAtNC45MjIyIDIuMTk1Ny00LjkyMjIgNC45MjI3djY3LjY1MmMwIDIuNzI3IDIuMTk1MiA0LjkyMjcgNC45MjIyIDQuOTIyN2gxNTkuMDVjMi43MjcgMCA0LjkyMjItMi4xOTU3IDQuOTIyMi00LjkyMjd2LTY3LjY1MmMwLTIuNzI3LTIuMTk1Mi00LjkyMjctNC45MjIyLTQuOTIyN2gtMjQuODA4YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDU2OCA5LjkyNWgtMTA3LjU0YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDYyLTkuOTI1eiIvPjxjaXJjbGUgY3g9IjEwNS4xMSIgY3k9IjE0OS40NiIgcj0iNjAuODcyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMTYuMDI1Ii8+PGc+PHBhdGggZD0ibTc5Ljk5NiAxMTUuODhjLTIuOTkgMC01LjM5NzEgMi40MDcxLTUuMzk3MSA1LjM5NzF2MjkuODk1YzAgMi45OSAyLjQwNzEgNS4zOTcxIDUuMzk3MSA1LjM5NzFoNTAuMjIzYzIuOTkgMCA1LjM5NzEtMi40MDcxIDUuMzk3MS01LjM5NzF2LTI5Ljg5NWMwLTIuOTktMi40MDcxLTUuMzk3MS01LjM5NzEtNS4zOTcxem04LjA4NTMgNS45NDloMTAuNjY2YzAuOTYxNTUgMCAxLjczNTMgMC43NzQyNiAxLjczNTMgMS43MzU4djcuNjE5N2MwIDAuOTYxNTUtMC43NzM3NSAxLjczNTMtMS43MzUzIDEuNzM1M2gtMTAuNjY2Yy0wLjk2MTU1IDAtMS43MzUzLTAuNzczNzUtMS43MzUzLTEuNzM1M3YtNy42MTk3YzAtMC45NjE1NSAwLjc3Mzc1LTEuNzM1OCAxLjczNTMtMS43MzU4em0yMy4zODcgMGgxMC42NjZjMC45NjE1NSAwIDEuNzM1OCAwLjc3NDI2IDEuNzM1OCAxLjczNTh2Ny42MTk3YzAgMC45NjE1NS0wLjc3NDI2IDEuNzM1My0xLjczNTggMS43MzUzaC0xMC42NjZjLTAuOTYxNTUgMC0xLjczNTgtMC43NzM3NS0xLjczNTgtMS43MzUzdi03LjYxOTdjMC0wLjk2MTU1IDAuNzc0MjYtMS43MzU4IDEuNzM1OC0xLjczNTh6Ii8+PHJlY3QgeD0iODEuNzIxIiB5PSIxNTIuMzciIHdpZHRoPSIxMS4zODEiIGhlaWdodD0iMTQuMDMiIHJ5PSI1LjM5NzEiLz48cmVjdCB4PSIxMTcuMTEiIHk9IjE1Mi4zNyIgd2lkdGg9IjExLjM4MSIgaGVpZ2h0PSIxNC4wMyIgcnk9IjUuMzk3MSIvPjxwYXRoIGQ9Im0xMDUuMTEgMTAwLjkyYTMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA4IDIwLjM1NSAzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODMgMi4zOTI2aDkuNTc5OGMwLjU1MDAzLTIuMzk4NyAyLjY4OTktNC4xNzc1IDUuMjYwMS00LjE3NzVoOC4wMDI2YzIuNTcwMiAwIDQuNzA5NiAxLjc3ODkgNS4yNTk2IDQuMTc3NWg1LjAyNjZjMC4yOTYwNS0yLjcwNjIgMi41NzYtNC43OTg3IDUuMzYzNS00Ljc5ODdoOC4wMDMxYzIuNzg3NSAwIDUuMDY3NCAyLjA5MjUgNS4zNjM1IDQuNzk4N2g4LjcwN2EzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODItMi4zOTI2IDMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA5LTIwLjM1NXoiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="56" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTU5LjU2bW0iIGhlaWdodD0iMTEyLjI0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1OS41NiAxMTIuMjQiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Ljk4MSAtODEuNDk3KSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48Y2lyY2xlIGN4PSI1Mi43MDEiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48Y2lyY2xlIGN4PSI3My4yNTkiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48cGF0aCBkPSJtNDAuMzk1IDEyNC40LTE1LjQxNSAyMy44MDl2MzcuMTUxaDE0LjIzMWMtMC4xMTk4OC0wLjcyNjE5LTAuMTgzNDUtMS40NzE4LTAuMTgzNDUtMi4yMzI5IDAtNy40ODIyIDYuMDI0LTEzLjUwNiAxMy41MDYtMTMuNTA2aDEwNC40NWM3LjQ4MjIgMCAxMy41MDYgNi4wMjQgMTMuNTA2IDEzLjUwNiAwIDAuNzYxMTktMC4wNjM2IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgxNC4yM3YtMzkuNTk1bC0xNC4zNzEtMjEuMzY2em0wLjkwMDcyIDUuNzc5YzEuOTUwOSAxZS0zIDYuMjkyMSAwIDYuMjkyMSAwIDEuNjUxOSAwIDIuOTgyMiAxLjMyOTggMi45ODIyIDIuOTgxN3YxMi41NmMwIDEuNjUxOS0xLjMzMDMgMi45ODE3LTIuOTgyMiAyLjk4MTdoLTEyLjY5NWMtMS42NTE5IDAtMi44NzIzLTIuNDU3NS0yLjA0NjQtMy44ODgxbDMuODA0OS02LjU5MDN6bTE4LjM1NSAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzIgMGgyNC42N2MxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yNC42N2MtMS42NTE5IDAtMi45ODE3LTEuMzI5OC0yLjk4MTctMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMyOTgtMi45ODE3IDIuOTgxNy0yLjk4MTd6bTM2LjczMyAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzMgMHM0LjM0MTMgMWUtMyA2LjI5MjEgMGw4LjQ0OTYgMTQuNjM1YzAuODI1OTYgMS40MzA2LTAuMzk0NDYgMy44ODgxLTIuMDQ2NCAzLjg4ODFoLTEyLjY5NWMtMS42NTE5IDAtMi45ODIyLTEuMzI5OC0yLjk4MjItMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMzMDMtMi45ODE3IDIuOTgyMi0yLjk4MTd6bS04MC44OTggNDIuMTAzYzMuMzAzOCAyLjQ1NzYgNS40MzY5IDYuMzkzMiA1LjQzNjkgMTAuODQ1IDAgMC43NjExOS0wLjA2MzU4IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgzNi45NDhjLTAuMTE5ODctMC43MjYxOS0wLjE4MzQ1LTEuNDcxOC0wLjE4MzQ1LTIuMjMyOSAwLTQuNDUyMSAyLjEzMzItOC4zODc3IDUuNDM2OS0xMC44NDV6IiBzdHJva2Utd2lkdGg9IjE0LjU4MiIvPjxjaXJjbGUgY3g9IjEzNi4yNiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjxjaXJjbGUgY3g9IjE1Ni44MiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjwvZz48cGF0aCBkPSJtOTAuNzQyIDExNi43OS0xMC43ODYtMTEuMTYgMjQuNjM4LTEzLjcxIDI1LjEwNiAxMy43MS05LjUxMDQgMTEuMTZjLTI3Ljc5NCAwLTYuNjg2My0xZS01IC0yOS40NDctMWUtNXoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLXdpZHRoPSI0LjI2Ii8+PHJlY3QgeD0iMTAyLjYzIiB5PSI4MS40OTciIHdpZHRoPSI0LjI2IiBoZWlnaHQ9IjExLjk2NCIgcnk9IjAiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="57" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzkuODdtbSIgaGVpZ2h0PSIxMjIuNjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNzkuODcgMTIyLjY4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wOCAtOTUuOTQ2KSI+PHBhdGggZD0ibTEwOS43OCAxMjEuMTd2NS4yZS00YTMxLjYgNi40NDU5IDAgMCAwLTEzLjU5NSAwLjYyOTQyaDAuMDAzNmExMC43MTYgMzAuMjcyIDY3LjgyOCAwIDAtMTEuNTkyIDQuNDUzIDEwLjcxNiAzMC4yNzIgNjcuODI4IDAgMC0xNC40OTcgOS4xODk2bC0xZS0zIDFlLTNhMTAuNzE2IDMwLjI3MiA2Ny44MjggMCAwLTAuMDIzMjUgMC4wMTkxdjcxLjU0OWg3LjMwNnYxMS42MTVoMTEuMjg3di0xMS42MTVoNDIuMTQ0djExLjYxNWgxMS4yODh2LTExLjYxNWg3LjMwNTV2LTM4LjkwN2gwLjA3OHYtMzIuNjRhMzkuNzA0IDE0LjU0NSAwIDAgMCAwLTUuMmUtNHYtNS4xZS00YTMwLjI3MiAxMC43MTYgMjIuMTcyIDAgMC0wLjAxNS0wLjAxMjkgMzAuMjcyIDEwLjcxNiAyMi4xNzIgMCAwLThlLTMgLTdlLTNsLTFlLTMgLTUuMmUtNGEzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTQuNDk4LTkuMTkwNiAzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTEuNTkyLTQuNDUzaDAuMDI4OWEzMS42IDYuNDQ1OSAwIDAgMC0xMy42Mi0wLjYyOTk0em0tMTcuMjQxIDkuMDExM2gzNC40ODNjMC40MjI1MSAwIDAuNzYyNzQgMC4zMzk3MSAwLjc2Mjc0IDAuNzYyMjN2My45MDMxYzAgMC40MjI1MS0wLjM0MDIzIDAuNzYyNzQtMC43NjI3NCAwLjc2Mjc0aC0zNC40ODNjLTAuNDIyNTEgMC0wLjc2Mjc0LTAuMzQwMjMtMC43NjI3NC0wLjc2Mjc0di0zLjkwMzFjMC0wLjQyMjUyIDAuMzQwMjMtMC43NjIyMyAwLjc2Mjc0LTAuNzYyMjN6bS0xMi4zNzEgMTAuODc3aDU5LjIyNWMxLjEyNTcgMCAyLjAzMTkgMC45MDY2OSAyLjAzMTkgMi4wMzI0djI0LjIwNmMwIDEuMTI1OC0wLjkwNjE4IDIuMDMxOS0yLjAzMTkgMi4wMzE5aC01OS4yMjVjLTEuMTI1NyAwLTIuMDMxOS0wLjkwNjE3LTIuMDMxOS0yLjAzMTl2LTI0LjIwNmMwLTEuMTI1OCAwLjkwNjE4LTIuMDMyNCAyLjAzMTktMi4wMzI0em0yLjg1NzcgNDMuNTY3YTQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzIDQuMjMxOCA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMyMyA0LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMS00LjIzMjMtNC4yMzIzIDQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzLTQuMjMxOHptNTMuNDMxIDBhNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMjMgNC4yMzE4IDQuMjMyMiA0LjIzMjIgMCAwIDEtNC4yMzIzIDQuMjMyMyA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMxOC00LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMTgtNC4yMzE4eiIvPjxwYXRoIGQ9Im05Ni43MTcgMTI1LjQzIDMwLjA0LTI4LjI4NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMi40Ii8+PHBhdGggZD0ibTExOC43MSAxMjUuNDMgMzAuMDQtMjguMjg0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIyLjQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.51563" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="58" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE1LjQzbW0iIGhlaWdodD0iMTY5LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNS40MyAxNjkuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ2LjE5NCAtNjIuOTE1KSI+PHBhdGggZD0ibTg2Ljg5IDYyLjkxNWMtMS4xMjM3IDAtMi4wMjgzIDAuOTA0NTgtMi4wMjgzIDIuMDI4M3YxMS4zMzRoLTYuNjU3Yy0xMy42NjkgMC0yNC42NzMgMTEuMDA1LTI0LjY3MyAyNC42NzN2NzEuNTY2YzAgMTAuODExIDYuODg2OSAxOS45NSAxNi41MjkgMjMuMzAxaC0yLjU2ODhsLTIxLjI5OCAyNC4zMjF2MTIuNTg5aDE0LjgxN2wxOS40ODUtMjQuMzc3aDQ2LjgyNWwxOS40ODUgMjQuMzc3aDE0LjgxNnYtMTIuNTg5bC0yMS4yOTctMjQuMzJoLTIuNTY5NGM5LjY0Mi0zLjM1MDkgMTYuNTI5LTEyLjQ4OSAxNi41MjktMjMuMzAxdi03MS41NjZjMC0xMy42NjktMTEuMDA1LTI0LjY3My0yNC42NzMtMjQuNjczaC02LjY1NjR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU4LTIuMDI4My0yLjAyODMtMi4wMjgzaC0xMi41NTVjLTEuMTIzNyAwLTIuMDI4MyAwLjkwNDU4LTIuMDI4MyAyLjAyODN2MTEuMzM0aC00Ljg2ODR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU5LTIuMDI4My0yLjAyODMtMi4wMjgzem04Ljg0NjUgMjQuNDk5aDE2LjM0MmMxLjEyMzcgMCAyLjAyODMgMC45MDQ1OSAyLjAyODMgMi4wMjgzdjMuNTE0YzAgMS4xMjM3LTAuOTA0NTggMi4wMjgzLTIuMDI4MyAyLjAyODNoLTE2LjM0MmMtMS4xMjM3IDAtMi4wMjgzLTAuOTA0NTktMi4wMjgzLTIuMDI4M3YtMy41MTRjMC0xLjEyMzcgMC45MDQ1OS0yLjAyODMgMi4wMjgzLTIuMDI4M3ptLTE2LjU5MiAxOC4wNDloNDkuNTI2YzQuMDI5NyAwIDcuMjczNSAzLjI0MzggNy4yNzM1IDcuMjczNHYxMi42YzAgNC4wMjk2LTMuMjQzOCA3LjI3MzUtNy4yNzM1IDcuMjczNWgtNDkuNTI2Yy00LjAyOTcgMC03LjI3NC0zLjI0MzgtNy4yNzQtNy4yNzM1di0xMi42YzAtNC4wMjk2IDMuMjQ0My03LjI3MzQgNy4yNzQtNy4yNzM0em0tMi41NzA5IDY0LjIzN2E2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNTUtNi4xMzU1IDYuMTM1NCA2LjEzNTQgMCAwIDEgNi4xMzU1LTYuMTM1em01NC42NjcgMGE2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNS02LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMSA2LjEzNS02LjEzNXoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.94261" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="59" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTQ4LjUzbW0iIGhlaWdodD0iODkuNjY5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OC41MyA4OS42NjkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM3Ljc1OCAtMTE3LjU1KSI+PHBhdGggZD0ibTM3Ljc1OCAxODYuNTR2MjAuNjczaDE0OC41M3YtMjAuNjczaC0xNi45NDV2Ni43NDAyaC0zOC42MDV2LTYuNzQwMmgtMzcuNDI5djYuNzQwMmgtMzguNjA1di02Ljc0MDJ6Ii8+PHBhdGggZD0ibTU2LjUyNSAxMTcuNTUtMTcuODI0IDM3LjMwMXY3LjY4MjdsMC43MDI4IDAuNTI5MTcgMTUuMjk5IDExLjUxNmg1LjE3ZS00IDguNzI3NnY3LjM1M2gyNS40NTV2LTcuMzUzaDQ2LjI3MnY3LjM1M2gyNS40NTV2LTcuMzUzaDguNzI3NmwxNS4zLTExLjUxNiAwLjcwMjgtMC41MjkxN3YtNy42NzE5bC0xNS4wMjItMzcuMzExaC0xMTMuOHptMi42MTA3IDYuMjg3aDIxLjExN3YxOC4zMzloLTI4LjYxNGw3LjQ5NzItMTguMzM5em0yNi4yNzIgMGgyNC4wMzd2MTguMzM5aC0yNC4wMzd2LTE4LjMzOXptMjkuMTkzIDBoMjQuMDM3djE4LjMzOWgtMjQuMDM3di0xOC4zMzl6bTI5LjE5MyAwaDIxLjExN2w3LjQ5NjcgMTguMzM5aC0yOC42MTN2LTE4LjMzOXoiIHN0cm9rZS1taXRlcmxpbWl0PSIyLjEiIHN0cm9rZS13aWR0aD0iNC4xMTIxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="60" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="61" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2OC44OW1tIiBoZWlnaHQ9IjE0OC40Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjguODkgMTQ4LjQyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMC42NjIgLTgwLjU3OCkiPjxwYXRoIGQ9Im0yNS41ODQgMTUxLjVjLTIuNzI3IDAtNC45MjIyIDIuMTk1Ny00LjkyMjIgNC45MjI3djY3LjY1MmMwIDIuNzI3IDIuMTk1MiA0LjkyMjcgNC45MjIyIDQuOTIyN2gxNTkuMDVjMi43MjcgMCA0LjkyMjItMi4xOTU3IDQuOTIyMi00LjkyMjd2LTY3LjY1MmMwLTIuNzI3LTIuMTk1Mi00LjkyMjctNC45MjIyLTQuOTIyN2gtMjQuODA4YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDU2OCA5LjkyNWgtMTA3LjU0YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDYyLTkuOTI1eiIvPjxjaXJjbGUgY3g9IjEwNS4xMSIgY3k9IjE0OS40NiIgcj0iNjAuODcyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMTYuMDI1Ii8+PGc+PHBhdGggZD0ibTc5Ljk5NiAxMTUuODhjLTIuOTkgMC01LjM5NzEgMi40MDcxLTUuMzk3MSA1LjM5NzF2MjkuODk1YzAgMi45OSAyLjQwNzEgNS4zOTcxIDUuMzk3MSA1LjM5NzFoNTAuMjIzYzIuOTkgMCA1LjM5NzEtMi40MDcxIDUuMzk3MS01LjM5NzF2LTI5Ljg5NWMwLTIuOTktMi40MDcxLTUuMzk3MS01LjM5NzEtNS4zOTcxem04LjA4NTMgNS45NDloMTAuNjY2YzAuOTYxNTUgMCAxLjczNTMgMC43NzQyNiAxLjczNTMgMS43MzU4djcuNjE5N2MwIDAuOTYxNTUtMC43NzM3NSAxLjczNTMtMS43MzUzIDEuNzM1M2gtMTAuNjY2Yy0wLjk2MTU1IDAtMS43MzUzLTAuNzczNzUtMS43MzUzLTEuNzM1M3YtNy42MTk3YzAtMC45NjE1NSAwLjc3Mzc1LTEuNzM1OCAxLjczNTMtMS43MzU4em0yMy4zODcgMGgxMC42NjZjMC45NjE1NSAwIDEuNzM1OCAwLjc3NDI2IDEuNzM1OCAxLjczNTh2Ny42MTk3YzAgMC45NjE1NS0wLjc3NDI2IDEuNzM1My0xLjczNTggMS43MzUzaC0xMC42NjZjLTAuOTYxNTUgMC0xLjczNTgtMC43NzM3NS0xLjczNTgtMS43MzUzdi03LjYxOTdjMC0wLjk2MTU1IDAuNzc0MjYtMS43MzU4IDEuNzM1OC0xLjczNTh6Ii8+PHJlY3QgeD0iODEuNzIxIiB5PSIxNTIuMzciIHdpZHRoPSIxMS4zODEiIGhlaWdodD0iMTQuMDMiIHJ5PSI1LjM5NzEiLz48cmVjdCB4PSIxMTcuMTEiIHk9IjE1Mi4zNyIgd2lkdGg9IjExLjM4MSIgaGVpZ2h0PSIxNC4wMyIgcnk9IjUuMzk3MSIvPjxwYXRoIGQ9Im0xMDUuMTEgMTAwLjkyYTMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA4IDIwLjM1NSAzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODMgMi4zOTI2aDkuNTc5OGMwLjU1MDAzLTIuMzk4NyAyLjY4OTktNC4xNzc1IDUuMjYwMS00LjE3NzVoOC4wMDI2YzIuNTcwMiAwIDQuNzA5NiAxLjc3ODkgNS4yNTk2IDQuMTc3NWg1LjAyNjZjMC4yOTYwNS0yLjcwNjIgMi41NzYtNC43OTg3IDUuMzYzNS00Ljc5ODdoOC4wMDMxYzIuNzg3NSAwIDUuMDY3NCAyLjA5MjUgNS4zNjM1IDQuNzk4N2g4LjcwN2EzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODItMi4zOTI2IDMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA5LTIwLjM1NXoiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="62" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTU5LjU2bW0iIGhlaWdodD0iMTEyLjI0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1OS41NiAxMTIuMjQiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Ljk4MSAtODEuNDk3KSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48Y2lyY2xlIGN4PSI1Mi43MDEiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48Y2lyY2xlIGN4PSI3My4yNTkiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48cGF0aCBkPSJtNDAuMzk1IDEyNC40LTE1LjQxNSAyMy44MDl2MzcuMTUxaDE0LjIzMWMtMC4xMTk4OC0wLjcyNjE5LTAuMTgzNDUtMS40NzE4LTAuMTgzNDUtMi4yMzI5IDAtNy40ODIyIDYuMDI0LTEzLjUwNiAxMy41MDYtMTMuNTA2aDEwNC40NWM3LjQ4MjIgMCAxMy41MDYgNi4wMjQgMTMuNTA2IDEzLjUwNiAwIDAuNzYxMTktMC4wNjM2IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgxNC4yM3YtMzkuNTk1bC0xNC4zNzEtMjEuMzY2em0wLjkwMDcyIDUuNzc5YzEuOTUwOSAxZS0zIDYuMjkyMSAwIDYuMjkyMSAwIDEuNjUxOSAwIDIuOTgyMiAxLjMyOTggMi45ODIyIDIuOTgxN3YxMi41NmMwIDEuNjUxOS0xLjMzMDMgMi45ODE3LTIuOTgyMiAyLjk4MTdoLTEyLjY5NWMtMS42NTE5IDAtMi44NzIzLTIuNDU3NS0yLjA0NjQtMy44ODgxbDMuODA0OS02LjU5MDN6bTE4LjM1NSAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzIgMGgyNC42N2MxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yNC42N2MtMS42NTE5IDAtMi45ODE3LTEuMzI5OC0yLjk4MTctMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMyOTgtMi45ODE3IDIuOTgxNy0yLjk4MTd6bTM2LjczMyAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzMgMHM0LjM0MTMgMWUtMyA2LjI5MjEgMGw4LjQ0OTYgMTQuNjM1YzAuODI1OTYgMS40MzA2LTAuMzk0NDYgMy44ODgxLTIuMDQ2NCAzLjg4ODFoLTEyLjY5NWMtMS42NTE5IDAtMi45ODIyLTEuMzI5OC0yLjk4MjItMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMzMDMtMi45ODE3IDIuOTgyMi0yLjk4MTd6bS04MC44OTggNDIuMTAzYzMuMzAzOCAyLjQ1NzYgNS40MzY5IDYuMzkzMiA1LjQzNjkgMTAuODQ1IDAgMC43NjExOS0wLjA2MzU4IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgzNi45NDhjLTAuMTE5ODctMC43MjYxOS0wLjE4MzQ1LTEuNDcxOC0wLjE4MzQ1LTIuMjMyOSAwLTQuNDUyMSAyLjEzMzItOC4zODc3IDUuNDM2OS0xMC44NDV6IiBzdHJva2Utd2lkdGg9IjE0LjU4MiIvPjxjaXJjbGUgY3g9IjEzNi4yNiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjxjaXJjbGUgY3g9IjE1Ni44MiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjwvZz48cGF0aCBkPSJtOTAuNzQyIDExNi43OS0xMC43ODYtMTEuMTYgMjQuNjM4LTEzLjcxIDI1LjEwNiAxMy43MS05LjUxMDQgMTEuMTZjLTI3Ljc5NCAwLTYuNjg2My0xZS01IC0yOS40NDctMWUtNXoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLXdpZHRoPSI0LjI2Ii8+PHJlY3QgeD0iMTAyLjYzIiB5PSI4MS40OTciIHdpZHRoPSI0LjI2IiBoZWlnaHQ9IjExLjk2NCIgcnk9IjAiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="63" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzkuODdtbSIgaGVpZ2h0PSIxMjIuNjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNzkuODcgMTIyLjY4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wOCAtOTUuOTQ2KSI+PHBhdGggZD0ibTEwOS43OCAxMjEuMTd2NS4yZS00YTMxLjYgNi40NDU5IDAgMCAwLTEzLjU5NSAwLjYyOTQyaDAuMDAzNmExMC43MTYgMzAuMjcyIDY3LjgyOCAwIDAtMTEuNTkyIDQuNDUzIDEwLjcxNiAzMC4yNzIgNjcuODI4IDAgMC0xNC40OTcgOS4xODk2bC0xZS0zIDFlLTNhMTAuNzE2IDMwLjI3MiA2Ny44MjggMCAwLTAuMDIzMjUgMC4wMTkxdjcxLjU0OWg3LjMwNnYxMS42MTVoMTEuMjg3di0xMS42MTVoNDIuMTQ0djExLjYxNWgxMS4yODh2LTExLjYxNWg3LjMwNTV2LTM4LjkwN2gwLjA3OHYtMzIuNjRhMzkuNzA0IDE0LjU0NSAwIDAgMCAwLTUuMmUtNHYtNS4xZS00YTMwLjI3MiAxMC43MTYgMjIuMTcyIDAgMC0wLjAxNS0wLjAxMjkgMzAuMjcyIDEwLjcxNiAyMi4xNzIgMCAwLThlLTMgLTdlLTNsLTFlLTMgLTUuMmUtNGEzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTQuNDk4LTkuMTkwNiAzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTEuNTkyLTQuNDUzaDAuMDI4OWEzMS42IDYuNDQ1OSAwIDAgMC0xMy42Mi0wLjYyOTk0em0tMTcuMjQxIDkuMDExM2gzNC40ODNjMC40MjI1MSAwIDAuNzYyNzQgMC4zMzk3MSAwLjc2Mjc0IDAuNzYyMjN2My45MDMxYzAgMC40MjI1MS0wLjM0MDIzIDAuNzYyNzQtMC43NjI3NCAwLjc2Mjc0aC0zNC40ODNjLTAuNDIyNTEgMC0wLjc2Mjc0LTAuMzQwMjMtMC43NjI3NC0wLjc2Mjc0di0zLjkwMzFjMC0wLjQyMjUyIDAuMzQwMjMtMC43NjIyMyAwLjc2Mjc0LTAuNzYyMjN6bS0xMi4zNzEgMTAuODc3aDU5LjIyNWMxLjEyNTcgMCAyLjAzMTkgMC45MDY2OSAyLjAzMTkgMi4wMzI0djI0LjIwNmMwIDEuMTI1OC0wLjkwNjE4IDIuMDMxOS0yLjAzMTkgMi4wMzE5aC01OS4yMjVjLTEuMTI1NyAwLTIuMDMxOS0wLjkwNjE3LTIuMDMxOS0yLjAzMTl2LTI0LjIwNmMwLTEuMTI1OCAwLjkwNjE4LTIuMDMyNCAyLjAzMTktMi4wMzI0em0yLjg1NzcgNDMuNTY3YTQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzIDQuMjMxOCA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMyMyA0LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMS00LjIzMjMtNC4yMzIzIDQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzLTQuMjMxOHptNTMuNDMxIDBhNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMjMgNC4yMzE4IDQuMjMyMiA0LjIzMjIgMCAwIDEtNC4yMzIzIDQuMjMyMyA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMxOC00LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMTgtNC4yMzE4eiIvPjxwYXRoIGQ9Im05Ni43MTcgMTI1LjQzIDMwLjA0LTI4LjI4NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMi40Ii8+PHBhdGggZD0ibTExOC43MSAxMjUuNDMgMzAuMDQtMjguMjg0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIyLjQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.51563" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="64" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE1LjQzbW0iIGhlaWdodD0iMTY5LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNS40MyAxNjkuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ2LjE5NCAtNjIuOTE1KSI+PHBhdGggZD0ibTg2Ljg5IDYyLjkxNWMtMS4xMjM3IDAtMi4wMjgzIDAuOTA0NTgtMi4wMjgzIDIuMDI4M3YxMS4zMzRoLTYuNjU3Yy0xMy42NjkgMC0yNC42NzMgMTEuMDA1LTI0LjY3MyAyNC42NzN2NzEuNTY2YzAgMTAuODExIDYuODg2OSAxOS45NSAxNi41MjkgMjMuMzAxaC0yLjU2ODhsLTIxLjI5OCAyNC4zMjF2MTIuNTg5aDE0LjgxN2wxOS40ODUtMjQuMzc3aDQ2LjgyNWwxOS40ODUgMjQuMzc3aDE0LjgxNnYtMTIuNTg5bC0yMS4yOTctMjQuMzJoLTIuNTY5NGM5LjY0Mi0zLjM1MDkgMTYuNTI5LTEyLjQ4OSAxNi41MjktMjMuMzAxdi03MS41NjZjMC0xMy42NjktMTEuMDA1LTI0LjY3My0yNC42NzMtMjQuNjczaC02LjY1NjR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU4LTIuMDI4My0yLjAyODMtMi4wMjgzaC0xMi41NTVjLTEuMTIzNyAwLTIuMDI4MyAwLjkwNDU4LTIuMDI4MyAyLjAyODN2MTEuMzM0aC00Ljg2ODR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU5LTIuMDI4My0yLjAyODMtMi4wMjgzem04Ljg0NjUgMjQuNDk5aDE2LjM0MmMxLjEyMzcgMCAyLjAyODMgMC45MDQ1OSAyLjAyODMgMi4wMjgzdjMuNTE0YzAgMS4xMjM3LTAuOTA0NTggMi4wMjgzLTIuMDI4MyAyLjAyODNoLTE2LjM0MmMtMS4xMjM3IDAtMi4wMjgzLTAuOTA0NTktMi4wMjgzLTIuMDI4M3YtMy41MTRjMC0xLjEyMzcgMC45MDQ1OS0yLjAyODMgMi4wMjgzLTIuMDI4M3ptLTE2LjU5MiAxOC4wNDloNDkuNTI2YzQuMDI5NyAwIDcuMjczNSAzLjI0MzggNy4yNzM1IDcuMjczNHYxMi42YzAgNC4wMjk2LTMuMjQzOCA3LjI3MzUtNy4yNzM1IDcuMjczNWgtNDkuNTI2Yy00LjAyOTcgMC03LjI3NC0zLjI0MzgtNy4yNzQtNy4yNzM1di0xMi42YzAtNC4wMjk2IDMuMjQ0My03LjI3MzQgNy4yNzQtNy4yNzM0em0tMi41NzA5IDY0LjIzN2E2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNTUtNi4xMzU1IDYuMTM1NCA2LjEzNTQgMCAwIDEgNi4xMzU1LTYuMTM1em01NC42NjcgMGE2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNS02LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMSA2LjEzNS02LjEzNXoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.94261" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="65" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTQ4LjUzbW0iIGhlaWdodD0iODkuNjY5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OC41MyA4OS42NjkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM3Ljc1OCAtMTE3LjU1KSI+PHBhdGggZD0ibTM3Ljc1OCAxODYuNTR2MjAuNjczaDE0OC41M3YtMjAuNjczaC0xNi45NDV2Ni43NDAyaC0zOC42MDV2LTYuNzQwMmgtMzcuNDI5djYuNzQwMmgtMzguNjA1di02Ljc0MDJ6Ii8+PHBhdGggZD0ibTU2LjUyNSAxMTcuNTUtMTcuODI0IDM3LjMwMXY3LjY4MjdsMC43MDI4IDAuNTI5MTcgMTUuMjk5IDExLjUxNmg1LjE3ZS00IDguNzI3NnY3LjM1M2gyNS40NTV2LTcuMzUzaDQ2LjI3MnY3LjM1M2gyNS40NTV2LTcuMzUzaDguNzI3NmwxNS4zLTExLjUxNiAwLjcwMjgtMC41MjkxN3YtNy42NzE5bC0xNS4wMjItMzcuMzExaC0xMTMuOHptMi42MTA3IDYuMjg3aDIxLjExN3YxOC4zMzloLTI4LjYxNGw3LjQ5NzItMTguMzM5em0yNi4yNzIgMGgyNC4wMzd2MTguMzM5aC0yNC4wMzd2LTE4LjMzOXptMjkuMTkzIDBoMjQuMDM3djE4LjMzOWgtMjQuMDM3di0xOC4zMzl6bTI5LjE5MyAwaDIxLjExN2w3LjQ5NjcgMTguMzM5aC0yOC42MTN2LTE4LjMzOXoiIHN0cm9rZS1taXRlcmxpbWl0PSIyLjEiIHN0cm9rZS13aWR0aD0iNC4xMTIxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="66" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="67" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2OC44OW1tIiBoZWlnaHQ9IjE0OC40Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjguODkgMTQ4LjQyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMC42NjIgLTgwLjU3OCkiPjxwYXRoIGQ9Im0yNS41ODQgMTUxLjVjLTIuNzI3IDAtNC45MjIyIDIuMTk1Ny00LjkyMjIgNC45MjI3djY3LjY1MmMwIDIuNzI3IDIuMTk1MiA0LjkyMjcgNC45MjIyIDQuOTIyN2gxNTkuMDVjMi43MjcgMCA0LjkyMjItMi4xOTU3IDQuOTIyMi00LjkyMjd2LTY3LjY1MmMwLTIuNzI3LTIuMTk1Mi00LjkyMjctNC45MjIyLTQuOTIyN2gtMjQuODA4YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDU2OCA5LjkyNWgtMTA3LjU0YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDYyLTkuOTI1eiIvPjxjaXJjbGUgY3g9IjEwNS4xMSIgY3k9IjE0OS40NiIgcj0iNjAuODcyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMTYuMDI1Ii8+PGc+PHBhdGggZD0ibTc5Ljk5NiAxMTUuODhjLTIuOTkgMC01LjM5NzEgMi40MDcxLTUuMzk3MSA1LjM5NzF2MjkuODk1YzAgMi45OSAyLjQwNzEgNS4zOTcxIDUuMzk3MSA1LjM5NzFoNTAuMjIzYzIuOTkgMCA1LjM5NzEtMi40MDcxIDUuMzk3MS01LjM5NzF2LTI5Ljg5NWMwLTIuOTktMi40MDcxLTUuMzk3MS01LjM5NzEtNS4zOTcxem04LjA4NTMgNS45NDloMTAuNjY2YzAuOTYxNTUgMCAxLjczNTMgMC43NzQyNiAxLjczNTMgMS43MzU4djcuNjE5N2MwIDAuOTYxNTUtMC43NzM3NSAxLjczNTMtMS43MzUzIDEuNzM1M2gtMTAuNjY2Yy0wLjk2MTU1IDAtMS43MzUzLTAuNzczNzUtMS43MzUzLTEuNzM1M3YtNy42MTk3YzAtMC45NjE1NSAwLjc3Mzc1LTEuNzM1OCAxLjczNTMtMS43MzU4em0yMy4zODcgMGgxMC42NjZjMC45NjE1NSAwIDEuNzM1OCAwLjc3NDI2IDEuNzM1OCAxLjczNTh2Ny42MTk3YzAgMC45NjE1NS0wLjc3NDI2IDEuNzM1My0xLjczNTggMS43MzUzaC0xMC42NjZjLTAuOTYxNTUgMC0xLjczNTgtMC43NzM3NS0xLjczNTgtMS43MzUzdi03LjYxOTdjMC0wLjk2MTU1IDAuNzc0MjYtMS43MzU4IDEuNzM1OC0xLjczNTh6Ii8+PHJlY3QgeD0iODEuNzIxIiB5PSIxNTIuMzciIHdpZHRoPSIxMS4zODEiIGhlaWdodD0iMTQuMDMiIHJ5PSI1LjM5NzEiLz48cmVjdCB4PSIxMTcuMTEiIHk9IjE1Mi4zNyIgd2lkdGg9IjExLjM4MSIgaGVpZ2h0PSIxNC4wMyIgcnk9IjUuMzk3MSIvPjxwYXRoIGQ9Im0xMDUuMTEgMTAwLjkyYTMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA4IDIwLjM1NSAzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODMgMi4zOTI2aDkuNTc5OGMwLjU1MDAzLTIuMzk4NyAyLjY4OTktNC4xNzc1IDUuMjYwMS00LjE3NzVoOC4wMDI2YzIuNTcwMiAwIDQuNzA5NiAxLjc3ODkgNS4yNTk2IDQuMTc3NWg1LjAyNjZjMC4yOTYwNS0yLjcwNjIgMi41NzYtNC43OTg3IDUuMzYzNS00Ljc5ODdoOC4wMDMxYzIuNzg3NSAwIDUuMDY3NCAyLjA5MjUgNS4zNjM1IDQuNzk4N2g4LjcwN2EzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODItMi4zOTI2IDMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA5LTIwLjM1NXoiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="68" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTU5LjU2bW0iIGhlaWdodD0iMTEyLjI0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1OS41NiAxMTIuMjQiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Ljk4MSAtODEuNDk3KSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48Y2lyY2xlIGN4PSI1Mi43MDEiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48Y2lyY2xlIGN4PSI3My4yNTkiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48cGF0aCBkPSJtNDAuMzk1IDEyNC40LTE1LjQxNSAyMy44MDl2MzcuMTUxaDE0LjIzMWMtMC4xMTk4OC0wLjcyNjE5LTAuMTgzNDUtMS40NzE4LTAuMTgzNDUtMi4yMzI5IDAtNy40ODIyIDYuMDI0LTEzLjUwNiAxMy41MDYtMTMuNTA2aDEwNC40NWM3LjQ4MjIgMCAxMy41MDYgNi4wMjQgMTMuNTA2IDEzLjUwNiAwIDAuNzYxMTktMC4wNjM2IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgxNC4yM3YtMzkuNTk1bC0xNC4zNzEtMjEuMzY2em0wLjkwMDcyIDUuNzc5YzEuOTUwOSAxZS0zIDYuMjkyMSAwIDYuMjkyMSAwIDEuNjUxOSAwIDIuOTgyMiAxLjMyOTggMi45ODIyIDIuOTgxN3YxMi41NmMwIDEuNjUxOS0xLjMzMDMgMi45ODE3LTIuOTgyMiAyLjk4MTdoLTEyLjY5NWMtMS42NTE5IDAtMi44NzIzLTIuNDU3NS0yLjA0NjQtMy44ODgxbDMuODA0OS02LjU5MDN6bTE4LjM1NSAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzIgMGgyNC42N2MxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yNC42N2MtMS42NTE5IDAtMi45ODE3LTEuMzI5OC0yLjk4MTctMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMyOTgtMi45ODE3IDIuOTgxNy0yLjk4MTd6bTM2LjczMyAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzMgMHM0LjM0MTMgMWUtMyA2LjI5MjEgMGw4LjQ0OTYgMTQuNjM1YzAuODI1OTYgMS40MzA2LTAuMzk0NDYgMy44ODgxLTIuMDQ2NCAzLjg4ODFoLTEyLjY5NWMtMS42NTE5IDAtMi45ODIyLTEuMzI5OC0yLjk4MjItMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMzMDMtMi45ODE3IDIuOTgyMi0yLjk4MTd6bS04MC44OTggNDIuMTAzYzMuMzAzOCAyLjQ1NzYgNS40MzY5IDYuMzkzMiA1LjQzNjkgMTAuODQ1IDAgMC43NjExOS0wLjA2MzU4IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgzNi45NDhjLTAuMTE5ODctMC43MjYxOS0wLjE4MzQ1LTEuNDcxOC0wLjE4MzQ1LTIuMjMyOSAwLTQuNDUyMSAyLjEzMzItOC4zODc3IDUuNDM2OS0xMC44NDV6IiBzdHJva2Utd2lkdGg9IjE0LjU4MiIvPjxjaXJjbGUgY3g9IjEzNi4yNiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjxjaXJjbGUgY3g9IjE1Ni44MiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjwvZz48cGF0aCBkPSJtOTAuNzQyIDExNi43OS0xMC43ODYtMTEuMTYgMjQuNjM4LTEzLjcxIDI1LjEwNiAxMy43MS05LjUxMDQgMTEuMTZjLTI3Ljc5NCAwLTYuNjg2My0xZS01IC0yOS40NDctMWUtNXoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLXdpZHRoPSI0LjI2Ii8+PHJlY3QgeD0iMTAyLjYzIiB5PSI4MS40OTciIHdpZHRoPSI0LjI2IiBoZWlnaHQ9IjExLjk2NCIgcnk9IjAiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="69" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzkuODdtbSIgaGVpZ2h0PSIxMjIuNjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNzkuODcgMTIyLjY4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wOCAtOTUuOTQ2KSI+PHBhdGggZD0ibTEwOS43OCAxMjEuMTd2NS4yZS00YTMxLjYgNi40NDU5IDAgMCAwLTEzLjU5NSAwLjYyOTQyaDAuMDAzNmExMC43MTYgMzAuMjcyIDY3LjgyOCAwIDAtMTEuNTkyIDQuNDUzIDEwLjcxNiAzMC4yNzIgNjcuODI4IDAgMC0xNC40OTcgOS4xODk2bC0xZS0zIDFlLTNhMTAuNzE2IDMwLjI3MiA2Ny44MjggMCAwLTAuMDIzMjUgMC4wMTkxdjcxLjU0OWg3LjMwNnYxMS42MTVoMTEuMjg3di0xMS42MTVoNDIuMTQ0djExLjYxNWgxMS4yODh2LTExLjYxNWg3LjMwNTV2LTM4LjkwN2gwLjA3OHYtMzIuNjRhMzkuNzA0IDE0LjU0NSAwIDAgMCAwLTUuMmUtNHYtNS4xZS00YTMwLjI3MiAxMC43MTYgMjIuMTcyIDAgMC0wLjAxNS0wLjAxMjkgMzAuMjcyIDEwLjcxNiAyMi4xNzIgMCAwLThlLTMgLTdlLTNsLTFlLTMgLTUuMmUtNGEzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTQuNDk4LTkuMTkwNiAzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTEuNTkyLTQuNDUzaDAuMDI4OWEzMS42IDYuNDQ1OSAwIDAgMC0xMy42Mi0wLjYyOTk0em0tMTcuMjQxIDkuMDExM2gzNC40ODNjMC40MjI1MSAwIDAuNzYyNzQgMC4zMzk3MSAwLjc2Mjc0IDAuNzYyMjN2My45MDMxYzAgMC40MjI1MS0wLjM0MDIzIDAuNzYyNzQtMC43NjI3NCAwLjc2Mjc0aC0zNC40ODNjLTAuNDIyNTEgMC0wLjc2Mjc0LTAuMzQwMjMtMC43NjI3NC0wLjc2Mjc0di0zLjkwMzFjMC0wLjQyMjUyIDAuMzQwMjMtMC43NjIyMyAwLjc2Mjc0LTAuNzYyMjN6bS0xMi4zNzEgMTAuODc3aDU5LjIyNWMxLjEyNTcgMCAyLjAzMTkgMC45MDY2OSAyLjAzMTkgMi4wMzI0djI0LjIwNmMwIDEuMTI1OC0wLjkwNjE4IDIuMDMxOS0yLjAzMTkgMi4wMzE5aC01OS4yMjVjLTEuMTI1NyAwLTIuMDMxOS0wLjkwNjE3LTIuMDMxOS0yLjAzMTl2LTI0LjIwNmMwLTEuMTI1OCAwLjkwNjE4LTIuMDMyNCAyLjAzMTktMi4wMzI0em0yLjg1NzcgNDMuNTY3YTQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzIDQuMjMxOCA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMyMyA0LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMS00LjIzMjMtNC4yMzIzIDQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzLTQuMjMxOHptNTMuNDMxIDBhNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMjMgNC4yMzE4IDQuMjMyMiA0LjIzMjIgMCAwIDEtNC4yMzIzIDQuMjMyMyA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMxOC00LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMTgtNC4yMzE4eiIvPjxwYXRoIGQ9Im05Ni43MTcgMTI1LjQzIDMwLjA0LTI4LjI4NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMi40Ii8+PHBhdGggZD0ibTExOC43MSAxMjUuNDMgMzAuMDQtMjguMjg0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIyLjQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.51563" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE2OC44OW1tIiBoZWlnaHQ9IjE0OC40Mm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxNjguODkgMTQ4LjQyIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMC42NjIgLTgwLjU3OCkiPjxwYXRoIGQ9Im0yNS41ODQgMTUxLjVjLTIuNzI3IDAtNC45MjIyIDIuMTk1Ny00LjkyMjIgNC45MjI3djY3LjY1MmMwIDIuNzI3IDIuMTk1MiA0LjkyMjcgNC45MjIyIDQuOTIyN2gxNTkuMDVjMi43MjcgMCA0LjkyMjItMi4xOTU3IDQuOTIyMi00LjkyMjd2LTY3LjY1MmMwLTIuNzI3LTIuMTk1Mi00LjkyMjctNC45MjIyLTQuOTIyN2gtMjQuODA4YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDU2OCA5LjkyNWgtMTA3LjU0YTU0LjcxNSA1NC43MTUgMCAwIDEtMC45NDYyLTkuOTI1eiIvPjxjaXJjbGUgY3g9IjEwNS4xMSIgY3k9IjE0OS40NiIgcj0iNjAuODcyIiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMTYuMDI1Ii8+PGc+PHBhdGggZD0ibTc5Ljk5NiAxMTUuODhjLTIuOTkgMC01LjM5NzEgMi40MDcxLTUuMzk3MSA1LjM5NzF2MjkuODk1YzAgMi45OSAyLjQwNzEgNS4zOTcxIDUuMzk3MSA1LjM5NzFoNTAuMjIzYzIuOTkgMCA1LjM5NzEtMi40MDcxIDUuMzk3MS01LjM5NzF2LTI5Ljg5NWMwLTIuOTktMi40MDcxLTUuMzk3MS01LjM5NzEtNS4zOTcxem04LjA4NTMgNS45NDloMTAuNjY2YzAuOTYxNTUgMCAxLjczNTMgMC43NzQyNiAxLjczNTMgMS43MzU4djcuNjE5N2MwIDAuOTYxNTUtMC43NzM3NSAxLjczNTMtMS43MzUzIDEuNzM1M2gtMTAuNjY2Yy0wLjk2MTU1IDAtMS43MzUzLTAuNzczNzUtMS43MzUzLTEuNzM1M3YtNy42MTk3YzAtMC45NjE1NSAwLjc3Mzc1LTEuNzM1OCAxLjczNTMtMS43MzU4em0yMy4zODcgMGgxMC42NjZjMC45NjE1NSAwIDEuNzM1OCAwLjc3NDI2IDEuNzM1OCAxLjczNTh2Ny42MTk3YzAgMC45NjE1NS0wLjc3NDI2IDEuNzM1My0xLjczNTggMS43MzUzaC0xMC42NjZjLTAuOTYxNTUgMC0xLjczNTgtMC43NzM3NS0xLjczNTgtMS43MzUzdi03LjYxOTdjMC0wLjk2MTU1IDAuNzc0MjYtMS43MzU4IDEuNzM1OC0xLjczNTh6Ii8+PHJlY3QgeD0iODEuNzIxIiB5PSIxNTIuMzciIHdpZHRoPSIxMS4zODEiIGhlaWdodD0iMTQuMDMiIHJ5PSI1LjM5NzEiLz48cmVjdCB4PSIxMTcuMTEiIHk9IjE1Mi4zNyIgd2lkdGg9IjExLjM4MSIgaGVpZ2h0PSIxNC4wMyIgcnk9IjUuMzk3MSIvPjxwYXRoIGQ9Im0xMDUuMTEgMTAwLjkyYTMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA4IDIwLjM1NSAzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODMgMi4zOTI2aDkuNTc5OGMwLjU1MDAzLTIuMzk4NyAyLjY4OTktNC4xNzc1IDUuMjYwMS00LjE3NzVoOC4wMDI2YzIuNTcwMiAwIDQuNzA5NiAxLjc3ODkgNS4yNTk2IDQuMTc3NWg1LjAyNjZjMC4yOTYwNS0yLjcwNjIgMi41NzYtNC43OTg3IDUuMzYzNS00Ljc5ODdoOC4wMDMxYzIuNzg3NSAwIDUuMDY3NCAyLjA5MjUgNS4zNjM1IDQuNzk4N2g4LjcwN2EzMC41MDkgMjAuMzU2IDAgMCAwIDAuMjI1ODItMi4zOTI2IDMwLjUwOSAyMC4zNTYgMCAwIDAtMzAuNTA5LTIwLjM1NXoiLz48L2c+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="70" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTE1LjQzbW0iIGhlaWdodD0iMTY5LjgxbW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDExNS40MyAxNjkuODEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ2LjE5NCAtNjIuOTE1KSI+PHBhdGggZD0ibTg2Ljg5IDYyLjkxNWMtMS4xMjM3IDAtMi4wMjgzIDAuOTA0NTgtMi4wMjgzIDIuMDI4M3YxMS4zMzRoLTYuNjU3Yy0xMy42NjkgMC0yNC42NzMgMTEuMDA1LTI0LjY3MyAyNC42NzN2NzEuNTY2YzAgMTAuODExIDYuODg2OSAxOS45NSAxNi41MjkgMjMuMzAxaC0yLjU2ODhsLTIxLjI5OCAyNC4zMjF2MTIuNTg5aDE0LjgxN2wxOS40ODUtMjQuMzc3aDQ2LjgyNWwxOS40ODUgMjQuMzc3aDE0LjgxNnYtMTIuNTg5bC0yMS4yOTctMjQuMzJoLTIuNTY5NGM5LjY0Mi0zLjM1MDkgMTYuNTI5LTEyLjQ4OSAxNi41MjktMjMuMzAxdi03MS41NjZjMC0xMy42NjktMTEuMDA1LTI0LjY3My0yNC42NzMtMjQuNjczaC02LjY1NjR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU4LTIuMDI4My0yLjAyODMtMi4wMjgzaC0xMi41NTVjLTEuMTIzNyAwLTIuMDI4MyAwLjkwNDU4LTIuMDI4MyAyLjAyODN2MTEuMzM0aC00Ljg2ODR2LTExLjMzNGMwLTEuMTIzNy0wLjkwNDU5LTIuMDI4My0yLjAyODMtMi4wMjgzem04Ljg0NjUgMjQuNDk5aDE2LjM0MmMxLjEyMzcgMCAyLjAyODMgMC45MDQ1OSAyLjAyODMgMi4wMjgzdjMuNTE0YzAgMS4xMjM3LTAuOTA0NTggMi4wMjgzLTIuMDI4MyAyLjAyODNoLTE2LjM0MmMtMS4xMjM3IDAtMi4wMjgzLTAuOTA0NTktMi4wMjgzLTIuMDI4M3YtMy41MTRjMC0xLjEyMzcgMC45MDQ1OS0yLjAyODMgMi4wMjgzLTIuMDI4M3ptLTE2LjU5MiAxOC4wNDloNDkuNTI2YzQuMDI5NyAwIDcuMjczNSAzLjI0MzggNy4yNzM1IDcuMjczNHYxMi42YzAgNC4wMjk2LTMuMjQzOCA3LjI3MzUtNy4yNzM1IDcuMjczNWgtNDkuNTI2Yy00LjAyOTcgMC03LjI3NC0zLjI0MzgtNy4yNzQtNy4yNzM1di0xMi42YzAtNC4wMjk2IDMuMjQ0My03LjI3MzQgNy4yNzQtNy4yNzM0em0tMi41NzA5IDY0LjIzN2E2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNTUtNi4xMzU1IDYuMTM1NCA2LjEzNTQgMCAwIDEgNi4xMzU1LTYuMTM1em01NC42NjcgMGE2LjEzNTQgNi4xMzU0IDAgMCAxIDYuMTM1NSA2LjEzNSA2LjEzNTQgNi4xMzU0IDAgMCAxLTYuMTM1NSA2LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMS02LjEzNS02LjEzNTUgNi4xMzU0IDYuMTM1NCAwIDAgMSA2LjEzNS02LjEzNXoiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.94261" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="71" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTQ4LjUzbW0iIGhlaWdodD0iODkuNjY5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE0OC41MyA4OS42NjkiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM3Ljc1OCAtMTE3LjU1KSI+PHBhdGggZD0ibTM3Ljc1OCAxODYuNTR2MjAuNjczaDE0OC41M3YtMjAuNjczaC0xNi45NDV2Ni43NDAyaC0zOC42MDV2LTYuNzQwMmgtMzcuNDI5djYuNzQwMmgtMzguNjA1di02Ljc0MDJ6Ii8+PHBhdGggZD0ibTU2LjUyNSAxMTcuNTUtMTcuODI0IDM3LjMwMXY3LjY4MjdsMC43MDI4IDAuNTI5MTcgMTUuMjk5IDExLjUxNmg1LjE3ZS00IDguNzI3NnY3LjM1M2gyNS40NTV2LTcuMzUzaDQ2LjI3MnY3LjM1M2gyNS40NTV2LTcuMzUzaDguNzI3NmwxNS4zLTExLjUxNiAwLjcwMjgtMC41MjkxN3YtNy42NzE5bC0xNS4wMjItMzcuMzExaC0xMTMuOHptMi42MTA3IDYuMjg3aDIxLjExN3YxOC4zMzloLTI4LjYxNGw3LjQ5NzItMTguMzM5em0yNi4yNzIgMGgyNC4wMzd2MTguMzM5aC0yNC4wMzd2LTE4LjMzOXptMjkuMTkzIDBoMjQuMDM3djE4LjMzOWgtMjQuMDM3di0xOC4zMzl6bTI5LjE5MyAwaDIxLjExN2w3LjQ5NjcgMTguMzM5aC0yOC42MTN2LTE4LjMzOXoiIHN0cm9rZS1taXRlcmxpbWl0PSIyLjEiIHN0cm9rZS13aWR0aD0iNC4xMTIxIi8+PC9nPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iMTU5LjU2bW0iIGhlaWdodD0iMTEyLjI0bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE1OS41NiAxMTIuMjQiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0Ljk4MSAtODEuNDk3KSI+PGcgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLW9wYWNpdHk9Ii41Ij48Y2lyY2xlIGN4PSI1Mi43MDEiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48Y2lyY2xlIGN4PSI3My4yNTkiIGN5PSIxODMuODYiIHI9IjkuODc3NyIgc3Ryb2tlLXdpZHRoPSIxMS40NDIiLz48cGF0aCBkPSJtNDAuMzk1IDEyNC40LTE1LjQxNSAyMy44MDl2MzcuMTUxaDE0LjIzMWMtMC4xMTk4OC0wLjcyNjE5LTAuMTgzNDUtMS40NzE4LTAuMTgzNDUtMi4yMzI5IDAtNy40ODIyIDYuMDI0LTEzLjUwNiAxMy41MDYtMTMuNTA2aDEwNC40NWM3LjQ4MjIgMCAxMy41MDYgNi4wMjQgMTMuNTA2IDEzLjUwNiAwIDAuNzYxMTktMC4wNjM2IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgxNC4yM3YtMzkuNTk1bC0xNC4zNzEtMjEuMzY2em0wLjkwMDcyIDUuNzc5YzEuOTUwOSAxZS0zIDYuMjkyMSAwIDYuMjkyMSAwIDEuNjUxOSAwIDIuOTgyMiAxLjMyOTggMi45ODIyIDIuOTgxN3YxMi41NmMwIDEuNjUxOS0xLjMzMDMgMi45ODE3LTIuOTgyMiAyLjk4MTdoLTEyLjY5NWMtMS42NTE5IDAtMi44NzIzLTIuNDU3NS0yLjA0NjQtMy44ODgxbDMuODA0OS02LjU5MDN6bTE4LjM1NSAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzIgMGgyNC42N2MxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yNC42N2MtMS42NTE5IDAtMi45ODE3LTEuMzI5OC0yLjk4MTctMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMyOTgtMi45ODE3IDIuOTgxNy0yLjk4MTd6bTM2LjczMyAwaDIwLjcwOWMxLjY1MTkgMCAyLjk4MTcgMS4zMjk4IDIuOTgxNyAyLjk4MTd2MTIuNTZjMCAxLjY1MTktMS4zMjk4IDIuOTgxNy0yLjk4MTcgMi45ODE3aC0yMC43MDljLTEuNjUxOSAwLTIuOTgxNy0xLjMyOTgtMi45ODE3LTIuOTgxN3YtMTIuNTZjMC0xLjY1MTkgMS4zMjk4LTIuOTgxNyAyLjk4MTctMi45ODE3em0zMi43NzMgMHM0LjM0MTMgMWUtMyA2LjI5MjEgMGw4LjQ0OTYgMTQuNjM1YzAuODI1OTYgMS40MzA2LTAuMzk0NDYgMy44ODgxLTIuMDQ2NCAzLjg4ODFoLTEyLjY5NWMtMS42NTE5IDAtMi45ODIyLTEuMzI5OC0yLjk4MjItMi45ODE3di0xMi41NmMwLTEuNjUxOSAxLjMzMDMtMi45ODE3IDIuOTgyMi0yLjk4MTd6bS04MC44OTggNDIuMTAzYzMuMzAzOCAyLjQ1NzYgNS40MzY5IDYuMzkzMiA1LjQzNjkgMTAuODQ1IDAgMC43NjExOS0wLjA2MzU4IDEuNTA2OC0wLjE4MzQ1IDIuMjMyOWgzNi45NDhjLTAuMTE5ODctMC43MjYxOS0wLjE4MzQ1LTEuNDcxOC0wLjE4MzQ1LTIuMjMyOSAwLTQuNDUyMSAyLjEzMzItOC4zODc3IDUuNDM2OS0xMC44NDV6IiBzdHJva2Utd2lkdGg9IjE0LjU4MiIvPjxjaXJjbGUgY3g9IjEzNi4yNiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjxjaXJjbGUgY3g9IjE1Ni44MiIgY3k9IjE4My44NiIgcj0iOS44Nzc3IiBzdHJva2Utd2lkdGg9IjExLjQ0MiIvPjwvZz48cGF0aCBkPSJtOTAuNzQyIDExNi43OS0xMC43ODYtMTEuMTYgMjQuNjM4LTEzLjcxIDI1LjEwNiAxMy43MS05LjUxMDQgMTEuMTZjLTI3Ljc5NCAwLTYuNjg2My0xZS01IC0yOS40NDctMWUtNXoiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjIuMSIgc3Ryb2tlLXdpZHRoPSI0LjI2Ii8+PHJlY3QgeD0iMTAyLjYzIiB5PSI4MS40OTciIHdpZHRoPSI0LjI2IiBoZWlnaHQ9IjExLjk2NCIgcnk9IjAiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PHN2ZyB3aWR0aD0iNzkuODdtbSIgaGVpZ2h0PSIxMjIuNjhtbSIgdmVyc2lvbj0iMS4xIiB2aWV3Qm94PSIwIDAgNzkuODcgMTIyLjY4IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wOCAtOTUuOTQ2KSI+PHBhdGggZD0ibTEwOS43OCAxMjEuMTd2NS4yZS00YTMxLjYgNi40NDU5IDAgMCAwLTEzLjU5NSAwLjYyOTQyaDAuMDAzNmExMC43MTYgMzAuMjcyIDY3LjgyOCAwIDAtMTEuNTkyIDQuNDUzIDEwLjcxNiAzMC4yNzIgNjcuODI4IDAgMC0xNC40OTcgOS4xODk2bC0xZS0zIDFlLTNhMTAuNzE2IDMwLjI3MiA2Ny44MjggMCAwLTAuMDIzMjUgMC4wMTkxdjcxLjU0OWg3LjMwNnYxMS42MTVoMTEuMjg3di0xMS42MTVoNDIuMTQ0djExLjYxNWgxMS4yODh2LTExLjYxNWg3LjMwNTV2LTM4LjkwN2gwLjA3OHYtMzIuNjRhMzkuNzA0IDE0LjU0NSAwIDAgMCAwLTUuMmUtNHYtNS4xZS00YTMwLjI3MiAxMC43MTYgMjIuMTcyIDAgMC0wLjAxNS0wLjAxMjkgMzAuMjcyIDEwLjcxNiAyMi4xNzIgMCAwLThlLTMgLTdlLTNsLTFlLTMgLTUuMmUtNGEzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTQuNDk4LTkuMTkwNiAzMC4yNzIgMTAuNzE2IDIyLjE3MiAwIDAtMTEuNTkyLTQuNDUzaDAuMDI4OWEzMS42IDYuNDQ1OSAwIDAgMC0xMy42Mi0wLjYyOTk0em0tMTcuMjQxIDkuMDExM2gzNC40ODNjMC40MjI1MSAwIDAuNzYyNzQgMC4zMzk3MSAwLjc2Mjc0IDAuNzYyMjN2My45MDMxYzAgMC40MjI1MS0wLjM0MDIzIDAuNzYyNzQtMC43NjI3NCAwLjc2Mjc0aC0zNC40ODNjLTAuNDIyNTEgMC0wLjc2Mjc0LTAuMzQwMjMtMC43NjI3NC0wLjc2Mjc0di0zLjkwMzFjMC0wLjQyMjUyIDAuMzQwMjMtMC43NjIyMyAwLjc2Mjc0LTAuNzYyMjN6bS0xMi4zNzEgMTAuODc3aDU5LjIyNWMxLjEyNTcgMCAyLjAzMTkgMC45MDY2OSAyLjAzMTkgMi4wMzI0djI0LjIwNmMwIDEuMTI1OC0wLjkwNjE4IDIuMDMxOS0yLjAzMTkgMi4wMzE5aC01OS4yMjVjLTEuMTI1NyAwLTIuMDMxOS0wLjkwNjE3LTIuMDMxOS0yLjAzMTl2LTI0LjIwNmMwLTEuMTI1OCAwLjkwNjE4LTIuMDMyNCAyLjAzMTktMi4wMzI0em0yLjg1NzcgNDMuNTY3YTQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzIDQuMjMxOCA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMyMyA0LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMS00LjIzMjMtNC4yMzIzIDQuMjMyMiA0LjIzMjIgMCAwIDEgNC4yMzIzLTQuMjMxOHptNTMuNDMxIDBhNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMjMgNC4yMzE4IDQuMjMyMiA0LjIzMjIgMCAwIDEtNC4yMzIzIDQuMjMyMyA0LjIzMjIgNC4yMzIyIDAgMCAxLTQuMjMxOC00LjIzMjMgNC4yMzIyIDQuMjMyMiAwIDAgMSA0LjIzMTgtNC4yMzE4eiIvPjxwYXRoIGQ9Im05Ni43MTcgMTI1LjQzIDMwLjA0LTI4LjI4NCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1taXRlcmxpbWl0PSI0LjgiIHN0cm9rZS13aWR0aD0iMi40Ii8+PHBhdGggZD0ibTExOC43MSAxMjUuNDMgMzAuMDQtMjguMjg0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjQuOCIgc3Ryb2tlLXdpZHRoPSIyLjQiLz48L2c+PC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3.51563" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Электродепо метрополитена" value="602030801" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Трамвайное депо" value="602030802" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Троллейбусное депо" value="602030803" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Совмещенное троллейбусно-трамвайное депо" value="602030804" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Автобусный парк" value="602030805" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CAPACITY" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="DANGER_OBJ" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Объекты использования атомной энергии (в том числе ядерные установки, пункты хранения ядерных материалов и радиоактивных веществ, пункты хранения радиоактивных отходов)" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Тепловые электростанции мощностью 150 мегаватт и выше" value="10" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Подвесные канатные дороги" value="11" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасные производственные объекты I и II классов опасности, на которых получаются, используются, перерабатываются, образуются, хранятся, транспортируются, уничтожаются опасные вещества" value="12" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасные производственные объекты, на которых получаются, транспортируются, используются расплавы черных и цветных металлов, сплавы на основе этих расплавов с применением оборудования, рассчитанного на максимальное количество расплава 500 килограммов иболее" value="13" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Опасные производственные объекты, на которых ведутся горные работы (за исключением добычи общераспространенных полезных ископаемых и разработки россыпных месторождений полезных ископаемых, осуществляемых открытым способом без применения взрывных работ), работы по обогащению полезных ископаемых" value="14" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Антенно-мачтовое сооружение (АМС)" value="15" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Гидротехнические сооружения первого и второго классов, устанавливаемые в соответствии с законодательством о безопасности гидротехнических сооружений" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Сооружения связи, являющиеся особо опасными, технически сложными в соответствии с законодательством Российской Федерации в области связи" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Линии электропередачи и иные объекты электросетевого хозяйства напряжением 330 киловольт и более" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты космической инфраструктуры" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты инфраструктуры воздушного транспорта, являющиеся особо опасными, технически сложными объектами в соответствии с воздушным законодательством Российской Федерации" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты капитального строительства инфраструктуры железнодорожного транспорта общего пользования, являющиеся особо опасными, технически сложными объектами в соответствии с законодательством Российской Федерации о железнодорожном транспорте" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты инфраструктуры внеуличного транспорта" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Портовые гидротехнические сооружения, относящиеся к объектам инфраструктуры морского порта, за исключением объектов инфраструктуры морского порта, предназначенных для стоянок и обслуживания маломерных, спортивных парусных и прогулочных судов" value="9" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FUNCTION" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к ликвидации" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTROKS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTRZU" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="CAPACITY" index="6" name="Вместимость, единиц"/>
    <alias field="DANGER_OBJ" index="7" name="Критерии отнесения объекта к особо опасным и технически сложным объектам"/>
    <alias field="FUNCTION" index="8" name="Назначение объекта"/>
    <alias field="EVENT_TIME" index="9" name=""/>
    <alias field="SOURCE" index="10" name="Источник данных"/>
    <alias field="NOTE" index="11" name="Примечание"/>
    <alias field="STATUS" index="12" name="Статус объекта"/>
    <alias field="REG_STATUS" index="13" name="Значение объекта"/>
    <alias field="KADASTROKS" index="14" name="Кадастровый номер объекта капитального строительства"/>
    <alias field="KADASTRZU" index="15" name=""/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602030801'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="CAPACITY" expression="0" applyOnUpdate="0"/>
    <default field="DANGER_OBJ" expression="" applyOnUpdate="0"/>
    <default field="FUNCTION" expression="''" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
    <default field="KADASTROKS" expression="''" applyOnUpdate="0"/>
    <default field="KADASTRZU" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="CAPACITY" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="DANGER_OBJ" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FUNCTION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="2" field="KADASTROKS" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="KADASTRZU" unique_strength="0" notnull_strength="0" constraints="4"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xd;&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="CAPACITY" desc="Значение должно быть представлено положительным целым числом" exp="&quot;CAPACITY&quot; > 0"/>
    <constraint field="DANGER_OBJ" desc="" exp=""/>
    <constraint field="FUNCTION" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
    <constraint field="KADASTROKS" desc="Кадастровый номер объекта должен соответствовать формату, принятому в ЕГРН" exp="regexp_match(&quot;KADASTROKS&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$')"/>
    <constraint field="KADASTRZU" desc="Обязательно для значений атрибута &quot;STATUS&quot; 1, 3, 4" exp="if (&quot;STATUS&quot; = 1 OR &quot;STATUS&quot; = 3 OR &quot;STATUS&quot; = 4,&#xd;&#xa;&#x9;regexp_match(&quot;KADASTRZU&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$|^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1})$'),&#xd;&#xa;&#x9;length(&quot;KADASTRZU&quot;) >= 0)"/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="6" name="CAPACITY">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="12" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="7" name="DANGER_OBJ">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="8" name="FUNCTION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="10" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="11" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="14" name="KADASTROKS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="9" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Кадастровый номер земельного участка и (или) номер кадастрового квартала, в границах которого расположен объект" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (1, 3, 4)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="15" name="KADASTRZU">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="CAPACITY" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="DANGER_OBJ" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="FUNCTION" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="KADASTROKS" editable="1"/>
    <field name="KADASTRZU" editable="1"/>
    <field name="NAME" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="STATUS" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="CAPACITY"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="DANGER_OBJ"/>
    <field labelOnTop="0" name="EVENT_TIME"/>
    <field labelOnTop="1" name="FUNCTION"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="KADASTROKS"/>
    <field labelOnTop="0" name="KADASTRZU"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="0" name="NUMBER"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="STATUS"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="CAPACITY" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="DANGER_OBJ" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="FUNCTION" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="KADASTROKS" reuseLastValue="0"/>
    <field name="KADASTRZU" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
