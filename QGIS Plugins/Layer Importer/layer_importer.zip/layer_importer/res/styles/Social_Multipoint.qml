<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{504d347e-02aa-474e-a5a7-5b106c611f85}">
      <rule label="Существующие, строящиеся объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="0" key="{a0ab2255-803d-415c-a14a-db6505b7f4b8}">
        <rule label="Стационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010501'" symbol="1" key="{72bf0ee1-ed19-4095-8ce6-2891eff290b9}"/>
        <rule label="Комплексные, полустационарные и нестационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010502'" symbol="2" key="{28ff5441-e8cd-4250-9c96-ce3898b95590}"/>
        <rule label="Организации (отделения) социального обслуживания на дому" filter="&quot;CLASSID&quot; = '602010503'" symbol="3" key="{ddc6e640-216b-4cc1-b86c-4d060e2bd64f}"/>
        <rule label="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" filter="&quot;CLASSID&quot; = '602010504'" symbol="4" key="{121a2495-65e9-4db9-bb3a-e32f410ebb7f}"/>
        <rule label="Объекты молодежной политики" filter="&quot;CLASSID&quot; = '602010506'" symbol="5" key="{e9ef1b69-5281-46b1-a0d3-af1aa6020ee1}"/>
      </rule>
      <rule label="Планируемые к размещению объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="6" key="{79eb4fe0-edd9-4d5d-9f29-b32f7821a444}">
        <rule label="Стационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010501'" symbol="7" key="{794805bf-bf2f-47f4-8ced-ac61fe4a63de}"/>
        <rule label="Комплексные, полустационарные и нестационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010502'" symbol="8" key="{7cd93fa1-f5c3-410b-b220-9ea8e2cad01e}"/>
        <rule label="Организации (отделения) социального обслуживания на дому" filter="&quot;CLASSID&quot; = '602010503'" symbol="9" key="{72cefffc-afd6-4798-8b60-667303ab6d37}"/>
        <rule label="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" filter="&quot;CLASSID&quot; = '602010504'" symbol="10" key="{4c9ee1b6-2fe3-4428-a3ff-ee6f16e2c08a}"/>
        <rule label="Объекты молодежной политики" filter="&quot;CLASSID&quot; = '602010506'" symbol="11" key="{a706356d-61d9-4a71-a01b-5a9b7055d10a}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="12" key="{9ce5404a-ff01-446d-9d09-1376b2e4bb07}">
        <rule label="Стационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010501'" symbol="13" key="{0ded104a-89a4-4cc1-a01b-496bfb9d683a}"/>
        <rule label="Комплексные, полустационарные и нестационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010502'" symbol="14" key="{dc719a25-a53f-47d1-b943-07e0f9ca0a7c}"/>
        <rule label="Организации (отделения) социального обслуживания на дому" filter="&quot;CLASSID&quot; = '602010503'" symbol="15" key="{0dc32cfc-32f0-4f29-ad1f-c9f2546ae55c}"/>
        <rule label="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" filter="&quot;CLASSID&quot; = '602010504'" symbol="16" key="{5f67b58f-f233-4094-87c6-259dd7b634fb}"/>
        <rule label="Объекты молодежной политики" filter="&quot;CLASSID&quot; = '602010506'" symbol="17" key="{ece535b5-bc94-47f9-b2d2-68e90d5d62aa}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты местного значения, иного значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; IN (3, 4, 5, 6, 8)" symbol="18" key="{e6c7e4fe-f7b0-49d4-8c50-27ae822c5ad8}">
        <rule label="Стационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010501'" symbol="19" key="{3ac3bac2-38b3-4f02-ab5f-56649036d640}"/>
        <rule label="Комплексные, полустационарные и нестационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010502'" symbol="20" key="{1a15b103-ab72-4fdd-b4f0-8d60e66e67c0}"/>
        <rule label="Организации (отделения) социального обслуживания на дому" filter="&quot;CLASSID&quot; = '602010503'" symbol="21" key="{79f39def-9904-4da7-80b5-33058b5095c0}"/>
        <rule label="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" filter="&quot;CLASSID&quot; = '602010504'" symbol="22" key="{a529b028-bb69-4b0b-a65d-4d1865b9136f}"/>
        <rule label="Объекты молодежной политики" filter="&quot;CLASSID&quot; = '602010506'" symbol="23" key="{98e26f1d-74bd-4b61-bfc7-e3747d7f950a}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты регионального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 2" symbol="24" key="{62699cd9-4f83-4060-b913-53462cf20eca}">
        <rule label="Стационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010501'" symbol="25" key="{b2c39505-257e-4dd8-bdc9-6d7785247ba1}"/>
        <rule label="Комплексные, полустационарные и нестационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010502'" symbol="26" key="{d092cd07-1b97-49b9-9be8-8b4e9bdfb40c}"/>
        <rule label="Организации (отделения) социального обслуживания на дому" filter="&quot;CLASSID&quot; = '602010503'" symbol="27" key="{a7d78729-d9fc-4996-b129-8c2117f5fae3}"/>
        <rule label="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" filter="&quot;CLASSID&quot; = '602010504'" symbol="28" key="{1a12259a-8286-4de6-99e9-64b5b6e9e676}"/>
        <rule label="Объекты молодежной политики" filter="&quot;CLASSID&quot; = '602010506'" symbol="29" key="{dbe5baaa-fd23-422c-96aa-406bf9a47569}"/>
      </rule>
      <rule label="Планируемые к размещению объекты регионального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 2" symbol="30" key="{ca19d0ec-815c-4f54-9f7e-f3b4ca5417be}">
        <rule label="Стационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010501'" symbol="31" key="{444ea37a-f6a8-494a-8aa4-64f31e9750e8}"/>
        <rule label="Комплексные, полустационарные и нестационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010502'" symbol="32" key="{4268710e-981e-4981-b73d-7acccca16387}"/>
        <rule label="Организации (отделения) социального обслуживания на дому" filter="&quot;CLASSID&quot; = '602010503'" symbol="33" key="{1a2b6b2c-4806-44ea-933f-7f2e2de32519}"/>
        <rule label="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" filter="&quot;CLASSID&quot; = '602010504'" symbol="34" key="{4fb05339-8db6-4243-84e2-b5b35406dbdf}"/>
        <rule label="Объекты молодежной политики" filter="&quot;CLASSID&quot; = '602010506'" symbol="35" key="{5421baa0-df73-4920-bb4c-4bb0b21def14}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты регионального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 2" symbol="36" key="{0c928aca-2c2a-4061-90af-00b950add242}">
        <rule label="Стационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010501'" symbol="37" key="{2aa47e52-f9a3-4a40-beae-b8fb558c8b5d}"/>
        <rule label="Комплексные, полустационарные и нестационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010502'" symbol="38" key="{fd763d5f-5f25-4cbe-b382-357387b2cd18}"/>
        <rule label="Организации (отделения) социального обслуживания на дому" filter="&quot;CLASSID&quot; = '602010503'" symbol="39" key="{f291db03-b2de-4821-952b-fe76a5ebcd6d}"/>
        <rule label="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" filter="&quot;CLASSID&quot; = '602010504'" symbol="40" key="{d95cc66f-0ab6-43c3-99b6-f8f7fed2fbbb}"/>
        <rule label="Объекты молодежной политики" filter="&quot;CLASSID&quot; = '602010506'" symbol="41" key="{ba39571e-12f1-47ba-95c8-9fe280f0a439}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты регионального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 2" symbol="42" key="{4a5aae95-16ad-4aca-b398-c96b4f85d657}">
        <rule label="Стационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010501'" symbol="43" key="{c9de9042-2c6b-417a-bcb5-8f1c1b7a3080}"/>
        <rule label="Комплексные, полустационарные и нестационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010502'" symbol="44" key="{9dec4321-2e64-4c0f-ae94-7251ec86ee95}"/>
        <rule label="Организации (отделения) социального обслуживания на дому" filter="&quot;CLASSID&quot; = '602010503'" symbol="45" key="{021f6496-7892-4ca0-b179-2ef0b647f424}"/>
        <rule label="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" filter="&quot;CLASSID&quot; = '602010504'" symbol="46" key="{c1873926-dc8a-4484-a343-55803de7fb9d}"/>
        <rule label="Объекты молодежной политики" filter="&quot;CLASSID&quot; = '602010506'" symbol="47" key="{24529588-3f42-4a6f-bf3b-3adf859f4835}"/>
      </rule>
      <rule label="Существующие, строящиеся объекты федерального значения" filter="&quot;STATUS&quot; = 1 AND &quot;REG_STATUS&quot; = 1" symbol="48" key="{54212298-f902-4f15-a19c-7ff8a7c9de58}">
        <rule label="Стационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010501'" symbol="49" key="{5ea04447-82bf-4ab8-8e69-babd24ff2b2d}"/>
        <rule label="Комплексные, полустационарные и нестационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010502'" symbol="50" key="{452b3d1f-2cdd-44f6-ab77-a43cc47e3a3a}"/>
        <rule label="Организации (отделения) социального обслуживания на дому" filter="&quot;CLASSID&quot; = '602010503'" symbol="51" key="{4b42d065-4428-4f1e-8a39-d877ecd3ee61}"/>
        <rule label="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" filter="&quot;CLASSID&quot; = '602010504'" symbol="52" key="{65bce604-b686-4376-aab1-c09168ee0750}"/>
        <rule label="Объекты молодежной политики" filter="&quot;CLASSID&quot; = '602010506'" symbol="53" key="{028d13a4-40b4-4900-9833-814acba55620}"/>
      </rule>
      <rule label="Планируемые к размещению объекты федерального значения" filter="&quot;STATUS&quot; = 2 AND &quot;REG_STATUS&quot; = 1" symbol="54" key="{de03b111-0f7a-49d1-9928-0d8f37bc5b4c}">
        <rule label="Стационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010501'" symbol="55" key="{e328d483-e32d-444b-8c84-cdfc3f718f1d}"/>
        <rule label="Комплексные, полустационарные и нестационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010502'" symbol="56" key="{2ce5c9c1-7e19-4943-8392-06e278615915}"/>
        <rule label="Организации (отделения) социального обслуживания на дому" filter="&quot;CLASSID&quot; = '602010503'" symbol="57" key="{5c0a3c89-dd22-4afe-a488-ecadf5549a0e}"/>
        <rule label="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" filter="&quot;CLASSID&quot; = '602010504'" symbol="58" key="{d43a7a67-9d89-45f1-8688-f1be42a76df9}"/>
        <rule label="Объекты молодежной политики" filter="&quot;CLASSID&quot; = '602010506'" symbol="59" key="{1f8a1852-60d0-4f49-86e2-88d16f1e22d7}"/>
      </rule>
      <rule label="Планируемые к реконструкции объекты федерального значения" filter="&quot;STATUS&quot; = 3 AND &quot;REG_STATUS&quot; = 1" symbol="60" key="{7debe4b2-fc2c-46c8-b9f8-621a4bd0bfbe}">
        <rule label="Стационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010501'" symbol="61" key="{9ba2bac1-1c92-4134-8794-9f15e2ad2c30}"/>
        <rule label="Комплексные, полустационарные и нестационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010502'" symbol="62" key="{951d6116-f91c-4eb4-a1b5-8d97c9f08bad}"/>
        <rule label="Организации (отделения) социального обслуживания на дому" filter="&quot;CLASSID&quot; = '602010503'" symbol="63" key="{c8d05a1c-6fd2-41c8-96ef-6d295b18bda6}"/>
        <rule label="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" filter="&quot;CLASSID&quot; = '602010504'" symbol="64" key="{37b1a35d-6878-49a2-8591-2fee1255795a}"/>
        <rule label="Объекты молодежной политики" filter="&quot;CLASSID&quot; = '602010506'" symbol="65" key="{c6b0e472-7c37-4c62-b5ca-b16da602d142}"/>
      </rule>
      <rule label="Планируемые к ликвидации объекты федерального значения" filter="&quot;STATUS&quot; = 4 AND &quot;REG_STATUS&quot; = 1" symbol="66" key="{12749376-3bd2-40c8-910f-96eda466eb2b}">
        <rule label="Стационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010501'" symbol="67" key="{6778582a-bf21-4418-bfbe-e6880afe61f7}"/>
        <rule label="Комплексные, полустационарные и нестационарные организации социального обслуживания" filter="&quot;CLASSID&quot; = '602010502'" symbol="68" key="{8991b677-a354-4dbd-b534-48ed88dc55b4}"/>
        <rule label="Организации (отделения) социального обслуживания на дому" filter="&quot;CLASSID&quot; = '602010503'" symbol="69" key="{70727461-3ff6-47dd-87f7-cac961c84c5f}"/>
        <rule label="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" filter="&quot;CLASSID&quot; = '602010504'" symbol="70" key="{812eb8ed-ce68-47e5-9352-347905f1be8c}"/>
        <rule label="Объекты молодежной политики" filter="&quot;CLASSID&quot; = '602010506'" symbol="71" key="{7095fb17-5383-4250-930a-9d396daca293}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3NS4wMyIgaGVpZ2h0PSIyMjAuNjgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NS4wMyAyMjAuNjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0ibTQzLjM1MSAyMDUuOTV2LTE0LjczNGwtMTcuMjQyLTIyLjc0NmMtOS40ODI5LTEyLjUxLTE5LjIzNy0yNS41NTctMjEuNjc1LTI4Ljk5M2wtNC40MzM2LTYuMjQ2OCAwLjAyNTgtMzMuMTljMC4wMzE1LTQwLjQ4MyAwLjU4MzctNTUuMzY4IDIuMTczMS01OC41OCAyLjA3ODgtNC4yMDAzIDguNzgwOS02LjI1OTkgMTMuNjI1LTQuMTg3MSAzLjIzNyAxLjM4NSA1LjE2OTIgMy45NjE1IDUuOTQ5IDcuOTMyNiAwLjgxODgyIDQuMTcgMS4wNzkzIDQyLjkxOSAwLjMxODQ5IDQ3LjM3Mi0wLjQxOTM2IDIuNDU0Mi0xLjA4NzIgMi41MTQ0LTIuNTY5MiAzLjgzNjUtMi4xNDE3IDEuOTEwOC02LjcxMjggNS4zMjkzLTguMDY0NiA5LjE2ODUtMS4zMTIzIDMuNzI3Mi0wLjcyOTE0IDkuMTQzNCAwLjUyNTU3IDExLjg0MyAxLjM3MDggMi45NDkxIDEzLjcxNSAxNi40OTEgMjAuNDU3IDIyLjQ0MSA0LjIyMTEgMy43MjU2IDUuMTE2OSA0LjI3MjIgNi4xMjExIDMuNzM0NyAwLjY0NzAzLTAuMzQ2MjcgMS4xNzY0LTAuOTI5NTIgMS4xNzY0LTEuMjk2MSAwLTAuODQ3NC0zLjcwOTctNS4yMDY3LTEzLjQ3Ni0xNS44MzYtNC4yNjYxLTQuNjQzLTguNDQzMS05LjQ3MTYtOS4yODIyLTEwLjczLTIuOTU4Mi00LjQzNzItMS40NjgyLTEwLjQ5NiAzLjQzMjQtMTMuOTU4IDMuMzExNS0yLjMzOTIgOC4yMTQxLTIuNTI3MyAxMS41ODQtMC40NDQ0OCAxLjIwMyAwLjc0MzQ3IDEzLjMyNiAxMi43NTkgMjYuOTQxIDI2LjcwMmwyNC43NTQgMjUuMzV2NjcuMjk2aC00MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yNjMzMiAwIDAgLjI2MzMyIDEyLjg3OCAtOC44Njg4KSIgZmlsbD0icGFyYW0oZmlsbCkiIHN0cm9rZT0icGFyYW0ob3V0bGluZSkiIHN0cm9rZS13aWR0aD0icGFyYW0ob3V0bGluZS13aWR0aCkiPjxjaXJjbGUgY3g9IjI4My40NSIgY3k9IjEwNi4yNCIgcj0iNzIuNTYzIi8+PGcgZmlsbC1vcGFjaXR5PSJwYXJhbShmaWxsLW9wYWNpdHkpIiBzdHJva2Utb3BhY2l0eT0icGFyYW0ob3V0bGluZS1vcGFjaXR5KSI+PHBhdGggZD0ibTQ1NS42MyAzMDEuMDgtOTguMTE1LTk4LjI2OGMtOC4xMDctNy45NzQtMTcuMzM3LTEyLjc5OS0zMS4wMi0xMi43OTloLTg3LjA5NGMtMTMuNjgzIDAtMjIuMzA1IDQuOTc3LTMwLjE4MyAxMi43OTlsLTk3LjEyOCA5Ny4zMTVjLTI2LjU0NSAyNi41NDggOS4zNzUgNjAuNTI5IDM1Ljg3NyAzNC4wMjdsNTguNjYtNTkuMDQ5djU1LjM4NWgxNTIuOTV2LTU1LjY4OWw2MC4xOTggNjAuMzI0YzI0LjIzOSAyNS41MzEgNjEuMTI5LTguNzczIDM1Ljg1OC0zNC4wNDV6Ii8+PHBhdGggZD0ibTM1OS4yNiAzNTkuMjItNTcuNjQ1IDU3LjY0OSA0Mi4zMjIgNDIuMjQzLTQzLjM2NyA0My4zNjZjLTI1LjU5NCAyNS41OTcgOS43MTUgNjIuMjA1IDM2LjE4NCAzNS43MzZsNjguNTg1LTcxLjMxM2MxNC43MTktMTUuMDIxIDE4Ljc4OS00Mi43NjUgMy4wMDktNTguNTQ0LTAuMDU0LTAuMDUzLTQ5LjA4OC00OS4xMzctNDkuMDg4LTQ5LjEzN3oiLz48cGF0aCBkPSJtMjIxLjk2IDQ1OS4xMSA0Mi4zMjMtNDIuMjQzLTU3LjY0Ny01Ny42NDlzLTQ5LjAzMyA0OS4wODQtNDkuMDg2IDQ5LjEzOGMtMTUuNzggMTUuNzc5LTExLjcxIDQzLjUyMyAzLjAwOSA1OC41NDRsNjguNTg1IDcxLjMxM2MyNi40NjggMjYuNDY5IDYxLjc3Ny0xMC4xNCAzNi4xODMtMzUuNzM2eiIvPjwvZz48L2c+PHBhdGggZD0ibTEzMS44IDIwNS45NXYtMTQuNzM0bDE3LjI0Mi0yMi43NDZjOS40ODI5LTEyLjUxIDE5LjIzNy0yNS41NTcgMjEuNjc1LTI4Ljk5M2w0LjQzMzYtNi4yNDY4LTAuMDI1OC0zMy4xOWMtMC4wMzE1LTQwLjQ4My0wLjU4MzctNTUuMzY4LTIuMTczMS01OC41OC0yLjA3ODgtNC4yMDAzLTguNzgwOS02LjI1OTktMTMuNjI1LTQuMTg3MS0zLjIzNyAxLjM4NS01LjE2OTIgMy45NjE1LTUuOTQ5IDcuOTMyNi0wLjgxODgyIDQuMTctMS4wNzkzIDQyLjkxOS0wLjMxODQ5IDQ3LjM3MiAwLjQxOTM2IDIuNDU0MiAxLjA4NzIgMi41MTQ0IDIuNTY5MiAzLjgzNjUgMi4xNDE3IDEuOTEwOCA2LjcxMjggNS4zMjkzIDguMDY0NiA5LjE2ODUgMS4zMTIzIDMuNzI3MiAwLjcyOTE0IDkuMTQzNC0wLjUyNTU3IDExLjg0My0xLjM3MDggMi45NDkxLTEzLjcxNSAxNi40OTEtMjAuNDU3IDIyLjQ0MS00LjIyMTEgMy43MjU2LTUuMTE2OSA0LjI3MjItNi4xMjExIDMuNzM0Ny0wLjY0NzAzLTAuMzQ2MjctMS4xNzY0LTAuOTI5NTItMS4xNzY0LTEuMjk2MSAwLTAuODQ3NCAzLjcwOTctNS4yMDY3IDEzLjQ3Ni0xNS44MzYgNC4yNjYxLTQuNjQzIDguNDQzMS05LjQ3MTYgOS4yODIyLTEwLjczIDIuOTU4Mi00LjQzNzIgMS40NjgyLTEwLjQ5Ni0zLjQzMjQtMTMuOTU4LTMuMzExNS0yLjMzOTItOC4yMTQxLTIuNTI3My0xMS41ODQtMC40NDQ0OC0xLjIwMyAwLjc0MzQ3LTEzLjMyNiAxMi43NTktMjYuOTQxIDI2LjcwMmwtMjQuNzU0IDI1LjM1djY3LjI5Nmg0MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28295" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi44NG1tIiBoZWlnaHQ9IjY3Ljc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi44NCA2Ny43OSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDcuODA0IC04MS43ODQpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSIxODUuOTYiPjxwYXRoIGQ9Im0xMDIuODYgODEuNzg0djM4LjA0OGEyNC4yNTMgMjQuMjUzIDAgMCAxIDYuMzY5MS0wLjg3Nzk5IDI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjkxIDAuODUyMTV2LTM4LjAyMnoiLz48cGF0aCBkPSJtNDcuODA0IDEzNi44NHYxMi43MzloMzguMDQ4YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC44ODQwOC02LjM2OTMgMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg4NDA4LTYuMzY5M3ptODQuODE0IDBhMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg1ODI3IDYuMzY5MyAyNC4yNTMgMjQuMjUzIDAgMCAxLTAuODc3NjMgNi4zNjkzaDM4LjA0MXYtMTIuNzM5eiIvPjxwYXRoIGQ9Im0xMzQuNDIgODYuODMtMTkuMDExIDMyLjkyNGEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAzNSA2LjM2OTFsMTkuMDA1LTMyLjkyNHoiLz48cGF0aCBkPSJtODQuMDMyIDg2LjgzLTExLjAzNSA2LjM2OTEgMTkuMDQzIDMyLjk3NmEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAyMi02LjM4ODh6Ii8+PHBhdGggZD0ibTU5LjIxOSAxMDYuOTgtNi4zNjkxIDExLjAzNSAzMi45NTYgMTkuMDNhMjQuMjUzIDI0LjI1MyAwIDAgMSA2LjM4ODgtMTEuMDIyem03My40MjQgNDIuMzkxYTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY3IDAuMjA2MTloMC40MjM3NXoiLz48cGF0aCBkPSJtMTU5LjIzIDEwNi45OC0zMi45MjQgMTkuMDExYTI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjI5IDExLjAzNWwzMi45My0xOS4wMTF6bS03My40MjQgNDIuMzkxLTAuMzU3MDggMC4yMDYxOWgwLjQyMzc1YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY2Ni0wLjIwNjE5eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExOS4xNW1tIiBoZWlnaHQ9IjE0MC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTkuMTUgMTQwLjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4zNDIgLTY4LjU2NCkiPjxnPjxjaXJjbGUgY3g9IjE0NyIgY3k9IjEwMy43MSIgcj0iMTAuNTEiLz48cGF0aCBkPSJtMTM3LjIxIDExOS4zNWMtMS42NDQ3IDAtMi4yNTQ0IDAuMTcxMjgtMi44NTU2IDAuOTc4MDUtMC42NzMyMyAwLjkwMzM5LTAuMjU2ODggMi41OTgyLTAuMTM1MzggMy4zNzcybDQuNTIxNyAyOS4wMTdjMC4xNzU2MyAxLjEyNzItMC4yMDMzMyAyLjE2OTUtMC45MDc5NiAyLjk5NTJoMjMuMDgzYzIuNTEyNiAwIDQuOTExNS0yLjA1MTMgNC41MzU2LTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjMxLTQuNTM1Ni00LjUzNTYtNC41MzU2eiIvPjxwYXRoIGQ9Im0xNDAuNSAxNTEuNGMtMC42NjU4OCAwLTEuMzEyNSAwLjE0Mzg0LTEuODk5NiAwLjQwMDQ5bDAuMTM5NTMgMC45MjM0NmMwLjI4MDMzIDEuODUzLTAuOTgzMzQgMy40NjQ1LTIuNjg2MiA0LjE2NDFsNC4xODc5IDQ3LjQwNWMwLjIyMDkzIDIuNTAwNSAyLjAyMDggNC41MzE1IDQuNTMxIDQuNTMxNWg0LjQ2NzRjMi41MTAyIDAgNC4zMTEtMi4wMzEgNC41MzEtNC41MzE1bDQuMjU0NS00OC4zNjJjMC4yMTk5OS0yLjUwMDYtMi4wMjA4LTQuNTMxLTQuNTMxLTQuNTMxeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTY0LjgzNCA5My4xOThhMTAuNTEgMTAuNTEgMCAwIDAtMTAuNTEgMTAuNTEgMTAuNTEgMTAuNTEgMCAwIDAgOC41OTEyIDEwLjMxNWwtMC4xMzkwMS0wLjI1ODljLTMuMzE4My02LjE5NTctMS4wMDE3LTEzLjg1NSA1LjE5NC0xNy4xNzMgMS4wNTUyLTAuNTY1MTYgMi4xNTI5LTAuOTY2NDMgMy4yNjQ0LTEuMjEzNGExMC41MSAxMC41MSAwIDAgMC02LjQwMDYtMi4xNzkyeiIgc3Ryb2tlLXdpZHRoPSIuMTE0ODkiLz48cGF0aCBkPSJtNTUuMDQ2IDExOS4zNWMtMi41MTI2IDAtNC4xNTk4IDIuMDUwOC00LjUzNTYgNC41MzUxbC00LjEyOTUgMjcuMjk3Yy0wLjM3NTg2IDIuNDg0MyAyLjAyMjYgNC41MzUxIDQuNTM1MSA0LjUzNTFoMjcuODM2YzIuMTk5MSAwIDUuNTcxOS0wLjE0MDY4IDQuMjYxOS0yLjk5NjItNS4wMjYtMTAuOTU2LTE3LjI0NS0zMy4zNzEtMTcuMjQ1LTMzLjM3MXoiLz48cGF0aCBkPSJtNTguMzM3IDE1MS40aDEyLjk5NWMyLjUxMDIgMCA0Ljc1MSAyLjAzMDUgNC41MzEgNC41MzExbC00LjI1NDggNDguMzYyYy0wLjIxOTk5IDIuNTAwNi0yLjAyMDggNC41MzExLTQuNTMxIDQuNTMxMWgtNC40NjY5Yy0yLjUxMDIgMC00LjMxMDEtMi4wMzA2LTQuNTMxMS00LjUzMTFsLTQuMjczLTQ4LjM2MmMtMC4yMjA5My0yLjUwMDUgMi4wMjA5LTQuNTMxMSA0LjUzMTEtNC41MzExeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTEwMi40MiAxMTkuMzVoLTExLjg5OXY1LjUzMjdsOC44OTYyIDQuNjgyMXoiLz48Y2lyY2xlIGN4PSIxMDYuMzIiIGN5PSIxMDMuNzEiIHI9IjEwLjUxIi8+PHBhdGggZD0ibTk2LjUzMyAxMTkuMzVjLTIuNTEyNiAwLTQuMTU5MyAyLjA1MTMtNC41MzUxIDQuNTM1NmwxLjQ5MzYgOS43ODU0czAuNTAzMzcgMjIuMDQ3IDMuMzM1MiAyMi4wNDdsMjMuNDEyLTFlLTNjMi41MTI2LTEuMWUtNCA0LjkxMS0yLjA1MTMgNC41MzUxLTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjI2LTQuNTM1Ni00LjUzNTEtNC41MzU2eiIvPjxwYXRoIGQ9Im05OS44MjMgMTUxLjRoMTIuOTk1YzIuNTEwMiAwIDQuNzUxIDIuMDMwNSA0LjUzMSA0LjUzMTFsLTQuMjU0OCA0OC4zNjJjLTAuMjE5OTkgMi41MDA2LTIuMDIwOCA0LjUzMTEtNC41MzEgNC41MzExaC00LjQ2NjljLTIuNTEwMiAwLTQuMzEwMS0yLjAzMDYtNC41MzExLTQuNTMxMWwtNC4yNzMtNDguMzYyYy0wLjIyMDkzLTIuNTAwNSAyLjAyMDktNC41MzExIDQuNTMxMS00LjUzMTF6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIyLjc1MDUiLz48cmVjdCB0cmFuc2Zvcm09InJvdGF0ZSgtMjguMTczKSIgeD0iMTIuNjUxIiB5PSIxMjcuNTgiIHdpZHRoPSIxMS4yOTUiIGhlaWdodD0iNjIuMDg0IiByeT0iNC41MzExIi8+PHBhdGggZD0ibTk1LjI5MiAxNTUuOTMgMS4yODExLTEuMzk2Mi0xLjI5NjItNC41ODU4LTguMzk0NS0xNC41MjMiLz48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzLjY2MiI+PHBhdGggZD0ibTEwNi4zMiA3MC4zOTV2MTQuOTczIi8+PHBhdGggZD0ibTg1LjA2MyA3Ni4yNjUgNy40ODY3IDEyLjk2NyIvPjxwYXRoIGQ9Im0xMjcuNTggNzYuMjY1LTcuNDg2NyAxMi45NjciLz48L2c+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.58727" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3NS4wMyIgaGVpZ2h0PSIyMjAuNjgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NS4wMyAyMjAuNjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0ibTQzLjM1MSAyMDUuOTV2LTE0LjczNGwtMTcuMjQyLTIyLjc0NmMtOS40ODI5LTEyLjUxLTE5LjIzNy0yNS41NTctMjEuNjc1LTI4Ljk5M2wtNC40MzM2LTYuMjQ2OCAwLjAyNTgtMzMuMTljMC4wMzE1LTQwLjQ4MyAwLjU4MzctNTUuMzY4IDIuMTczMS01OC41OCAyLjA3ODgtNC4yMDAzIDguNzgwOS02LjI1OTkgMTMuNjI1LTQuMTg3MSAzLjIzNyAxLjM4NSA1LjE2OTIgMy45NjE1IDUuOTQ5IDcuOTMyNiAwLjgxODgyIDQuMTcgMS4wNzkzIDQyLjkxOSAwLjMxODQ5IDQ3LjM3Mi0wLjQxOTM2IDIuNDU0Mi0xLjA4NzIgMi41MTQ0LTIuNTY5MiAzLjgzNjUtMi4xNDE3IDEuOTEwOC02LjcxMjggNS4zMjkzLTguMDY0NiA5LjE2ODUtMS4zMTIzIDMuNzI3Mi0wLjcyOTE0IDkuMTQzNCAwLjUyNTU3IDExLjg0MyAxLjM3MDggMi45NDkxIDEzLjcxNSAxNi40OTEgMjAuNDU3IDIyLjQ0MSA0LjIyMTEgMy43MjU2IDUuMTE2OSA0LjI3MjIgNi4xMjExIDMuNzM0NyAwLjY0NzAzLTAuMzQ2MjcgMS4xNzY0LTAuOTI5NTIgMS4xNzY0LTEuMjk2MSAwLTAuODQ3NC0zLjcwOTctNS4yMDY3LTEzLjQ3Ni0xNS44MzYtNC4yNjYxLTQuNjQzLTguNDQzMS05LjQ3MTYtOS4yODIyLTEwLjczLTIuOTU4Mi00LjQzNzItMS40NjgyLTEwLjQ5NiAzLjQzMjQtMTMuOTU4IDMuMzExNS0yLjMzOTIgOC4yMTQxLTIuNTI3MyAxMS41ODQtMC40NDQ0OCAxLjIwMyAwLjc0MzQ3IDEzLjMyNiAxMi43NTkgMjYuOTQxIDI2LjcwMmwyNC43NTQgMjUuMzV2NjcuMjk2aC00MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yNjMzMiAwIDAgLjI2MzMyIDEyLjg3OCAtOC44Njg4KSIgZmlsbD0icGFyYW0oZmlsbCkiIHN0cm9rZT0icGFyYW0ob3V0bGluZSkiIHN0cm9rZS13aWR0aD0icGFyYW0ob3V0bGluZS13aWR0aCkiPjxjaXJjbGUgY3g9IjI4My40NSIgY3k9IjEwNi4yNCIgcj0iNzIuNTYzIi8+PGcgZmlsbC1vcGFjaXR5PSJwYXJhbShmaWxsLW9wYWNpdHkpIiBzdHJva2Utb3BhY2l0eT0icGFyYW0ob3V0bGluZS1vcGFjaXR5KSI+PHBhdGggZD0ibTQ1NS42MyAzMDEuMDgtOTguMTE1LTk4LjI2OGMtOC4xMDctNy45NzQtMTcuMzM3LTEyLjc5OS0zMS4wMi0xMi43OTloLTg3LjA5NGMtMTMuNjgzIDAtMjIuMzA1IDQuOTc3LTMwLjE4MyAxMi43OTlsLTk3LjEyOCA5Ny4zMTVjLTI2LjU0NSAyNi41NDggOS4zNzUgNjAuNTI5IDM1Ljg3NyAzNC4wMjdsNTguNjYtNTkuMDQ5djU1LjM4NWgxNTIuOTV2LTU1LjY4OWw2MC4xOTggNjAuMzI0YzI0LjIzOSAyNS41MzEgNjEuMTI5LTguNzczIDM1Ljg1OC0zNC4wNDV6Ii8+PHBhdGggZD0ibTM1OS4yNiAzNTkuMjItNTcuNjQ1IDU3LjY0OSA0Mi4zMjIgNDIuMjQzLTQzLjM2NyA0My4zNjZjLTI1LjU5NCAyNS41OTcgOS43MTUgNjIuMjA1IDM2LjE4NCAzNS43MzZsNjguNTg1LTcxLjMxM2MxNC43MTktMTUuMDIxIDE4Ljc4OS00Mi43NjUgMy4wMDktNTguNTQ0LTAuMDU0LTAuMDUzLTQ5LjA4OC00OS4xMzctNDkuMDg4LTQ5LjEzN3oiLz48cGF0aCBkPSJtMjIxLjk2IDQ1OS4xMSA0Mi4zMjMtNDIuMjQzLTU3LjY0Ny01Ny42NDlzLTQ5LjAzMyA0OS4wODQtNDkuMDg2IDQ5LjEzOGMtMTUuNzggMTUuNzc5LTExLjcxIDQzLjUyMyAzLjAwOSA1OC41NDRsNjguNTg1IDcxLjMxM2MyNi40NjggMjYuNDY5IDYxLjc3Ny0xMC4xNCAzNi4xODMtMzUuNzM2eiIvPjwvZz48L2c+PHBhdGggZD0ibTEzMS44IDIwNS45NXYtMTQuNzM0bDE3LjI0Mi0yMi43NDZjOS40ODI5LTEyLjUxIDE5LjIzNy0yNS41NTcgMjEuNjc1LTI4Ljk5M2w0LjQzMzYtNi4yNDY4LTAuMDI1OC0zMy4xOWMtMC4wMzE1LTQwLjQ4My0wLjU4MzctNTUuMzY4LTIuMTczMS01OC41OC0yLjA3ODgtNC4yMDAzLTguNzgwOS02LjI1OTktMTMuNjI1LTQuMTg3MS0zLjIzNyAxLjM4NS01LjE2OTIgMy45NjE1LTUuOTQ5IDcuOTMyNi0wLjgxODgyIDQuMTctMS4wNzkzIDQyLjkxOS0wLjMxODQ5IDQ3LjM3MiAwLjQxOTM2IDIuNDU0MiAxLjA4NzIgMi41MTQ0IDIuNTY5MiAzLjgzNjUgMi4xNDE3IDEuOTEwOCA2LjcxMjggNS4zMjkzIDguMDY0NiA5LjE2ODUgMS4zMTIzIDMuNzI3MiAwLjcyOTE0IDkuMTQzNC0wLjUyNTU3IDExLjg0My0xLjM3MDggMi45NDkxLTEzLjcxNSAxNi40OTEtMjAuNDU3IDIyLjQ0MS00LjIyMTEgMy43MjU2LTUuMTE2OSA0LjI3MjItNi4xMjExIDMuNzM0Ny0wLjY0NzAzLTAuMzQ2MjctMS4xNzY0LTAuOTI5NTItMS4xNzY0LTEuMjk2MSAwLTAuODQ3NCAzLjcwOTctNS4yMDY3IDEzLjQ3Ni0xNS44MzYgNC4yNjYxLTQuNjQzIDguNDQzMS05LjQ3MTYgOS4yODIyLTEwLjczIDIuOTU4Mi00LjQzNzIgMS40NjgyLTEwLjQ5Ni0zLjQzMjQtMTMuOTU4LTMuMzExNS0yLjMzOTItOC4yMTQxLTIuNTI3My0xMS41ODQtMC40NDQ0OC0xLjIwMyAwLjc0MzQ3LTEzLjMyNiAxMi43NTktMjYuOTQxIDI2LjcwMmwtMjQuNzU0IDI1LjM1djY3LjI5Nmg0MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28295" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjM3LjE3OCIgaGVpZ2h0PSIzNy4xNzgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDM3LjE3OCAzNy4xNzgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjg1OTM4IC0xLjExNzIpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI1Ni4yODMiPgogIDxwYXRoIGQ9Im0xNy41MjEgMS4xMTcydjExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3Ny0wLjI2NTYyIDcuMzQwNSA3LjM0MDUgMCAwIDEgMS45Mjc3IDAuMjU3ODF2LTExLjUwOHptMCAyNS42NjR2MTEuNTE0aDMuODU1NXYtMTEuNTE0YTcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3IDAuMjY1NjIgNy4zNDA1IDcuMzQwNSAwIDAgMS0xLjkyNzctMC4yNjU2MnoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSg5MCkiIGQ9Im0xNy43NzktMC44NTkzOGgzLjg1NTV2LTExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxLTEuOTI3NyAwLjI2NzU4IDcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3LTAuMjY3NTh6bTAtMjUuNjdhNy4zNDA1IDcuMzQwNSAwIDAgMSAxLjkyNzctMC4yNTk3NiA3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3NyAwLjI2NTYydi0xMS41MTRoLTMuODU1NXoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSgzMCkiIGQ9Im0yNC43NjktMTEuMjQ3LTYuMDdlLTQgMTEuNTA3YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTYzLTQuNTQ5NGUtNGwtMC4wMDExLTExLjUwNnptLTMuNjllLTQgMjUuNjUyLTIuNzVlLTQgMTEuNTI3IDMuODU2My00LjU1ZS00IDcuOTllLTQgLTExLjUxOGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU2OC0wLjAwODN6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTMwKSIgZD0ibTguOTE3OCA4LjIwMjMtMy44NTYzLTQuNTQ5ZS00IDAuMDAxMjUgMTEuNTI1YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4LTAuMDA2NnptMy42ODhlLTQgMjUuNjUyYTcuMzQwNSA3LjM0MDUgMCAwIDEtMy44NTY4IDAuMDA4M2w3Ljk4N2UtNCAxMS41MTggMy44NTQ2LTUuMjJlLTR6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTYwKSIgZD0ibS01LjQxMzcgOC4xMDc1LTMuODU2MyA0LjU0OWUtNCAtNy45ODdlLTQgMTEuNTE4YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4IDAuMDA2NnptMS41NDVlLTQgMjUuNjZhNy4zNDA1IDcuMzQwNSAwIDAgMS0zLjg1NjgtMC4wMDgzbDAuMDAxNDIgMTEuNTI2IDMuODU0NiA1LjIyZS00eiIvPgogIDxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDYwKSIgZD0ibTI0Ljg2My0yNS41OCA2LjA3ZS00IDExLjUwN2E3LjM0MDUgNy4zNDA1IDAgMCAxIDMuODU1MyAwLjAwMjFsMy42OWUtNCAtMTEuNTA4em0tMS41NWUtNCAyNS42NiA3Ljk5ZS00IDExLjUxOCAzLjg1NDYtNS4yMmUtNCA0LjRlLTQgLTExLjUyNGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU1OCAwLjAwNjU3MjZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjMzLjQ4MiIgaGVpZ2h0PSIzNy42NjMiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMzLjQ4MiAzNy42NjMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8cGF0aCBkPSJtNy43MDMxIDE0LjY0OWExMS45MDYgMTEuOTA2IDAgMCAwLTcuNzAzMSAxMS4xMDcgMTEuOTA2IDExLjkwNiAwIDAgMCAxMS45MDYgMTEuOTA2IDExLjkwNiAxMS45MDYgMCAwIDAgMTEuOTA2LTExLjkwNiAxMS45MDYgMTEuOTA2IDAgMCAwLTAuMTIxMDktMS42ODE2aC0zLjgxMjVhOC4yNzc1IDguMjc3NSAwIDAgMSAwLjE2Nzk3IDEuNjQ2NSA4LjI3NzUgOC4yNzc1IDAgMCAxLTguMjc5MyA4LjI3NzMgOC4yNzc1IDguMjc3NSAwIDAgMS04LjI3NzMtOC4yNzczIDguMjc3NSA4LjI3NzUgMCAwIDEgNC4yMTI5LTcuMTg3NXoiLz4KIDxjaXJjbGUgY3g9IjExLjIzNCIgY3k9IjMuNzUyNCIgcj0iMy43NTI0Ii8+CiA8cGF0aCBkPSJtOS43MzYyIDE1LjYxaDEzLjUzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDczNCIvPgogPHBhdGggZD0ibTEwLjI5NiA0LjY5MjR2MTYuODc0aDE0LjQ3NWw0LjA4MDggMTMuMDQ5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMy4xNzUxIi8+CiA8cmVjdCB4PSI4LjcwODQiIHk9IjIwLjE4NCIgd2lkdGg9IjMuOTQxMSIgaGVpZ2h0PSIyLjk2NzIiIHJ5PSIwIi8+CiA8cGF0aCBkPSJtMjguODUyIDM0LjYxNSAxLjUxNTItMC40NjYzMSAzLjExNDktMC45ODY5NC0wLjQ1NjI4LTEuNjE1MS00LjY3ODQgMS40NTQ3eiIvPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.60054" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi44NG1tIiBoZWlnaHQ9IjY3Ljc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi44NCA2Ny43OSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDcuODA0IC04MS43ODQpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSIxODUuOTYiPjxwYXRoIGQ9Im0xMDIuODYgODEuNzg0djM4LjA0OGEyNC4yNTMgMjQuMjUzIDAgMCAxIDYuMzY5MS0wLjg3Nzk5IDI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjkxIDAuODUyMTV2LTM4LjAyMnoiLz48cGF0aCBkPSJtNDcuODA0IDEzNi44NHYxMi43MzloMzguMDQ4YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC44ODQwOC02LjM2OTMgMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg4NDA4LTYuMzY5M3ptODQuODE0IDBhMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg1ODI3IDYuMzY5MyAyNC4yNTMgMjQuMjUzIDAgMCAxLTAuODc3NjMgNi4zNjkzaDM4LjA0MXYtMTIuNzM5eiIvPjxwYXRoIGQ9Im0xMzQuNDIgODYuODMtMTkuMDExIDMyLjkyNGEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAzNSA2LjM2OTFsMTkuMDA1LTMyLjkyNHoiLz48cGF0aCBkPSJtODQuMDMyIDg2LjgzLTExLjAzNSA2LjM2OTEgMTkuMDQzIDMyLjk3NmEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAyMi02LjM4ODh6Ii8+PHBhdGggZD0ibTU5LjIxOSAxMDYuOTgtNi4zNjkxIDExLjAzNSAzMi45NTYgMTkuMDNhMjQuMjUzIDI0LjI1MyAwIDAgMSA2LjM4ODgtMTEuMDIyem03My40MjQgNDIuMzkxYTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY3IDAuMjA2MTloMC40MjM3NXoiLz48cGF0aCBkPSJtMTU5LjIzIDEwNi45OC0zMi45MjQgMTkuMDExYTI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjI5IDExLjAzNWwzMi45My0xOS4wMTF6bS03My40MjQgNDIuMzkxLTAuMzU3MDggMC4yMDYxOWgwLjQyMzc1YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY2Ni0wLjIwNjE5eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExOS4xNW1tIiBoZWlnaHQ9IjE0MC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTkuMTUgMTQwLjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4zNDIgLTY4LjU2NCkiPjxnPjxjaXJjbGUgY3g9IjE0NyIgY3k9IjEwMy43MSIgcj0iMTAuNTEiLz48cGF0aCBkPSJtMTM3LjIxIDExOS4zNWMtMS42NDQ3IDAtMi4yNTQ0IDAuMTcxMjgtMi44NTU2IDAuOTc4MDUtMC42NzMyMyAwLjkwMzM5LTAuMjU2ODggMi41OTgyLTAuMTM1MzggMy4zNzcybDQuNTIxNyAyOS4wMTdjMC4xNzU2MyAxLjEyNzItMC4yMDMzMyAyLjE2OTUtMC45MDc5NiAyLjk5NTJoMjMuMDgzYzIuNTEyNiAwIDQuOTExNS0yLjA1MTMgNC41MzU2LTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjMxLTQuNTM1Ni00LjUzNTYtNC41MzU2eiIvPjxwYXRoIGQ9Im0xNDAuNSAxNTEuNGMtMC42NjU4OCAwLTEuMzEyNSAwLjE0Mzg0LTEuODk5NiAwLjQwMDQ5bDAuMTM5NTMgMC45MjM0NmMwLjI4MDMzIDEuODUzLTAuOTgzMzQgMy40NjQ1LTIuNjg2MiA0LjE2NDFsNC4xODc5IDQ3LjQwNWMwLjIyMDkzIDIuNTAwNSAyLjAyMDggNC41MzE1IDQuNTMxIDQuNTMxNWg0LjQ2NzRjMi41MTAyIDAgNC4zMTEtMi4wMzEgNC41MzEtNC41MzE1bDQuMjU0NS00OC4zNjJjMC4yMTk5OS0yLjUwMDYtMi4wMjA4LTQuNTMxLTQuNTMxLTQuNTMxeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTY0LjgzNCA5My4xOThhMTAuNTEgMTAuNTEgMCAwIDAtMTAuNTEgMTAuNTEgMTAuNTEgMTAuNTEgMCAwIDAgOC41OTEyIDEwLjMxNWwtMC4xMzkwMS0wLjI1ODljLTMuMzE4My02LjE5NTctMS4wMDE3LTEzLjg1NSA1LjE5NC0xNy4xNzMgMS4wNTUyLTAuNTY1MTYgMi4xNTI5LTAuOTY2NDMgMy4yNjQ0LTEuMjEzNGExMC41MSAxMC41MSAwIDAgMC02LjQwMDYtMi4xNzkyeiIgc3Ryb2tlLXdpZHRoPSIuMTE0ODkiLz48cGF0aCBkPSJtNTUuMDQ2IDExOS4zNWMtMi41MTI2IDAtNC4xNTk4IDIuMDUwOC00LjUzNTYgNC41MzUxbC00LjEyOTUgMjcuMjk3Yy0wLjM3NTg2IDIuNDg0MyAyLjAyMjYgNC41MzUxIDQuNTM1MSA0LjUzNTFoMjcuODM2YzIuMTk5MSAwIDUuNTcxOS0wLjE0MDY4IDQuMjYxOS0yLjk5NjItNS4wMjYtMTAuOTU2LTE3LjI0NS0zMy4zNzEtMTcuMjQ1LTMzLjM3MXoiLz48cGF0aCBkPSJtNTguMzM3IDE1MS40aDEyLjk5NWMyLjUxMDIgMCA0Ljc1MSAyLjAzMDUgNC41MzEgNC41MzExbC00LjI1NDggNDguMzYyYy0wLjIxOTk5IDIuNTAwNi0yLjAyMDggNC41MzExLTQuNTMxIDQuNTMxMWgtNC40NjY5Yy0yLjUxMDIgMC00LjMxMDEtMi4wMzA2LTQuNTMxMS00LjUzMTFsLTQuMjczLTQ4LjM2MmMtMC4yMjA5My0yLjUwMDUgMi4wMjA5LTQuNTMxMSA0LjUzMTEtNC41MzExeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTEwMi40MiAxMTkuMzVoLTExLjg5OXY1LjUzMjdsOC44OTYyIDQuNjgyMXoiLz48Y2lyY2xlIGN4PSIxMDYuMzIiIGN5PSIxMDMuNzEiIHI9IjEwLjUxIi8+PHBhdGggZD0ibTk2LjUzMyAxMTkuMzVjLTIuNTEyNiAwLTQuMTU5MyAyLjA1MTMtNC41MzUxIDQuNTM1NmwxLjQ5MzYgOS43ODU0czAuNTAzMzcgMjIuMDQ3IDMuMzM1MiAyMi4wNDdsMjMuNDEyLTFlLTNjMi41MTI2LTEuMWUtNCA0LjkxMS0yLjA1MTMgNC41MzUxLTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjI2LTQuNTM1Ni00LjUzNTEtNC41MzU2eiIvPjxwYXRoIGQ9Im05OS44MjMgMTUxLjRoMTIuOTk1YzIuNTEwMiAwIDQuNzUxIDIuMDMwNSA0LjUzMSA0LjUzMTFsLTQuMjU0OCA0OC4zNjJjLTAuMjE5OTkgMi41MDA2LTIuMDIwOCA0LjUzMTEtNC41MzEgNC41MzExaC00LjQ2NjljLTIuNTEwMiAwLTQuMzEwMS0yLjAzMDYtNC41MzExLTQuNTMxMWwtNC4yNzMtNDguMzYyYy0wLjIyMDkzLTIuNTAwNSAyLjAyMDktNC41MzExIDQuNTMxMS00LjUzMTF6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIyLjc1MDUiLz48cmVjdCB0cmFuc2Zvcm09InJvdGF0ZSgtMjguMTczKSIgeD0iMTIuNjUxIiB5PSIxMjcuNTgiIHdpZHRoPSIxMS4yOTUiIGhlaWdodD0iNjIuMDg0IiByeT0iNC41MzExIi8+PHBhdGggZD0ibTk1LjI5MiAxNTUuOTMgMS4yODExLTEuMzk2Mi0xLjI5NjItNC41ODU4LTguMzk0NS0xNC41MjMiLz48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzLjY2MiI+PHBhdGggZD0ibTEwNi4zMiA3MC4zOTV2MTQuOTczIi8+PHBhdGggZD0ibTg1LjA2MyA3Ni4yNjUgNy40ODY3IDEyLjk2NyIvPjxwYXRoIGQ9Im0xMjcuNTggNzYuMjY1LTcuNDg2NyAxMi45NjciLz48L2c+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.58727" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3NS4wMyIgaGVpZ2h0PSIyMjAuNjgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NS4wMyAyMjAuNjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0ibTQzLjM1MSAyMDUuOTV2LTE0LjczNGwtMTcuMjQyLTIyLjc0NmMtOS40ODI5LTEyLjUxLTE5LjIzNy0yNS41NTctMjEuNjc1LTI4Ljk5M2wtNC40MzM2LTYuMjQ2OCAwLjAyNTgtMzMuMTljMC4wMzE1LTQwLjQ4MyAwLjU4MzctNTUuMzY4IDIuMTczMS01OC41OCAyLjA3ODgtNC4yMDAzIDguNzgwOS02LjI1OTkgMTMuNjI1LTQuMTg3MSAzLjIzNyAxLjM4NSA1LjE2OTIgMy45NjE1IDUuOTQ5IDcuOTMyNiAwLjgxODgyIDQuMTcgMS4wNzkzIDQyLjkxOSAwLjMxODQ5IDQ3LjM3Mi0wLjQxOTM2IDIuNDU0Mi0xLjA4NzIgMi41MTQ0LTIuNTY5MiAzLjgzNjUtMi4xNDE3IDEuOTEwOC02LjcxMjggNS4zMjkzLTguMDY0NiA5LjE2ODUtMS4zMTIzIDMuNzI3Mi0wLjcyOTE0IDkuMTQzNCAwLjUyNTU3IDExLjg0MyAxLjM3MDggMi45NDkxIDEzLjcxNSAxNi40OTEgMjAuNDU3IDIyLjQ0MSA0LjIyMTEgMy43MjU2IDUuMTE2OSA0LjI3MjIgNi4xMjExIDMuNzM0NyAwLjY0NzAzLTAuMzQ2MjcgMS4xNzY0LTAuOTI5NTIgMS4xNzY0LTEuMjk2MSAwLTAuODQ3NC0zLjcwOTctNS4yMDY3LTEzLjQ3Ni0xNS44MzYtNC4yNjYxLTQuNjQzLTguNDQzMS05LjQ3MTYtOS4yODIyLTEwLjczLTIuOTU4Mi00LjQzNzItMS40NjgyLTEwLjQ5NiAzLjQzMjQtMTMuOTU4IDMuMzExNS0yLjMzOTIgOC4yMTQxLTIuNTI3MyAxMS41ODQtMC40NDQ0OCAxLjIwMyAwLjc0MzQ3IDEzLjMyNiAxMi43NTkgMjYuOTQxIDI2LjcwMmwyNC43NTQgMjUuMzV2NjcuMjk2aC00MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yNjMzMiAwIDAgLjI2MzMyIDEyLjg3OCAtOC44Njg4KSIgZmlsbD0icGFyYW0oZmlsbCkiIHN0cm9rZT0icGFyYW0ob3V0bGluZSkiIHN0cm9rZS13aWR0aD0icGFyYW0ob3V0bGluZS13aWR0aCkiPjxjaXJjbGUgY3g9IjI4My40NSIgY3k9IjEwNi4yNCIgcj0iNzIuNTYzIi8+PGcgZmlsbC1vcGFjaXR5PSJwYXJhbShmaWxsLW9wYWNpdHkpIiBzdHJva2Utb3BhY2l0eT0icGFyYW0ob3V0bGluZS1vcGFjaXR5KSI+PHBhdGggZD0ibTQ1NS42MyAzMDEuMDgtOTguMTE1LTk4LjI2OGMtOC4xMDctNy45NzQtMTcuMzM3LTEyLjc5OS0zMS4wMi0xMi43OTloLTg3LjA5NGMtMTMuNjgzIDAtMjIuMzA1IDQuOTc3LTMwLjE4MyAxMi43OTlsLTk3LjEyOCA5Ny4zMTVjLTI2LjU0NSAyNi41NDggOS4zNzUgNjAuNTI5IDM1Ljg3NyAzNC4wMjdsNTguNjYtNTkuMDQ5djU1LjM4NWgxNTIuOTV2LTU1LjY4OWw2MC4xOTggNjAuMzI0YzI0LjIzOSAyNS41MzEgNjEuMTI5LTguNzczIDM1Ljg1OC0zNC4wNDV6Ii8+PHBhdGggZD0ibTM1OS4yNiAzNTkuMjItNTcuNjQ1IDU3LjY0OSA0Mi4zMjIgNDIuMjQzLTQzLjM2NyA0My4zNjZjLTI1LjU5NCAyNS41OTcgOS43MTUgNjIuMjA1IDM2LjE4NCAzNS43MzZsNjguNTg1LTcxLjMxM2MxNC43MTktMTUuMDIxIDE4Ljc4OS00Mi43NjUgMy4wMDktNTguNTQ0LTAuMDU0LTAuMDUzLTQ5LjA4OC00OS4xMzctNDkuMDg4LTQ5LjEzN3oiLz48cGF0aCBkPSJtMjIxLjk2IDQ1OS4xMSA0Mi4zMjMtNDIuMjQzLTU3LjY0Ny01Ny42NDlzLTQ5LjAzMyA0OS4wODQtNDkuMDg2IDQ5LjEzOGMtMTUuNzggMTUuNzc5LTExLjcxIDQzLjUyMyAzLjAwOSA1OC41NDRsNjguNTg1IDcxLjMxM2MyNi40NjggMjYuNDY5IDYxLjc3Ny0xMC4xNCAzNi4xODMtMzUuNzM2eiIvPjwvZz48L2c+PHBhdGggZD0ibTEzMS44IDIwNS45NXYtMTQuNzM0bDE3LjI0Mi0yMi43NDZjOS40ODI5LTEyLjUxIDE5LjIzNy0yNS41NTcgMjEuNjc1LTI4Ljk5M2w0LjQzMzYtNi4yNDY4LTAuMDI1OC0zMy4xOWMtMC4wMzE1LTQwLjQ4My0wLjU4MzctNTUuMzY4LTIuMTczMS01OC41OC0yLjA3ODgtNC4yMDAzLTguNzgwOS02LjI1OTktMTMuNjI1LTQuMTg3MS0zLjIzNyAxLjM4NS01LjE2OTIgMy45NjE1LTUuOTQ5IDcuOTMyNi0wLjgxODgyIDQuMTctMS4wNzkzIDQyLjkxOS0wLjMxODQ5IDQ3LjM3MiAwLjQxOTM2IDIuNDU0MiAxLjA4NzIgMi41MTQ0IDIuNTY5MiAzLjgzNjUgMi4xNDE3IDEuOTEwOCA2LjcxMjggNS4zMjkzIDguMDY0NiA5LjE2ODUgMS4zMTIzIDMuNzI3MiAwLjcyOTE0IDkuMTQzNC0wLjUyNTU3IDExLjg0My0xLjM3MDggMi45NDkxLTEzLjcxNSAxNi40OTEtMjAuNDU3IDIyLjQ0MS00LjIyMTEgMy43MjU2LTUuMTE2OSA0LjI3MjItNi4xMjExIDMuNzM0Ny0wLjY0NzAzLTAuMzQ2MjctMS4xNzY0LTAuOTI5NTItMS4xNzY0LTEuMjk2MSAwLTAuODQ3NCAzLjcwOTctNS4yMDY3IDEzLjQ3Ni0xNS44MzYgNC4yNjYxLTQuNjQzIDguNDQzMS05LjQ3MTYgOS4yODIyLTEwLjczIDIuOTU4Mi00LjQzNzIgMS40NjgyLTEwLjQ5Ni0zLjQzMjQtMTMuOTU4LTMuMzExNS0yLjMzOTItOC4yMTQxLTIuNTI3My0xMS41ODQtMC40NDQ0OC0xLjIwMyAwLjc0MzQ3LTEzLjMyNiAxMi43NTktMjYuOTQxIDI2LjcwMmwtMjQuNzU0IDI1LjM1djY3LjI5Nmg0MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28295" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjM3LjE3OCIgaGVpZ2h0PSIzNy4xNzgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDM3LjE3OCAzNy4xNzgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjg1OTM4IC0xLjExNzIpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI1Ni4yODMiPgogIDxwYXRoIGQ9Im0xNy41MjEgMS4xMTcydjExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3Ny0wLjI2NTYyIDcuMzQwNSA3LjM0MDUgMCAwIDEgMS45Mjc3IDAuMjU3ODF2LTExLjUwOHptMCAyNS42NjR2MTEuNTE0aDMuODU1NXYtMTEuNTE0YTcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3IDAuMjY1NjIgNy4zNDA1IDcuMzQwNSAwIDAgMS0xLjkyNzctMC4yNjU2MnoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSg5MCkiIGQ9Im0xNy43NzktMC44NTkzOGgzLjg1NTV2LTExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxLTEuOTI3NyAwLjI2NzU4IDcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3LTAuMjY3NTh6bTAtMjUuNjdhNy4zNDA1IDcuMzQwNSAwIDAgMSAxLjkyNzctMC4yNTk3NiA3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3NyAwLjI2NTYydi0xMS41MTRoLTMuODU1NXoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSgzMCkiIGQ9Im0yNC43NjktMTEuMjQ3LTYuMDdlLTQgMTEuNTA3YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTYzLTQuNTQ5NGUtNGwtMC4wMDExLTExLjUwNnptLTMuNjllLTQgMjUuNjUyLTIuNzVlLTQgMTEuNTI3IDMuODU2My00LjU1ZS00IDcuOTllLTQgLTExLjUxOGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU2OC0wLjAwODN6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTMwKSIgZD0ibTguOTE3OCA4LjIwMjMtMy44NTYzLTQuNTQ5ZS00IDAuMDAxMjUgMTEuNTI1YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4LTAuMDA2NnptMy42ODhlLTQgMjUuNjUyYTcuMzQwNSA3LjM0MDUgMCAwIDEtMy44NTY4IDAuMDA4M2w3Ljk4N2UtNCAxMS41MTggMy44NTQ2LTUuMjJlLTR6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTYwKSIgZD0ibS01LjQxMzcgOC4xMDc1LTMuODU2MyA0LjU0OWUtNCAtNy45ODdlLTQgMTEuNTE4YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4IDAuMDA2NnptMS41NDVlLTQgMjUuNjZhNy4zNDA1IDcuMzQwNSAwIDAgMS0zLjg1NjgtMC4wMDgzbDAuMDAxNDIgMTEuNTI2IDMuODU0NiA1LjIyZS00eiIvPgogIDxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDYwKSIgZD0ibTI0Ljg2My0yNS41OCA2LjA3ZS00IDExLjUwN2E3LjM0MDUgNy4zNDA1IDAgMCAxIDMuODU1MyAwLjAwMjFsMy42OWUtNCAtMTEuNTA4em0tMS41NWUtNCAyNS42NiA3Ljk5ZS00IDExLjUxOCAzLjg1NDYtNS4yMmUtNCA0LjRlLTQgLTExLjUyNGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU1OCAwLjAwNjU3MjZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjM3LjE3OCIgaGVpZ2h0PSIzNy4xNzgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDM3LjE3OCAzNy4xNzgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjg1OTM4IC0xLjExNzIpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI1Ni4yODMiPgogIDxwYXRoIGQ9Im0xNy41MjEgMS4xMTcydjExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3Ny0wLjI2NTYyIDcuMzQwNSA3LjM0MDUgMCAwIDEgMS45Mjc3IDAuMjU3ODF2LTExLjUwOHptMCAyNS42NjR2MTEuNTE0aDMuODU1NXYtMTEuNTE0YTcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3IDAuMjY1NjIgNy4zNDA1IDcuMzQwNSAwIDAgMS0xLjkyNzctMC4yNjU2MnoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSg5MCkiIGQ9Im0xNy43NzktMC44NTkzOGgzLjg1NTV2LTExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxLTEuOTI3NyAwLjI2NzU4IDcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3LTAuMjY3NTh6bTAtMjUuNjdhNy4zNDA1IDcuMzQwNSAwIDAgMSAxLjkyNzctMC4yNTk3NiA3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3NyAwLjI2NTYydi0xMS41MTRoLTMuODU1NXoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSgzMCkiIGQ9Im0yNC43NjktMTEuMjQ3LTYuMDdlLTQgMTEuNTA3YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTYzLTQuNTQ5NGUtNGwtMC4wMDExLTExLjUwNnptLTMuNjllLTQgMjUuNjUyLTIuNzVlLTQgMTEuNTI3IDMuODU2My00LjU1ZS00IDcuOTllLTQgLTExLjUxOGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU2OC0wLjAwODN6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTMwKSIgZD0ibTguOTE3OCA4LjIwMjMtMy44NTYzLTQuNTQ5ZS00IDAuMDAxMjUgMTEuNTI1YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4LTAuMDA2NnptMy42ODhlLTQgMjUuNjUyYTcuMzQwNSA3LjM0MDUgMCAwIDEtMy44NTY4IDAuMDA4M2w3Ljk4N2UtNCAxMS41MTggMy44NTQ2LTUuMjJlLTR6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTYwKSIgZD0ibS01LjQxMzcgOC4xMDc1LTMuODU2MyA0LjU0OWUtNCAtNy45ODdlLTQgMTEuNTE4YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4IDAuMDA2NnptMS41NDVlLTQgMjUuNjZhNy4zNDA1IDcuMzQwNSAwIDAgMS0zLjg1NjgtMC4wMDgzbDAuMDAxNDIgMTEuNTI2IDMuODU0NiA1LjIyZS00eiIvPgogIDxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDYwKSIgZD0ibTI0Ljg2My0yNS41OCA2LjA3ZS00IDExLjUwN2E3LjM0MDUgNy4zNDA1IDAgMCAxIDMuODU1MyAwLjAwMjFsMy42OWUtNCAtMTEuNTA4em0tMS41NWUtNCAyNS42NiA3Ljk5ZS00IDExLjUxOCAzLjg1NDYtNS4yMmUtNCA0LjRlLTQgLTExLjUyNGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU1OCAwLjAwNjU3MjZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjMzLjQ4MiIgaGVpZ2h0PSIzNy42NjMiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMzLjQ4MiAzNy42NjMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8cGF0aCBkPSJtNy43MDMxIDE0LjY0OWExMS45MDYgMTEuOTA2IDAgMCAwLTcuNzAzMSAxMS4xMDcgMTEuOTA2IDExLjkwNiAwIDAgMCAxMS45MDYgMTEuOTA2IDExLjkwNiAxMS45MDYgMCAwIDAgMTEuOTA2LTExLjkwNiAxMS45MDYgMTEuOTA2IDAgMCAwLTAuMTIxMDktMS42ODE2aC0zLjgxMjVhOC4yNzc1IDguMjc3NSAwIDAgMSAwLjE2Nzk3IDEuNjQ2NSA4LjI3NzUgOC4yNzc1IDAgMCAxLTguMjc5MyA4LjI3NzMgOC4yNzc1IDguMjc3NSAwIDAgMS04LjI3NzMtOC4yNzczIDguMjc3NSA4LjI3NzUgMCAwIDEgNC4yMTI5LTcuMTg3NXoiLz4KIDxjaXJjbGUgY3g9IjExLjIzNCIgY3k9IjMuNzUyNCIgcj0iMy43NTI0Ii8+CiA8cGF0aCBkPSJtOS43MzYyIDE1LjYxaDEzLjUzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDczNCIvPgogPHBhdGggZD0ibTEwLjI5NiA0LjY5MjR2MTYuODc0aDE0LjQ3NWw0LjA4MDggMTMuMDQ5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMy4xNzUxIi8+CiA8cmVjdCB4PSI4LjcwODQiIHk9IjIwLjE4NCIgd2lkdGg9IjMuOTQxMSIgaGVpZ2h0PSIyLjk2NzIiIHJ5PSIwIi8+CiA8cGF0aCBkPSJtMjguODUyIDM0LjYxNSAxLjUxNTItMC40NjYzMSAzLjExNDktMC45ODY5NC0wLjQ1NjI4LTEuNjE1MS00LjY3ODQgMS40NTQ3eiIvPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.60054" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi44NG1tIiBoZWlnaHQ9IjY3Ljc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi44NCA2Ny43OSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDcuODA0IC04MS43ODQpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSIxODUuOTYiPjxwYXRoIGQ9Im0xMDIuODYgODEuNzg0djM4LjA0OGEyNC4yNTMgMjQuMjUzIDAgMCAxIDYuMzY5MS0wLjg3Nzk5IDI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjkxIDAuODUyMTV2LTM4LjAyMnoiLz48cGF0aCBkPSJtNDcuODA0IDEzNi44NHYxMi43MzloMzguMDQ4YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC44ODQwOC02LjM2OTMgMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg4NDA4LTYuMzY5M3ptODQuODE0IDBhMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg1ODI3IDYuMzY5MyAyNC4yNTMgMjQuMjUzIDAgMCAxLTAuODc3NjMgNi4zNjkzaDM4LjA0MXYtMTIuNzM5eiIvPjxwYXRoIGQ9Im0xMzQuNDIgODYuODMtMTkuMDExIDMyLjkyNGEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAzNSA2LjM2OTFsMTkuMDA1LTMyLjkyNHoiLz48cGF0aCBkPSJtODQuMDMyIDg2LjgzLTExLjAzNSA2LjM2OTEgMTkuMDQzIDMyLjk3NmEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAyMi02LjM4ODh6Ii8+PHBhdGggZD0ibTU5LjIxOSAxMDYuOTgtNi4zNjkxIDExLjAzNSAzMi45NTYgMTkuMDNhMjQuMjUzIDI0LjI1MyAwIDAgMSA2LjM4ODgtMTEuMDIyem03My40MjQgNDIuMzkxYTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY3IDAuMjA2MTloMC40MjM3NXoiLz48cGF0aCBkPSJtMTU5LjIzIDEwNi45OC0zMi45MjQgMTkuMDExYTI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjI5IDExLjAzNWwzMi45My0xOS4wMTF6bS03My40MjQgNDIuMzkxLTAuMzU3MDggMC4yMDYxOWgwLjQyMzc1YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY2Ni0wLjIwNjE5eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExOS4xNW1tIiBoZWlnaHQ9IjE0MC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTkuMTUgMTQwLjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4zNDIgLTY4LjU2NCkiPjxnPjxjaXJjbGUgY3g9IjE0NyIgY3k9IjEwMy43MSIgcj0iMTAuNTEiLz48cGF0aCBkPSJtMTM3LjIxIDExOS4zNWMtMS42NDQ3IDAtMi4yNTQ0IDAuMTcxMjgtMi44NTU2IDAuOTc4MDUtMC42NzMyMyAwLjkwMzM5LTAuMjU2ODggMi41OTgyLTAuMTM1MzggMy4zNzcybDQuNTIxNyAyOS4wMTdjMC4xNzU2MyAxLjEyNzItMC4yMDMzMyAyLjE2OTUtMC45MDc5NiAyLjk5NTJoMjMuMDgzYzIuNTEyNiAwIDQuOTExNS0yLjA1MTMgNC41MzU2LTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjMxLTQuNTM1Ni00LjUzNTYtNC41MzU2eiIvPjxwYXRoIGQ9Im0xNDAuNSAxNTEuNGMtMC42NjU4OCAwLTEuMzEyNSAwLjE0Mzg0LTEuODk5NiAwLjQwMDQ5bDAuMTM5NTMgMC45MjM0NmMwLjI4MDMzIDEuODUzLTAuOTgzMzQgMy40NjQ1LTIuNjg2MiA0LjE2NDFsNC4xODc5IDQ3LjQwNWMwLjIyMDkzIDIuNTAwNSAyLjAyMDggNC41MzE1IDQuNTMxIDQuNTMxNWg0LjQ2NzRjMi41MTAyIDAgNC4zMTEtMi4wMzEgNC41MzEtNC41MzE1bDQuMjU0NS00OC4zNjJjMC4yMTk5OS0yLjUwMDYtMi4wMjA4LTQuNTMxLTQuNTMxLTQuNTMxeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTY0LjgzNCA5My4xOThhMTAuNTEgMTAuNTEgMCAwIDAtMTAuNTEgMTAuNTEgMTAuNTEgMTAuNTEgMCAwIDAgOC41OTEyIDEwLjMxNWwtMC4xMzkwMS0wLjI1ODljLTMuMzE4My02LjE5NTctMS4wMDE3LTEzLjg1NSA1LjE5NC0xNy4xNzMgMS4wNTUyLTAuNTY1MTYgMi4xNTI5LTAuOTY2NDMgMy4yNjQ0LTEuMjEzNGExMC41MSAxMC41MSAwIDAgMC02LjQwMDYtMi4xNzkyeiIgc3Ryb2tlLXdpZHRoPSIuMTE0ODkiLz48cGF0aCBkPSJtNTUuMDQ2IDExOS4zNWMtMi41MTI2IDAtNC4xNTk4IDIuMDUwOC00LjUzNTYgNC41MzUxbC00LjEyOTUgMjcuMjk3Yy0wLjM3NTg2IDIuNDg0MyAyLjAyMjYgNC41MzUxIDQuNTM1MSA0LjUzNTFoMjcuODM2YzIuMTk5MSAwIDUuNTcxOS0wLjE0MDY4IDQuMjYxOS0yLjk5NjItNS4wMjYtMTAuOTU2LTE3LjI0NS0zMy4zNzEtMTcuMjQ1LTMzLjM3MXoiLz48cGF0aCBkPSJtNTguMzM3IDE1MS40aDEyLjk5NWMyLjUxMDIgMCA0Ljc1MSAyLjAzMDUgNC41MzEgNC41MzExbC00LjI1NDggNDguMzYyYy0wLjIxOTk5IDIuNTAwNi0yLjAyMDggNC41MzExLTQuNTMxIDQuNTMxMWgtNC40NjY5Yy0yLjUxMDIgMC00LjMxMDEtMi4wMzA2LTQuNTMxMS00LjUzMTFsLTQuMjczLTQ4LjM2MmMtMC4yMjA5My0yLjUwMDUgMi4wMjA5LTQuNTMxMSA0LjUzMTEtNC41MzExeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTEwMi40MiAxMTkuMzVoLTExLjg5OXY1LjUzMjdsOC44OTYyIDQuNjgyMXoiLz48Y2lyY2xlIGN4PSIxMDYuMzIiIGN5PSIxMDMuNzEiIHI9IjEwLjUxIi8+PHBhdGggZD0ibTk2LjUzMyAxMTkuMzVjLTIuNTEyNiAwLTQuMTU5MyAyLjA1MTMtNC41MzUxIDQuNTM1NmwxLjQ5MzYgOS43ODU0czAuNTAzMzcgMjIuMDQ3IDMuMzM1MiAyMi4wNDdsMjMuNDEyLTFlLTNjMi41MTI2LTEuMWUtNCA0LjkxMS0yLjA1MTMgNC41MzUxLTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjI2LTQuNTM1Ni00LjUzNTEtNC41MzU2eiIvPjxwYXRoIGQ9Im05OS44MjMgMTUxLjRoMTIuOTk1YzIuNTEwMiAwIDQuNzUxIDIuMDMwNSA0LjUzMSA0LjUzMTFsLTQuMjU0OCA0OC4zNjJjLTAuMjE5OTkgMi41MDA2LTIuMDIwOCA0LjUzMTEtNC41MzEgNC41MzExaC00LjQ2NjljLTIuNTEwMiAwLTQuMzEwMS0yLjAzMDYtNC41MzExLTQuNTMxMWwtNC4yNzMtNDguMzYyYy0wLjIyMDkzLTIuNTAwNSAyLjAyMDktNC41MzExIDQuNTMxMS00LjUzMTF6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIyLjc1MDUiLz48cmVjdCB0cmFuc2Zvcm09InJvdGF0ZSgtMjguMTczKSIgeD0iMTIuNjUxIiB5PSIxMjcuNTgiIHdpZHRoPSIxMS4yOTUiIGhlaWdodD0iNjIuMDg0IiByeT0iNC41MzExIi8+PHBhdGggZD0ibTk1LjI5MiAxNTUuOTMgMS4yODExLTEuMzk2Mi0xLjI5NjItNC41ODU4LTguMzk0NS0xNC41MjMiLz48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzLjY2MiI+PHBhdGggZD0ibTEwNi4zMiA3MC4zOTV2MTQuOTczIi8+PHBhdGggZD0ibTg1LjA2MyA3Ni4yNjUgNy40ODY3IDEyLjk2NyIvPjxwYXRoIGQ9Im0xMjcuNTggNzYuMjY1LTcuNDg2NyAxMi45NjciLz48L2c+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.58727" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.997" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3NS4wMyIgaGVpZ2h0PSIyMjAuNjgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NS4wMyAyMjAuNjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0ibTQzLjM1MSAyMDUuOTV2LTE0LjczNGwtMTcuMjQyLTIyLjc0NmMtOS40ODI5LTEyLjUxLTE5LjIzNy0yNS41NTctMjEuNjc1LTI4Ljk5M2wtNC40MzM2LTYuMjQ2OCAwLjAyNTgtMzMuMTljMC4wMzE1LTQwLjQ4MyAwLjU4MzctNTUuMzY4IDIuMTczMS01OC41OCAyLjA3ODgtNC4yMDAzIDguNzgwOS02LjI1OTkgMTMuNjI1LTQuMTg3MSAzLjIzNyAxLjM4NSA1LjE2OTIgMy45NjE1IDUuOTQ5IDcuOTMyNiAwLjgxODgyIDQuMTcgMS4wNzkzIDQyLjkxOSAwLjMxODQ5IDQ3LjM3Mi0wLjQxOTM2IDIuNDU0Mi0xLjA4NzIgMi41MTQ0LTIuNTY5MiAzLjgzNjUtMi4xNDE3IDEuOTEwOC02LjcxMjggNS4zMjkzLTguMDY0NiA5LjE2ODUtMS4zMTIzIDMuNzI3Mi0wLjcyOTE0IDkuMTQzNCAwLjUyNTU3IDExLjg0MyAxLjM3MDggMi45NDkxIDEzLjcxNSAxNi40OTEgMjAuNDU3IDIyLjQ0MSA0LjIyMTEgMy43MjU2IDUuMTE2OSA0LjI3MjIgNi4xMjExIDMuNzM0NyAwLjY0NzAzLTAuMzQ2MjcgMS4xNzY0LTAuOTI5NTIgMS4xNzY0LTEuMjk2MSAwLTAuODQ3NC0zLjcwOTctNS4yMDY3LTEzLjQ3Ni0xNS44MzYtNC4yNjYxLTQuNjQzLTguNDQzMS05LjQ3MTYtOS4yODIyLTEwLjczLTIuOTU4Mi00LjQzNzItMS40NjgyLTEwLjQ5NiAzLjQzMjQtMTMuOTU4IDMuMzExNS0yLjMzOTIgOC4yMTQxLTIuNTI3MyAxMS41ODQtMC40NDQ0OCAxLjIwMyAwLjc0MzQ3IDEzLjMyNiAxMi43NTkgMjYuOTQxIDI2LjcwMmwyNC43NTQgMjUuMzV2NjcuMjk2aC00MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yNjMzMiAwIDAgLjI2MzMyIDEyLjg3OCAtOC44Njg4KSIgZmlsbD0icGFyYW0oZmlsbCkiIHN0cm9rZT0icGFyYW0ob3V0bGluZSkiIHN0cm9rZS13aWR0aD0icGFyYW0ob3V0bGluZS13aWR0aCkiPjxjaXJjbGUgY3g9IjI4My40NSIgY3k9IjEwNi4yNCIgcj0iNzIuNTYzIi8+PGcgZmlsbC1vcGFjaXR5PSJwYXJhbShmaWxsLW9wYWNpdHkpIiBzdHJva2Utb3BhY2l0eT0icGFyYW0ob3V0bGluZS1vcGFjaXR5KSI+PHBhdGggZD0ibTQ1NS42MyAzMDEuMDgtOTguMTE1LTk4LjI2OGMtOC4xMDctNy45NzQtMTcuMzM3LTEyLjc5OS0zMS4wMi0xMi43OTloLTg3LjA5NGMtMTMuNjgzIDAtMjIuMzA1IDQuOTc3LTMwLjE4MyAxMi43OTlsLTk3LjEyOCA5Ny4zMTVjLTI2LjU0NSAyNi41NDggOS4zNzUgNjAuNTI5IDM1Ljg3NyAzNC4wMjdsNTguNjYtNTkuMDQ5djU1LjM4NWgxNTIuOTV2LTU1LjY4OWw2MC4xOTggNjAuMzI0YzI0LjIzOSAyNS41MzEgNjEuMTI5LTguNzczIDM1Ljg1OC0zNC4wNDV6Ii8+PHBhdGggZD0ibTM1OS4yNiAzNTkuMjItNTcuNjQ1IDU3LjY0OSA0Mi4zMjIgNDIuMjQzLTQzLjM2NyA0My4zNjZjLTI1LjU5NCAyNS41OTcgOS43MTUgNjIuMjA1IDM2LjE4NCAzNS43MzZsNjguNTg1LTcxLjMxM2MxNC43MTktMTUuMDIxIDE4Ljc4OS00Mi43NjUgMy4wMDktNTguNTQ0LTAuMDU0LTAuMDUzLTQ5LjA4OC00OS4xMzctNDkuMDg4LTQ5LjEzN3oiLz48cGF0aCBkPSJtMjIxLjk2IDQ1OS4xMSA0Mi4zMjMtNDIuMjQzLTU3LjY0Ny01Ny42NDlzLTQ5LjAzMyA0OS4wODQtNDkuMDg2IDQ5LjEzOGMtMTUuNzggMTUuNzc5LTExLjcxIDQzLjUyMyAzLjAwOSA1OC41NDRsNjguNTg1IDcxLjMxM2MyNi40NjggMjYuNDY5IDYxLjc3Ny0xMC4xNCAzNi4xODMtMzUuNzM2eiIvPjwvZz48L2c+PHBhdGggZD0ibTEzMS44IDIwNS45NXYtMTQuNzM0bDE3LjI0Mi0yMi43NDZjOS40ODI5LTEyLjUxIDE5LjIzNy0yNS41NTcgMjEuNjc1LTI4Ljk5M2w0LjQzMzYtNi4yNDY4LTAuMDI1OC0zMy4xOWMtMC4wMzE1LTQwLjQ4My0wLjU4MzctNTUuMzY4LTIuMTczMS01OC41OC0yLjA3ODgtNC4yMDAzLTguNzgwOS02LjI1OTktMTMuNjI1LTQuMTg3MS0zLjIzNyAxLjM4NS01LjE2OTIgMy45NjE1LTUuOTQ5IDcuOTMyNi0wLjgxODgyIDQuMTctMS4wNzkzIDQyLjkxOS0wLjMxODQ5IDQ3LjM3MiAwLjQxOTM2IDIuNDU0MiAxLjA4NzIgMi41MTQ0IDIuNTY5MiAzLjgzNjUgMi4xNDE3IDEuOTEwOCA2LjcxMjggNS4zMjkzIDguMDY0NiA5LjE2ODUgMS4zMTIzIDMuNzI3MiAwLjcyOTE0IDkuMTQzNC0wLjUyNTU3IDExLjg0My0xLjM3MDggMi45NDkxLTEzLjcxNSAxNi40OTEtMjAuNDU3IDIyLjQ0MS00LjIyMTEgMy43MjU2LTUuMTE2OSA0LjI3MjItNi4xMjExIDMuNzM0Ny0wLjY0NzAzLTAuMzQ2MjctMS4xNzY0LTAuOTI5NTItMS4xNzY0LTEuMjk2MSAwLTAuODQ3NCAzLjcwOTctNS4yMDY3IDEzLjQ3Ni0xNS44MzYgNC4yNjYxLTQuNjQzIDguNDQzMS05LjQ3MTYgOS4yODIyLTEwLjczIDIuOTU4Mi00LjQzNzIgMS40NjgyLTEwLjQ5Ni0zLjQzMjQtMTMuOTU4LTMuMzExNS0yLjMzOTItOC4yMTQxLTIuNTI3My0xMS41ODQtMC40NDQ0OC0xLjIwMyAwLjc0MzQ3LTEzLjMyNiAxMi43NTktMjYuOTQxIDI2LjcwMmwtMjQuNzU0IDI1LjM1djY3LjI5Nmg0MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28295" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjM3LjE3OCIgaGVpZ2h0PSIzNy4xNzgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDM3LjE3OCAzNy4xNzgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjg1OTM4IC0xLjExNzIpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI1Ni4yODMiPgogIDxwYXRoIGQ9Im0xNy41MjEgMS4xMTcydjExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3Ny0wLjI2NTYyIDcuMzQwNSA3LjM0MDUgMCAwIDEgMS45Mjc3IDAuMjU3ODF2LTExLjUwOHptMCAyNS42NjR2MTEuNTE0aDMuODU1NXYtMTEuNTE0YTcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3IDAuMjY1NjIgNy4zNDA1IDcuMzQwNSAwIDAgMS0xLjkyNzctMC4yNjU2MnoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSg5MCkiIGQ9Im0xNy43NzktMC44NTkzOGgzLjg1NTV2LTExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxLTEuOTI3NyAwLjI2NzU4IDcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3LTAuMjY3NTh6bTAtMjUuNjdhNy4zNDA1IDcuMzQwNSAwIDAgMSAxLjkyNzctMC4yNTk3NiA3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3NyAwLjI2NTYydi0xMS41MTRoLTMuODU1NXoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSgzMCkiIGQ9Im0yNC43NjktMTEuMjQ3LTYuMDdlLTQgMTEuNTA3YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTYzLTQuNTQ5NGUtNGwtMC4wMDExLTExLjUwNnptLTMuNjllLTQgMjUuNjUyLTIuNzVlLTQgMTEuNTI3IDMuODU2My00LjU1ZS00IDcuOTllLTQgLTExLjUxOGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU2OC0wLjAwODN6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTMwKSIgZD0ibTguOTE3OCA4LjIwMjMtMy44NTYzLTQuNTQ5ZS00IDAuMDAxMjUgMTEuNTI1YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4LTAuMDA2NnptMy42ODhlLTQgMjUuNjUyYTcuMzQwNSA3LjM0MDUgMCAwIDEtMy44NTY4IDAuMDA4M2w3Ljk4N2UtNCAxMS41MTggMy44NTQ2LTUuMjJlLTR6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTYwKSIgZD0ibS01LjQxMzcgOC4xMDc1LTMuODU2MyA0LjU0OWUtNCAtNy45ODdlLTQgMTEuNTE4YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4IDAuMDA2NnptMS41NDVlLTQgMjUuNjZhNy4zNDA1IDcuMzQwNSAwIDAgMS0zLjg1NjgtMC4wMDgzbDAuMDAxNDIgMTEuNTI2IDMuODU0NiA1LjIyZS00eiIvPgogIDxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDYwKSIgZD0ibTI0Ljg2My0yNS41OCA2LjA3ZS00IDExLjUwN2E3LjM0MDUgNy4zNDA1IDAgMCAxIDMuODU1MyAwLjAwMjFsMy42OWUtNCAtMTEuNTA4em0tMS41NWUtNCAyNS42NiA3Ljk5ZS00IDExLjUxOCAzLjg1NDYtNS4yMmUtNCA0LjRlLTQgLTExLjUyNGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU1OCAwLjAwNjU3MjZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjMzLjQ4MiIgaGVpZ2h0PSIzNy42NjMiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMzLjQ4MiAzNy42NjMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8cGF0aCBkPSJtNy43MDMxIDE0LjY0OWExMS45MDYgMTEuOTA2IDAgMCAwLTcuNzAzMSAxMS4xMDcgMTEuOTA2IDExLjkwNiAwIDAgMCAxMS45MDYgMTEuOTA2IDExLjkwNiAxMS45MDYgMCAwIDAgMTEuOTA2LTExLjkwNiAxMS45MDYgMTEuOTA2IDAgMCAwLTAuMTIxMDktMS42ODE2aC0zLjgxMjVhOC4yNzc1IDguMjc3NSAwIDAgMSAwLjE2Nzk3IDEuNjQ2NSA4LjI3NzUgOC4yNzc1IDAgMCAxLTguMjc5MyA4LjI3NzMgOC4yNzc1IDguMjc3NSAwIDAgMS04LjI3NzMtOC4yNzczIDguMjc3NSA4LjI3NzUgMCAwIDEgNC4yMTI5LTcuMTg3NXoiLz4KIDxjaXJjbGUgY3g9IjExLjIzNCIgY3k9IjMuNzUyNCIgcj0iMy43NTI0Ii8+CiA8cGF0aCBkPSJtOS43MzYyIDE1LjYxaDEzLjUzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDczNCIvPgogPHBhdGggZD0ibTEwLjI5NiA0LjY5MjR2MTYuODc0aDE0LjQ3NWw0LjA4MDggMTMuMDQ5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMy4xNzUxIi8+CiA8cmVjdCB4PSI4LjcwODQiIHk9IjIwLjE4NCIgd2lkdGg9IjMuOTQxMSIgaGVpZ2h0PSIyLjk2NzIiIHJ5PSIwIi8+CiA8cGF0aCBkPSJtMjguODUyIDM0LjYxNSAxLjUxNTItMC40NjYzMSAzLjExNDktMC45ODY5NC0wLjQ1NjI4LTEuNjE1MS00LjY3ODQgMS40NTQ3eiIvPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.60054" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi44NG1tIiBoZWlnaHQ9IjY3Ljc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi44NCA2Ny43OSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDcuODA0IC04MS43ODQpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSIxODUuOTYiPjxwYXRoIGQ9Im0xMDIuODYgODEuNzg0djM4LjA0OGEyNC4yNTMgMjQuMjUzIDAgMCAxIDYuMzY5MS0wLjg3Nzk5IDI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjkxIDAuODUyMTV2LTM4LjAyMnoiLz48cGF0aCBkPSJtNDcuODA0IDEzNi44NHYxMi43MzloMzguMDQ4YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC44ODQwOC02LjM2OTMgMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg4NDA4LTYuMzY5M3ptODQuODE0IDBhMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg1ODI3IDYuMzY5MyAyNC4yNTMgMjQuMjUzIDAgMCAxLTAuODc3NjMgNi4zNjkzaDM4LjA0MXYtMTIuNzM5eiIvPjxwYXRoIGQ9Im0xMzQuNDIgODYuODMtMTkuMDExIDMyLjkyNGEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAzNSA2LjM2OTFsMTkuMDA1LTMyLjkyNHoiLz48cGF0aCBkPSJtODQuMDMyIDg2LjgzLTExLjAzNSA2LjM2OTEgMTkuMDQzIDMyLjk3NmEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAyMi02LjM4ODh6Ii8+PHBhdGggZD0ibTU5LjIxOSAxMDYuOTgtNi4zNjkxIDExLjAzNSAzMi45NTYgMTkuMDNhMjQuMjUzIDI0LjI1MyAwIDAgMSA2LjM4ODgtMTEuMDIyem03My40MjQgNDIuMzkxYTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY3IDAuMjA2MTloMC40MjM3NXoiLz48cGF0aCBkPSJtMTU5LjIzIDEwNi45OC0zMi45MjQgMTkuMDExYTI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjI5IDExLjAzNWwzMi45My0xOS4wMTF6bS03My40MjQgNDIuMzkxLTAuMzU3MDggMC4yMDYxOWgwLjQyMzc1YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY2Ni0wLjIwNjE5eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExOS4xNW1tIiBoZWlnaHQ9IjE0MC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTkuMTUgMTQwLjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4zNDIgLTY4LjU2NCkiPjxnPjxjaXJjbGUgY3g9IjE0NyIgY3k9IjEwMy43MSIgcj0iMTAuNTEiLz48cGF0aCBkPSJtMTM3LjIxIDExOS4zNWMtMS42NDQ3IDAtMi4yNTQ0IDAuMTcxMjgtMi44NTU2IDAuOTc4MDUtMC42NzMyMyAwLjkwMzM5LTAuMjU2ODggMi41OTgyLTAuMTM1MzggMy4zNzcybDQuNTIxNyAyOS4wMTdjMC4xNzU2MyAxLjEyNzItMC4yMDMzMyAyLjE2OTUtMC45MDc5NiAyLjk5NTJoMjMuMDgzYzIuNTEyNiAwIDQuOTExNS0yLjA1MTMgNC41MzU2LTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjMxLTQuNTM1Ni00LjUzNTYtNC41MzU2eiIvPjxwYXRoIGQ9Im0xNDAuNSAxNTEuNGMtMC42NjU4OCAwLTEuMzEyNSAwLjE0Mzg0LTEuODk5NiAwLjQwMDQ5bDAuMTM5NTMgMC45MjM0NmMwLjI4MDMzIDEuODUzLTAuOTgzMzQgMy40NjQ1LTIuNjg2MiA0LjE2NDFsNC4xODc5IDQ3LjQwNWMwLjIyMDkzIDIuNTAwNSAyLjAyMDggNC41MzE1IDQuNTMxIDQuNTMxNWg0LjQ2NzRjMi41MTAyIDAgNC4zMTEtMi4wMzEgNC41MzEtNC41MzE1bDQuMjU0NS00OC4zNjJjMC4yMTk5OS0yLjUwMDYtMi4wMjA4LTQuNTMxLTQuNTMxLTQuNTMxeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTY0LjgzNCA5My4xOThhMTAuNTEgMTAuNTEgMCAwIDAtMTAuNTEgMTAuNTEgMTAuNTEgMTAuNTEgMCAwIDAgOC41OTEyIDEwLjMxNWwtMC4xMzkwMS0wLjI1ODljLTMuMzE4My02LjE5NTctMS4wMDE3LTEzLjg1NSA1LjE5NC0xNy4xNzMgMS4wNTUyLTAuNTY1MTYgMi4xNTI5LTAuOTY2NDMgMy4yNjQ0LTEuMjEzNGExMC41MSAxMC41MSAwIDAgMC02LjQwMDYtMi4xNzkyeiIgc3Ryb2tlLXdpZHRoPSIuMTE0ODkiLz48cGF0aCBkPSJtNTUuMDQ2IDExOS4zNWMtMi41MTI2IDAtNC4xNTk4IDIuMDUwOC00LjUzNTYgNC41MzUxbC00LjEyOTUgMjcuMjk3Yy0wLjM3NTg2IDIuNDg0MyAyLjAyMjYgNC41MzUxIDQuNTM1MSA0LjUzNTFoMjcuODM2YzIuMTk5MSAwIDUuNTcxOS0wLjE0MDY4IDQuMjYxOS0yLjk5NjItNS4wMjYtMTAuOTU2LTE3LjI0NS0zMy4zNzEtMTcuMjQ1LTMzLjM3MXoiLz48cGF0aCBkPSJtNTguMzM3IDE1MS40aDEyLjk5NWMyLjUxMDIgMCA0Ljc1MSAyLjAzMDUgNC41MzEgNC41MzExbC00LjI1NDggNDguMzYyYy0wLjIxOTk5IDIuNTAwNi0yLjAyMDggNC41MzExLTQuNTMxIDQuNTMxMWgtNC40NjY5Yy0yLjUxMDIgMC00LjMxMDEtMi4wMzA2LTQuNTMxMS00LjUzMTFsLTQuMjczLTQ4LjM2MmMtMC4yMjA5My0yLjUwMDUgMi4wMjA5LTQuNTMxMSA0LjUzMTEtNC41MzExeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTEwMi40MiAxMTkuMzVoLTExLjg5OXY1LjUzMjdsOC44OTYyIDQuNjgyMXoiLz48Y2lyY2xlIGN4PSIxMDYuMzIiIGN5PSIxMDMuNzEiIHI9IjEwLjUxIi8+PHBhdGggZD0ibTk2LjUzMyAxMTkuMzVjLTIuNTEyNiAwLTQuMTU5MyAyLjA1MTMtNC41MzUxIDQuNTM1NmwxLjQ5MzYgOS43ODU0czAuNTAzMzcgMjIuMDQ3IDMuMzM1MiAyMi4wNDdsMjMuNDEyLTFlLTNjMi41MTI2LTEuMWUtNCA0LjkxMS0yLjA1MTMgNC41MzUxLTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjI2LTQuNTM1Ni00LjUzNTEtNC41MzU2eiIvPjxwYXRoIGQ9Im05OS44MjMgMTUxLjRoMTIuOTk1YzIuNTEwMiAwIDQuNzUxIDIuMDMwNSA0LjUzMSA0LjUzMTFsLTQuMjU0OCA0OC4zNjJjLTAuMjE5OTkgMi41MDA2LTIuMDIwOCA0LjUzMTEtNC41MzEgNC41MzExaC00LjQ2NjljLTIuNTEwMiAwLTQuMzEwMS0yLjAzMDYtNC41MzExLTQuNTMxMWwtNC4yNzMtNDguMzYyYy0wLjIyMDkzLTIuNTAwNSAyLjAyMDktNC41MzExIDQuNTMxMS00LjUzMTF6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIyLjc1MDUiLz48cmVjdCB0cmFuc2Zvcm09InJvdGF0ZSgtMjguMTczKSIgeD0iMTIuNjUxIiB5PSIxMjcuNTgiIHdpZHRoPSIxMS4yOTUiIGhlaWdodD0iNjIuMDg0IiByeT0iNC41MzExIi8+PHBhdGggZD0ibTk1LjI5MiAxNTUuOTMgMS4yODExLTEuMzk2Mi0xLjI5NjItNC41ODU4LTguMzk0NS0xNC41MjMiLz48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzLjY2MiI+PHBhdGggZD0ibTEwNi4zMiA3MC4zOTV2MTQuOTczIi8+PHBhdGggZD0ibTg1LjA2MyA3Ni4yNjUgNy40ODY3IDEyLjk2NyIvPjxwYXRoIGQ9Im0xMjcuNTggNzYuMjY1LTcuNDg2NyAxMi45NjciLz48L2c+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.58727" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjMzLjQ4MiIgaGVpZ2h0PSIzNy42NjMiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMzLjQ4MiAzNy42NjMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8cGF0aCBkPSJtNy43MDMxIDE0LjY0OWExMS45MDYgMTEuOTA2IDAgMCAwLTcuNzAzMSAxMS4xMDcgMTEuOTA2IDExLjkwNiAwIDAgMCAxMS45MDYgMTEuOTA2IDExLjkwNiAxMS45MDYgMCAwIDAgMTEuOTA2LTExLjkwNiAxMS45MDYgMTEuOTA2IDAgMCAwLTAuMTIxMDktMS42ODE2aC0zLjgxMjVhOC4yNzc1IDguMjc3NSAwIDAgMSAwLjE2Nzk3IDEuNjQ2NSA4LjI3NzUgOC4yNzc1IDAgMCAxLTguMjc5MyA4LjI3NzMgOC4yNzc1IDguMjc3NSAwIDAgMS04LjI3NzMtOC4yNzczIDguMjc3NSA4LjI3NzUgMCAwIDEgNC4yMTI5LTcuMTg3NXoiLz4KIDxjaXJjbGUgY3g9IjExLjIzNCIgY3k9IjMuNzUyNCIgcj0iMy43NTI0Ii8+CiA8cGF0aCBkPSJtOS43MzYyIDE1LjYxaDEzLjUzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDczNCIvPgogPHBhdGggZD0ibTEwLjI5NiA0LjY5MjR2MTYuODc0aDE0LjQ3NWw0LjA4MDggMTMuMDQ5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMy4xNzUxIi8+CiA8cmVjdCB4PSI4LjcwODQiIHk9IjIwLjE4NCIgd2lkdGg9IjMuOTQxMSIgaGVpZ2h0PSIyLjk2NzIiIHJ5PSIwIi8+CiA8cGF0aCBkPSJtMjguODUyIDM0LjYxNSAxLjUxNTItMC40NjYzMSAzLjExNDktMC45ODY5NC0wLjQ1NjI4LTEuNjE1MS00LjY3ODQgMS40NTQ3eiIvPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.60054" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="31" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3NS4wMyIgaGVpZ2h0PSIyMjAuNjgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NS4wMyAyMjAuNjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0ibTQzLjM1MSAyMDUuOTV2LTE0LjczNGwtMTcuMjQyLTIyLjc0NmMtOS40ODI5LTEyLjUxLTE5LjIzNy0yNS41NTctMjEuNjc1LTI4Ljk5M2wtNC40MzM2LTYuMjQ2OCAwLjAyNTgtMzMuMTljMC4wMzE1LTQwLjQ4MyAwLjU4MzctNTUuMzY4IDIuMTczMS01OC41OCAyLjA3ODgtNC4yMDAzIDguNzgwOS02LjI1OTkgMTMuNjI1LTQuMTg3MSAzLjIzNyAxLjM4NSA1LjE2OTIgMy45NjE1IDUuOTQ5IDcuOTMyNiAwLjgxODgyIDQuMTcgMS4wNzkzIDQyLjkxOSAwLjMxODQ5IDQ3LjM3Mi0wLjQxOTM2IDIuNDU0Mi0xLjA4NzIgMi41MTQ0LTIuNTY5MiAzLjgzNjUtMi4xNDE3IDEuOTEwOC02LjcxMjggNS4zMjkzLTguMDY0NiA5LjE2ODUtMS4zMTIzIDMuNzI3Mi0wLjcyOTE0IDkuMTQzNCAwLjUyNTU3IDExLjg0MyAxLjM3MDggMi45NDkxIDEzLjcxNSAxNi40OTEgMjAuNDU3IDIyLjQ0MSA0LjIyMTEgMy43MjU2IDUuMTE2OSA0LjI3MjIgNi4xMjExIDMuNzM0NyAwLjY0NzAzLTAuMzQ2MjcgMS4xNzY0LTAuOTI5NTIgMS4xNzY0LTEuMjk2MSAwLTAuODQ3NC0zLjcwOTctNS4yMDY3LTEzLjQ3Ni0xNS44MzYtNC4yNjYxLTQuNjQzLTguNDQzMS05LjQ3MTYtOS4yODIyLTEwLjczLTIuOTU4Mi00LjQzNzItMS40NjgyLTEwLjQ5NiAzLjQzMjQtMTMuOTU4IDMuMzExNS0yLjMzOTIgOC4yMTQxLTIuNTI3MyAxMS41ODQtMC40NDQ0OCAxLjIwMyAwLjc0MzQ3IDEzLjMyNiAxMi43NTkgMjYuOTQxIDI2LjcwMmwyNC43NTQgMjUuMzV2NjcuMjk2aC00MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yNjMzMiAwIDAgLjI2MzMyIDEyLjg3OCAtOC44Njg4KSIgZmlsbD0icGFyYW0oZmlsbCkiIHN0cm9rZT0icGFyYW0ob3V0bGluZSkiIHN0cm9rZS13aWR0aD0icGFyYW0ob3V0bGluZS13aWR0aCkiPjxjaXJjbGUgY3g9IjI4My40NSIgY3k9IjEwNi4yNCIgcj0iNzIuNTYzIi8+PGcgZmlsbC1vcGFjaXR5PSJwYXJhbShmaWxsLW9wYWNpdHkpIiBzdHJva2Utb3BhY2l0eT0icGFyYW0ob3V0bGluZS1vcGFjaXR5KSI+PHBhdGggZD0ibTQ1NS42MyAzMDEuMDgtOTguMTE1LTk4LjI2OGMtOC4xMDctNy45NzQtMTcuMzM3LTEyLjc5OS0zMS4wMi0xMi43OTloLTg3LjA5NGMtMTMuNjgzIDAtMjIuMzA1IDQuOTc3LTMwLjE4MyAxMi43OTlsLTk3LjEyOCA5Ny4zMTVjLTI2LjU0NSAyNi41NDggOS4zNzUgNjAuNTI5IDM1Ljg3NyAzNC4wMjdsNTguNjYtNTkuMDQ5djU1LjM4NWgxNTIuOTV2LTU1LjY4OWw2MC4xOTggNjAuMzI0YzI0LjIzOSAyNS41MzEgNjEuMTI5LTguNzczIDM1Ljg1OC0zNC4wNDV6Ii8+PHBhdGggZD0ibTM1OS4yNiAzNTkuMjItNTcuNjQ1IDU3LjY0OSA0Mi4zMjIgNDIuMjQzLTQzLjM2NyA0My4zNjZjLTI1LjU5NCAyNS41OTcgOS43MTUgNjIuMjA1IDM2LjE4NCAzNS43MzZsNjguNTg1LTcxLjMxM2MxNC43MTktMTUuMDIxIDE4Ljc4OS00Mi43NjUgMy4wMDktNTguNTQ0LTAuMDU0LTAuMDUzLTQ5LjA4OC00OS4xMzctNDkuMDg4LTQ5LjEzN3oiLz48cGF0aCBkPSJtMjIxLjk2IDQ1OS4xMSA0Mi4zMjMtNDIuMjQzLTU3LjY0Ny01Ny42NDlzLTQ5LjAzMyA0OS4wODQtNDkuMDg2IDQ5LjEzOGMtMTUuNzggMTUuNzc5LTExLjcxIDQzLjUyMyAzLjAwOSA1OC41NDRsNjguNTg1IDcxLjMxM2MyNi40NjggMjYuNDY5IDYxLjc3Ny0xMC4xNCAzNi4xODMtMzUuNzM2eiIvPjwvZz48L2c+PHBhdGggZD0ibTEzMS44IDIwNS45NXYtMTQuNzM0bDE3LjI0Mi0yMi43NDZjOS40ODI5LTEyLjUxIDE5LjIzNy0yNS41NTcgMjEuNjc1LTI4Ljk5M2w0LjQzMzYtNi4yNDY4LTAuMDI1OC0zMy4xOWMtMC4wMzE1LTQwLjQ4My0wLjU4MzctNTUuMzY4LTIuMTczMS01OC41OC0yLjA3ODgtNC4yMDAzLTguNzgwOS02LjI1OTktMTMuNjI1LTQuMTg3MS0zLjIzNyAxLjM4NS01LjE2OTIgMy45NjE1LTUuOTQ5IDcuOTMyNi0wLjgxODgyIDQuMTctMS4wNzkzIDQyLjkxOS0wLjMxODQ5IDQ3LjM3MiAwLjQxOTM2IDIuNDU0MiAxLjA4NzIgMi41MTQ0IDIuNTY5MiAzLjgzNjUgMi4xNDE3IDEuOTEwOCA2LjcxMjggNS4zMjkzIDguMDY0NiA5LjE2ODUgMS4zMTIzIDMuNzI3MiAwLjcyOTE0IDkuMTQzNC0wLjUyNTU3IDExLjg0My0xLjM3MDggMi45NDkxLTEzLjcxNSAxNi40OTEtMjAuNDU3IDIyLjQ0MS00LjIyMTEgMy43MjU2LTUuMTE2OSA0LjI3MjItNi4xMjExIDMuNzM0Ny0wLjY0NzAzLTAuMzQ2MjctMS4xNzY0LTAuOTI5NTItMS4xNzY0LTEuMjk2MSAwLTAuODQ3NCAzLjcwOTctNS4yMDY3IDEzLjQ3Ni0xNS44MzYgNC4yNjYxLTQuNjQzIDguNDQzMS05LjQ3MTYgOS4yODIyLTEwLjczIDIuOTU4Mi00LjQzNzIgMS40NjgyLTEwLjQ5Ni0zLjQzMjQtMTMuOTU4LTMuMzExNS0yLjMzOTItOC4yMTQxLTIuNTI3My0xMS41ODQtMC40NDQ0OC0xLjIwMyAwLjc0MzQ3LTEzLjMyNiAxMi43NTktMjYuOTQxIDI2LjcwMmwtMjQuNzU0IDI1LjM1djY3LjI5Nmg0MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28295" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="32" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjM3LjE3OCIgaGVpZ2h0PSIzNy4xNzgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDM3LjE3OCAzNy4xNzgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjg1OTM4IC0xLjExNzIpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI1Ni4yODMiPgogIDxwYXRoIGQ9Im0xNy41MjEgMS4xMTcydjExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3Ny0wLjI2NTYyIDcuMzQwNSA3LjM0MDUgMCAwIDEgMS45Mjc3IDAuMjU3ODF2LTExLjUwOHptMCAyNS42NjR2MTEuNTE0aDMuODU1NXYtMTEuNTE0YTcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3IDAuMjY1NjIgNy4zNDA1IDcuMzQwNSAwIDAgMS0xLjkyNzctMC4yNjU2MnoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSg5MCkiIGQ9Im0xNy43NzktMC44NTkzOGgzLjg1NTV2LTExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxLTEuOTI3NyAwLjI2NzU4IDcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3LTAuMjY3NTh6bTAtMjUuNjdhNy4zNDA1IDcuMzQwNSAwIDAgMSAxLjkyNzctMC4yNTk3NiA3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3NyAwLjI2NTYydi0xMS41MTRoLTMuODU1NXoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSgzMCkiIGQ9Im0yNC43NjktMTEuMjQ3LTYuMDdlLTQgMTEuNTA3YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTYzLTQuNTQ5NGUtNGwtMC4wMDExLTExLjUwNnptLTMuNjllLTQgMjUuNjUyLTIuNzVlLTQgMTEuNTI3IDMuODU2My00LjU1ZS00IDcuOTllLTQgLTExLjUxOGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU2OC0wLjAwODN6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTMwKSIgZD0ibTguOTE3OCA4LjIwMjMtMy44NTYzLTQuNTQ5ZS00IDAuMDAxMjUgMTEuNTI1YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4LTAuMDA2NnptMy42ODhlLTQgMjUuNjUyYTcuMzQwNSA3LjM0MDUgMCAwIDEtMy44NTY4IDAuMDA4M2w3Ljk4N2UtNCAxMS41MTggMy44NTQ2LTUuMjJlLTR6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTYwKSIgZD0ibS01LjQxMzcgOC4xMDc1LTMuODU2MyA0LjU0OWUtNCAtNy45ODdlLTQgMTEuNTE4YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4IDAuMDA2NnptMS41NDVlLTQgMjUuNjZhNy4zNDA1IDcuMzQwNSAwIDAgMS0zLjg1NjgtMC4wMDgzbDAuMDAxNDIgMTEuNTI2IDMuODU0NiA1LjIyZS00eiIvPgogIDxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDYwKSIgZD0ibTI0Ljg2My0yNS41OCA2LjA3ZS00IDExLjUwN2E3LjM0MDUgNy4zNDA1IDAgMCAxIDMuODU1MyAwLjAwMjFsMy42OWUtNCAtMTEuNTA4em0tMS41NWUtNCAyNS42NiA3Ljk5ZS00IDExLjUxOCAzLjg1NDYtNS4yMmUtNCA0LjRlLTQgLTExLjUyNGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU1OCAwLjAwNjU3MjZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="33" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjMzLjQ4MiIgaGVpZ2h0PSIzNy42NjMiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMzLjQ4MiAzNy42NjMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8cGF0aCBkPSJtNy43MDMxIDE0LjY0OWExMS45MDYgMTEuOTA2IDAgMCAwLTcuNzAzMSAxMS4xMDcgMTEuOTA2IDExLjkwNiAwIDAgMCAxMS45MDYgMTEuOTA2IDExLjkwNiAxMS45MDYgMCAwIDAgMTEuOTA2LTExLjkwNiAxMS45MDYgMTEuOTA2IDAgMCAwLTAuMTIxMDktMS42ODE2aC0zLjgxMjVhOC4yNzc1IDguMjc3NSAwIDAgMSAwLjE2Nzk3IDEuNjQ2NSA4LjI3NzUgOC4yNzc1IDAgMCAxLTguMjc5MyA4LjI3NzMgOC4yNzc1IDguMjc3NSAwIDAgMS04LjI3NzMtOC4yNzczIDguMjc3NSA4LjI3NzUgMCAwIDEgNC4yMTI5LTcuMTg3NXoiLz4KIDxjaXJjbGUgY3g9IjExLjIzNCIgY3k9IjMuNzUyNCIgcj0iMy43NTI0Ii8+CiA8cGF0aCBkPSJtOS43MzYyIDE1LjYxaDEzLjUzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDczNCIvPgogPHBhdGggZD0ibTEwLjI5NiA0LjY5MjR2MTYuODc0aDE0LjQ3NWw0LjA4MDggMTMuMDQ5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMy4xNzUxIi8+CiA8cmVjdCB4PSI4LjcwODQiIHk9IjIwLjE4NCIgd2lkdGg9IjMuOTQxMSIgaGVpZ2h0PSIyLjk2NzIiIHJ5PSIwIi8+CiA8cGF0aCBkPSJtMjguODUyIDM0LjYxNSAxLjUxNTItMC40NjYzMSAzLjExNDktMC45ODY5NC0wLjQ1NjI4LTEuNjE1MS00LjY3ODQgMS40NTQ3eiIvPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.60054" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="34" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi44NG1tIiBoZWlnaHQ9IjY3Ljc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi44NCA2Ny43OSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDcuODA0IC04MS43ODQpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSIxODUuOTYiPjxwYXRoIGQ9Im0xMDIuODYgODEuNzg0djM4LjA0OGEyNC4yNTMgMjQuMjUzIDAgMCAxIDYuMzY5MS0wLjg3Nzk5IDI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjkxIDAuODUyMTV2LTM4LjAyMnoiLz48cGF0aCBkPSJtNDcuODA0IDEzNi44NHYxMi43MzloMzguMDQ4YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC44ODQwOC02LjM2OTMgMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg4NDA4LTYuMzY5M3ptODQuODE0IDBhMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg1ODI3IDYuMzY5MyAyNC4yNTMgMjQuMjUzIDAgMCAxLTAuODc3NjMgNi4zNjkzaDM4LjA0MXYtMTIuNzM5eiIvPjxwYXRoIGQ9Im0xMzQuNDIgODYuODMtMTkuMDExIDMyLjkyNGEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAzNSA2LjM2OTFsMTkuMDA1LTMyLjkyNHoiLz48cGF0aCBkPSJtODQuMDMyIDg2LjgzLTExLjAzNSA2LjM2OTEgMTkuMDQzIDMyLjk3NmEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAyMi02LjM4ODh6Ii8+PHBhdGggZD0ibTU5LjIxOSAxMDYuOTgtNi4zNjkxIDExLjAzNSAzMi45NTYgMTkuMDNhMjQuMjUzIDI0LjI1MyAwIDAgMSA2LjM4ODgtMTEuMDIyem03My40MjQgNDIuMzkxYTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY3IDAuMjA2MTloMC40MjM3NXoiLz48cGF0aCBkPSJtMTU5LjIzIDEwNi45OC0zMi45MjQgMTkuMDExYTI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjI5IDExLjAzNWwzMi45My0xOS4wMTF6bS03My40MjQgNDIuMzkxLTAuMzU3MDggMC4yMDYxOWgwLjQyMzc1YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY2Ni0wLjIwNjE5eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="35" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExOS4xNW1tIiBoZWlnaHQ9IjE0MC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTkuMTUgMTQwLjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4zNDIgLTY4LjU2NCkiPjxnPjxjaXJjbGUgY3g9IjE0NyIgY3k9IjEwMy43MSIgcj0iMTAuNTEiLz48cGF0aCBkPSJtMTM3LjIxIDExOS4zNWMtMS42NDQ3IDAtMi4yNTQ0IDAuMTcxMjgtMi44NTU2IDAuOTc4MDUtMC42NzMyMyAwLjkwMzM5LTAuMjU2ODggMi41OTgyLTAuMTM1MzggMy4zNzcybDQuNTIxNyAyOS4wMTdjMC4xNzU2MyAxLjEyNzItMC4yMDMzMyAyLjE2OTUtMC45MDc5NiAyLjk5NTJoMjMuMDgzYzIuNTEyNiAwIDQuOTExNS0yLjA1MTMgNC41MzU2LTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjMxLTQuNTM1Ni00LjUzNTYtNC41MzU2eiIvPjxwYXRoIGQ9Im0xNDAuNSAxNTEuNGMtMC42NjU4OCAwLTEuMzEyNSAwLjE0Mzg0LTEuODk5NiAwLjQwMDQ5bDAuMTM5NTMgMC45MjM0NmMwLjI4MDMzIDEuODUzLTAuOTgzMzQgMy40NjQ1LTIuNjg2MiA0LjE2NDFsNC4xODc5IDQ3LjQwNWMwLjIyMDkzIDIuNTAwNSAyLjAyMDggNC41MzE1IDQuNTMxIDQuNTMxNWg0LjQ2NzRjMi41MTAyIDAgNC4zMTEtMi4wMzEgNC41MzEtNC41MzE1bDQuMjU0NS00OC4zNjJjMC4yMTk5OS0yLjUwMDYtMi4wMjA4LTQuNTMxLTQuNTMxLTQuNTMxeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTY0LjgzNCA5My4xOThhMTAuNTEgMTAuNTEgMCAwIDAtMTAuNTEgMTAuNTEgMTAuNTEgMTAuNTEgMCAwIDAgOC41OTEyIDEwLjMxNWwtMC4xMzkwMS0wLjI1ODljLTMuMzE4My02LjE5NTctMS4wMDE3LTEzLjg1NSA1LjE5NC0xNy4xNzMgMS4wNTUyLTAuNTY1MTYgMi4xNTI5LTAuOTY2NDMgMy4yNjQ0LTEuMjEzNGExMC41MSAxMC41MSAwIDAgMC02LjQwMDYtMi4xNzkyeiIgc3Ryb2tlLXdpZHRoPSIuMTE0ODkiLz48cGF0aCBkPSJtNTUuMDQ2IDExOS4zNWMtMi41MTI2IDAtNC4xNTk4IDIuMDUwOC00LjUzNTYgNC41MzUxbC00LjEyOTUgMjcuMjk3Yy0wLjM3NTg2IDIuNDg0MyAyLjAyMjYgNC41MzUxIDQuNTM1MSA0LjUzNTFoMjcuODM2YzIuMTk5MSAwIDUuNTcxOS0wLjE0MDY4IDQuMjYxOS0yLjk5NjItNS4wMjYtMTAuOTU2LTE3LjI0NS0zMy4zNzEtMTcuMjQ1LTMzLjM3MXoiLz48cGF0aCBkPSJtNTguMzM3IDE1MS40aDEyLjk5NWMyLjUxMDIgMCA0Ljc1MSAyLjAzMDUgNC41MzEgNC41MzExbC00LjI1NDggNDguMzYyYy0wLjIxOTk5IDIuNTAwNi0yLjAyMDggNC41MzExLTQuNTMxIDQuNTMxMWgtNC40NjY5Yy0yLjUxMDIgMC00LjMxMDEtMi4wMzA2LTQuNTMxMS00LjUzMTFsLTQuMjczLTQ4LjM2MmMtMC4yMjA5My0yLjUwMDUgMi4wMjA5LTQuNTMxMSA0LjUzMTEtNC41MzExeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTEwMi40MiAxMTkuMzVoLTExLjg5OXY1LjUzMjdsOC44OTYyIDQuNjgyMXoiLz48Y2lyY2xlIGN4PSIxMDYuMzIiIGN5PSIxMDMuNzEiIHI9IjEwLjUxIi8+PHBhdGggZD0ibTk2LjUzMyAxMTkuMzVjLTIuNTEyNiAwLTQuMTU5MyAyLjA1MTMtNC41MzUxIDQuNTM1NmwxLjQ5MzYgOS43ODU0czAuNTAzMzcgMjIuMDQ3IDMuMzM1MiAyMi4wNDdsMjMuNDEyLTFlLTNjMi41MTI2LTEuMWUtNCA0LjkxMS0yLjA1MTMgNC41MzUxLTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjI2LTQuNTM1Ni00LjUzNTEtNC41MzU2eiIvPjxwYXRoIGQ9Im05OS44MjMgMTUxLjRoMTIuOTk1YzIuNTEwMiAwIDQuNzUxIDIuMDMwNSA0LjUzMSA0LjUzMTFsLTQuMjU0OCA0OC4zNjJjLTAuMjE5OTkgMi41MDA2LTIuMDIwOCA0LjUzMTEtNC41MzEgNC41MzExaC00LjQ2NjljLTIuNTEwMiAwLTQuMzEwMS0yLjAzMDYtNC41MzExLTQuNTMxMWwtNC4yNzMtNDguMzYyYy0wLjIyMDkzLTIuNTAwNSAyLjAyMDktNC41MzExIDQuNTMxMS00LjUzMTF6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIyLjc1MDUiLz48cmVjdCB0cmFuc2Zvcm09InJvdGF0ZSgtMjguMTczKSIgeD0iMTIuNjUxIiB5PSIxMjcuNTgiIHdpZHRoPSIxMS4yOTUiIGhlaWdodD0iNjIuMDg0IiByeT0iNC41MzExIi8+PHBhdGggZD0ibTk1LjI5MiAxNTUuOTMgMS4yODExLTEuMzk2Mi0xLjI5NjItNC41ODU4LTguMzk0NS0xNC41MjMiLz48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzLjY2MiI+PHBhdGggZD0ibTEwNi4zMiA3MC4zOTV2MTQuOTczIi8+PHBhdGggZD0ibTg1LjA2MyA3Ni4yNjUgNy40ODY3IDEyLjk2NyIvPjxwYXRoIGQ9Im0xMjcuNTggNzYuMjY1LTcuNDg2NyAxMi45NjciLz48L2c+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.58727" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="36" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="37" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3NS4wMyIgaGVpZ2h0PSIyMjAuNjgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NS4wMyAyMjAuNjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0ibTQzLjM1MSAyMDUuOTV2LTE0LjczNGwtMTcuMjQyLTIyLjc0NmMtOS40ODI5LTEyLjUxLTE5LjIzNy0yNS41NTctMjEuNjc1LTI4Ljk5M2wtNC40MzM2LTYuMjQ2OCAwLjAyNTgtMzMuMTljMC4wMzE1LTQwLjQ4MyAwLjU4MzctNTUuMzY4IDIuMTczMS01OC41OCAyLjA3ODgtNC4yMDAzIDguNzgwOS02LjI1OTkgMTMuNjI1LTQuMTg3MSAzLjIzNyAxLjM4NSA1LjE2OTIgMy45NjE1IDUuOTQ5IDcuOTMyNiAwLjgxODgyIDQuMTcgMS4wNzkzIDQyLjkxOSAwLjMxODQ5IDQ3LjM3Mi0wLjQxOTM2IDIuNDU0Mi0xLjA4NzIgMi41MTQ0LTIuNTY5MiAzLjgzNjUtMi4xNDE3IDEuOTEwOC02LjcxMjggNS4zMjkzLTguMDY0NiA5LjE2ODUtMS4zMTIzIDMuNzI3Mi0wLjcyOTE0IDkuMTQzNCAwLjUyNTU3IDExLjg0MyAxLjM3MDggMi45NDkxIDEzLjcxNSAxNi40OTEgMjAuNDU3IDIyLjQ0MSA0LjIyMTEgMy43MjU2IDUuMTE2OSA0LjI3MjIgNi4xMjExIDMuNzM0NyAwLjY0NzAzLTAuMzQ2MjcgMS4xNzY0LTAuOTI5NTIgMS4xNzY0LTEuMjk2MSAwLTAuODQ3NC0zLjcwOTctNS4yMDY3LTEzLjQ3Ni0xNS44MzYtNC4yNjYxLTQuNjQzLTguNDQzMS05LjQ3MTYtOS4yODIyLTEwLjczLTIuOTU4Mi00LjQzNzItMS40NjgyLTEwLjQ5NiAzLjQzMjQtMTMuOTU4IDMuMzExNS0yLjMzOTIgOC4yMTQxLTIuNTI3MyAxMS41ODQtMC40NDQ0OCAxLjIwMyAwLjc0MzQ3IDEzLjMyNiAxMi43NTkgMjYuOTQxIDI2LjcwMmwyNC43NTQgMjUuMzV2NjcuMjk2aC00MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yNjMzMiAwIDAgLjI2MzMyIDEyLjg3OCAtOC44Njg4KSIgZmlsbD0icGFyYW0oZmlsbCkiIHN0cm9rZT0icGFyYW0ob3V0bGluZSkiIHN0cm9rZS13aWR0aD0icGFyYW0ob3V0bGluZS13aWR0aCkiPjxjaXJjbGUgY3g9IjI4My40NSIgY3k9IjEwNi4yNCIgcj0iNzIuNTYzIi8+PGcgZmlsbC1vcGFjaXR5PSJwYXJhbShmaWxsLW9wYWNpdHkpIiBzdHJva2Utb3BhY2l0eT0icGFyYW0ob3V0bGluZS1vcGFjaXR5KSI+PHBhdGggZD0ibTQ1NS42MyAzMDEuMDgtOTguMTE1LTk4LjI2OGMtOC4xMDctNy45NzQtMTcuMzM3LTEyLjc5OS0zMS4wMi0xMi43OTloLTg3LjA5NGMtMTMuNjgzIDAtMjIuMzA1IDQuOTc3LTMwLjE4MyAxMi43OTlsLTk3LjEyOCA5Ny4zMTVjLTI2LjU0NSAyNi41NDggOS4zNzUgNjAuNTI5IDM1Ljg3NyAzNC4wMjdsNTguNjYtNTkuMDQ5djU1LjM4NWgxNTIuOTV2LTU1LjY4OWw2MC4xOTggNjAuMzI0YzI0LjIzOSAyNS41MzEgNjEuMTI5LTguNzczIDM1Ljg1OC0zNC4wNDV6Ii8+PHBhdGggZD0ibTM1OS4yNiAzNTkuMjItNTcuNjQ1IDU3LjY0OSA0Mi4zMjIgNDIuMjQzLTQzLjM2NyA0My4zNjZjLTI1LjU5NCAyNS41OTcgOS43MTUgNjIuMjA1IDM2LjE4NCAzNS43MzZsNjguNTg1LTcxLjMxM2MxNC43MTktMTUuMDIxIDE4Ljc4OS00Mi43NjUgMy4wMDktNTguNTQ0LTAuMDU0LTAuMDUzLTQ5LjA4OC00OS4xMzctNDkuMDg4LTQ5LjEzN3oiLz48cGF0aCBkPSJtMjIxLjk2IDQ1OS4xMSA0Mi4zMjMtNDIuMjQzLTU3LjY0Ny01Ny42NDlzLTQ5LjAzMyA0OS4wODQtNDkuMDg2IDQ5LjEzOGMtMTUuNzggMTUuNzc5LTExLjcxIDQzLjUyMyAzLjAwOSA1OC41NDRsNjguNTg1IDcxLjMxM2MyNi40NjggMjYuNDY5IDYxLjc3Ny0xMC4xNCAzNi4xODMtMzUuNzM2eiIvPjwvZz48L2c+PHBhdGggZD0ibTEzMS44IDIwNS45NXYtMTQuNzM0bDE3LjI0Mi0yMi43NDZjOS40ODI5LTEyLjUxIDE5LjIzNy0yNS41NTcgMjEuNjc1LTI4Ljk5M2w0LjQzMzYtNi4yNDY4LTAuMDI1OC0zMy4xOWMtMC4wMzE1LTQwLjQ4My0wLjU4MzctNTUuMzY4LTIuMTczMS01OC41OC0yLjA3ODgtNC4yMDAzLTguNzgwOS02LjI1OTktMTMuNjI1LTQuMTg3MS0zLjIzNyAxLjM4NS01LjE2OTIgMy45NjE1LTUuOTQ5IDcuOTMyNi0wLjgxODgyIDQuMTctMS4wNzkzIDQyLjkxOS0wLjMxODQ5IDQ3LjM3MiAwLjQxOTM2IDIuNDU0MiAxLjA4NzIgMi41MTQ0IDIuNTY5MiAzLjgzNjUgMi4xNDE3IDEuOTEwOCA2LjcxMjggNS4zMjkzIDguMDY0NiA5LjE2ODUgMS4zMTIzIDMuNzI3MiAwLjcyOTE0IDkuMTQzNC0wLjUyNTU3IDExLjg0My0xLjM3MDggMi45NDkxLTEzLjcxNSAxNi40OTEtMjAuNDU3IDIyLjQ0MS00LjIyMTEgMy43MjU2LTUuMTE2OSA0LjI3MjItNi4xMjExIDMuNzM0Ny0wLjY0NzAzLTAuMzQ2MjctMS4xNzY0LTAuOTI5NTItMS4xNzY0LTEuMjk2MSAwLTAuODQ3NCAzLjcwOTctNS4yMDY3IDEzLjQ3Ni0xNS44MzYgNC4yNjYxLTQuNjQzIDguNDQzMS05LjQ3MTYgOS4yODIyLTEwLjczIDIuOTU4Mi00LjQzNzIgMS40NjgyLTEwLjQ5Ni0zLjQzMjQtMTMuOTU4LTMuMzExNS0yLjMzOTItOC4yMTQxLTIuNTI3My0xMS41ODQtMC40NDQ0OC0xLjIwMyAwLjc0MzQ3LTEzLjMyNiAxMi43NTktMjYuOTQxIDI2LjcwMmwtMjQuNzU0IDI1LjM1djY3LjI5Nmg0MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28295" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="38" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjM3LjE3OCIgaGVpZ2h0PSIzNy4xNzgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDM3LjE3OCAzNy4xNzgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjg1OTM4IC0xLjExNzIpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI1Ni4yODMiPgogIDxwYXRoIGQ9Im0xNy41MjEgMS4xMTcydjExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3Ny0wLjI2NTYyIDcuMzQwNSA3LjM0MDUgMCAwIDEgMS45Mjc3IDAuMjU3ODF2LTExLjUwOHptMCAyNS42NjR2MTEuNTE0aDMuODU1NXYtMTEuNTE0YTcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3IDAuMjY1NjIgNy4zNDA1IDcuMzQwNSAwIDAgMS0xLjkyNzctMC4yNjU2MnoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSg5MCkiIGQ9Im0xNy43NzktMC44NTkzOGgzLjg1NTV2LTExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxLTEuOTI3NyAwLjI2NzU4IDcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3LTAuMjY3NTh6bTAtMjUuNjdhNy4zNDA1IDcuMzQwNSAwIDAgMSAxLjkyNzctMC4yNTk3NiA3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3NyAwLjI2NTYydi0xMS41MTRoLTMuODU1NXoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSgzMCkiIGQ9Im0yNC43NjktMTEuMjQ3LTYuMDdlLTQgMTEuNTA3YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTYzLTQuNTQ5NGUtNGwtMC4wMDExLTExLjUwNnptLTMuNjllLTQgMjUuNjUyLTIuNzVlLTQgMTEuNTI3IDMuODU2My00LjU1ZS00IDcuOTllLTQgLTExLjUxOGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU2OC0wLjAwODN6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTMwKSIgZD0ibTguOTE3OCA4LjIwMjMtMy44NTYzLTQuNTQ5ZS00IDAuMDAxMjUgMTEuNTI1YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4LTAuMDA2NnptMy42ODhlLTQgMjUuNjUyYTcuMzQwNSA3LjM0MDUgMCAwIDEtMy44NTY4IDAuMDA4M2w3Ljk4N2UtNCAxMS41MTggMy44NTQ2LTUuMjJlLTR6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTYwKSIgZD0ibS01LjQxMzcgOC4xMDc1LTMuODU2MyA0LjU0OWUtNCAtNy45ODdlLTQgMTEuNTE4YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4IDAuMDA2NnptMS41NDVlLTQgMjUuNjZhNy4zNDA1IDcuMzQwNSAwIDAgMS0zLjg1NjgtMC4wMDgzbDAuMDAxNDIgMTEuNTI2IDMuODU0NiA1LjIyZS00eiIvPgogIDxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDYwKSIgZD0ibTI0Ljg2My0yNS41OCA2LjA3ZS00IDExLjUwN2E3LjM0MDUgNy4zNDA1IDAgMCAxIDMuODU1MyAwLjAwMjFsMy42OWUtNCAtMTEuNTA4em0tMS41NWUtNCAyNS42NiA3Ljk5ZS00IDExLjUxOCAzLjg1NDYtNS4yMmUtNCA0LjRlLTQgLTExLjUyNGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU1OCAwLjAwNjU3MjZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="39" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjMzLjQ4MiIgaGVpZ2h0PSIzNy42NjMiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMzLjQ4MiAzNy42NjMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8cGF0aCBkPSJtNy43MDMxIDE0LjY0OWExMS45MDYgMTEuOTA2IDAgMCAwLTcuNzAzMSAxMS4xMDcgMTEuOTA2IDExLjkwNiAwIDAgMCAxMS45MDYgMTEuOTA2IDExLjkwNiAxMS45MDYgMCAwIDAgMTEuOTA2LTExLjkwNiAxMS45MDYgMTEuOTA2IDAgMCAwLTAuMTIxMDktMS42ODE2aC0zLjgxMjVhOC4yNzc1IDguMjc3NSAwIDAgMSAwLjE2Nzk3IDEuNjQ2NSA4LjI3NzUgOC4yNzc1IDAgMCAxLTguMjc5MyA4LjI3NzMgOC4yNzc1IDguMjc3NSAwIDAgMS04LjI3NzMtOC4yNzczIDguMjc3NSA4LjI3NzUgMCAwIDEgNC4yMTI5LTcuMTg3NXoiLz4KIDxjaXJjbGUgY3g9IjExLjIzNCIgY3k9IjMuNzUyNCIgcj0iMy43NTI0Ii8+CiA8cGF0aCBkPSJtOS43MzYyIDE1LjYxaDEzLjUzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDczNCIvPgogPHBhdGggZD0ibTEwLjI5NiA0LjY5MjR2MTYuODc0aDE0LjQ3NWw0LjA4MDggMTMuMDQ5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMy4xNzUxIi8+CiA8cmVjdCB4PSI4LjcwODQiIHk9IjIwLjE4NCIgd2lkdGg9IjMuOTQxMSIgaGVpZ2h0PSIyLjk2NzIiIHJ5PSIwIi8+CiA8cGF0aCBkPSJtMjguODUyIDM0LjYxNSAxLjUxNTItMC40NjYzMSAzLjExNDktMC45ODY5NC0wLjQ1NjI4LTEuNjE1MS00LjY3ODQgMS40NTQ3eiIvPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.60054" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi44NG1tIiBoZWlnaHQ9IjY3Ljc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi44NCA2Ny43OSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDcuODA0IC04MS43ODQpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSIxODUuOTYiPjxwYXRoIGQ9Im0xMDIuODYgODEuNzg0djM4LjA0OGEyNC4yNTMgMjQuMjUzIDAgMCAxIDYuMzY5MS0wLjg3Nzk5IDI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjkxIDAuODUyMTV2LTM4LjAyMnoiLz48cGF0aCBkPSJtNDcuODA0IDEzNi44NHYxMi43MzloMzguMDQ4YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC44ODQwOC02LjM2OTMgMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg4NDA4LTYuMzY5M3ptODQuODE0IDBhMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg1ODI3IDYuMzY5MyAyNC4yNTMgMjQuMjUzIDAgMCAxLTAuODc3NjMgNi4zNjkzaDM4LjA0MXYtMTIuNzM5eiIvPjxwYXRoIGQ9Im0xMzQuNDIgODYuODMtMTkuMDExIDMyLjkyNGEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAzNSA2LjM2OTFsMTkuMDA1LTMyLjkyNHoiLz48cGF0aCBkPSJtODQuMDMyIDg2LjgzLTExLjAzNSA2LjM2OTEgMTkuMDQzIDMyLjk3NmEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAyMi02LjM4ODh6Ii8+PHBhdGggZD0ibTU5LjIxOSAxMDYuOTgtNi4zNjkxIDExLjAzNSAzMi45NTYgMTkuMDNhMjQuMjUzIDI0LjI1MyAwIDAgMSA2LjM4ODgtMTEuMDIyem03My40MjQgNDIuMzkxYTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY3IDAuMjA2MTloMC40MjM3NXoiLz48cGF0aCBkPSJtMTU5LjIzIDEwNi45OC0zMi45MjQgMTkuMDExYTI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjI5IDExLjAzNWwzMi45My0xOS4wMTF6bS03My40MjQgNDIuMzkxLTAuMzU3MDggMC4yMDYxOWgwLjQyMzc1YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY2Ni0wLjIwNjE5eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="40" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi44NG1tIiBoZWlnaHQ9IjY3Ljc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi44NCA2Ny43OSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDcuODA0IC04MS43ODQpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSIxODUuOTYiPjxwYXRoIGQ9Im0xMDIuODYgODEuNzg0djM4LjA0OGEyNC4yNTMgMjQuMjUzIDAgMCAxIDYuMzY5MS0wLjg3Nzk5IDI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjkxIDAuODUyMTV2LTM4LjAyMnoiLz48cGF0aCBkPSJtNDcuODA0IDEzNi44NHYxMi43MzloMzguMDQ4YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC44ODQwOC02LjM2OTMgMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg4NDA4LTYuMzY5M3ptODQuODE0IDBhMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg1ODI3IDYuMzY5MyAyNC4yNTMgMjQuMjUzIDAgMCAxLTAuODc3NjMgNi4zNjkzaDM4LjA0MXYtMTIuNzM5eiIvPjxwYXRoIGQ9Im0xMzQuNDIgODYuODMtMTkuMDExIDMyLjkyNGEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAzNSA2LjM2OTFsMTkuMDA1LTMyLjkyNHoiLz48cGF0aCBkPSJtODQuMDMyIDg2LjgzLTExLjAzNSA2LjM2OTEgMTkuMDQzIDMyLjk3NmEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAyMi02LjM4ODh6Ii8+PHBhdGggZD0ibTU5LjIxOSAxMDYuOTgtNi4zNjkxIDExLjAzNSAzMi45NTYgMTkuMDNhMjQuMjUzIDI0LjI1MyAwIDAgMSA2LjM4ODgtMTEuMDIyem03My40MjQgNDIuMzkxYTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY3IDAuMjA2MTloMC40MjM3NXoiLz48cGF0aCBkPSJtMTU5LjIzIDEwNi45OC0zMi45MjQgMTkuMDExYTI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjI5IDExLjAzNWwzMi45My0xOS4wMTF6bS03My40MjQgNDIuMzkxLTAuMzU3MDggMC4yMDYxOWgwLjQyMzc1YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY2Ni0wLjIwNjE5eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="41" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExOS4xNW1tIiBoZWlnaHQ9IjE0MC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTkuMTUgMTQwLjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4zNDIgLTY4LjU2NCkiPjxnPjxjaXJjbGUgY3g9IjE0NyIgY3k9IjEwMy43MSIgcj0iMTAuNTEiLz48cGF0aCBkPSJtMTM3LjIxIDExOS4zNWMtMS42NDQ3IDAtMi4yNTQ0IDAuMTcxMjgtMi44NTU2IDAuOTc4MDUtMC42NzMyMyAwLjkwMzM5LTAuMjU2ODggMi41OTgyLTAuMTM1MzggMy4zNzcybDQuNTIxNyAyOS4wMTdjMC4xNzU2MyAxLjEyNzItMC4yMDMzMyAyLjE2OTUtMC45MDc5NiAyLjk5NTJoMjMuMDgzYzIuNTEyNiAwIDQuOTExNS0yLjA1MTMgNC41MzU2LTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjMxLTQuNTM1Ni00LjUzNTYtNC41MzU2eiIvPjxwYXRoIGQ9Im0xNDAuNSAxNTEuNGMtMC42NjU4OCAwLTEuMzEyNSAwLjE0Mzg0LTEuODk5NiAwLjQwMDQ5bDAuMTM5NTMgMC45MjM0NmMwLjI4MDMzIDEuODUzLTAuOTgzMzQgMy40NjQ1LTIuNjg2MiA0LjE2NDFsNC4xODc5IDQ3LjQwNWMwLjIyMDkzIDIuNTAwNSAyLjAyMDggNC41MzE1IDQuNTMxIDQuNTMxNWg0LjQ2NzRjMi41MTAyIDAgNC4zMTEtMi4wMzEgNC41MzEtNC41MzE1bDQuMjU0NS00OC4zNjJjMC4yMTk5OS0yLjUwMDYtMi4wMjA4LTQuNTMxLTQuNTMxLTQuNTMxeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTY0LjgzNCA5My4xOThhMTAuNTEgMTAuNTEgMCAwIDAtMTAuNTEgMTAuNTEgMTAuNTEgMTAuNTEgMCAwIDAgOC41OTEyIDEwLjMxNWwtMC4xMzkwMS0wLjI1ODljLTMuMzE4My02LjE5NTctMS4wMDE3LTEzLjg1NSA1LjE5NC0xNy4xNzMgMS4wNTUyLTAuNTY1MTYgMi4xNTI5LTAuOTY2NDMgMy4yNjQ0LTEuMjEzNGExMC41MSAxMC41MSAwIDAgMC02LjQwMDYtMi4xNzkyeiIgc3Ryb2tlLXdpZHRoPSIuMTE0ODkiLz48cGF0aCBkPSJtNTUuMDQ2IDExOS4zNWMtMi41MTI2IDAtNC4xNTk4IDIuMDUwOC00LjUzNTYgNC41MzUxbC00LjEyOTUgMjcuMjk3Yy0wLjM3NTg2IDIuNDg0MyAyLjAyMjYgNC41MzUxIDQuNTM1MSA0LjUzNTFoMjcuODM2YzIuMTk5MSAwIDUuNTcxOS0wLjE0MDY4IDQuMjYxOS0yLjk5NjItNS4wMjYtMTAuOTU2LTE3LjI0NS0zMy4zNzEtMTcuMjQ1LTMzLjM3MXoiLz48cGF0aCBkPSJtNTguMzM3IDE1MS40aDEyLjk5NWMyLjUxMDIgMCA0Ljc1MSAyLjAzMDUgNC41MzEgNC41MzExbC00LjI1NDggNDguMzYyYy0wLjIxOTk5IDIuNTAwNi0yLjAyMDggNC41MzExLTQuNTMxIDQuNTMxMWgtNC40NjY5Yy0yLjUxMDIgMC00LjMxMDEtMi4wMzA2LTQuNTMxMS00LjUzMTFsLTQuMjczLTQ4LjM2MmMtMC4yMjA5My0yLjUwMDUgMi4wMjA5LTQuNTMxMSA0LjUzMTEtNC41MzExeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTEwMi40MiAxMTkuMzVoLTExLjg5OXY1LjUzMjdsOC44OTYyIDQuNjgyMXoiLz48Y2lyY2xlIGN4PSIxMDYuMzIiIGN5PSIxMDMuNzEiIHI9IjEwLjUxIi8+PHBhdGggZD0ibTk2LjUzMyAxMTkuMzVjLTIuNTEyNiAwLTQuMTU5MyAyLjA1MTMtNC41MzUxIDQuNTM1NmwxLjQ5MzYgOS43ODU0czAuNTAzMzcgMjIuMDQ3IDMuMzM1MiAyMi4wNDdsMjMuNDEyLTFlLTNjMi41MTI2LTEuMWUtNCA0LjkxMS0yLjA1MTMgNC41MzUxLTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjI2LTQuNTM1Ni00LjUzNTEtNC41MzU2eiIvPjxwYXRoIGQ9Im05OS44MjMgMTUxLjRoMTIuOTk1YzIuNTEwMiAwIDQuNzUxIDIuMDMwNSA0LjUzMSA0LjUzMTFsLTQuMjU0OCA0OC4zNjJjLTAuMjE5OTkgMi41MDA2LTIuMDIwOCA0LjUzMTEtNC41MzEgNC41MzExaC00LjQ2NjljLTIuNTEwMiAwLTQuMzEwMS0yLjAzMDYtNC41MzExLTQuNTMxMWwtNC4yNzMtNDguMzYyYy0wLjIyMDkzLTIuNTAwNSAyLjAyMDktNC41MzExIDQuNTMxMS00LjUzMTF6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIyLjc1MDUiLz48cmVjdCB0cmFuc2Zvcm09InJvdGF0ZSgtMjguMTczKSIgeD0iMTIuNjUxIiB5PSIxMjcuNTgiIHdpZHRoPSIxMS4yOTUiIGhlaWdodD0iNjIuMDg0IiByeT0iNC41MzExIi8+PHBhdGggZD0ibTk1LjI5MiAxNTUuOTMgMS4yODExLTEuMzk2Mi0xLjI5NjItNC41ODU4LTguMzk0NS0xNC41MjMiLz48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzLjY2MiI+PHBhdGggZD0ibTEwNi4zMiA3MC4zOTV2MTQuOTczIi8+PHBhdGggZD0ibTg1LjA2MyA3Ni4yNjUgNy40ODY3IDEyLjk2NyIvPjxwYXRoIGQ9Im0xMjcuNTggNzYuMjY1LTcuNDg2NyAxMi45NjciLz48L2c+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.58727" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="42" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="43" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3NS4wMyIgaGVpZ2h0PSIyMjAuNjgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NS4wMyAyMjAuNjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0ibTQzLjM1MSAyMDUuOTV2LTE0LjczNGwtMTcuMjQyLTIyLjc0NmMtOS40ODI5LTEyLjUxLTE5LjIzNy0yNS41NTctMjEuNjc1LTI4Ljk5M2wtNC40MzM2LTYuMjQ2OCAwLjAyNTgtMzMuMTljMC4wMzE1LTQwLjQ4MyAwLjU4MzctNTUuMzY4IDIuMTczMS01OC41OCAyLjA3ODgtNC4yMDAzIDguNzgwOS02LjI1OTkgMTMuNjI1LTQuMTg3MSAzLjIzNyAxLjM4NSA1LjE2OTIgMy45NjE1IDUuOTQ5IDcuOTMyNiAwLjgxODgyIDQuMTcgMS4wNzkzIDQyLjkxOSAwLjMxODQ5IDQ3LjM3Mi0wLjQxOTM2IDIuNDU0Mi0xLjA4NzIgMi41MTQ0LTIuNTY5MiAzLjgzNjUtMi4xNDE3IDEuOTEwOC02LjcxMjggNS4zMjkzLTguMDY0NiA5LjE2ODUtMS4zMTIzIDMuNzI3Mi0wLjcyOTE0IDkuMTQzNCAwLjUyNTU3IDExLjg0MyAxLjM3MDggMi45NDkxIDEzLjcxNSAxNi40OTEgMjAuNDU3IDIyLjQ0MSA0LjIyMTEgMy43MjU2IDUuMTE2OSA0LjI3MjIgNi4xMjExIDMuNzM0NyAwLjY0NzAzLTAuMzQ2MjcgMS4xNzY0LTAuOTI5NTIgMS4xNzY0LTEuMjk2MSAwLTAuODQ3NC0zLjcwOTctNS4yMDY3LTEzLjQ3Ni0xNS44MzYtNC4yNjYxLTQuNjQzLTguNDQzMS05LjQ3MTYtOS4yODIyLTEwLjczLTIuOTU4Mi00LjQzNzItMS40NjgyLTEwLjQ5NiAzLjQzMjQtMTMuOTU4IDMuMzExNS0yLjMzOTIgOC4yMTQxLTIuNTI3MyAxMS41ODQtMC40NDQ0OCAxLjIwMyAwLjc0MzQ3IDEzLjMyNiAxMi43NTkgMjYuOTQxIDI2LjcwMmwyNC43NTQgMjUuMzV2NjcuMjk2aC00MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yNjMzMiAwIDAgLjI2MzMyIDEyLjg3OCAtOC44Njg4KSIgZmlsbD0icGFyYW0oZmlsbCkiIHN0cm9rZT0icGFyYW0ob3V0bGluZSkiIHN0cm9rZS13aWR0aD0icGFyYW0ob3V0bGluZS13aWR0aCkiPjxjaXJjbGUgY3g9IjI4My40NSIgY3k9IjEwNi4yNCIgcj0iNzIuNTYzIi8+PGcgZmlsbC1vcGFjaXR5PSJwYXJhbShmaWxsLW9wYWNpdHkpIiBzdHJva2Utb3BhY2l0eT0icGFyYW0ob3V0bGluZS1vcGFjaXR5KSI+PHBhdGggZD0ibTQ1NS42MyAzMDEuMDgtOTguMTE1LTk4LjI2OGMtOC4xMDctNy45NzQtMTcuMzM3LTEyLjc5OS0zMS4wMi0xMi43OTloLTg3LjA5NGMtMTMuNjgzIDAtMjIuMzA1IDQuOTc3LTMwLjE4MyAxMi43OTlsLTk3LjEyOCA5Ny4zMTVjLTI2LjU0NSAyNi41NDggOS4zNzUgNjAuNTI5IDM1Ljg3NyAzNC4wMjdsNTguNjYtNTkuMDQ5djU1LjM4NWgxNTIuOTV2LTU1LjY4OWw2MC4xOTggNjAuMzI0YzI0LjIzOSAyNS41MzEgNjEuMTI5LTguNzczIDM1Ljg1OC0zNC4wNDV6Ii8+PHBhdGggZD0ibTM1OS4yNiAzNTkuMjItNTcuNjQ1IDU3LjY0OSA0Mi4zMjIgNDIuMjQzLTQzLjM2NyA0My4zNjZjLTI1LjU5NCAyNS41OTcgOS43MTUgNjIuMjA1IDM2LjE4NCAzNS43MzZsNjguNTg1LTcxLjMxM2MxNC43MTktMTUuMDIxIDE4Ljc4OS00Mi43NjUgMy4wMDktNTguNTQ0LTAuMDU0LTAuMDUzLTQ5LjA4OC00OS4xMzctNDkuMDg4LTQ5LjEzN3oiLz48cGF0aCBkPSJtMjIxLjk2IDQ1OS4xMSA0Mi4zMjMtNDIuMjQzLTU3LjY0Ny01Ny42NDlzLTQ5LjAzMyA0OS4wODQtNDkuMDg2IDQ5LjEzOGMtMTUuNzggMTUuNzc5LTExLjcxIDQzLjUyMyAzLjAwOSA1OC41NDRsNjguNTg1IDcxLjMxM2MyNi40NjggMjYuNDY5IDYxLjc3Ny0xMC4xNCAzNi4xODMtMzUuNzM2eiIvPjwvZz48L2c+PHBhdGggZD0ibTEzMS44IDIwNS45NXYtMTQuNzM0bDE3LjI0Mi0yMi43NDZjOS40ODI5LTEyLjUxIDE5LjIzNy0yNS41NTcgMjEuNjc1LTI4Ljk5M2w0LjQzMzYtNi4yNDY4LTAuMDI1OC0zMy4xOWMtMC4wMzE1LTQwLjQ4My0wLjU4MzctNTUuMzY4LTIuMTczMS01OC41OC0yLjA3ODgtNC4yMDAzLTguNzgwOS02LjI1OTktMTMuNjI1LTQuMTg3MS0zLjIzNyAxLjM4NS01LjE2OTIgMy45NjE1LTUuOTQ5IDcuOTMyNi0wLjgxODgyIDQuMTctMS4wNzkzIDQyLjkxOS0wLjMxODQ5IDQ3LjM3MiAwLjQxOTM2IDIuNDU0MiAxLjA4NzIgMi41MTQ0IDIuNTY5MiAzLjgzNjUgMi4xNDE3IDEuOTEwOCA2LjcxMjggNS4zMjkzIDguMDY0NiA5LjE2ODUgMS4zMTIzIDMuNzI3MiAwLjcyOTE0IDkuMTQzNC0wLjUyNTU3IDExLjg0My0xLjM3MDggMi45NDkxLTEzLjcxNSAxNi40OTEtMjAuNDU3IDIyLjQ0MS00LjIyMTEgMy43MjU2LTUuMTE2OSA0LjI3MjItNi4xMjExIDMuNzM0Ny0wLjY0NzAzLTAuMzQ2MjctMS4xNzY0LTAuOTI5NTItMS4xNzY0LTEuMjk2MSAwLTAuODQ3NCAzLjcwOTctNS4yMDY3IDEzLjQ3Ni0xNS44MzYgNC4yNjYxLTQuNjQzIDguNDQzMS05LjQ3MTYgOS4yODIyLTEwLjczIDIuOTU4Mi00LjQzNzIgMS40NjgyLTEwLjQ5Ni0zLjQzMjQtMTMuOTU4LTMuMzExNS0yLjMzOTItOC4yMTQxLTIuNTI3My0xMS41ODQtMC40NDQ0OC0xLjIwMyAwLjc0MzQ3LTEzLjMyNiAxMi43NTktMjYuOTQxIDI2LjcwMmwtMjQuNzU0IDI1LjM1djY3LjI5Nmg0MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28295" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="44" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjM3LjE3OCIgaGVpZ2h0PSIzNy4xNzgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDM3LjE3OCAzNy4xNzgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjg1OTM4IC0xLjExNzIpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI1Ni4yODMiPgogIDxwYXRoIGQ9Im0xNy41MjEgMS4xMTcydjExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3Ny0wLjI2NTYyIDcuMzQwNSA3LjM0MDUgMCAwIDEgMS45Mjc3IDAuMjU3ODF2LTExLjUwOHptMCAyNS42NjR2MTEuNTE0aDMuODU1NXYtMTEuNTE0YTcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3IDAuMjY1NjIgNy4zNDA1IDcuMzQwNSAwIDAgMS0xLjkyNzctMC4yNjU2MnoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSg5MCkiIGQ9Im0xNy43NzktMC44NTkzOGgzLjg1NTV2LTExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxLTEuOTI3NyAwLjI2NzU4IDcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3LTAuMjY3NTh6bTAtMjUuNjdhNy4zNDA1IDcuMzQwNSAwIDAgMSAxLjkyNzctMC4yNTk3NiA3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3NyAwLjI2NTYydi0xMS41MTRoLTMuODU1NXoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSgzMCkiIGQ9Im0yNC43NjktMTEuMjQ3LTYuMDdlLTQgMTEuNTA3YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTYzLTQuNTQ5NGUtNGwtMC4wMDExLTExLjUwNnptLTMuNjllLTQgMjUuNjUyLTIuNzVlLTQgMTEuNTI3IDMuODU2My00LjU1ZS00IDcuOTllLTQgLTExLjUxOGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU2OC0wLjAwODN6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTMwKSIgZD0ibTguOTE3OCA4LjIwMjMtMy44NTYzLTQuNTQ5ZS00IDAuMDAxMjUgMTEuNTI1YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4LTAuMDA2NnptMy42ODhlLTQgMjUuNjUyYTcuMzQwNSA3LjM0MDUgMCAwIDEtMy44NTY4IDAuMDA4M2w3Ljk4N2UtNCAxMS41MTggMy44NTQ2LTUuMjJlLTR6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTYwKSIgZD0ibS01LjQxMzcgOC4xMDc1LTMuODU2MyA0LjU0OWUtNCAtNy45ODdlLTQgMTEuNTE4YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4IDAuMDA2NnptMS41NDVlLTQgMjUuNjZhNy4zNDA1IDcuMzQwNSAwIDAgMS0zLjg1NjgtMC4wMDgzbDAuMDAxNDIgMTEuNTI2IDMuODU0NiA1LjIyZS00eiIvPgogIDxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDYwKSIgZD0ibTI0Ljg2My0yNS41OCA2LjA3ZS00IDExLjUwN2E3LjM0MDUgNy4zNDA1IDAgMCAxIDMuODU1MyAwLjAwMjFsMy42OWUtNCAtMTEuNTA4em0tMS41NWUtNCAyNS42NiA3Ljk5ZS00IDExLjUxOCAzLjg1NDYtNS4yMmUtNCA0LjRlLTQgLTExLjUyNGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU1OCAwLjAwNjU3MjZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="45" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjMzLjQ4MiIgaGVpZ2h0PSIzNy42NjMiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMzLjQ4MiAzNy42NjMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8cGF0aCBkPSJtNy43MDMxIDE0LjY0OWExMS45MDYgMTEuOTA2IDAgMCAwLTcuNzAzMSAxMS4xMDcgMTEuOTA2IDExLjkwNiAwIDAgMCAxMS45MDYgMTEuOTA2IDExLjkwNiAxMS45MDYgMCAwIDAgMTEuOTA2LTExLjkwNiAxMS45MDYgMTEuOTA2IDAgMCAwLTAuMTIxMDktMS42ODE2aC0zLjgxMjVhOC4yNzc1IDguMjc3NSAwIDAgMSAwLjE2Nzk3IDEuNjQ2NSA4LjI3NzUgOC4yNzc1IDAgMCAxLTguMjc5MyA4LjI3NzMgOC4yNzc1IDguMjc3NSAwIDAgMS04LjI3NzMtOC4yNzczIDguMjc3NSA4LjI3NzUgMCAwIDEgNC4yMTI5LTcuMTg3NXoiLz4KIDxjaXJjbGUgY3g9IjExLjIzNCIgY3k9IjMuNzUyNCIgcj0iMy43NTI0Ii8+CiA8cGF0aCBkPSJtOS43MzYyIDE1LjYxaDEzLjUzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDczNCIvPgogPHBhdGggZD0ibTEwLjI5NiA0LjY5MjR2MTYuODc0aDE0LjQ3NWw0LjA4MDggMTMuMDQ5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMy4xNzUxIi8+CiA8cmVjdCB4PSI4LjcwODQiIHk9IjIwLjE4NCIgd2lkdGg9IjMuOTQxMSIgaGVpZ2h0PSIyLjk2NzIiIHJ5PSIwIi8+CiA8cGF0aCBkPSJtMjguODUyIDM0LjYxNSAxLjUxNTItMC40NjYzMSAzLjExNDktMC45ODY5NC0wLjQ1NjI4LTEuNjE1MS00LjY3ODQgMS40NTQ3eiIvPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.60054" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="46" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi44NG1tIiBoZWlnaHQ9IjY3Ljc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi44NCA2Ny43OSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDcuODA0IC04MS43ODQpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSIxODUuOTYiPjxwYXRoIGQ9Im0xMDIuODYgODEuNzg0djM4LjA0OGEyNC4yNTMgMjQuMjUzIDAgMCAxIDYuMzY5MS0wLjg3Nzk5IDI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjkxIDAuODUyMTV2LTM4LjAyMnoiLz48cGF0aCBkPSJtNDcuODA0IDEzNi44NHYxMi43MzloMzguMDQ4YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC44ODQwOC02LjM2OTMgMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg4NDA4LTYuMzY5M3ptODQuODE0IDBhMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg1ODI3IDYuMzY5MyAyNC4yNTMgMjQuMjUzIDAgMCAxLTAuODc3NjMgNi4zNjkzaDM4LjA0MXYtMTIuNzM5eiIvPjxwYXRoIGQ9Im0xMzQuNDIgODYuODMtMTkuMDExIDMyLjkyNGEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAzNSA2LjM2OTFsMTkuMDA1LTMyLjkyNHoiLz48cGF0aCBkPSJtODQuMDMyIDg2LjgzLTExLjAzNSA2LjM2OTEgMTkuMDQzIDMyLjk3NmEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAyMi02LjM4ODh6Ii8+PHBhdGggZD0ibTU5LjIxOSAxMDYuOTgtNi4zNjkxIDExLjAzNSAzMi45NTYgMTkuMDNhMjQuMjUzIDI0LjI1MyAwIDAgMSA2LjM4ODgtMTEuMDIyem03My40MjQgNDIuMzkxYTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY3IDAuMjA2MTloMC40MjM3NXoiLz48cGF0aCBkPSJtMTU5LjIzIDEwNi45OC0zMi45MjQgMTkuMDExYTI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjI5IDExLjAzNWwzMi45My0xOS4wMTF6bS03My40MjQgNDIuMzkxLTAuMzU3MDggMC4yMDYxOWgwLjQyMzc1YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY2Ni0wLjIwNjE5eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="47" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjcuM21tIiBoZWlnaHQ9IjcuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA3LjMgNy4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY3NSAtNzguNTIzKSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44MjYiIHk9Ijc4LjY3NCIgd2lkdGg9IjYuOTk4IiBoZWlnaHQ9IjYuOTk4IiByeT0iMS4yMTQyIiBzdHJva2Utd2lkdGg9Ii4zMDE5NyIvPgogIDxyZWN0IHg9IjYxLjMyNSIgeT0iNzkuMTczIiB3aWR0aD0iNiIgaGVpZ2h0PSI2IiByeT0iMS4wNDEiIHN0cm9rZS13aWR0aD0iLjMiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="7.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExOS4xNW1tIiBoZWlnaHQ9IjE0MC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTkuMTUgMTQwLjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4zNDIgLTY4LjU2NCkiPjxnPjxjaXJjbGUgY3g9IjE0NyIgY3k9IjEwMy43MSIgcj0iMTAuNTEiLz48cGF0aCBkPSJtMTM3LjIxIDExOS4zNWMtMS42NDQ3IDAtMi4yNTQ0IDAuMTcxMjgtMi44NTU2IDAuOTc4MDUtMC42NzMyMyAwLjkwMzM5LTAuMjU2ODggMi41OTgyLTAuMTM1MzggMy4zNzcybDQuNTIxNyAyOS4wMTdjMC4xNzU2MyAxLjEyNzItMC4yMDMzMyAyLjE2OTUtMC45MDc5NiAyLjk5NTJoMjMuMDgzYzIuNTEyNiAwIDQuOTExNS0yLjA1MTMgNC41MzU2LTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjMxLTQuNTM1Ni00LjUzNTYtNC41MzU2eiIvPjxwYXRoIGQ9Im0xNDAuNSAxNTEuNGMtMC42NjU4OCAwLTEuMzEyNSAwLjE0Mzg0LTEuODk5NiAwLjQwMDQ5bDAuMTM5NTMgMC45MjM0NmMwLjI4MDMzIDEuODUzLTAuOTgzMzQgMy40NjQ1LTIuNjg2MiA0LjE2NDFsNC4xODc5IDQ3LjQwNWMwLjIyMDkzIDIuNTAwNSAyLjAyMDggNC41MzE1IDQuNTMxIDQuNTMxNWg0LjQ2NzRjMi41MTAyIDAgNC4zMTEtMi4wMzEgNC41MzEtNC41MzE1bDQuMjU0NS00OC4zNjJjMC4yMTk5OS0yLjUwMDYtMi4wMjA4LTQuNTMxLTQuNTMxLTQuNTMxeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTY0LjgzNCA5My4xOThhMTAuNTEgMTAuNTEgMCAwIDAtMTAuNTEgMTAuNTEgMTAuNTEgMTAuNTEgMCAwIDAgOC41OTEyIDEwLjMxNWwtMC4xMzkwMS0wLjI1ODljLTMuMzE4My02LjE5NTctMS4wMDE3LTEzLjg1NSA1LjE5NC0xNy4xNzMgMS4wNTUyLTAuNTY1MTYgMi4xNTI5LTAuOTY2NDMgMy4yNjQ0LTEuMjEzNGExMC41MSAxMC41MSAwIDAgMC02LjQwMDYtMi4xNzkyeiIgc3Ryb2tlLXdpZHRoPSIuMTE0ODkiLz48cGF0aCBkPSJtNTUuMDQ2IDExOS4zNWMtMi41MTI2IDAtNC4xNTk4IDIuMDUwOC00LjUzNTYgNC41MzUxbC00LjEyOTUgMjcuMjk3Yy0wLjM3NTg2IDIuNDg0MyAyLjAyMjYgNC41MzUxIDQuNTM1MSA0LjUzNTFoMjcuODM2YzIuMTk5MSAwIDUuNTcxOS0wLjE0MDY4IDQuMjYxOS0yLjk5NjItNS4wMjYtMTAuOTU2LTE3LjI0NS0zMy4zNzEtMTcuMjQ1LTMzLjM3MXoiLz48cGF0aCBkPSJtNTguMzM3IDE1MS40aDEyLjk5NWMyLjUxMDIgMCA0Ljc1MSAyLjAzMDUgNC41MzEgNC41MzExbC00LjI1NDggNDguMzYyYy0wLjIxOTk5IDIuNTAwNi0yLjAyMDggNC41MzExLTQuNTMxIDQuNTMxMWgtNC40NjY5Yy0yLjUxMDIgMC00LjMxMDEtMi4wMzA2LTQuNTMxMS00LjUzMTFsLTQuMjczLTQ4LjM2MmMtMC4yMjA5My0yLjUwMDUgMi4wMjA5LTQuNTMxMSA0LjUzMTEtNC41MzExeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTEwMi40MiAxMTkuMzVoLTExLjg5OXY1LjUzMjdsOC44OTYyIDQuNjgyMXoiLz48Y2lyY2xlIGN4PSIxMDYuMzIiIGN5PSIxMDMuNzEiIHI9IjEwLjUxIi8+PHBhdGggZD0ibTk2LjUzMyAxMTkuMzVjLTIuNTEyNiAwLTQuMTU5MyAyLjA1MTMtNC41MzUxIDQuNTM1NmwxLjQ5MzYgOS43ODU0czAuNTAzMzcgMjIuMDQ3IDMuMzM1MiAyMi4wNDdsMjMuNDEyLTFlLTNjMi41MTI2LTEuMWUtNCA0LjkxMS0yLjA1MTMgNC41MzUxLTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjI2LTQuNTM1Ni00LjUzNTEtNC41MzU2eiIvPjxwYXRoIGQ9Im05OS44MjMgMTUxLjRoMTIuOTk1YzIuNTEwMiAwIDQuNzUxIDIuMDMwNSA0LjUzMSA0LjUzMTFsLTQuMjU0OCA0OC4zNjJjLTAuMjE5OTkgMi41MDA2LTIuMDIwOCA0LjUzMTEtNC41MzEgNC41MzExaC00LjQ2NjljLTIuNTEwMiAwLTQuMzEwMS0yLjAzMDYtNC41MzExLTQuNTMxMWwtNC4yNzMtNDguMzYyYy0wLjIyMDkzLTIuNTAwNSAyLjAyMDktNC41MzExIDQuNTMxMS00LjUzMTF6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIyLjc1MDUiLz48cmVjdCB0cmFuc2Zvcm09InJvdGF0ZSgtMjguMTczKSIgeD0iMTIuNjUxIiB5PSIxMjcuNTgiIHdpZHRoPSIxMS4yOTUiIGhlaWdodD0iNjIuMDg0IiByeT0iNC41MzExIi8+PHBhdGggZD0ibTk1LjI5MiAxNTUuOTMgMS4yODExLTEuMzk2Mi0xLjI5NjItNC41ODU4LTguMzk0NS0xNC41MjMiLz48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzLjY2MiI+PHBhdGggZD0ibTEwNi4zMiA3MC4zOTV2MTQuOTczIi8+PHBhdGggZD0ibTg1LjA2MyA3Ni4yNjUgNy40ODY3IDEyLjk2NyIvPjxwYXRoIGQ9Im0xMjcuNTggNzYuMjY1LTcuNDg2NyAxMi45NjciLz48L2c+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.58727" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.96" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="48" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="243,166,178,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="49" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3NS4wMyIgaGVpZ2h0PSIyMjAuNjgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NS4wMyAyMjAuNjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0ibTQzLjM1MSAyMDUuOTV2LTE0LjczNGwtMTcuMjQyLTIyLjc0NmMtOS40ODI5LTEyLjUxLTE5LjIzNy0yNS41NTctMjEuNjc1LTI4Ljk5M2wtNC40MzM2LTYuMjQ2OCAwLjAyNTgtMzMuMTljMC4wMzE1LTQwLjQ4MyAwLjU4MzctNTUuMzY4IDIuMTczMS01OC41OCAyLjA3ODgtNC4yMDAzIDguNzgwOS02LjI1OTkgMTMuNjI1LTQuMTg3MSAzLjIzNyAxLjM4NSA1LjE2OTIgMy45NjE1IDUuOTQ5IDcuOTMyNiAwLjgxODgyIDQuMTcgMS4wNzkzIDQyLjkxOSAwLjMxODQ5IDQ3LjM3Mi0wLjQxOTM2IDIuNDU0Mi0xLjA4NzIgMi41MTQ0LTIuNTY5MiAzLjgzNjUtMi4xNDE3IDEuOTEwOC02LjcxMjggNS4zMjkzLTguMDY0NiA5LjE2ODUtMS4zMTIzIDMuNzI3Mi0wLjcyOTE0IDkuMTQzNCAwLjUyNTU3IDExLjg0MyAxLjM3MDggMi45NDkxIDEzLjcxNSAxNi40OTEgMjAuNDU3IDIyLjQ0MSA0LjIyMTEgMy43MjU2IDUuMTE2OSA0LjI3MjIgNi4xMjExIDMuNzM0NyAwLjY0NzAzLTAuMzQ2MjcgMS4xNzY0LTAuOTI5NTIgMS4xNzY0LTEuMjk2MSAwLTAuODQ3NC0zLjcwOTctNS4yMDY3LTEzLjQ3Ni0xNS44MzYtNC4yNjYxLTQuNjQzLTguNDQzMS05LjQ3MTYtOS4yODIyLTEwLjczLTIuOTU4Mi00LjQzNzItMS40NjgyLTEwLjQ5NiAzLjQzMjQtMTMuOTU4IDMuMzExNS0yLjMzOTIgOC4yMTQxLTIuNTI3MyAxMS41ODQtMC40NDQ0OCAxLjIwMyAwLjc0MzQ3IDEzLjMyNiAxMi43NTkgMjYuOTQxIDI2LjcwMmwyNC43NTQgMjUuMzV2NjcuMjk2aC00MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yNjMzMiAwIDAgLjI2MzMyIDEyLjg3OCAtOC44Njg4KSIgZmlsbD0icGFyYW0oZmlsbCkiIHN0cm9rZT0icGFyYW0ob3V0bGluZSkiIHN0cm9rZS13aWR0aD0icGFyYW0ob3V0bGluZS13aWR0aCkiPjxjaXJjbGUgY3g9IjI4My40NSIgY3k9IjEwNi4yNCIgcj0iNzIuNTYzIi8+PGcgZmlsbC1vcGFjaXR5PSJwYXJhbShmaWxsLW9wYWNpdHkpIiBzdHJva2Utb3BhY2l0eT0icGFyYW0ob3V0bGluZS1vcGFjaXR5KSI+PHBhdGggZD0ibTQ1NS42MyAzMDEuMDgtOTguMTE1LTk4LjI2OGMtOC4xMDctNy45NzQtMTcuMzM3LTEyLjc5OS0zMS4wMi0xMi43OTloLTg3LjA5NGMtMTMuNjgzIDAtMjIuMzA1IDQuOTc3LTMwLjE4MyAxMi43OTlsLTk3LjEyOCA5Ny4zMTVjLTI2LjU0NSAyNi41NDggOS4zNzUgNjAuNTI5IDM1Ljg3NyAzNC4wMjdsNTguNjYtNTkuMDQ5djU1LjM4NWgxNTIuOTV2LTU1LjY4OWw2MC4xOTggNjAuMzI0YzI0LjIzOSAyNS41MzEgNjEuMTI5LTguNzczIDM1Ljg1OC0zNC4wNDV6Ii8+PHBhdGggZD0ibTM1OS4yNiAzNTkuMjItNTcuNjQ1IDU3LjY0OSA0Mi4zMjIgNDIuMjQzLTQzLjM2NyA0My4zNjZjLTI1LjU5NCAyNS41OTcgOS43MTUgNjIuMjA1IDM2LjE4NCAzNS43MzZsNjguNTg1LTcxLjMxM2MxNC43MTktMTUuMDIxIDE4Ljc4OS00Mi43NjUgMy4wMDktNTguNTQ0LTAuMDU0LTAuMDUzLTQ5LjA4OC00OS4xMzctNDkuMDg4LTQ5LjEzN3oiLz48cGF0aCBkPSJtMjIxLjk2IDQ1OS4xMSA0Mi4zMjMtNDIuMjQzLTU3LjY0Ny01Ny42NDlzLTQ5LjAzMyA0OS4wODQtNDkuMDg2IDQ5LjEzOGMtMTUuNzggMTUuNzc5LTExLjcxIDQzLjUyMyAzLjAwOSA1OC41NDRsNjguNTg1IDcxLjMxM2MyNi40NjggMjYuNDY5IDYxLjc3Ny0xMC4xNCAzNi4xODMtMzUuNzM2eiIvPjwvZz48L2c+PHBhdGggZD0ibTEzMS44IDIwNS45NXYtMTQuNzM0bDE3LjI0Mi0yMi43NDZjOS40ODI5LTEyLjUxIDE5LjIzNy0yNS41NTcgMjEuNjc1LTI4Ljk5M2w0LjQzMzYtNi4yNDY4LTAuMDI1OC0zMy4xOWMtMC4wMzE1LTQwLjQ4My0wLjU4MzctNTUuMzY4LTIuMTczMS01OC41OC0yLjA3ODgtNC4yMDAzLTguNzgwOS02LjI1OTktMTMuNjI1LTQuMTg3MS0zLjIzNyAxLjM4NS01LjE2OTIgMy45NjE1LTUuOTQ5IDcuOTMyNi0wLjgxODgyIDQuMTctMS4wNzkzIDQyLjkxOS0wLjMxODQ5IDQ3LjM3MiAwLjQxOTM2IDIuNDU0MiAxLjA4NzIgMi41MTQ0IDIuNTY5MiAzLjgzNjUgMi4xNDE3IDEuOTEwOCA2LjcxMjggNS4zMjkzIDguMDY0NiA5LjE2ODUgMS4zMTIzIDMuNzI3MiAwLjcyOTE0IDkuMTQzNC0wLjUyNTU3IDExLjg0My0xLjM3MDggMi45NDkxLTEzLjcxNSAxNi40OTEtMjAuNDU3IDIyLjQ0MS00LjIyMTEgMy43MjU2LTUuMTE2OSA0LjI3MjItNi4xMjExIDMuNzM0Ny0wLjY0NzAzLTAuMzQ2MjctMS4xNzY0LTAuOTI5NTItMS4xNzY0LTEuMjk2MSAwLTAuODQ3NCAzLjcwOTctNS4yMDY3IDEzLjQ3Ni0xNS44MzYgNC4yNjYxLTQuNjQzIDguNDQzMS05LjQ3MTYgOS4yODIyLTEwLjczIDIuOTU4Mi00LjQzNzIgMS40NjgyLTEwLjQ5Ni0zLjQzMjQtMTMuOTU4LTMuMzExNS0yLjMzOTItOC4yMTQxLTIuNTI3My0xMS41ODQtMC40NDQ0OC0xLjIwMyAwLjc0MzQ3LTEzLjMyNiAxMi43NTktMjYuOTQxIDI2LjcwMmwtMjQuNzU0IDI1LjM1djY3LjI5Nmg0MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28295" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExOS4xNW1tIiBoZWlnaHQ9IjE0MC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTkuMTUgMTQwLjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4zNDIgLTY4LjU2NCkiPjxnPjxjaXJjbGUgY3g9IjE0NyIgY3k9IjEwMy43MSIgcj0iMTAuNTEiLz48cGF0aCBkPSJtMTM3LjIxIDExOS4zNWMtMS42NDQ3IDAtMi4yNTQ0IDAuMTcxMjgtMi44NTU2IDAuOTc4MDUtMC42NzMyMyAwLjkwMzM5LTAuMjU2ODggMi41OTgyLTAuMTM1MzggMy4zNzcybDQuNTIxNyAyOS4wMTdjMC4xNzU2MyAxLjEyNzItMC4yMDMzMyAyLjE2OTUtMC45MDc5NiAyLjk5NTJoMjMuMDgzYzIuNTEyNiAwIDQuOTExNS0yLjA1MTMgNC41MzU2LTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjMxLTQuNTM1Ni00LjUzNTYtNC41MzU2eiIvPjxwYXRoIGQ9Im0xNDAuNSAxNTEuNGMtMC42NjU4OCAwLTEuMzEyNSAwLjE0Mzg0LTEuODk5NiAwLjQwMDQ5bDAuMTM5NTMgMC45MjM0NmMwLjI4MDMzIDEuODUzLTAuOTgzMzQgMy40NjQ1LTIuNjg2MiA0LjE2NDFsNC4xODc5IDQ3LjQwNWMwLjIyMDkzIDIuNTAwNSAyLjAyMDggNC41MzE1IDQuNTMxIDQuNTMxNWg0LjQ2NzRjMi41MTAyIDAgNC4zMTEtMi4wMzEgNC41MzEtNC41MzE1bDQuMjU0NS00OC4zNjJjMC4yMTk5OS0yLjUwMDYtMi4wMjA4LTQuNTMxLTQuNTMxLTQuNTMxeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTY0LjgzNCA5My4xOThhMTAuNTEgMTAuNTEgMCAwIDAtMTAuNTEgMTAuNTEgMTAuNTEgMTAuNTEgMCAwIDAgOC41OTEyIDEwLjMxNWwtMC4xMzkwMS0wLjI1ODljLTMuMzE4My02LjE5NTctMS4wMDE3LTEzLjg1NSA1LjE5NC0xNy4xNzMgMS4wNTUyLTAuNTY1MTYgMi4xNTI5LTAuOTY2NDMgMy4yNjQ0LTEuMjEzNGExMC41MSAxMC41MSAwIDAgMC02LjQwMDYtMi4xNzkyeiIgc3Ryb2tlLXdpZHRoPSIuMTE0ODkiLz48cGF0aCBkPSJtNTUuMDQ2IDExOS4zNWMtMi41MTI2IDAtNC4xNTk4IDIuMDUwOC00LjUzNTYgNC41MzUxbC00LjEyOTUgMjcuMjk3Yy0wLjM3NTg2IDIuNDg0MyAyLjAyMjYgNC41MzUxIDQuNTM1MSA0LjUzNTFoMjcuODM2YzIuMTk5MSAwIDUuNTcxOS0wLjE0MDY4IDQuMjYxOS0yLjk5NjItNS4wMjYtMTAuOTU2LTE3LjI0NS0zMy4zNzEtMTcuMjQ1LTMzLjM3MXoiLz48cGF0aCBkPSJtNTguMzM3IDE1MS40aDEyLjk5NWMyLjUxMDIgMCA0Ljc1MSAyLjAzMDUgNC41MzEgNC41MzExbC00LjI1NDggNDguMzYyYy0wLjIxOTk5IDIuNTAwNi0yLjAyMDggNC41MzExLTQuNTMxIDQuNTMxMWgtNC40NjY5Yy0yLjUxMDIgMC00LjMxMDEtMi4wMzA2LTQuNTMxMS00LjUzMTFsLTQuMjczLTQ4LjM2MmMtMC4yMjA5My0yLjUwMDUgMi4wMjA5LTQuNTMxMSA0LjUzMTEtNC41MzExeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTEwMi40MiAxMTkuMzVoLTExLjg5OXY1LjUzMjdsOC44OTYyIDQuNjgyMXoiLz48Y2lyY2xlIGN4PSIxMDYuMzIiIGN5PSIxMDMuNzEiIHI9IjEwLjUxIi8+PHBhdGggZD0ibTk2LjUzMyAxMTkuMzVjLTIuNTEyNiAwLTQuMTU5MyAyLjA1MTMtNC41MzUxIDQuNTM1NmwxLjQ5MzYgOS43ODU0czAuNTAzMzcgMjIuMDQ3IDMuMzM1MiAyMi4wNDdsMjMuNDEyLTFlLTNjMi41MTI2LTEuMWUtNCA0LjkxMS0yLjA1MTMgNC41MzUxLTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjI2LTQuNTM1Ni00LjUzNTEtNC41MzU2eiIvPjxwYXRoIGQ9Im05OS44MjMgMTUxLjRoMTIuOTk1YzIuNTEwMiAwIDQuNzUxIDIuMDMwNSA0LjUzMSA0LjUzMTFsLTQuMjU0OCA0OC4zNjJjLTAuMjE5OTkgMi41MDA2LTIuMDIwOCA0LjUzMTEtNC41MzEgNC41MzExaC00LjQ2NjljLTIuNTEwMiAwLTQuMzEwMS0yLjAzMDYtNC41MzExLTQuNTMxMWwtNC4yNzMtNDguMzYyYy0wLjIyMDkzLTIuNTAwNSAyLjAyMDktNC41MzExIDQuNTMxMS00LjUzMTF6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIyLjc1MDUiLz48cmVjdCB0cmFuc2Zvcm09InJvdGF0ZSgtMjguMTczKSIgeD0iMTIuNjUxIiB5PSIxMjcuNTgiIHdpZHRoPSIxMS4yOTUiIGhlaWdodD0iNjIuMDg0IiByeT0iNC41MzExIi8+PHBhdGggZD0ibTk1LjI5MiAxNTUuOTMgMS4yODExLTEuMzk2Mi0xLjI5NjItNC41ODU4LTguMzk0NS0xNC41MjMiLz48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzLjY2MiI+PHBhdGggZD0ibTEwNi4zMiA3MC4zOTV2MTQuOTczIi8+PHBhdGggZD0ibTg1LjA2MyA3Ni4yNjUgNy40ODY3IDEyLjk2NyIvPjxwYXRoIGQ9Im0xMjcuNTggNzYuMjY1LTcuNDg2NyAxMi45NjciLz48L2c+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.58727" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="50" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjM3LjE3OCIgaGVpZ2h0PSIzNy4xNzgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDM3LjE3OCAzNy4xNzgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjg1OTM4IC0xLjExNzIpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI1Ni4yODMiPgogIDxwYXRoIGQ9Im0xNy41MjEgMS4xMTcydjExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3Ny0wLjI2NTYyIDcuMzQwNSA3LjM0MDUgMCAwIDEgMS45Mjc3IDAuMjU3ODF2LTExLjUwOHptMCAyNS42NjR2MTEuNTE0aDMuODU1NXYtMTEuNTE0YTcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3IDAuMjY1NjIgNy4zNDA1IDcuMzQwNSAwIDAgMS0xLjkyNzctMC4yNjU2MnoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSg5MCkiIGQ9Im0xNy43NzktMC44NTkzOGgzLjg1NTV2LTExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxLTEuOTI3NyAwLjI2NzU4IDcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3LTAuMjY3NTh6bTAtMjUuNjdhNy4zNDA1IDcuMzQwNSAwIDAgMSAxLjkyNzctMC4yNTk3NiA3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3NyAwLjI2NTYydi0xMS41MTRoLTMuODU1NXoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSgzMCkiIGQ9Im0yNC43NjktMTEuMjQ3LTYuMDdlLTQgMTEuNTA3YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTYzLTQuNTQ5NGUtNGwtMC4wMDExLTExLjUwNnptLTMuNjllLTQgMjUuNjUyLTIuNzVlLTQgMTEuNTI3IDMuODU2My00LjU1ZS00IDcuOTllLTQgLTExLjUxOGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU2OC0wLjAwODN6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTMwKSIgZD0ibTguOTE3OCA4LjIwMjMtMy44NTYzLTQuNTQ5ZS00IDAuMDAxMjUgMTEuNTI1YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4LTAuMDA2NnptMy42ODhlLTQgMjUuNjUyYTcuMzQwNSA3LjM0MDUgMCAwIDEtMy44NTY4IDAuMDA4M2w3Ljk4N2UtNCAxMS41MTggMy44NTQ2LTUuMjJlLTR6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTYwKSIgZD0ibS01LjQxMzcgOC4xMDc1LTMuODU2MyA0LjU0OWUtNCAtNy45ODdlLTQgMTEuNTE4YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4IDAuMDA2NnptMS41NDVlLTQgMjUuNjZhNy4zNDA1IDcuMzQwNSAwIDAgMS0zLjg1NjgtMC4wMDgzbDAuMDAxNDIgMTEuNTI2IDMuODU0NiA1LjIyZS00eiIvPgogIDxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDYwKSIgZD0ibTI0Ljg2My0yNS41OCA2LjA3ZS00IDExLjUwN2E3LjM0MDUgNy4zNDA1IDAgMCAxIDMuODU1MyAwLjAwMjFsMy42OWUtNCAtMTEuNTA4em0tMS41NWUtNCAyNS42NiA3Ljk5ZS00IDExLjUxOCAzLjg1NDYtNS4yMmUtNCA0LjRlLTQgLTExLjUyNGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU1OCAwLjAwNjU3MjZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="51" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjMzLjQ4MiIgaGVpZ2h0PSIzNy42NjMiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMzLjQ4MiAzNy42NjMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8cGF0aCBkPSJtNy43MDMxIDE0LjY0OWExMS45MDYgMTEuOTA2IDAgMCAwLTcuNzAzMSAxMS4xMDcgMTEuOTA2IDExLjkwNiAwIDAgMCAxMS45MDYgMTEuOTA2IDExLjkwNiAxMS45MDYgMCAwIDAgMTEuOTA2LTExLjkwNiAxMS45MDYgMTEuOTA2IDAgMCAwLTAuMTIxMDktMS42ODE2aC0zLjgxMjVhOC4yNzc1IDguMjc3NSAwIDAgMSAwLjE2Nzk3IDEuNjQ2NSA4LjI3NzUgOC4yNzc1IDAgMCAxLTguMjc5MyA4LjI3NzMgOC4yNzc1IDguMjc3NSAwIDAgMS04LjI3NzMtOC4yNzczIDguMjc3NSA4LjI3NzUgMCAwIDEgNC4yMTI5LTcuMTg3NXoiLz4KIDxjaXJjbGUgY3g9IjExLjIzNCIgY3k9IjMuNzUyNCIgcj0iMy43NTI0Ii8+CiA8cGF0aCBkPSJtOS43MzYyIDE1LjYxaDEzLjUzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDczNCIvPgogPHBhdGggZD0ibTEwLjI5NiA0LjY5MjR2MTYuODc0aDE0LjQ3NWw0LjA4MDggMTMuMDQ5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMy4xNzUxIi8+CiA8cmVjdCB4PSI4LjcwODQiIHk9IjIwLjE4NCIgd2lkdGg9IjMuOTQxMSIgaGVpZ2h0PSIyLjk2NzIiIHJ5PSIwIi8+CiA8cGF0aCBkPSJtMjguODUyIDM0LjYxNSAxLjUxNTItMC40NjYzMSAzLjExNDktMC45ODY5NC0wLjQ1NjI4LTEuNjE1MS00LjY3ODQgMS40NTQ3eiIvPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.60054" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="52" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi44NG1tIiBoZWlnaHQ9IjY3Ljc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi44NCA2Ny43OSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDcuODA0IC04MS43ODQpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSIxODUuOTYiPjxwYXRoIGQ9Im0xMDIuODYgODEuNzg0djM4LjA0OGEyNC4yNTMgMjQuMjUzIDAgMCAxIDYuMzY5MS0wLjg3Nzk5IDI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjkxIDAuODUyMTV2LTM4LjAyMnoiLz48cGF0aCBkPSJtNDcuODA0IDEzNi44NHYxMi43MzloMzguMDQ4YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC44ODQwOC02LjM2OTMgMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg4NDA4LTYuMzY5M3ptODQuODE0IDBhMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg1ODI3IDYuMzY5MyAyNC4yNTMgMjQuMjUzIDAgMCAxLTAuODc3NjMgNi4zNjkzaDM4LjA0MXYtMTIuNzM5eiIvPjxwYXRoIGQ9Im0xMzQuNDIgODYuODMtMTkuMDExIDMyLjkyNGEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAzNSA2LjM2OTFsMTkuMDA1LTMyLjkyNHoiLz48cGF0aCBkPSJtODQuMDMyIDg2LjgzLTExLjAzNSA2LjM2OTEgMTkuMDQzIDMyLjk3NmEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAyMi02LjM4ODh6Ii8+PHBhdGggZD0ibTU5LjIxOSAxMDYuOTgtNi4zNjkxIDExLjAzNSAzMi45NTYgMTkuMDNhMjQuMjUzIDI0LjI1MyAwIDAgMSA2LjM4ODgtMTEuMDIyem03My40MjQgNDIuMzkxYTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY3IDAuMjA2MTloMC40MjM3NXoiLz48cGF0aCBkPSJtMTU5LjIzIDEwNi45OC0zMi45MjQgMTkuMDExYTI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjI5IDExLjAzNWwzMi45My0xOS4wMTF6bS03My40MjQgNDIuMzkxLTAuMzU3MDggMC4yMDYxOWgwLjQyMzc1YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY2Ni0wLjIwNjE5eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="53" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExOS4xNW1tIiBoZWlnaHQ9IjE0MC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTkuMTUgMTQwLjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4zNDIgLTY4LjU2NCkiPjxnPjxjaXJjbGUgY3g9IjE0NyIgY3k9IjEwMy43MSIgcj0iMTAuNTEiLz48cGF0aCBkPSJtMTM3LjIxIDExOS4zNWMtMS42NDQ3IDAtMi4yNTQ0IDAuMTcxMjgtMi44NTU2IDAuOTc4MDUtMC42NzMyMyAwLjkwMzM5LTAuMjU2ODggMi41OTgyLTAuMTM1MzggMy4zNzcybDQuNTIxNyAyOS4wMTdjMC4xNzU2MyAxLjEyNzItMC4yMDMzMyAyLjE2OTUtMC45MDc5NiAyLjk5NTJoMjMuMDgzYzIuNTEyNiAwIDQuOTExNS0yLjA1MTMgNC41MzU2LTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjMxLTQuNTM1Ni00LjUzNTYtNC41MzU2eiIvPjxwYXRoIGQ9Im0xNDAuNSAxNTEuNGMtMC42NjU4OCAwLTEuMzEyNSAwLjE0Mzg0LTEuODk5NiAwLjQwMDQ5bDAuMTM5NTMgMC45MjM0NmMwLjI4MDMzIDEuODUzLTAuOTgzMzQgMy40NjQ1LTIuNjg2MiA0LjE2NDFsNC4xODc5IDQ3LjQwNWMwLjIyMDkzIDIuNTAwNSAyLjAyMDggNC41MzE1IDQuNTMxIDQuNTMxNWg0LjQ2NzRjMi41MTAyIDAgNC4zMTEtMi4wMzEgNC41MzEtNC41MzE1bDQuMjU0NS00OC4zNjJjMC4yMTk5OS0yLjUwMDYtMi4wMjA4LTQuNTMxLTQuNTMxLTQuNTMxeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTY0LjgzNCA5My4xOThhMTAuNTEgMTAuNTEgMCAwIDAtMTAuNTEgMTAuNTEgMTAuNTEgMTAuNTEgMCAwIDAgOC41OTEyIDEwLjMxNWwtMC4xMzkwMS0wLjI1ODljLTMuMzE4My02LjE5NTctMS4wMDE3LTEzLjg1NSA1LjE5NC0xNy4xNzMgMS4wNTUyLTAuNTY1MTYgMi4xNTI5LTAuOTY2NDMgMy4yNjQ0LTEuMjEzNGExMC41MSAxMC41MSAwIDAgMC02LjQwMDYtMi4xNzkyeiIgc3Ryb2tlLXdpZHRoPSIuMTE0ODkiLz48cGF0aCBkPSJtNTUuMDQ2IDExOS4zNWMtMi41MTI2IDAtNC4xNTk4IDIuMDUwOC00LjUzNTYgNC41MzUxbC00LjEyOTUgMjcuMjk3Yy0wLjM3NTg2IDIuNDg0MyAyLjAyMjYgNC41MzUxIDQuNTM1MSA0LjUzNTFoMjcuODM2YzIuMTk5MSAwIDUuNTcxOS0wLjE0MDY4IDQuMjYxOS0yLjk5NjItNS4wMjYtMTAuOTU2LTE3LjI0NS0zMy4zNzEtMTcuMjQ1LTMzLjM3MXoiLz48cGF0aCBkPSJtNTguMzM3IDE1MS40aDEyLjk5NWMyLjUxMDIgMCA0Ljc1MSAyLjAzMDUgNC41MzEgNC41MzExbC00LjI1NDggNDguMzYyYy0wLjIxOTk5IDIuNTAwNi0yLjAyMDggNC41MzExLTQuNTMxIDQuNTMxMWgtNC40NjY5Yy0yLjUxMDIgMC00LjMxMDEtMi4wMzA2LTQuNTMxMS00LjUzMTFsLTQuMjczLTQ4LjM2MmMtMC4yMjA5My0yLjUwMDUgMi4wMjA5LTQuNTMxMSA0LjUzMTEtNC41MzExeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTEwMi40MiAxMTkuMzVoLTExLjg5OXY1LjUzMjdsOC44OTYyIDQuNjgyMXoiLz48Y2lyY2xlIGN4PSIxMDYuMzIiIGN5PSIxMDMuNzEiIHI9IjEwLjUxIi8+PHBhdGggZD0ibTk2LjUzMyAxMTkuMzVjLTIuNTEyNiAwLTQuMTU5MyAyLjA1MTMtNC41MzUxIDQuNTM1NmwxLjQ5MzYgOS43ODU0czAuNTAzMzcgMjIuMDQ3IDMuMzM1MiAyMi4wNDdsMjMuNDEyLTFlLTNjMi41MTI2LTEuMWUtNCA0LjkxMS0yLjA1MTMgNC41MzUxLTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjI2LTQuNTM1Ni00LjUzNTEtNC41MzU2eiIvPjxwYXRoIGQ9Im05OS44MjMgMTUxLjRoMTIuOTk1YzIuNTEwMiAwIDQuNzUxIDIuMDMwNSA0LjUzMSA0LjUzMTFsLTQuMjU0OCA0OC4zNjJjLTAuMjE5OTkgMi41MDA2LTIuMDIwOCA0LjUzMTEtNC41MzEgNC41MzExaC00LjQ2NjljLTIuNTEwMiAwLTQuMzEwMS0yLjAzMDYtNC41MzExLTQuNTMxMWwtNC4yNzMtNDguMzYyYy0wLjIyMDkzLTIuNTAwNSAyLjAyMDktNC41MzExIDQuNTMxMS00LjUzMTF6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIyLjc1MDUiLz48cmVjdCB0cmFuc2Zvcm09InJvdGF0ZSgtMjguMTczKSIgeD0iMTIuNjUxIiB5PSIxMjcuNTgiIHdpZHRoPSIxMS4yOTUiIGhlaWdodD0iNjIuMDg0IiByeT0iNC41MzExIi8+PHBhdGggZD0ibTk1LjI5MiAxNTUuOTMgMS4yODExLTEuMzk2Mi0xLjI5NjItNC41ODU4LTguMzk0NS0xNC41MjMiLz48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzLjY2MiI+PHBhdGggZD0ibTEwNi4zMiA3MC4zOTV2MTQuOTczIi8+PHBhdGggZD0ibTg1LjA2MyA3Ni4yNjUgNy40ODY3IDEyLjk2NyIvPjxwYXRoIGQ9Im0xMjcuNTggNzYuMjY1LTcuNDg2NyAxMi45NjciLz48L2c+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.58727" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="54" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="55" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3NS4wMyIgaGVpZ2h0PSIyMjAuNjgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NS4wMyAyMjAuNjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0ibTQzLjM1MSAyMDUuOTV2LTE0LjczNGwtMTcuMjQyLTIyLjc0NmMtOS40ODI5LTEyLjUxLTE5LjIzNy0yNS41NTctMjEuNjc1LTI4Ljk5M2wtNC40MzM2LTYuMjQ2OCAwLjAyNTgtMzMuMTljMC4wMzE1LTQwLjQ4MyAwLjU4MzctNTUuMzY4IDIuMTczMS01OC41OCAyLjA3ODgtNC4yMDAzIDguNzgwOS02LjI1OTkgMTMuNjI1LTQuMTg3MSAzLjIzNyAxLjM4NSA1LjE2OTIgMy45NjE1IDUuOTQ5IDcuOTMyNiAwLjgxODgyIDQuMTcgMS4wNzkzIDQyLjkxOSAwLjMxODQ5IDQ3LjM3Mi0wLjQxOTM2IDIuNDU0Mi0xLjA4NzIgMi41MTQ0LTIuNTY5MiAzLjgzNjUtMi4xNDE3IDEuOTEwOC02LjcxMjggNS4zMjkzLTguMDY0NiA5LjE2ODUtMS4zMTIzIDMuNzI3Mi0wLjcyOTE0IDkuMTQzNCAwLjUyNTU3IDExLjg0MyAxLjM3MDggMi45NDkxIDEzLjcxNSAxNi40OTEgMjAuNDU3IDIyLjQ0MSA0LjIyMTEgMy43MjU2IDUuMTE2OSA0LjI3MjIgNi4xMjExIDMuNzM0NyAwLjY0NzAzLTAuMzQ2MjcgMS4xNzY0LTAuOTI5NTIgMS4xNzY0LTEuMjk2MSAwLTAuODQ3NC0zLjcwOTctNS4yMDY3LTEzLjQ3Ni0xNS44MzYtNC4yNjYxLTQuNjQzLTguNDQzMS05LjQ3MTYtOS4yODIyLTEwLjczLTIuOTU4Mi00LjQzNzItMS40NjgyLTEwLjQ5NiAzLjQzMjQtMTMuOTU4IDMuMzExNS0yLjMzOTIgOC4yMTQxLTIuNTI3MyAxMS41ODQtMC40NDQ0OCAxLjIwMyAwLjc0MzQ3IDEzLjMyNiAxMi43NTkgMjYuOTQxIDI2LjcwMmwyNC43NTQgMjUuMzV2NjcuMjk2aC00MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yNjMzMiAwIDAgLjI2MzMyIDEyLjg3OCAtOC44Njg4KSIgZmlsbD0icGFyYW0oZmlsbCkiIHN0cm9rZT0icGFyYW0ob3V0bGluZSkiIHN0cm9rZS13aWR0aD0icGFyYW0ob3V0bGluZS13aWR0aCkiPjxjaXJjbGUgY3g9IjI4My40NSIgY3k9IjEwNi4yNCIgcj0iNzIuNTYzIi8+PGcgZmlsbC1vcGFjaXR5PSJwYXJhbShmaWxsLW9wYWNpdHkpIiBzdHJva2Utb3BhY2l0eT0icGFyYW0ob3V0bGluZS1vcGFjaXR5KSI+PHBhdGggZD0ibTQ1NS42MyAzMDEuMDgtOTguMTE1LTk4LjI2OGMtOC4xMDctNy45NzQtMTcuMzM3LTEyLjc5OS0zMS4wMi0xMi43OTloLTg3LjA5NGMtMTMuNjgzIDAtMjIuMzA1IDQuOTc3LTMwLjE4MyAxMi43OTlsLTk3LjEyOCA5Ny4zMTVjLTI2LjU0NSAyNi41NDggOS4zNzUgNjAuNTI5IDM1Ljg3NyAzNC4wMjdsNTguNjYtNTkuMDQ5djU1LjM4NWgxNTIuOTV2LTU1LjY4OWw2MC4xOTggNjAuMzI0YzI0LjIzOSAyNS41MzEgNjEuMTI5LTguNzczIDM1Ljg1OC0zNC4wNDV6Ii8+PHBhdGggZD0ibTM1OS4yNiAzNTkuMjItNTcuNjQ1IDU3LjY0OSA0Mi4zMjIgNDIuMjQzLTQzLjM2NyA0My4zNjZjLTI1LjU5NCAyNS41OTcgOS43MTUgNjIuMjA1IDM2LjE4NCAzNS43MzZsNjguNTg1LTcxLjMxM2MxNC43MTktMTUuMDIxIDE4Ljc4OS00Mi43NjUgMy4wMDktNTguNTQ0LTAuMDU0LTAuMDUzLTQ5LjA4OC00OS4xMzctNDkuMDg4LTQ5LjEzN3oiLz48cGF0aCBkPSJtMjIxLjk2IDQ1OS4xMSA0Mi4zMjMtNDIuMjQzLTU3LjY0Ny01Ny42NDlzLTQ5LjAzMyA0OS4wODQtNDkuMDg2IDQ5LjEzOGMtMTUuNzggMTUuNzc5LTExLjcxIDQzLjUyMyAzLjAwOSA1OC41NDRsNjguNTg1IDcxLjMxM2MyNi40NjggMjYuNDY5IDYxLjc3Ny0xMC4xNCAzNi4xODMtMzUuNzM2eiIvPjwvZz48L2c+PHBhdGggZD0ibTEzMS44IDIwNS45NXYtMTQuNzM0bDE3LjI0Mi0yMi43NDZjOS40ODI5LTEyLjUxIDE5LjIzNy0yNS41NTcgMjEuNjc1LTI4Ljk5M2w0LjQzMzYtNi4yNDY4LTAuMDI1OC0zMy4xOWMtMC4wMzE1LTQwLjQ4My0wLjU4MzctNTUuMzY4LTIuMTczMS01OC41OC0yLjA3ODgtNC4yMDAzLTguNzgwOS02LjI1OTktMTMuNjI1LTQuMTg3MS0zLjIzNyAxLjM4NS01LjE2OTIgMy45NjE1LTUuOTQ5IDcuOTMyNi0wLjgxODgyIDQuMTctMS4wNzkzIDQyLjkxOS0wLjMxODQ5IDQ3LjM3MiAwLjQxOTM2IDIuNDU0MiAxLjA4NzIgMi41MTQ0IDIuNTY5MiAzLjgzNjUgMi4xNDE3IDEuOTEwOCA2LjcxMjggNS4zMjkzIDguMDY0NiA5LjE2ODUgMS4zMTIzIDMuNzI3MiAwLjcyOTE0IDkuMTQzNC0wLjUyNTU3IDExLjg0My0xLjM3MDggMi45NDkxLTEzLjcxNSAxNi40OTEtMjAuNDU3IDIyLjQ0MS00LjIyMTEgMy43MjU2LTUuMTE2OSA0LjI3MjItNi4xMjExIDMuNzM0Ny0wLjY0NzAzLTAuMzQ2MjctMS4xNzY0LTAuOTI5NTItMS4xNzY0LTEuMjk2MSAwLTAuODQ3NCAzLjcwOTctNS4yMDY3IDEzLjQ3Ni0xNS44MzYgNC4yNjYxLTQuNjQzIDguNDQzMS05LjQ3MTYgOS4yODIyLTEwLjczIDIuOTU4Mi00LjQzNzIgMS40NjgyLTEwLjQ5Ni0zLjQzMjQtMTMuOTU4LTMuMzExNS0yLjMzOTItOC4yMTQxLTIuNTI3My0xMS41ODQtMC40NDQ0OC0xLjIwMyAwLjc0MzQ3LTEzLjMyNiAxMi43NTktMjYuOTQxIDI2LjcwMmwtMjQuNzU0IDI1LjM1djY3LjI5Nmg0MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28295" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="56" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjM3LjE3OCIgaGVpZ2h0PSIzNy4xNzgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDM3LjE3OCAzNy4xNzgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjg1OTM4IC0xLjExNzIpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI1Ni4yODMiPgogIDxwYXRoIGQ9Im0xNy41MjEgMS4xMTcydjExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3Ny0wLjI2NTYyIDcuMzQwNSA3LjM0MDUgMCAwIDEgMS45Mjc3IDAuMjU3ODF2LTExLjUwOHptMCAyNS42NjR2MTEuNTE0aDMuODU1NXYtMTEuNTE0YTcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3IDAuMjY1NjIgNy4zNDA1IDcuMzQwNSAwIDAgMS0xLjkyNzctMC4yNjU2MnoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSg5MCkiIGQ9Im0xNy43NzktMC44NTkzOGgzLjg1NTV2LTExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxLTEuOTI3NyAwLjI2NzU4IDcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3LTAuMjY3NTh6bTAtMjUuNjdhNy4zNDA1IDcuMzQwNSAwIDAgMSAxLjkyNzctMC4yNTk3NiA3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3NyAwLjI2NTYydi0xMS41MTRoLTMuODU1NXoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSgzMCkiIGQ9Im0yNC43NjktMTEuMjQ3LTYuMDdlLTQgMTEuNTA3YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTYzLTQuNTQ5NGUtNGwtMC4wMDExLTExLjUwNnptLTMuNjllLTQgMjUuNjUyLTIuNzVlLTQgMTEuNTI3IDMuODU2My00LjU1ZS00IDcuOTllLTQgLTExLjUxOGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU2OC0wLjAwODN6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTMwKSIgZD0ibTguOTE3OCA4LjIwMjMtMy44NTYzLTQuNTQ5ZS00IDAuMDAxMjUgMTEuNTI1YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4LTAuMDA2NnptMy42ODhlLTQgMjUuNjUyYTcuMzQwNSA3LjM0MDUgMCAwIDEtMy44NTY4IDAuMDA4M2w3Ljk4N2UtNCAxMS41MTggMy44NTQ2LTUuMjJlLTR6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTYwKSIgZD0ibS01LjQxMzcgOC4xMDc1LTMuODU2MyA0LjU0OWUtNCAtNy45ODdlLTQgMTEuNTE4YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4IDAuMDA2NnptMS41NDVlLTQgMjUuNjZhNy4zNDA1IDcuMzQwNSAwIDAgMS0zLjg1NjgtMC4wMDgzbDAuMDAxNDIgMTEuNTI2IDMuODU0NiA1LjIyZS00eiIvPgogIDxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDYwKSIgZD0ibTI0Ljg2My0yNS41OCA2LjA3ZS00IDExLjUwN2E3LjM0MDUgNy4zNDA1IDAgMCAxIDMuODU1MyAwLjAwMjFsMy42OWUtNCAtMTEuNTA4em0tMS41NWUtNCAyNS42NiA3Ljk5ZS00IDExLjUxOCAzLjg1NDYtNS4yMmUtNCA0LjRlLTQgLTExLjUyNGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU1OCAwLjAwNjU3MjZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="57" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjMzLjQ4MiIgaGVpZ2h0PSIzNy42NjMiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMzLjQ4MiAzNy42NjMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8cGF0aCBkPSJtNy43MDMxIDE0LjY0OWExMS45MDYgMTEuOTA2IDAgMCAwLTcuNzAzMSAxMS4xMDcgMTEuOTA2IDExLjkwNiAwIDAgMCAxMS45MDYgMTEuOTA2IDExLjkwNiAxMS45MDYgMCAwIDAgMTEuOTA2LTExLjkwNiAxMS45MDYgMTEuOTA2IDAgMCAwLTAuMTIxMDktMS42ODE2aC0zLjgxMjVhOC4yNzc1IDguMjc3NSAwIDAgMSAwLjE2Nzk3IDEuNjQ2NSA4LjI3NzUgOC4yNzc1IDAgMCAxLTguMjc5MyA4LjI3NzMgOC4yNzc1IDguMjc3NSAwIDAgMS04LjI3NzMtOC4yNzczIDguMjc3NSA4LjI3NzUgMCAwIDEgNC4yMTI5LTcuMTg3NXoiLz4KIDxjaXJjbGUgY3g9IjExLjIzNCIgY3k9IjMuNzUyNCIgcj0iMy43NTI0Ii8+CiA8cGF0aCBkPSJtOS43MzYyIDE1LjYxaDEzLjUzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDczNCIvPgogPHBhdGggZD0ibTEwLjI5NiA0LjY5MjR2MTYuODc0aDE0LjQ3NWw0LjA4MDggMTMuMDQ5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMy4xNzUxIi8+CiA8cmVjdCB4PSI4LjcwODQiIHk9IjIwLjE4NCIgd2lkdGg9IjMuOTQxMSIgaGVpZ2h0PSIyLjk2NzIiIHJ5PSIwIi8+CiA8cGF0aCBkPSJtMjguODUyIDM0LjYxNSAxLjUxNTItMC40NjYzMSAzLjExNDktMC45ODY5NC0wLjQ1NjI4LTEuNjE1MS00LjY3ODQgMS40NTQ3eiIvPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.60054" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="58" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi44NG1tIiBoZWlnaHQ9IjY3Ljc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi44NCA2Ny43OSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDcuODA0IC04MS43ODQpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSIxODUuOTYiPjxwYXRoIGQ9Im0xMDIuODYgODEuNzg0djM4LjA0OGEyNC4yNTMgMjQuMjUzIDAgMCAxIDYuMzY5MS0wLjg3Nzk5IDI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjkxIDAuODUyMTV2LTM4LjAyMnoiLz48cGF0aCBkPSJtNDcuODA0IDEzNi44NHYxMi43MzloMzguMDQ4YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC44ODQwOC02LjM2OTMgMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg4NDA4LTYuMzY5M3ptODQuODE0IDBhMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg1ODI3IDYuMzY5MyAyNC4yNTMgMjQuMjUzIDAgMCAxLTAuODc3NjMgNi4zNjkzaDM4LjA0MXYtMTIuNzM5eiIvPjxwYXRoIGQ9Im0xMzQuNDIgODYuODMtMTkuMDExIDMyLjkyNGEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAzNSA2LjM2OTFsMTkuMDA1LTMyLjkyNHoiLz48cGF0aCBkPSJtODQuMDMyIDg2LjgzLTExLjAzNSA2LjM2OTEgMTkuMDQzIDMyLjk3NmEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAyMi02LjM4ODh6Ii8+PHBhdGggZD0ibTU5LjIxOSAxMDYuOTgtNi4zNjkxIDExLjAzNSAzMi45NTYgMTkuMDNhMjQuMjUzIDI0LjI1MyAwIDAgMSA2LjM4ODgtMTEuMDIyem03My40MjQgNDIuMzkxYTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY3IDAuMjA2MTloMC40MjM3NXoiLz48cGF0aCBkPSJtMTU5LjIzIDEwNi45OC0zMi45MjQgMTkuMDExYTI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjI5IDExLjAzNWwzMi45My0xOS4wMTF6bS03My40MjQgNDIuMzkxLTAuMzU3MDggMC4yMDYxOWgwLjQyMzc1YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY2Ni0wLjIwNjE5eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="59" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExOS4xNW1tIiBoZWlnaHQ9IjE0MC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTkuMTUgMTQwLjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4zNDIgLTY4LjU2NCkiPjxnPjxjaXJjbGUgY3g9IjE0NyIgY3k9IjEwMy43MSIgcj0iMTAuNTEiLz48cGF0aCBkPSJtMTM3LjIxIDExOS4zNWMtMS42NDQ3IDAtMi4yNTQ0IDAuMTcxMjgtMi44NTU2IDAuOTc4MDUtMC42NzMyMyAwLjkwMzM5LTAuMjU2ODggMi41OTgyLTAuMTM1MzggMy4zNzcybDQuNTIxNyAyOS4wMTdjMC4xNzU2MyAxLjEyNzItMC4yMDMzMyAyLjE2OTUtMC45MDc5NiAyLjk5NTJoMjMuMDgzYzIuNTEyNiAwIDQuOTExNS0yLjA1MTMgNC41MzU2LTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjMxLTQuNTM1Ni00LjUzNTYtNC41MzU2eiIvPjxwYXRoIGQ9Im0xNDAuNSAxNTEuNGMtMC42NjU4OCAwLTEuMzEyNSAwLjE0Mzg0LTEuODk5NiAwLjQwMDQ5bDAuMTM5NTMgMC45MjM0NmMwLjI4MDMzIDEuODUzLTAuOTgzMzQgMy40NjQ1LTIuNjg2MiA0LjE2NDFsNC4xODc5IDQ3LjQwNWMwLjIyMDkzIDIuNTAwNSAyLjAyMDggNC41MzE1IDQuNTMxIDQuNTMxNWg0LjQ2NzRjMi41MTAyIDAgNC4zMTEtMi4wMzEgNC41MzEtNC41MzE1bDQuMjU0NS00OC4zNjJjMC4yMTk5OS0yLjUwMDYtMi4wMjA4LTQuNTMxLTQuNTMxLTQuNTMxeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTY0LjgzNCA5My4xOThhMTAuNTEgMTAuNTEgMCAwIDAtMTAuNTEgMTAuNTEgMTAuNTEgMTAuNTEgMCAwIDAgOC41OTEyIDEwLjMxNWwtMC4xMzkwMS0wLjI1ODljLTMuMzE4My02LjE5NTctMS4wMDE3LTEzLjg1NSA1LjE5NC0xNy4xNzMgMS4wNTUyLTAuNTY1MTYgMi4xNTI5LTAuOTY2NDMgMy4yNjQ0LTEuMjEzNGExMC41MSAxMC41MSAwIDAgMC02LjQwMDYtMi4xNzkyeiIgc3Ryb2tlLXdpZHRoPSIuMTE0ODkiLz48cGF0aCBkPSJtNTUuMDQ2IDExOS4zNWMtMi41MTI2IDAtNC4xNTk4IDIuMDUwOC00LjUzNTYgNC41MzUxbC00LjEyOTUgMjcuMjk3Yy0wLjM3NTg2IDIuNDg0MyAyLjAyMjYgNC41MzUxIDQuNTM1MSA0LjUzNTFoMjcuODM2YzIuMTk5MSAwIDUuNTcxOS0wLjE0MDY4IDQuMjYxOS0yLjk5NjItNS4wMjYtMTAuOTU2LTE3LjI0NS0zMy4zNzEtMTcuMjQ1LTMzLjM3MXoiLz48cGF0aCBkPSJtNTguMzM3IDE1MS40aDEyLjk5NWMyLjUxMDIgMCA0Ljc1MSAyLjAzMDUgNC41MzEgNC41MzExbC00LjI1NDggNDguMzYyYy0wLjIxOTk5IDIuNTAwNi0yLjAyMDggNC41MzExLTQuNTMxIDQuNTMxMWgtNC40NjY5Yy0yLjUxMDIgMC00LjMxMDEtMi4wMzA2LTQuNTMxMS00LjUzMTFsLTQuMjczLTQ4LjM2MmMtMC4yMjA5My0yLjUwMDUgMi4wMjA5LTQuNTMxMSA0LjUzMTEtNC41MzExeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTEwMi40MiAxMTkuMzVoLTExLjg5OXY1LjUzMjdsOC44OTYyIDQuNjgyMXoiLz48Y2lyY2xlIGN4PSIxMDYuMzIiIGN5PSIxMDMuNzEiIHI9IjEwLjUxIi8+PHBhdGggZD0ibTk2LjUzMyAxMTkuMzVjLTIuNTEyNiAwLTQuMTU5MyAyLjA1MTMtNC41MzUxIDQuNTM1NmwxLjQ5MzYgOS43ODU0czAuNTAzMzcgMjIuMDQ3IDMuMzM1MiAyMi4wNDdsMjMuNDEyLTFlLTNjMi41MTI2LTEuMWUtNCA0LjkxMS0yLjA1MTMgNC41MzUxLTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjI2LTQuNTM1Ni00LjUzNTEtNC41MzU2eiIvPjxwYXRoIGQ9Im05OS44MjMgMTUxLjRoMTIuOTk1YzIuNTEwMiAwIDQuNzUxIDIuMDMwNSA0LjUzMSA0LjUzMTFsLTQuMjU0OCA0OC4zNjJjLTAuMjE5OTkgMi41MDA2LTIuMDIwOCA0LjUzMTEtNC41MzEgNC41MzExaC00LjQ2NjljLTIuNTEwMiAwLTQuMzEwMS0yLjAzMDYtNC41MzExLTQuNTMxMWwtNC4yNzMtNDguMzYyYy0wLjIyMDkzLTIuNTAwNSAyLjAyMDktNC41MzExIDQuNTMxMS00LjUzMTF6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIyLjc1MDUiLz48cmVjdCB0cmFuc2Zvcm09InJvdGF0ZSgtMjguMTczKSIgeD0iMTIuNjUxIiB5PSIxMjcuNTgiIHdpZHRoPSIxMS4yOTUiIGhlaWdodD0iNjIuMDg0IiByeT0iNC41MzExIi8+PHBhdGggZD0ibTk1LjI5MiAxNTUuOTMgMS4yODExLTEuMzk2Mi0xLjI5NjItNC41ODU4LTguMzk0NS0xNC41MjMiLz48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzLjY2MiI+PHBhdGggZD0ibTEwNi4zMiA3MC4zOTV2MTQuOTczIi8+PHBhdGggZD0ibTg1LjA2MyA3Ni4yNjUgNy40ODY3IDEyLjk2NyIvPjxwYXRoIGQ9Im0xMjcuNTggNzYuMjY1LTcuNDg2NyAxMi45NjciLz48L2c+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.58727" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="141,90,153,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="60" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="232,113,141,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="61" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3NS4wMyIgaGVpZ2h0PSIyMjAuNjgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NS4wMyAyMjAuNjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0ibTQzLjM1MSAyMDUuOTV2LTE0LjczNGwtMTcuMjQyLTIyLjc0NmMtOS40ODI5LTEyLjUxLTE5LjIzNy0yNS41NTctMjEuNjc1LTI4Ljk5M2wtNC40MzM2LTYuMjQ2OCAwLjAyNTgtMzMuMTljMC4wMzE1LTQwLjQ4MyAwLjU4MzctNTUuMzY4IDIuMTczMS01OC41OCAyLjA3ODgtNC4yMDAzIDguNzgwOS02LjI1OTkgMTMuNjI1LTQuMTg3MSAzLjIzNyAxLjM4NSA1LjE2OTIgMy45NjE1IDUuOTQ5IDcuOTMyNiAwLjgxODgyIDQuMTcgMS4wNzkzIDQyLjkxOSAwLjMxODQ5IDQ3LjM3Mi0wLjQxOTM2IDIuNDU0Mi0xLjA4NzIgMi41MTQ0LTIuNTY5MiAzLjgzNjUtMi4xNDE3IDEuOTEwOC02LjcxMjggNS4zMjkzLTguMDY0NiA5LjE2ODUtMS4zMTIzIDMuNzI3Mi0wLjcyOTE0IDkuMTQzNCAwLjUyNTU3IDExLjg0MyAxLjM3MDggMi45NDkxIDEzLjcxNSAxNi40OTEgMjAuNDU3IDIyLjQ0MSA0LjIyMTEgMy43MjU2IDUuMTE2OSA0LjI3MjIgNi4xMjExIDMuNzM0NyAwLjY0NzAzLTAuMzQ2MjcgMS4xNzY0LTAuOTI5NTIgMS4xNzY0LTEuMjk2MSAwLTAuODQ3NC0zLjcwOTctNS4yMDY3LTEzLjQ3Ni0xNS44MzYtNC4yNjYxLTQuNjQzLTguNDQzMS05LjQ3MTYtOS4yODIyLTEwLjczLTIuOTU4Mi00LjQzNzItMS40NjgyLTEwLjQ5NiAzLjQzMjQtMTMuOTU4IDMuMzExNS0yLjMzOTIgOC4yMTQxLTIuNTI3MyAxMS41ODQtMC40NDQ0OCAxLjIwMyAwLjc0MzQ3IDEzLjMyNiAxMi43NTkgMjYuOTQxIDI2LjcwMmwyNC43NTQgMjUuMzV2NjcuMjk2aC00MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yNjMzMiAwIDAgLjI2MzMyIDEyLjg3OCAtOC44Njg4KSIgZmlsbD0icGFyYW0oZmlsbCkiIHN0cm9rZT0icGFyYW0ob3V0bGluZSkiIHN0cm9rZS13aWR0aD0icGFyYW0ob3V0bGluZS13aWR0aCkiPjxjaXJjbGUgY3g9IjI4My40NSIgY3k9IjEwNi4yNCIgcj0iNzIuNTYzIi8+PGcgZmlsbC1vcGFjaXR5PSJwYXJhbShmaWxsLW9wYWNpdHkpIiBzdHJva2Utb3BhY2l0eT0icGFyYW0ob3V0bGluZS1vcGFjaXR5KSI+PHBhdGggZD0ibTQ1NS42MyAzMDEuMDgtOTguMTE1LTk4LjI2OGMtOC4xMDctNy45NzQtMTcuMzM3LTEyLjc5OS0zMS4wMi0xMi43OTloLTg3LjA5NGMtMTMuNjgzIDAtMjIuMzA1IDQuOTc3LTMwLjE4MyAxMi43OTlsLTk3LjEyOCA5Ny4zMTVjLTI2LjU0NSAyNi41NDggOS4zNzUgNjAuNTI5IDM1Ljg3NyAzNC4wMjdsNTguNjYtNTkuMDQ5djU1LjM4NWgxNTIuOTV2LTU1LjY4OWw2MC4xOTggNjAuMzI0YzI0LjIzOSAyNS41MzEgNjEuMTI5LTguNzczIDM1Ljg1OC0zNC4wNDV6Ii8+PHBhdGggZD0ibTM1OS4yNiAzNTkuMjItNTcuNjQ1IDU3LjY0OSA0Mi4zMjIgNDIuMjQzLTQzLjM2NyA0My4zNjZjLTI1LjU5NCAyNS41OTcgOS43MTUgNjIuMjA1IDM2LjE4NCAzNS43MzZsNjguNTg1LTcxLjMxM2MxNC43MTktMTUuMDIxIDE4Ljc4OS00Mi43NjUgMy4wMDktNTguNTQ0LTAuMDU0LTAuMDUzLTQ5LjA4OC00OS4xMzctNDkuMDg4LTQ5LjEzN3oiLz48cGF0aCBkPSJtMjIxLjk2IDQ1OS4xMSA0Mi4zMjMtNDIuMjQzLTU3LjY0Ny01Ny42NDlzLTQ5LjAzMyA0OS4wODQtNDkuMDg2IDQ5LjEzOGMtMTUuNzggMTUuNzc5LTExLjcxIDQzLjUyMyAzLjAwOSA1OC41NDRsNjguNTg1IDcxLjMxM2MyNi40NjggMjYuNDY5IDYxLjc3Ny0xMC4xNCAzNi4xODMtMzUuNzM2eiIvPjwvZz48L2c+PHBhdGggZD0ibTEzMS44IDIwNS45NXYtMTQuNzM0bDE3LjI0Mi0yMi43NDZjOS40ODI5LTEyLjUxIDE5LjIzNy0yNS41NTcgMjEuNjc1LTI4Ljk5M2w0LjQzMzYtNi4yNDY4LTAuMDI1OC0zMy4xOWMtMC4wMzE1LTQwLjQ4My0wLjU4MzctNTUuMzY4LTIuMTczMS01OC41OC0yLjA3ODgtNC4yMDAzLTguNzgwOS02LjI1OTktMTMuNjI1LTQuMTg3MS0zLjIzNyAxLjM4NS01LjE2OTIgMy45NjE1LTUuOTQ5IDcuOTMyNi0wLjgxODgyIDQuMTctMS4wNzkzIDQyLjkxOS0wLjMxODQ5IDQ3LjM3MiAwLjQxOTM2IDIuNDU0MiAxLjA4NzIgMi41MTQ0IDIuNTY5MiAzLjgzNjUgMi4xNDE3IDEuOTEwOCA2LjcxMjggNS4zMjkzIDguMDY0NiA5LjE2ODUgMS4zMTIzIDMuNzI3MiAwLjcyOTE0IDkuMTQzNC0wLjUyNTU3IDExLjg0My0xLjM3MDggMi45NDkxLTEzLjcxNSAxNi40OTEtMjAuNDU3IDIyLjQ0MS00LjIyMTEgMy43MjU2LTUuMTE2OSA0LjI3MjItNi4xMjExIDMuNzM0Ny0wLjY0NzAzLTAuMzQ2MjctMS4xNzY0LTAuOTI5NTItMS4xNzY0LTEuMjk2MSAwLTAuODQ3NCAzLjcwOTctNS4yMDY3IDEzLjQ3Ni0xNS44MzYgNC4yNjYxLTQuNjQzIDguNDQzMS05LjQ3MTYgOS4yODIyLTEwLjczIDIuOTU4Mi00LjQzNzIgMS40NjgyLTEwLjQ5Ni0zLjQzMjQtMTMuOTU4LTMuMzExNS0yLjMzOTItOC4yMTQxLTIuNTI3My0xMS41ODQtMC40NDQ0OC0xLjIwMyAwLjc0MzQ3LTEzLjMyNiAxMi43NTktMjYuOTQxIDI2LjcwMmwtMjQuNzU0IDI1LjM1djY3LjI5Nmg0MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28295" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="62" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjM3LjE3OCIgaGVpZ2h0PSIzNy4xNzgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDM3LjE3OCAzNy4xNzgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjg1OTM4IC0xLjExNzIpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI1Ni4yODMiPgogIDxwYXRoIGQ9Im0xNy41MjEgMS4xMTcydjExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3Ny0wLjI2NTYyIDcuMzQwNSA3LjM0MDUgMCAwIDEgMS45Mjc3IDAuMjU3ODF2LTExLjUwOHptMCAyNS42NjR2MTEuNTE0aDMuODU1NXYtMTEuNTE0YTcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3IDAuMjY1NjIgNy4zNDA1IDcuMzQwNSAwIDAgMS0xLjkyNzctMC4yNjU2MnoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSg5MCkiIGQ9Im0xNy43NzktMC44NTkzOGgzLjg1NTV2LTExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxLTEuOTI3NyAwLjI2NzU4IDcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3LTAuMjY3NTh6bTAtMjUuNjdhNy4zNDA1IDcuMzQwNSAwIDAgMSAxLjkyNzctMC4yNTk3NiA3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3NyAwLjI2NTYydi0xMS41MTRoLTMuODU1NXoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSgzMCkiIGQ9Im0yNC43NjktMTEuMjQ3LTYuMDdlLTQgMTEuNTA3YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTYzLTQuNTQ5NGUtNGwtMC4wMDExLTExLjUwNnptLTMuNjllLTQgMjUuNjUyLTIuNzVlLTQgMTEuNTI3IDMuODU2My00LjU1ZS00IDcuOTllLTQgLTExLjUxOGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU2OC0wLjAwODN6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTMwKSIgZD0ibTguOTE3OCA4LjIwMjMtMy44NTYzLTQuNTQ5ZS00IDAuMDAxMjUgMTEuNTI1YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4LTAuMDA2NnptMy42ODhlLTQgMjUuNjUyYTcuMzQwNSA3LjM0MDUgMCAwIDEtMy44NTY4IDAuMDA4M2w3Ljk4N2UtNCAxMS41MTggMy44NTQ2LTUuMjJlLTR6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTYwKSIgZD0ibS01LjQxMzcgOC4xMDc1LTMuODU2MyA0LjU0OWUtNCAtNy45ODdlLTQgMTEuNTE4YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4IDAuMDA2NnptMS41NDVlLTQgMjUuNjZhNy4zNDA1IDcuMzQwNSAwIDAgMS0zLjg1NjgtMC4wMDgzbDAuMDAxNDIgMTEuNTI2IDMuODU0NiA1LjIyZS00eiIvPgogIDxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDYwKSIgZD0ibTI0Ljg2My0yNS41OCA2LjA3ZS00IDExLjUwN2E3LjM0MDUgNy4zNDA1IDAgMCAxIDMuODU1MyAwLjAwMjFsMy42OWUtNCAtMTEuNTA4em0tMS41NWUtNCAyNS42NiA3Ljk5ZS00IDExLjUxOCAzLjg1NDYtNS4yMmUtNCA0LjRlLTQgLTExLjUyNGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU1OCAwLjAwNjU3MjZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="63" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjMzLjQ4MiIgaGVpZ2h0PSIzNy42NjMiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMzLjQ4MiAzNy42NjMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8cGF0aCBkPSJtNy43MDMxIDE0LjY0OWExMS45MDYgMTEuOTA2IDAgMCAwLTcuNzAzMSAxMS4xMDcgMTEuOTA2IDExLjkwNiAwIDAgMCAxMS45MDYgMTEuOTA2IDExLjkwNiAxMS45MDYgMCAwIDAgMTEuOTA2LTExLjkwNiAxMS45MDYgMTEuOTA2IDAgMCAwLTAuMTIxMDktMS42ODE2aC0zLjgxMjVhOC4yNzc1IDguMjc3NSAwIDAgMSAwLjE2Nzk3IDEuNjQ2NSA4LjI3NzUgOC4yNzc1IDAgMCAxLTguMjc5MyA4LjI3NzMgOC4yNzc1IDguMjc3NSAwIDAgMS04LjI3NzMtOC4yNzczIDguMjc3NSA4LjI3NzUgMCAwIDEgNC4yMTI5LTcuMTg3NXoiLz4KIDxjaXJjbGUgY3g9IjExLjIzNCIgY3k9IjMuNzUyNCIgcj0iMy43NTI0Ii8+CiA8cGF0aCBkPSJtOS43MzYyIDE1LjYxaDEzLjUzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDczNCIvPgogPHBhdGggZD0ibTEwLjI5NiA0LjY5MjR2MTYuODc0aDE0LjQ3NWw0LjA4MDggMTMuMDQ5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMy4xNzUxIi8+CiA8cmVjdCB4PSI4LjcwODQiIHk9IjIwLjE4NCIgd2lkdGg9IjMuOTQxMSIgaGVpZ2h0PSIyLjk2NzIiIHJ5PSIwIi8+CiA8cGF0aCBkPSJtMjguODUyIDM0LjYxNSAxLjUxNTItMC40NjYzMSAzLjExNDktMC45ODY5NC0wLjQ1NjI4LTEuNjE1MS00LjY3ODQgMS40NTQ3eiIvPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.60054" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="64" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi44NG1tIiBoZWlnaHQ9IjY3Ljc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi44NCA2Ny43OSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDcuODA0IC04MS43ODQpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSIxODUuOTYiPjxwYXRoIGQ9Im0xMDIuODYgODEuNzg0djM4LjA0OGEyNC4yNTMgMjQuMjUzIDAgMCAxIDYuMzY5MS0wLjg3Nzk5IDI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjkxIDAuODUyMTV2LTM4LjAyMnoiLz48cGF0aCBkPSJtNDcuODA0IDEzNi44NHYxMi43MzloMzguMDQ4YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC44ODQwOC02LjM2OTMgMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg4NDA4LTYuMzY5M3ptODQuODE0IDBhMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg1ODI3IDYuMzY5MyAyNC4yNTMgMjQuMjUzIDAgMCAxLTAuODc3NjMgNi4zNjkzaDM4LjA0MXYtMTIuNzM5eiIvPjxwYXRoIGQ9Im0xMzQuNDIgODYuODMtMTkuMDExIDMyLjkyNGEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAzNSA2LjM2OTFsMTkuMDA1LTMyLjkyNHoiLz48cGF0aCBkPSJtODQuMDMyIDg2LjgzLTExLjAzNSA2LjM2OTEgMTkuMDQzIDMyLjk3NmEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAyMi02LjM4ODh6Ii8+PHBhdGggZD0ibTU5LjIxOSAxMDYuOTgtNi4zNjkxIDExLjAzNSAzMi45NTYgMTkuMDNhMjQuMjUzIDI0LjI1MyAwIDAgMSA2LjM4ODgtMTEuMDIyem03My40MjQgNDIuMzkxYTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY3IDAuMjA2MTloMC40MjM3NXoiLz48cGF0aCBkPSJtMTU5LjIzIDEwNi45OC0zMi45MjQgMTkuMDExYTI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjI5IDExLjAzNWwzMi45My0xOS4wMTF6bS03My40MjQgNDIuMzkxLTAuMzU3MDggMC4yMDYxOWgwLjQyMzc1YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY2Ni0wLjIwNjE5eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="65" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExOS4xNW1tIiBoZWlnaHQ9IjE0MC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTkuMTUgMTQwLjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4zNDIgLTY4LjU2NCkiPjxnPjxjaXJjbGUgY3g9IjE0NyIgY3k9IjEwMy43MSIgcj0iMTAuNTEiLz48cGF0aCBkPSJtMTM3LjIxIDExOS4zNWMtMS42NDQ3IDAtMi4yNTQ0IDAuMTcxMjgtMi44NTU2IDAuOTc4MDUtMC42NzMyMyAwLjkwMzM5LTAuMjU2ODggMi41OTgyLTAuMTM1MzggMy4zNzcybDQuNTIxNyAyOS4wMTdjMC4xNzU2MyAxLjEyNzItMC4yMDMzMyAyLjE2OTUtMC45MDc5NiAyLjk5NTJoMjMuMDgzYzIuNTEyNiAwIDQuOTExNS0yLjA1MTMgNC41MzU2LTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjMxLTQuNTM1Ni00LjUzNTYtNC41MzU2eiIvPjxwYXRoIGQ9Im0xNDAuNSAxNTEuNGMtMC42NjU4OCAwLTEuMzEyNSAwLjE0Mzg0LTEuODk5NiAwLjQwMDQ5bDAuMTM5NTMgMC45MjM0NmMwLjI4MDMzIDEuODUzLTAuOTgzMzQgMy40NjQ1LTIuNjg2MiA0LjE2NDFsNC4xODc5IDQ3LjQwNWMwLjIyMDkzIDIuNTAwNSAyLjAyMDggNC41MzE1IDQuNTMxIDQuNTMxNWg0LjQ2NzRjMi41MTAyIDAgNC4zMTEtMi4wMzEgNC41MzEtNC41MzE1bDQuMjU0NS00OC4zNjJjMC4yMTk5OS0yLjUwMDYtMi4wMjA4LTQuNTMxLTQuNTMxLTQuNTMxeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTY0LjgzNCA5My4xOThhMTAuNTEgMTAuNTEgMCAwIDAtMTAuNTEgMTAuNTEgMTAuNTEgMTAuNTEgMCAwIDAgOC41OTEyIDEwLjMxNWwtMC4xMzkwMS0wLjI1ODljLTMuMzE4My02LjE5NTctMS4wMDE3LTEzLjg1NSA1LjE5NC0xNy4xNzMgMS4wNTUyLTAuNTY1MTYgMi4xNTI5LTAuOTY2NDMgMy4yNjQ0LTEuMjEzNGExMC41MSAxMC41MSAwIDAgMC02LjQwMDYtMi4xNzkyeiIgc3Ryb2tlLXdpZHRoPSIuMTE0ODkiLz48cGF0aCBkPSJtNTUuMDQ2IDExOS4zNWMtMi41MTI2IDAtNC4xNTk4IDIuMDUwOC00LjUzNTYgNC41MzUxbC00LjEyOTUgMjcuMjk3Yy0wLjM3NTg2IDIuNDg0MyAyLjAyMjYgNC41MzUxIDQuNTM1MSA0LjUzNTFoMjcuODM2YzIuMTk5MSAwIDUuNTcxOS0wLjE0MDY4IDQuMjYxOS0yLjk5NjItNS4wMjYtMTAuOTU2LTE3LjI0NS0zMy4zNzEtMTcuMjQ1LTMzLjM3MXoiLz48cGF0aCBkPSJtNTguMzM3IDE1MS40aDEyLjk5NWMyLjUxMDIgMCA0Ljc1MSAyLjAzMDUgNC41MzEgNC41MzExbC00LjI1NDggNDguMzYyYy0wLjIxOTk5IDIuNTAwNi0yLjAyMDggNC41MzExLTQuNTMxIDQuNTMxMWgtNC40NjY5Yy0yLjUxMDIgMC00LjMxMDEtMi4wMzA2LTQuNTMxMS00LjUzMTFsLTQuMjczLTQ4LjM2MmMtMC4yMjA5My0yLjUwMDUgMi4wMjA5LTQuNTMxMSA0LjUzMTEtNC41MzExeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTEwMi40MiAxMTkuMzVoLTExLjg5OXY1LjUzMjdsOC44OTYyIDQuNjgyMXoiLz48Y2lyY2xlIGN4PSIxMDYuMzIiIGN5PSIxMDMuNzEiIHI9IjEwLjUxIi8+PHBhdGggZD0ibTk2LjUzMyAxMTkuMzVjLTIuNTEyNiAwLTQuMTU5MyAyLjA1MTMtNC41MzUxIDQuNTM1NmwxLjQ5MzYgOS43ODU0czAuNTAzMzcgMjIuMDQ3IDMuMzM1MiAyMi4wNDdsMjMuNDEyLTFlLTNjMi41MTI2LTEuMWUtNCA0LjkxMS0yLjA1MTMgNC41MzUxLTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjI2LTQuNTM1Ni00LjUzNTEtNC41MzU2eiIvPjxwYXRoIGQ9Im05OS44MjMgMTUxLjRoMTIuOTk1YzIuNTEwMiAwIDQuNzUxIDIuMDMwNSA0LjUzMSA0LjUzMTFsLTQuMjU0OCA0OC4zNjJjLTAuMjE5OTkgMi41MDA2LTIuMDIwOCA0LjUzMTEtNC41MzEgNC41MzExaC00LjQ2NjljLTIuNTEwMiAwLTQuMzEwMS0yLjAzMDYtNC41MzExLTQuNTMxMWwtNC4yNzMtNDguMzYyYy0wLjIyMDkzLTIuNTAwNSAyLjAyMDktNC41MzExIDQuNTMxMS00LjUzMTF6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIyLjc1MDUiLz48cmVjdCB0cmFuc2Zvcm09InJvdGF0ZSgtMjguMTczKSIgeD0iMTIuNjUxIiB5PSIxMjcuNTgiIHdpZHRoPSIxMS4yOTUiIGhlaWdodD0iNjIuMDg0IiByeT0iNC41MzExIi8+PHBhdGggZD0ibTk1LjI5MiAxNTUuOTMgMS4yODExLTEuMzk2Mi0xLjI5NjItNC41ODU4LTguMzk0NS0xNC41MjMiLz48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzLjY2MiI+PHBhdGggZD0ibTEwNi4zMiA3MC4zOTV2MTQuOTczIi8+PHBhdGggZD0ibTg1LjA2MyA3Ni4yNjUgNy40ODY3IDEyLjk2NyIvPjxwYXRoIGQ9Im0xMjcuNTggNzYuMjY1LTcuNDg2NyAxMi45NjciLz48L2c+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.58727" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="66" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,158,23,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="0" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="67" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3NS4wMyIgaGVpZ2h0PSIyMjAuNjgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NS4wMyAyMjAuNjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0ibTQzLjM1MSAyMDUuOTV2LTE0LjczNGwtMTcuMjQyLTIyLjc0NmMtOS40ODI5LTEyLjUxLTE5LjIzNy0yNS41NTctMjEuNjc1LTI4Ljk5M2wtNC40MzM2LTYuMjQ2OCAwLjAyNTgtMzMuMTljMC4wMzE1LTQwLjQ4MyAwLjU4MzctNTUuMzY4IDIuMTczMS01OC41OCAyLjA3ODgtNC4yMDAzIDguNzgwOS02LjI1OTkgMTMuNjI1LTQuMTg3MSAzLjIzNyAxLjM4NSA1LjE2OTIgMy45NjE1IDUuOTQ5IDcuOTMyNiAwLjgxODgyIDQuMTcgMS4wNzkzIDQyLjkxOSAwLjMxODQ5IDQ3LjM3Mi0wLjQxOTM2IDIuNDU0Mi0xLjA4NzIgMi41MTQ0LTIuNTY5MiAzLjgzNjUtMi4xNDE3IDEuOTEwOC02LjcxMjggNS4zMjkzLTguMDY0NiA5LjE2ODUtMS4zMTIzIDMuNzI3Mi0wLjcyOTE0IDkuMTQzNCAwLjUyNTU3IDExLjg0MyAxLjM3MDggMi45NDkxIDEzLjcxNSAxNi40OTEgMjAuNDU3IDIyLjQ0MSA0LjIyMTEgMy43MjU2IDUuMTE2OSA0LjI3MjIgNi4xMjExIDMuNzM0NyAwLjY0NzAzLTAuMzQ2MjcgMS4xNzY0LTAuOTI5NTIgMS4xNzY0LTEuMjk2MSAwLTAuODQ3NC0zLjcwOTctNS4yMDY3LTEzLjQ3Ni0xNS44MzYtNC4yNjYxLTQuNjQzLTguNDQzMS05LjQ3MTYtOS4yODIyLTEwLjczLTIuOTU4Mi00LjQzNzItMS40NjgyLTEwLjQ5NiAzLjQzMjQtMTMuOTU4IDMuMzExNS0yLjMzOTIgOC4yMTQxLTIuNTI3MyAxMS41ODQtMC40NDQ0OCAxLjIwMyAwLjc0MzQ3IDEzLjMyNiAxMi43NTkgMjYuOTQxIDI2LjcwMmwyNC43NTQgMjUuMzV2NjcuMjk2aC00MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yNjMzMiAwIDAgLjI2MzMyIDEyLjg3OCAtOC44Njg4KSIgZmlsbD0icGFyYW0oZmlsbCkiIHN0cm9rZT0icGFyYW0ob3V0bGluZSkiIHN0cm9rZS13aWR0aD0icGFyYW0ob3V0bGluZS13aWR0aCkiPjxjaXJjbGUgY3g9IjI4My40NSIgY3k9IjEwNi4yNCIgcj0iNzIuNTYzIi8+PGcgZmlsbC1vcGFjaXR5PSJwYXJhbShmaWxsLW9wYWNpdHkpIiBzdHJva2Utb3BhY2l0eT0icGFyYW0ob3V0bGluZS1vcGFjaXR5KSI+PHBhdGggZD0ibTQ1NS42MyAzMDEuMDgtOTguMTE1LTk4LjI2OGMtOC4xMDctNy45NzQtMTcuMzM3LTEyLjc5OS0zMS4wMi0xMi43OTloLTg3LjA5NGMtMTMuNjgzIDAtMjIuMzA1IDQuOTc3LTMwLjE4MyAxMi43OTlsLTk3LjEyOCA5Ny4zMTVjLTI2LjU0NSAyNi41NDggOS4zNzUgNjAuNTI5IDM1Ljg3NyAzNC4wMjdsNTguNjYtNTkuMDQ5djU1LjM4NWgxNTIuOTV2LTU1LjY4OWw2MC4xOTggNjAuMzI0YzI0LjIzOSAyNS41MzEgNjEuMTI5LTguNzczIDM1Ljg1OC0zNC4wNDV6Ii8+PHBhdGggZD0ibTM1OS4yNiAzNTkuMjItNTcuNjQ1IDU3LjY0OSA0Mi4zMjIgNDIuMjQzLTQzLjM2NyA0My4zNjZjLTI1LjU5NCAyNS41OTcgOS43MTUgNjIuMjA1IDM2LjE4NCAzNS43MzZsNjguNTg1LTcxLjMxM2MxNC43MTktMTUuMDIxIDE4Ljc4OS00Mi43NjUgMy4wMDktNTguNTQ0LTAuMDU0LTAuMDUzLTQ5LjA4OC00OS4xMzctNDkuMDg4LTQ5LjEzN3oiLz48cGF0aCBkPSJtMjIxLjk2IDQ1OS4xMSA0Mi4zMjMtNDIuMjQzLTU3LjY0Ny01Ny42NDlzLTQ5LjAzMyA0OS4wODQtNDkuMDg2IDQ5LjEzOGMtMTUuNzggMTUuNzc5LTExLjcxIDQzLjUyMyAzLjAwOSA1OC41NDRsNjguNTg1IDcxLjMxM2MyNi40NjggMjYuNDY5IDYxLjc3Ny0xMC4xNCAzNi4xODMtMzUuNzM2eiIvPjwvZz48L2c+PHBhdGggZD0ibTEzMS44IDIwNS45NXYtMTQuNzM0bDE3LjI0Mi0yMi43NDZjOS40ODI5LTEyLjUxIDE5LjIzNy0yNS41NTcgMjEuNjc1LTI4Ljk5M2w0LjQzMzYtNi4yNDY4LTAuMDI1OC0zMy4xOWMtMC4wMzE1LTQwLjQ4My0wLjU4MzctNTUuMzY4LTIuMTczMS01OC41OC0yLjA3ODgtNC4yMDAzLTguNzgwOS02LjI1OTktMTMuNjI1LTQuMTg3MS0zLjIzNyAxLjM4NS01LjE2OTIgMy45NjE1LTUuOTQ5IDcuOTMyNi0wLjgxODgyIDQuMTctMS4wNzkzIDQyLjkxOS0wLjMxODQ5IDQ3LjM3MiAwLjQxOTM2IDIuNDU0MiAxLjA4NzIgMi41MTQ0IDIuNTY5MiAzLjgzNjUgMi4xNDE3IDEuOTEwOCA2LjcxMjggNS4zMjkzIDguMDY0NiA5LjE2ODUgMS4zMTIzIDMuNzI3MiAwLjcyOTE0IDkuMTQzNC0wLjUyNTU3IDExLjg0My0xLjM3MDggMi45NDkxLTEzLjcxNSAxNi40OTEtMjAuNDU3IDIyLjQ0MS00LjIyMTEgMy43MjU2LTUuMTE2OSA0LjI3MjItNi4xMjExIDMuNzM0Ny0wLjY0NzAzLTAuMzQ2MjctMS4xNzY0LTAuOTI5NTItMS4xNzY0LTEuMjk2MSAwLTAuODQ3NCAzLjcwOTctNS4yMDY3IDEzLjQ3Ni0xNS44MzYgNC4yNjYxLTQuNjQzIDguNDQzMS05LjQ3MTYgOS4yODIyLTEwLjczIDIuOTU4Mi00LjQzNzIgMS40NjgyLTEwLjQ5Ni0zLjQzMjQtMTMuOTU4LTMuMzExNS0yLjMzOTItOC4yMTQxLTIuNTI3My0xMS41ODQtMC40NDQ0OC0xLjIwMyAwLjc0MzQ3LTEzLjMyNiAxMi43NTktMjYuOTQxIDI2LjcwMmwtMjQuNzU0IDI1LjM1djY3LjI5Nmg0MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28295" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="68" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjM3LjE3OCIgaGVpZ2h0PSIzNy4xNzgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDM3LjE3OCAzNy4xNzgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjg1OTM4IC0xLjExNzIpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI1Ni4yODMiPgogIDxwYXRoIGQ9Im0xNy41MjEgMS4xMTcydjExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3Ny0wLjI2NTYyIDcuMzQwNSA3LjM0MDUgMCAwIDEgMS45Mjc3IDAuMjU3ODF2LTExLjUwOHptMCAyNS42NjR2MTEuNTE0aDMuODU1NXYtMTEuNTE0YTcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3IDAuMjY1NjIgNy4zNDA1IDcuMzQwNSAwIDAgMS0xLjkyNzctMC4yNjU2MnoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSg5MCkiIGQ9Im0xNy43NzktMC44NTkzOGgzLjg1NTV2LTExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxLTEuOTI3NyAwLjI2NzU4IDcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3LTAuMjY3NTh6bTAtMjUuNjdhNy4zNDA1IDcuMzQwNSAwIDAgMSAxLjkyNzctMC4yNTk3NiA3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3NyAwLjI2NTYydi0xMS41MTRoLTMuODU1NXoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSgzMCkiIGQ9Im0yNC43NjktMTEuMjQ3LTYuMDdlLTQgMTEuNTA3YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTYzLTQuNTQ5NGUtNGwtMC4wMDExLTExLjUwNnptLTMuNjllLTQgMjUuNjUyLTIuNzVlLTQgMTEuNTI3IDMuODU2My00LjU1ZS00IDcuOTllLTQgLTExLjUxOGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU2OC0wLjAwODN6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTMwKSIgZD0ibTguOTE3OCA4LjIwMjMtMy44NTYzLTQuNTQ5ZS00IDAuMDAxMjUgMTEuNTI1YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4LTAuMDA2NnptMy42ODhlLTQgMjUuNjUyYTcuMzQwNSA3LjM0MDUgMCAwIDEtMy44NTY4IDAuMDA4M2w3Ljk4N2UtNCAxMS41MTggMy44NTQ2LTUuMjJlLTR6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTYwKSIgZD0ibS01LjQxMzcgOC4xMDc1LTMuODU2MyA0LjU0OWUtNCAtNy45ODdlLTQgMTEuNTE4YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4IDAuMDA2NnptMS41NDVlLTQgMjUuNjZhNy4zNDA1IDcuMzQwNSAwIDAgMS0zLjg1NjgtMC4wMDgzbDAuMDAxNDIgMTEuNTI2IDMuODU0NiA1LjIyZS00eiIvPgogIDxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDYwKSIgZD0ibTI0Ljg2My0yNS41OCA2LjA3ZS00IDExLjUwN2E3LjM0MDUgNy4zNDA1IDAgMCAxIDMuODU1MyAwLjAwMjFsMy42OWUtNCAtMTEuNTA4em0tMS41NWUtNCAyNS42NiA3Ljk5ZS00IDExLjUxOCAzLjg1NDYtNS4yMmUtNCA0LjRlLTQgLTExLjUyNGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU1OCAwLjAwNjU3MjZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="69" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjMzLjQ4MiIgaGVpZ2h0PSIzNy42NjMiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMzLjQ4MiAzNy42NjMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8cGF0aCBkPSJtNy43MDMxIDE0LjY0OWExMS45MDYgMTEuOTA2IDAgMCAwLTcuNzAzMSAxMS4xMDcgMTEuOTA2IDExLjkwNiAwIDAgMCAxMS45MDYgMTEuOTA2IDExLjkwNiAxMS45MDYgMCAwIDAgMTEuOTA2LTExLjkwNiAxMS45MDYgMTEuOTA2IDAgMCAwLTAuMTIxMDktMS42ODE2aC0zLjgxMjVhOC4yNzc1IDguMjc3NSAwIDAgMSAwLjE2Nzk3IDEuNjQ2NSA4LjI3NzUgOC4yNzc1IDAgMCAxLTguMjc5MyA4LjI3NzMgOC4yNzc1IDguMjc3NSAwIDAgMS04LjI3NzMtOC4yNzczIDguMjc3NSA4LjI3NzUgMCAwIDEgNC4yMTI5LTcuMTg3NXoiLz4KIDxjaXJjbGUgY3g9IjExLjIzNCIgY3k9IjMuNzUyNCIgcj0iMy43NTI0Ii8+CiA8cGF0aCBkPSJtOS43MzYyIDE1LjYxaDEzLjUzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDczNCIvPgogPHBhdGggZD0ibTEwLjI5NiA0LjY5MjR2MTYuODc0aDE0LjQ3NWw0LjA4MDggMTMuMDQ5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMy4xNzUxIi8+CiA8cmVjdCB4PSI4LjcwODQiIHk9IjIwLjE4NCIgd2lkdGg9IjMuOTQxMSIgaGVpZ2h0PSIyLjk2NzIiIHJ5PSIwIi8+CiA8cGF0aCBkPSJtMjguODUyIDM0LjYxNSAxLjUxNTItMC40NjYzMSAzLjExNDktMC45ODY5NC0wLjQ1NjI4LTEuNjE1MS00LjY3ODQgMS40NTQ3eiIvPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.60054" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjE3NS4wMyIgaGVpZ2h0PSIyMjAuNjgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDE3NS4wMyAyMjAuNjgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0ibTQzLjM1MSAyMDUuOTV2LTE0LjczNGwtMTcuMjQyLTIyLjc0NmMtOS40ODI5LTEyLjUxLTE5LjIzNy0yNS41NTctMjEuNjc1LTI4Ljk5M2wtNC40MzM2LTYuMjQ2OCAwLjAyNTgtMzMuMTljMC4wMzE1LTQwLjQ4MyAwLjU4MzctNTUuMzY4IDIuMTczMS01OC41OCAyLjA3ODgtNC4yMDAzIDguNzgwOS02LjI1OTkgMTMuNjI1LTQuMTg3MSAzLjIzNyAxLjM4NSA1LjE2OTIgMy45NjE1IDUuOTQ5IDcuOTMyNiAwLjgxODgyIDQuMTcgMS4wNzkzIDQyLjkxOSAwLjMxODQ5IDQ3LjM3Mi0wLjQxOTM2IDIuNDU0Mi0xLjA4NzIgMi41MTQ0LTIuNTY5MiAzLjgzNjUtMi4xNDE3IDEuOTEwOC02LjcxMjggNS4zMjkzLTguMDY0NiA5LjE2ODUtMS4zMTIzIDMuNzI3Mi0wLjcyOTE0IDkuMTQzNCAwLjUyNTU3IDExLjg0MyAxLjM3MDggMi45NDkxIDEzLjcxNSAxNi40OTEgMjAuNDU3IDIyLjQ0MSA0LjIyMTEgMy43MjU2IDUuMTE2OSA0LjI3MjIgNi4xMjExIDMuNzM0NyAwLjY0NzAzLTAuMzQ2MjcgMS4xNzY0LTAuOTI5NTIgMS4xNzY0LTEuMjk2MSAwLTAuODQ3NC0zLjcwOTctNS4yMDY3LTEzLjQ3Ni0xNS44MzYtNC4yNjYxLTQuNjQzLTguNDQzMS05LjQ3MTYtOS4yODIyLTEwLjczLTIuOTU4Mi00LjQzNzItMS40NjgyLTEwLjQ5NiAzLjQzMjQtMTMuOTU4IDMuMzExNS0yLjMzOTIgOC4yMTQxLTIuNTI3MyAxMS41ODQtMC40NDQ0OCAxLjIwMyAwLjc0MzQ3IDEzLjMyNiAxMi43NTkgMjYuOTQxIDI2LjcwMmwyNC43NTQgMjUuMzV2NjcuMjk2aC00MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yNjMzMiAwIDAgLjI2MzMyIDEyLjg3OCAtOC44Njg4KSIgZmlsbD0icGFyYW0oZmlsbCkiIHN0cm9rZT0icGFyYW0ob3V0bGluZSkiIHN0cm9rZS13aWR0aD0icGFyYW0ob3V0bGluZS13aWR0aCkiPjxjaXJjbGUgY3g9IjI4My40NSIgY3k9IjEwNi4yNCIgcj0iNzIuNTYzIi8+PGcgZmlsbC1vcGFjaXR5PSJwYXJhbShmaWxsLW9wYWNpdHkpIiBzdHJva2Utb3BhY2l0eT0icGFyYW0ob3V0bGluZS1vcGFjaXR5KSI+PHBhdGggZD0ibTQ1NS42MyAzMDEuMDgtOTguMTE1LTk4LjI2OGMtOC4xMDctNy45NzQtMTcuMzM3LTEyLjc5OS0zMS4wMi0xMi43OTloLTg3LjA5NGMtMTMuNjgzIDAtMjIuMzA1IDQuOTc3LTMwLjE4MyAxMi43OTlsLTk3LjEyOCA5Ny4zMTVjLTI2LjU0NSAyNi41NDggOS4zNzUgNjAuNTI5IDM1Ljg3NyAzNC4wMjdsNTguNjYtNTkuMDQ5djU1LjM4NWgxNTIuOTV2LTU1LjY4OWw2MC4xOTggNjAuMzI0YzI0LjIzOSAyNS41MzEgNjEuMTI5LTguNzczIDM1Ljg1OC0zNC4wNDV6Ii8+PHBhdGggZD0ibTM1OS4yNiAzNTkuMjItNTcuNjQ1IDU3LjY0OSA0Mi4zMjIgNDIuMjQzLTQzLjM2NyA0My4zNjZjLTI1LjU5NCAyNS41OTcgOS43MTUgNjIuMjA1IDM2LjE4NCAzNS43MzZsNjguNTg1LTcxLjMxM2MxNC43MTktMTUuMDIxIDE4Ljc4OS00Mi43NjUgMy4wMDktNTguNTQ0LTAuMDU0LTAuMDUzLTQ5LjA4OC00OS4xMzctNDkuMDg4LTQ5LjEzN3oiLz48cGF0aCBkPSJtMjIxLjk2IDQ1OS4xMSA0Mi4zMjMtNDIuMjQzLTU3LjY0Ny01Ny42NDlzLTQ5LjAzMyA0OS4wODQtNDkuMDg2IDQ5LjEzOGMtMTUuNzggMTUuNzc5LTExLjcxIDQzLjUyMyAzLjAwOSA1OC41NDRsNjguNTg1IDcxLjMxM2MyNi40NjggMjYuNDY5IDYxLjc3Ny0xMC4xNCAzNi4xODMtMzUuNzM2eiIvPjwvZz48L2c+PHBhdGggZD0ibTEzMS44IDIwNS45NXYtMTQuNzM0bDE3LjI0Mi0yMi43NDZjOS40ODI5LTEyLjUxIDE5LjIzNy0yNS41NTcgMjEuNjc1LTI4Ljk5M2w0LjQzMzYtNi4yNDY4LTAuMDI1OC0zMy4xOWMtMC4wMzE1LTQwLjQ4My0wLjU4MzctNTUuMzY4LTIuMTczMS01OC41OC0yLjA3ODgtNC4yMDAzLTguNzgwOS02LjI1OTktMTMuNjI1LTQuMTg3MS0zLjIzNyAxLjM4NS01LjE2OTIgMy45NjE1LTUuOTQ5IDcuOTMyNi0wLjgxODgyIDQuMTctMS4wNzkzIDQyLjkxOS0wLjMxODQ5IDQ3LjM3MiAwLjQxOTM2IDIuNDU0MiAxLjA4NzIgMi41MTQ0IDIuNTY5MiAzLjgzNjUgMi4xNDE3IDEuOTEwOCA2LjcxMjggNS4zMjkzIDguMDY0NiA5LjE2ODUgMS4zMTIzIDMuNzI3MiAwLjcyOTE0IDkuMTQzNC0wLjUyNTU3IDExLjg0My0xLjM3MDggMi45NDkxLTEzLjcxNSAxNi40OTEtMjAuNDU3IDIyLjQ0MS00LjIyMTEgMy43MjU2LTUuMTE2OSA0LjI3MjItNi4xMjExIDMuNzM0Ny0wLjY0NzAzLTAuMzQ2MjctMS4xNzY0LTAuOTI5NTItMS4xNzY0LTEuMjk2MSAwLTAuODQ3NCAzLjcwOTctNS4yMDY3IDEzLjQ3Ni0xNS44MzYgNC4yNjYxLTQuNjQzIDguNDQzMS05LjQ3MTYgOS4yODIyLTEwLjczIDIuOTU4Mi00LjQzNzIgMS40NjgyLTEwLjQ5Ni0zLjQzMjQtMTMuOTU4LTMuMzExNS0yLjMzOTItOC4yMTQxLTIuNTI3My0xMS41ODQtMC40NDQ0OC0xLjIwMyAwLjc0MzQ3LTEzLjMyNiAxMi43NTktMjYuOTQxIDI2LjcwMmwtMjQuNzU0IDI1LjM1djY3LjI5Nmg0MC4zNHoiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1taXRlcmxpbWl0PSIwIiBzdHJva2Utd2lkdGg9IjM0LjkyNCIvPjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.28295" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="70" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjEyMi44NG1tIiBoZWlnaHQ9IjY3Ljc5bW0iIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDEyMi44NCA2Ny43OSIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDcuODA0IC04MS43ODQpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSIxODUuOTYiPjxwYXRoIGQ9Im0xMDIuODYgODEuNzg0djM4LjA0OGEyNC4yNTMgMjQuMjUzIDAgMCAxIDYuMzY5MS0wLjg3Nzk5IDI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjkxIDAuODUyMTV2LTM4LjAyMnoiLz48cGF0aCBkPSJtNDcuODA0IDEzNi44NHYxMi43MzloMzguMDQ4YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC44ODQwOC02LjM2OTMgMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg4NDA4LTYuMzY5M3ptODQuODE0IDBhMjQuMjUzIDI0LjI1MyAwIDAgMSAwLjg1ODI3IDYuMzY5MyAyNC4yNTMgMjQuMjUzIDAgMCAxLTAuODc3NjMgNi4zNjkzaDM4LjA0MXYtMTIuNzM5eiIvPjxwYXRoIGQ9Im0xMzQuNDIgODYuODMtMTkuMDExIDMyLjkyNGEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAzNSA2LjM2OTFsMTkuMDA1LTMyLjkyNHoiLz48cGF0aCBkPSJtODQuMDMyIDg2LjgzLTExLjAzNSA2LjM2OTEgMTkuMDQzIDMyLjk3NmEyNC4yNTMgMjQuMjUzIDAgMCAxIDExLjAyMi02LjM4ODh6Ii8+PHBhdGggZD0ibTU5LjIxOSAxMDYuOTgtNi4zNjkxIDExLjAzNSAzMi45NTYgMTkuMDNhMjQuMjUzIDI0LjI1MyAwIDAgMSA2LjM4ODgtMTEuMDIyem03My40MjQgNDIuMzkxYTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY3IDAuMjA2MTloMC40MjM3NXoiLz48cGF0aCBkPSJtMTU5LjIzIDEwNi45OC0zMi45MjQgMTkuMDExYTI0LjI1MyAyNC4yNTMgMCAwIDEgNi4zNjI5IDExLjAzNWwzMi45My0xOS4wMTF6bS03My40MjQgNDIuMzkxLTAuMzU3MDggMC4yMDYxOWgwLjQyMzc1YTI0LjI1MyAyNC4yNTMgMCAwIDEtMC4wNjY2Ni0wLjIwNjE5eiIvPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="71" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjguM21tIiBoZWlnaHQ9IjguM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA4LjMgOC4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwLjY5NiAtNzguNTQ1KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICA8cmVjdCB4PSI2MC44NDciIHk9Ijc4LjY5NiIgd2lkdGg9IjcuOTk4NCIgaGVpZ2h0PSI3Ljk5ODQiIHJ5PSIxLjM4NzciIHN0cm9rZS13aWR0aD0iLjMwMTU3Ii8+CiAgPHJlY3QgeD0iNjEuMzQ3IiB5PSI3OS4xOTYiIHdpZHRoPSI2Ljk5OCIgaGVpZ2h0PSI2Ljk5OCIgcnk9IjEuMjE0MiIgc3Ryb2tlLXdpZHRoPSIuMzAxOTciLz4KICA8cmVjdCB4PSI2MS44NDYiIHk9Ijc5LjY5NSIgd2lkdGg9IjYiIGhlaWdodD0iNiIgcnk9IjEuMDQxIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="8.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjExOS4xNW1tIiBoZWlnaHQ9IjE0MC4yNm1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAxMTkuMTUgMTQwLjI2IiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00Ni4zNDIgLTY4LjU2NCkiPjxnPjxjaXJjbGUgY3g9IjE0NyIgY3k9IjEwMy43MSIgcj0iMTAuNTEiLz48cGF0aCBkPSJtMTM3LjIxIDExOS4zNWMtMS42NDQ3IDAtMi4yNTQ0IDAuMTcxMjgtMi44NTU2IDAuOTc4MDUtMC42NzMyMyAwLjkwMzM5LTAuMjU2ODggMi41OTgyLTAuMTM1MzggMy4zNzcybDQuNTIxNyAyOS4wMTdjMC4xNzU2MyAxLjEyNzItMC4yMDMzMyAyLjE2OTUtMC45MDc5NiAyLjk5NTJoMjMuMDgzYzIuNTEyNiAwIDQuOTExNS0yLjA1MTMgNC41MzU2LTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjMxLTQuNTM1Ni00LjUzNTYtNC41MzU2eiIvPjxwYXRoIGQ9Im0xNDAuNSAxNTEuNGMtMC42NjU4OCAwLTEuMzEyNSAwLjE0Mzg0LTEuODk5NiAwLjQwMDQ5bDAuMTM5NTMgMC45MjM0NmMwLjI4MDMzIDEuODUzLTAuOTgzMzQgMy40NjQ1LTIuNjg2MiA0LjE2NDFsNC4xODc5IDQ3LjQwNWMwLjIyMDkzIDIuNTAwNSAyLjAyMDggNC41MzE1IDQuNTMxIDQuNTMxNWg0LjQ2NzRjMi41MTAyIDAgNC4zMTEtMi4wMzEgNC41MzEtNC41MzE1bDQuMjU0NS00OC4zNjJjMC4yMTk5OS0yLjUwMDYtMi4wMjA4LTQuNTMxLTQuNTMxLTQuNTMxeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTY0LjgzNCA5My4xOThhMTAuNTEgMTAuNTEgMCAwIDAtMTAuNTEgMTAuNTEgMTAuNTEgMTAuNTEgMCAwIDAgOC41OTEyIDEwLjMxNWwtMC4xMzkwMS0wLjI1ODljLTMuMzE4My02LjE5NTctMS4wMDE3LTEzLjg1NSA1LjE5NC0xNy4xNzMgMS4wNTUyLTAuNTY1MTYgMi4xNTI5LTAuOTY2NDMgMy4yNjQ0LTEuMjEzNGExMC41MSAxMC41MSAwIDAgMC02LjQwMDYtMi4xNzkyeiIgc3Ryb2tlLXdpZHRoPSIuMTE0ODkiLz48cGF0aCBkPSJtNTUuMDQ2IDExOS4zNWMtMi41MTI2IDAtNC4xNTk4IDIuMDUwOC00LjUzNTYgNC41MzUxbC00LjEyOTUgMjcuMjk3Yy0wLjM3NTg2IDIuNDg0MyAyLjAyMjYgNC41MzUxIDQuNTM1MSA0LjUzNTFoMjcuODM2YzIuMTk5MSAwIDUuNTcxOS0wLjE0MDY4IDQuMjYxOS0yLjk5NjItNS4wMjYtMTAuOTU2LTE3LjI0NS0zMy4zNzEtMTcuMjQ1LTMzLjM3MXoiLz48cGF0aCBkPSJtNTguMzM3IDE1MS40aDEyLjk5NWMyLjUxMDIgMCA0Ljc1MSAyLjAzMDUgNC41MzEgNC41MzExbC00LjI1NDggNDguMzYyYy0wLjIxOTk5IDIuNTAwNi0yLjAyMDggNC41MzExLTQuNTMxIDQuNTMxMWgtNC40NjY5Yy0yLjUxMDIgMC00LjMxMDEtMi4wMzA2LTQuNTMxMS00LjUzMTFsLTQuMjczLTQ4LjM2MmMtMC4yMjA5My0yLjUwMDUgMi4wMjA5LTQuNTMxMSA0LjUzMTEtNC41MzExeiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utb3BhY2l0eT0iLjUiIHN0cm9rZS13aWR0aD0iMi43NTA1Ii8+PHBhdGggZD0ibTEwMi40MiAxMTkuMzVoLTExLjg5OXY1LjUzMjdsOC44OTYyIDQuNjgyMXoiLz48Y2lyY2xlIGN4PSIxMDYuMzIiIGN5PSIxMDMuNzEiIHI9IjEwLjUxIi8+PHBhdGggZD0ibTk2LjUzMyAxMTkuMzVjLTIuNTEyNiAwLTQuMTU5MyAyLjA1MTMtNC41MzUxIDQuNTM1NmwxLjQ5MzYgOS43ODU0czAuNTAzMzcgMjIuMDQ3IDMuMzM1MiAyMi4wNDdsMjMuNDEyLTFlLTNjMi41MTI2LTEuMWUtNCA0LjkxMS0yLjA1MTMgNC41MzUxLTQuNTM1NmwtNC4xMjk1LTI3LjI5NmMtMC4zNzU4NS0yLjQ4NDMtMi4wMjI2LTQuNTM1Ni00LjUzNTEtNC41MzU2eiIvPjxwYXRoIGQ9Im05OS44MjMgMTUxLjRoMTIuOTk1YzIuNTEwMiAwIDQuNzUxIDIuMDMwNSA0LjUzMSA0LjUzMTFsLTQuMjU0OCA0OC4zNjJjLTAuMjE5OTkgMi41MDA2LTIuMDIwOCA0LjUzMTEtNC41MzEgNC41MzExaC00LjQ2NjljLTIuNTEwMiAwLTQuMzEwMS0yLjAzMDYtNC41MzExLTQuNTMxMWwtNC4yNzMtNDguMzYyYy0wLjIyMDkzLTIuNTAwNSAyLjAyMDktNC41MzExIDQuNTMxMS00LjUzMTF6IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS1vcGFjaXR5PSIuNSIgc3Ryb2tlLXdpZHRoPSIyLjc1MDUiLz48cmVjdCB0cmFuc2Zvcm09InJvdGF0ZSgtMjguMTczKSIgeD0iMTIuNjUxIiB5PSIxMjcuNTgiIHdpZHRoPSIxMS4yOTUiIGhlaWdodD0iNjIuMDg0IiByeT0iNC41MzExIi8+PHBhdGggZD0ibTk1LjI5MiAxNTUuOTMgMS4yODExLTEuMzk2Mi0xLjI5NjItNC41ODU4LTguMzk0NS0xNC41MjMiLz48ZyBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIzLjY2MiI+PHBhdGggZD0ibTEwNi4zMiA3MC4zOTV2MTQuOTczIi8+PHBhdGggZD0ibTg1LjA2MyA3Ni4yNjUgNy40ODY3IDEyLjk2NyIvPjxwYXRoIGQ9Im0xMjcuNTggNzYuMjY1LTcuNDg2NyAxMi45NjciLz48L2c+PC9nPjwvZz48L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.58727" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjUuNW1tIiBoZWlnaHQ9IjUuNW1tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1LjUgNS41IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLS4yMjQ5OCAtLjIyNDk4KSI+CiAgPHBhdGggZD0ibTUuNjYxNyAwLjI4ODMxLTUuMzczMyA1LjM3MzMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2YwMCIgc3Ryb2tlLXdpZHRoPSIuMTc5MTEiLz4KIDwvZz4KPC9zdmc+Cg==" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.93" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjM3LjE3OCIgaGVpZ2h0PSIzNy4xNzgiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDM3LjE3OCAzNy4xNzgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtLjg1OTM4IC0xLjExNzIpIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbWl0ZXJsaW1pdD0iMCIgc3Ryb2tlLXdpZHRoPSI1Ni4yODMiPgogIDxwYXRoIGQ9Im0xNy41MjEgMS4xMTcydjExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3Ny0wLjI2NTYyIDcuMzQwNSA3LjM0MDUgMCAwIDEgMS45Mjc3IDAuMjU3ODF2LTExLjUwOHptMCAyNS42NjR2MTEuNTE0aDMuODU1NXYtMTEuNTE0YTcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3IDAuMjY1NjIgNy4zNDA1IDcuMzQwNSAwIDAgMS0xLjkyNzctMC4yNjU2MnoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSg5MCkiIGQ9Im0xNy43NzktMC44NTkzOGgzLjg1NTV2LTExLjUxNmE3LjM0MDUgNy4zNDA1IDAgMCAxLTEuOTI3NyAwLjI2NzU4IDcuMzQwNSA3LjM0MDUgMCAwIDEtMS45Mjc3LTAuMjY3NTh6bTAtMjUuNjdhNy4zNDA1IDcuMzQwNSAwIDAgMSAxLjkyNzctMC4yNTk3NiA3LjM0MDUgNy4zNDA1IDAgMCAxIDEuOTI3NyAwLjI2NTYydi0xMS41MTRoLTMuODU1NXoiLz4KICA8cGF0aCB0cmFuc2Zvcm09InJvdGF0ZSgzMCkiIGQ9Im0yNC43NjktMTEuMjQ3LTYuMDdlLTQgMTEuNTA3YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTYzLTQuNTQ5NGUtNGwtMC4wMDExLTExLjUwNnptLTMuNjllLTQgMjUuNjUyLTIuNzVlLTQgMTEuNTI3IDMuODU2My00LjU1ZS00IDcuOTllLTQgLTExLjUxOGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU2OC0wLjAwODN6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTMwKSIgZD0ibTguOTE3OCA4LjIwMjMtMy44NTYzLTQuNTQ5ZS00IDAuMDAxMjUgMTEuNTI1YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4LTAuMDA2NnptMy42ODhlLTQgMjUuNjUyYTcuMzQwNSA3LjM0MDUgMCAwIDEtMy44NTY4IDAuMDA4M2w3Ljk4N2UtNCAxMS41MTggMy44NTQ2LTUuMjJlLTR6Ii8+CiAgPHBhdGggdHJhbnNmb3JtPSJyb3RhdGUoLTYwKSIgZD0ibS01LjQxMzcgOC4xMDc1LTMuODU2MyA0LjU0OWUtNCAtNy45ODdlLTQgMTEuNTE4YTcuMzQwNSA3LjM0MDUgMCAwIDEgMy44NTU4IDAuMDA2NnptMS41NDVlLTQgMjUuNjZhNy4zNDA1IDcuMzQwNSAwIDAgMS0zLjg1NjgtMC4wMDgzbDAuMDAxNDIgMTEuNTI2IDMuODU0NiA1LjIyZS00eiIvPgogIDxwYXRoIHRyYW5zZm9ybT0icm90YXRlKDYwKSIgZD0ibTI0Ljg2My0yNS41OCA2LjA3ZS00IDExLjUwN2E3LjM0MDUgNy4zNDA1IDAgMCAxIDMuODU1MyAwLjAwMjFsMy42OWUtNCAtMTEuNTA4em0tMS41NWUtNCAyNS42NiA3Ljk5ZS00IDExLjUxOCAzLjg1NDYtNS4yMmUtNCA0LjRlLTQgLTExLjUyNGE3LjM0MDUgNy4zNDA1IDAgMCAxLTMuODU1OCAwLjAwNjU3MjZ6Ii8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjYuM21tIiBoZWlnaHQ9IjYuM21tIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2LjMgNi4zIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYxLjE3MyAtNzkuMDA3KSI+CiAgPHJlY3QgeD0iNjEuMzIzIiB5PSI3OS4xNTciIHdpZHRoPSI2IiBoZWlnaHQ9IjYiIHJ5PSIxLjA0MSIgZmlsbD0iI2YwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii4zIi8+CiA8L2c+Cjwvc3ZnPgo=" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="6.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SvgMarker">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="fixedAspectRatio" value="0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="base64:PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBDcmVhdGVkIHdpdGggSW5rc2NhcGUgKGh0dHA6Ly93d3cuaW5rc2NhcGUub3JnLykgLS0+Cjxzdmcgd2lkdGg9IjMzLjQ4MiIgaGVpZ2h0PSIzNy42NjMiIHZlcnNpb249IjEuMSIgdmlld0JveD0iMCAwIDMzLjQ4MiAzNy42NjMiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiA8cGF0aCBkPSJtNy43MDMxIDE0LjY0OWExMS45MDYgMTEuOTA2IDAgMCAwLTcuNzAzMSAxMS4xMDcgMTEuOTA2IDExLjkwNiAwIDAgMCAxMS45MDYgMTEuOTA2IDExLjkwNiAxMS45MDYgMCAwIDAgMTEuOTA2LTExLjkwNiAxMS45MDYgMTEuOTA2IDAgMCAwLTAuMTIxMDktMS42ODE2aC0zLjgxMjVhOC4yNzc1IDguMjc3NSAwIDAgMSAwLjE2Nzk3IDEuNjQ2NSA4LjI3NzUgOC4yNzc1IDAgMCAxLTguMjc5MyA4LjI3NzMgOC4yNzc1IDguMjc3NSAwIDAgMS04LjI3NzMtOC4yNzczIDguMjc3NSA4LjI3NzUgMCAwIDEgNC4yMTI5LTcuMTg3NXoiLz4KIDxjaXJjbGUgY3g9IjExLjIzNCIgY3k9IjMuNzUyNCIgcj0iMy43NTI0Ii8+CiA8cGF0aCBkPSJtOS43MzYyIDE1LjYxaDEzLjUzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDczNCIvPgogPHBhdGggZD0ibTEwLjI5NiA0LjY5MjR2MTYuODc0aDE0LjQ3NWw0LjA4MDggMTMuMDQ5IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMy4xNzUxIi8+CiA8cmVjdCB4PSI4LjcwODQiIHk9IjIwLjE4NCIgd2lkdGg9IjMuOTQxMSIgaGVpZ2h0PSIyLjk2NzIiIHJ5PSIwIi8+CiA8cGF0aCBkPSJtMjguODUyIDM0LjYxNSAxLjUxNTItMC40NjYzMSAzLjExNDktMC45ODY5NC0wLjQ1NjI4LTEuNjE1MS00LjY3ODQgMS40NTQ3eiIvPgo8L3N2Zz4K" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="parameters"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="4.60054" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Стационарные организации социального обслуживания" value="602010501" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Комплексные, полустационарные и нестационарные организации социального обслуживания" value="602010502" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Организации (отделения) социального обслуживания на дому" value="602010503" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" value="602010504" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объекты молодежной политики" value="602010506" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBER" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OKTMO" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ADDRESS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ST_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Геронтологический центр" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Социальный приют для детей" value="10" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Специальный дом-интернат" value="11" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Специальный дом для одиноких престарелых" value="12" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Центр временного проживания граждан пожилого возраста и инвалидов" value="13" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Центр помощи детям, оставшимся без попечения родителей" value="14" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Геронтопсихиатрический центр" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Детский дом-интернат для детей с физическими недостатками" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Детский дом-интернат для умственно отсталых детей" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Дом-интернат для ветеранов войны и труда" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Дом-интернат для престарелых и инвалидов" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Дом-интернат милосердия для престарелых и инвалидов" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Психоневрологический интернат" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Социальная гостиница" value="9" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SP_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Комплексный центр по оказанию помощи лицам без определенного места жительства и занятий" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Центр социальной адаптации несовершеннолетних и молодежи" value="10" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Центр психолого-педагогической помощи" value="11" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Центр дневного пребывания граждан пожилого возраста и инвалидов" value="12" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Центр социальной помощи семье и детям" value="13" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Комплексный центр социального обслуживания населения" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Кризисный центр помощи женщинам" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Реабилитационный (Социально-реабилитационный) центр для детей и подростков с ограниченными (умственными и физическими) возможностями" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Социально-оздоровительный центр" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Социально-реабилитационный центр для несовершеннолетних" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Территориальный центр социальной помощи семье и детям" value="7" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Организация, оказывающая социальную помощь лицам без определенного места жительства и занятий" value="8" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Центр социального обслуживания граждан пожилого возраста и инвалидов" value="9" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SSAH_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Центр социального обслуживания на дому граждан пожилого возраста и инвалидов" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Специализированный центр социально-медицинского обслуживания на дому граждан пожилого возраста и инвалидов" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="USA_STYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Центр срочного социального обслуживания" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Консультативный центр" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Центр экстренной психологической помощи по телефону" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CAPACITY" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="PERSON_PH" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="PERSON_PD" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="BLD_AREA" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1e+06" type="double"/>
            <Option name="Min" value="0" type="double"/>
            <Option name="Precision" value="2" type="int"/>
            <Option name="Step" value="1" type="double"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="WRK_COUNT" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="1000000" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FUNCTION" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="EVENT_TIME" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="false" type="bool"/>
            <Option name="Max" value="2100" type="int"/>
            <Option name="Min" value="0" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий, реконструируемый, строящийся" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к размещению" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к реконструкции" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый к ликвидации" value="4" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REG_STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Федеральное значение" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Региональное значение" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального района" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение городского округа" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение поселения" value="5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Иное значение, местное значение муниципального района, необходимое для осуществления полномочий по вопросам местного значения муниципального района, предусмотренных частью 4 статьи 14, статьей 15 Федерального закона от 6 октября 2003 г. N 131-ФЗ «Об общих принципах организации местного самоуправления в Российской Федерации»" value="6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Местное значение муниципального округа" value="8" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTROKS" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="KADASTRZU" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NAMEDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="DATEDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBERDOCOSN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="NUMBER" index="2" name=""/>
    <alias field="NAME" index="3" name="Наименование объекта"/>
    <alias field="OKTMO" index="4" name="Код ОКТМО"/>
    <alias field="ADDRESS" index="5" name="Местоположение, адресное описание"/>
    <alias field="ST_STYPE" index="6" name=""/>
    <alias field="SP_STYPE" index="7" name=""/>
    <alias field="SSAH_STYPE" index="8" name=""/>
    <alias field="USA_STYPE" index="9" name=""/>
    <alias field="CAPACITY" index="10" name=""/>
    <alias field="PERSON_PH" index="11" name=""/>
    <alias field="PERSON_PD" index="12" name=""/>
    <alias field="BLD_AREA" index="13" name="Общая площадь здания, комплекса зданий, кв. м"/>
    <alias field="WRK_COUNT" index="14" name="Количество рабочих мест, единиц"/>
    <alias field="FUNCTION" index="15" name="Назначение объекта"/>
    <alias field="EVENT_TIME" index="16" name=""/>
    <alias field="SOURCE" index="17" name="Источник данных"/>
    <alias field="NOTE" index="18" name="Примечание"/>
    <alias field="STATUS" index="19" name="Статус объекта"/>
    <alias field="REG_STATUS" index="20" name="Значение объекта"/>
    <alias field="KADASTROKS" index="21" name="Кадастровый номер объекта капитального строительства"/>
    <alias field="KADASTRZU" index="22" name=""/>
    <alias field="NAMEDOCOSN" index="23" name=""/>
    <alias field="DATEDOCOSN" index="24" name=""/>
    <alias field="NUMBERDOCOSN" index="25" name=""/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'602010501'" applyOnUpdate="0"/>
    <default field="NUMBER" expression="''" applyOnUpdate="0"/>
    <default field="NAME" expression="''" applyOnUpdate="0"/>
    <default field="OKTMO" expression="''" applyOnUpdate="0"/>
    <default field="ADDRESS" expression="''" applyOnUpdate="0"/>
    <default field="ST_STYPE" expression="if(&quot;CLASSID&quot; = '602010501', attribute('ST_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="SP_STYPE" expression="if(&quot;CLASSID&quot; = '602010502', attribute('SP_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="SSAH_STYPE" expression="if(&quot;CLASSID&quot; = '602010503', attribute('SSAH_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="USA_STYPE" expression="if(&quot;CLASSID&quot; = '602010504', attribute('USA_STYPE'), NULL)" applyOnUpdate="1"/>
    <default field="CAPACITY" expression="0" applyOnUpdate="0"/>
    <default field="PERSON_PH" expression="0" applyOnUpdate="0"/>
    <default field="PERSON_PD" expression="0" applyOnUpdate="0"/>
    <default field="BLD_AREA" expression="0" applyOnUpdate="0"/>
    <default field="WRK_COUNT" expression="0" applyOnUpdate="0"/>
    <default field="FUNCTION" expression="''" applyOnUpdate="0"/>
    <default field="EVENT_TIME" expression="0" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="REG_STATUS" expression="1" applyOnUpdate="0"/>
    <default field="KADASTROKS" expression="''" applyOnUpdate="0"/>
    <default field="KADASTRZU" expression="''" applyOnUpdate="0"/>
    <default field="NAMEDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="DATEDOCOSN" expression="''" applyOnUpdate="0"/>
    <default field="NUMBERDOCOSN" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="1" field="NUMBER" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="1" field="OKTMO" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="ADDRESS" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="ST_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="SP_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="SSAH_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="USA_STYPE" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="CAPACITY" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="PERSON_PH" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="PERSON_PD" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="BLD_AREA" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="WRK_COUNT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FUNCTION" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="EVENT_TIME" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="REG_STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="2" field="KADASTROKS" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="KADASTRZU" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NAMEDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="DATEDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="1" field="NUMBERDOCOSN" unique_strength="0" notnull_strength="0" constraints="4"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="NUMBER" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;length(&quot;NUMBER&quot;) > 0,&#xa;&#x9;length(&quot;NUMBER&quot;) >= 0)"/>
    <constraint field="NAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;NAME&quot;) > 0"/>
    <constraint field="OKTMO" desc="Код ОКТМО должен состоять из 8 или 11 цифр. Запись об ОКТМО не должна содержать пробелов и других служебных символов." exp="regexp_match(&quot;OKTMO&quot;, '^(\\d{8}|\\d{11})$')"/>
    <constraint field="ADDRESS" desc="" exp=""/>
    <constraint field="ST_STYPE" desc="Заполняется для объекта 602010501" exp="if(&quot;CLASSID&quot; = '602010501', &quot;ST_STYPE&quot; IS NOT NULL, &quot;ST_STYPE&quot; IS NULL)"/>
    <constraint field="SP_STYPE" desc="Заполняется для объекта 602010502" exp="if(&quot;CLASSID&quot; = '602010502', &quot;SP_STYPE&quot; IS NOT NULL, &quot;SP_STYPE&quot; IS NULL)"/>
    <constraint field="SSAH_STYPE" desc="Заполняется для объекта 602010503" exp="if(&quot;CLASSID&quot; = '602010503', &quot;SSAH_STYPE&quot; IS NOT NULL, &quot;SSAH_STYPE&quot; IS NULL)"/>
    <constraint field="USA_STYPE" desc="Заполняется для объекта 602010504" exp="if(&quot;CLASSID&quot; = '602010504', &quot;USA_STYPE&quot; IS NOT NULL, &quot;USA_STYPE&quot; IS NULL)"/>
    <constraint field="CAPACITY" desc="Заполняется для объектов 602010501, 602010502" exp="if (&quot;CLASSID&quot; = '602010501' OR &quot;CLASSID&quot; = '602010502',&#xa;&#x9;&quot;CAPACITY&quot; > 0,&#xa;&#x9;&quot;CAPACITY&quot; >= 0)"/>
    <constraint field="PERSON_PH" desc="Заполняется для объектов 602010502, 602010503" exp="if (&quot;CLASSID&quot; = '602010502' OR &quot;CLASSID&quot; = '602010503',&#xa;&#x9;&quot;PERSON_PH&quot; > 0,&#xa;&#x9;&quot;PERSON_PH&quot; >= 0)"/>
    <constraint field="PERSON_PD" desc="Заполняется для объектов 602010502, 602010504" exp="if (&quot;CLASSID&quot; = '602010502' OR &quot;CLASSID&quot; = '602010504',&#xa;&#x9;&quot;PERSON_PD&quot; > 0,&#xa;&#x9;&quot;PERSON_PD&quot; >= 0)"/>
    <constraint field="BLD_AREA" desc="" exp=""/>
    <constraint field="WRK_COUNT" desc="" exp=""/>
    <constraint field="FUNCTION" desc="" exp=""/>
    <constraint field="EVENT_TIME" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;&quot;EVENT_TIME&quot; > 0,&#xa;&#x9;&quot;EVENT_TIME&quot; >= 0)"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="REG_STATUS" desc="" exp=""/>
    <constraint field="KADASTROKS" desc="Кадастровый номер объекта должен соответствовать формату, принятому в ЕГРН" exp="regexp_match(&quot;KADASTROKS&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$')"/>
    <constraint field="KADASTRZU" desc="Обязательно для значений атрибута &quot;STATUS&quot; 1, 3, 4" exp="if (&quot;STATUS&quot; = 1 OR &quot;STATUS&quot; = 3 OR &quot;STATUS&quot; = 4,&#xa;&#x9;regexp_match(&quot;KADASTRZU&quot;, '^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1}):\\d{1,}$|^\\d{1,2}:\\d{1,2}:(\\d{6,7}|\\d{1})$'),&#xa;&#x9;length(&quot;KADASTRZU&quot;) >= 0)"/>
    <constraint field="NAMEDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;length(&quot;NAMEDOCOSN&quot;) > 0,&#xa;&#x9;length(&quot;NAMEDOCOSN&quot;) >= 0)"/>
    <constraint field="DATEDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3. Формат даты (ДД.ММ.ГГГГ)." exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;regexp_match(&quot;DATEDOCOSN&quot;, '^\\d{2}\\.\\d{2}\\.\\d{4}$'),&#xa;&#x9;length(&quot;DATEDOCOSN&quot;) >= 0)"/>
    <constraint field="NUMBERDOCOSN" desc="Обязательно для значений атрибута &quot;STATUS&quot; 2, 3" exp="if (&quot;STATUS&quot; = 2 OR &quot;STATUS&quot; = 3,&#xa;&#x9;length(&quot;NUMBERDOCOSN&quot;) > 0,&#xa;&#x9;length(&quot;NUMBERDOCOSN&quot;) >= 0)"/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="NAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="OKTMO">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="19" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="20" name="REG_STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ADDRESS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="BLD_AREA">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="14" name="WRK_COUNT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="15" name="FUNCTION">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="17" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="18" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="21" name="KADASTROKS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Условные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер согласно положению о территориальном планировании" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="2" name="NUMBER">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип стационарной организации социального обслуживания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010501'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="6" name="ST_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип комплексной, полустационарной, нестационарной организации социального обслуживания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010502'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="7" name="SP_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип организации (отделения) социального обслуживания на дому" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010503'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="8" name="SSAH_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Подтип организации (отделения) срочного социального обслуживания, срочной социально-консультационной помощи" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; = '602010504'">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="9" name="USA_STYPE">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Вместимость стационарных организаций, мест" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; IN ('602010501', '602010502')">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="10" name="CAPACITY">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Численность граждан, обслуживаемых на дому, чел." collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; IN ('602010502', '602010503')">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="11" name="PERSON_PH">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Мощность учреждений (отделений), число обслуживаемых лиц в сутки (без услуг стационара)" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;CLASSID&quot; IN ('602010502', '602010504')">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="12" name="PERSON_PD">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Срок реализации" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="16" name="EVENT_TIME">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Кадастровый номер земельного участка и (или) номер кадастрового квартала, в границах которого расположен объект" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (1, 3, 4)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="22" name="KADASTRZU">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Наименование документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="23" name="NAMEDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Дата документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="24" name="DATEDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
      <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="1" collapsed="0" name="Номер документа-основания" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="1" visibilityExpression="&quot;STATUS&quot; IN (2, 3)">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
        </labelStyle>
        <attributeEditorField showLabel="0" index="25" name="NUMBERDOCOSN">
          <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
            <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
          </labelStyle>
        </attributeEditorField>
      </attributeEditorContainer>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="ADDRESS" editable="1"/>
    <field name="BLD_AREA" editable="1"/>
    <field name="CAPACITY" editable="1"/>
    <field name="CLASSID" editable="1"/>
    <field name="DATEDOCOSN" editable="1"/>
    <field name="EVENT_TIME" editable="1"/>
    <field name="FUNCTION" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="KADASTROKS" editable="1"/>
    <field name="KADASTRZU" editable="1"/>
    <field name="NAME" editable="1"/>
    <field name="NAMEDOCOSN" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBER" editable="1"/>
    <field name="NUMBERDOCOSN" editable="1"/>
    <field name="OKTMO" editable="1"/>
    <field name="PERSON_PD" editable="1"/>
    <field name="PERSON_PH" editable="1"/>
    <field name="REG_STATUS" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="SP_STYPE" editable="1"/>
    <field name="SSAH_STYPE" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="ST_STYPE" editable="1"/>
    <field name="USA_STYPE" editable="1"/>
    <field name="WRK_COUNT" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="ADDRESS"/>
    <field labelOnTop="1" name="BLD_AREA"/>
    <field labelOnTop="1" name="CAPACITY"/>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="DATEDOCOSN"/>
    <field labelOnTop="1" name="EVENT_TIME"/>
    <field labelOnTop="1" name="FUNCTION"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="KADASTROKS"/>
    <field labelOnTop="1" name="KADASTRZU"/>
    <field labelOnTop="1" name="NAME"/>
    <field labelOnTop="1" name="NAMEDOCOSN"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBER"/>
    <field labelOnTop="1" name="NUMBERDOCOSN"/>
    <field labelOnTop="1" name="OKTMO"/>
    <field labelOnTop="1" name="PERSON_PD"/>
    <field labelOnTop="1" name="PERSON_PH"/>
    <field labelOnTop="1" name="REG_STATUS"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="SP_STYPE"/>
    <field labelOnTop="1" name="SSAH_STYPE"/>
    <field labelOnTop="1" name="STATUS"/>
    <field labelOnTop="1" name="ST_STYPE"/>
    <field labelOnTop="1" name="USA_STYPE"/>
    <field labelOnTop="1" name="WRK_COUNT"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ADDRESS" reuseLastValue="0"/>
    <field name="BLD_AREA" reuseLastValue="0"/>
    <field name="CAPACITY" reuseLastValue="0"/>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="DATEDOCOSN" reuseLastValue="0"/>
    <field name="EVENT_TIME" reuseLastValue="0"/>
    <field name="FUNCTION" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="KADASTROKS" reuseLastValue="0"/>
    <field name="KADASTRZU" reuseLastValue="0"/>
    <field name="NAME" reuseLastValue="0"/>
    <field name="NAMEDOCOSN" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBER" reuseLastValue="0"/>
    <field name="NUMBERDOCOSN" reuseLastValue="0"/>
    <field name="OKTMO" reuseLastValue="0"/>
    <field name="PERSON_PD" reuseLastValue="0"/>
    <field name="PERSON_PH" reuseLastValue="0"/>
    <field name="REG_STATUS" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="SP_STYPE" reuseLastValue="0"/>
    <field name="SSAH_STYPE" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="ST_STYPE" reuseLastValue="0"/>
    <field name="USA_STYPE" reuseLastValue="0"/>
    <field name="WRK_COUNT" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>0</layerGeometryType>
</qgis>
