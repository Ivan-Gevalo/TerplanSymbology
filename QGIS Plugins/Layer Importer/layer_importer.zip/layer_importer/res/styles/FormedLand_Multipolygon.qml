<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis styleCategories="Symbology|Labeling|Fields|Forms|Actions" labelsEnabled="1" version="3.28.15-Firenze">
  <renderer-v2 referencescale="-1" symbollevels="0" enableorderby="0" forceraster="0" type="RuleRenderer">
    <rules key="{84f35168-029a-4725-80e5-b056ba9ec5d1}">
      <rule symbol="0" label="Границы существующих (сохраняемых) земельных участков" filter="&quot;Class&quot; = '7F.1'" key="{1863594e-26c3-4bbb-a80c-38909c26fe33}"/>
      <rule symbol="1" label="Границы земельных участков, предполагаемых к изъятию для государственных или муниципальных нужд" filter="&quot;Class&quot; = '7F.2'" key="{71c600d7-93fd-450f-a6cd-438439ff2ea5}"/>
      <rule symbol="2" label="Границы изменяемых земельных участков" filter="&quot;Class&quot; = '7F.3'" key="{4f5f3490-2d6c-4575-aa21-fc2034bb302e}"/>
      <rule symbol="3" label="Границы образуемых земельных участков" filter="&quot;Class&quot; = '7F.4'" key="{f9b85c01-c5bf-4537-8f2e-8f3ed1f965c2}"/>
      <rule symbol="4" label="Границы образуемых земельных участков, которые после образования будут относиться к имуществу общего пользования" filter="&quot;Class&quot; = '7F.5'" key="{8877a3cc-0af0-426d-a86d-bce3b23a32be}"/>
      <rule symbol="5" label="Границы образуемых земельных участков, которые после образования будут относиться к территориям общего пользования" filter="&quot;Class&quot; = '7F.6'" key="{61b230da-e221-4f75-9a6a-fced8469afd5}"/>
      <rule symbol="6" label="Границы образуемых земельных участков, предполагаемых к изъятию для государственных или муниципальных нужд" filter="&quot;Class&quot; = '7F.7'" key="{5393f9a3-b05d-4b6a-b2cf-5dde8335ed5a}"/>
    </rules>
    <symbols>
      <symbol name="0" force_rhr="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="255,230,129,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="1" force_rhr="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="255,129,139,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="2" force_rhr="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="129,255,146,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="3" force_rhr="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="255,163,253,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="4" force_rhr="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="255,163,253,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="LinePatternFill" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="clip_mode" value="during_render" type="QString"/>
            <Option name="color" value="0,0,255,255" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="distance" value="3" type="QString"/>
            <Option name="distance_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_unit" value="MM" type="QString"/>
            <Option name="line_width" value="0.26" type="QString"/>
            <Option name="line_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol name="@4@1" force_rhr="0" frame_rate="10" type="line" alpha="1" clip_to_extent="1" is_animated="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleLine" pass="0" locked="0" enabled="1">
              <Option type="Map">
                <Option name="align_dash_pattern" value="0" type="QString"/>
                <Option name="capstyle" value="flat" type="QString"/>
                <Option name="customdash" value="5;2" type="QString"/>
                <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="customdash_unit" value="MM" type="QString"/>
                <Option name="dash_pattern_offset" value="0" type="QString"/>
                <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
                <Option name="draw_inside_polygon" value="0" type="QString"/>
                <Option name="joinstyle" value="miter" type="QString"/>
                <Option name="line_color" value="3,182,0,255" type="QString"/>
                <Option name="line_style" value="solid" type="QString"/>
                <Option name="line_width" value="0.2" type="QString"/>
                <Option name="line_width_unit" value="MM" type="QString"/>
                <Option name="offset" value="0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="ring_filter" value="0" type="QString"/>
                <Option name="trim_distance_end" value="0" type="QString"/>
                <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="trim_distance_end_unit" value="MM" type="QString"/>
                <Option name="trim_distance_start" value="0" type="QString"/>
                <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="trim_distance_start_unit" value="MM" type="QString"/>
                <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
                <Option name="use_custom_dash" value="0" type="QString"/>
                <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol name="5" force_rhr="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="255,163,253,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="LinePatternFill" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option name="angle" value="90" type="QString"/>
            <Option name="clip_mode" value="during_render" type="QString"/>
            <Option name="color" value="0,0,255,255" type="QString"/>
            <Option name="coordinate_reference" value="feature" type="QString"/>
            <Option name="distance" value="3" type="QString"/>
            <Option name="distance_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="distance_unit" value="MM" type="QString"/>
            <Option name="line_width" value="0.26" type="QString"/>
            <Option name="line_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol name="@5@1" force_rhr="0" frame_rate="10" type="line" alpha="1" clip_to_extent="1" is_animated="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleLine" pass="0" locked="0" enabled="1">
              <Option type="Map">
                <Option name="align_dash_pattern" value="0" type="QString"/>
                <Option name="capstyle" value="flat" type="QString"/>
                <Option name="customdash" value="5;2" type="QString"/>
                <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="customdash_unit" value="MM" type="QString"/>
                <Option name="dash_pattern_offset" value="0" type="QString"/>
                <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
                <Option name="draw_inside_polygon" value="0" type="QString"/>
                <Option name="joinstyle" value="miter" type="QString"/>
                <Option name="line_color" value="3,182,0,255" type="QString"/>
                <Option name="line_style" value="solid" type="QString"/>
                <Option name="line_width" value="0.2" type="QString"/>
                <Option name="line_width_unit" value="MM" type="QString"/>
                <Option name="offset" value="0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="ring_filter" value="0" type="QString"/>
                <Option name="trim_distance_end" value="0" type="QString"/>
                <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="trim_distance_end_unit" value="MM" type="QString"/>
                <Option name="trim_distance_start" value="0" type="QString"/>
                <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="trim_distance_start_unit" value="MM" type="QString"/>
                <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
                <Option name="use_custom_dash" value="0" type="QString"/>
                <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol name="6" force_rhr="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" pass="0" locked="0" enabled="1">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="254,28,58,255" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="128,128,128,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontWeight="50" multilineHeight="1" useSubstitutions="0" namedStyle="Regular" textOrientation="horizontal" fontUnderline="0" legendString="Aa" fontLetterSpacing="0" textColor="194,0,123,255" allowHtml="0" capitalization="0" fontKerning="1" forcedBold="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" multilineHeightUnit="Percentage" fieldName="&quot;NominalNum&quot; || '\nS=' || round(&quot;Area&quot;, 0) || ' кв. м'" fontItalic="0" fontStrikeout="0" fontSize="11" isExpression="1" fontWordSpacing="0" fontSizeUnit="Point" textOpacity="1" previewBkgrdColor="255,255,255,255" forcedItalic="0" fontFamily="Open Sans" blendMode="0">
        <families/>
        <text-buffer bufferBlendMode="0" bufferColor="250,250,250,255" bufferDraw="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferSizeUnits="MM" bufferJoinStyle="128" bufferOpacity="1" bufferNoFill="1"/>
        <text-mask maskSize="0" maskedSymbolLayers="" maskType="0" maskJoinStyle="128" maskSizeUnits="MM" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1"/>
        <background shapeRadiiX="0" shapeBlendMode="0" shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeRadiiY="0" shapeRotation="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeFillColor="255,255,255,255" shapeRadiiUnit="Point" shapeRotationType="0" shapeBorderWidthUnit="Point" shapeType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeSVGFile="" shapeSizeY="0.29999999999999999" shapeOpacity="1" shapeOffsetUnit="Point" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetX="0" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="Point" shapeOffsetY="0" shapeSizeX="1" shapeBorderWidth="0">
          <symbol name="markerSymbol" force_rhr="0" frame_rate="10" type="marker" alpha="1" clip_to_extent="1" is_animated="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleMarker" pass="0" locked="0" enabled="1">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="125,139,143,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="circle" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="35,35,35,255" type="QString"/>
                <Option name="outline_style" value="solid" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="2" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol name="fillSymbol" force_rhr="0" frame_rate="10" type="fill" alpha="1" clip_to_extent="1" is_animated="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleFill" pass="0" locked="0" enabled="1">
              <Option type="Map">
                <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="255,255,255,255" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="128,128,128,255" type="QString"/>
                <Option name="outline_style" value="no" type="QString"/>
                <Option name="outline_width" value="0" type="QString"/>
                <Option name="outline_width_unit" value="Point" type="QString"/>
                <Option name="style" value="solid" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowOffsetGlobal="1" shadowScale="100" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowUnder="0" shadowOffsetDist="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowBlendMode="6" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusAlphaOnly="0" shadowOffsetAngle="135"/>
        <dd_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format useMaxLineLengthForAutoWrap="1" reverseDirectionSymbol="0" formatNumbers="0" placeDirectionSymbol="0" autoWrapLength="0" leftDirectionSymbol="&lt;" rightDirectionSymbol=">" multilineAlign="3" wrapChar="" plussign="0" addDirectionSymbol="0" decimals="3"/>
      <placement offsetUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" lineAnchorTextPoint="FollowPlacement" repeatDistanceUnits="MM" lineAnchorPercent="0.5" distUnits="MM" dist="0" polygonPlacementFlags="2" lineAnchorType="0" rotationAngle="0" layerType="PolygonGeometry" priority="5" rotationUnit="AngleDegrees" fitInPolygonOnly="1" maxCurvedCharAngleIn="25" preserveRotation="1" yOffset="0" geometryGenerator="" geometryGeneratorType="PointGeometry" geometryGeneratorEnabled="0" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" centroidWhole="0" offsetType="0" allowDegraded="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistance="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" centroidInside="0" overrunDistanceUnit="MM" lineAnchorClipping="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overlapHandling="PreventOverlap" placement="1" overrunDistance="0" maxCurvedCharAngleOut="-25" quadOffset="4"/>
      <rendering scaleMax="0" fontMaxPixelSize="10000" fontMinPixelSize="3" zIndex="0" obstacle="1" upsidedownLabels="0" unplacedVisibility="0" maxNumLabels="2000" limitNumLabels="0" minFeatureSize="0" labelPerPart="1" drawLabels="1" scaleVisibility="0" obstacleFactor="1" scaleMin="0" mergeLines="0" obstacleType="1" fontLimitPixelSize="0"/>
      <dd_properties>
        <Option type="Map">
          <Option name="name" value="" type="QString"/>
          <Option name="properties"/>
          <Option name="type" value="collection" type="QString"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
          <Option name="blendMode" value="0" type="int"/>
          <Option name="ddProperties" type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
          <Option name="drawToAllParts" value="false" type="bool"/>
          <Option name="enabled" value="0" type="QString"/>
          <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
          <Option name="lineSymbol" value="&lt;symbol name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot; alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; is_animated=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
          <Option name="minLength" value="0" type="double"/>
          <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
          <Option name="minLengthUnit" value="MM" type="QString"/>
          <Option name="offsetFromAnchor" value="0" type="double"/>
          <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
          <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
          <Option name="offsetFromLabel" value="0" type="double"/>
          <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
          <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="Guid" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Class" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Границы существующих (сохраняемых) земельных участков" value="7F.1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Границы земельных участков, предполагаемых к изъятию для государственных или муниципальных нужд" value="7F.2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Границы изменяемых земельных участков" value="7F.3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Границы образуемых земельных участков" value="7F.4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Границы образуемых земельных участков, которые после образования будут относиться к имуществу общего пользования" value="7F.5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Границы образуемых земельных участков, которые после образования будут относиться к территориям общего пользования" value="7F.6" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Границы образуемых земельных участков, предполагаемых к изъятию для государственных или муниципальных нужд" value="7F.7" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Status" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий" value="7B.1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый" value="7B.2" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="FormingType" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Образование земельных участков из земель или земельных участков, находящихся в государственной или муниципальной собственности" value="7G.1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Раздел земельного участка" value="7G.2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Объединение земельных участков" value="7G.3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Выдел земельного участка" value="7G.4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Перераспределение земельных участков" value="7G.5" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name=" " value="{2839923C-8B7D-419E-B84B-CA2FE9B80EC7}" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NominalNum" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Location" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="PermittedUseType" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Area" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Easement" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Note" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="Идентификатор объекта" index="0" field="Guid"/>
    <alias name="Вид границы образуемого (изменяемого) земельного участка" index="1" field="Class"/>
    <alias name="Статус объекта" index="2" field="Status"/>
    <alias name="Способ образования земельного участка" index="3" field="FormingType"/>
    <alias name="Условный или кадастровый номер образуемого (изменяемого) земельного участка" index="4" field="NominalNum"/>
    <alias name="Местоположение (адрес или при отсутствии адреса иное описание местоположения)" index="5" field="Location"/>
    <alias name="Вид разрешенного использования земельного участка и объекта капитального строительства" index="6" field="PermittedUseType"/>
    <alias name="Площадь общая, кв. м" index="7" field="Area"/>
    <alias name="Информация о наличии публичного сервитута" index="8" field="Easement"/>
    <alias name="Примечание" index="9" field="Note"/>
  </aliases>
  <defaults>
    <default field="Guid" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="Class" expression="'7F.1'" applyOnUpdate="0"/>
    <default field="Status" expression="'7B.1'" applyOnUpdate="0"/>
    <default field="FormingType" expression="" applyOnUpdate="0"/>
    <default field="NominalNum" expression="''" applyOnUpdate="0"/>
    <default field="Location" expression="''" applyOnUpdate="0"/>
    <default field="PermittedUseType" expression="''" applyOnUpdate="0"/>
    <default field="Area" expression="round(area($geometry), 2)" applyOnUpdate="1"/>
    <default field="Easement" expression="''" applyOnUpdate="0"/>
    <default field="Note" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint constraints="3" exp_strength="0" notnull_strength="1" field="Guid" unique_strength="1"/>
    <constraint constraints="5" exp_strength="1" notnull_strength="1" field="Class" unique_strength="0"/>
    <constraint constraints="5" exp_strength="1" notnull_strength="1" field="Status" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" notnull_strength="0" field="FormingType" unique_strength="0"/>
    <constraint constraints="5" exp_strength="1" notnull_strength="1" field="NominalNum" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" notnull_strength="0" field="Location" unique_strength="0"/>
    <constraint constraints="5" exp_strength="1" notnull_strength="1" field="PermittedUseType" unique_strength="0"/>
    <constraint constraints="1" exp_strength="0" notnull_strength="1" field="Area" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" notnull_strength="0" field="Easement" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" notnull_strength="0" field="Note" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="Guid"/>
    <constraint desc="Поле &quot;Вид границы образуемого (изменяемого) земельного участка&quot; должно принимать одно из значений справочника &quot;Виды границы образуемого (изменяемого) земельного участка&quot;" exp="&quot;Class&quot; IN ('7F.1', '7F.2', '7F.3', '7F.4', '7F.5', '7F.6', '7F.7')" field="Class"/>
    <constraint desc="Поле &quot;Статус объекта&quot; должно принимать одно из значений справочника &quot;Статусы объекта&quot;" exp="&quot;Status&quot; IN ('7B.1', '7B.2')" field="Status"/>
    <constraint desc="" exp="" field="FormingType"/>
    <constraint desc="Минимальная длина строки - 1 символ" exp="length(&quot;NominalNum&quot;) > 0" field="NominalNum"/>
    <constraint desc="" exp="" field="Location"/>
    <constraint desc="Минимальная длина строки - 1 символ" exp="length(&quot;PermittedUseType&quot;) > 0" field="PermittedUseType"/>
    <constraint desc="" exp="" field="Area"/>
    <constraint desc="" exp="" field="Easement"/>
    <constraint desc="" exp="" field="Note"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
    <actionsetting id="{ee95666b-8de4-4f34-81e3-77796120b5ad}" name="Сформировать электронный документ" icon="" shortTitle="Сформировать электронный документ" action="import re, uuid&#xa;&#xa;from PyQt5 import QtCore, QtWidgets&#xa;from PyQt5.QtWidgets import QDialog, QLabel, QTextEdit, QLineEdit, QDoubleSpinBox, QComboBox, QCheckBox, QPushButton, QFileDialog&#xa;from PyQt5.QtCore import QSize&#xa;from PyQt5.QtGui import QFont, QTextCursor, QCursor&#xa;from PyQt5.QtXml import QDomDocument&#xa;from qgis.core import QgsProject&#xa;&#xa;def isLayerValid():&#xa;    if layer.featureCount() == 0:&#xa;        QtWidgets.QMessageBox.critical(None, &quot;Внимание!&quot;, &quot;Слой не содержит объектов. Операция прервана.&quot;)&#xa;        return False&#xa;        &#xa;    return True&#xa;&#xa;def limitNameObj():&#xa;    maxLimit = 1000&#xa;    textContent = nameObj.toPlainText()&#xa;&#xa;    if len(textContent) > maxLimit:&#xa;        nameObj.blockSignals(True)&#xa;        nameObj.setPlainText(textContent[:maxLimit])&#xa;            &#xa;        cursor = nameObj.textCursor()&#xa;        &#xa;        cursor.movePosition(QTextCursor.MoveOperation.End)&#xa;        nameObj.setTextCursor(cursor)&#xa;        nameObj.blockSignals(False)&#xa;&#xa;def validateAllInputs():&#xa;    cadNumPattern = re.compile(r&quot;^\d{1,2}:\d{1,2}:(\d{1}|\d{6,7})$&quot;)&#xa;    skCodePattern = re.compile(r&quot;^\d{2}\.\d{1,2}$&quot;)&#xa;&#xa;    if len(nameObj.toPlainText()) == 0:&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;Поле с наименованием проекта межевания не может быть пустым.&quot;)&#xa;        return False&#xa;&#xa;    if not re.match(cadNumPattern, cadNum.text()):&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;Указано некорректное значение кадастрового номера квартала.&quot;)&#xa;        return False&#xa;&#xa;    if not re.match(skCodePattern, skCode.text()):&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;Указан некорректный код системы координат.&quot;)&#xa;        return False&#xa;    &#xa;    return True&#xa;&#xa;def validateFeatures(features):&#xa;    validFeatures = []&#xa;&#xa;    for feature in features:&#xa;        if feature.attribute(&quot;Class&quot;) in (&quot;7F.4&quot;, &quot;7F.5&quot;, &quot;7F.6&quot;, &quot;7F.7&quot;) and not feature.geometry().isEmpty() and len(feature.attribute(&quot;NominalNum&quot;)) > 0:&#xa;            validFeatures.append(feature)&#xa;&#xa;    return validFeatures&#xa;&#xa;def buildSpatialElement(coords, ptIdx):&#xa;    doc = QDomDocument()&#xa;&#xa;    spatialElement = doc.createElement(&quot;EnSpa2:spatial_element&quot;)&#xa;    typeUnit = doc.createElement(&quot;EnSpa2:type_unit&quot;)&#xa;    typeUnit.appendChild(doc.createTextNode(&quot;01&quot;))&#xa;    spatialElement.appendChild(typeUnit)&#xa;&#xa;    ordinates = doc.createElement(&quot;EnSpa2:ordinates&quot;)&#xa;    spatialElement.appendChild(ordinates)&#xa;&#xa;    for n, point in enumerate(coords):&#xa;        ordinate = doc.createElement(&quot;EnSpa2:ordinate&quot;)&#xa;        xCoord = doc.createElement(&quot;EnSpa2:x&quot;)&#xa;        xCoord.appendChild(doc.createTextNode(str(round(point[0], 2))))&#xa;        yCoord = doc.createElement(&quot;EnSpa2:y&quot;)&#xa;        yCoord.appendChild(doc.createTextNode(str(round(point[1], 2))))&#xa;                &#xa;        ordinate.appendChild(xCoord)&#xa;        ordinate.appendChild(yCoord)&#xa;&#xa;        ordNmb = doc.createElement(&quot;EnSpa2:ord_nmb&quot;)&#xa;        numGeopoint = doc.createElement(&quot;EnSpa2:num_geopoint&quot;)&#xa;&#xa;        if n == (len(coords) - 1):&#xa;            ordNmb.appendChild(doc.createTextNode(str(ptIdx + 1)))&#xa;            numGeopoint.appendChild(doc.createTextNode(str(ptIdx + 1)))&#xa;        else:&#xa;            ordNmb.appendChild(doc.createTextNode(str(n + 1 + ptIdx)))&#xa;            numGeopoint.appendChild(doc.createTextNode(str(n + 1 + ptIdx)))&#xa;&#xa;        ordinate.appendChild(ordNmb)&#xa;        ordinate.appendChild(numGeopoint)&#xa;                    &#xa;        geopointOpred = doc.createElement(&quot;EnSpa2:geopoint_opred&quot;)&#xa;        geopointOpred.appendChild(doc.createTextNode(geoOpredsCodes[geoOpred.currentIndex()]))&#xa;        ordinate.appendChild(geopointOpred)&#xa;&#xa;        deltaGeopoint = doc.createElement(&quot;EnSpa2:delta_geopoint&quot;)&#xa;        deltaGeopoint.appendChild(doc.createTextNode(str(delta.value())))&#xa;        ordinate.appendChild(deltaGeopoint)&#xa;        ordinates.appendChild(ordinate)&#xa;        &#xa;    return spatialElement&#xa;&#xa;def buildXMLTree(id):&#xa;    if onlySelected.isChecked():&#xa;        features = validateFeatures(layer.selectedFeatures())&#xa;    else:&#xa;        features = validateFeatures(layer.getFeatures())&#xa;&#xa;    if len(features) == 0:&#xa;        QtWidgets.QMessageBox.critical(window, &quot;Внимание!&quot;, &quot;В составе слоя отсутствуют земельные участки, подлежащие записи в электронный документ.&quot;)&#xa;        window.reject()&#xa;&#xa;    xmlDocument = QDomDocument()&#xa;&#xa;    docRoot = xmlDocument.createElement(&quot;interact_entry_boundaries&quot;)&#xa;    docRoot.setAttribute(&quot;xmlns&quot;, &quot;urn://x-artefacts-rosreestr-ru/interact/interact-entry-boundaries/2.0.1&quot;)&#xa;    docRoot.setAttribute(&quot;xmlns:iBND2&quot;, &quot;urn://x-artefacts-rosreestr-ru/interact/interact-entry-boundaries/2.0.1&quot;)&#xa;    docRoot.setAttribute(&quot;xmlns:Are1&quot;, &quot;urn://x-artefacts-rosreestr-ru/commons/complex-types/area/1.0.1&quot;)&#xa;    docRoot.setAttribute(&quot;xmlns:EnSpa2&quot;, &quot;urn://x-artefacts-rosreestr-ru/commons/complex-types/entity-spatial/2.0.1&quot;)&#xa;    docRoot.setAttribute(&quot;guid&quot;, id)&#xa;    docRoot.setAttribute(&quot;version&quot;, &quot;02&quot;)&#xa;&#xa;    xmlDocument.appendChild(docRoot)&#xa;&#xa;    boundaries = xmlDocument.createElement(&quot;information_registry_boundaries&quot;)&#xa;    docRoot.appendChild(boundaries)&#xa;&#xa;    boundary = xmlDocument.createElement(&quot;information_registry_boundary&quot;)&#xa;    boundaries.appendChild(boundary)&#xa;&#xa;    typeBoundary = xmlDocument.createElement(&quot;iBND2:type_boundary&quot;)&#xa;    typeBoundary.appendChild(xmlDocument.createTextNode(&quot;17&quot;))&#xa;    boundary.appendChild(typeBoundary)&#xa;&#xa;    nameObject = xmlDocument.createElement(&quot;iBND2:name_object&quot;)&#xa;    nameObject.appendChild(xmlDocument.createTextNode(nameObj.toPlainText()))&#xa;    boundary.appendChild(nameObject)&#xa;&#xa;    infoBoundary = xmlDocument.createElement(&quot;iBND2:information_boundary&quot;)&#xa;    boundary.appendChild(infoBoundary)&#xa;&#xa;    surveyingProject = xmlDocument.createElement(&quot;iBND2:surveying_project&quot;)&#xa;    infoBoundary.appendChild(surveyingProject)&#xa;&#xa;    sProject = xmlDocument.createElement(&quot;iBND2:establishment_surveying_project&quot;)&#xa;    surveyingProject.appendChild(sProject)&#xa;&#xa;    cadNumber = xmlDocument.createElement(&quot;iBND2:quarter_cad_number&quot;)&#xa;    cadNumber.appendChild(xmlDocument.createTextNode(cadNum.text()))&#xa;    sProject.appendChild(cadNumber)&#xa;&#xa;    formingParcels = xmlDocument.createElement(&quot;iBND2:forming_parcels&quot;)&#xa;        &#xa;    for feature in features:&#xa;        circuitNum = len(list(feature.geometry().constParts()))&#xa;        &#xa;        formingParcel = xmlDocument.createElement(&quot;iBND2:forming_parcel&quot;)&#xa;        nominalNumber = xmlDocument.createElement(&quot;iBND2:nominal_number&quot;)&#xa;        nominalNumber.appendChild(xmlDocument.createTextNode(feature.attribute(&quot;NominalNum&quot;)))&#xa;        formingParcel.appendChild(nominalNumber)&#xa;        &#xa;        subtype = xmlDocument.createElement(&quot;iBND2:subtype&quot;)&#xa;        &#xa;        if circuitNum > 1:&#xa;            subtype.appendChild(xmlDocument.createTextNode(&quot;05&quot;))&#xa;            isMultiParts = True&#xa;        else:&#xa;            subtype.appendChild(xmlDocument.createTextNode(&quot;01&quot;))&#xa;            isMultiParts = False&#xa;            &#xa;        formingParcel.appendChild(subtype)&#xa;            &#xa;        fArea = xmlDocument.createElement(&quot;iBND2:area&quot;)&#xa;        areaValue = xmlDocument.createElement(&quot;Are1:value&quot;)&#xa;        areaValue.appendChild(xmlDocument.createTextNode(str(round(feature.geometry().area(), 2))))&#xa;        fArea.appendChild(areaValue)&#xa;        formingParcel.appendChild(fArea)&#xa;        &#xa;        if len(feature.attribute(&quot;PermittedUseType&quot;)) > 0:&#xa;            permittedUse = xmlDocument.createElement(&quot;iBND2:permitted_use_grad_reg&quot;)&#xa;            permittedUseText = xmlDocument.createElement(&quot;iBND2:permitted_use_text&quot;)&#xa;            permittedUseText.appendChild(xmlDocument.createTextNode(feature.attribute(&quot;PermittedUseType&quot;)))&#xa;            permittedUse.appendChild(permittedUseText)&#xa;            formingParcel.appendChild(permittedUse)&#xa;            &#xa;        contoursLocation = xmlDocument.createElement(&quot;iBND2:zu_contours_location&quot;)&#xa;        contours = xmlDocument.createElement(&quot;EnSpa2:contours&quot;)&#xa;        &#xa;        contoursLocation.appendChild(contours)&#xa;        formingParcel.appendChild(contoursLocation)&#xa;&#xa;        geom = feature.geometry()&#xa;        &#xa;        if geom.isMultipart():&#xa;            polygons = geom.asMultiPolygon()&#xa;        else:&#xa;            polygons = [geom.asPolygon()]&#xa;&#xa;        startPtIdx = 0&#xa;&#xa;        for i, poly in enumerate(polygons):&#xa;            exterior_coords = [(p.x(), p.y()) for p in poly[0]]&#xa;            holes_coords = [[(p.x(), p.y()) for p in ring] for ring in poly[1:]]&#xa;        &#xa;            contour = xmlDocument.createElement(&quot;EnSpa2:contour&quot;)&#xa;&#xa;            if isMultiParts:&#xa;                numPP = xmlDocument.createElement(&quot;EnSpa2:number_pp&quot;)&#xa;                numPP.appendChild(xmlDocument.createTextNode(str(i + 1)))&#xa;                contour.appendChild(numPP)&#xa;&#xa;            contours.appendChild(contour)&#xa;&#xa;            entitySpatial = xmlDocument.createElement(&quot;EnSpa2:entity_spatial&quot;)&#xa;            sCode = xmlDocument.createElement(&quot;EnSpa2:sk_code&quot;)&#xa;            sCode.appendChild(xmlDocument.createTextNode(skCode.text()))&#xa;            entitySpatial.appendChild(sCode)&#xa;            contour.appendChild(entitySpatial)&#xa;&#xa;            spatialsElements = xmlDocument.createElement(&quot;EnSpa2:spatials_elements&quot;)&#xa;            spatialsElements.appendChild(buildSpatialElement(exterior_coords, startPtIdx))&#xa;&#xa;            startPtIdx += (len(exterior_coords) - 1)&#xa;&#xa;            if len(holes_coords) > 0:&#xa;                for hole in holes_coords:&#xa;                    spatialsElements.appendChild(buildSpatialElement(hole, startPtIdx))&#xa;&#xa;                    startPtIdx += (len(hole) - 1)&#xa;&#xa;            entitySpatial.appendChild(spatialsElements)&#xa;&#xa;        if feature.attribute(&quot;Class&quot;) in (&quot;7F.5&quot;, &quot;7F.6&quot;):&#xa;            commonUse = xmlDocument.createElement(&quot;iBND2:common_use&quot;)&#xa;            formingParcel.appendChild(commonUse)&#xa;&#xa;            if feature.attribute(&quot;Class&quot;) == &quot;7F.5&quot;:&#xa;                propertyCommonUse = xmlDocument.createElement(&quot;iBND2:property_common_use&quot;)&#xa;                propertyCommonUse.appendChild(xmlDocument.createTextNode(&quot;true&quot;))&#xa;                commonUse.appendChild(propertyCommonUse)&#xa;&#xa;            if feature.attribute(&quot;Class&quot;) == &quot;7F.6&quot;:&#xa;                territoryCommonUse = xmlDocument.createElement(&quot;iBND2:territory_common_use&quot;)&#xa;                territoryCommonUse.appendChild(xmlDocument.createTextNode(&quot;true&quot;))&#xa;                commonUse.appendChild(territoryCommonUse)&#xa;        &#xa;        formingParcels.appendChild(formingParcel)&#xa;&#xa;    sProject.appendChild(formingParcels)&#xa;&#xa;    return xmlDocument&#xa;&#xa;def exportToXML():&#xa;    if validateAllInputs():&#xa;        documentId = str(uuid.uuid4())&#xa;        selectedDirectory = QFileDialog.getExistingDirectory(window, &quot;Выбор каталога для сохранения документа&quot;)&#xa;&#xa;        if selectedDirectory:&#xa;            xmlTree = buildXMLTree(documentId)&#xa;&#xa;            with open(selectedDirectory + &quot;/&quot; + &quot;interact_entry_boundaries_&quot; + documentId + &quot;.xml&quot;, &quot;w&quot;) as file:&#xa;                file.write(xmlTree.toString(4))&#xa;&#xa;            QtWidgets.QMessageBox.information(window, &quot;Операция завершена&quot;, f&quot;Электронный документ interact_entry_boundaries_{documentId}.xml сохранен.&quot;)&#xa;&#xa;            window.done(1)&#xa;&#xa;layer = QgsProject.instance().mapLayer('[%@layer_id%]')&#xa;&#xa;if isLayerValid():&#xa;    geoOpredsCodes = [&quot;692001000000&quot;, &quot;692002000000&quot;, &quot;692003000000&quot;, &quot;692004000000&quot;, &quot;692005000000&quot;, &quot;692006000000&quot;]&#xa;    geoOpredsValues = [&quot;Геодезический метод&quot;, &quot;Фотограмметрический метод&quot;, &quot;Картометрический метод&quot;, &quot;Иное описание&quot;, &quot;Метод спутниковых геодезических измерений (определений)&quot;, &quot;Аналитический метод&quot;]&#xa;&#xa;    window = QDialog()&#xa;    window.setFixedSize(QSize(700, 370))&#xa;    window.move(window.frameGeometry().center())&#xa;    window.setModal(True)&#xa;&#xa;    window.setWindowTitle(&quot;Формирование электронного документа&quot;)&#xa;&#xa;    nameObjLabel = QLabel(&quot;Наименование проекта межевания&quot;, window)&#xa;    nameObjLabel.setFont(QFont(&quot;&quot;, 10, QFont.Bold))&#xa;    nameObjLabel.move(10, 10)&#xa;&#xa;    nameObj = QTextEdit(window)&#xa;    nameObj.textChanged.connect(limitNameObj)&#xa;    nameObj.setPlaceholderText(&quot;Максимальная длина 1000 символов&quot;)&#xa;    nameObj.resize(680, 109)&#xa;    nameObj.move(10, 35)&#xa;&#xa;    cadNumLabel = QLabel(&quot;Кадастровый номер квартала&quot;, window)&#xa;    cadNumLabel.setFont(QFont(&quot;&quot;, 10, QFont.Bold))&#xa;    cadNumLabel.move(10, 162)&#xa;&#xa;    cadNum = QLineEdit(window)&#xa;    cadNum.setInputMask(&quot;99:99:9999999&quot;)&#xa;    cadNum.setMaxLength(13)&#xa;    cadNum.resize(150, 25)&#xa;    cadNum.move(250, 158)&#xa;&#xa;    skCodeLabel = QLabel(&quot;Код системы координат&quot;, window)&#xa;    skCodeLabel.setFont(QFont(&quot;&quot;, 10, QFont.Bold))&#xa;    skCodeLabel.move(420, 162)&#xa;&#xa;    skCode = QLineEdit(window)&#xa;    skCode.setInputMask(&quot;99.99&quot;)&#xa;    skCode.setMaxLength(5)&#xa;    skCode.resize(70, 25)&#xa;    skCode.move(620, 158)&#xa;&#xa;    geoOpred = QComboBox(window)&#xa;    geoOpred.addItems(geoOpredsValues)&#xa;    geoOpred.setEditable(False)&#xa;    geoOpred.setCurrentIndex(5)&#xa;    geoOpred.resize(680, 25)&#xa;    geoOpred.move(10, 200)&#xa;&#xa;    deltaLabel = QLabel(&quot;Погрешность определения координат&quot;, window)&#xa;    deltaLabel.setFont(QFont(&quot;&quot;, 10, QFont.Bold))&#xa;    deltaLabel.move(10, 246)&#xa;&#xa;    delta = QDoubleSpinBox(window)&#xa;    delta.setRange(0.10, 5.00)&#xa;    delta.setSingleStep(0.10)&#xa;    delta.resize(80, 25)&#xa;    delta.move(315, 240)&#xa;&#xa;    onlySelected = QCheckBox(&quot;Сохранить только выделенные объекты&quot;, window)&#xa;    onlySelected.move(10, 280)&#xa;&#xa;    button = QPushButton(&quot;Сформировать&quot;, window)&#xa;    button.setCursor(QCursor(QtCore.Qt.PointingHandCursor))&#xa;    button.clicked.connect(exportToXML)&#xa;    button.resize(110, 25)&#xa;    button.move(580, 335)&#xa;&#xa;    if layer.selectedFeatureCount() > 0:&#xa;        onlySelected.setEnabled(True)&#xa;    else:&#xa;        onlySelected.setEnabled(False)&#xa;&#xa;    window.show()&#xa;" capture="0" notificationMessage="" type="1" isEnabledOnlyWhenEditable="0">
      <actionScope id="Layer"/>
    </actionsetting>
  </attributeactions>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle overrideLabelFont="0" labelColor="0,0,0,255" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer visibilityExpressionEnabled="0" name="Обязательные атрибуты" collapsed="0" groupBox="0" showLabel="1" collapsedExpression="" visibilityExpression="" collapsedExpressionEnabled="0" columnCount="1">
      <labelStyle overrideLabelFont="0" labelColor="0,0,0,255" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField name="Guid" showLabel="1" index="0">
        <labelStyle overrideLabelFont="1" labelColor="0,0,0,255" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Class" showLabel="1" index="1">
        <labelStyle overrideLabelFont="1" labelColor="0,0,0,255" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Status" showLabel="1" index="2">
        <labelStyle overrideLabelFont="1" labelColor="0,0,0,255" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="NominalNum" showLabel="1" index="4">
        <labelStyle overrideLabelFont="1" labelColor="0,0,0,255" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="PermittedUseType" showLabel="1" index="6">
        <labelStyle overrideLabelFont="1" labelColor="0,0,0,255" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Area" showLabel="1" index="7">
        <labelStyle overrideLabelFont="1" labelColor="0,0,0,255" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer visibilityExpressionEnabled="0" name="Необязательные атрибуты" collapsed="0" groupBox="0" showLabel="1" collapsedExpression="" visibilityExpression="" collapsedExpressionEnabled="0" columnCount="1">
      <labelStyle overrideLabelFont="0" labelColor="0,0,0,255" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField name="FormingType" showLabel="1" index="3">
        <labelStyle overrideLabelFont="1" labelColor="0,0,0,255" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Location" showLabel="1" index="5">
        <labelStyle overrideLabelFont="1" labelColor="0,0,0,255" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Note" showLabel="1" index="9">
        <labelStyle overrideLabelFont="1" labelColor="0,0,0,255" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer visibilityExpressionEnabled="0" name="Условно-обязательные атрибуты" collapsed="0" groupBox="0" showLabel="1" collapsedExpression="" visibilityExpression="" collapsedExpressionEnabled="0" columnCount="1">
      <labelStyle overrideLabelFont="0" labelColor="0,0,0,255" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField name="Easement" showLabel="1" index="8">
        <labelStyle overrideLabelFont="1" labelColor="0,0,0,255" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field editable="0" name="Area"/>
    <field editable="1" name="Class"/>
    <field editable="1" name="Easement"/>
    <field editable="1" name="FormingType"/>
    <field editable="0" name="Guid"/>
    <field editable="1" name="Location"/>
    <field editable="1" name="NominalNum"/>
    <field editable="1" name="Note"/>
    <field editable="1" name="PermittedUseType"/>
    <field editable="1" name="Status"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="Area"/>
    <field labelOnTop="1" name="Class"/>
    <field labelOnTop="1" name="Easement"/>
    <field labelOnTop="1" name="FormingType"/>
    <field labelOnTop="1" name="Guid"/>
    <field labelOnTop="1" name="Location"/>
    <field labelOnTop="1" name="NominalNum"/>
    <field labelOnTop="1" name="Note"/>
    <field labelOnTop="1" name="PermittedUseType"/>
    <field labelOnTop="1" name="Status"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="Area" reuseLastValue="0"/>
    <field name="Class" reuseLastValue="0"/>
    <field name="Easement" reuseLastValue="0"/>
    <field name="FormingType" reuseLastValue="0"/>
    <field name="Guid" reuseLastValue="0"/>
    <field name="Location" reuseLastValue="0"/>
    <field name="NominalNum" reuseLastValue="0"/>
    <field name="Note" reuseLastValue="0"/>
    <field name="PermittedUseType" reuseLastValue="0"/>
    <field name="Status" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <layerGeometryType>2</layerGeometryType>
</qgis>
