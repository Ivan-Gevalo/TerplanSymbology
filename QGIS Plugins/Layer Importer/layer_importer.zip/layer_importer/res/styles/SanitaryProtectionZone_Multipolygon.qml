<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer" symbollevels="0">
    <rules key="{56b57480-1053-4bf9-b1be-86cbf9a27224}">
      <rule label="Существующие" filter="&quot;STATUS&quot; = 1" symbol="0" key="{b954e57b-0bd0-44d7-8f9d-4eb9166ebbc1}">
        <rule label="Санитарно-защитная зона предприятий, сооружений и иных объектов" filter="&quot;CLASSID&quot; = '603010101'" symbol="1" key="{cf3afc64-d252-4bcb-b53d-948f945c82cd}"/>
        <rule label="Санитарно-защитная зона радиационных объектов" filter="&quot;CLASSID&quot; = '603010102'" symbol="2" key="{ad6aed3a-8200-402f-89f2-233f457c59d3}"/>
      </rule>
      <rule label="Планируемые" filter="&quot;STATUS&quot; = 2" symbol="3" key="{75cd236f-1151-4831-b571-618b3e8acb43}">
        <rule label="Санитарно-защитная зона предприятий, сооружений и иных объектов" filter="&quot;CLASSID&quot; = '603010101'" symbol="4" key="{6d710148-d72c-4ecf-9386-fb8575dbf6b2}"/>
        <rule label="Санитарно-защитная зона радиационных объектов" filter="&quot;CLASSID&quot; = '603010102'" symbol="5" key="{625c0551-5182-46cb-a603-4dd4185f012c}"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="133,182,111,0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0.26" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="232,113,141,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.3" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="MarkerLine">
          <Option type="Map">
            <Option name="average_angle_length" value="0" type="QString"/>
            <Option name="average_angle_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="average_angle_unit" value="MM" type="QString"/>
            <Option name="interval" value="10" type="QString"/>
            <Option name="interval_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="interval_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_along_line" value="0" type="QString"/>
            <Option name="offset_along_line_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_along_line_unit" value="MM" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="place_on_every_part" value="true" type="bool"/>
            <Option name="placements" value="Interval" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="rotate" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@1@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="line" type="QString"/>
                <Option name="offset" value="0,0.40000000000000002" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="0,0,0,255" type="QString"/>
                <Option name="outline_style" value="solid" type="QString"/>
                <Option name="outline_width" value="0.15" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="0.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="232,113,141,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.3" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="MarkerLine">
          <Option type="Map">
            <Option name="average_angle_length" value="0" type="QString"/>
            <Option name="average_angle_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="average_angle_unit" value="MM" type="QString"/>
            <Option name="interval" value="10" type="QString"/>
            <Option name="interval_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="interval_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_along_line" value="0" type="QString"/>
            <Option name="offset_along_line_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_along_line_unit" value="MM" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="place_on_every_part" value="true" type="bool"/>
            <Option name="placements" value="Interval" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="rotate" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@2@1" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="line" type="QString"/>
                <Option name="offset" value="0,0.40000000000000002" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="0,0,0,255" type="QString"/>
                <Option name="outline_style" value="solid" type="QString"/>
                <Option name="outline_width" value="0.15" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="0.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="164,113,88,0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0.26" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="232,113,141,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0.3" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SimpleLine">
          <Option type="Map">
            <Option name="align_dash_pattern" value="0" type="QString"/>
            <Option name="capstyle" value="square" type="QString"/>
            <Option name="customdash" value="5;2" type="QString"/>
            <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="customdash_unit" value="MM" type="QString"/>
            <Option name="dash_pattern_offset" value="0" type="QString"/>
            <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
            <Option name="draw_inside_polygon" value="0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="line_color" value="0,0,0,255" type="QString"/>
            <Option name="line_style" value="solid" type="QString"/>
            <Option name="line_width" value="0.3" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="trim_distance_end" value="0" type="QString"/>
            <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_end_unit" value="MM" type="QString"/>
            <Option name="trim_distance_start" value="0" type="QString"/>
            <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_start_unit" value="MM" type="QString"/>
            <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
            <Option name="use_custom_dash" value="1" type="QString"/>
            <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="MarkerLine">
          <Option type="Map">
            <Option name="average_angle_length" value="0" type="QString"/>
            <Option name="average_angle_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="average_angle_unit" value="MM" type="QString"/>
            <Option name="interval" value="7" type="QString"/>
            <Option name="interval_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="interval_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_along_line" value="2.5" type="QString"/>
            <Option name="offset_along_line_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_along_line_unit" value="MM" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="place_on_every_part" value="true" type="bool"/>
            <Option name="placements" value="Interval" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="rotate" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@4@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="line" type="QString"/>
                <Option name="offset" value="0,0.40000000000000002" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="0,0,0,255" type="QString"/>
                <Option name="outline_style" value="solid" type="QString"/>
                <Option name="outline_width" value="0.15" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="0.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" clip_to_extent="1" type="fill" alpha="1" is_animated="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="232,113,141,0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="no" type="QString"/>
            <Option name="outline_width" value="0.3" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SimpleLine">
          <Option type="Map">
            <Option name="align_dash_pattern" value="0" type="QString"/>
            <Option name="capstyle" value="square" type="QString"/>
            <Option name="customdash" value="5;2" type="QString"/>
            <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="customdash_unit" value="MM" type="QString"/>
            <Option name="dash_pattern_offset" value="0" type="QString"/>
            <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
            <Option name="draw_inside_polygon" value="0" type="QString"/>
            <Option name="joinstyle" value="miter" type="QString"/>
            <Option name="line_color" value="0,0,0,255" type="QString"/>
            <Option name="line_style" value="solid" type="QString"/>
            <Option name="line_width" value="0.3" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="trim_distance_end" value="0" type="QString"/>
            <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_end_unit" value="MM" type="QString"/>
            <Option name="trim_distance_start" value="0" type="QString"/>
            <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_start_unit" value="MM" type="QString"/>
            <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
            <Option name="use_custom_dash" value="1" type="QString"/>
            <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="MarkerLine">
          <Option type="Map">
            <Option name="average_angle_length" value="0" type="QString"/>
            <Option name="average_angle_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="average_angle_unit" value="MM" type="QString"/>
            <Option name="interval" value="7" type="QString"/>
            <Option name="interval_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="interval_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_along_line" value="2.5" type="QString"/>
            <Option name="offset_along_line_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_along_line_unit" value="MM" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="place_on_every_part" value="true" type="bool"/>
            <Option name="placements" value="Interval" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="rotate" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@5@2" clip_to_extent="1" type="marker" alpha="1" is_animated="0" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" value="0" type="QString"/>
                <Option name="cap_style" value="square" type="QString"/>
                <Option name="color" value="255,0,0,255" type="QString"/>
                <Option name="horizontal_anchor_point" value="1" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="name" value="line" type="QString"/>
                <Option name="offset" value="0,0.40000000000000002" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="0,0,0,255" type="QString"/>
                <Option name="outline_style" value="solid" type="QString"/>
                <Option name="outline_width" value="0.15" type="QString"/>
                <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="scale_method" value="diameter" type="QString"/>
                <Option name="size" value="0.5" type="QString"/>
                <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="size_unit" value="MM" type="QString"/>
                <Option name="vertical_anchor_point" value="1" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="GLOBALID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CLASSID" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Санитарно-защитная зона предприятий, сооружений и иных объектов" value="603010101" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Санитарно-защитная зона радиационных объектов" value="603010102" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SZZ_TYPE" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Ориентировочная (нормативная) зона" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Расчетная (предварительная) зона" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Установленная (окончательная) зона" value="3" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="HZRD_CLASS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="I класс опасности объекта" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="II класс опасности объекта" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="III класс опасности объекта" value="3" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="IV класс опасности объекта" value="4" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="V класс опасности объекта" value="5" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SPZ_EVENT" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Сохраняемая" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Ликвидируемая (при выносе объекта)" value="2" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Требующая изменения границы" value="3" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="ZONE_DESC" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="true" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OBJECTNAME" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="SOURCE" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option name="Editable" value="true" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NOTE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="STATUS" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option name="map" type="List">
              <Option type="Map">
                <Option name="Существующий" value="1" type="QString"/>
              </Option>
              <Option type="Map">
                <Option name="Планируемый" value="2" type="QString"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="NUMBERZOIT" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="REESTRZOIT" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="DATEEGRN" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="OPONZ" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="true" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GLOBALID" index="0" name="Идентификатор объекта"/>
    <alias field="CLASSID" index="1" name=""/>
    <alias field="SZZ_TYPE" index="2" name="Тип санитарно-защитной зоны"/>
    <alias field="HZRD_CLASS" index="3" name="Класс опасности объекта в соответствии с санитарной классификацией"/>
    <alias field="SPZ_EVENT" index="4" name="Планируемое событие/мероприятие по санитарно-защитной зоне"/>
    <alias field="ZONE_DESC" index="5" name="Описание расчетной или установленной зоны"/>
    <alias field="OBJECTNAME" index="6" name="Наименование объекта (для которого устанавливается зона)"/>
    <alias field="SOURCE" index="7" name="Источник данных (реквизиты правового акта, устанавливающего характеристики зоны с особыми условиями использования территории)"/>
    <alias field="NOTE" index="8" name="Примечание"/>
    <alias field="STATUS" index="9" name="Статус"/>
    <alias field="NUMBERZOIT" index="10" name="Учетный номер зоны, внесенный в единый государственный реестр недвижимости"/>
    <alias field="REESTRZOIT" index="11" name="Реестровый номер зоны, внесенный в единый государственный реестр недвижимости"/>
    <alias field="DATEEGRN" index="12" name="Дата внесения зон с особыми условиями использования территории в единый государственный реестр недвижимости"/>
    <alias field="OPONZ" index="13" name="Описание ориентировочной (нормативной) зоны"/>
  </aliases>
  <defaults>
    <default field="GLOBALID" expression="uuid('WithoutBraces')" applyOnUpdate="1"/>
    <default field="CLASSID" expression="'603010101'" applyOnUpdate="0"/>
    <default field="SZZ_TYPE" expression="1" applyOnUpdate="0"/>
    <default field="HZRD_CLASS" expression="1" applyOnUpdate="0"/>
    <default field="SPZ_EVENT" expression="1" applyOnUpdate="0"/>
    <default field="ZONE_DESC" expression="''" applyOnUpdate="0"/>
    <default field="OBJECTNAME" expression="''" applyOnUpdate="0"/>
    <default field="SOURCE" expression="''" applyOnUpdate="0"/>
    <default field="NOTE" expression="''" applyOnUpdate="0"/>
    <default field="STATUS" expression="1" applyOnUpdate="0"/>
    <default field="NUMBERZOIT" expression="''" applyOnUpdate="0"/>
    <default field="REESTRZOIT" expression="''" applyOnUpdate="0"/>
    <default field="DATEEGRN" expression="''" applyOnUpdate="0"/>
    <default field="OPONZ" expression="''" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="GLOBALID" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="CLASSID" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="SZZ_TYPE" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="HZRD_CLASS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="SPZ_EVENT" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="ZONE_DESC" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="1" field="OBJECTNAME" unique_strength="0" notnull_strength="1" constraints="5"/>
    <constraint exp_strength="0" field="SOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="NOTE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="STATUS" unique_strength="0" notnull_strength="1" constraints="1"/>
    <constraint exp_strength="0" field="NUMBERZOIT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="2" field="REESTRZOIT" unique_strength="0" notnull_strength="0" constraints="4"/>
    <constraint exp_strength="0" field="DATEEGRN" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="OPONZ" unique_strength="0" notnull_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GLOBALID" desc="" exp=""/>
    <constraint field="CLASSID" desc="" exp=""/>
    <constraint field="SZZ_TYPE" desc="" exp=""/>
    <constraint field="HZRD_CLASS" desc="" exp=""/>
    <constraint field="SPZ_EVENT" desc="" exp=""/>
    <constraint field="ZONE_DESC" desc="" exp=""/>
    <constraint field="OBJECTNAME" desc="Минимальная длина строки - 1 символ" exp="length(&quot;OBJECTNAME&quot;) > 0"/>
    <constraint field="SOURCE" desc="" exp=""/>
    <constraint field="NOTE" desc="" exp=""/>
    <constraint field="STATUS" desc="" exp=""/>
    <constraint field="NUMBERZOIT" desc="" exp=""/>
    <constraint field="REESTRZOIT" desc="Реестровый номер зоны должен соответствовать формату, принятому в ЕГРН (приказ Росреестра от 22.05.2023 № П/0183)" exp="regexp_match(&quot;REESTRZOIT&quot;, '^\\d{1,2}:\\d{1,2}-6.\\d{1,}$')"/>
    <constraint field="DATEEGRN" desc="" exp=""/>
    <constraint field="OPONZ" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Обязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="GLOBALID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="CLASSID">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="2" name="SZZ_TYPE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="HZRD_CLASS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="4" name="SPZ_EVENT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="6" name="OBJECTNAME">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="9" name="STATUS">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" columnCount="1" visibilityExpressionEnabled="0" collapsed="0" name="Необязательные атрибуты" collapsedExpressionEnabled="0" collapsedExpression="" groupBox="0" visibilityExpression="">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" underline="0" italic="0" style="" bold="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="ZONE_DESC">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="7" name="SOURCE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="8" name="NOTE">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="10" name="NUMBERZOIT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="11" name="REESTRZOIT">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="12" name="DATEEGRN">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="13" name="OPONZ">
        <labelStyle labelColor="0,0,0,255" overrideLabelFont="1" overrideLabelColor="0">
          <labelFont description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" underline="0" italic="0" style="" bold="1" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="CLASSID" editable="1"/>
    <field name="DATEEGRN" editable="1"/>
    <field name="GLOBALID" editable="0"/>
    <field name="HZRD_CLASS" editable="1"/>
    <field name="NOTE" editable="1"/>
    <field name="NUMBERZOIT" editable="1"/>
    <field name="OBJECTNAME" editable="1"/>
    <field name="OPONZ" editable="1"/>
    <field name="REESTRZOIT" editable="1"/>
    <field name="SOURCE" editable="1"/>
    <field name="SPZ_EVENT" editable="1"/>
    <field name="STATUS" editable="1"/>
    <field name="SZZ_TYPE" editable="1"/>
    <field name="ZONE_DESC" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="1" name="CLASSID"/>
    <field labelOnTop="1" name="DATEEGRN"/>
    <field labelOnTop="1" name="GLOBALID"/>
    <field labelOnTop="1" name="HZRD_CLASS"/>
    <field labelOnTop="1" name="NOTE"/>
    <field labelOnTop="1" name="NUMBERZOIT"/>
    <field labelOnTop="1" name="OBJECTNAME"/>
    <field labelOnTop="1" name="OPONZ"/>
    <field labelOnTop="1" name="REESTRZOIT"/>
    <field labelOnTop="1" name="SOURCE"/>
    <field labelOnTop="1" name="SPZ_EVENT"/>
    <field labelOnTop="1" name="STATUS"/>
    <field labelOnTop="1" name="SZZ_TYPE"/>
    <field labelOnTop="1" name="ZONE_DESC"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="CLASSID" reuseLastValue="0"/>
    <field name="DATEEGRN" reuseLastValue="0"/>
    <field name="GLOBALID" reuseLastValue="0"/>
    <field name="HZRD_CLASS" reuseLastValue="0"/>
    <field name="NOTE" reuseLastValue="0"/>
    <field name="NUMBERZOIT" reuseLastValue="0"/>
    <field name="OBJECTNAME" reuseLastValue="0"/>
    <field name="OPONZ" reuseLastValue="0"/>
    <field name="REESTRZOIT" reuseLastValue="0"/>
    <field name="SOURCE" reuseLastValue="0"/>
    <field name="SPZ_EVENT" reuseLastValue="0"/>
    <field name="STATUS" reuseLastValue="0"/>
    <field name="SZZ_TYPE" reuseLastValue="0"/>
    <field name="ZONE_DESC" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties>
    <field name="CLASSID">
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties" type="Map">
          <Option name="dataDefinedAlias" type="Map">
            <Option name="active" value="true" type="bool"/>
            <Option name="expression" value="'Код объекта: ' || attribute(@feature, 'CLASSID')" type="QString"/>
            <Option name="type" value="3" type="int"/>
          </Option>
        </Option>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </field>
  </dataDefinedFieldProperties>
  <widgets/>
  <layerGeometryType>2</layerGeometryType>
</qgis>
