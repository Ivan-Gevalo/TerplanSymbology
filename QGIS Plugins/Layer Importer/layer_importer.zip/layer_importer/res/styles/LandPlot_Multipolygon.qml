<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.15-Firenze" styleCategories="Symbology|Fields|Forms">
  <renderer-v2 symbollevels="0" forceraster="0" type="singleSymbol" enableorderby="0" referencescale="-1">
    <symbols>
      <symbol force_rhr="0" alpha="1" type="fill" name="0" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" pass="0" locked="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="255,230,204,255"/>
            <Option type="QString" name="joinstyle" value="miter"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="255,179,103,255"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.4"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <fieldConfiguration>
    <field name="Guid" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Status" configurationFlags="None">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" name="Учтен в Едином государственном реестре недвижимости" value="13D.1"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Снят с учета в Едином государственном реестре недвижимости" value="13D.2"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Нет данных об учете в Едином государственном реестре недвижимости" value="13D.3"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="CadastralNum" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Area" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Location" configurationFlags="None">
      <editWidget type="UniqueValues">
        <config>
          <Option type="Map">
            <Option type="bool" name="Editable" value="true"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Easement" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Note" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="Guid" name="Идентификатор объекта"/>
    <alias index="1" field="Status" name="Статус объекта недвижимости"/>
    <alias index="2" field="CadastralNum" name="Сведения о кадастровом (ином) номере земельного участка"/>
    <alias index="3" field="Area" name="Сведения о площади, кв. м"/>
    <alias index="4" field="Location" name="Сведения о местоположении"/>
    <alias index="5" field="Easement" name="Информация о сервитуте, публичном сервитуте"/>
    <alias index="6" field="Note" name="Примечание"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="1" field="Guid" expression="uuid('WithoutBraces')"/>
    <default applyOnUpdate="0" field="Status" expression="'13D.1'"/>
    <default applyOnUpdate="0" field="CadastralNum" expression="''"/>
    <default applyOnUpdate="1" field="Area" expression="round(area($geometry), 2)"/>
    <default applyOnUpdate="0" field="Location" expression="''"/>
    <default applyOnUpdate="0" field="Easement" expression="''"/>
    <default applyOnUpdate="0" field="Note" expression="''"/>
  </defaults>
  <constraints>
    <constraint field="Guid" notnull_strength="1" unique_strength="1" exp_strength="0" constraints="3"/>
    <constraint field="Status" notnull_strength="1" unique_strength="0" exp_strength="1" constraints="5"/>
    <constraint field="CadastralNum" notnull_strength="1" unique_strength="0" exp_strength="1" constraints="5"/>
    <constraint field="Area" notnull_strength="1" unique_strength="0" exp_strength="0" constraints="1"/>
    <constraint field="Location" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="Easement" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="Note" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="Guid"/>
    <constraint exp="&quot;Status&quot; IN ('13D.1', '13D.2', '13D.3')" desc="Поле &quot;Статус объекта недвижимости&quot; должно принимать одно из значений справочника &quot;Статусы объекта недвижимости&quot;" field="Status"/>
    <constraint exp="length(&quot;CadastralNum&quot;) > 0" desc="Минимальная длина строки - 1 символ" field="CadastralNum"/>
    <constraint exp="" desc="" field="Area"/>
    <constraint exp="" desc="" field="Location"/>
    <constraint exp="" desc="" field="Easement"/>
    <constraint exp="" desc="" field="Note"/>
  </constraintExpressions>
  <expressionfields/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- кодировка: utf-8 -*-
"""
Формы QGIS могут иметь функцию Python, которая вызывается при открытии формы.

Используйте эту функцию для добавления дополнительной логики в ваши формы.

Введите имя функции в поле «Функция init Python».
Например:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="0">
      <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" style="" italic="0" underline="0" bold="0"/>
    </labelStyle>
    <attributeEditorContainer collapsedExpressionEnabled="0" groupBox="0" showLabel="1" collapsedExpression="" visibilityExpressionEnabled="0" name="Обязательные атрибуты" collapsed="0" columnCount="1" visibilityExpression="">
      <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="0">
        <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" style="" italic="0" underline="0" bold="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="0" name="Guid">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="1" name="Status">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="2" name="CadastralNum">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="3" name="Area">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer collapsedExpressionEnabled="0" groupBox="0" showLabel="1" collapsedExpression="" visibilityExpressionEnabled="0" name="Необязательные атрибуты" collapsed="0" columnCount="1" visibilityExpression="">
      <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="0">
        <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" style="" italic="0" underline="0" bold="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="4" name="Location">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField showLabel="1" index="6" name="Note">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer collapsedExpressionEnabled="0" groupBox="0" showLabel="1" collapsedExpression="" visibilityExpressionEnabled="0" name="Условно-обязательные атрибуты" collapsed="0" columnCount="1" visibilityExpression="">
      <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="0">
        <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,50,0,0,0,0,0" style="" italic="0" underline="0" bold="0"/>
      </labelStyle>
      <attributeEditorField showLabel="1" index="5" name="Easement">
        <labelStyle overrideLabelColor="0" labelColor="0,0,0,255" overrideLabelFont="1">
          <labelFont strikethrough="0" description="DejaVu Sans,10,-1,5,75,0,0,0,0,0" style="" italic="0" underline="0" bold="1"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="Area" editable="0"/>
    <field name="CadastralNum" editable="1"/>
    <field name="Easement" editable="1"/>
    <field name="Guid" editable="0"/>
    <field name="Location" editable="1"/>
    <field name="Note" editable="1"/>
    <field name="Status" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="Area" labelOnTop="1"/>
    <field name="CadastralNum" labelOnTop="1"/>
    <field name="Easement" labelOnTop="1"/>
    <field name="Guid" labelOnTop="1"/>
    <field name="Location" labelOnTop="1"/>
    <field name="Note" labelOnTop="1"/>
    <field name="Status" labelOnTop="1"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="Area" reuseLastValue="0"/>
    <field name="CadastralNum" reuseLastValue="0"/>
    <field name="Easement" reuseLastValue="0"/>
    <field name="Guid" reuseLastValue="0"/>
    <field name="Location" reuseLastValue="0"/>
    <field name="Note" reuseLastValue="0"/>
    <field name="Status" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <layerGeometryType>2</layerGeometryType>
</qgis>
