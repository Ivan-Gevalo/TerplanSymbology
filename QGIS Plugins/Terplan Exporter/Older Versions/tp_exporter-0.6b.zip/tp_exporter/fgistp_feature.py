from qgis.core import QgsFeature
from qgis.PyQt.QtXml import QDomDocument
from osgeo import ogr

from .fgistp_attribute import FGISTPAttribute

import uuid, re

class FGISTPFeature (QgsFeature):
    GEOMETRY_TYPES = {
        0: "point",
        1: "linestring",
        2: "polygon"
    }

    ATTRIBUTE_MARKS = {
        "VALID": "valid",
        "NOT_EXIST": "у объекта отсутствует атрибут, являющийся обязательным",
        "EMPTY_STRING": "обнаружена пустая строка, символьный атрибут должен быть заполнен",
        "INTEGER_REQUIRED": "некорректное значение атрибута - %v (ожидается целое число)",
        "POSITIVE_INTEGER_REQUIRED": "некорректное значение атрибута - %v (ожидается строго положительное целое число)",
        "NON_NEGATIVE_REQUIRED": "некорректное значение атрибута - %v (ожидается неотрицательное целое число)",
        "FLOAT_REQUIRED": "некорректное значение атрибута - %v (ожидается вещественное число)",
        "PATTERN_MISMATCH": "значение атрибута не соответствует заданным ограничениям",
        "NOT_IN_ENUMERATION": "значение атрибута (%v) не предусмотрено справочником",
        "POSITIVE_REQUIRED": "некорректное значение атрибута - %v (ожидается положительное число)",
        "CONDITIONS_NOT_MET": "не выполнено условие заполнения атрибута",
        "IGNORE_IT": "ignore it"
    }

    INTEGER_SUBTYPES = ("integer", "positiveInteger", "nonNegativeInteger")

    def __init__(self, feature, crsId):
        super().__init__(feature)

        self.GLOBALID = None
        self.className = None
        self.crs = crsId
        self.attributeSchema = []
        self.attributesCorrespond = True

    def initGlobalId(self, uniqueIdList):
        idPattern = "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}|\{[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\}"

        try:
            if re.search(idPattern, self.attribute("GLOBALID")) is None or self.attribute("GLOBALID") in uniqueIdList:
                self.GLOBALID = self.generateFeatureId()
            else:
                self.GLOBALID = self.attribute("GLOBALID")
        except KeyError:
            self.GLOBALID = self.generateFeatureId()

        return self.GLOBALID

    def generateFeatureId(self):
        return uuid.uuid4()

    def validateFeature(self, schema):
        if schema.isSpatial() and not self.hasGeometry():
            return ("у объекта отсутствует геометрия", None)

        # определение принадлежности объекта к классу, предусмотренному схемой
        for key, value in schema.getClasses().items():
            if str(self.attribute("CLASSID")) in value["objects"]:
                self.className = key
        
                break

        # проверка соответствия типа геометрии объекта требованиям схемы
        if self.className is not None:
            if schema.isSpatial():
                if self.geometry().wkbType() not in schema.getClasses()[self.className]["geometry"]:
                    return (f"тип геометрии объекта не предусмотрен выбранной XML-схемой для объекта с кодом {self.attribute('CLASSID')}", None)
        else:
            return ("значение атрибута CLASSID не предусмотрено выбранной XML-схемой, из-за чего невозможно идентифицировать объект", None)

        return ("", self)

    def validateAttributes(self, schema):
        schemaType = schema.getSchema().find(f".//xs:complexType[@name='{self.className}_Type']", schema.getNamespaces())
        
        for element in schemaType.findall(".//xs:element", schema.getNamespaces()):
            if element.attrib.get("name") is not None and element.attrib.get("name") not in ("GLOBALID", "CLASSID"):
                try:
                    conditions = element.findall(".//xs:appinfo", schema.getNamespaces())
                    requiredFlag = True

                    if element.get("minOccurs") == "0":
                        if self.areConditionsMet(conditions) == False:
                            requiredFlag = False
        
                    validationResult = self.validateAttribute(schema, element, self.attribute(element.attrib["name"]), requiredFlag)
                    
                    self.attributeSchema.append(validationResult)
                        
                    if validationResult.getStatus() not in ("VALID", "IGNORE_IT"):
                        self.attributesCorrespond = False
                except KeyError:
                    if requiredFlag:
                        self.attributeSchema.append(FGISTPAttribute(element.attrib["name"], "NOT_EXIST"))
                        self.attributesCorrespond = False

    def getXMLFeature(self, document, schema):
        featureMember = document.createElement("gml:featureMember")

        featureElement = document.createElement(f"fgistp:{self.className}")
        featureElement.setAttribute("gml:id", f"ID_{uuid.uuid4().__str__()}")
        featureMember.appendChild(featureElement)
        featureElement.appendChild(self.createTreeElement(document, "fgistp:GLOBALID", self.GLOBALID))
        featureElement.appendChild(self.createTreeElement(document, "fgistp:CLASSID", self.attribute("CLASSID")))

        for attr in self.attributeSchema:
            if attr.getStatus() == "VALID":
                if attr.getType() == "string":
                    attributeValue = str(self.attribute(attr.getName()))
                if attr.getType() == "int":
                    attributeValue = int(self.attribute(attr.getName()))
                if attr.getType() == "float":
                    attributeValue = float(self.attribute(attr.getName()))

                featureElement.appendChild(self.createTreeElement(document, f"fgistp:{attr.getName()}", attributeValue))

        # запись геометрии в случае, если создается пространственный объект
        if schema.isSpatial():
            geomDocument = QDomDocument()
            featureGeometry = self.geometry()

            if not featureGeometry.isMultipart():
                featureGeometry.convertToMultiType()
            
            ogrGeom = ogr.CreateGeometryFromWkt(featureGeometry.asWkt())
            geomDocument.setContent(ogrGeom.ExportToGML(["FORMAT=GML32", f"GMLID=geom_{uuid.uuid4().__str__()}"]))
            geom = geomDocument.firstChild().toElement()
            geom.setAttribute("srsName", self.crs)
            
            featureElement.appendChild(geom)

        return featureMember

    def validateAttribute(self, schema, schemaElement, attributeValue, requiredFlag):
        if schemaElement.attrib["type"] == "xs:string":
            return self.validateString(schemaElement, attributeValue, requiredFlag)
        elif schemaElement.attrib["type"] == "xs:integer":
            return self.validateInteger(schemaElement, attributeValue, self.INTEGER_SUBTYPES[0], requiredFlag)
        elif schemaElement.attrib["type"] == "xs:positiveInteger":
            return self.validateInteger(schemaElement, attributeValue, self.INTEGER_SUBTYPES[1], requiredFlag)
        elif schemaElement.attrib["type"] == "xs:nonNegativeInteger":
            return self.validateInteger(schemaElement, attributeValue, self.INTEGER_SUBTYPES[2], requiredFlag)
        elif schemaElement.attrib["type"] == "xs:double":
            return self.validateFloat(schemaElement, attributeValue, requiredFlag)
        
        fgistpType = schema.getSchema().find(".//xs:simpleType[@name='" + schemaElement.attrib["type"][7:] + "']", schema.getNamespaces())
        fgistpSubType = fgistpType.find(".//xs:restriction", schema.getNamespaces()).attrib["base"]
    
        if fgistpSubType == "xs:string":
            return self.validateByPattern(schemaElement, fgistpType.find(".//xs:pattern", schema.getNamespaces()).attrib["value"], attributeValue)
        elif fgistpSubType in ("xs:integer", "xs:positiveInteger", "xs:nonNegativeInteger"):
            return self.validateByEnumeration(schemaElement, fgistpType.findall(".//xs:enumeration", schema.getNamespaces()), attributeValue, requiredFlag)

    def validateString(self, schemaElement, value, isRequired):
        stringValue = str(value)
        status = "VALID"

        if stringValue in ("None", "NULL") or len(stringValue) == 0:
            if isRequired:
                status = "EMPTY_STRING"
            else:
                status = "IGNORE_IT"
            
        return FGISTPAttribute(schemaElement.attrib["name"], status, "string")
    
    def validateInteger(self, schemaElement, value, intSubtype, isRequired):
        status = "VALID"

        try:
            integerValue = int(value)
        except (ValueError, TypeError):
            if isRequired:
                status = "INTEGER_REQUIRED"
                #return FGISTPAttribute(schemaElement.attrib["name"], "INTEGER_REQUIRED", "int")
            else:
                #return FGISTPAttribute(schemaElement.attrib["name"], "IGNORE_IT")
                status = "IGNORE_IT"

            return FGISTPAttribute(schemaElement.attrib["name"], status)
            
        if intSubtype == "positiveInteger" and integerValue <= 0:
            if isRequired:
                status = "POSITIVE_INTEGER_REQUIRED"
            else:
                status = "IGNORE_IT"
        elif intSubtype == "nonNegativeInteger" and integerValue < 0:
            if isRequired:
                status = "NON_NEGATIVE_REQUIRED"
            else:
                status = "IGNORE_IT"

        return FGISTPAttribute(schemaElement.attrib["name"], status, "int")
    
    def validateFloat(self, schemaElement, value, isRequired):
        status = "VALID"

        try:
            floatValue = float(value)
        except (ValueError, TypeError):
            if isRequired:
                status = "FLOAT_REQUIRED"
            else:
                status = "IGNORE_IT"
            
            return FGISTPAttribute(schemaElement.attrib["name"], status)
            
        if floatValue < 0:
            status = "POSITIVE_REQUIRED"
        elif floatValue == 0:
            if not isRequired:
                status = "IGNORE_IT"

        return FGISTPAttribute(schemaElement.attrib["name"], status, "float")
    
    def validateByPattern(self, schemaElement, pattern, value):
        stringValue = str(value)
        status = "VALID"
    
        if re.search(pattern, stringValue) is None:
            status = "PATTERN_MISMATCH"

        return FGISTPAttribute(schemaElement.attrib["name"], status, "string")
    
    def validateByEnumeration(self, schemaElement, enumeration, value, isRequired):
        status = None

        try:
            integerValue = int(value)
        except (ValueError, TypeError):
            if isRequired:
                status = "INTEGER_REQUIRED"
            else:
                status = "IGNORE_IT"

            return FGISTPAttribute(schemaElement.attrib["name"], status)
    
        for currentElement in enumeration:
            if integerValue == int(currentElement.attrib["value"]):
                status = "VALID"
                
                break
                
        if status is None:
            status = "NOT_IN_ENUMERATION"

        return FGISTPAttribute(schemaElement.attrib["name"], status, "int")

    def createTreeElement(self, document, name, value):
        newElement = document.createElement(name)
        newElement.appendChild(document.createTextNode(self.removeForbiddenSymbols(value.__str__())))

        return newElement

    def removeForbiddenSymbols(self, textString):
        FORBIDDEN_SYMBOLS = ("'", "\\", "\r\n", "\n")
        ALLOWED_SYMBOLS = ("\"", "/", " ", " ")
    
        cleanString = textString
        i = 0
    
        while i < len(FORBIDDEN_SYMBOLS):
            cleanString = cleanString.replace(FORBIDDEN_SYMBOLS[i], ALLOWED_SYMBOLS[i])
            i += 1
    
        return cleanString

    def areConditionsMet(self, conditions):
        if len(conditions) == 0:
            return False

        for condition in conditions:
            separatedString = condition.text.split(":")
            attributeName = separatedString[0]
            attributeValues = separatedString[1].split(",")

            if str(self.attribute(attributeName)) not in attributeValues:
                return False

        return True

    def getClassName(self):
        return self.className

    def getCRS(self):
        return self.crs

    def areAttributesCorrespond(self):
        return self.attributesCorrespond

    def getAttributeSchema(self):
        return self.attributeSchema
