class FGISTPAttribute:
    def __init__(self, name, status, type=None):
        self.name = name
        self.type = type
        self.status = status

    def getName(self):
        return self.name

    def getType(self):
        return self.type

    def getStatus(self):
        return self.status

    def __str__(self):
        return f"{self.name}: {self.type} [{self.status}]"
