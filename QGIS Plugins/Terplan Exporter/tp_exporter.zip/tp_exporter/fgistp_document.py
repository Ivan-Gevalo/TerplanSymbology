from qgis.PyQt.QtXml import QDomDocument, QDomNode
from .bounding_box import BoundingBox

import uuid

class FGISTPDocument (QDomDocument):
    def __init__(self, rootElement, schema):
        super().__init__()

        header = QDomNode(self.createProcessingInstruction("xml", "version=\"1.0\" encoding=\"UTF-8\""))
        self.insertBefore(header, self.documentElement())

        self.root = self.createElement(rootElement)

        for key, value in schema.getNamespaces().items():
            if key not in ("xs", "vc"):
                self.root.setAttribute(f"xmlns:{key}", value)        

        self.root.setAttribute("gml:id", f"Doc_{uuid.uuid4().__str__()}")
        self.root.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
        self.root.setAttribute("xsi:schemaLocation", "http://fgistp fgistp.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd")

        self.appendChild(self.root)

        if schema.isSpatial():
            self.boundingBox = BoundingBox()
            self.createBoundedElement()

    def getRoot(self):
        return self.root

    def getBoundingBox(self):
        try:
            return self.boundingBox
        except AttributeError:
            return None

    def createBoundedElement(self):
        boundedElement = self.createElement("gml:boundedBy")
        envelopeElement = self.createElement("gml:Envelope")
        lowerCornerElement = self.createElement("gml:lowerCorner")
        upperCornerElement = self.createElement("gml:upperCorner")
    
        envelopeElement.appendChild(lowerCornerElement)
        envelopeElement.appendChild(upperCornerElement)
        boundedElement.appendChild(envelopeElement)
        self.root.appendChild(boundedElement)

    def putBoundingCoords(self):
        lowerCornerNode = self.createTextNode(self.boundingBox.getMinX().__str__() + " " + self.boundingBox.getMinY().__str__())
        upperCornerNode = self.createTextNode(self.boundingBox.getMaxX().__str__() + " " + self.boundingBox.getMaxY().__str__())
        
        self.elementsByTagName("gml:lowerCorner").item(0).toElement().appendChild(lowerCornerNode)
        self.elementsByTagName("gml:upperCorner").item(0).toElement().appendChild(upperCornerNode)

    def writeDocumentToFile(self, path):
        with open(path, "w") as documentFile:
            documentFile.write(self.toString(4))
        