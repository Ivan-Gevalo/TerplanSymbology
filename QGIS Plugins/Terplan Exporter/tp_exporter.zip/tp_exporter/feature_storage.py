from .fgistp_feature import FGISTPFeature

class FeatureStorage:
    def __init__(self):
        self.storage = {}
        self.storage["point"] = {}
        self.storage["linestring"] = {}
        self.storage["polygon"] = {}

    def clearStorage(self):
        self.storage["point"].clear()
        self.storage["linestring"].clear()
        self.storage["polygon"].clear()

    def addFeatureToStorage(self, feature):
        geometryType = FGISTPFeature.GEOMETRY_TYPES[feature.geometry().type()]

        if self.storage[geometryType].get(feature.getClassName()) is None:
            self.storage[geometryType][feature.getClassName()] = []

        self.storage[geometryType][feature.getClassName()].append(feature)

    def getStorage(self):
        return self.storage