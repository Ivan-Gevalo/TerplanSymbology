import xml.etree.ElementTree as ET

class XMLSchema:
    def __init__(self, schemaUrl):
        self.schema = ET.parse(schemaUrl).getroot()
        self.namespaces = {}
        self.classes = {}

        for event, namespace in ET.iterparse(schemaUrl, ["start-ns"]):
            prefix, uri = namespace
            self.namespaces[prefix] = uri

        spatialRef = self.schema.find("./xs:annotation/xs:appinfo", self.namespaces).text

        if spatialRef == "spatial":
            self.hasGeometry = True
        else:
            self.hasGeometry = False

    def initClasses(self):
        fgistpClasses = []
        
        for simpleType in self.schema.findall(".//xs:simpleType", self.namespaces):
            if "_CLASSID" in simpleType.get("name"):
                fgistpClasses.append(simpleType)

        for fgistpClass in fgistpClasses:
            className = fgistpClass.attrib["name"].split("_")[0]
            objectCodes = []

            for objectCode in fgistpClass.findall(".//xs:enumeration", self.namespaces):
                objectCodes.append(objectCode.attrib["value"])

            self.classes[className] = {}
            self.classes[className]["objects"] = objectCodes

        if self.hasGeometry == True:
            self.initGeometryTypes()

    def initGeometryTypes(self):
        for key in self.classes.keys():
            self.classes[key]["geometry"] = []

            geometries = self.schema.findall(f".//xs:complexType[@name='{key}_Type']//xs:choice/xs:element", self.namespaces)

            for geometry in geometries:
                if geometry.attrib["ref"] == "gml:MultiPoint":
                    self.classes[key]["geometry"].extend((1, 4))

                if geometry.attrib["ref"] == "gml:MultiCurve":
                    self.classes[key]["geometry"].extend((2, 5, 9, 11))

                if geometry.attrib["ref"] == "gml:MultiSurface":
                    self.classes[key]["geometry"].extend((3, 6, 12))

    def getSchema(self):
        return self.schema

    def getNamespaces(self):
        return self.namespaces

    def getClasses(self):
        return self.classes

    def isSpatial(self):
        return self.hasGeometry
