from qgis.core import QgsFeature
from qgis.PyQt.QtXml import QDomDocument
from osgeo import ogr

import uuid, re

class FGISTPFeature (QgsFeature):
    GEOMETRY_TYPES = {
        0: "point",
        1: "linestring",
        2: "polygon"
    }

    INTEGER_SUBTYPES = ("integer", "positiveInteger", "nonNegativeInteger")

    def __init__(self, feature, crsId):
        super().__init__(feature)

        self.GLOBALID = None
        self.className = None
        self.crs = crsId

    def initGlobalId(self, uniqueIdList):
        idPattern = "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}|\{[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\}"

        try:
            if re.search(idPattern, self.attribute("GLOBALID")) is None or self.attribute("GLOBALID") in uniqueIdList:
                self.GLOBALID = self.generateFeatureId()
            else:
                self.GLOBALID = self.attribute("GLOBALID")
        except KeyError:
            self.GLOBALID = self.generateFeatureId()

        return self.GLOBALID

    def generateFeatureId(self):
        return uuid.uuid4()

    def validateFeature(self, schema):
        if schema.isSpatial() and not self.hasGeometry():
            return (3, None)

        # определение принадлежности объекта к классу, предусмотренному схемой
        for key, value in schema.getClasses().items():
            if str(self.attribute("CLASSID")) in value["objects"]:
                self.className = key
        
                break

        # проверка соответствия типа геометрии объекта требованиям схемы
        if self.className is not None:
            if schema.isSpatial():
                if self.geometry().wkbType() not in schema.getClasses()[self.className]["geometry"]:
                    return (2, None)
        else:
            return (1, None)

        return (-1, self)

    def getXMLFeature(self, document, schema):
        featureMember = document.createElement("gml:featureMember")

        featureElement = document.createElement(f"fgistp:{self.className}")
        featureElement.setAttribute("gml:id", f"ID_{uuid.uuid4().__str__()}")
        featureMember.appendChild(featureElement)
        featureElement.appendChild(self.createTreeElement(document, "fgistp:GLOBALID", self.GLOBALID))
        featureElement.appendChild(self.createTreeElement(document, "fgistp:CLASSID", self.attribute("CLASSID")))

        # валидация значений атрибутов по схеме и добавление атрибутов в XML-дерево
        schemaType = schema.getSchema().find(f".//xs:complexType[@name='{self.className}_Type']", schema.getNamespaces())

        for element in schemaType.findall(".//xs:element", schema.getNamespaces()):
            if element.attrib.get("name") is not None and element.attrib.get("name") not in ("GLOBALID", "CLASSID"):
                try:
                    conditions = element.findall(".//xs:appinfo", schema.getNamespaces())

                    if conditions is not None:
                        if self.areConditionsMet(conditions) == False:
                            continue

                    if element.get("minOccurs") == "0":
                        requiredFlag = False
                    else:
                        requiredFlag = True

                    validValue = self.validateAttribute(schema, element, self.attribute(element.attrib["name"]), requiredFlag)

                    if validValue is not None:
                        featureElement.appendChild(self.createTreeElement(document, f"fgistp:{element.attrib['name']}", validValue))
                except KeyError:
                    continue

        # запись геометрии в случае, если создается пространственный объект
        if schema.isSpatial():
            geomDocument = QDomDocument()
            featureGeometry = self.geometry()

            if not featureGeometry.isMultipart():
                featureGeometry.convertToMultiType()
            
            ogrGeom = ogr.CreateGeometryFromWkt(featureGeometry.asWkt())
            geomDocument.setContent(ogrGeom.ExportToGML(["FORMAT=GML32", f"GMLID=geom_{uuid.uuid4().__str__()}"]))
            geom = geomDocument.firstChild().toElement()
            geom.setAttribute("srsName", self.crs)
            
            featureElement.appendChild(geom)

        return featureMember

    def validateAttribute(self, schema, schemaElement, attributeValue, requiredFlag):
        if schemaElement.attrib["type"] == "xs:string":
            return self.validateString(attributeValue)
        elif schemaElement.attrib["type"] == "xs:integer":
            return self.validateInteger(attributeValue, self.INTEGER_SUBTYPES[0])
        elif schemaElement.attrib["type"] == "xs:positiveInteger":
            return self.validateInteger(attributeValue, self.INTEGER_SUBTYPES[1])
        elif schemaElement.attrib["type"] == "xs:nonNegativeInteger":
            return self.validateInteger(attributeValue, self.INTEGER_SUBTYPES[2])
        elif schemaElement.attrib["type"] == "xs:double":
            return self.validateFloat(attributeValue, requiredFlag)
        else:
            fgistpType = schema.getSchema().find(".//xs:simpleType[@name='" + schemaElement.attrib["type"][7:] + "']", schema.getNamespaces())
            fgistpSubType = fgistpType.find(".//xs:restriction", schema.getNamespaces()).attrib["base"]
    
            if fgistpSubType == "xs:string":
                return self.validateByPattern(fgistpType.find(".//xs:pattern", schema.getNamespaces()).attrib["value"], attributeValue)
            elif fgistpSubType == "xs:integer" or fgistpSubType == "xs:positiveInteger":
                return self.validateByEnumeration(fgistpType.findall(".//xs:enumeration", schema.getNamespaces()), attributeValue)

    def validateString(self, value):
        stringValue = str(value)
    
        if stringValue in ("None", "NULL") or len(stringValue) == 0:
            return None
            
        return self.removeForbiddenSymbols(stringValue)
    
    def validateInteger(self, value, intSubtype):
        try:
            integerValue = int(value)
        except (ValueError, TypeError):
            return None
            
        if intSubtype == "positiveInteger" and integerValue <= 0:
            return None
        elif intSubtype == "nonNegativeInteger" and integerValue < 0:
            return None
        
        return integerValue
    
    def validateFloat(self, value, isRequired):
        try:
            floatValue = float(value)
        except (ValueError, TypeError):
            return None
            
        if floatValue < 0:
            return None
        elif floatValue > 0:
            return floatValue
        elif floatValue == 0:
            if isRequired:
                return floatValue
            else:
                return None
    
    def validateByPattern(self, pattern, value):
        stringValue = str(value)
    
        if re.search(pattern, stringValue) is None:
            return None
            
        return stringValue
    
    
    def validateByEnumeration(self, enumeration, value):
        try:
            integerValue = int(value)
        except (ValueError, TypeError):
            return None
    
        for currentElement in enumeration:
            if integerValue == int(currentElement.attrib["value"]):
                return integerValue
                
        return None

    def createTreeElement(self, document, name, value):
        newElement = document.createElement(name)
        newElement.appendChild(document.createTextNode(value.__str__()))

        return newElement

    def removeForbiddenSymbols(self, textString):
        FORBIDDEN_SYMBOLS = ("'", "\\", "\r\n", "\n")
        ALLOWED_SYMBOLS = ("\"", "/", " ", " ")
    
        cleanString = textString
        i = 0
    
        while i < len(FORBIDDEN_SYMBOLS):
            cleanString = cleanString.replace(FORBIDDEN_SYMBOLS[i], ALLOWED_SYMBOLS[i])
            i += 1
    
        return cleanString

    def areConditionsMet(self, conditions):
        for condition in conditions:
            separatedString = condition.text.split(":")
            attributeName = separatedString[0]
            attributeValues = separatedString[1].split(",")

            if str(self.attribute(attributeName)) not in attributeValues:
                return False

        return True

    def getClassName(self):
        return self.className

    def getCRS(self):
        return self.crs
