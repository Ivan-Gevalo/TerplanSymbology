from qgis.PyQt.QtXml import QDomDocument

class BoundingBox:
    def __init__(self):
        self.minX = 999999999
        self.minY = 999999999
        self.maxX = 0
        self.maxY = 0

    def recalculateBoundingBox(self, featureBound):
        if featureBound.xMaximum() > self.maxX:
            self.maxX = featureBound.xMaximum()
    
        if featureBound.yMaximum() > self.maxY:
            self.maxY = featureBound.yMaximum()
    
        if featureBound.xMinimum() < self.minX:
            self.minX = featureBound.xMinimum()
    
        if featureBound.yMinimum() < self.minY:
            self.minY = featureBound.yMinimum()

    def getMaxX(self):
        return self.maxX

    def getMinX(self):
        return self.minX

    def getMaxY(self):
        return self.maxY

    def getMinY(self):
        return self.minY
        